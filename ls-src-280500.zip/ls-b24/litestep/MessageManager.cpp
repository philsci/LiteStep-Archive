// MessageManager.cpp: implementation of the MessageManager class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)
#include <windows.h>
#include "MessageManager.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MessageManager::MessageManager()
{

}

MessageManager::~MessageManager()
{

}

// [Message Handler Code]
BOOL MessageManager::HandlerExists(UINT uMsg) {
	if (msgMap.find(uMsg) != msgMap.end()) {
		return TRUE;
	} else {
		return FALSE;
	}		
}

HRESULT MessageManager::PassOnMessage(UINT Msg, WPARAM wParam, LPARAM lParam, BOOL wait) {
	HRESULT returnVal = 0;
	windowSet *winSet;
	messageMap::iterator iter1;

	iter1 = msgMap.find(Msg);

	if (iter1 == msgMap.end()) {
		return returnVal;
	}

	winSet = iter1->second;

	windowSet::iterator iter2 = winSet->begin();

	while (iter2 != winSet->end()) {
		if (wait) {
			returnVal |= SendMessage(*iter2, Msg, wParam, lParam);
		} else {
			PostMessage(*iter2, Msg, wParam, lParam);
		}

		iter2++;
	}

	return returnVal;
}

void MessageManager::AddWndMessage(HWND hwnd, UINT Message) {
	windowSet *winSet;
	messageMap::iterator iter;

	iter = msgMap.find(Message);

	if (iter == msgMap.end()) {
		winSet = new windowSet();
		msgMap[Message] = winSet;
	} else {
		winSet = iter->second;
	}

	winSet->insert(hwnd);
}

void MessageManager::AddMessages(HWND hwnd, UINT* Msg) {
	int i = 0;
	while ((Msg[i])) {
		AddWndMessage(hwnd, Msg[i]);
		i++;
	}
}

void MessageManager::RemoveWndMessage(HWND hwnd, UINT Message) {
	messageMap::iterator iter;

	iter = msgMap.find(Message);

	if (iter == msgMap.end()) {
		return;
	}

	iter->second->erase(hwnd);

	if (iter->second->size() == 0) {
		delete iter->second;

		msgMap.erase(iter);
	}
}

void MessageManager::RemoveMessages(HWND hwnd, UINT* Msg) {
	int i = 0;
	while ((Msg[i])) {
		RemoveWndMessage(hwnd, Msg[i]);
		i++;
	}
}

void MessageManager::ClearMessages() {
	messageMap::iterator iter = msgMap.begin();

	while (iter != msgMap.end()) {
		if (iter->second) {
			delete iter->second;
		}
		iter++;
	}

	msgMap.clear();
}
