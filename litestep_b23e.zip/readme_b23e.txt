    *****************************************************************
    * LiteStep version 1.00                                  � 23e  *
    * http://dev.litestep.net                             07/??/98  *
    *                                                               *
    *                        FULL INSTALL                           *
    *****************************************************************
    *         For contact, see at the end of this document.         *
    *****************************************************************


         **Note: If a feature is not listed in this document,
          then chances are you can't do it (yet) so don't ask!**


     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ======================[What is LiteStep?]================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  LiteStep is a shell replacement for Windows 9x/NT (NT not yet fully
  supported) that will give your Windows setup the Afterstep look
  and feel.

  LiteStep consists of a wharf toolbar, a popup menu and some modules.

  The wharf toolbar is used to organize your most-used applications
  & modules. (If you have a small monitor with a lower resolution,
  i.e. 800x600, then you'll probably be best off using the wharf
  for modules only (to conserve screen space.)

  The popup menu automatically gives you access to all installed
  applications (in the step.rc - see below.)

  All modules have a particular function: clock, temperature monitor,
  WinAMP plugins, virtual window manager, CPU load monitor...

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ====================[Why use LiteStep?]==================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

     - If you come from the LINUX world and like AFTERSTEP.

     - If having multiple desktops would make your work easier.

     - If you dislike Microsoft's shell or find it eats too much
       memory, CPU and that it is not always stable.

     - If the appearance aspect of your desktop is important to you.

     - If you like to have something different from your friends.

     Or simply to try a cool & stable alternative to Microsoft's shell.

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | =======================[Installation]====================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  Extract files to C:\LiteStep (or you will have to edit your step.rc)

  Windows 95/98: Either Edit system.ini or use ShellSw to replace
     your shell

     Method 1: edit system.ini:

         [boot]
         shell=explorer.exe

         add a new line, just below, like this:

         [boot]
         shell=c:\litestep\litestep.exe

     and change the 'shell=explorer.exe' to ';shell=explorer.exe',
     without the quotes.

	 Example:

	 [boot]
         ;shell=explorer.exe
	 shell=c:\litestep\litestep.exe

     Method 2: use shellsw:

         install shellsw as indicated in its doc

  NT installation:

    If you desire to use LiteStep and not affect the other users:

     Load RegEdit (Start -> Run -> Type in Regedit, and press enter)
     Add the following value to this key:
       HKCU\Software\Microsoft\Windows NT\Current Version\Winlogon
       Type: DWORD_STRING, Name: Shell, Value: C:\LiteStep\litestep.exe
     Log out, and Log back in

    If you would like all users to use LiteStep:

     Load RegEdit (Start -> Run -> Type in Regedit, and press enter)
     Change the following value of this key:
       HKLM\Software\Microsoft\Windows NT\Current Version\Winlogon
       Name: Shell, change value from EXPLORER.EXE to:
         C:\LiteStep\litestep.exe
     Reboot the system for changes to take effect

  Edit step.rc to match your configuration

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ====================[Uninstalling LiteStep]=====================|
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  Just reverse the installation procedure:

  Windows 95/98:

    edit system.ini:

         [boot]
         ;shell=explorer.exe
         shell=c:\litestep\litestep.exe


    replace by :

         [boot]
         shell=explorer.exe
         ;shell=c:\litestep\litestep.exe

  Windows NT 4.0:

     If LiteStep installation only affected you:
     Load RegEdit (Start -> Run -> Type in Regedit, and press enter)
     Remove the following value from this key:
       HKCU\Software\Microsoft\Windows NT\Current Version\Winlogon
       Value: Shell (DELETE THIS VALUE)

     If LiteStep installation affected all users:
     Load RegEdit (Start -> Run -> Type in Regedit, and press enter)
     Change the following value of this key:
       HKLM\Software\Microsoft\Windows NT\Current Version\Winlogon
       Name: Shell, change value from C:\LiteStep\litestep.exe to:
          EXPLORER.EXE

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ==========================[Usage]========================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  Usage is quiet easy, and there are some tricks that you should know :


    The LSVWM virtual window manager:


     - Left Click & Drag   = drag windows between desktops
     - Right Click         = select desktop
           
     - The LSVWM has definable hotkeys to move throughout the window panes.
       In your modules.ini (if you don't have one, create a modules.txt
       and rename it modules.ini in C:\LiteStep):
          
[lsvwm]
hotkey=0,1,2 (with one of the numbers being your choice).
                 
       0==Winkey (default), 1==ALT, 2==CTRL
       When you have your hotkey defined, use as so:
                      
           HOTKEY+RIGHTARROW
           HOTKEY+LEFTARROW
           HOTKEY+DOWN
           HOTKEY+UP
                  
       *example:
[lsvwm]
hotkey=1
         
       Your Hotkey is ALT, and you would use it like so:
       ALT+UP, ALT+DOWN, ALT+RIGHT, ALT+LEFT

       + Holding the mouse at the screen border will autoswitch desktop
       (configure the resistance to fit your needs, this can also be
       turned off)


     The task manager:

     - Left Click          = Switch to task
     - Right Click         = open system menu
     - Shift-Right Click   = Sets tip to Window class (usefull to set
                             a 64x64 icon)

     WharfAmp:

     - Left-Click          = Switches to WinAmp


     LSClock:

     - Left-DblClick       = Opens Time & Date properties
     - Right-Click         = Brings up Time & Date menu; NTP Setup,
                             Syncronize

     Overall:

     - Alt-Tab             = Switch tasks (this is a regular Windows
                             function)


     Popup Menu

     - Right-Click         = Scroll down BIG popup menus (larger than
                             the screen)
     - WIN Key             = Pop up the menu (if mskey.dll installed)
     - Ctrl-Esc            = Pop up the menu
     - Up/Down             = navigate through the menu
     - Left                = Close current submenu
     - Enter               = Run command
     - Right/Enter         = Open submenu
     - PgDn/PgUp           = See next part of the menu


     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | =========================[step.rc]========================= |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


  Notes:

  => These specifications are subject to change without notice.
  => Step.rc is a straight text file, where lines are delimited with
     carriage returns.
  => Any string may be enclosed by quotes ("). This may be useful for
     long names, paths, and filenames, font names & Wharf tiles.
     Using (") you can include spaces in these.


  Commands
  --------

  - PixmapPath path

    Set the directory where to look for images

    > path = directory where to look at

    (default: images)


  - DefaultBackPix bitmap

    > bitmap = bitmap you want to use as background when you use the
               ".extract" function to automatically assing an icon.

    (default: images\default.bmp)


  - FolderPix bitmap

    > bitmap = bitmap you want to use as layer for wharf folders

    (default: images\3dots.bmp)


  - WharfTitleFontSize n

    Set the font size of the wharf titles (usually only used by the
    Task Manager unless a WharfAllTitles command has been issued)

    > n = size of font in points


  - WharfTitleFont fontname

    Set the font used for the wharf titles (usually only used by the
    task manager unless a WharfAllTitles command has been issued)

    > fontname = name of font


  - WharfTitleFore color

    Set the Wharf titles foreground color

    > color = RGB components of color to be used (hexidecimal numbers
              such as: FFFFFF = white, 000000 = black, 808080 = grey)


  - WharfTitleBack color

    Set the Wharf titles background color

    > color = RGB components of color to be used (hexidecimal numbers
              such as: FFFFFF = white, 000000 = black, 808080 = grey)


  - WharfAllTitles

    Tell LiteStep to put titles on all Wharfs, even normal and folder
    ones.


  - LoadModule modulename

    Load a DLL global module

    > modulename = path & name of the DLL module file to load

    (i.e.: Loadmodule c:\litestep\lsvwm.dll)

  - NTStyleTaskMgr

    Tell Task Manager to behave like NT's explorer shell: that is, when
    a window is the selected window, a click on its icon will minimize it.

    Without this command, the task manager will just switch back to the
    selected window upon clicking on its icon.

    This is not a recommended setting since it is quite confusing (to
    novices).


  - WharfBevelWidth n

    Width of the wharf bevel (thickness of buttons):

    > n = width in pixel


  - WharfPressOffset n

    Offset to shift image for button press effect (usually set to same
    value as WharfBevelWidth):

    > n = shift in pixel


  - WharfNoHints

    Tell LiteStep not to show hints with Wharf names when the mouse
    stops on a Wharf.


  - WharfNoAnim

    Tell LiteStep not to animate opening wharf folders.

  - Icon iconname [.] regexp

    Set the task manager icon for the specified window.

    > iconname = icon to use for the Wharf image
    > . = sets class name regexp instead of window name regexp
    > regexp = regular expression to apply against window name or
               class name (ie: *Netscape will match any window name
               ending with the word 'Netscape')


  - NoShowBeta

    Remove the beta symbol at the top left corner of the screen.


  - AutoHideWharf

    Set the wharf bar to autohide when not selected.


  - AutoHideTaskbar

    Set the taskbar to autohide when not selected.


  - AutoHideDelay

    Set the delay between deselection and auto-hiding of wharf and/or
    taskbar.

  - HideApplication

    Tell litestep.exe to hide its icon from the alt-tab window (Recommended).

  - NoSplashScreen

    Turn off splash screen.
    You may want to design your own splash screen: edit the file
    splash.bmp in your images directory. Keep its dimensions (they are
    fixed at 400x200, sorry). Use color FF00FF for transparency. Thanks
    to Mr. Splif/Aegis (splif@aegis-corp.org) for the artwork.


  - *Wharf

       The *Wharf command may be used in 3 ways:


           - *Wharf wharfname iconname [%systemname] action [parameters]

              Set a new visible Wharf, launching a command

              > wharfname = name to appear in Hints
              > iconname = icon to use as the Wharf image
                or ".extract" to extract from an exe file
                or ".extract=file.exe[or file.dll]"
                or ".extract=file.exe[ir file.dll],n"
                   > n = icon number
              > %systemname = (optional) tells the Wharf systemname
                (used by the WharfAmp plugin for example)
              > action = any action to perform
              > parameters = any parameter to pass to the action

           - *Wharf wharfname iconname Folder

              Set a new visible Wharf, opening a Wharf folder

              > wharfname = name to appear in Hints
              > iconname = icon to use as the Wharf image
              > Folder = Word "Folder"

           - *Wharf ~Folder

              Close Wharf folder definition

              > ~Folder = Word "~Folder"

  - *Popup 

     The Popup command is used in 3 ways:

           - *Popup Entryname action [parameters]

             Set a new entry with its title and action
             (See bellow for special actions)

           - *Popup Entryname Folder

             Set up a new folder

           - *Popup ~Folder

             Close previous folder

  - PopupTitlePix bitmap

    Set texture of title entries in popup menu. Bitmap should be
    approx. 17x400.

  - PopupEntryPix bitmap
                
    Set texture of normal unselected entries in popup menu. Bitmap
    should be approx. 17x400.
               
  - PopupSelEntryPix bitmap
                  
    Sets texture of selected entries in popup menu. Bitmap should
    be approx. 17x400.

  - PopupTitleColor RGBvalue
               
    Set font color for popup title entry. ie: FFFFFF
              
  - PopupEntryColor RGBvalue
               
    Set font color for popup unselected entry. ie: 000000
              
  - PopupSelEntryColor RGBvalue
               
    Set font color for popup selected entry. ie: 000000
             
  - HotListName name
               
    Set name of the root popup menu. ie: HotListName Popup Menu
             
  - NoPopupBevel

    Disables bevel on popup menu. 

  - PopupFontFace fontname

    Specifies font face for popup menu. ie: PopupFontFace "Comic Sans MS"

  - PopupFontHeight number

    Specifies font face height. ie: PopupFontHeight 14
    Note: Negative side-effects may result when using a font size that does
    not fit on the PopupBar (>17 pixels).

  - ShrinkPopupBar

    Shrink bar.bmp to fit Popup Menu size
    Note: All bar .bmp's should be the same size when using this setting

------------------------------------------------------------------------------
  ------ Everything below this line is dedicated to external modules -----

  Desktop:

                  ===CONFIGURATION OF SYSTEM TRAY===

The configuration of the system tray is done through the modules.ini file
in your LiteStep folder. (After you load the new desktop module for the
first time, it will create a section in this file).  The section looks like:

[SysTray]
OnRightSide=1
OnBottomSide=1
Vertical=1
WrapCount=6

If your taskbar is disabled (The line 'NoTaskBar' is uncommented in your
step.rc):

    OnRightSide indicates whether you want the system tray on the left
    (0) or right (1) side of your desktop.

    OnBottomSide indicates whether you want the system tray on the top
    (0) or bottom (1) of your desktop.

    Vertical indicates whether you want your system tray icons to be
    added horizontally (0), or vertically (1).

    WrapCount indicates the number of icons to add in a row or column
    before 'wrapping' to the next row or column.  Set this to a large
    number to keep it from wrapping.

If your taskbar is enabled:

    OnRightSide indicates whether you want the system tray on the left
    (0) or right (1) end of your taskbar.

    None of the other fields are used when the taskbar is turned on.



                          ===AUTORUN===

  Full autorun support is now added in desktop.dll.  Data CD's will
  load up just like they should, and Audio CD's will as well.  Please
  note that Audio CD's are keyed to MS's built-in CD player, but in
  the future you will be able to key this to a wharf CD app if you 
  wish.


  - SysTrayIconSize n

    Specify size of System Tray icons.

    > n = size in pixel

  - NoTaskBar

    Tell desktop.dll not to create a TaskBar.

  - MsTaskBar

    Tell desktop.dll to create a Microsoft-like TaskBar instead of
    LiteStep's implentation.

  - LSTaskBarFore color
  - LSTaskBarFore2 color
  - LSTaskBarBack color
  - LSTaskBarText color

    > color = RGB hexadecimal value of colors for taskbar foreground,
      2nd foreground, background & text

  - StripTaskBar

    Strips the taskbar so wharf and taskbar do not overlap.

  - *Shortcut
                     
    The Desktop shortcuts are added to your step.rc file.  The syntax
    is:
                  
*Shortcut <x-coord> <y-coord> <bitmap> <command_to_execute>
              
    x-coord and y-coord specify the location of the top-left corner
    of the shortcut. If you use a negative value for either of these,
    the value is used to offset from the right or bottom edge of the
    screen.
                
    'bitmap' specifies the image to use for the shortcut.  The image
    must be a .BMP file, and must be located in your LiteStep images
    folder.  As usual, the color FF00FF is used for transparency.
                   
    'Command_to_execute' is the command to perform when this shortcut
    is clicked on.
                   
    Some examples:
               
*Shortcut -128 0 explorer.bmp explorer.exe
*Shortcut -128 64 term.bmp c:\command.com
              
    These will put two icons in the upper right corner of the screen,
    next to the wharf. The top one will launch explorer, and the second
    will launch a command prompt.
                    
*Shortcut 300 250 splash.bmp c:\ns4.0\netscape.exe http://litestep.computerheaven.net
                
    This will put the LiteStep splash screen on your desktop, and when
    clicked, it will take you to the LiteStep homepage.  Of course, this
    assumes that the path to netscape is correct.

  LM78

  - lm78Cpu cputype

    Specify your CPU type for the lm78 monitor

    > cputype = "amd", "cyrix", or "intel"

  - lm78Unit unit

    Specify Temperature units

    > unit = "C" or "F"

  - lm78MaxCpu n

    Specify cpu temperature above witch the warning led flashes

    > n = temperature limit

  - lm78MaxMb n

    Specify mother board temperature above witch the warning led flashes

    > n = temperature limit

  ***Please note that this module only works if your motherboard has LDCM
     temperature monitoring support and is Intel 430TX chipset based.
     Does not function correctly with all supported motherboards.


                  ===Virtual Window Manager===

  - VWMVelocity n

    Set the apparent resistance of screen border

    > n = milliseconds to hold the mouse at the border before switching


  - VWMNoAuto

    Disable VWM AutoSwitch.


  - VWMNoGathering

    Disable gathering of windows upon recycling. (Will not reload any
    programs in the Startup folder and Registry)
    

  - VWMSecurityDistance n

    Set the distance to the border the mouse will be moved to upon
    autoswitch.

  - VWMBackColor color
  - VWMSelBackColor color
  - VWMForeColor color
  - VWMBorderColor color

    Set the VWM colors

                       ===STICKY WINDOWS===

  You can now specify windows that will be "sticky": in other words,
  they follow the active VWM desktop.  This is useful for programs you
  want to have on the desktop at all times. Place these lines in your 
  modules.ini:

[lsvwm]
stickies=1
sticky1=*Winamp

  stickies= is the number of sticky items that are listed, in this
  case only one sticky item is listed so there is a stickies=1.
  Each sticky window is referenced by its window title, and is listed
  in ascending order, i.e. sticky1= , sticky2= , etc.  Note that
  this title is case-sensitive in the modules.ini.  Also note that
  it will accept wildcards in the form of *whatever (as in the
  *Winamp above.)
  You can also reference sticky windows by their window 'class'.
  This has nothing to do with C++ classes, it is one of those weird
  windows things. In order to do this you must excplicitly specify
  stypeN=1 where N is the sticky number. I.e. to make all winamp
  windows (main, EQ, PE) float:

[lsvwm]
stickies=1
sticky1=Winamp*
stype1=1

  Note: You can also specify stypeN=0 to force it to use window titles,
  however this is not needed as lsvwm defaults to titles if it can't
  find the stypeN. (You can put in stypeN for some stickies and not for
  others, the lsvwm doesn't care. To it not specifying is the same as
  stypeN=0.)

  LSCLOCK

  - UsClock

    Set clock to 12h format instead of 24h format.

  X-MOUSE

  - XMouseDelay n

    Set the delay before X-Mouse effect.

  - XMouseBringToTop

    Tell the X-mouse module to bring to top windows touched by pointer
    (no clicking required.)

  - If you want to have X-Mouse functionality under NT, rather than using
    xmouse.dll (for memory/performance sakes, in case you care), add a
    Registry Value to this Key: HKCU\Control Panel\Mouse
    Type: DWORD_BINARY, Name: ActiveWindowTracking, Value (Hex): 1

    *Note that this will only take effect the next time you log in to NT.

  BAKSAVER

  - BackScreenSaver name

    Specify which screen saver will run in background

    > name = full path & name fo screen saver (*.scr)

    This module will work only with screensavers that are able to run in
    the mini-preview mode in Display Properties/Screen Saver. It will not
    work with 3DFX screen savers, nor with screen savers that change your
    screen resolution, such as DirectX-based screensavers.

                          ===HOTKEY.DLL SUPPORT===

  Hotkeys are set in the step.rc. Here are some examples:

*Hotkey Win E explorer
*Hotkey Win R !HotkeyRun
*Hotkey Win S !HotkeyShutdown

  Valid key types are Win, Ctrl, Alt; so if you don't have a Win key you
  can rebind it.  Note that there are two special functions hard-coded,
  !HotkeyRun and !HotkeyShutdown that will pop up the run dialogue and
  give you the shut down menu, respectively.  Also, it will accept any
  path to a program, .lnk file, or .pif file, like so:

*Hotkey Win X c:\4dos\4dos.com

  This would launch 4dos.com.
	
  In NT: Use "%SystemRoot%\system32\rasphone.exe" -lt "whatever file.rnk"
  to run .rnk files, as they are not directly supported at the moment.

                                ===LSVWM===
  New hotkey support for LSVWM.DLL has been added. Unfortunately, this
  info is contained in modules.ini at the moment (it will be moved in
  the next release to the step.rc) under this heading:

[lsvwm]
Hotkey=0

  Where the hotkey values are 0 = WIN, 1 = ALT, 2 = CTRL.  

  Also, you can specify a background image the same way you would a
  folder image (in step.rc):

*Wharf lsvwm somebmp.bmp lsvwm.dll



------------------------------------------------------------------------------

  Actions for Wharf
  -----------------


    !WharfRecycle

       Reload LiteStep configuration and Wharfs.

    !WharfShutdown

       Opens Shutdown/Restart/MS-DOS/Logoff menu.

    !WharfLogoff

       Close all programs and Logoff.

    !WharfTasks
              
       Opens task manager

    d:\path\filename.exe [params]

       Runs the specified filename

    @c:\path\module.dll

       Loads the specified Wharf module
       NOTE: This commands takes effect DURING THE STEP.RC LOADING,
       not when you click on the wharf!

    !WharfRun

       Pops up the Run box.

  Actions for Popup
  -----------------

    !PopupStartMenu

       Automatically inserts the Start Menu folder contents in the
       popup's tree hierarchy.

    !PopupShutdown

       Opens Shutdown/Restart/MSDOS/Logoff Menu.

    !PopupLogoff

       Close all programs and logoff.

    !PopupQuit

       Unloads LiteStep while Windows is still running (you'll rarely use
       this).

    !PopupPrograms 

       Fills following tree with contents of the programs system folder.

    !PopupRecentDocs

       Fills following tree with contents of the recently open documents
       system folder.

    !PopupPersonal

       Fills following tree with contents of the personal documents
       system folder

    !PopupDesktop

       Fills following tree with items from explorer's desktop (except
       system items such as Network Neighborhood, My Computer, Recycle
       Bin.)

    !PopupFolder:...

       Fills following tree with contents of the specified folder. 
       ie: !PopupFolder:C:\Temp
       (Warning: putting big trees like root folders will make the
       popup menu loading very slow, as it has to read all objects
       in that folder.)

    !PopupRun

       Pops up the run box.

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ===========================[TIPS]========================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

     Here are some tips you can use to customize your STEP.RC:

      - "explorer /e" will open explorer in the Desktop section.
      - "explorer /s" will open an explorer cabinet (.cab) file
      - The file "Exit To Dos.PIF" in your windows directory will
        shutdown windows and exit to DOS
      - "control filename.cpl" will open the specific control panel
        application (i.e.: "control timedate.cpl" will open time and
        date properties.)
      - You can make .LNK files (shortcuts) and launch them (useful
        for Network Neighborhood.)
      - You can also launch any document, just put its name (ie:
        mytext.doc)

     Specials for NT users:
      - "%SystemRoot%" is the directory Windows NT is installed in
        (C:\WINNT)
      - "%SystemDrive%" is the drive Windows NT is installed to (C:)
      - "%UserProfile%" is your directory where you keep your
         personal files (Start Menu, Desktop, etc.)

     For more advanced users:

     When you know the CLSID of an explorer namespace (in the Windows
     registry), you can use it this way:

     (extract from MS SDK Help)

         - If the junction point is an item under the desktop:

           explorer.exe /e,/root,::{CLSID of item}


         - If the junction point is an item under My Computer:

           explorer.exe /e,/root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}
           \::{CLSID of item}
   

         - If the junction point is a file system folder:

           explorer.exe /e,/root, [path to a junction point]


      For an example, look at the default step.rc. The control panel is
      run using this method.


     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | ===========================[BUGS]========================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

     - If you have found a bug, go to http://litestep.ru.ac.za/bugs/
       and report it. The LiteStep Development Team always checks
       over these pages. Remember, if the bug you have is aready
       listed on the page, 'check' that bug and it'll be notified
       that you have the same problem too (priorities).

     - The lsvwm (Virtual Window Manager) is still not perfect in its
       behavior. When you have only one app open in a desktop and you
       close/minimize it, it should not switch desktop. Sometimes it
       does.  Also, because of its drawing method, all your apps
       sometime disappear.  This doesn't happen very often, but it
       *will* be fixed in the future.
     
     - Sometimes (very rarely), lsvwm's border is white... Never seen
       it, but we've had such reports (in fact, one ;)

     - *Very* buggy windows installations may not be able to boot back
       or load Explorer.  *We've seen this only ONCE* and on a VERY
       BUGGY WINDOWS installation.  If your Windows does this, it's
       time to deltree C:\Windows and reinstall <=
       
       Since there is STRICTLY NO CODE in litestep TO WRITE ANYTHING
       ANYWHERE (this was one of the main directions of this software,
       so you have total control over it), blame Microsoft if something
       goes wrong :)

     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
     | =======================[The Future]======================== |
     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  This is the very first release of LiteStep by the offical Dev Team.
  We want to hear your feedback, so please come to #litestep on IRC's
  EFNet, or send an email to us at any of the email addresses below :)


      NOTE: In the directory SDK/ you can find the Software
            Developement Kit to build wharf modules. Be creative,
            and write something for everyone to use!

    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
    | ===========================[Info]========================== |
    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  LiteStep is still in beta stage.

  LiteStep is freeware, so you use it at your own risk. The LiteStep
  Development Team cannot be held responsible for any damage (software or
  hardware) that happens while using LiteStep.

  LiteStep is free to use & give to your friends, we do not ask for any
  money, nor do we offer any official technical support. However, if you
  have some questions, consult the EFNet IRC network #LiteStep channel.

  URLs:

   Dev Page                   - http://dev.litestep.net   
   Official Site              - http://litestep.computerheaven.net
   Floach's Site              - http://floach.ml.org      
   Col_KFC's Bucket o' Themes - http://kfc.themes.org
   Official FAQ               - http://litestep.base.org
   The Litestep Distro        - http://www.litestep.net

    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
    | ============================[Thanks]========================|
    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

  Francis Gastellu (Lonerunnr - gastellu@club-internet.fr) 
    - For helping us all of the way through our first [small]
      release, and releasing the source for us to get our hands on. :)

  Brandon Williams (Floach - floach@pimpin.net)
    - As our project leader/coordinator, Brandon pushed us on to our
      first release :)
         
  Philip Bowens (Scheisse - pbowens@dcr.net)
    - Webpage development, minor coordination

  Bryan Kilian (MHolmesIV - bryan@rucus.ru.ac.za)
    - CVS tree, LCE, LS Mailing Lists     

  Aaron Putnam (Azerov - azerov@yahoo.com)
    - Desktop development

  Damian Hodgkiss (sc/mian - mian@mindless.com)
    - Hotkey.dll

  Jonathan Vaughn (Sehnsucht - silverh@mindspring.com)
    - LSVWM development

  Chris Jenkins (j_edge - j_edge@earthling.net)
    - Desktop & LSVWM development, popup work

  Chris Williams (Chris\  - chris@litestep.net)
    - Webspace

  Edwin Man (TheMAN - theman@utopia2.com)
    - NT consulting, Beta testing, Docs editor/writer

          README written by Philip Bowens and Brandon Williams
                 Editors: Edwin Man and Jonathan Vaughn
    Batteries not included, best used when dry - at room tempature.
