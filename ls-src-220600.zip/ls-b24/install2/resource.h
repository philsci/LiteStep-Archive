//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDBACK                          3
#define IDD_AGREE                       101
#define IDB_BITMAP1                     102
#define IDD_INSTALL_TYPE                103
#define IDD_INSTALL_SETTINGS            104
#define IDD_PROGRESSBAR                 105
#define IDD_HELP                        106
#define IDD_INSTALL_COMPLETE            107
#define IDD_SYSTEM_SETTINGS             108
#define IDD_ALLDONE                     110
#define IDD_UPGRADE_SETTINGS            111
#define IDD_NT_ADMINORNOT               113
#define IDD_SYSTEM_SETTINGS_NT_1        114
#define IDD_SYSTEM_SETTINGS_NT_2        115
#define IDC_EDIT1                       1001
#define IDC_EDIT_NTINFO                 1001
#define IDC_EDIT_REG_HKLMNEW            1001
#define IDC_EDIT_AGREE                  1002
#define IDC_EDIT_REG_HKLMNEW2           1002
#define IDC_EDIT_INI_OLDSETTING         1003
#define IDC_EDIT_ALLDONE                1004
#define IDC_EDIT_LSDIR                  1005
#define IDC_EDIT_INI_NEWSETTING         1006
#define IDC_EDIT_WINDIR                 1007
#define IDC_EDIT_STARTDIR               1008
#define IDFULL                          1009
#define IDUPGRADE                       1010
#define IDC_CHANGE_LSDIR                1011
#define IDC_CHANGE_WINDIR               1012
#define IDC_CHANGE_STARTDIR             1013
#define IDEXIT                          1014
#define IDINSTALL                       1015
#define IDC_COMBO_WINVER                1016
#define IDC_PROGRESS_FILECOPY           1017
#define IDC_EDIT_HELP                   1018
#define IDNEXT                          1019
#define IDC_EDIT_CONFIGINFO             1020
#define IDC_STATIC_INILOCATION          1021
#define IDC_STATIC_HEADER               1022
#define IDC_STATIC_KEYNAME              1023
#define IDC_EDIT_LMDIR                  1024
#define IDC_EDIT_WMDIR                  1025
#define IDC_CHANGE_LMDIR                1026
#define IDC_CHANGE_WMDIR                1027
#define IDADMIN                         1028
#define IDNOTADMIN                      1029
#define IDC_STATIC_HKLM_KEY             1030
#define IDC_STATIC_HKLM_ITEM            1031
#define IDC_STATIC_HKCU_KEY2            1032
#define IDC_STATIC_HKCU_ITEM2           1033
#define IDC_EDIT_REG_HKCUNEW            1034
#define IDC_EDIT_REG_HKLMOLD            1035
#define IDC_EDIT_REG_HKCUOLD            1036
#define IDC_EDIT_REG_HKCUOLD2           1037
#define IDC_EDIT_REG_HKCUNEW2           1038
#define IDC_STATIC_HKCU_KEY             1039
#define IDC_STATIC_HKCU_ITEM            1040
#define IDC_EDIT_REG_HKLMOLD2           1041
#define IDC_STATIC_HKLM_KEY2            1042
#define IDC_STATIC_HKLM_ITEM2           1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
