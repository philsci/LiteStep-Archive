#ifndef __NTPFRAC_H
#define __NTPFRAC_H

extern long ntpfracTable[];

#endif