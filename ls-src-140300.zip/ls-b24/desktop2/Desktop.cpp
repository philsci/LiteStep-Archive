#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <malloc.h>
#include <commctrl.h>
#include <dbt.h>
//#include "../lsutil/LSh"
#include "Desktop.h"
#include "../lsapi/lsapi.h"

Desktop *myDesktop;

Desktop::Desktop(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
	trayIconSize = GetRCInt("SysTrayIconSize", 16);
	setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
	sdaLeft = GetRCInt("SDALeft", 0);
	sdaRight = GetRCInt("SDARight", 600);
	sdaTop = GetRCInt("SDATop", 0);
	sdaBottom = GetRCInt("SDABottom", 450);
	autoHide = GetRCBool("AutoHideTaskBar", TRUE);
}

// -------------------------------------------------------------------------------------------------------
// Initialization of the module
// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
	myDesktop = new Desktop(ParentWnd, dllInst, szPath);

	myDesktop->initModule(ParentWnd, dllInst, szPath);
    
	return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
// -------------------------------------------------------------------------------------------------------
void quitModule(HINSTANCE dllInst) {
	myDesktop->quitModule(dllInst);
	delete myDesktop;
}

// window procedure for our window
LRESULT CALLBACK Desktop::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	Desktop *theDesktop = (Desktop*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theDesktop) {
		return theDesktop->WindowProc(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

// -----------------------------------------------------------------------------------------------
//  Compares drive type to drives that have autorun enabled set in registry 
//		(using getAutorunDrives()) and if enabled launches open= entry in autorun.inf
// -----------------------------------------------------------------------------------------------
void Desktop::autorun(int drive) {
    unsigned char *pDriveData;
    UINT uDriveType;
    char szDrive[4] = " :\\";
    BOOL floppyNoAutorun = TRUE;
    BOOL fixedNoAutorun = TRUE;
    BOOL netNoAutorun = TRUE;
    BOOL cdNoAutorun = TRUE;
    BOOL ramNoAutorun = TRUE;
    char szInfFilename[15];
    char szOpenEntry[_MAX_PATH];
    char szCommandline[_MAX_PATH];
    STARTUPINFO sInfo;
    PROCESS_INFORMATION pInfo;
    BOOL bResult;
	
    // get info for drive that media has been inserted in
    *szDrive = (char) (drive+(int)'A');
    uDriveType = GetDriveType(szDrive);
	
    // figure out which drives have autorun disabled in registry
    pDriveData = getAutorunDrives();
    floppyNoAutorun = ( 0x04 & *pDriveData );
    fixedNoAutorun = ( 0x08 & *pDriveData );
    netNoAutorun = ( 0x10 & *pDriveData );
    cdNoAutorun = ( 0x20 & *pDriveData );
    ramNoAutorun = ( 0x40 & *pDriveData );
	
    free(pDriveData);
	
    // return if drive has autorun disabled
    switch(uDriveType) {
    case DRIVE_REMOVABLE:
		if( floppyNoAutorun )
			return;
		break;
    case DRIVE_FIXED:
		if( fixedNoAutorun )
			free(pDriveData);
		return;
		break;
    case DRIVE_REMOTE:
		if( netNoAutorun )
			return;
		break;
    case DRIVE_CDROM:
		if( cdNoAutorun )
			return;
		else { 
			// handle AudioCD's here since they should be the only media type
			// this pertains to (can you play an audio cd over a network?)
			char szVolumeName[12];
			DWORD dwVolSerNum;
			DWORD dwMaxCompLength;
			DWORD dwFileSystemFlags;
			char szFileSysName[10];
			HINSTANCE hResult;
			
			GetVolumeInformation( szDrive, szVolumeName, sizeof(szVolumeName), 
				&dwVolSerNum, &dwMaxCompLength, &dwFileSystemFlags, szFileSysName,
				sizeof(szFileSysName) );
			
			// only do this if it's an audio cd & AudioAutoplay is enabled
			if( (strcmp( szVolumeName, "Audio CD" ) == 0) && bAudioAutoplay ) {	
				hResult = ShellExecute(GetDesktopWindow(), "play", "track01.cda", 
					NULL, szDrive, SW_SHOW );
				return;
			} else if( strcmp( szVolumeName, "Audio CD" ) == 0 )
				return;			// AudioAutoplay is disabled in MODULES.INI
		}		
		break;
    case DRIVE_RAMDISK:
		if( ramNoAutorun )
			return;
		break;
    default:
		return;
		break;
    }
    
    // if we've made it this far, it's a data cd so check if there's an autorun.inf
    // and if so get the "open" entry from it & execute it
    _makepath( szInfFilename, szDrive, NULL, "Autorun", ".inf" );
	
    GetPrivateProfileString( "autorun", "open", "", szOpenEntry, 
		sizeof(szOpenEntry), szInfFilename );
	
    if( !*szOpenEntry )
		return;
	
    strcpy( szCommandline, szDrive );
    strcat( szCommandline, szOpenEntry );
	
    memset( &sInfo, 0, sizeof(sInfo) );
    sInfo.cb=sizeof(sInfo);
    sInfo.wShowWindow=SW_SHOWNORMAL;
	
	
    bResult = CreateProcess( NULL, szCommandline, NULL, NULL, FALSE,
		CREATE_NEW_PROCESS_GROUP, NULL, szDrive, &sInfo, &pInfo );
    
    if(!bResult)
    {
		char lpMsgBuf[256];
		
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL, GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf, 0, NULL );
		
		MessageBox(NULL, lpMsgBuf, "ERROR:CreateProcess() failed", 
			MB_OK|MB_ICONINFORMATION );
		
		LocalFree( lpMsgBuf );
		return;
    }
	
    if(pInfo.hProcess)
		CloseHandle( pInfo.hProcess );
    if(pInfo.hThread)
		CloseHandle( pInfo.hThread );
}

// -----------------------------------------------------------------------------------------------
// used by autorun()
// -----------------------------------------------------------------------------------------------
unsigned char *Desktop::getAutorunDrives( void ) 
{
    HKEY hKey = NULL;
    DWORD dwType, dwSize = 0;
    unsigned char *pDriveData = NULL;
    char *lpzRegistryString =
		"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer";
    LONG result;
	
    result = RegOpenKeyEx( HKEY_CURRENT_USER, lpzRegistryString, 
		(unsigned long)NULL, KEY_READ, &hKey );
	
    if (result == ERROR_SUCCESS)
    {
		result = RegQueryValueEx( hKey, "NoDriveTypeAutorun", NULL, &dwType, NULL, &dwSize );
		
		if (result == ERROR_SUCCESS)
		{
			pDriveData = (unsigned char *)malloc(dwSize);
			RegQueryValueEx( hKey, "NoDriveTypeAutorun", NULL, &dwType, pDriveData, &dwSize );
		}
		RegCloseKey( hKey );
    }
	
    if (!pDriveData)
    {
		pDriveData = (unsigned char *) malloc (1);
		
		*pDriveData = '\0';
    }
    return pDriveData;
}


int Desktop::initModule(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	/////////////////////////////////////////////////////////////////////////////////////////////

   	WNDCLASSEX wc;
	
    parent = ParentWnd;

	// get windows version info
    memset (&os_info, 0, sizeof (os_info));
    os_info.dwOSVersionInfoSize = sizeof (os_info);
    GetVersionEx (&os_info);
    
	// set up screen sizes
    ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
    ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	
    // Register Desktop window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   	wc.lpfnWndProc = Desktop::WndProc;				// our window procedure
   	wc.hInstance = dllInst;					// hInstance of DLL
   	wc.lpszClassName = szAppName;			// our window class name
   	wc.style = 0;

   	if (!RegisterClassEx(&wc)) {
		MessageBox(parent,"Error registering window class","Desktop",MB_OK);
		return 1;
   	}

	// Find the litestep main window
    HWND hContWnd = GetLitestepWnd();
    
	// Desktop Window (main window)
   	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,							// exstyles 
		szAppName,									// our window class name
		"LSDesktop",								// use description for a window title
        WS_POPUP|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,	// styles
		0, 0,										// position 
		ScreenWidth,ScreenHeight,					// width & height of window
		hContWnd,									// parent window 
		NULL,										// no menu
		dllInst,									// hInstance of DLL
		NULL);										// no window creation data
	if (!hMainWnd) {						   
		MessageBox(parent,"Error creating window","Desktop",MB_OK);
		return 1;
    }

	// Set class pointer into window for access later
	SetWindowLong(hMainWnd, LS_GWL_CLASSPOINTER, (LONG)this);
	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	
	// show the main window
	SetCursor(LoadCursor(NULL,IDC_ARROW));
	SetWindowPos(hMainWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	setMinMax();

	return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void Desktop::quitModule(HINSTANCE dllInst) { 
    int Msgs[6];
    
    DestroyWindow(hMainWnd); // delete our window
	
	Msgs[0] = LM_GETREVID;
	Msgs[1] = LM_CHECKFORAPPBAR;
	Msgs[2] = LM_REPAINT;
	Msgs[3] = LM_ADDWINDOW;
	Msgs[4] = LM_REMOVEWINDOW;
	Msgs[5] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	
	resetMinMax();

    UnregisterClass(szAppName,dllInst); // unregister window class
}

LRESULT Desktop::WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
	case LM_GETREVID:
		{
			char *buf = (char *) lParam;
			
			if (wParam == 0) {
				strcpy(buf, "desktop.dll: ");
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = '\0';
			} else if (wParam == 1) {
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = '\0';
			} else {
				strcpy(buf, "");
			}
			return strlen(buf);
		}
		
	case WM_DISPLAYCHANGE:
		{	
            // Screen resolution has changed. Change things accordingly
			
            int cxScreen = LOWORD(lParam); 
            int cyScreen = HIWORD(lParam);

            ScreenWidth = cxScreen;
            ScreenHeight = cyScreen;
		}
        return 0;
		
	case WM_DEVICECHANGE:
		{
			// A device has changed in the system
			PDEV_BROADCAST_HDR pdbch;
			PDEV_BROADCAST_VOLUME pdbcv;
			if (wParam != DBT_DEVICEARRIVAL) return TRUE;
			pdbch = (PDEV_BROADCAST_HDR) lParam;
			switch (pdbch->dbch_devicetype) {
			case DBT_DEVTYP_VOLUME:
				pdbcv = (PDEV_BROADCAST_VOLUME) pdbch;
				if (pdbcv->dbcv_flags == DBTF_MEDIA)  {
					int i;
					for (i =0; i< 26;i++) {
						if (pdbcv->dbcv_unitmask & (1 << i)) {
							if( !(GetAsyncKeyState( VK_SHIFT ) & 0x8000) )
								autorun(i); // Call autorun on a specific drive
						}
					}
				}
				return TRUE;
			default:
				return TRUE;
			}
		}
	case WM_MOUSEACTIVATE:
		PostMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam)); // Close any popup open
		return MA_ACTIVATE;
	case WM_ACTIVATE:
		SendMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		if (LOWORD(wParam)) SetActiveWindow(parent);
		return 0;
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_CREATE:
		return 0;
	case WM_ERASEBKGND:
		{
			PaintDesktop( (HDC) wParam );
			return TRUE;
		}
	case LM_REPAINT: // Manually ask for a paint (stupid)
	case WM_PAINT:
		{ // update from doublebuffer
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
			
			PaintDesktop(hdc);
			//if (!appBar && np++ == 0) // If this is the first time we paint, tell it to litestep
			PostMessage(parent, LM_FIRSTDESKTOPPAINT, 0, 0);
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_SYSCOMMAND:
		{
			switch (wParam) {
			case SC_CLOSE: // stupid but works
				PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				break;
			}
			
			break;
		}
	case WM_KEYDOWN:
		{
			int i=0;
			i++;
		}
	case WM_KEYUP:
		{ // forward
			PostMessage(parent,message,wParam,lParam);
		}
		return 0;
	case WM_HOTKEY:
		{
			int i=0;
			i++;
		}
	case WM_WINDOWPOSCHANGING:
		{
			// Trap windowposchanging messages
			WINDOWPOS *c = (WINDOWPOS*)lParam;
			c->hwndInsertAfter = HWND_BOTTOM;
			c->flags |= SWP_NOMOVE | SWP_NOSIZE;
		}
		return 0;
	case WM_NCPAINT: // one more security
		if (!wParam)
			SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
		return 0;
	case WM_RBUTTONUP: // Open popup menu
		SendMessage(parent, LM_POPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_LBUTTONUP:
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_RBUTTONDOWN: // Close popup menu
	case WM_LBUTTONDOWN:
	case WM_MBUTTONDOWN:
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
    }
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Sets maximized windows size
// -------------------------------------------------------------------------------------------------------
void Desktop::setMinMax(void) {
	RECT r;
	
	if (!setDesktopArea) {
		return;
	}
	SystemParametersInfo(SPI_GETWORKAREA,0,(PVOID)&r,SPIF_SENDCHANGE);
	origWorkArea = r;
	r.bottom = ScreenHeight - ((autoHide) ? 1 : (trayIconSize+10));
	SetDesktopArea(r.left, r.top, r.right, r.bottom);
	
	if (setDesktopArea) {
		r.left = sdaLeft;
		r.top = sdaTop;
		r.right = sdaRight<0 ? ScreenWidth+sdaRight:sdaRight;
		r.bottom = sdaBottom<0 ? ScreenHeight+sdaBottom:sdaBottom;
		SetDesktopArea(r.left, r.top, r.right, r.bottom);
	}
}

// -------------------------------------------------------------------------------------------------------
// Reset to old maximized windows size
// -------------------------------------------------------------------------------------------------------
void Desktop::resetMinMax(void)
{
	RECT r;
	
	if (!setDesktopArea)
		return;
	r.top = 0;
	r.left = 0;
	r.bottom = ScreenHeight;
	r.right = ScreenWidth;
	SetDesktopArea(r.left, r.top, r.right, r.bottom);
}
