/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05/19/00 - Bobby G. Vinyard (Message)
  - Moved hInst into shared memory section
  - Does not return HSHELL_WINDOWCREATED/DESTROYED for cmd.exe under w2k
     (may have something to do with threading)
  - Skip catching HSHELL_TASKMAN, HSHELL_LANGUAGE, HSHELL_ACTIVATESHELLWINDOW
     they were causing lockups in win9x
05/18/00 - Bobby G. Vinyard (Message)
  - Removed the following libs from being linked (thet weren't needed):
    uuid.lib odbc32.lib odbccp32.lib gdi32.lib winspool.lib comdlg32.lib 
    ole32.lib oleaut32.lib advapi32.lib
  - Removed headers files that were not needed
  - Revised shell message handling, the shell messages are now sent only to 
    litestep to be handled by msgmgr and not hookmgr
  - Removed InstallShellFilter, shell hook is now install automatically
  - GetMsgProc no longer uses WM_COPYDATA, instead the LM_SHELLMESSAGE is sent
    to hookmgr with:
    wParam: Specifies whether the message has been removed from the queue
    lParam: Pointer to an MSG structure that contains details about the message
****************************************************************************/
#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "../lsapi/lsapi.h"
#define HOOK_DLL
#include "hook.h"
#include <stdlib.h>
#pragma data_seg("SHAREDATA")
static HHOOK g_hHookShell=0;    // Hook for WH_SHELL
static HHOOK g_hHookMessage =0; // Hook for WH_GETMESSAGE
static HWND parent=NULL;        // HWND of process loading hook.dll
static HWND hLS = NULL;
static HINSTANCE hInst=NULL;
#pragma data_seg()


void AttachHookDll(HWND hwndParent) {
  
  if (hwndParent) {

    MINIMIZEDMETRICS mm;
  
    hLS = FindWindow( TEXT("TApplication"), TEXT("Litestep") );

    // Store hwnd of Parent, this will be used later to send captured messages
    parent = hwndParent;

    // Prevent windows from being shown when minimized
    memset(&mm, 0, sizeof(MINIMIZEDMETRICS));
    mm.cbSize = sizeof(MINIMIZEDMETRICS);
    SystemParametersInfo(SPI_GETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);
    mm.iArrange |= ARW_HIDE; // ARW_HIDE == 8
    SystemParametersInfo(SPI_SETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);

    g_hHookShell = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellProc, hInst, 0);
		if (!g_hHookShell)
			MessageBox(parent, "Error creating shell Hook!", "Hook", MB_OK);

  } else {
    // Unload shell filter
		UnhookWindowsHookEx(g_hHookShell);
    g_hHookShell = 0;
    // Unload msg filter
    InstallMsgFilter(false);
  }
}

/*
Installs and uninstall the message filter
*/
bool InstallMsgFilter(bool install) {
  if ((install) && !(g_hHookMessage)) {
    // Create message hook
    g_hHookMessage = SetWindowsHookEx(WH_GETMESSAGE, (HOOKPROC)GetMsgProc, hInst, 0);
    if (!g_hHookMessage)
      MessageBox(parent, "Error creating message Hook!", "Hook", MB_OK);
  }
  else if (!(install) && (g_hHookMessage)) {
    UnhookWindowsHookEx(g_hHookMessage);
    g_hHookMessage = 0;
  }
  if (g_hHookMessage == NULL) return false;
  return true;
}

/*
Call back for WH_SHELL
*/
LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
  /*char test[25];
  char* ptest = test;
  itoa(nCode, ptest, 25);
  OutputDebugString(test);*/
  if (nCode < 0)
    return CallNextHookEx( g_hHookShell, nCode, wParam, lParam );
  switch (nCode) {
    case HSHELL_TASKMAN:
    case HSHELL_ACTIVATESHELLWINDOW:
    case HSHELL_LANGUAGE:
      break;
    default:
      SendMessage( hLS, nCode + 9500, wParam, lParam );
  }
  return 0;
}

/*
Call back for WH_GETMESSAGE
*/
LRESULT CALLBACK GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam )
{
  if ( nCode >= 0 ) {
    SendMessage(parent, LM_SHELLMESSAGE, wParam, lParam);
  }
  return (CallNextHookEx(g_hHookMessage, nCode, wParam, lParam));
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  if (fdwReason == DLL_PROCESS_ATTACH) {
    // We don't need thread notifications for what we're doing.  Thus, get
    // rid of them, thereby eliminating some of the overhead of this DLL,
    // which will end up in nearly every GUI process anyhow.
    DisableThreadLibraryCalls(hinstDLL);
    hInst = hinstDLL;
  }
  return TRUE;
}
