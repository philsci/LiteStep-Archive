#include "LSToolTips.h"

// Constructor
LSToolTips::LSToolTips(HWND toolWnd) {
	hToolWnd = toolWnd;
}

// -------------------------------------------------------------------------------------------------------
// Create task button tooltip
// -------------------------------------------------------------------------------------------------------
void LSToolTips::CreateTooltip(HWND hWnd, char *txt, RECT *r)
{
    TOOLINFO ti;    // tool information
	
    if (!hToolWnd)
    {
		return;
    }
	
    ti.cbSize = sizeof(TOOLINFO);
    ti.uFlags = TTF_SUBCLASS;
    ti.hwnd = hWnd;
	ti.hinst = (HINSTANCE)GetCurrentProcess();
    ti.uId = 0;
    ti.lpszText = txt;
    ti.rect = *r;
	
    SendMessage(hToolWnd, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

// -------------------------------------------------------------------------------------------------------
// Update task button tooltip
// -------------------------------------------------------------------------------------------------------
void LSToolTips::UpdateTooltip(HWND hWnd, char *txt, RECT *r)
{
    TOOLINFO ti;    // tool information
    char cleartext[256];
	
    if (!hToolWnd)
    {
		return;
    }
    memset(cleartext, 0, sizeof(cleartext));
    strcpy(cleartext, txt);
	
    ti.cbSize = sizeof(TOOLINFO);
    ti.uFlags = TTF_SUBCLASS;
    ti.hwnd = hWnd;
    ti.hinst = (HINSTANCE)GetCurrentProcess();
    ti.uId = 0;
    ti.lpszText = cleartext;
    ti.rect = *r;
	
    SendMessage(hToolWnd, TTM_UPDATETIPTEXT, 0, (LPARAM) (LPTOOLINFO) &ti);
}
// -------------------------------------------------------------------------------------------------------
// Remove task button's tooltip
// -------------------------------------------------------------------------------------------------------
void LSToolTips::RemoveTooltip(HWND hWnd/*, HWND hwndTT*/)
{
    TOOLINFO ti;    // tool information
    RECT r={0,0,0,0};
	
    ti.cbSize = sizeof(TOOLINFO);
    ti.uFlags = 0;
    ti.hwnd = hWnd;
    ti.hinst = (HINSTANCE)GetCurrentProcess();
    ti.uId = 0;
    ti.lpszText = NULL;
    ti.rect = r;
	
    SendMessage(hToolWnd, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}
