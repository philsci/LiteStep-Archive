// StandardWindowList.h: interface for the StandardWindowList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_)
#define AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <vector>
#include "../core/ifcs.h"

#define WINDOWLIST_CLASS "WindowListClass"
#define WINDOWLIST_TITLE "Window List Manager"

using namespace std;

class StandardWindowList: public IWindowList
{
public:
	StandardWindowList(HINSTANCE hInstance);
	virtual ~StandardWindowList();
	
	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	////////////////////////////////////////////////////////////////////////////
	// From IDispatch
    HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo);
		
	HRESULT STDMETHODCALLTYPE GetTypeInfo( 
		/* [in] */ UINT iTInfo,
		/* [in] */ LCID lcid,
		/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
	
	HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
		/* [in] */ REFIID riid,
		/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
		/* [in] */ UINT cNames,
		/* [in] */ LCID lcid,
		/* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
	
	/* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
		/* [in] */ DISPID dispIdMember,
		/* [in] */ REFIID riid,
		/* [in] */ LCID lcid,
		/* [in] */ WORD wFlags,
		/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
		/* [out] */ VARIANT __RPC_FAR *pVarResult,
		/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
		/* [out] */ UINT __RPC_FAR *puArgErr);
		
	/////////////////////////////////////////////////////////////////////////////
	// From IWindowList
    /* [id] */ HRESULT STDMETHODCALLTYPE GetWindow( 
        /* [in] */ long index,
        /* [out] */ OLE_HANDLE __RPC_FAR *hwnd);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE FindWindow( 
        /* [in] */ OLE_HANDLE hwnd,
        /* [out] */ long __RPC_FAR *index);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE GetWindowList( 
        /* [out] */ SAFEARRAY __RPC_FAR * list,
		/* [out] */ long * count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE GetWindowCount( 
        /* [out] */ long __RPC_FAR *count);
        
    /* [id] */ HRESULT STDMETHODCALLTYPE EnumerateWindows( 
        /* [in] */ ENUMPROC enumProc,
        /* [in] */ LPARAM lParam,
		/* [out] */ long *count);

	/////////////////////////////////////////////////////////////////////////////
	// Internal methods
	LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);
	static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);
	static int CALLBACK EnumProc(HWND hwnd, LPARAM lParam);

private:
	typedef vector<OLE_HANDLE> hwndVect;

	long refCount;
	hwndVect windowList;
	//HWND winList[200];
	//int nWin;
	BOOL InWinList(OLE_HANDLE hwnd);
	HINSTANCE hInstance;
	void AddWindow(OLE_HANDLE hwnd);
	void RemoveWindow(OLE_HANDLE hwnd);
	HWND hWnd;
	HWND hWndParent;

};

#endif // !defined(AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_)
