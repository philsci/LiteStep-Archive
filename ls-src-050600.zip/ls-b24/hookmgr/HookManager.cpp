/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05/18/00 - Bobby G. Vinyard (Message)
  - Rewrote hookmgr to handle only WM messages and to d2 format 
****************************************************************************/
#include "HookManager.h"

const char szAppName[] = "Hook Manager Window"; // Our window class, etc
Hookmanager *hookmanager; // The module

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  Window::init(dllInst);
  hookmanager = new Hookmanager(ParentWnd, code);
  return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete hookmanager;
}

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Hookmanager::Hookmanager(HWND parentWnd, int& code):
Window(szAppName)
{
  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, 0,
                    0, 0, 0, 0, parentWnd))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  numMessages = 0;

  AttachHookDll(hWnd);

  code = 0;

}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Hookmanager::~Hookmanager()
{
  msg2hwnd::iterator m2hit;

  while (!m2hmap.empty()) {
    m2hit = m2hmap.begin();
    delete m2hit->second;
    m2hmap.erase(m2hit);
  }

  AttachHookDll(NULL);

  destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Hookmanager::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
    MESSAGE(onLMRegisterMessage,     LM_REGISTERMESSAGE)
    MESSAGE(onLMUnregisterMessage,     LM_UNREGISTERMESSAGE)
    MESSAGE(onLMShellMessage,     LM_SHELLMESSAGE)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Hookmanager::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}



void Hookmanager::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Hookmanager::onLMRegisterMessage(Message& message) {
  sMsgHookList* psHwnds;
  msg2hwnd::iterator m2hit;

  if (numMessages == 0) { 
    if (InstallMsgFilter(true)) {
      psHwnds = new sMsgHookList;
      psHwnds->insert((HWND)message.wParam);
      m2hmap.insert(msg2hwnd::value_type((UINT)message.lParam,psHwnds));
      numMessages++;
    }
  }
  else {
    m2hit = m2hmap.find((UINT)message.lParam);
    if (m2hit == m2hmap.end()) {
      psHwnds = new sMsgHookList;
      psHwnds->insert((HWND)message.wParam);
      m2hmap.insert(msg2hwnd::value_type((UINT)message.lParam,psHwnds));
    }
    else {
      psHwnds = (*m2hit).second;
      psHwnds->insert((HWND)message.wParam);
    }
    numMessages++;
  }
}


void Hookmanager::onLMUnregisterMessage(Message& message) {
  sMsgHookList *psHwnds;
  sMsgHookList::iterator lit;
  msg2hwnd::iterator m2hit;
  
  if (numMessages) {
    m2hit = m2hmap.find((UINT)message.lParam);
    if (m2hit != m2hmap.end()) {
      psHwnds = (*m2hit).second;
      lit = psHwnds->find((HWND)message.wParam);
      if (lit == psHwnds->end()) {
        psHwnds->erase(lit);
        if (psHwnds->empty()) {
          delete (*m2hit).second;
          m2hmap.erase(m2hit);
        }
        numMessages--;
        if (!numMessages) {
          InstallMsgFilter(false);
        }
      }   
    }
  }
}


void Hookmanager::onLMShellMessage(Message& message) {
  sMsgHookList *psHwnds;
  sMsgHookList::reverse_iterator lrit;
  msg2hwnd::iterator m2hit;
  PMSG msg = (PMSG)message.lParam;

  m2hit = m2hmap.find(msg->message);
  if (m2hit != m2hmap.end()) {
    psHwnds = (*m2hit).second;
    for(lrit=psHwnds->rbegin(); lrit != psHwnds->rend(); lrit++) {
      PostMessage(*lrit, LM_SHELLMESSAGE, message.wParam, message.lParam);
    }
  }
}

