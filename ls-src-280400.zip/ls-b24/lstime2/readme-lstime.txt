Skin entries
------------
BitmapFile <PATH><FILE.BMP>
DigiClockFont sourceX sourceY WIDTH HEIGHT
DateFont sourceX sourceY WIDTH HEIGHT
DigiClock destinationX destinationY
DigiDay destinationX destinationY
DigiMonth destinationX destinationY
Digi2dYear destinationX destinationY
DigiYear destinationX destinationY
AnaDayFont 0 24 18 13
AnaDay destinationX destinationY
AnaMonthFont 0 37 18 13
AnaMonth destinationX destinationY
AnaClock sourceX sourceY WIDTH HEIGHT
HourHandColor BBGGRR
HourHandShade BBGGRR
MinHandColor BBGGRR
MinHandShade BBGGRR
SecHandColor BBGGRR