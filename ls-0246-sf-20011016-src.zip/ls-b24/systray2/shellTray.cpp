/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "shellTray.h"
#include <algorithm>

using namespace std;

// don't know the purpose of this one...
#define MAGICDWORD         0x49474541

// pass message structure
typedef struct SHELLTRAYDATA {
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
} SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;


// this is the version of NOTIFYICONDATA that shell32.dll v5 uses
typedef struct _NOTIFYICONDATAV5 {
    DWORD cbSize;
    HWND hWnd;
    UINT uID;
    UINT uFlags;
    UINT uCallbackMessage;
    HICON hIcon;
    WCHAR szTip[128];
    DWORD dwState;
    DWORD dwStateMask;
    WCHAR szInfo[256];
    union {
        UINT  uTimeout;
        UINT  uVersion;
    } DUMMYUNIONNAME;
    WCHAR szInfoTitle[64];
    DWORD dwInfoFlags;
} NOTIFYICONDATAV5, *PNOTIFYICONDATAV5;


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: grdShellTray()                                * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:
/* *                                                         * */
/* *   HWND hTray                                            * */
/* *   the _TEXT("parent") tray window                              * */
/* *                                                         * */
/* *   HINSTANCE dll                                         * */
/* *   the current instance                                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: initialize the shellTray class                 * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

shellTray::shellTray (HWND lswnd, HINSTANCE hInstance) {

	// temporary variables
	WNDCLASSEX wc;

	/* *************************************** */
	/* *     STORE THE INFORMATION PASSED    * */
	/* *************************************** */

	hLiteStep = lswnd;


	/* *************************************** */
	/* *     REGISTER THE SHELLTRAY CLASS    * */
	/* *************************************** */

   	memset(&wc,0,sizeof(wc));

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS ;
	wc.lpfnWndProc = (WNDPROC) shellTray::WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = 0;
	wc.lpszClassName = WC_SHELLTRAY;

   	if (!::RegisterClassEx(&wc))
	{
		_TCHAR szText [MAX_LINE_LENGTH+1];
 		::GetResStr( hInstance, IDS_SYSTRAY2_ERROR1, szText, MAX_LINE_LENGTH,
			_TEXT("Error registering window class"));
		::MessageBox( hLiteStep, szText, WC_SHELLTRAY, MB_OK | MB_TOPMOST);
	}

	/* *************************************** */
	/* *     CREATE THE SHELLTRAY WINDOW     * */
	/* *************************************** */

	hShellTray = ::CreateWindowEx( WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
								   WC_SHELLTRAY,
								   TEXT(_TEXT("grdSysTrayManager")),
								   WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
								   0,0,
								   0,0,
								   hLiteStep,
								   NULL,
								   (HINSTANCE)0,
								   NULL );

	if ( !hShellTray )
	{
		_TCHAR szText [MAX_LINE_LENGTH + 1];
		::GetResStr( hInstance, IDS_SYSTRAY2_ERROR2, szText, MAX_LINE_LENGTH,
			_TEXT("Error creating window"));
		::MessageBox( hLiteStep,szText, WC_SHELLTRAY, MB_OK | MB_TOPMOST);
	}


	/* *************************************** */
	/* *      ADJUST THE SYSTRAY WINDOW      * */
	/* *************************************** */

	// set the magicDWord
	::SetWindowLong( hShellTray, GWL_USERDATA, (LONG)MAGICDWORD );

	// save the class handle as a window long
	::SetWindowLong( hShellTray, 0, (LONG)this );

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: ~grdShellTray()                               * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: destroy the shellTray class                    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

shellTray::~shellTray ( ) {

	// the window could be deleted
	::DestroyWindow( hShellTray );

	// the class could be unregistered
	::UnregisterClass( WC_SHELLTRAY, 0 );

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WndProc()                             * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: forward the window's messages                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

LRESULT CALLBACK shellTray::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {

	shellTray *theShellTray = (shellTray*)::GetWindowLong(hwnd, 0);

	if (theShellTray)
		return theShellTray->WindowProc(hwnd, message, wParam, lParam);

	else
        return DefWindowProc(hwnd, message, wParam, lParam);

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WindowProc()                          * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: handle the window's messages                   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

LRESULT shellTray::WindowProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam ) {

	switch( nMessage )
	{

		case WM_COPYDATA:
		{

			// odd conversion... don't know about this...
			PNOTIFYICONDATA pnid = NULL;
			PNOTIFYICONDATAV5 pnid5 = NULL;

			PCOPYDATASTRUCT pcds;
			PSHELLTRAYDATA pstd;

			BOOL result = FALSE;

			pcds = (PCOPYDATASTRUCT) lParam;

			if( pcds->dwData != 1 )
				return FALSE;

			pstd = (PSHELLTRAYDATA) pcds->lpData;

			if ( pstd->nid.cbSize == sizeof( NOTIFYICONDATAV5 ) ) {

				pnid5 = (PNOTIFYICONDATAV5)&pstd->nid;
				pnid = (PNOTIFYICONDATA)new BYTE[sizeof(NOTIFYICONDATA)];

				pnid->cbSize		   = sizeof(NOTIFYICONDATA);
				pnid->hWnd			   = pnid5->hWnd;
				pnid->uID			   = pnid5->uID;
				pnid->uFlags		   = pnid5->uFlags;
				pnid->uCallbackMessage = pnid5->uCallbackMessage;
				pnid->hIcon			   = pnid5->hIcon;
				pnid->szTip[0]		   = '\0';

				if ( pnid5->szTip == NULL )
					pnid->szTip[0] = '\0';
				else {

					UINT nChars = min( UINT( wcslen( pnid5->szTip ) + 1 ), UINT(64) );

					::WideCharToMultiByte(CP_ACP, 0, pnid5->szTip, nChars, (_TCHAR *)&pnid->szTip, nChars, NULL, NULL);

					// just to ensure last character is a NULL... :P
					pnid->szTip[63] = '\0';

				}

				result = (BOOL)::SendMessage( hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM)pnid );

				delete[] pnid;

			} else {

				result = (BOOL)::SendMessage( hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM)&pstd->nid );

			}

			return result;

		}

	}

	return ::DefWindowProc( hWnd, nMessage, wParam, lParam );
}

