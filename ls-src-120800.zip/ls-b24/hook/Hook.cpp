/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
06/03/00 - Bobby G. Vinyard (Message)
  - Aww... yet another rewrite of hook (Back to using WM_COPYDATA, silly me
     you can't pass the pointer to the MSG struct from GetMsgProc)
  - Probably should be using WM_CALLWNDPROC or WM_CALLWNDPROCRET but these
     lock my system up everytime i try set one... =\ ( so the implementation
     is commented out for now)
05/19/00 - Bobby G. Vinyard (Message)
  - Moved hInst into shared memory section
  - Does not return HSHELL_WINDOWCREATED/DESTROYED for cmd.exe under w2k
     (may have something to do with threading)
  - Skip catching HSHELL_TASKMAN, HSHELL_LANGUAGE, HSHELL_ACTIVATESHELLWINDOW
     they were causing lockups in win9x
05/18/00 - Bobby G. Vinyard (Message)
  - Removed the following libs from being linked (thet weren't needed):
    uuid.lib odbc32.lib odbccp32.lib gdi32.lib winspool.lib comdlg32.lib 
    ole32.lib oleaut32.lib advapi32.lib
  - Removed headers files that were not needed
  - Revised shell message handling, the shell messages are now sent only to 
    litestep to be handled by msgmgr and not hookmgr
  - Removed InstallShellFilter, shell hook is now install automatically
  - GetMsgProc no longer uses WM_COPYDATA, instead the LM_SHELLMESSAGE is sent
    to hookmgr with:
    wParam: Specifies whether the message has been removed from the queue
    lParam: Pointer to an MSG structure that contains details about the message
****************************************************************************/
#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "../lsapi/lsapi.h"
#define HOOK_DLL
#include "hook.h"
#include <stdlib.h>

#pragma data_seg("SHAREDATA")
static HHOOK g_hHookShell=0;    // Hook for WH_SHELL
static HHOOK g_hHookMessage =0; // Hook for WH_GETMESSAGE
//static HHOOK g_hHookCallWnd =0;
#pragma data_seg()

HWND hwndHookMgr = NULL;
HWND hwndLiteStep = NULL;
HINSTANCE hInst=NULL;

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  UNREFERENCED_PARAMETER(lpvReserved);
  if (fdwReason == DLL_PROCESS_ATTACH) {
    hInst = hinstDLL;
    hwndHookMgr = FindWindow(HOOKMGRWINDOWCLASS, HOOKMGRWINDOWNAME);
    hwndLiteStep = FindWindow("TApplication", "LiteStep");
  }
  return TRUE;
}

void setShellHook(HHOOK hShell) {
  g_hHookShell = hShell;
}

HHOOK getShellHook() {
  return g_hHookShell;
}

void setMsgHook(HHOOK hMSG) {
  g_hHookMessage = hMSG;
}

HHOOK getMsgHook() {
  return g_hHookMessage;
}
/*
void setCallWndHook(HHOOK hCallWnd) {
  g_hHookCallWnd = hCallWnd;
}

HHOOK getCallWndHook() {
  return g_hHookCallWnd;
}
*/
/*
Call back for WH_SHELL
*/
LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
  if (nCode < 0)
    return CallNextHookEx( g_hHookShell, nCode, wParam, lParam );
  switch (nCode) {
    case HSHELL_TASKMAN:
    case HSHELL_ACTIVATESHELLWINDOW:
    case HSHELL_LANGUAGE:
      break;
    default:
      if ((hwndLiteStep == NULL) || (!IsWindow(hwndLiteStep))) {
        hwndLiteStep = FindWindow("TApplication", "LiteStep");
      }
      if (hwndLiteStep != NULL) {
        PostMessage(hwndLiteStep, nCode + 9500, wParam, lParam );
      }
  }
  return 0;
}


bool ProcessGetMsg(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
  if ((hwndHookMgr == NULL) || (!IsWindow(hwndHookMgr))) {
    hwndHookMgr = FindWindow(HOOKMGRWINDOWCLASS, HOOKMGRWINDOWNAME);
  }
  if (hwndHookMgr != NULL) {
    gcds.dwData = msg;
    msgd.hwnd = hwnd;
    msgd.message = msg;
    msgd.lParam = lParam;
    msgd.wParam = wParam;
    SendMessage(hwndHookMgr, WM_COPYDATA, (WPARAM)msg, (LPARAM)&gcds);
  }
  return true;
}


/*
Call back for WH_GETMESSAGE
*/
LRESULT CALLBACK GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam )
{
  PMSG pmsg;
  pmsg = (PMSG)lParam;
  UINT msg = pmsg->message;
  if ((nCode >= 0) && pmsg && pmsg->hwnd ) {
    if (msg < WM_USER) {
      switch (msg)
      {
        case WM_TIMER:
          break;
        case WM_PAINT:
          break;
        case WM_ERASEBKGND:
          break;
        case WM_NCPAINT:
          break;
        case WM_COPYDATA:
          break;
        default:
          ProcessGetMsg(pmsg->hwnd, pmsg->message, pmsg->wParam, pmsg->lParam);
      }
    }
  }
  return (CallNextHookEx(g_hHookMessage, nCode, wParam, lParam));
}


/*
Call back for WH_CALLWNDPROC
*//*
LRESULT CALLBACK CallWndProc(int nCode, WPARAM wParam, LPARAM lParam )
{
  PCWPSTRUCT pmsg;
  pmsg = (PCWPSTRUCT)lParam;
  UINT msg = pmsg->message;
  if ((nCode >= 0) && pmsg && pmsg->hwnd ) {
    if (msg < WM_USER) {
      switch (msg)
      {
        case WM_TIMER:
          break;
        case WM_PAINT:
          break;
        case WM_ERASEBKGND:
          break;
        case WM_NCPAINT:
          break;
        case WM_COPYDATA:
          break;
        default:
          if (pmsg->message == WM_CREATE) {
            _LSDEBUG1("CallWndProc WM_CREATE");
          }
          ProcessGetMsg(pmsg->hwnd, pmsg->message, pmsg->wParam, pmsg->lParam);
          break;
      }
    }
  }
  return (CallNextHookEx(g_hHookCallWnd, nCode, wParam, lParam));
}
*/