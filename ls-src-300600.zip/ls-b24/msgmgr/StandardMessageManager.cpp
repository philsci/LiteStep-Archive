/*

  This is a part of the LiteStep Shell Source code.
  
  Copyright (C) 1997-98 The LiteStep Development Team
    
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
      
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
    
*/


/****************************************************************************
06/04/00 - Bobby G. Vinyard. (Message)
  - Changed from PostMessage to SendMessage in GetRevId since it was waiting
     for a return string (per Maduin)
04/08/00 - Bobby G. Vinyard. (Message)
  - Added GetRevID method for handling !about (NOTE: this method is likely to
    disappears when a method is implemented to return a list of hwnds for
    a given message

****************************************************************************/

// StandardMessageManager.cpp: implementation of the StandardMessageManager class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)
#include <windows.h>
#include <comdef.h>
#include "StandardMessageManager.h"
#include "..\lsapi\lsapi.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StandardMessageManager::StandardMessageManager()
{
	refCount = 0;
}

StandardMessageManager::~StandardMessageManager()
{
	ClearMessages();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StandardMessageManager::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IMessageManager) {
		*ppv = static_cast<IMessageManager*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StandardMessageManager::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StandardMessageManager::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

////////////////////////////////////////////////////////////////////////////
// From IModuleManager

HRESULT STDMETHODCALLTYPE StandardMessageManager::AddMessage( 
    /* [in] */ OLE_HANDLE window,
    /* [in] */ UINT message) {
	windowSet *winSet;
	messageMap::iterator iter;

	iter = msgMap.find(message);

	if (iter == msgMap.end()) {
		winSet = new windowSet();
		msgMap[message] = winSet;
	} else {
		winSet = iter->second;
	}

	winSet->insert(window);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::AddMessages( 
    /* [in] */ OLE_HANDLE window,
    /* [in] */ SAFEARRAY __RPC_FAR * messages) {
	long lBound;
	long uBound;
	long size;
	
	UINT *msgs = 0;

	SafeArrayGetUBound(messages, 1, &uBound);
	SafeArrayGetLBound(messages, 1, &lBound);

	size = uBound - lBound + 1;

	SafeArrayAccessData(messages, (void**)&msgs);

	for (long i = 0; i < size; i++) {
		AddMessage(window, msgs[i]);
	}

	SafeArrayUnaccessData(messages);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::RemoveMessage( 
    /* [in] */ OLE_HANDLE window,
    /* [in] */ UINT message) {
	messageMap::iterator iter;

	iter = msgMap.find(message);

	if (iter == msgMap.end()) {
		return S_OK;
	}

	iter->second->erase(window);

	if (iter->second->size() == 0) {
		delete iter->second;

		msgMap.erase(iter);
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::RemoveMessages( 
    /* [in] */ OLE_HANDLE window,
    /* [in] */ SAFEARRAY __RPC_FAR * messages) {
	long lBound;
	long uBound;
	long size;
	
	UINT *msgs = 0;

	SafeArrayGetUBound(messages, 1, &uBound);
	SafeArrayGetLBound(messages, 1, &lBound);

	size = uBound - lBound + 1;

	SafeArrayAccessData(messages, (void**)&msgs);

	for (long i = 0; i < size; i++) {
		RemoveMessage(window, msgs[i]);
	}

	SafeArrayUnaccessData(messages);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::ClearMessages(void) {
	messageMap::iterator iter = msgMap.begin();

	while (iter != msgMap.end()) {
		if (iter->second) {
			delete iter->second;
		}
		iter++;
	}

	msgMap.clear();

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::SendMessage( 
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam,
	/* [retval][out] */ LRESULT __RPC_FAR *retval) {
	windowSet *winSet;
	messageMap::iterator iter1;

	if( retval )
		*retval = 0;

	iter1 = msgMap.find(message);

	if (iter1 == msgMap.end()) {
		return S_OK;
	}

	winSet = iter1->second;

	windowSet::iterator iter2 = winSet->begin();

	// use first one for result
	if( iter2 != winSet->end() )
	{
		if( retval )
		{
			*retval = ::SendMessage( (HWND) *iter2, message, wparam, lparam );
			iter2++;
		}
	}

	while (iter2 != winSet->end()) {
		::SendMessage((HWND)*iter2, message, wparam, lparam);

		iter2++;
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::PostMessage( 
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam) {
	windowSet *winSet;
	messageMap::iterator iter1;

	iter1 = msgMap.find(message);

	if (iter1 == msgMap.end()) {
		return S_OK;
	}

	winSet = iter1->second;

	windowSet::iterator iter2 = winSet->begin();

	while (iter2 != winSet->end()) {
		::PostMessage((HWND)*iter2, message, wparam, lparam);

		iter2++;
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::HandlerExists( 
    /* [in] */ UINT message,
    /* [retval][out] */ BOOL __RPC_FAR *exists) {
	if (msgMap.find(message) != msgMap.end()) {
		*exists = TRUE;
	} else {
		*exists = FALSE;
	}		

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::GetRevID( 
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam) {
	windowSet *winSet;
	messageMap::iterator iter1;

	iter1 = msgMap.find(message);

	if (iter1 == msgMap.end()) {
		return S_OK;
	}

	winSet = iter1->second;

	windowSet::iterator iter2 = winSet->begin();
  char buffer[1024];
	while (iter2 != winSet->end()) {
    buffer[0] = '\0';
		::SendMessage((HWND)*iter2, message, wparam, (LPARAM)buffer);
    ::SendMessage((HWND)lparam, message, 0, (LPARAM)buffer);
		iter2++;
	}

  return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::GetWindowsForMessage( UINT message, SAFEARRAY **retval )
{
	if( retval )
		*retval = NULL;
	else
		return E_POINTER;

	messageMap::iterator iter = msgMap.find( message );

	windowSet *windows;
	int count;

	if( iter != msgMap.end() )
	{
		windows = iter->second;
		count = windows->size();
	}
	else
	{
		windows = NULL;
		count = 0;
	}

	SAFEARRAY *array = SafeArrayCreateVector( VT_I4, 0, count );

	if( !array )
		return E_OUTOFMEMORY;

	if( windows )
	{
		OLE_HANDLE *arrayData;
		SafeArrayAccessData( array, (void **) &arrayData );

		windowSet::iterator is = windows->begin();
		int i = 0;

		while( is != windows->end() && i < count )
			arrayData[i++] = *is++;

		SafeArrayUnaccessData( array );
	}

	*retval = array;
	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardMessageManager::GetMessagesForWindow( OLE_HANDLE hWnd, SAFEARRAY **retval )
{
	if( retval )
		*retval = NULL;
	else
		return E_POINTER;

	set<UINT> messages;
	messageMap::iterator im = msgMap.begin();

	while( im != msgMap.end() )
	{
		windowSet *windows = im->second;
		windowSet::iterator is = windows->begin();

		while( is != windows->end() )
		{
			if( *is == hWnd )
			{
				messages.insert( im->first );
				break;
			}
			
			is++;
		}

		im++;
	}

	int count = messages.size();
	SAFEARRAY *array = SafeArrayCreateVector( VT_I4, 0, count );

	if( !array )
		return E_OUTOFMEMORY;

	if( count > 0 )
	{
		OLE_HANDLE *arrayData;
		SafeArrayAccessData( array, (void **) &arrayData );

		set<UINT>::iterator is = messages.begin();
		int i = 0;

		while( is != messages.end() && i < count )
			arrayData[i++] = *is++;

		SafeArrayUnaccessData( array );
	}

	*retval = array;
	return S_OK;
}
