/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-2000 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05/17/00 - Joachim Calvert (NeXTer)
  - Added the command !ShortcutGroupOnTopToggle.
05/12/00 - Joachim Calvert (NeXTer)
  - If a shortcut is started as hidden, the resources for it aren't created
    until it is shown, substantially decreasing the time to load LS if there
    are many hidden shortcuts.
04/27/00 - Joachim Calvert (NeXTer)
  - You now have to preceed any creation flags with '#', otherwise it'll be
    assumed that it's the command.
04/26/00 - Joachim Calvert (NeXTer)
  - After som thorough testing by rootrider, it should now be pretty stable.
    Currently supported bang commands are !ShortcutGroupToggle,
    !ShortcutGroupShow, !ShortcutGroupHide, !ShortcutGroupOnTop &
    !ShortcutGroupOnBottom, followed by one or more group numbers, or * to
    perform the operation on all groups.
04/25/00 - Joachim Calvert (NeXTer)
  - Complete rewrite from scratch, 2nd edition. The first edition
    accidentally got overwritten when I had finished it...
****************************************************************************/

#include <stdio.h>
#include <windows.h>
#include <commctrl.h>

#include "shortcut.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/safestr.h"

using namespace std;

//---------------------------------------------------------
// Global defs and vars
//---------------------------------------------------------

const char szAppName[] = "ShortcutClass"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.11 $"; // Our Version
const char rcsId[] = "$Id: shortcut.cpp,v 1.11 2000/05/17 20:00:36 NeXTer Exp $"; // The Full RCS ID.

const leaveTimerId = 1;

ShortcutFactory* shortcutFactory;
HWND desktopWnd;


//---------------------------------------------------------
// Module startup and shutdown
//---------------------------------------------------------

int initModuleEx(HWND parentWnd, HINSTANCE, LPCSTR)
{
  int code;

  desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
  if (!desktopWnd)
    desktopWnd = GetDesktopWindow();

  new ShortcutFactory(shortcutFactory, parentWnd, code);

  return code;
}


void quitModule(HINSTANCE)
{
  delete shortcutFactory;
}


//=========================================================
// ShortcutFactory ////////////////////////////////////////
//=========================================================

ShortcutFactory::ShortcutFactory(ShortcutFactory*& self, HWND parentWnd, int& code):
Window(szAppName)
{
  self = this;
  shortcutHints = CreateWindow
  (
    TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
    CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
    NULL, NULL, hInstance, NULL
  );
  if (shortcutHints)
    SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

  createWindow(WS_EX_TOOLWINDOW, "ShortcutFactory", WS_POPUP,
               0, 0, 0, 0, parentWnd);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  createShortcuts();
}


ShortcutFactory::~ShortcutFactory()
{
  destroyWindow();
}


void ShortcutFactory::relayHintMessage(HWND hWnd, Message& message)
{
  MSG hintMessage = {hWnd, message.uMsg, message.wParam, message.lParam};

  if (!shortcutHints)
    return;
  SendMessage(shortcutHints, TTM_RELAYEVENT, 0, LPARAM(&hintMessage));
  SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}


void ShortcutFactory::addHint(HWND hWnd, LPSTR caption)
{
  TOOLINFO ti;
  RECT clientRect;

  if (!shortcutHints)
    return;
  GetClientRect(hWnd, &clientRect);
  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = TTF_SUBCLASS;
  ti.hwnd = hWnd;
  ti.uId = 0;
  ti.rect = clientRect;
  ti.hinst = hInstance;
  ti.lpszText = caption;
  ti.lParam = 0;
  SendMessage(shortcutHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::removeHint(HWND hWnd)
{
  TOOLINFO ti;
  RECT emptyRect = {0, 0, 0, 0};

  if (!shortcutHints)
    return;
  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = 0;
  ti.hwnd = hWnd;
  ti.uId = 0;
  ti.rect = emptyRect;
  ti.hinst = hInstance;
  ti.lpszText = NULL;
  ti.lParam = 0;
  SendMessage(shortcutHints, TTM_DELTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::createShortcuts()
{
  char configLine[MAX_LINE_LENGTH];
  FILE* step = LCOpen(NULL);
  DWORD groupNumber;
  ShortcutMap::iterator smIter;
  Shortcut* newShortcut;

  if (step)
  {
    while (LCReadNextConfig(step, "*shortcut", configLine, MAX_LINE_LENGTH))
    {
      newShortcut = new Shortcut(configLine, groupNumber);
      smIter = shortcutGroups.find(groupNumber);
      if (smIter == shortcutGroups.end())
        shortcutGroups.insert(ShortcutMap::value_type(groupNumber, newShortcut));
      else
      {
        newShortcut->append(smIter->second);
        smIter->second = newShortcut;
      }
    }
    LCClose(step);
  }
}


void ShortcutFactory::setVisible(LPCSTR groups, int state)
{
  char group[MAX_LINE_LENGTH];
  LPCSTR nextGroup = groups;
  ShortcutMap::iterator smIter;

  if (CharInStr('*', groups))
  {
    for (smIter = shortcutGroups.begin(); smIter != shortcutGroups.end(); smIter++)
      if (smIter->second)
        smIter->second->setVisible(state);
  }
  else while (GetToken(nextGroup, group, &nextGroup, false))
  {
    smIter = shortcutGroups.find(atoi(group));
    if (smIter != shortcutGroups.end())
      if (smIter->second)
        smIter->second->setVisible(state);
  }
}


void ShortcutFactory::setTopMost(LPCSTR groups, int topMost)
{
  char group[MAX_LINE_LENGTH];
  LPCSTR nextGroup = groups;
  ShortcutMap::iterator smIter;

  if (CharInStr('*', groups))
  {
    for (smIter = shortcutGroups.begin(); smIter != shortcutGroups.end(); smIter++)
      if (smIter->second)
        smIter->second->setTopMost(topMost);
  }
  else while (GetToken(nextGroup, group, &nextGroup, false))
  {
    smIter = shortcutGroups.find(atoi(group));
    if (smIter != shortcutGroups.end())
      if (smIter->second)
        smIter->second->setTopMost(topMost);
  }
}


//---------------------------------------------------------
// Bang commands
//---------------------------------------------------------

void ShortcutFactory::bangGroupToggle(HWND sender, LPCSTR args)
{
  shortcutFactory->setVisible(args, 0);
}


void ShortcutFactory::bangGroupShow(HWND sender, LPCSTR args)
{
  shortcutFactory->setVisible(args, 1);
}


void ShortcutFactory::bangGroupHide(HWND sender, LPCSTR args)
{
  shortcutFactory->setVisible(args, -1);
}


void ShortcutFactory::bangGroupOnTop(HWND sender, LPCSTR args)
{
  shortcutFactory->setTopMost(args, true);
}


void ShortcutFactory::bangGroupOnBottom(HWND sender, LPCSTR args)
{
  shortcutFactory->setTopMost(args, false);
}


//---------------------------------------------------------
// Message handling
//---------------------------------------------------------

void ShortcutFactory::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onGetRevId, LM_GETREVID)
  END_MESSAGEPROC
}


void ShortcutFactory::onCreate(Message& message)
{
  int lsMessages[] = {LM_GETREVID, 0};

  SendMessage(hParent, LM_REGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

  AddBangCommand("!shortcutgrouptoggle", bangGroupToggle);
  AddBangCommand("!shortcutgroupshow", bangGroupShow);
  AddBangCommand("!shortcutgrouphide", bangGroupHide);
  AddBangCommand("!shortcutgroupontoptoggle", bangGroupOnTop);
  AddBangCommand("!shortcutgroupontop", bangGroupOnTop);
  AddBangCommand("!shortcutgrouponbottom", bangGroupOnBottom);
}


void ShortcutFactory::onDestroy(Message& message)
{
  ShortcutMap::iterator smIter;
  int lsMessages[] = {LM_GETREVID, 0};

  for (smIter = shortcutGroups.begin(); smIter != shortcutGroups.end(); smIter++)
    if (smIter->second)
      delete smIter->second;

  if (shortcutHints)
    DestroyWindow(shortcutHints);

  SendMessage(hParent, LM_UNREGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

  RemoveBangCommand("!shortcutgrouptoggle");
  RemoveBangCommand("!shortcutgroupshow");
  RemoveBangCommand("!shortcutgrouphide");
  RemoveBangCommand("!shortcutgroupontoptoggle");
  RemoveBangCommand("!shortcutgroupontop");
  RemoveBangCommand("!shortcutgrouponbottom");
}


void ShortcutFactory::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "shortcut.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


//=========================================================
// Shortcut ///////////////////////////////////////////////
//=========================================================

Shortcut::Shortcut(LPCSTR szLine, DWORD& group):
Window(szAppName),
next(NULL),
riCurrent(NULL),
caption(NULL),
command(NULL),
commandArgs(NULL),
normalName(NULL),
hoverName(NULL),
clickName(NULL),
state(ssNormal),
isTopMost(false),
isVisible(true),
leaveTimer(0),
left(0),
top(0),
width(32),
height(32)
{
  memset(&riNormal, 0, sizeof(RegionImage));
  memset(&riHover, 0, sizeof(RegionImage));
  memset(&riClick, 0, sizeof(RegionImage));

  group = parseConfig(szLine);

  if (isVisible)
    createShortcut();
}


Shortcut::~Shortcut()
{
  if (next)
    delete next;
  clear();
  destroyWindow();
}


void Shortcut::append(Shortcut* shortcut)
{
  next = shortcut;
}


void Shortcut::setVisible(int visible)
{
  bool wasVisible = isVisible;

  if (!visible)
    isVisible = !isVisible;
  else
    isVisible = visible > 0;

  if (!hWnd && isVisible)
    createShortcut();

  if (isVisible != wasVisible)
    ShowWindow(hWnd, (isVisible ? SW_SHOW : SW_HIDE));

  if (next)
    next->setVisible(visible);
}


void Shortcut::setTopMost(int topMost)
{
  bool wasTopMost = isTopMost;

  if (!topMost)
    isTopMost = !isTopMost;
  else
    isTopMost = (topMost > 0 ? true : false);

  if (isVisible && (isTopMost != wasTopMost))
  {
    destroyWindow();

    createWindow((isTopMost ? WS_EX_TOPMOST | WS_EX_TOOLWINDOW : WS_EX_TOOLWINDOW),
                 "Shortcut", (isTopMost ? WS_POPUP : WS_CHILD | WS_CLIPSIBLINGS),
                 relLeft, relTop, width, height, desktopWnd);

    if (isVisible)
      ShowWindow(hWnd, SW_SHOW);
  }

  if (next)
    next->setTopMost(topMost);
}


DWORD Shortcut::parseConfig(LPCSTR szConfigLine)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR nextToken = szConfigLine;
  DWORD result = 0;
  bool hasCommand = true;

  clear();

  GetToken(nextToken, NULL, &nextToken, false);
  if (GetToken(nextToken, token, &nextToken, false))
  {
    caption = new char[StrLen(token) + 1];
    StrCopy(caption, token);
  }

  if (GetToken(nextToken, token, &nextToken, false))
    left = atoi(token);
  if (GetToken(nextToken, token, &nextToken, false))
    top = atoi(token);

  if (GetToken(nextToken, token, &nextToken, false))
  {
    normalName = new char[strlen(token) + 1];
    StrCopy(normalName, token);
  }
  if (GetToken(nextToken, token, &nextToken, false))
  {
    hoverName = new char[strlen(token) + 1];
    StrCopy(hoverName, token);
  }
  if (GetToken(nextToken, token, &nextToken, false))
  {
    clickName = new char[strlen(token) + 1];
    StrCopy(clickName, token);
  }

  if (GetToken(nextToken, token, &nextToken, false))
  {
    if (token[0] == '#')
    {
      strlwr(token);
      result = atoi(&token[1]);
      isVisible = !strchr(token, 'h');
      isTopMost = strchr(token, 't');
      hasCommand = GetToken(nextToken, token, &nextToken, false);
    }
    if (hasCommand)
    {
      command = new char[StrLen(token) + 1];
      StrCopy(command, token);
    }
    if (nextToken)
    {
      commandArgs = new char[StrLen(nextToken) + 1];
      StrCopy(commandArgs, nextToken);
    }
  }

  return result;
}


void Shortcut::createShortcut()
{
  if (normalName)
    riNormal.image = LoadLSImage(normalName, NULL);
  if (hoverName)
    riHover.image = LoadLSImage(hoverName, NULL);
  if (clickName)
    riClick.image = LoadLSImage(clickName, NULL);

  if (riNormal.image)
    riNormal.region = BitmapToRegion(riNormal.image, RGB(255, 0, 255), 0x101010, 0, 0);
  if (riHover.image)
    riHover.region = BitmapToRegion(riHover.image, RGB(255, 0, 255), 0x101010, 0, 0);
  if (riClick.image)
    riClick.region = BitmapToRegion(riClick.image, RGB(255, 0, 255), 0x101010, 0, 0);

  relLeft = (left < 0 ? GetSystemMetrics(SM_CXSCREEN) + left : left);
  relTop = (top < 0 ? GetSystemMetrics(SM_CYSCREEN) + top : top);

  createWindow((isTopMost ? WS_EX_TOPMOST | WS_EX_TOOLWINDOW : WS_EX_TOOLWINDOW),
               "Shortcut", (isTopMost ? WS_POPUP : WS_CHILD | WS_CLIPSIBLINGS),
               relLeft, relTop, width, height, desktopWnd);

  ShowWindow(hWnd, SW_SHOW);
}


void Shortcut::clear()
{
  if (caption)
    delete[] caption;
  if (command)
    delete[] command;
  if (commandArgs)
    delete[] commandArgs;
  if (normalName)
    delete[] normalName;
  if (hoverName)
    delete[] hoverName;
  if (clickName)
    delete[] clickName;

  if (riNormal.image)
    DeleteObject(riNormal.image);
  if (riNormal.region)
    DeleteObject(riNormal.region);
  if (riHover.image)
    DeleteObject(riHover.image);
  if (riHover.region)
    DeleteObject(riHover.region);
  if (riClick.image)
    DeleteObject(riClick.image);
  if (riClick.region)
    DeleteObject(riClick.region);

  caption = NULL;
  command = NULL;
  commandArgs = NULL;
  normalName = NULL;
  hoverName = NULL;
  clickName = NULL;
  memset(&riNormal, 0, sizeof(RegionImage));
  memset(&riHover, 0, sizeof(RegionImage));
  memset(&riClick, 0, sizeof(RegionImage));
}


void Shortcut::setImage(RegionImage& regionImage)
{
  if (!regionImage.image || (&regionImage == riCurrent))
    return;

  HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
  RECT clientRect;

  riCurrent = &regionImage;
  GetLSBitmapSize(riCurrent->image, &width, &height);
  SetWindowPos(hWnd, HWND_TOP, 0, 0, width, height, SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
  CombineRgn(windowRgn, riCurrent->region, NULL, RGN_COPY);
  SetWindowRgn(hWnd, windowRgn, true);
  GetClientRect(hWnd, &clientRect);
  InvalidateRect(hWnd, &clientRect, true);
}


//---------------------------------------------------------
// Message handling
//---------------------------------------------------------

void Shortcut::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onMouseMove, WM_MOUSEMOVE)
    MESSAGE(onMouseActivate, WM_MOUSEACTIVATE)
    MESSAGE(onTimer, WM_TIMER)
    MESSAGE(onLButtonDown, WM_LBUTTONDOWN)
    MESSAGE(onLButtonUp, WM_LBUTTONUP)
    MESSAGE(onPaint, WM_PAINT)
    MESSAGE(onDisplayChange, WM_DISPLAYCHANGE)
    MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
    REJECT_MESSAGE(WM_ERASEBKGND)
  END_MESSAGEPROC
}


void Shortcut::onCreate(Message& message)
{
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
  setImage(riNormal);
  if (caption)
    shortcutFactory->addHint(hWnd, caption);
}


void Shortcut::onDestroy(Message& message)
{
  if (leaveTimer)
    KillTimer(hWnd, leaveTimer);
  shortcutFactory->removeHint(hWnd);
}


void Shortcut::onMouseMove(Message& message)
{
  if (!leaveTimer)
    leaveTimer = SetTimer(hWnd, leaveTimerId, 20, NULL);

  if (state != ssNormal)
    return;

  state = ssHover;
  setImage(riHover);

  shortcutFactory->relayHintMessage(hWnd, message);
}


void Shortcut::onMouseActivate(Message& message)
{
  PostMessage(hWnd, WM_LBUTTONDOWN, 0, 0);
  message.lResult = MA_ACTIVATE;
}


void Shortcut::onTimer(Message& message)
{
  if (message.wParam != leaveTimerId)
    return;

  HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
  POINT cursorPos;

  GetCursorPos(&cursorPos);
  GetWindowRgn(hWnd, windowRgn);

  if (!PtInRegion(windowRgn, cursorPos.x - relLeft, cursorPos.y - relTop))
  {
    if (state != ssNormal)
    {
      state = ssNormal;
      setImage(riNormal);
    }
    KillTimer(hWnd, leaveTimer);
    leaveTimer = 0;
  }
  DeleteObject(windowRgn);
}


void Shortcut::onLButtonDown(Message& message)
{
  if (state == ssClick)
    return;

  state = ssClick;

  setImage(riClick);
}


void Shortcut::onLButtonUp(Message& message)
{
  char buffer[MAX_LINE_LENGTH];

  if (state != ssClick)
    return;

  state = ssNormal;
  setImage(riNormal);

  if (command)
  {
    if (commandArgs)
      sprintf(buffer, "[%s] %s", command, commandArgs);
    else
      sprintf(buffer, "[%s]", command);
    LSExecute(hWnd, buffer, SW_SHOWDEFAULT);
  }
}


void Shortcut::onPaint(Message& message)
{
  HDC hDC;
  HDC sourceDC;
  PAINTSTRUCT paintStruct;
  HBITMAP oldImage;

  if (!riCurrent)
    return;
  hDC = BeginPaint(hWnd, &paintStruct);
  sourceDC = CreateCompatibleDC(hDC);
  oldImage = HBITMAP(SelectObject(sourceDC, riCurrent->image));
  BitBlt(hDC, 0, 0, width, height, sourceDC, 0, 0, SRCCOPY);
  SelectObject(sourceDC, oldImage);
  DeleteDC(sourceDC);
  EndPaint(hWnd, &paintStruct);
}


void Shortcut::onDisplayChange(Message& message)
{
  relLeft = (left < 0 ? message.lParamLo + left : left);
  relTop = (top < 0 ? message.lParamHi + top : top);
  SetWindowPos(hWnd, HWND_TOP, relLeft, relTop, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}


void Shortcut::onWindowPosChanging(Message& message)
{
  WINDOWPOS& windowPos = *(WINDOWPOS*)(message.lParam);

  if (!changeZOrder)
    windowPos.flags |= SWP_NOZORDER;
  changeZOrder = false;
}


