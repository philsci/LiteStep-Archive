//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by install3.rc
//
#define IDD_LICENSE                     106
#define IDD_ALLDONE                     107
#define IDD_INSTALL_SETTINGS            108
#define IDD_SYSTEM_SETTINGS_9X          109
#define IDD_SYSTEM_SETTINGS_NT          110
#define IDC_EDIT_AGREE                  1000
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                     1005
#define IDC_BUTTON4                     1006
#define IDC_REBOOT                      1007
#define IDC_NOREBOOT                    1008
#define IDC_FINISH                      1009
#define IDC_EDIT1                       1010
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_COMBO1                      1013
#define IDC_BUTTON5                     1014
#define IDC_CONFIGFILENAME              1015
#define IDC_CONFIGSECTION               1016
#define IDC_CONFIGKEYNAME               1017
#define IDC_CONFIGCURRENT               1018
#define IDC_EDIT5                       1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
