#ifndef  __GRDSYSTRAY
#define  __GRDSYSTRAY

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#pragma warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include <stdlib.h>
#include <map>
#include "resource.h"
#include "shellTray.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * STRUCTURE: GRDSYSTRAYICON                               * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the structure that is stored for every icon    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

typedef struct SYSTRAYICON {

	// owner window
	HWND hWnd;
	// id
	UINT uID;
	// callback message ( to send to the owner window )
	UINT uCallbackMessage;
	// icon
	HICON hIcon;
	// icon region
	HRGN hRgn;
	// trayicon rectangle
	RECT rc;

	// tooltip text
	char *szTip;
	// tooltip id
	UINT uToolTip;

	struct SYSTRAYICON *pNext, *pPrev;

} SYSTRAYICON, *PSYSTRAYICON;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdTray                                          * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the main class, which does all the real work   * */
/* *  it initializes a couple of "sub-classes" that are      * */
/* *  that just to make it easier to understand and manage   * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class systray : public Window
{
private:
	// booleans
	BOOL onTop;
	BOOL hideIfEmpty;
	BOOL visible;
	BOOL inWharf;

	// tray
	int trayX;
	int trayY;
	int trayWidth;
	int trayHeight;

	// autosize
	BOOL autoSize;

	// borders
	int borderTop; 
	int borderLeft;
	int borderRight;
	int borderBottom;
	BOOL borderDrag;

	int snapDistance;

	// tray wrapping
	int direction;
	int wrapCount;
	int wrapDirection;

	// icon
	int iconSize;
	int iconSpacingX;
	int iconSpacingY;
	int deltaX;
	int deltaY;

	int firstX;
	int lastX;
	int firstY;
	int lastY;

	// icon effects
	COLORREF clrHue;
	UCHAR hueIntensity;
	UCHAR saturnation;
	UCHAR effectFlags;

	BOOL transpBack;
	HBITMAP hbmSkin;
	HBITMAP hbmBack;
	HRGN hrgnBack;
	BOOL skinTiled;
	BOOL transpSkin;

	COLORREF clrBack;
	COLORREF clrBorder;

	HWND liteStep;
	HWND desktop;
	HWND tooltip;

	UINT uLastID;

	PSYSTRAYICON pFirst;
	PSYSTRAYICON pLast;

	shellTray *shelltray;

public:
  systray(HWND parentWnd, int& code);
  ~systray();

	// bang handlers
	void hide();
	void show();
	void toggle();
	void toggleOnTop();
	void move(int x, int y);
	void size(int cx, int cy);

private:
	void paintBackground( HDC hdcDst, HRGN hrgnDst );
	void createBackground();
	void setFirstLast();
	void adjustSize();

	int copyBlt(HDC hdcDst, int xDst, int yDt, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc);
	int sizeBlt(HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc);

	/* *** * LIST MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconListFind(HWND hWnd, UINT uID);
	PSYSTRAYICON iconListFindPt(POINT pt);
	int iconListSave(void *dst);
	int iconListLoad(void *src);
	int iconListLoadMaduin();
	void iconListCleanup();
	BOOL iconListDelAll();
	void iconListPaint(HDC hdcDest, HRGN hrgnDest);

	/* *** * ICON MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconAdd(PNOTIFYICONDATA pnid);
	BOOL       iconDel(PNOTIFYICONDATA pnid);
	BOOL       iconDelGRD(PSYSTRAYICON pSysTrayIcon);
	PSYSTRAYICON iconMod(PNOTIFYICONDATA pnid);

	void       setIcon(PSYSTRAYICON pSysTrayIcon, HICON hIcon);
	void       setToolTip(PSYSTRAYICON pSysTrayIcon, char *tooltip);
	void       adjustRect(PSYSTRAYICON pSysTrayIcon);

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onDisplayChange(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onKeyMessage(Message& message);
  void onMouse(Message& message);
	BOOL onMouseIcon(Message& message);
  void onPaint(Message& message);
  void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onRestoreTray(Message& message);
	void onSaveTray(Message& message);
	void onSysTray(Message& message);
	void onWindowPosChanging(Message& message);
};

void bangHide( HWND sender, char *args );
void bangShow( HWND sender, char *args );
void bangToggle( HWND sender, char *args );
void bangOnTop( HWND sender, char *args );
void bangMove( HWND sender, char *args );
void bangSize( HWND sender, char *args );

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif// __GRDSYSTRAY