#pragma warning(disable: 4786)

#include "CallbackBangCommand.h"

class ThreadedBangCommand : public IBangCommand  
{

public:
	ThreadedBangCommand(DWORD thread, BANG b);
	ThreadedBangCommand(DWORD thread, BANGEX b, wstring command);
	virtual ~ThreadedBangCommand();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
  ULONG STDMETHODCALLTYPE Release( void);
	
	///////////////////////////////////////////////////////////////////////////
	// From IBangCommand
    HRESULT STDMETHODCALLTYPE Execute( 
        /* [in] */ OLE_HANDLE caller,
        /* [in] */ SAFEARRAY __RPC_FAR * params,
        /* [retval][out] */ VARIANT __RPC_FAR *result);
private:
	DWORD thread_id;
	IBangCommand *callback_bang;

	long refCount;
};
