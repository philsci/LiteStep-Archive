/*
  Copyright (C) 1998-1999 Johan Redestig
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#if !defined(AFX_HEADERITEM_H__D5612517_732D_11D2_B69F_00C0DF466974__INCLUDED_)
#define AFX_HEADERITEM_H__D5612517_732D_11D2_B69F_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TitleItem.h"

class PopupMenu;

/**
A popup menu header item this paints the menu title, and
contains the feature to pin the menu to the desktop
*/
class HeaderItem  : public TitleItem
{
public:
	/**
	constructs a headeritem object

	@param pszTitle pointer to a zero concatenated string that 
	       points a the title
	*/
	HeaderItem(char* pszTitle);

	/// destroys the header item object
	virtual ~HeaderItem();

	/**
	used to detect when the user moves the menu item
	
	@param x the x location
	@param y the y location
	*/
	LRESULT NcHitTest(int x, int y);

	/**
	tells the header item that the menu is moving
	*/
	void Moving();

	/**
	asks the menu item object if it is ok to hide the menu

	@return it it is ok to hide the menu
	*/
	BOOL Hide();

	/**
	paints a header on the DC

	@param hDC handle to the device to be painted
	*/
	void Paint(HDC hDC);

	/**
	tries to activate the header, this is not possible so it returns false
	
	@param bActive the new state of the activation
	@return FALSE
	*/
	BOOL Active(BOOL bActive) {return FALSE;};

	/**
	mose move messages

	@param nMsg the type of message
	@param x the x location of the mouse
	@param y the y location of the mouse
	*/
	void Mouse(int nMsg, int x, int y);

	/**
	key press messages

	@param nKey the key that was pressed
	@return returns true if the message was handled
	*/
	BOOL Key(int nKey);

	/**
	sets the position of the menu item in the menu

	@param nLeft the left location in the menu
	@param nTop the top location in the menu
	*/
	void SetPosition(int nLeft, int nTop);

	/**
	Sets if the |> shall be painted on folder items

	@param bDraw true to paint, false to not paint 
	*/
	static void SetDrawCloseButton(BOOL bDraw){m_bCloseButton = bDraw;};

	/**
	Should the menu always be ontop (even when pinned?)

	@param bAlways true to always be ontop false otherwise
	*/
	static void SetAlwaysOnTop(BOOL bAlways){m_bAlwaysOnTop=bAlways;};

	/**
	sets the rect that contains the title

	@param r pointer to a RECT to receive the rect
	*/
	void GetTitleRect(RECT* r);

	UINT GetDrawTextFormat() { return GetTitleAlignment() | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOCLIP; }

private:	
	static BOOL m_bCloseButton;
	static BOOL m_bAlwaysOnTop;

	RECT m_CloseButton;
	//BOOL m_bPinned;
};

#endif // !defined(AFX_HEADERITEM_H__D5612517_732D_11D2_B69F_00C0DF466974__INCLUDED_)
