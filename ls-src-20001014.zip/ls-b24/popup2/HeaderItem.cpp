/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "HeaderItem.h"
#include "TitleItem.h"
#include "PopupMenu.h"
#include "Painter.h"

BOOL HeaderItem::m_bCloseButton = TRUE;
BOOL HeaderItem::m_bAlwaysOnTop = TRUE;

HeaderItem::HeaderItem(char* pszTitle) : TitleItem(pszTitle)
{
	//m_bPinned = FALSE;
	m_nSortPriority = 20;
}

HeaderItem::~HeaderItem()
{
}

LRESULT HeaderItem::NcHitTest(int x, int y)
{
	if(IsOver(x, y))
	{
		// since i will tell window that i am a caption, window will not
		// send me any WM_MOUSEMOVE messages .. sigh .. so i send it my
		// self, this is important for tracking active menu item.
	//	PostMessage(m_pParent->GetWindow(), WM_MOUSEMOVE, MAKEWORD(x,y), 0);

		POINT p;
		p.x = x;
		p.y = y;
		if(PtInRect(&m_CloseButton, p))
		{
			return HTCLOSE;
		}
		else
		{
			// tell window that i am a caption so the user can drag the popup
			// around ... what fun!
			return HTCAPTION;
		}
	}
	return 0;
}

void HeaderItem::Mouse(int nMsg, int x, int y)
{
	POINT p;
	
	if(nMsg != WM_NCLBUTTONUP)
		return;

	p.x = x;
	p.y = y;

	ScreenToClient(m_pParent->GetWindow(), &p);

	if(!IsOver(p.x, p.y))
		return;

	if(PtInRect(&m_CloseButton, p) || !m_bCloseButton)
	{
		SetWindowPos(m_pParent->GetWindow(), 
			m_bAlwaysOnTop?HWND_TOPMOST:HWND_NOTOPMOST, 
			0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);

		if(m_pParent->IsPinned())
//		if(m_bPinned == TRUE)
		{
			m_pParent->SetPinned(false);
//			m_bPinned = FALSE;
			m_pParent->Hide(HIDE_THIS);
		}
		else
		{
			RECT r;
//			m_bPinned = TRUE;
			m_pParent->SetPinned(true);
			if(m_pParent->GetParent())
				m_pParent->GetParent()->Hide(HIDE_PARENTS);

			GetItemRect(&r);
			RedrawWindow(m_pParent->GetWindow(), &r, NULL, RDW_INVALIDATE);
		}
	}
}

void HeaderItem::Moving()
{	
	if(m_pParent->GetParent() && 
		IsWindowVisible(m_pParent->GetWindow()) && 
		!m_pParent->IsPinned())
	{
		RECT r;
		//m_bPinned = TRUE;
		m_pParent->SetPinned(true);
		m_pParent->Hide(HIDE_PARENTS);

		SetWindowPos(m_pParent->GetWindow(), 
			m_bAlwaysOnTop?HWND_TOPMOST:HWND_NOTOPMOST, 
			0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);

		GetItemRect(&r);
		RedrawWindow(m_pParent->GetWindow(), &r, NULL, RDW_INVALIDATE);
	}
}

BOOL HeaderItem::Hide()
{
	return !m_pParent->IsPinned();
}

void HeaderItem::Paint(HDC hDC)
{
	TitleItem::Paint(hDC);

	if(m_pParent->IsPinned() && m_bCloseButton)
	{
		HPEN hPen;
		HPEN hOldPen;
		int left = GetWidth()-GetHeight();
		int insert = (int)((((double)GetHeight())/3.5)+.5);
		
		// ' |'
		hPen = CreatePen(PS_SOLID, 1, m_nLightColor);
		hOldPen = (HPEN) SelectObject(hDC, hPen);
		MoveToEx(hDC, left, m_nTop, NULL);
		LineTo(hDC, left, GetHeight());
		DeleteObject(hPen);

		// '| '
		hPen = CreatePen(PS_SOLID, 1, m_nDarkColor);
		SelectObject(hDC, hPen);
		MoveToEx(hDC, left-1, m_nTop, NULL);
		LineTo(hDC, left-1, GetHeight());
		DeleteObject(hPen);

		// '/'
 		hPen = CreatePen(PS_SOLID, 2, m_pBackground->GetFontColor());
		SelectObject(hDC, hPen);
		MoveToEx(hDC, left+insert, m_nTop+insert, NULL);
		LineTo(hDC, GetWidth()-insert, GetHeight()-insert);

		// '\'		
		MoveToEx(hDC, left+insert, GetHeight()-insert, NULL);
		LineTo(hDC, GetWidth()-insert, m_nTop+insert);		
		SelectObject(hDC, hOldPen);
		DeleteObject(hPen);
	}
}

void HeaderItem::GetTitleRect(RECT* r)
{
	r->top = m_nTop;
	r->left = m_hIcon == NULL ? 3 +GetIndent(): GetHeight() + 3 + GetIndent();
	r->bottom = GetHeight() + m_nTop - 1;
	r->right = GetWidth() - (m_pParent->IsPinned() ? GetHeight() : 0);
}


BOOL HeaderItem::Key(int nKey)
{
	MenuItem::Key(nKey);
	if(nKey == VK_ESCAPE)
		m_pParent->SetPinned(false);
	return FALSE;
}

void HeaderItem::SetPosition(int nLeft, int nTop)
{
	TitleItem::SetPosition(nLeft, nTop);
	SetRect(&m_CloseButton, GetWidth()-GetHeight(), 0, GetWidth(), GetHeight());
}
