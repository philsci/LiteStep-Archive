// DO NOT DELETE NEXT LINE
// LMA1.0 
/*
LiteStep Module AppWizard
*/

#ifndef __command_H
#define __command_H

#ifdef _DEBUG
#define _LSDEBUG
#endif

#include <windows.h>
#include <Shlwapi.h>

#pragma	warning(disable: 4786) // STL naming warnings
#include <vector>
#include <string>

#include "C:\cvs\ls-b24\lsapi\lsapi.h"
#include "C:\cvs\ls-b24\lsapi\safestr.h"
#include "C:\cvs\ls-b24\lsapi\lswinbase.h"
#include "C:\cvs\ls-b24\lsapi\lsdebug.h"

using namespace std;

typedef vector<string> vecMRUList;

#define ID_EDITCHILD 3578
#define MAX_POPRUN_HISTORY 5
#define MAX_POPRUN_STRING 1024

class Command : public Window
{
public:
  int height;
  int width;
  int xpos;
  int ypos;
  int borderSize;
  int borderSizeTop;
  int borderSizeLeft;
  int borderSizeBottom;
  int borderSizeRight;


  HFONT hFont;
  HBRUSH hBrush;
  HBRUSH hBorderBrush;

  LPSTR szFontFace;
  int textSize;
  COLORREF colorText;
  COLORREF colorBG;
  COLORREF colorBorder;

  HWND hEdit;

	char* PreviousHistory();
	char* NextHistory();
	static BOOL bRememberLast;
  int mruListCount;
  vecMRUList mruList;

  char* pszCommand;
	char* pszArgument;
public:
  Command(HWND parentWnd, int& code);
  ~Command();

  void BangCommandMove(HWND, LPCSTR);
  void BangCommandToggle(HWND, LPCSTR);

private:

	void InitializeHistory();
	void AddToHistory(char* pszCommand);

  virtual void windowProc(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);
  void onCreate(Message& message);
  void onCtlColorEdit(Message& message);
  void onDropFiles(Message& message);
  void onNCHitTest(Message& message);
  void onPaint(Message& message);
  void onEraseBkgnd(Message &message);
  void onCommand(Message &message);
  /*
  TODO:
    Add any Message Handlers

  */

};

void BangCommandMoveFunction(HWND, LPCSTR);
void BangCommandToggleFunction(HWND, LPCSTR);

/*
TODO:
  Add any Bang Command Declarations

*/

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
