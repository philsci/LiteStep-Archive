// Console.h: interface for the Console class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONSOLE_H__ED77640F_F529_4CF8_AFB3_63C8D6943776__INCLUDED_)
#define AFX_CONSOLE_H__ED77640F_F529_4CF8_AFB3_63C8D6943776__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../core/ifcs.h"
#include "../lsapi/lswinbase.h"

class ConsoleLogHandler : public ILogHandler {
public:
	ConsoleLogHandler(HWND listbox);
	virtual ~ConsoleLogHandler();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
  virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
      /* [in] */ REFIID riid,
      /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	virtual ULONG STDMETHODCALLTYPE AddRef( void);
    
  virtual ULONG STDMETHODCALLTYPE Release( void);
	
	/////////////////////////////////////////////////////////////////////////
	// from ILogHandler
  virtual HRESULT STDMETHODCALLTYPE Log( 
      /* [in] */ BSTR message,
      /* [in] */ int timestamp);

private:
	HWND listbox;
	long refCount;
};

class Console : public Window
{
public:
	Console(HWND parentWnd, int &code);
	virtual ~Console();

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onRefresh(Message& message);
  void onSysCommand(Message& message);
  void onDestroy(Message& message);
  void onHotkey(Message& message);
  void onTimer(Message& message);

private:
	BOOL consoleOnTop;
	BOOL logInfo;
	BOOL logVerbose;
	BOOL logWarning;
	BOOL logNonerr;
	BOOL logFaterr;
	int consoleX;
	int consoleY;
	int consoleWidth;
	int consoleHeight;
	void ReadSettings();
	ILogDispatch* log;
	HWND listbox;

	ConsoleLogHandler *info, *verbose, *warning, *nonerr, *faterr;
};

#endif // !defined(AFX_CONSOLE_H__ED77640F_F529_4CF8_AFB3_63C8D6943776__INCLUDED_)
