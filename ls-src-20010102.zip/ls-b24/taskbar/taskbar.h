/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __TASKBAR_H
#define __TASKBAR_H

#include <string>
#include <vector>
using namespace std;

class Taskbar;
class TaskbarButton;
class TaskbarSkin;
class Texture;

typedef vector<TaskbarButton *>::iterator TaskbarButtonIterator;

class Taskbar
{
private:  // variables

	HWND hWnd;
	HINSTANCE hInstance;
	HWND hToolTips;

	boolean alwaysOnTop;
	boolean visible;

	boolean keepDesktopArea;

	int edge;
	int height;
	int width;

	int neededHeight;

	int screenHeight;
	int screenWidth;

	RECT adjustedDeskArea;
	RECT prevDeskArea;

	BOOL active;
	BOOL autoHidden;
	BOOL mouseOver;
	TaskbarButton *capture;

	BOOL startButton;
	BOOL startMousePressed;
	BOOL startMouseOver;
	
	BOOL isTaskFlash;

	HWND hTray;
	int trayWidth;

	TaskbarSkin *skin;
	TaskbarSkin *buttonSkin;
	TaskbarSkin *activeButtonSkin;
	TaskbarSkin *traySkin;
	TaskbarSkin *flashSkin;
	//TaskbarSkin *activeFlashSkin;

	HFONT activeFont;
	HFONT font;

	vector<TaskbarButton *> buttons;

	boolean listChanged;

public:

	Taskbar();
	virtual ~Taskbar();

	void OnLoad( HINSTANCE );
	void OnUnload();

	void Invalidate( int, int, int, int );

	TaskbarButton *GetCapture();
	void SetCapture( TaskbarButton * );
	void ReleaseCapture();

	friend class TaskbarButton;

	//TRUE if the user specifies tasks flashing
	BOOL IsTaskFlash() const { return isTaskFlash;}

	boolean isAlwaysOnTop() const { return alwaysOnTop; }
	boolean isVisible() const { return visible; }

	void setAlwaysOnTop(boolean alwaysOnTop);

	void hide();
	void show();

private:  // functions

	TaskbarButton *SearchForButtonByHandle( HWND );

	TaskbarButton *ButtonAtPoint( int, int );
	void ReadConfig();
	void Layout();
	void SetWindowPosition();

	void Dock( HWND );
	void ApplyTraySkin( HDC, RECT & );

private:  // configuration variables

	BOOL autoHide;
	int autoHideDelay;

	BOOL stripTaskbar;

	BOOL msTaskbar;
	COLORREF foreColor1;
	COLORREF foreColor2;
	COLORREF backColor;
	COLORREF textColor;
	COLORREF flashColor;

	BOOL noSkinShift;
	BOOL noTextShift;

private:  // message handlers

	void OnActivate( BOOL );
	void OnDisplayChange();
	void OnGetMinRect( HWND, RECT * );
	void OnLButtonDown( int, int );
	void OnLButtonUp( int, int );
	void OnMouseMove( int, int );
	void OnPaint( HDC );
	void OnRedraw( HWND, BOOL );
	void OnRButtonDown( int, int );
	void OnRButtonUp( int, int );
	void OnSettingChange();
	void OnSize( int, int );
	void OnTimerAutoHide();
	void OnTimerUpdate();
	void OnWindowActivated( HWND, BOOL );
	void OnWindowCreated( HWND );
	void OnWindowDestroyed( HWND );
	BOOL OnWindowMessage( UINT, WPARAM, LPARAM, LRESULT & );

private:  // statics
	char startButtonImage[256];
	TaskbarSkin* startButtonSkin;
	TaskbarButton* pStartButton;
	char startButtonText[256];
	int startButtonSize;

	static BOOL WINAPI EnumWindowsProc( HWND, LPARAM );
	static LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );
};

class TaskbarButton
{
private:

	boolean active;
	// boolean flashing;
	HICON icon;
	// string label;
	// HWND taskHandle;
	// string toolTip;

	char* otherCaption;
	TaskbarSkin* skin;
	TaskbarSkin* activeskin;
	TaskbarSkin* flashskin;

	HWND hTask;

	LPTSTR caption;

	BOOL mousePressed;
	BOOL mouseOver;
	BOOL taskflash; //current state

	int x;
	int y;
	int height;
	int width;

	Taskbar &container;

public:
	void SetCaption(LPCTSTR cap);
	TaskbarSkin* GetSkin();
	TaskbarSkin* GetActiveSkin();
	TaskbarSkin* GetFlashSkin();
	void SetSkin(TaskbarSkin *s);
	void SetActiveSkin(TaskbarSkin *s);
	void SetFlashSkin(TaskbarSkin *s);

	TaskbarButton( Taskbar &, HWND );
	virtual ~TaskbarButton();

	BOOL HasPoint( int, int );
	void Move( int, int, int, int );

	void OnLButtonDown( int, int );
	void OnLButtonUp( int, int );
	void OnMouseMove( int, int );
	void OnPaint( HDC );
	void OnRButtonDown( int, int );
	void OnRButtonUp( int, int );

	// redraw == TRUE to force ths button to update
	//			 FALSE to let the button decide whether to update or not
	void OnUpdate(BOOL needRedraw = FALSE);

	// boolean isActive() const { return active; }
	// boolean isFlashing() const { return flashing; }
	// HICON getIcon() const { return icon; }
	// const string &getLabel() const { return label; }
	// HWND getTaskHandle() const { return taskHandle; }
	// const string &getToolTip() const { return toolTip; }

	// void setActive(boolean active);
	// void setFlashing(boolean flashing);
	// void setIcon(HICON icon);
	// void setLabel(const string &label);
	// void setTaskHandle(HWND taskHandle);
	// void setToolTip(const string &toolTip);

	// void updateTaskInfo();

	inline HWND GetTask() const { return hTask; }
	inline BOOL IsActive() const { return active ? TRUE : FALSE; }

	void SetFlashing(BOOL flash) {	taskflash = flash;	}

	BOOL GetFlashing() const { return taskflash;}

private:

	LPTSTR GetWindowCaption();
	HICON GetIcon();

	// boolean isTaskActive() const;
	// HICON getTaskIcon() const;
	// string getTaskLabel() const;
};

class TaskbarSkin
{
public:
	COLORREF GetBackColor();
	void SetBackColor(COLORREF color);
	BOOL stretch;
	BOOL GetStretch();
	void SetStretch(BOOL s);

	TaskbarSkin();
	TaskbarSkin( LPCTSTR, LPCTSTR, LPCTSTR );
	virtual ~TaskbarSkin();

	void Apply( HDC, int, int, int, int );

protected:

	HBITMAP hbmLeft;
	int leftH;
	int leftW;

	HBITMAP hbmMiddle;
	int middleH;
	int middleW;

	HBITMAP hbmRight;
	int rightH;
	int rightW;
private:
	COLORREF backColor;
};

HFONT GetRCFont(const char *name, const LOGFONT *lfDefault);

HICON GetIconFromWindow( HWND, BOOL );
BOOL IsAppWindow( HWND );
BOOL WINAPIV PrintLog( LPCTSTR, ... );

extern void (WINAPI *SwitchToThisWindow)( HWND, int );

#endif // __TASKBAR_H
