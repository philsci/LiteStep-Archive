/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <comdef.h>

#include "StandardBangManager.h"
#include "../lsapi/lsapi.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StandardBangManager::StandardBangManager()
{
	refCount = 0;
}

StandardBangManager::~StandardBangManager()
{
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StandardBangManager::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IBangManager) {
		*ppv = static_cast<IBangManager*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StandardBangManager::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StandardBangManager::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

///////////////////////////////////////////////////////////////////////////
// From IBangManager

// Add a bang command to the manager
HRESULT STDMETHODCALLTYPE StandardBangManager::AddBangCommand( 
    /* [in] */ BSTR name,
    /* [in] */ IBangCommand __RPC_FAR *command) {
	
	const wchar_t *name_str = _bstr_t(name, false);

	map<wstring, IBangCommand*>::iterator iter = bang_map.find(name_str);
	
	if (iter != bang_map.end()) {
		return E_FAIL;
	}

	bang_map[name_str] = command;
	
	return S_OK;
}

// Remove a bang command from the manager
HRESULT STDMETHODCALLTYPE StandardBangManager::RemoveBangCommand( 
	/* [in] */ BSTR name) {

	const wchar_t *name_str = _bstr_t(name, false);

	BangMap::iterator iter = bang_map.find(name_str);

	if (iter == bang_map.end()) {
		return E_FAIL;
	}

	iter->second->Release();
	bang_map.erase(name_str);

	return S_OK;
}

// Retrieve a bang command from the manager
HRESULT STDMETHODCALLTYPE StandardBangManager::GetBangCommand( 
    /* [in] */ BSTR name,
    /* [retval][out] */ IBangCommand __RPC_FAR *__RPC_FAR *ret_command) {

	wchar_t *name_str = _bstr_t(name, false);

	BangMap::iterator iter = bang_map.find(name_str);

	if (iter == bang_map.end()) {
		return E_FAIL;
	}

	iter->second->AddRef();
	*ret_command = iter->second;

	return S_OK;
}

// Execute a bang command with the specified name, passing params, getting result
HRESULT STDMETHODCALLTYPE StandardBangManager::ExecuteBangCommand( 
    /* [in] */ BSTR name,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ SAFEARRAY __RPC_FAR * params,
    /* [retval][out] */ VARIANT __RPC_FAR *result) {

	wchar_t *name_str = _bstr_t(name, false);

	BangMap::iterator iter = bang_map.find(name_str);

	if (iter == bang_map.end()) {
		return E_FAIL;
	}

	iter->second->Execute(caller, params, result);

	return S_OK;
}

// TODO: Execute multiple bang commands with multiple param lists
HRESULT STDMETHODCALLTYPE StandardBangManager::ExecuteBangCommands( 
    /* [in] */ SAFEARRAY __RPC_FAR * names,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ SAFEARRAY __RPC_FAR * params,
    /* [out] */ SAFEARRAY __RPC_FAR * __MIDL_0018,
    /* [retval][out] */ int __RPC_FAR *number) {

	return NULL;
}

HRESULT STDMETHODCALLTYPE StandardBangManager::ClearBangCommands( void) {

	BangMap::iterator iter = bang_map.begin();

	while (iter != bang_map.end()) {
		iter->second->Release();
		iter++;
	}

	bang_map.clear();

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardBangManager::GetBangCommandNames( 
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval)
{
	if( retval )
		*retval = NULL;
	else
		return E_POINTER;

	BangMap::iterator iter = bang_map.begin();

	int count = bang_map.size();
	int i = 0;

	SAFEARRAY *array = SafeArrayCreateVector( VT_BSTR, 0, count );

	if( !array )
		return E_OUTOFMEMORY;

	BSTR *arrayData;
	SafeArrayAccessData( array, (void **) &arrayData );

	while( i < count && iter != bang_map.end() )
	{
		arrayData[i++] = SysAllocString( iter->first.c_str() );
		iter++;
	}
	
	SafeArrayUnaccessData( array );

	*retval = array;
	return S_OK;
}
