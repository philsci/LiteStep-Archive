/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// StepSettings.h: interface for the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#if !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
#define AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <string>
#include <map>

#include "../core/ifcs.h"

using namespace std;

#define MAX_BANGCOMMAND            64
#define MAX_BANGARGS               256
#define MAX_RCCOMMAND              64
#define MAX_LINE_LENGTH            4096
#define MAX_PATH_LENGTH			   1024
#define MAX_LINE_LENGTH 4096
#define WHITESPACE " \t\n\r"

typedef vector<string> StringVector;

typedef map< string, StringVector > CacheMap;
typedef map< string, CacheMap > CacheMapMap;

typedef pair< string, StringVector > StringAndStringVector;
typedef map< string, StringAndStringVector > StringAndStringVectorMap;
struct CacheState {
	// filename we are using, for command iteration
	string filename;

	// whether we have a valid line iterator
	bool line_iter_valid;

	// whether we have valid command and line iters
	bool command_iter_valid;

	StringAndStringVectorMap::iterator line_map_iter;
	StringVector::iterator line_iter;
	CacheMap::iterator command_iter;
};

class StepSettings//: public IStepSettings
{
	BOOL ThemeInUse;
	string ThemeFile;
	string StepFile;


	// One file/line-list combo per name.
	// Meant for settings that are overridden by ones loaded later.
	StringAndStringVectorMap NameToFileAndLines;
	// One name2line per file. One list of lines per name.
	// Meant for settings that are loaded on a per-file basis.
	CacheMapMap FileToNameToLines;

	typedef map<string, string> VarMap;

	// pre-defined variables provided by litestep
	VarMap stepVariables;

protected:
	FILE* Open(LPCTSTR szPath);
	BOOL Close (FILE *f);
	BOOL ReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength);
	BOOL ReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength);
	BOOL ReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength);
	char* CleanString(char* szString);
	char* StripComment(char* szString);
	LPCTSTR FindLine(LPCTSTR szKeyName);
	void AddFileLine(LPCTSTR filename, LPCTSTR name, LPCTSTR value);
	bool AddLine(LPCSTR filename, LPCSTR name, LPCSTR value);
	bool GetLine(LPCSTR name, string& value);

	bool ReadLine(FILE *, LPTSTR, LPTSTR);
	bool ProcessLine(FILE *, LPCTSTR, LPCTSTR, LPCTSTR);
	bool ProcessIf(FILE *, LPCTSTR, LPCTSTR);
	bool SkipIf(FILE *);

	string ProcessInclude(LPCTSTR szPath, LPCSTR szRCPath);

public:
	void Clear();
	string GetThemeFile();
	string GetStepFile();
	void SetThemeFile(string theme_file);
	void SetStepFile(string step_file);
	StepSettings();
	virtual ~StepSettings();
  CacheMapMap &GetFileToNameToLines();
  StringAndStringVectorMap &GetNameToFileAndLines();
	string CacheRCFile(LPCTSTR szPath);
	bool AddVariable(LPCSTR name, LPCSTR value);
	bool GetVariable(LPCSTR name, string& value);
	bool VariableExists(LPCTSTR name);
	BOOL GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets);
	void VarExpansion(char *buffer, const char * value);
	int GetRCInt(LPCTSTR szKeyName, int nDefault);
	BOOL GetRCBool(LPCTSTR szKeyName, BOOL ifFound);
  BOOL GetRCBoolDef(LPCTSTR szKeyName, BOOL bDefault);
	BOOL GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen);
	COLORREF GetRCColor(LPCTSTR szKeyName, COLORREF colDef);
	BOOL GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault);
	int Tokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters, bool useBrackets = false);
	BOOL RCLineExists(LPCTSTR szKeyName);

	FILE* LCOpen(LPCTSTR szPath);
	BOOL LCClose (FILE *f);
	BOOL LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength);
	BOOL LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength);
	BOOL LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength);
};

#endif // !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
