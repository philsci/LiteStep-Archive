/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "common.h"
#include "bangs.h"
#include "safestr.h"

extern char szAppPath[256];
extern char szRcPath[256];

void setupBangs()
{
  AddBangCommand("!GATHER", BangGather);
  AddBangCommand("!RECYCLE", BangRecycle);
  AddBangCommand("!RUN", BangRun);
  AddBangCommand("!SHUTDOWN", BangShutdown);
  AddBangCommand("!TOGGLEWHARF", BangToggleWharf);
  AddBangCommand("!LOGOFF", BangLogoff);
  AddBangCommand("!QUIT", BangQuit);
  AddBangCommand("!POPUP", BangPopup);
  AddBangCommand("!TILEWINDOWSH", BangTileWindowsH);
  AddBangCommand("!TILEWINDOWSV", BangTileWindowsV);
  AddBangCommand("!CASCADEWINDOWS", BangCascadeWindows);
  AddBangCommand("!MINIMIZEWINDOWS", BangMinimizeWindows);
  AddBangCommand("!RESTOREWINDOWS", BangRestoreWindows);
  AddBangCommand("!ABOUT",  BangAbout);
  AddBangCommand("!UNLOADMODULE", BangUnloadModule);
  AddBangCommand("!RELOADMODULE", BangReloadModule);
  AddBangCommand("!EXECUTE", BangExecute);
  AddBangCommand("!REFRESH", BangRefresh);
  AddBangCommand("!ALERT", BangAlert);
  AddBangCommand("!CONFIRM", BangConfirm);
}


ULONG WINAPI AboutBoxThread( void * );

void BangAbout( HWND, LPCSTR )
{
	HANDLE threadHandle;
	DWORD threadID;

	threadHandle = CreateThread( NULL,
		0,
		AboutBoxThread,
		NULL,
		0,
		&threadID );

	CloseHandle( threadHandle );
}


void BangAlert(HWND caller, LPCSTR args)
{
	char message[MAX_PATH];
	char title[MAX_PATH];
	char *tokens[] = { message, title };

	int tokenCount = LCTokenize(args, tokens, 2, 0);

	if(tokenCount >= 1)
	{
		if(tokenCount == 1)
			lstrcpy(title, "Litestep");

		MessageBox(caller, message, title, MB_OK | MB_SETFOREGROUND);
	}
}


void BangCascadeWindows(HWND caller, LPCSTR args)
{
  CascadeWindows(NULL, MDITILE_SKIPDISABLED, NULL, 0, NULL);
}


void BangConfirm(HWND caller, LPCSTR args)
{
	char first[MAX_PATH];
	char second[MAX_PATH];
	char third[MAX_PATH];
	char fourth[MAX_PATH];
	char *tokens[] = { first, second, third, fourth };

	int tokenCount = CommandTokenize(args, tokens, 4, 0);

	if(tokenCount >= 3)
	{
		char *message;
		char *title;
		char *yesCommand;
		char *noCommand;

		if(tokenCount == 3)
		{
			message = first;
			yesCommand = second;
			noCommand = third;

			lstrcpy(fourth, "Litestep");
			title = fourth;
		}
		else
		{
			message = first;
			title = second;
			yesCommand = third;
			noCommand = fourth;
		}

		if(MessageBox(caller, message, title, MB_YESNO | MB_SETFOREGROUND) == IDYES)
			LSExecute(caller, yesCommand, SW_SHOWNORMAL);
		else
			LSExecute(caller, noCommand, SW_SHOWNORMAL);
	}
}


void BangExecute(HWND caller, LPCSTR args)
{
  char command[MAX_LINE_LENGTH];
  LPCSTR nextCommand = args;

  if (!StrLen(args))
    return;

  while (GetToken(nextCommand, command, &nextCommand, true))
    LSExecute(caller, command, SW_SHOWDEFAULT);
}


void BangGather(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_BRINGTOFRONT, 1, 0);
}


void BangLogoff(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 1, 0);
}


void BangMinimizeWindows(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    winList->GetWindowCount(&max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;
      winList->GetWindow(i, (OLE_HANDLE*)&window);
      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsWindowVisible(window))
        continue;
      ShowWindow(window, SW_MINIMIZE);
    }
  }
}


void BangPopup(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  char token0[MAX_LINE_LENGTH], token1[MAX_LINE_LENGTH];
  char* tokens[2];
  POINT p;
  int count = 0;
  tokens[0] = token0;
  tokens[1] = token1;
  token0[0] = token1[0] = '\0';
  if (args)
    count = LCTokenize(args, tokens, 2, NULL);
  if (ls)
  {
    if (GetCursorPos((LPPOINT)&p) == 0)
      p.x = p.y = 0;
    if (count > 1) {
      for (int i = 0; i <= 1; i++)
      {
        if (strnicmp(tokens[i], "X=", 2) == 0)
          p.x = atol(tokens[i] + 2);
        else if (strnicmp(tokens[i], "Y=",2) == 0)
          p.y = atol(tokens[i] + 2);
      }
    }
    SendMessage(ls, LM_HIDEPOPUP, 0, 0);
    SendMessage(ls, LM_POPUP, 0, MAKELPARAM(p.x, p.y));
  }
}


void BangQuit(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 2, 0);
}


void BangRecycle(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    PostMessage(ls, LM_RECYCLE, 0, 0);
  }
}


void BangRefresh(HWND caller, LPCSTR args)
{
  CloseRC();
	setupVars(szAppPath);
  SetupRC(szRcPath);
	SendMessage(GetLitestepWnd(), LM_REFRESH, 0, 0);
}


void BangReloadModule(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCSTR nextToken = args;
  char path[MAX_PATH];

  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_RELOADMODULE, (WPARAM)path, 0);
}


void BangRestoreWindows(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    winList->GetWindowCount(&max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;

      winList->GetWindow(i, (OLE_HANDLE*)&window);
      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsIconic(window))
        continue;
      ShowWindow(window, SW_RESTORE);
    }
  }
}


void BangRun(HWND caller, LPCSTR args)
{
    FARPROC (__stdcall *MSRun)(HWND, int, int, char*, char*, int);

    MSRun = (FARPROC (__stdcall *) (HWND, int, int, char*, char*, int))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3D));
    MSRun(NULL, 0, 0, NULL, NULL, 0);
}


void BangShutdown(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();
    FARPROC (__stdcall *MSWinShutdown)(HWND);

    MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
    MSWinShutdown(ls);
}


void BangTileWindowsH(HWND caller, LPCSTR args)
{
  TileWindows(NULL, MDITILE_HORIZONTAL, NULL, 0, NULL);
}


void BangTileWindowsV(HWND caller, LPCSTR args)
{
  TileWindows(NULL, MDITILE_VERTICAL, NULL, 0, NULL);
}


void BangToggleWharf(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_SHADETOGGLE, 0, 0);
}


void BangUnloadModule(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCSTR nextToken = args;
  char path[MAX_PATH];
  
  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_UNLOADMODULE, (WPARAM)path, 0);
}









