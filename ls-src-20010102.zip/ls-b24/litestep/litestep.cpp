/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
11/21/00 - Joachim Calvert (NeXTer)
  - Added the ability to specify bang commands on the command line. The bang
    has to be the last argument since everything following it is assumed to
    be the arguments for the bang
11/10/00 - Bobby G. Vinyard (Message)
  - Finished converting void installLitestep(LPCSTR szPath) to use resource
    strings, only void uninstallLitestep() in litestep.cpp is left to do
  - Added an uninstall litestep option to the ctl-alt-f1 recovery menu
  - Changed the recovery menu to use GetResStr instead of LoadString to allow
    for localization
10/30/00 - Joachim Calvert (NeXTer)
  - The -install/-uninstall feature is no longer broken under 9x (why hasn't
    anyone reported this before?)
08/17/00 - Joachim Calvert (NeXTer)
  - Unbroke the shell warning, sorry about that folks
08/05/00 - Joachim Calvert (NeXTer)
  - Changed some VC code into more generic API code in the startup code
08/03/00 - Joachim Calvert (NeXTer)
  - Added the ability to pause a recycle by holding the shift key
08/02/00 - Joachim Calvert (NeXTer)
  - Fixed a minor syntax error
  - Added code to prevent the accidental launch of multiple instances
  - Fixed the behavior of the -nostartup switch
  - Implemented support for specifying an arbitrary step.rc on the
    command line (the support was already there, but nonfunctional)
08/01/00 - Charles Oliver Nutter (Headius)
  - Fixed installLitestep bug, backslash between path and Litestep.exe
07/21/00 - Charles Oliver Nutter (Headius)
  - Cleaned up source a bit, removed DoEvents() function
07/21/00 - Joachim Calvert (NeXTer)
  - setupVars() wasn't called soon enough on recycle, so anything that
	  relied on the system variables would cause errors.
06-09-00 - Charles Oliver Nutter (Headius)
  - Added call to LitestepAPIInit, to initialize lsapi.dll
06-03-00 - Bobby G. Vinyard (Message)
  - Removed call causing hookmgr to be unloaded twice
  - Moved code that hides minimized windows  from hook.dll to litestep
05/27/00 - Charles Oliver Nutter (Headius)
  - Reorganized start/stop and reloading of settings to prevent loading them
	  twice initially
05/27/00 - Charles Oliver Nutter (Headius)
  - Added call to clear the bang manager
05/25/00 - Joachim Calvert (NeXTer)
  - Added an ugly clause to enable compilation under BCB.
05/18/00 - Bobby G. Vinyard (Message)
  - Removed litestep call to hookmgr for shell messages
04/13/00 - Bobby G. Vinyard (Message)
  - Added setupBangs() to startup routine
04/08/00 - Bobby G. Vinyard. (Message)
  - Reimplemented !about, !about detailed via void GetRevID();

****************************************************************************/
#pragma warning(disable: 4786)
#include <io.h>
#include <time.h>
#include <tchar.h>
#include <stdio.h>
#include <shlobj.h>
#include <crtdbg.h>
#include <windows.h>
#include <process.h>
#include <winuser.h>

#ifdef __BORLANDC__
  #include <system.hpp>
  #include <wstring.h>
  #define _INC_COMDEF

  #define _bstr_t(pSrc) (BSTR(WideString(pSrc)))
#else
  #include <comdef.h>
#endif


#include <fstream>

#include "litestep.h"
#include "../lsapi/lsapi.h"
#include "wharfdata.h"
#include "StartupRunner.h"
#include "DataStore.h"
#include "LitestepClass.h"
#include "StandardLogDispatch.h"
#include "../core/ifcs.h"
#include "../lsapi/macros.h"

// const char rcsRevision[] = "$Revision: 1.22.2.37 $"; // Our Version
const char rcsId[] = "$Id: litestep.cpp,v 1.22.2.37 2000/11/28 04:39:07 message Exp $"; // The Full RCS ID.
const char LSRev[] = "0.24.5 ";

// Program Options
const LPCTSTR   szMainWindowClass = _T("TApplication");
const LPCTSTR   szMainWindowTitle = _T("LiteStep");

const TCHAR szRecoveryMenuWndClass[] = TEXT("RecoveryMenuWndClass");

// Paths
CHAR szAppPath[256], szRcPath[256];

// Application instance
HINSTANCE hDLLInstance;

// Run startup items flag
BOOL bRunStartup = TRUE;

// Bang command passed on the command line
LMBANGCOMMAND* bcBangCommand = NULL;

// Windows
HWND hMainWindow = NULL;

// Main window procedure
LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Show explorer warning? LS is the shell?
BOOL ShowWarning = TRUE, isShell = FALSE;

// Initialize/shutdown manager services
void InitializeManagers();
void ShutdownManagers();

// Read config from step.rc
void ReadConfig (void);

// Parse the command line
void ParseCmdLine(LPSTR lpCmdLine, HWND hLSWnd);

// The manager services
DataStore *globalDataStore = NULL;
IMessageManager *globalMsgManager = NULL;
IWindowList *globalWindowList = NULL;
IModuleManager *globalModuleManager = NULL;
IBangManager *globalBangManager = NULL;

ILitestep *globalLitestep = NULL;
ILogDispatch *globalLogDispatch = NULL;

// Handle thread messages
void HandleThreadMessage(MSG msg);

// Start up anything that should be started
void start();

// Stop the stuff we started
void stop();

// Shut down litestep
void ShutDown(void);

// We are under explorer? recycling? ending the current session?
BOOL UnderExplorer = FALSE, gRecycle = FALSE, gEndSession = FALSE;

// Skip events (?)
BOOL skipEvents = FALSE;

// Get revision ID's
//HRESULT GetRevId(WPARAM wParam, LPARAM lParam);
void GetRevId(WPARAM wParam, LPARAM lParam);

// Install and Uninstall Routines
void installLitestep(LPCSTR);
void uninstallLitestep();

// recovery menu functions
LRESULT WINAPI RecoveryMenuWndProc( HWND, UINT, WPARAM, LPARAM );
DWORD WINAPI RecoveryThreadProc( LPVOID );

// Tray data pointer for storage
static trayType *trayData = NULL;

// Undocumented API: Set/Get the shell window, Shutdown windows
FARPROC (__stdcall *SetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *GetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *MSWinShutdown)(HWND) = NULL;

// Some pointers we don't want in the header
int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
int (FAR *quitWharfModule)(HINSTANCE);

//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//
// Code Starts Here

BOOL FileExists(LPCTSTR szFileName)
{
  HANDLE handle;
  WIN32_FIND_DATA findData;

  handle = FindFirstFile(szFileName, &findData);
  if (handle != INVALID_HANDLE_VALUE)
  {
    FindClose(handle);
    if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
      return TRUE;
  }
  return FALSE;
}

int main(int argc, char** argv) {
  for (int i = 0; i < argc; i++) {
		if (stricmp(argv[i], "-help") == 0 ||
			stricmp(argv[i], "-h") == 0 ||
			stricmp(argv[i], "/?") == 0) {
			printf("LiteStep DOS-mode command line params:\n-install - Install LiteStep as default shell\n-uninstall - Uninstall LiteStep as default shell\n-help - Get this help message\n");
			break;
		}
    if (argv[i][0] == '-') {
      if (!stricmp(argv[i], "-install")) {
        installLitestep(szAppPath);
				break;
			}
      if (!stricmp(argv[i], "-uninstall")) {
        uninstallLitestep();
				break;
			}
    }
  }

	return 0;
}

// [Main Litestep Code]
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow) 
{
	ATOM aClass;
	WNDCLASS wc;
	
	bRunStartup = TRUE;       
	szAppPath[0] = 0;
	hDLLInstance = hInstance;

	// Determine our application's path
	if (GetModuleFileName (hDLLInstance, szAppPath, sizeof (szAppPath)) > 0) 
  {
		int len = lstrlen (szAppPath);
		while (len && szAppPath[len-1] != _T('\\')) 
    {
			szAppPath[--len] = _T('\0');
		}
		
		if (len) 
    {
			szAppPath[--len] = _T('\0');
		}
	}

	// Parse command line, setting appropriate variables
  HWND hLSWnd = FindWindow(TEXT("TApplication"), TEXT("Litestep"));
	ParseCmdLine(lpCmdLine, hLSWnd);

	// Check for previous instance
	CreateMutex(NULL, FALSE, "LiteStep");
	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
    if (!bcBangCommand)
    {
		  // Prevent multiple instances of LiteStep
		  RESOURCE_STR(hInstance, IDS_LITESTEP_ERROR1,
		    "A previous instance of LiteStep was detected.\nAre you sure you want to continue?");
		  if (IDNO == MessageBox(
		    NULL,
		    resourceTextBuffer, 
		    "LiteStep", 
		    MB_TOPMOST | MB_ICONINFORMATION | MB_YESNO | MB_DEFBUTTON2
		  ))
		    return 0;
    }
    else
    {
      // A bang command was sent on the command line so we execute it
      if (hLSWnd)
      {
        COPYDATASTRUCT cds = {LM_BANGCOMMAND, sizeof(LMBANGCOMMAND), (LPVOID)bcBangCommand};
      
        SendMessage(hLSWnd, WM_COPYDATA, 0, (LPARAM)&cds);
      }
      delete bcBangCommand;
      return 0;
    }
	}

	// before anything else, start the recovery menu thread
	DWORD dwThreadID;
	CloseHandle( CreateThread( NULL, 0, RecoveryThreadProc, NULL, 0, &dwThreadID ) );

  // Get undocumented APIs
	SetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "SetShellWindow");
	GetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "GetShellWindow");
	MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
	
  // If we can't find "step.rc", there's no point in proceeding
  if (!FileExists(szRcPath))
  {
    RESOURCE_STREX(hInstance, IDS_LITESTEP_ERROR2, resourceTextBuffer, MAX_LINE_LENGTH, 
      "Unable to find the file \"%s\".\nPlease verify the location of the file, and try again.", szRcPath);
    MessageBox(NULL, resourceTextBuffer, "LiteStep", MB_TOPMOST | MB_ICONEXCLAMATION);
    return 0;
  }


	// Initialize OLE/COM
	OleInitialize( NULL );

	// Initalized LitestepAPI
	LitestepAPIInit();
	
	// configure the Win32 window manager to hide windows when they are minimized
	MINIMIZEDMETRICS mm;
	mm.cbSize = sizeof(MINIMIZEDMETRICS);

	SystemParametersInfo( SPI_GETMINIMIZEDMETRICS, mm.cbSize, &mm, 0 );
	
	if( !(mm.iArrange & ARW_HIDE) )
	{
		mm.iArrange |= ARW_HIDE;
		SystemParametersInfo( SPI_SETMINIMIZEDMETRICS, mm.cbSize, &mm, 0 );
	}

	//Setup environment variables
  setupVars(szAppPath);

	// Read config and close the .rc file
	ReadConfig();
	
	// Check for explorer
	if (FindWindow("Shell_TrayWnd", NULL)) // Running under Exploder
  {
    if (ShowWarning) 
    {
      RESOURCE_STR(hInstance, IDS_LITESTEP_ERROR3,
        "You are currently running another shell, while Litestep b24 allows you\012to run under Explorer, we don't advise it for inexperienced users, and we\012will not support it, so do so at your own risk.\012\012If you continue, some of the advanced features of Litestep will be disabled\012such as the desktop. The wharf, hotkeys, and shortcuts will still work.\012\012To get rid of this message next time, put LSNoShellWarning in your step.rc\012\012Continue?")     
      RESOURCE_TITLE(hInstance, IDS_LITESTEP_TITLE_WARNING, "Warning")
			if (MessageBox(0, resourceTextBuffer, resourceTitleBuffer, MB_YESNO | MB_ICONEXCLAMATION | MB_TOPMOST) == IDNO)
				exit(0);
			UnderExplorer = TRUE;
    }
	}
	
	// Register Window Class
	memset (&wc, 0, sizeof (wc));
	
	wc.lpfnWndProc = MainWndProc;
	wc.hInstance = hDLLInstance;
	wc.lpszClassName = szMainWindowClass;
	aClass = RegisterClass(&wc);
	if (!aClass) 
  {
    RESOURCE_MSGBOX_T(hInstance, IDS_LITESTEP_ERROR4,
      "Error registering main Litestep window class.",
      IDS_LITESTEP_TITLE_ERROR, "Error")

		return 0;
	}

	// Create our main window
	hMainWindow = CreateWindowEx(WS_EX_TOOLWINDOW,
		szMainWindowClass, szMainWindowTitle, 0,
		0, 0, 0, 0, NULL, NULL, hDLLInstance, NULL);
	
	// Start up everything
	if (hMainWindow) 
  {
		MSG message;
		
		// Set magic DWORD to prevent VWM from seeing main window
		SetWindowLong (hMainWindow, GWL_USERDATA, magicDWord);
		
		// Set Shell Window
		if (!UnderExplorer && isShell) SetShellWindow(hMainWindow);

		// init managers
		InitializeManagers();
		
		start();
		
		// Main message pump
		while (GetMessage(&message, 0, 0, 0) > 0) 
    {
			__try 
      {
				if (message.hwnd == NULL)
        {
					if (message.message == NULL) {
						//something's wacked, break out of this
						break;
					}
					// Thread message
					HandleThreadMessage(message);
				}
        else 
        {
					TranslateMessage(&message);
					DispatchMessage (&message);
				}
			}
      __except(1)
      {
			}
		}
		
		stop();
		
		// Clean up remaining events in message queue
		/*if (!skipEvents)
    {
			while (GetMessage (&message, 0, 0, 0) > 0)
      {
				TranslateMessage(&message);
				DispatchMessage (&message);
			}
		}*/
		
		// Destroy main window
		DestroyWindow(hMainWindow);
		hMainWindow = NULL;
		
		// Shutdown managers
		ShutdownManagers();
	} else {
    RESOURCE_MSGBOX_T(hInstance, IDS_LITESTEP_ERROR5,
      "Error creating Litestep main application window.",
      IDS_LITESTEP_TITLE_ERROR, "Error")
	}
	
	// Unreg class
	UnregisterClass (szMainWindowClass, hDLLInstance);
	
	// Uninitialize OLE/COM
	OleUninitialize();
	
	// close the recovery thread
	DestroyWindow( FindWindow( szRecoveryMenuWndClass, NULL ) );

	return 0;
}

void HandleThreadMessage(MSG msg)
{
	switch (msg.message)
  {
		case LM_THREAD_BANGCOMMAND:
			BangCommandInfo *info = (BangCommandInfo*)msg.wParam;

			info->bang->Execute(info->caller, info->params, info->result);
			break;
	}
}

void start()
{
	SetBangManager(globalBangManager);

	// Setup bang commands in lsapi
	setupBangs();

	// Load the hook manager
  globalModuleManager->LoadModule(_bstr_t("hookmgr.dll"), 0); // dependency wackiness...we'll put up with it for now.

	// Load modules
	globalModuleManager->LoadModules(NULL);

	globalLogDispatch->Log(1, _bstr_t("Modules finished loadingModules finished loadingModules finished loadingModules finished loadingModules finished loading"));

	// Restore the system tray
	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_RESTORESYSTRAY, &exists);

	if (gRecycle && exists && trayData)
  {
		SendMessage(hMainWindow, LM_RESTORESYSTRAY, 0, (LONG)trayData);
		if (trayData) free(trayData);
	}
	
	// If not recycling, run startup items
	if (!gRecycle)
  {
		// Run startup items if the SHIFT key is not down
		if(!(GetAsyncKeyState(VK_SHIFT) & 0x8000) && bRunStartup)
    {
			_beginthread(StartupRunner::RunStartupStuff, 0, &UnderExplorer);
		}
	}
	gRecycle = FALSE;
	
	SendMessage(GetDesktopWindow(), 0x400, 0, 0); // Undocumented call: Shell Loading Finished
}

void stop() {
	// Save system tray data
	globalModuleManager->QuitModule(_bstr_t("hookmgr.dll")); // dependency wackiness...we'll put up with it for now.

	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_SAVESYSTRAY, &exists);

	if (gRecycle && exists) {
		trayData = (trayType *)calloc(200, sizeof(trayType));
		SendMessage(hMainWindow, LM_SAVESYSTRAY, 0, (LONG)trayData);
	}
	
	// Quit all modules
	globalModuleManager->QuitModules();

	globalBangManager->ClearBangCommands();
	ClearBangManager();
}

void restart() {
	stop();

	CloseRC();

  if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
  {
    RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_ERROR6,
      "Recycle has been paused, click OK to continue.", "LiteStep")

  }
	setupVars(szAppPath);
	ReadConfig();

	start();
}

LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	switch (uMsg) {
	case WM_KEYDOWN:
		if (wParam == LM_SHUTDOWN) {
			ParseBangCommand(hwnd, "!ShutDown", NULL);
		}
		return 0;
		
	case WM_SYSCOMMAND: 
		switch (wParam) {
		case SC_CLOSE:
			ParseBangCommand(hwnd, "!ShutDown", NULL);
			return 0;
		default:
			return DefWindowProc(hwnd,uMsg,wParam,lParam);
		}
		
	case WM_QUERYENDSESSION:
		return TRUE;
		
	case WM_ENDSESSION:
		gEndSession = TRUE;
		break;
		
	case LM_SAVEDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->StoreData(ident, data, len);
		}
		return 0;
					  }
		
	case LM_RESTOREDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->ReleaseData(ident, data, len);
		}
		return 0;
						 }
		
	case LM_REGISTERMESSAGE: // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->AddMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
		
	case LM_UNREGISTERMESSAGE: // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->RemoveMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
		
	case LM_GETLSOBJECT:
		return (LONG) globalLitestep;

	case LM_WINDOWLIST:
		return (LONG)globalWindowList;

	case LM_DATASTORE:
		return (LONG)globalDataStore;
		
	case LM_MESSAGEMANAGER:
		return (LONG) globalMsgManager;

	case LM_RECYCLE:
		if (wParam == 0) {
			gRecycle = TRUE;
			restart();
		} else if (wParam == 1) {
			if (ExitWindowsEx (EWX_LOGOFF, 0)) {
				PostQuitMessage(0);
			}
		} else if (wParam == 2) {
			PostQuitMessage(0);
			skipEvents = TRUE;
		} else {
			ShutDown();
		}
		break;

	case LM_UNLOADMODULE:	{ // Module Handler Message

		LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		break;
	}
		
	case LM_RELOADMODULE:	{ // Module Handler Message
    
    LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		globalModuleManager->LoadModule( wszPath, 0 );
		break;
	}
		
	case LM_BANGCOMMAND: {
		PLMBANGCOMMAND plmbc = (PLMBANGCOMMAND) lParam;

		if( !plmbc )
			return FALSE;
		
		if( plmbc->cbSize != sizeof(LMBANGCOMMAND) )
			return FALSE;
		
		ParseBangCommand( plmbc->hWnd, plmbc->szCommand, plmbc->szArgs );
		return TRUE;
	}
		
	case WM_COPYDATA: {
		PCOPYDATASTRUCT pcds = (PCOPYDATASTRUCT) lParam;
		
		switch( pcds->dwData )
		{
			case LM_BANGCOMMAND:
				
				return SendMessage( hwnd, LM_BANGCOMMAND, 0,
					(LPARAM) pcds->lpData );
		}
		
		return 0;
	}

  case LM_GETREVID: {
    GetRevId(wParam, lParam);
		break;
  }

	default:
		if (globalMsgManager) {
			BOOL exists = FALSE;
			globalMsgManager->HandlerExists(uMsg, &exists);
			
			if (exists) {
				LRESULT lResult;
				globalMsgManager->SendMessage( uMsg, wParam, lParam, &lResult );
				return lResult;
			}
		}
		
		return DefWindowProc (hwnd, uMsg, wParam, lParam);
 }

 return 0;
}


// [Config/Settings Code]
void InitializeManagers(void) {
	globalDataStore = new DataStore();
    
  RESOURCE_TITLE(hDLLInstance, IDS_LITESTEP_TITLE_FATAL_ERROR, "Fatal Error");

	HINSTANCE msgMgrLib = ::LoadLibrary("msgmgr.dll");

	if (msgMgrLib == NULL) {
    RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_ERROR7, resourceTextBuffer, MAX_LINE_LENGTH,
      "Unable to load %s", "msgmgr.dll");
    RESOURCE_DISPLAY_MSGBOX
		// do something
	}

	IMessageManager *(__stdcall *CreateMessageManager)(void) = (IMessageManager *(__stdcall *)())GetProcAddress(msgMgrLib, "CreateMessageManager");
	globalMsgManager = CreateMessageManager();

	// requires message registration, must come after message manager
	HINSTANCE winListLib = ::LoadLibrary("winlist.dll");

	if (winListLib == NULL) {
    RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_ERROR7, resourceTextBuffer, MAX_LINE_LENGTH,
      "Unable to load %s", "winlist.dll");
    RESOURCE_DISPLAY_MSGBOX
		// do something
	}

	IWindowList *(__stdcall *CreateWindowList)(void) = (IWindowList *(__stdcall *)())GetProcAddress(winListLib, "CreateWindowList");
	globalWindowList = CreateWindowList();

	// DLL module manager
	HINSTANCE modManLib = ::LoadLibrary("dllmgr.dll");

	if (modManLib == NULL) {
    RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_ERROR7, resourceTextBuffer, MAX_LINE_LENGTH,
      "Unable to load %s", "dllmgr.dll");
    RESOURCE_DISPLAY_MSGBOX
		// do something
	}

	IModuleManager *(__stdcall *CreateModuleManager)(HWND, LPCTSTR) = (IModuleManager *(__stdcall *)(HWND, LPCTSTR))GetProcAddress(modManLib, "CreateModuleManager");
	globalModuleManager = CreateModuleManager(hMainWindow, szAppPath);

	HINSTANCE bangmgr = LoadLibrary("bangmgr.dll");

	if (bangmgr == NULL) {
    RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_ERROR7, resourceTextBuffer, MAX_LINE_LENGTH,
      "Unable to load %s", "bangmgr.dll");
    RESOURCE_DISPLAY_MSGBOX
	} else {
		IBangManager *(__stdcall *CreateBangManager)(void) = (IBangManager *(__stdcall *)())GetProcAddress(bangmgr, "CreateBangManager");
		globalBangManager = CreateBangManager();
	}

	Litestep *ls = new Litestep();
	ls->QueryInterface(IID_ILitestep, (void**)&globalLitestep);

	StandardLogDispatch *log_disp = new StandardLogDispatch();
	log_disp->QueryInterface(IID_ILogDispatch, (void**)&globalLogDispatch);
	ls->SetLogDispatch(globalLogDispatch);

	globalLitestep->RegisterWindowList(_bstr_t(L"default"), globalWindowList);
	globalLitestep->RegisterMessageManager(_bstr_t(L"default"), globalMsgManager);
	globalLitestep->RegisterModuleManager(_bstr_t(L"default"), globalModuleManager);
	globalLitestep->RegisterBangManager(_bstr_t(L"default"), globalBangManager);

	globalLogDispatch->Log(2, _bstr_t("Modules loaded"));
}

void ShutdownManagers() {
	globalLitestep->Release();
	globalLitestep = NULL;

	globalLogDispatch->Release();
	globalLogDispatch = NULL;

	globalBangManager->Release();
	globalBangManager = NULL;

	globalModuleManager->Release();
	globalModuleManager = NULL;

	globalWindowList->Release();
	globalWindowList = NULL;

	globalMsgManager->Release();
	globalMsgManager = NULL;

	globalDataStore->Clear();
	delete globalDataStore;
	globalDataStore = NULL;
}

void ReadConfig (void)
{
	if (SetupRC(szRcPath))
  {
		
		// Modified - Maduin, 10-20-1999
		//   Added "ExplorerNoWarn" and "SetAsShell" again to smooth
		//   the transition to the new style. Eventually these should
		//   be removed, but for now backwards compability is a good
		//   thing.
		
		ShowWarning = !(GetRCBool("LSNoShellWarning", TRUE) || GetRCBool("ExplorerNoWarn", TRUE));
		isShell = GetRCBool("LSSetAsShell", TRUE) || GetRCBool("SetAsShell", TRUE);
	}
}

void ParseCmdLine(LPSTR lpCmdLine, HWND hLSWnd)
{
	char token[MAX_PATH];
	LPCTSTR nextToken = lpCmdLine;

  sprintf(szRcPath, "%s\\step.rc", szAppPath);
  while (GetToken(nextToken, token, &nextToken, false))
  {
    switch (token[0])
    {
      case '-':
        if (!stricmp(token, "-nostartup"))
          bRunStartup = FALSE;
        if (!stricmp(token, "-install"))
          installLitestep(szAppPath);
        if (!stricmp(token, "-uninstall"))
          uninstallLitestep();
        break;

      case '!':
        if (hLSWnd)
        {
          bcBangCommand = new LMBANGCOMMAND;
          bcBangCommand->cbSize = sizeof(LMBANGCOMMAND);
          bcBangCommand->hWnd = NULL;
          if (token)
            strcpy(bcBangCommand->szCommand, token);
          if (nextToken)
            strcpy(bcBangCommand->szArgs, nextToken);
          else
            bcBangCommand->szArgs[0] = '\0';
          return;
        }
        break;

      default:
        if (FileExists(token))
        {
          if (strchr(token, '\\'))
            strcpy(szRcPath, token);
          else
            sprintf(szRcPath, "%s\\%s", szAppPath, token);
        }
    }
  }
}

int ErrorBox( HWND hWnd, LPCTSTR pszText, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags )
{
	TCHAR szMessage[MAX_PATH];
	int nLen;
	
	lstrcpyn(szMessage, pszText, MAX_PATH - 1);
	lstrcat(szMessage, TEXT(" "));
	nLen = lstrlen(szMessage);
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, dwErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), szMessage + nLen,
		MAX_PATH - nLen, NULL);
	
	return MessageBox( hWnd, szMessage, pszTitle, nFlags | MB_TOPMOST);
}

void ShutDown(void) {
	
	MSWinShutdown(hMainWindow);
	return;
}

void GetRevId(WPARAM wParam, LPARAM lParam) {
	char buf[256];

	if (wParam == 1) {
    		strcpy(buf, &rcsId[1]);
		buf[strlen(buf)-1] = '\0';
	} else {
		strcpy(buf, "litestep.exe: ");
		strcat(buf, (LPCSTR)&LSRev);
		buf[strlen(buf)-1] = '\0';
	}
  SendMessage((HWND)lParam, LM_GETREVID, 0, (long)buf);
  globalMsgManager->GetRevID(LM_GETREVID, wParam, lParam);
}

void installLitestep(LPCSTR szPath) {
  
  OSVERSIONINFO osInfo;
  char szLs[MAX_PATH];

  RESOURCE_TITLE(hDLLInstance, IDS_LITESTEP_TITLE_INSTALL, "LiteStep Installation")
  
  ZeroMemory(&osInfo, sizeof(osInfo));
  osInfo.dwOSVersionInfoSize = sizeof(osInfo);
  GetVersionEx(&osInfo);
  
  RESOURCE_STR(hDLLInstance, IDS_LITESTEP_INSTALL1,
    "Do you want to install Litestep as your default shell?");
  if(RESOURCE_YESNO_MSGBOX == IDYES)
  {
    
    if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) 
    {
      RESOURCE_STR(hDLLInstance, IDS_LITESTEP_INSTALL2,
        "Would you like to update your Registry with the Shell path?");
      if (RESOURCE_YESNO_MSGBOX == IDYES) 
      {

        HKEY key;
        DWORD result;

				if (szLs[strlen(szLs) - 1] == '\\') 
        {
					wsprintf(szLs, "%sLitestep.exe\0\0", szPath);
				} 
        else 
        {
					wsprintf(szLs, "%s\\Litestep.exe\0\0", szPath);
				}


        RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_INSTALL3, resourceTextBuffer, MAX_LINE_LENGTH,
          "Install %s for All Users? No will install for Current User (yourself) only", szLs);
        if (RESOURCE_YESNO_MSGBOX == IDYES) 
        {
          // setup reg key for all users
          if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) 
          {
            if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            {
              RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL4,
                "Installation successful!\nInstallation complete!", resourceTitleBuffer)
            }
            else
            {
              RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL5,
                "Installation unsuccessful!\nUnable to set registry key.", resourceTitleBuffer)
              RegCloseKey(key);
            }
          }
          else
          {
            RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL5,
              "Installation unsuccessful!\nUnable to set registry key.", resourceTitleBuffer)
          }
        } 
        else 
        {
          // setup reg key for current user only
          if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) {
            if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            {
              RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL4,
                "Installation successful!\nInstallation complete!", resourceTitleBuffer)
            }
            else
            {
              RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL5,
                "Installation unsuccessful!\nUnable to set registry key.", resourceTitleBuffer)
              RegCloseKey(key);
            }
          }
          else
          {
            RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL5,
              "Installation unsuccessful!\nUnable to set registry key.", resourceTitleBuffer)
          }
        }
      }
    } 
    else	
    { // Win9x
      char szWinDir[MAX_PATH];
      
      GetWindowsDirectory(szWinDir, sizeof(szWinDir));
      strcat(szWinDir, "\\");
      strcat(szWinDir, "SYSTEM.INI");
      if (szPath[strlen(szPath) - 1] == '\\')
        wsprintf(szLs, "%slitestep.exe", szPath);
      else
        wsprintf(szLs, "%s\\litestep.exe", szPath);
      
      //wsprintf(szInf, "Would you like to update %s with the following\r\n\r\nShell=%s", szWinDir, szLs);
      RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_INSTALL6, resourceTextBuffer,  MAX_LINE_LENGTH,
        "Would you like to update %s with the following\r\n\r\nShell=%s",
        szWinDir, szLs);
      if (RESOURCE_YESNO_MSGBOX == IDYES) 
      {
        if (WritePrivateProfileString("Boot", "Shell", szLs, szWinDir) != 0)
        {
          RESOURCE_MSGBOX(hDLLInstance, IDS_LITESTEP_INSTALL4,
            "Installation successful!\nInstallation complete!", resourceTitleBuffer)
        }
        else 
        {
          //wsprintf(szInf, "Unable to update %s \n You will need to manually add %s to %s", szWinDir, szLs, szWinDir);
          RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_INSTALL7, resourceTextBuffer, MAX_LINE_LENGTH,
            "Installation unsuccessful!\nUnable to update %s \n You will need to manually add %s to %s",
            szWinDir, szLs, szWinDir);
          RESOURCE_DISPLAY_MSGBOX
        }
      }
      else 
      {
        //wsprintf(szInf, "You will need to manually add %s to %s", szLs, szWinDir);
        RESOURCE_STREX(hDLLInstance, IDS_LITESTEP_INSTALL8, resourceTextBuffer, MAX_LINE_LENGTH,
          "Installation unsuccessful!\nYou will need to manually add %s to %s",
          szLs, szWinDir);
        RESOURCE_DISPLAY_MSGBOX
      }
    }
  }
}

void uninstallLitestep() {

  OSVERSIONINFO osInfo;
  // bool setupSucceed; // UNUSED

  ZeroMemory(&osInfo, sizeof(osInfo));
  osInfo.dwOSVersionInfoSize = sizeof(osInfo);
  GetVersionEx(&osInfo);
  
  if(MessageBox(NULL, "Do you want to uninstall Litestep?", "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES)
  {
    if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
    {
      char szLs[MAX_PATH], szInf[1024];
      HKEY key;
      DWORD result;
      
      GetWindowsDirectory(szInf, MAX_PATH);
      
      wsprintf(szLs, "%s\\explorer.exe\0\0", szInf);
      
      wsprintf(szInf, "Install %s for All Users? No will install for Current User (yourself) only", szLs);
      if (MessageBox(NULL, szInf, "LiteStep Uninstallation", MB_YESNO | MB_TOPMOST) == IDYES)
      {
        // setup reg key for all users
        if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
          NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS)
        {
          if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            MessageBox(NULL, "Uninstallation successful, you may now safely delete the Litestep Directory.", "LiteStep Uninstallation Complete", MB_OK | MB_TOPMOST);
          else
            MessageBox(NULL, "Unable to set registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
          RegCloseKey(key);
        }
        else
          MessageBox(NULL, "Unable to open registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK);
      } 
      else
      {
        // setup reg key for current user only
        if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
          NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS)
        {
          if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            MessageBox(NULL, "Uninstallation successful, ensure no other users are using Litestep before deleting the Litestep directory.", "LiteStep Uinstallation Complete", MB_OK | MB_TOPMOST);
          else
            MessageBox(NULL, "Unable to set registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
          RegCloseKey(key);
        }
        else
          MessageBox(NULL, "Unable to open registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
      }
    }
    else
    { // Win9x
      char szWinDir[MAX_PATH], szInf[1024], szLs[MAX_PATH];
    
      GetWindowsDirectory(szWinDir, sizeof(szWinDir));
      strcat(szWinDir, "\\");
      wsprintf(szLs, "%sexplorer.exe", szWinDir);
      strcat(szWinDir, "SYSTEM.INI");
    
    
      wsprintf(szInf, "Would you like to update %s with the following?\n\nShell=%s", szWinDir, szLs);
      if (MessageBox(NULL, szInf, "LiteStep Uninstallation", MB_YESNO | MB_TOPMOST) == IDYES)
      {
        if (WritePrivateProfileString("Boot", "Shell", szLs, szWinDir) != 0)
          MessageBox(NULL, "Uninstallation successful, you may now safely delete the Litestep Directory", "LiteStep Uninstallation Complete", MB_OK | MB_TOPMOST);
        else
        {
          wsprintf(szInf, "Unable to update %s \n You will need to manually add %s to %s", szWinDir, szLs, szWinDir);
          MessageBox(NULL, szInf, "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
        }
      }
      else
      {
        wsprintf(szInf, "You will need to manually add %s to %s", szLs, szWinDir);
        MessageBox(NULL, szInf, "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
      }
    } 
  }
}

// this thread provides a recovery menu which can be accessed in
// case errors render Litestep unusable
DWORD WINAPI RecoveryThreadProc( LPVOID )
{
	WNDCLASSEX wc;
	memset( &wc, 0, sizeof(WNDCLASSEX) );

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.lpfnWndProc = RecoveryMenuWndProc;
	wc.hInstance = GetModuleHandle( NULL );
	wc.lpszClassName = szRecoveryMenuWndClass;

	RegisterClassEx( &wc );

	CreateWindowEx( 0,
		szRecoveryMenuWndClass,
		NULL,
		WS_POPUP,
		0, 0, 0, 0,
		NULL,
		NULL,
		GetModuleHandle( NULL ),
		NULL );

	MSG msg;

	while( GetMessage( &msg, NULL, 0, 0 ) )
	{
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}

	return 0;
}

#define ID_HOTKEY 1

#define ID_RECYCLE 1
#define ID_QUIT 2
#define ID_TERMINATE 3
#define ID_RUN 4
#define ID_SHUTDOWN 5
#define ID_UNINSTALL 6

struct { int nStringID; int nCommandID; char* pszDefText; } rgMenuCommands[] =
{
	IDS_LITESTEP_RECYCLELS, ID_RECYCLE, "&Recycle LiteStep",
	IDS_LITESTEP_QUITLS, ID_QUIT, "&Quit LiteStep",
	IDS_LITESTEP_TERMINATELS, ID_TERMINATE, "Forcibly &Terminate LiteStep",
  IDS_LITESTEP_UNINSTALLLS, ID_UNINSTALL, "U&ninstall LiteStep",
	0, -1, "",
	IDS_LITESTEP_RUN, ID_RUN, "R&un...",
	0, -1, "",
	IDS_LITESTEP_SHUTDOWNWIN, ID_SHUTDOWN, "&Shutdown Windows..."
};

const int cMenuCommands = sizeof(rgMenuCommands) / sizeof(rgMenuCommands[0]);

LRESULT WINAPI RecoveryMenuWndProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam )
{
	switch( nMessage )
	{
		case WM_HOTKEY:
		{
			if( wParam != ID_HOTKEY )
				break;

			HMENU hMenu = CreatePopupMenu();

			for( int i = 0; i < cMenuCommands; i++ )
			{
				if( rgMenuCommands[i].nStringID )
				{
					TCHAR szBuffer[MAX_PATH];
					//LoadString( (HINSTANCE) GetWindowLong( hWnd, GWL_HINSTANCE ), rgMenuCommands[i].nStringID, szBuffer, MAX_PATH );
          GetResStr( (HINSTANCE) GetWindowLong( hWnd, GWL_HINSTANCE ), 
            rgMenuCommands[i].nStringID, szBuffer, MAX_PATH,
            rgMenuCommands[i].pszDefText);
					AppendMenu( hMenu, MF_STRING, rgMenuCommands[i].nCommandID, szBuffer );
				}
				else
				{
					AppendMenu( hMenu, MF_SEPARATOR, 0, NULL );
				}
			}

			POINT pt;
			GetCursorPos( &pt );

			SetForegroundWindow( hWnd );

			int nCommand = (int) TrackPopupMenu( hMenu,
				TPM_LEFTBUTTON | TPM_RETURNCMD | TPM_NONOTIFY,
				pt.x, pt.y,
				0, hWnd, NULL );

			switch( nCommand )
			{
				case ID_RECYCLE:
				{
					SendMessage( GetLitestepWnd(), LM_RECYCLE, 0, 0 );
					return 0;
				}

				case ID_QUIT:
				{
					SendMessage( GetLitestepWnd(), LM_RECYCLE, 2, 0 );
					return 0;
				}

				case ID_TERMINATE:
				{
					TerminateProcess( GetCurrentProcess(), 1 );
					return 0;
				}

				case ID_RUN:
				{
					void (WINAPI *RunDlg)( HWND, HICON, LPCTSTR, LPCTSTR, LPCTSTR, UINT ) = (void (WINAPI *)( HWND, HICON, LPCTSTR, LPCTSTR, LPCTSTR, UINT )) GetProcAddress(
						GetModuleHandle( TEXT("SHELL32.DLL") ), (LPCTSTR) 61 );

					RunDlg( NULL, NULL, NULL, NULL, NULL, 0 );
					return 0;
				}

				case ID_SHUTDOWN:
				{
					void (WINAPI *ShutdownDlg)( HWND ) = (void (WINAPI *)( HWND )) GetProcAddress(
						GetModuleHandle( TEXT("SHELL32.DLL") ), (LPCTSTR) 60 );

					ShutdownDlg( NULL );
					return 0;
				}

        case ID_UNINSTALL:
        {
          uninstallLitestep();
          return 0;
        }
			}

			return 0;
		}

		case WM_CREATE:
		{
			RegisterHotKey( hWnd, ID_HOTKEY, MOD_CONTROL | MOD_ALT, VK_F1 );
			return 0;
		}

		case WM_DESTROY:
		{
			UnregisterHotKey( hWnd, ID_HOTKEY );

			PostQuitMessage( 0 );
			return 0;
		}
	}

	return DefWindowProc( hWnd, nMessage, wParam, lParam );
}
