// StandardLogDispatch.h: interface for the StandardLogDispatch class.
//
//////////////////////////////////////////////////////////////////////

#pragma	warning(disable: 4786) // STL naming warnings

#if !defined(AFX_STANDARDLOGDISPATCH_H__F1F98169_D95B_41D8_A0F1_289B148F299F__INCLUDED_)
#define AFX_STANDARDLOGDISPATCH_H__F1F98169_D95B_41D8_A0F1_289B148F299F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <vector>

#include "../core/ifcs.h"

typedef std::vector< IUnknown* > LogHandlerList;
typedef std::map< int, LogHandlerList > LogHandlerMap;

class StandardLogDispatch : public ILogDispatch  
{
	long refCount;
	LogHandlerMap logHandlers;

public:
	StandardLogDispatch();
	virtual ~StandardLogDispatch();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
  HRESULT STDMETHODCALLTYPE QueryInterface( 
      /* [in] */ REFIID riid,
      /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
  ULONG STDMETHODCALLTYPE Release( void);
	
  virtual HRESULT STDMETHODCALLTYPE Log( 
      /* [in] */ int logLevel,
      /* [in] */ BSTR formatMessage);
  
  virtual HRESULT STDMETHODCALLTYPE RegisterLogHandler( 
      /* [in] */ int logLevel,
      /* [in] */ ILogHandler __RPC_FAR *handler);
  
  virtual HRESULT STDMETHODCALLTYPE UnregisterLogHandler( 
      /* [in] */ int logLevel,
      /* [in] */ ILogHandler __RPC_FAR *handler);
};

#endif // !defined(AFX_STANDARDLOGDISPATCH_H__F1F98169_D95B_41D8_A0F1_289B148F299F__INCLUDED_)
