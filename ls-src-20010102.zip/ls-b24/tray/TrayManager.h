/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef TRAYMANAGER
#define TRAYMANAGER

#include <vector>
#include <string>

#define TRAYMANAGER_CLASS "Shell_TrayWnd"
#define TRAYMANAGER_TITLE "Litestep Tray Manager"

using namespace std;

// data sent by shell via Shell_NotifyIcon -- Maduin
typedef struct SHELLTRAYDATA {
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
} SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;

typedef vector<NOTIFYICONDATA> NID_vector;

class LSBar;

int initModuleEx(HWND, HINSTANCE, LPCTSTR);
void quitModule(HINSTANCE);

class TrayManager {
	HINSTANCE dll;

	HWND hTrayWnd;
	NID_vector trayWnds;
	BOOL dontReleaseIcons;
	HWND lsWindow;
	string lsPath;

public:
	~TrayManager();
	TrayManager(HWND, HINSTANCE, LPCSTR);

	static LRESULT CALLBACK WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	void addTrayInfo(NOTIFYICONDATA*);
	void removeTrayInfo(NOTIFYICONDATA*);
	BOOL SystrayMessage( PSHELLTRAYDATA pstd );
	void modifyTrayInfo(NOTIFYICONDATA *data);
private:
	void restoreTrayIcons(void *src);
	void saveTrayIcons(void *dest);
};

#endif //!defined TRAYMANAGER