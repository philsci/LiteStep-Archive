/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_POPUPMENU_H__D5612513_732D_11D2_B69F_00C0DF466974__INCLUDED_)
#define AFX_POPUPMENU_H__D5612513_732D_11D2_B69F_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>

#define HIDE_CHILDREN 1
#define HIDE_THIS 0
#define HIDE_PARENTS  -1

#define ALIGN_LEFT 1
#define ALIGN_TOP 1
#define ALIGN_CENTER 0
#define ALIGN_RIGHT -1
#define ALIGN_BOTTOM -1

using namespace std;
class MenuItem;
typedef vector<MenuItem*>::iterator MENUITERATOR;

/**
PopupMenu is a class that contains a set of MenuItems. This class manages
the underlying system window that is used to render the menuitems.
*/
class PopupMenu  
{
public:
	/**
	Constructs a new object

	@param hInstance the instance to this process
	*/
	PopupMenu(HINSTANCE hInstance);

	/**
	Destroys the popup menu
	*/
	virtual ~PopupMenu();

	/**
	Displays the popup at location (x, y) with the given alignment
	*/
	void Show(int x, int y, int nAlignX, int nAlignY);

	/**
	displays the popup with upper left corners at
	
	@param x location on the screen
	@param y location on the screen
	*/
	void Show(int x, int y);

	/// Displays the popup at a location that the popup consider to be reasonable
	void Show();

	/**
	Adds the MenuItem m to the popup menu. PopupMenu will free the object when
	it is no longer needed

	@param m pointer to a menuitem object to be added
	*/
	void AddMenuItem(MenuItem* m);

	// sorted add
	void AddMenuItem(MenuItem *m, bool (*pfnSort)(void *, MenuItem *, MenuItem *), void *pvSortParam);

	/**
	Deletes the entire list of menu items, and deletes the objects that it
	referes to
	*/
	void DeleteMenuItems();

	/**
	Returns TRUE if this popupmenu is a pinned state

	@return if the popup is pinned
	*/
	bool IsPinned(){return m_bPinned;};

	/**
	Sets the pinned state of the popup

	@param bPinned TRUE to set pinned, FALSE to unpinn
	*/
	void SetPinned(bool bPinned){m_bPinned = bPinned;};

	// the popup should be pinned when it is shown
	void SetPinnedOnShow(bool bPinnedOnShow) { m_bPinnedOnShow = bPinnedOnShow; }

	// Hides the popup menu
	// 1. this and all below this
	// 2. this and all above this
	// 3. only this popupmenu
	void Hide(int h);

	/**
	Returns the associated window

	@return handle to the associated window
	*/
	HWND GetWindow();

	/// Calls paint on each menu item
	void Paint();

	/// Calls the key pressed on each menu item
	void Key(int nKey);

	/// calls mouse message on each menu item
	void Mouse(int nMsg, int x, int y);

	/// this window is activated or de-activated
	void Activate(int fActive, HWND hWnd);

	/// timer message has been sent to this window
	void Time(int nTimer);

	/// nc-hit test has been sent to this window
	LRESULT  NcHitTest(int x, int y);

	/// WM_COMMAND has been sent...
	LRESULT Command(WPARAM wParam, LPARAM lParam);

	/**
	paints a bevel around the popupmenu

	@param hDC handle to a device context on which the bevel is painted
	*/
	void PaintBevel(HDC hDC);

	/**
	Sets the parent menu of this menu

	@param pParent PopupMenu pointer pointing at the parent object
	*/
	void SetParent(PopupMenu* pParent);

	/**
	Adds a child popup menu to this menu

	@param pChild PopupMenu pinter pointing at the child object
	*/
	void AddChild(PopupMenu* pChild);

	/**
	Removes a popupmenu from the vector of children

	@param pChild pointer to the popupmenu object to be removed
	*/
	void RemoveChild(PopupMenu* pChild);

	/**
	Returns the parent object of this popupmenu

	@return Returns the parent popupmenu object, NULL if there is no parent object
	*/
	PopupMenu* GetParent();

	// the user is moving the popupmenu about
	void Moving();

	BOOL IsActive();

	static void DrawBevel(BOOL bBevel){m_bPopupMenuBevel = bBevel;};
	static void SetDark(DWORD nColor) {m_nDarkColor = nColor;};
	static void SetLight(DWORD nColor) {m_nLightColor = nColor;};
	static void SetMaxWidth(int nMaxWidth){m_nMaxWidth = nMaxWidth;};
	static void SetMinWidth(int nMinWidth){m_nMinWidth = nMinWidth;};
	static void SetScrollSpeed(int nScrollSpeed){m_nScrollSpeed = nScrollSpeed;};

	/// retrieve/set bang command name associated with this popup menu
	const char *GetBangName();
	void SetBangName(const char *pszBangName);

	/// Sorts the menuitems in this menu
	void Sort();

	/// validate the width and transparency of this menu
	void Validate();

	/// do actuallly validate next time validate is called
	void Invalidate();
	
	/// Called when the mouse leaves the menu
	void MouseLeave();

	/// Respond to the WM_SHOWWINDOW message
	virtual void OnShow(BOOL fShow) { }

	/// Respond to the WM_TIMER message
	virtual void OnTimer(int nTimer) { }

	/// Respond to messages in the WM_USER range
	virtual BOOL OnUser(int nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult);

protected:	
	/**
	Utility method used to find and deactivate the currently selected menu item

	@param pMenuIterator will upon return point at the deselected menu item
	@return TRUE if one was deselected, FALSE otherwuse
	*/
	BOOL FindActiveAndDeactivate(MENUITERATOR* pMenuIterator);

	/** 
	utility method that reutrns TRUE if hWnd is a children of this menue

	@param hWnd the window to be checked
	@return TRUE if hWnd is a children, FALSE otherwise
	*/
	BOOL IsChildWindow(HWND hWnd);

	/// timer callback used to monitor the position of the mouse
	static void CALLBACK TrackMouseProc(HWND hWnd,UINT uMsg,UINT idEvent,DWORD dwTime);

	/// TRUE if the menu is validated for size and transparency, FALSE otherwise
	BOOL m_bValidated;

	/// The string title of the popupmenu
	char* m_pszTitle;

	/// Handle to the window that is the popup menu
	HWND m_hWnd;

	/// The parent popup menu. The root popup menue does not have any parent.
	PopupMenu* m_pParent;

	/// a vector of pointers to children menues
	vector<PopupMenu*> m_Children;

	/// A vector of menuitems that is associated with this popup menu
	vector<MenuItem*> m_MenuItems;

	/// handle to the instace of this process
	HINSTANCE m_hInstance;

	/// Scroll speed when popup is out of the screen.
	static int m_nScrollSpeed;

	/// maximal width of popupmenues
	static int m_nMaxWidth;

	/// minimun allowed width of popupmenues
	static int m_nMinWidth;

	/// if the bevel shall be rendered
	static BOOL m_bPopupMenuBevel;

	/// color that shall be used to render the dark areas of bevels
	static DWORD m_nDarkColor;

	/// color that shall be used to render the light areas of bevels
	static DWORD m_nLightColor;

	/// the number of popupmenu objects loaded
	static int m_nInstances;

	/// if the mouse is currently over this window
	bool m_bMouseOver;

	/// if this popupmenu is pinned or not
	bool m_bPinned;

	/// should this popup be pinned when it is shown?
	bool m_bPinnedOnShow;

	/// bang command name for this popup menu
	char *m_pszBangName;
};

#endif // !defined(AFX_POPUPMENU_H__D5612513_732D_11D2_B69F_00C0DF466974__INCLUDED_)
