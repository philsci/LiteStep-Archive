/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "RemoteAmpItem.h"
#include "MenuItem.h"

// WINAMP 
#define WA_CLASS	 "Winamp v1.x"
#define WA_LPARAM    WM_COMMAND
#define WA_PREVIOUS  40044
#define WA_PLAY      40045 
#define WA_PAUSE     40046
#define WA_STOP      40047 
#define WA_NEXT      40048 

// APOLLO 
#define AP_CLASS	 "Apollo - Main Window"
#define AP_LPARAM    (WM_USER+3)
#define AP_PREVIOUS  10
#define AP_PLAY      12
#define AP_PAUSE     13
#define AP_STOP      11
#define AP_NEXT      14

// KJOFOL 
#define KJ_CLASS     "KJofolMainWindow"
#define KJ_LPARAM    WM_COMMAND
#define KJ_PLAY      0x08 
#define KJ_STOP      0x04
#define KJ_PAUSE     0x0C
#define KJ_NEXT      0x12
#define KJ_PREVIOUS  0x11

RemoteControl RemoteControls[] = 
{
	{WA_CLASS, WA_LPARAM, WA_PREVIOUS, WA_PLAY, WA_PAUSE, WA_STOP, WA_NEXT},
	{AP_CLASS, AP_LPARAM, AP_PREVIOUS, AP_PLAY, AP_PAUSE, AP_STOP, AP_NEXT},
	{KJ_CLASS, KJ_LPARAM, KJ_PREVIOUS, KJ_PLAY, KJ_PAUSE, KJ_STOP, KJ_NEXT},
	{NULL,     0,         0,           0,       0,        0,       0      }
};

RemoteAmpItem::RemoteAmpItem()
{
	m_nWidth = 110;
}

RemoteAmpItem::~RemoteAmpItem()
{

}

void RemoteAmpItem::Mouse(int nMsg, int x, int y)
{
	HWND hAmp;
	POINT p;
	WPARAM wParam=0;
	BOOL bFinished=FALSE;

	if(nMsg != WM_LBUTTONUP)
		return;

	if(!IsOver(x, y))
		return;

	p.x = x;
	p.y = y;

	for(int i=0; RemoteControls[i].pszClassName != NULL && !bFinished; i++)
	{
		hAmp = FindWindow(RemoteControls[i].pszClassName, NULL);
		if(hAmp != NULL)
		{
			if(PtInRect(&m_Button1, p))
				wParam = RemoteControls[i].nPrevious;
			else if(PtInRect(&m_Button2, p))
				wParam = RemoteControls[i].nPlay;
			else if(PtInRect(&m_Button3, p))
				wParam = RemoteControls[i].nPause;
			else if(PtInRect(&m_Button4, p))
				wParam = RemoteControls[i].nStop;
			else if(PtInRect(&m_Button5, p))
				wParam = RemoteControls[i].nNext;
			PostMessage(hAmp, RemoteControls[i].lParam, wParam, 0);
			bFinished=TRUE;
		}
	}
}


void RemoteAmpItem::SetPosition(int nLeft, int nTop)
{
	int w;

	MenuItem::SetPosition(nLeft, nTop);

	w = GetWidth() / 5; // width of each button

	m_Button1.left = 0;
	m_Button1.top = m_nTop;
	m_Button1.right = w;
	m_Button1.bottom = m_Button1.top + GetHeight();

	m_Button2.left = m_Button1.right;
	m_Button2.top = m_nTop;
	m_Button2.right = m_Button1.right + w;
	m_Button2.bottom = m_Button2.top + GetHeight();

	m_Button3.left = m_Button2.right;
	m_Button3.top = m_nTop;
	m_Button3.right = m_Button2.right + w;
	m_Button3.bottom = m_Button3.top + GetHeight();

	m_Button4.left = m_Button3.right;
	m_Button4.top = m_nTop;
	m_Button4.right = m_Button3.right + w;
	m_Button4.bottom = m_Button4.top + GetHeight();

	m_Button5.left = m_Button4.right;
	m_Button5.top = m_nTop;
	m_Button5.right = m_Button4.right + w;
	m_Button5.bottom = m_Button5.top + GetHeight();
}