/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
12/06/00 - Bobby G. Vinyard
  - Modified !PopupRun to use the mru class in lsapi\, it now shares
    the same mru run list as command.dll  
11/25/00 - Bobby G. Vinyard (Message)
  - Fixed drop files to inclose a path in qoutes if it included spaces
****************************************************************************/
#include "stdafx.h"
#include "RunItem.h"
#include "PopupMenu.h"
#include "Painter.h"

#include <shlwapi.h>

#define ID_EDITCHILD 3578
 
WNDPROC pEditWndProc;
LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL RunItem::m_bRememberLast = FALSE;

RunItem::RunItem(char* pszTitle) : CommandItem(NULL,NULL,pszTitle)
{
	m_hEdit=NULL;
	// initialize the history to zero.
	//ZeroMemory(m_ppszHistory, MAX_POPRUN_HISTORY*MAX_POPRUN_STRING);
}

RunItem::~RunItem()
{
	if(IsWindow(m_hEdit)) DestroyWindow(m_hEdit);
	m_hEdit = NULL;
}

void RunItem::Attached(PopupMenu* pMenu)
{
	CommandItem::Attached(pMenu);
	
	HWND hParent = pMenu->GetWindow();
	// Create an edit box
	m_hEdit = CreateWindow("EDIT", NULL, WS_CHILD | ES_LEFT | ES_AUTOHSCROLL, 
							0,0,0,0, hParent, (HMENU) ID_EDITCHILD, 
							(HINSTANCE) GetWindowLong(hParent, GWL_HINSTANCE), 
							NULL);
	
	DragAcceptFiles(m_hEdit, TRUE);

	// subclass, to enable us to receive the IDOK that are rightfullt ours
	pEditWndProc = (WNDPROC)GetWindowLong(m_hEdit, GWL_WNDPROC); 
    SetWindowLong(m_hEdit, GWL_WNDPROC, (LONG)EditSubclass); 

	SendMessage(m_hEdit, WM_SETFONT,(WPARAM)m_pBackground->GetFont(),MAKELPARAM(FALSE, 0));
	
}

void RunItem::SetPosition(int nLeft, int nTop)
{
	SIZE size;
	HDC hDC;

	CommandItem::SetPosition(nLeft, nTop);

	// Get the width of the title
	hDC = GetDC(GetWindow());
	GetTextExtentPoint32(hDC, GetTitle(), lstrlen(GetTitle()), &size);
	ReleaseDC(GetWindow(), hDC);

	SetWindowPos(m_hEdit, 0, size.cx+GetIndent(), m_nTop, GetWidth()-size.cx-5, GetHeight(), 0);
}

LRESULT RunItem::Command(WPARAM wParam, LPARAM lParam)
{
	switch(wParam)
	{
	// EXECUTE
	case IDOK:
		{
			char pszCmd[MAX_PATH];

			GetWindowText(m_hEdit, pszCmd, sizeof(pszCmd));

			// trim the string
			PathRemoveBlanks(pszCmd);

      if ((int)LSExecute(GetParent(m_hEdit), pszCmd, SW_SHOWNORMAL) > 32)
      {
			  mruList.Add((LPCSTR)pszCmd);
      }

			Active(FALSE);

			if(!m_bRememberLast)
				SetWindowText(m_hEdit, "");
			break;
		}
	// HISTORY PREVIOUS
	case VK_UP:
		{
      char buffer[MAX_LINE_LENGTH];
			mruList.Previous(buffer, sizeof(buffer));
			SetWindowText(m_hEdit, buffer);
			CallWindowProc(pEditWndProc, m_hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
	// HISTORY NEXT
	case VK_DOWN:
		{
      char buffer[MAX_LINE_LENGTH];
			mruList.Next(buffer, sizeof(buffer));			
			SetWindowText(m_hEdit, buffer);
      CallWindowProc(pEditWndProc, m_hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
	}

	return 1;
}

void RunItem::Invoke()
{
	SetFocus(m_hEdit);
	ShowWindow(m_hEdit, SW_SHOW);
	SetCapture(m_hEdit);
}

BOOL RunItem::Active(BOOL bActive)
{
	ShowWindow(m_hEdit, bActive ? SW_SHOW : SW_HIDE);
	if(IsActive() != bActive)
		ReleaseCapture();

	return CommandItem::Active(bActive);
}

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static char pszPattern[MAX_PATH] = {'\0'};
	static HANDLE handle;
	static WIN32_FIND_DATA found;
	BOOL bContinue;

	if(uMsg == WM_KEYDOWN)
	{
		switch(wParam)
		{
		case VK_RETURN:
			PostMessage(GetParent(hwnd), WM_COMMAND, IDOK, NULL);
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_ESCAPE:
			ShowWindow(hwnd, SW_HIDE);
			SetFocus(GetParent(hwnd));
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_TAB:
		case VK_F2: 
			// Auto completion

			if(lstrlen(pszPattern) == 0)
			{
				GetWindowText(hwnd, pszPattern, sizeof(pszPattern));
				strcat(pszPattern, "*");
				handle = FindFirstFile(pszPattern, &found);
				bContinue = (handle != INVALID_HANDLE_VALUE);

				// ignore the . and .. directories
				while(bContinue && (lstrcmp(found.cFileName, ".") == 0 || (lstrcmp(found.cFileName, "..") == 0)))
					bContinue = FindNextFile(handle, &found);
			}
			else
			{
				bContinue = (FindNextFile(handle, &found) != 0);
			}

			// if the last search did find some file then update
			// the editbox
			if(bContinue)
			{
				char path_buffer[_MAX_PATH];
				char drive[_MAX_DRIVE];
				char dir[_MAX_DIR];

				_splitpath(pszPattern, drive, dir, NULL, NULL);
				_makepath(path_buffer, drive, dir, found.cFileName, NULL);
				SetWindowText(hwnd, path_buffer);

				// move the cursor to the end of the line
				CallWindowProc(pEditWndProc, hwnd, WM_KEYDOWN, VK_END, 0);
			}
			else
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_UP:
		case VK_DOWN:
			PostMessage(GetParent(hwnd), WM_COMMAND, wParam, NULL);
			break;
		default:
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		}
	}

	if(uMsg == WM_DROPFILES)
	{
    UINT uSize = DragQueryFile((HDROP)wParam, 0, NULL, 0);
    char* szFileName = new char[uSize + 10];
    DragQueryFile((HDROP)wParam, 0, szFileName, uSize + 1);
    if (strchr(szFileName, ' ') != NULL)
    {
      char* szQoutedPath = new char[uSize + 3];
      sprintf(szQoutedPath, "\"%s\"", szFileName);
      SetWindowText(hwnd, szQoutedPath);
      delete [] szQoutedPath;
    }
    else
    {
      SetWindowText(hwnd, szFileName);
    }
    delete [] szFileName;
    SetFocus(hwnd);
    DragFinish((HDROP)wParam);
	}

	return CallWindowProc(pEditWndProc, hwnd, uMsg, wParam, lParam);
}

