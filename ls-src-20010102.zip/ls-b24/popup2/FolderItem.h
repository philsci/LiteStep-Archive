/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_FOLDERITEM_H__D5612515_732D_11D2_B69F_00C0DF466974__INCLUDED_)
#define AFX_FOLDERITEM_H__D5612515_732D_11D2_B69F_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TitleItem.h"

#define FOLDER_LEFT 0
#define FOLDER_RIGHT 1

class PopupMenu;

/**
An menuitem that is a pointer to a sub menu, theese folder items
typically contain a |> icon at their right side.
*/
class FolderItem : public TitleItem
{
public:
	/**
	Constructs a FolderItem object

	@param pSubMenu pointer to the submenu that is assocuiated with this folder
	@param bDrawArrow should the arrow pointer be painted
	@param pszTitle the title text
	*/
	FolderItem(PopupMenu* pSubMenu, char* pszTitle);

	/// destrous the folderitem object
	virtual ~FolderItem();

	/**
	Paints the folder item, the parent class will paint first
	the will we add the |> icon

	@param hDC the devicecontec that is used for painting
	*/
	void Paint(HDC hDC);

	/**
	Notifies this object that is has been attached to a PopupMenu

	@param pMenu pointer to the popupmenu object
	*/
	void Attached(PopupMenu* pMenu);

	/**
	Activate or deactivate this object

	@param bActivate is this item active
	@return returns the activation state of this item (not all items accept
	        to be activates)
	*/
	BOOL Active(BOOL bActivate);

	/**
	Handles keypresses

	@param nKey the key that was presses
	*/
	BOOL Key(int nKey);

	/**
	Activates this folderitem
	*/
	void Invoke();

	/**
	Handles timer messages, the folder uses timers to wait before the submenues
	are opened

	@param nTimer the identity of the timer
	*/
	void Timer(int nTimer);

  /**
  Returns whether the item is a leaf or a node
  */
  virtual inline BOOL IsLeaf(){return FALSE;};

	/**
	Sets how much submenues should overlap their parents

	@param x overlap in pixels in x direction
	@param y overlap in pixels in y direction
	*/
	static void SetOverlap(int x, int y){m_nOverlapX=x; m_nOverlapY=y;};

	/**
	Sets the number of millisecods that the folder waits from it is activated
	before it opens it's submenu

	@param nDelay the number of milliseconds to wait
	*/
	static void SetDelay(int nDelay){m_nDelay=nDelay;};


	static void SetDrawArrow(BOOL bDrawArrow){m_bDrawArrow = bDrawArrow;};

//	virtual void UpdateFolder();
protected:

	/// the current timer id, this is 0 if the folder is not currently waiting
	UINT m_nTimerId;

	/// displays the submenu at some reasonable position
	void ShowSubMenu();	

	/// Returns a rect containing the title
	void GetTitleRect(RECT* r);

	/// utility method for painting the |> icon
	void PaintArrow(HDC hDC, int totalHeight);

	/// Pointer at submenu
	PopupMenu* m_pSubMenu;

	/// Indicated weather or not the folder arrow thing should be painted or not
	static BOOL m_bDrawArrow;

	/// contains the horizontal overlap
	static int m_nOverlapX;

	/// contains the vertical overlap
	static int m_nOverlapY;

	/// contains the number of milliseconds to wait
	static int m_nDelay;
};

#endif // !defined(AFX_FOLDERITEM_H__D5612515_732D_11D2_B69F_00C0DF466974__INCLUDED_)
