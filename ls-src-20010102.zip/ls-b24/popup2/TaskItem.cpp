/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "TaskItem.h"
#include "PopupMenu.h"
#include "../lsapi/lsapi.h"

BOOL TaskItem::m_bWindowCaption = FALSE;
FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

TaskItem::TaskItem(HWND hWnd) : CommandItem(NULL, NULL, NULL)
{
	char pszWindowText[1024];
	GetWindowText(hWnd, pszWindowText, sizeof(pszWindowText));
	m_pszTitle = pszWindowText != NULL ? strdup(pszWindowText) : NULL;
	m_hWnd = hWnd;

	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
}

TaskItem::~TaskItem()
{
	// do not destroy the icon!
	m_hIcon = NULL;

	if(m_pszTitle) free(m_pszTitle);
	m_pszTitle = NULL;
}

void TaskItem::Invoke()
{
	m_pParent->Hide(HIDE_PARENTS);

	if(SwitchToThisWindow){
		if (IsIconic(m_hWnd)) 
			SwitchToThisWindow(m_hWnd, TRUE);
		else
			if(!SendMessage(GetLitestepWnd(), LM_BRINGTOFRONT, 0, (LPARAM)m_hWnd))
				SwitchToThisWindow(m_hWnd, TRUE);
	}
}

void TaskItem::Mouse(int nMsg, int x, int y)
{
	if(nMsg == WM_RBUTTONUP) 
	{
		RECT r;
		POINT p;
		p.x = x;
		p.y = y;
		GetItemRect(&r);

		if(PtInRect(&r, p))
		{
			SetWindowPos(m_hWnd, NULL, 50, 50, 0, 0, SWP_NOSIZE);
			Invoke();
		}
	}

	CommandItem::Mouse(nMsg, x, y);
}

void TaskItem::Paint(HDC hDC)
{
	if(m_bWindowCaption)
	{
		RECT r;
		GetItemRect(&r);

		if(m_bActive)
			DrawCaption(m_hWnd, hDC, &r, DC_ACTIVE|DC_ICON|DC_TEXT);
		else
			DrawCaption(m_hWnd, hDC, &r, DC_ICON|DC_TEXT);

		if(m_bDrawBevel)
			PaintBevel(hDC, m_nTop);
	}
	else
	{
		CommandItem::Paint(hDC);
	}

}