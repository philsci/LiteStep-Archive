/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// TimeItem.h: interface for the TimeItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEITEM_H__5CAE4534_748B_11D2_B6A1_00C0DF466974__INCLUDED_)
#define AFX_TIMEITEM_H__5CAE4534_748B_11D2_B6A1_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MenuItem.h"

// A menuitem that contains the current time
class TimeItem : public MenuItem  
{
public:
	TimeItem(int nAlign, char* pszFormat);
	virtual ~TimeItem();

	void Paint(HDC hDC);
	void Attached(PopupMenu* pMenu);
	void Timer(int nTimer);

	// Starts the system time settings applet
	void Invoke();

	BOOL Active(BOOL bActive);

protected:

	// DateTime items cannot have icons
	BOOL ShouldPaintIcon() { return FALSE; }

	void MergeInternetTime(char* pszTime, int nTime);

	UINT m_nTimer;
	int m_nAlign;
	char* m_pszFormat;
};

#endif // !defined(AFX_TIMEITEM_H__5CAE4534_748B_11D2_B6A1_00C0DF466974__INCLUDED_)
