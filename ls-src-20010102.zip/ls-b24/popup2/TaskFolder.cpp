/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "TaskFolder.h"
#include "PopupMenu.h"
#include "PopupMaker.h"

#include "HeaderItem.h"
#include "TaskItem.h"
#include "SeparatorItem.h"

#include "Re5ources.h"

BOOL CALLBACK TaskFolderEnumWindowsProc(HWND hwnd,LPARAM lParam);
#define TASK_FOLDER_TIMER 4434

TaskFolder::TaskFolder(PopupMaker* pPopupMaker, char* pszTitle) :
	FolderItem(NULL, pszTitle)
{
	m_pPopupMaker = pPopupMaker;
	m_nTimer = 0;
}

TaskFolder::~TaskFolder()
{
	if(m_pSubMenu) delete m_pSubMenu;
	m_pSubMenu = NULL;

	//if(m_nTimer) KillTimer(GetWindow
}

BOOL TaskFolder::Active(BOOL bActivate)
{
	if(bActivate && !m_bActive)
	{
		UpdateFolder();
		//m_nTimer = SetTimer(GetWindow(), TASK_FOLDER_TIMER, 1000, NULL);
/*		// remove the old items
		m_pSubMenu->DeleteMenuItems();

		// add a title
		m_pPopupMaker->AddHeaderItem(m_pSubMenu, GetTitle(), FALSE);

		// add the contents
		EnumWindows(TaskFolderEnumWindowsProc, (LPARAM)this);

		// add the footer
		m_pPopupMaker->AddBottomItem(m_pSubMenu);

		// fix the layout
		m_pSubMenu->Sort();
		m_pSubMenu->Invalidate();
		m_pSubMenu->Validate();*/
	}

	return FolderItem::Active(bActivate);
}

void TaskFolder::AddWindow(HWND hWnd)
{	
	MenuItem* pMenu = new TaskItem(hWnd);
	pMenu->SetHeight(m_pPopupMaker->m_nSubmenuHeight);
	pMenu->SetPainter(m_pPopupMaker->m_pEntry);
	pMenu->SetActivePainter(m_pPopupMaker->m_pSelEntry);

	if(m_pPopupMaker->m_bIcons)
		pMenu->SetIcon(GetIconFromWindow(hWnd, FALSE));
	m_pSubMenu->AddMenuItem(pMenu);
}

void TaskFolder::Attached(PopupMenu* pMenu)
{
	m_pParent = pMenu;
	m_pSubMenu = new PopupMenu(m_pPopupMaker->hInst);
	m_pParent->AddChild(m_pSubMenu);
	m_pSubMenu->SetParent(m_pParent);

	SetTimer(GetWindow(), TASK_FOLDER_TIMER, 2000, NULL);
}

void TaskFolder::Timer(int nTimer)
{
	FolderItem::Timer(nTimer);

	if(nTimer == TASK_FOLDER_TIMER && IsWindowVisible(m_pSubMenu->GetWindow()))
	{
		UpdateFolder();
//		RedrawWindow(GetWindow(), NULL, NULL, RDW_INVALIDATE);
	}
}

void TaskFolder::UpdateFolder()
{
	// remove the old items
	m_pSubMenu->DeleteMenuItems();

	// add a title
	m_pPopupMaker->AddHeaderItem(m_pSubMenu, GetTitle(), FALSE);

	// add the contents
	EnumWindows(TaskFolderEnumWindowsProc, (LPARAM)this);

	// add the footer
	m_pPopupMaker->AddBottomItem(m_pSubMenu);

	// fix the layout
	m_pSubMenu->Sort();
	m_pSubMenu->Invalidate();
	m_pSubMenu->Validate();
}

BOOL CALLBACK TaskFolderEnumWindowsProc(HWND hwnd,LPARAM lParam)
{
	if(IsAppWindow(hwnd))
	{
		TaskFolder* pT = (TaskFolder*)lParam;
		pT->AddWindow(hwnd);
	}

	return TRUE;
}
