/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "../lsapi/lsapi.h"

#include "PopupMaker.h"
#include "DesktopMenuItem.h"
#include "DesktopMenu.h"

DesktopMenu::DesktopMenu(const char *pszTitle, PopupMaker *pPopupMaker)
	: PopupMenu(pPopupMaker->hInst)
{
	m_pPopupMaker = pPopupMaker;
	m_pszTitle = pszTitle ? strdup(pszTitle) : 0;
}

DesktopMenu::~DesktopMenu()
{
	if(m_pszTitle)
		free(m_pszTitle);
}

void DesktopMenu::OnShow(BOOL fShow)
{
	if(fShow)
		UpdateFolder();
}

BOOL DesktopMenu::OnUser(int nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	if(nMessage == LM_DESKTOPINFO)
	{
		LSDESKTOPINFO *pDesktopInfo = (LSDESKTOPINFO *) lParam;
		DesktopMenuItem *item = new DesktopMenuItem(pDesktopInfo->name,
			m_pPopupMaker, pDesktopInfo->number);

		item->SetActivePainter(m_pPopupMaker->m_pSelEntry);
		item->SetPainter(m_pPopupMaker->m_pEntry);
		item->SetHeight(m_pPopupMaker->m_nSubmenuHeight);
		
		if(m_pPopupMaker->m_bIcons && pDesktopInfo->icon)
			item->SetIcon(CopyIcon(pDesktopInfo->icon));

		AddMenuItem(item);
		return TRUE;
	}

	return PopupMenu::OnUser(nMessage, wParam, lParam, lResult);
}

void DesktopMenu::UpdateFolder()
{
	DeleteMenuItems();

	m_pPopupMaker->AddHeaderItem(this, m_pszTitle, FALSE);
	SendMessage(GetLitestepWnd(), LM_LISTDESKTOPS, (WPARAM) GetWindow(), 0);
	m_pPopupMaker->AddBottomItem(this);

	Invalidate();
	Validate();
}
