//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by popup2.rc
//
#define IDS_POPUP_HOTLISTNAME           1
#define IDS_POPUP_RUN                   2
#define IDS_POPUP_TASKS                 3
#define IDS_POPUP_LOADING               4
#define IDS_POPUP_EMPTY                 5
#define IDS_POPUP_DESKTOPS              6

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
