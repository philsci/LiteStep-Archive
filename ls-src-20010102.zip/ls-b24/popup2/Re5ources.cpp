/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include "../lsapi/macros.h"
#include "Re5ources.h"

HINSTANCE g_hResStrInstance = NULL;
TCHAR g_szResStrBuffer[MAX_PATH];

HICON GetIconFromPath(const char* pszPath)
{
	SHFILEINFO shFileInfo;
	char pszFileName[MAX_PATH];
	_searchenv(pszPath, "PATH", pszFileName);
	SHGetFileInfo(pszFileName, NULL, &shFileInfo, sizeof(shFileInfo), SHGFI_ICON | SHGFI_SMALLICON);

	if(strlen(pszFileName) == 0)
	{
		char pszGuess[MAX_PATH];
		// well... guess that the user has an exe in mind ..
		strcpy(pszGuess, pszPath);
		strcat(pszGuess, ".exe");
		_searchenv(pszGuess, "PATH", pszFileName);
		SHGetFileInfo(pszFileName, NULL, &shFileInfo, sizeof(shFileInfo), SHGFI_ICON | SHGFI_SMALLICON);
	} 
	return shFileInfo.hIcon;
}

HICON GetIconFromWindow(HWND hWnd, BOOL bBigIcon)
{
	HICON hIcon = NULL;

	if( bBigIcon )
	{
		SendMessageTimeout(hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) hIcon = (HICON) GetClassLong(hWnd, GCL_HICON);
		if(!hIcon) SendMessageTimeout(hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) SendMessageTimeout(hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) hIcon = (HICON) GetClassLong(hWnd, GCL_HICONSM);
	}
	else
	{
		SendMessageTimeout(hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) hIcon = (HICON) GetClassLong(hWnd, GCL_HICONSM);
		if(!hIcon) SendMessageTimeout(hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) SendMessageTimeout(hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon);
		if(!hIcon) hIcon = (HICON) GetClassLong(hWnd, GCL_HICON);
	}

	return hIcon;
}

BOOL IsAppWindow(HWND hWnd)
{
	BOOL bResult = TRUE;
	LONG nStyle;
	HWND hOwner;
	HWND hParent;

	// if it is a WS_CHILD or not WS_VISIBLE, fail it
	nStyle = GetWindowLong(hWnd, GWL_STYLE);	
	if((nStyle & WS_CHILD) || !(nStyle & WS_VISIBLE))
		bResult = FALSE;

	// if the window is a WS_EX_TOOLWINDOW fail it
	nStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
	if(nStyle & WS_EX_TOOLWINDOW)
		bResult = FALSE;

	// If this has an owner, then only accept this window
	// if the partent is not accepted
	hOwner = GetWindow(hWnd, GW_OWNER);
	if(hOwner && bResult)
		bResult = !IsAppWindow(hOwner);

	// if it has a parent, fail
	hParent = GetParent(hWnd);
	if(hParent)
		bResult = FALSE;

	if(GetWindowLong(hWnd, GWL_USERDATA) == 0x49474541)
		bResult = FALSE;

	return bResult;
}

int GetInetTime(long now)
{
	// and one hour to get GMT+1 (swizz based time :)
	long nDawn = now + 3600; 

	// get number of seconds since midnight
	long nSeconds = nDawn % 86400; 

	// convert the number of seconds to a number 0..1000
	int nInetTime = (int)(nSeconds / 86.4);

	// account for possible overlapp
	if(nInetTime >= 1000)
		nInetTime = 0;
	return nInetTime;
}

void SnappWindow(WINDOWPOS* pwPos, int nDist, BOOL bUseScreenSize)
{
	RECT workArea;
	int nTemp;

	if(bUseScreenSize)
	{
		ZeroMemory(&workArea, sizeof(workArea));
		workArea.right = SCREEN_WIDTH;
		workArea.bottom = SCREEN_HEIGHT;
	}
	else
	{
		SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);
	}

	// left edge
	nTemp = pwPos->x;
	if(nTemp < nDist && nTemp > -nDist)
		pwPos->x = 0;

	// top edge
	nTemp = pwPos->y;
	if(nTemp < nDist && nTemp > -nDist)
		pwPos->y = 0;

	// bottom edge
	nTemp =  workArea.bottom - (pwPos->y + pwPos->cy);
	if(nTemp < nDist && nTemp > -nDist)
		pwPos->y = workArea.bottom - pwPos->cy;

	// right edge
	nTemp = workArea.right - (pwPos->x + pwPos->cx);
	if(nTemp < nDist && nTemp > -nDist) 
		pwPos->x = workArea.right - pwPos->cx;
}

void TrimLeft( char *toTrim )
{
	char *trimmed = toTrim;

	// skip past spaces
	while( *toTrim && isspace( *toTrim ) )
		toTrim++;

	// copy the rest of the string over
	while( *toTrim )
		*trimmed++ = *toTrim++;

	// null-terminate it
	*trimmed = 0;
}

LPTSTR LoadStringInplace( HINSTANCE hInstance, UINT nID, LPTSTR pszBuffer, UINT nLength )
{
	LoadString( hInstance, nID, pszBuffer, nLength );
	return pszBuffer;
}
