/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
12/31/00 - Bobby G. Vinyard (Message)
  - Added CommandRememberPosition to allow the module to remember where it was
  last placed
  - Added !CommandResetPos to move the module back to the settings sepecified in
  the step.rc
12/20/00 - Bobby G. Vinyard (Message)
  - Fixed some problems with always on top
  - Added CommandNotMoveable, default is moveable
12/01/00 - Bobby G. Vinyard (Message)
  - Added CommandNotAlwaysOnTop, CommandSelectAllOnFocus
11/28/00 - Bobby G. Vinyard (Message)
  - Added multimonitor support
11/26/00 - Bobby G. Vinyard (Message)
  - Added CommandBevel to put a bevel around the command window
  - Added CommandBevelSize, CommandBevelLightColor, CommandBevelDarkColor
11/25/00 - Bobby G. Vinyard (Message)
  - Added !CommandFocus - will show the command window if it is hidden and 
    set focus in the edit control
  - Added response to LM_REFRESH & !Refresh
11/24/00 - Bobby G. Vinyard (Message)
  - Added !CommandShow, !CommandHide, !CommandToggle, CommandHideOnUnfocus,
    CommandHiddenOnStart, CommandNoClearOnCommand (these all function exactly
    like their lsxcommand counterparts)
11/24/00 - Bobby G. Vinyard (Message)
  - Fixed drop files to inclose a path in qoutes if it included spaces
****************************************************************************/
#include <stdio.h>
#include <malloc.h>
#include <tchar.h>

#include "command.h"
const char szAppName[] = "Command"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.1.2.16 $"; // Our Version
const char rcsId[] = "$Id: command.cpp,v 1.1.2.16 2000/12/31 06:29:15 message Exp $"; // The Full RCS ID.
Command *command; // The module

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam);
WNDPROC pEditWndProc;

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  
  Window::init(dllInst);
  
  command = new Command(ParentWnd, code);
  return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete command;
}


//=========================================================
// Bang commands
//=========================================================
void BangCommandMoveFunction(HWND caller, LPCSTR args) {
  command->BangCommandMove(caller, args);
}


void BangCommandToggleFunction(HWND caller, LPCSTR args) {
  command->BangCommandToggle(caller, args);
}

void BangCommandHideFunction(HWND caller, LPCSTR args) {
  command->BangCommandHide(caller, args);
}

void BangCommandShowFunction(HWND caller, LPCSTR args) {
  command->BangCommandShow(caller, args);
}

void BangCommandFocusFunction(HWND caller, LPCSTR args) {
  command->BangCommandFocus(caller, args);
}

void BangCommandResetPosFunction(HWND caller, LPCSTR args) {
  command->BangCommandResetPos(caller, args);
}
/*
TODO:
  Add Code for Bang Commands (i.e. void Bang(HWND caller, LPCSTR args)

*/

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Command::Command(HWND parentWnd, int& code):
Window(szAppName)
{

  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  setupCommand();
  if (!parentWnd)
  {
    parentWnd = FindWindow("DesktopBackgroundClass", NULL);
    if (!parentWnd)
    {
      parentWnd = GetDesktopWindow();
    }
  }

  if (!createWindow((isNotAlwaysOnTop ? 0 : WS_EX_TOPMOST)|WS_EX_TOOLWINDOW, 
    szAppName, 
    (isNotAlwaysOnTop ? WS_CHILD : WS_POPUP)|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
    xpos, ypos, width, height, 
    (isNotAlwaysOnTop ? parentWnd : NULL)))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  //AddBangCommand("!CommandMove",BangCommandMoveFunction);
  AddBangCommand("!CommandToggle",BangCommandToggleFunction);
  AddBangCommand("!CommandHide", BangCommandHideFunction);
  AddBangCommand("!CommandShow", BangCommandShowFunction);
  AddBangCommand("!CommandFocus", BangCommandFocusFunction);
  AddBangCommand("!CommandResetPos", BangCommandResetPosFunction);

  ShowWindow(hWnd, (isVisible) ? SW_SHOWNORMAL : SW_HIDE);

  UpdateWindow(hWnd);

  code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Command::~Command()
{

  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  //RemoveBangCommand("!CommandMove");
  RemoveBangCommand("!CommandToggle");
  RemoveBangCommand("!CommandHide");
  RemoveBangCommand("!CommandShow");
  RemoveBangCommand("!CommandFocus");
  RemoveBangCommand("!CommandResetPos");

  cleanCommand();

  if (rememberPosition)
  {
    char szKeyName[MAX_LINE_LENGTH];
    WINDOWPLACEMENT wpData;
    HKEY key;
    DWORD result;
    
    GetWindowPlacement(hWnd, &wpData);
    strcpy(szKeyName, "Software\\LiteStep\\");
    strcat(szKeyName, szAppName);

    if (RegCreateKeyEx(HKEY_CURRENT_USER, szKeyName, 0,
      NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &key, &result) == ERROR_SUCCESS)
    {
      //RegSetValueEx(key, "flags", 0, REG_DWORD, (LPBYTE)&wpData.flags, sizeof(DWORD));
      //RegSetValueEx(key, "ptMaxPosition.x", 0, REG_DWORD, (LPBYTE)&wpData.ptMaxPosition.x, sizeof(DWORD));
      //RegSetValueEx(key, "ptMaxPosition.y", 0, REG_DWORD, (LPBYTE)&wpData.ptMaxPosition.y, sizeof(DWORD));
      //RegSetValueEx(key, "ptMinPosition.x", 0, REG_DWORD, (LPBYTE)&wpData.ptMinPosition.x, sizeof(DWORD));
      //RegSetValueEx(key, "ptMinPosition.y", 0, REG_DWORD, (LPBYTE)&wpData.ptMinPosition.y, sizeof(DWORD));
      //RegSetValueEx(key, "showCmd", 0, REG_DWORD, (LPBYTE)&wpData.showCmd, sizeof(DWORD));
      RegSetValueEx(key, "bottom", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.bottom, sizeof(DWORD));
      RegSetValueEx(key, "left", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.left, sizeof(DWORD));
      RegSetValueEx(key, "right", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.right, sizeof(DWORD));
      RegSetValueEx(key, "top", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.top, sizeof(DWORD));
      RegCloseKey(key);
    }
  }

  destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Command::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,     WM_ENDSESSION)
    MESSAGE(onEndSession,     WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,       LM_GETREVID)
    MESSAGE(onSysCommand,     WM_SYSCOMMAND)
    MESSAGE(onCreate,         WM_CREATE)
    MESSAGE(onCtlColorEdit,   WM_CTLCOLOREDIT)
    MESSAGE(onSetFocus,       WM_SETFOCUS)
    MESSAGE(onNCHitTest,      WM_NCHITTEST)
    //MESSAGE(onPaint,          WM_MOUSEMOVE)
    MESSAGE(onEraseBkgnd,     WM_ERASEBKGND)
    MESSAGE(onCommand,        WM_COMMAND)
    MESSAGE(onKillFocus,      WM_USER+1)
    MESSAGE(onRefresh,        LM_REFRESH)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Command::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Command::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "command.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void Command::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Command::onCreate(Message& message) {

	hEdit = CreateWindowEx(0L, "EDIT", "", WS_CHILD | ES_LEFT | ES_AUTOHSCROLL, 
							borderSizeLeft, borderSizeTop,
              width - (borderSizeRight + borderSizeLeft),
              height - (borderSizeBottom + borderSizeTop), 
              hWnd, 0, hInstance, 0);

	DragAcceptFiles(hEdit, TRUE);

	pEditWndProc = (WNDPROC)SetWindowLong(hEdit, GWL_WNDPROC, (long)EditSubclass);

  SendMessage(hEdit, WM_SETFONT,(WPARAM)hFont, MAKELPARAM(FALSE, 0));

  ShowWindow(hEdit, SW_SHOW);
}


void Command::onCtlColorEdit(Message& message) {
  SetBkColor((HDC)message.wParam, colorBG);
  SetTextColor((HDC)message.wParam, colorText);
  message.lResult = (long)hBrush;
}


void Command::onSetFocus(Message& message) {
  if (selectAllOnFocus)
    SendMessage(hEdit, EM_SETSEL, 0, -1);
}


void Command::onNCHitTest(Message& message) {
  message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
  if (isMoveable)
  {
    if (message.lResult = HTCLIENT)
    {
      message.lResult = HTCAPTION;
    }
  }
}


void Command::onPaint(Message& message) {

}


void Command::onEraseBkgnd(Message &message) {
  HDC hDC;
  RECT rc;

  hDC = (HDC) message.wParam; 
  GetClientRect(hWnd, &rc);
  FillRect(hDC, &rc, hBorderBrush);

  if (hasBevel)
  {
    Frame3D(hDC, rc, bevelLightColor, bevelDarkColor, bevelSize);
  }
}


void Command::onCommand(Message &message) {
	switch(message.wParam)
	{
	case IDOK:
		{
			char pszCmd[MAX_PATH];

			GetWindowText(hEdit, pszCmd, sizeof(pszCmd));

			// trim the string
			PathRemoveBlanks(pszCmd);
      _LSDEBUG1(pszCmd);
      if ((int)LSExecute(hWnd, pszCmd, SW_SHOWNORMAL) > 32)
      {
			  mruList.Add((LPCSTR)pszCmd);
      }

			if(clearEditOnCommand)
				SetWindowText(hEdit, "");
			break;
		}
	// HISTORY PREVIOUS
	case VK_UP:
		{
      char buffer[MAX_LINE_LENGTH];
      _LSDEBUG1((int)strlen(buffer))
			mruList.Previous(buffer, sizeof(buffer));
			SetWindowText(hEdit, buffer);
      _LSDEBUG1("VK_UP - HISTORY PREVIOUS")
      _LSDEBUG1(buffer)
			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
	// HISTORY NEXT
	case VK_DOWN:
		{
      char buffer[MAX_LINE_LENGTH];
			mruList.Next(buffer, sizeof(buffer));			
			SetWindowText(hEdit, buffer);
      _LSDEBUG1("VK_DOWN - HISTORY NEXT")
      _LSDEBUG1(buffer)
			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
	}
}


void Command::onKillFocus(Message& message) {
  if (hideOnUnfocus && isVisible)
  {
    ShowWindow(hWnd, SW_HIDE);
    isVisible = (isVisible ? false : true);
  }
}

void Command::onRefresh(Message& message) {
  cleanCommand();
  setupCommand();
  SetWindowPos(hWnd, NULL, xpos, ypos, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
  SetWindowPos(hEdit, NULL, borderSizeLeft, borderSizeTop,
              width - (borderSizeRight + borderSizeLeft),
              height - (borderSizeBottom + borderSizeTop),
              SWP_NOZORDER | SWP_NOACTIVATE);
  SendMessage(hEdit, WM_SETFONT,(WPARAM)hFont, MAKELPARAM(FALSE, 0));
  ShowWindow(hWnd, (isVisible) ? SW_SHOWNORMAL : SW_HIDE);
  UpdateWindow(hWnd);
}
//=========================================================
// Bang command handling
//=========================================================
void Command::BangCommandMove(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
}


void Command::BangCommandToggle(HWND caller, LPCSTR args) {
  ShowWindow(hWnd, (!isVisible) ? SW_SHOWNORMAL : SW_HIDE);
  isVisible = (isVisible ? false : true);
}

void Command::BangCommandHide(HWND caller, LPCSTR args) {
  if (isVisible)
  {
    ShowWindow(hWnd, SW_HIDE);
    isVisible = false;
  }
}

void Command::BangCommandShow(HWND caller, LPCSTR args) {
  if (!isVisible)
  {
    ShowWindow(hWnd, SW_SHOWNORMAL);
    isVisible = true;
  }
}

void Command::BangCommandFocus(HWND caller, LPCSTR args) {
  if (!isVisible)
  {
    ShowWindow(hWnd, SW_SHOWNORMAL);
    isVisible = true;
  }
	SetForegroundWindow(hEdit);
	SetFocus(hEdit);
}

void Command::BangCommandResetPos(HWND caller, LPCSTR args) {
	width = GetRCInt("CommandWidth",160);
  height = GetRCInt("CommandHeight",20);
	xpos = GetRCInt("CommandX",0);
  xpos = CONVERT_COORDINATE_X(xpos);
	ypos = GetRCInt("CommandY",0);
  ypos = CONVERT_COORDINATE_Y(ypos);
  SetWindowPos(hWnd, NULL, xpos, ypos, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
  SetWindowPos(hEdit, NULL, borderSizeLeft, borderSizeTop,
              width - (borderSizeRight + borderSizeLeft),
              height - (borderSizeBottom + borderSizeTop),
              SWP_NOZORDER | SWP_NOACTIVATE);
}

void Command::setupCommand()
{
  char configLine[MAX_LINE_LENGTH];

	width = GetRCInt("CommandWidth",160);
  height = GetRCInt("CommandHeight",20);
	xpos = GetRCInt("CommandX",0);
  xpos = CONVERT_COORDINATE_X(xpos);
	ypos = GetRCInt("CommandY",0);
  ypos = CONVERT_COORDINATE_Y(ypos);
  borderSize = GetRCInt("CommandBorderSize", -1);
  if (borderSize == -1)
  {
    borderSizeBottom = GetRCInt("CommandBottomBorderSize",2);
    borderSizeTop = GetRCInt("CommandTopBorderSize",2);
    borderSizeLeft = GetRCInt("CommandLeftBorderSize",2);
    borderSizeRight = GetRCInt("CommandRightBorderSize",2);   
  }
  else
  {
    borderSizeBottom = borderSize;
    borderSizeTop = borderSize;
    borderSizeLeft = borderSize;
    borderSizeRight = borderSize;
  }

	GetRCString("CommandTextFontFace", configLine,"Arial",256);
  szFontFace = new char[StrLen(configLine) +1];
  StrCopy(szFontFace, configLine);
	colorBG = GetRCColor("CommandBGColor",RGB(255,255,255));
  colorBorder = GetRCColor("CommandBorderColor",RGB(255,255,255));
	colorText = GetRCColor("CommandTextColor",RGB(0,0,0));
	textSize = GetRCInt("CommandTextSize",14);

	// 3d decoration colors
  hasBevel = GetRCBool("CommandBevel", true);
	bevelLightColor = GetRCColor("CommandBevelLightColor", GetSysColor(COLOR_3DHILIGHT));
	bevelDarkColor = GetRCColor("CommandBevelDarkColor", GetSysColor(COLOR_3DSHADOW));
  bevelSize = GetRCInt("CommandBevelSize", 1);

  hideOnUnfocus = GetRCBool("CommandHideOnUnfocus", true);
  isVisible = GetRCBool("CommandHiddenOnStart", false);
  isNotAlwaysOnTop = GetRCBool("CommandNotAlwaysOnTop",true);
  clearEditOnCommand = GetRCBool("CommandNoClearOnCommand", false);
  selectAllOnFocus = GetRCBool("CommandSelectAllOnFocus", true);
  isMoveable = GetRCBool("CommandNotMoveable", false);
  rememberPosition = GetRCBool("CommandRememberPosition", true);

  if (rememberPosition)
  {
    char szKeyName[MAX_LINE_LENGTH];
    HKEY key;

    strcpy(szKeyName, "Software\\LiteStep\\");
    strcat(szKeyName, szAppName);

    if (RegOpenKeyEx(HKEY_CURRENT_USER, szKeyName, 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
    {
      //RegSetValueEx(key, "flags", 0, REG_DWORD, (LPBYTE)&wpData.flags, sizeof(DWORD));
      //RegSetValueEx(key, "ptMaxPosition.x", 0, REG_DWORD, (LPBYTE)&wpData.ptMaxPosition.x, sizeof(DWORD));
      //RegSetValueEx(key, "ptMaxPosition.y", 0, REG_DWORD, (LPBYTE)&wpData.ptMaxPosition.y, sizeof(DWORD));
      //RegSetValueEx(key, "ptMinPosition.x", 0, REG_DWORD, (LPBYTE)&wpData.ptMinPosition.x, sizeof(DWORD));
      //RegSetValueEx(key, "ptMinPosition.y", 0, REG_DWORD, (LPBYTE)&wpData.ptMinPosition.y, sizeof(DWORD));
      //RegSetValueEx(key, "showCmd", 0, REG_DWORD, (LPBYTE)&wpData.showCmd, sizeof(DWORD));
      DWORD nValue;
	    unsigned long len = sizeof(DWORD);
	    unsigned long tp = REG_DWORD;
      if (RegQueryValueEx(key, "top", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
      {
        ypos = nValue;
      }
      if (RegQueryValueEx(key, "bottom", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
      {
        height = nValue - ypos;
      }
      if (RegQueryValueEx(key, "left", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
      {
        xpos = nValue;
      }
      if (RegQueryValueEx(key, "right", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
      {
        width = nValue - xpos;
      }
      RegCloseKey(key);
    }
  }

  hBorderBrush = CreateSolidBrush(colorBorder);
	hFont = CreateFont(textSize,0,0,0,0,0,0,0,0,0,0,0,0,szFontFace);
  hBrush = CreateSolidBrush(colorBG);

}

void Command::cleanCommand()
{
  delete[] szFontFace;
  DeleteObject(hFont);
  DeleteObject(hBrush);
  DeleteObject(hBorderBrush);
}


LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  static char pszPattern[MAX_PATH] = {'\0'};
  static HANDLE handle;
  static WIN32_FIND_DATA found;
  BOOL bContinue;
  
  switch(uMsg)
  {
  case WM_KEYDOWN:
    {
      switch(wParam)
      {
      case VK_RETURN:
        PostMessage(GetParent(hwnd), WM_COMMAND, IDOK, NULL);
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      case VK_ESCAPE:
        /*ShowWindow(hwnd, SW_HIDE);
        SetFocus(GetParent(hwnd));
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }*/
        SetWindowText(hwnd, "");
        break;
      case VK_TAB:
      case VK_F2: 
        // Auto completion
        
        if(lstrlen(pszPattern) == 0)
        {
          GetWindowText(hwnd, pszPattern, sizeof(pszPattern));
          strcat(pszPattern, "*");
          handle = FindFirstFile(pszPattern, &found);
          bContinue = (handle != INVALID_HANDLE_VALUE);
          
          // ignore the . and .. directories
          while(bContinue && (lstrcmp(found.cFileName, ".") == 0 || (lstrcmp(found.cFileName, "..") == 0)))
            bContinue = FindNextFile(handle, &found);
        }
        else
        {
          bContinue = (FindNextFile(handle, &found) != 0);
        }
        
        // if the last search did find some file then update
        // the editbox
        if(bContinue)
        {
          char path_buffer[_MAX_PATH];
          char drive[_MAX_DRIVE];
          char dir[_MAX_DIR];
          
          _splitpath(pszPattern, drive, dir, NULL, NULL);
          _makepath(path_buffer, drive, dir, found.cFileName, NULL);
          SetWindowText(hwnd, path_buffer);
          
          // move the cursor to the end of the line
          CallWindowProc(pEditWndProc, hwnd, WM_KEYDOWN, VK_END, 0);
        }
        else
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      case VK_UP:
      case VK_DOWN:
        PostMessage(GetParent(hwnd), WM_COMMAND, wParam, NULL);
        break;
      default:
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      }
    }
    break;
  case WM_DROPFILES:
    {
      UINT uSize = DragQueryFile((HDROP)wParam, 0, NULL, 0);
      char* szFileName = new char[uSize + 10];
      DragQueryFile((HDROP)wParam, 0, szFileName, uSize + 1);
      if (strchr(szFileName, ' ') != NULL)
      {
        char* szQoutedPath = new char[uSize + 3];
        sprintf(szQoutedPath, "\"%s\"", szFileName);
        SetWindowText(hwnd, szQoutedPath);
        delete [] szQoutedPath;
      }
      else
      {
        SetWindowText(hwnd, szFileName);
      }
      delete [] szFileName;
      SetFocus(hwnd);
      DragFinish((HDROP)wParam);
    }
    break;
  case WM_KILLFOCUS:
    {
      PostMessage(GetParent(hwnd), WM_USER+1, wParam, lParam);
    }
    break;
  }
  return CallWindowProc(pEditWndProc, hwnd, uMsg, wParam, lParam);
}

