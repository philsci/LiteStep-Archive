// DLLModuleManager.h: interface for the DLLModuleManager class.
//
//////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4786)
#if !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
#define AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "../core/ifcs.h"
#include <map>
#include <string>

#define BAD_MODULE 0
#define BAD_INIT 1
#define BAD_QUIT 2

using namespace std;

class DLLModule {
	typedef int (*ModuleInitExFunc) (HWND, HINSTANCE, LPCSTR);
	typedef int (*ModuleQuitFunc) (HINSTANCE);

	HINSTANCE hInstance;
	HANDLE hThread;
	wstring location;

	wstring appPath;
	HWND mainWindow;

	ModuleInitExFunc pInitEx;
	ModuleQuitFunc pQuit;

	BOOL threaded;
	BOOL pumped;

public:
	DLLModule(BSTR loc, BOOL = false, BOOL = false);
	virtual ~DLLModule();
	void Init(HWND hMainWindow, wstring appPath);
	void Quit();
	static ULONG __stdcall ThreadProc(void* dllModPtr);
	HINSTANCE GetInstance();
	HANDLE GetThread();
	wstring GetLocation();

private:
	ULONG CallInit();
};

class DLLModuleManager : public IModuleManager  
{
public:
	DLLModuleManager(HWND, LPCTSTR);
	virtual ~DLLModuleManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	////////////////////////////////////////////////////////////////////////////
	// From IDispatch
    HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo);
		
	HRESULT STDMETHODCALLTYPE GetTypeInfo( 
		/* [in] */ UINT iTInfo,
		/* [in] */ LCID lcid,
		/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
	
	HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
		/* [in] */ REFIID riid,
		/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
		/* [in] */ UINT cNames,
		/* [in] */ LCID lcid,
		/* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
	
	/* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
		/* [in] */ DISPID dispIdMember,
		/* [in] */ REFIID riid,
		/* [in] */ LCID lcid,
		/* [in] */ WORD wFlags,
		/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
		/* [out] */ VARIANT __RPC_FAR *pVarResult,
		/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
		/* [out] */ UINT __RPC_FAR *puArgErr);
	
	////////////////////////////////////////////////////////////////////////////
	// From IModuleManager
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModules( 
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModule( 
        /* [in] */ BSTR location,
        /* [in] */ int flags);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModules( void);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModule( 
        /* [in] */ BSTR location);
        
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleList( 
        /* [in] */ SAFEARRAY __RPC_FAR * strlist,
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleCount( 
        /* [retval][out] */ int __RPC_FAR *count);
private:
	typedef std::map<std::wstring, DLLModule*> wstring2module;

	wstring2module dllModuleMap;
	HWND hMainWindow;
	wstring appPath;
	long refCount;
};

#endif // !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
