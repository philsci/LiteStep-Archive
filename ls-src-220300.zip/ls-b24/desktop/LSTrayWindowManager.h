// Represents the tray icons and the windows that contain them

#ifndef LSTRAYWINDOW
#define LSTRAYWINDOW

#include <vector>
//#include "desktop.h"

using namespace std;

// data sent by shell via Shell_NotifyIcon -- Maduin
typedef struct SHELLTRAYDATA {
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
} SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;

class LSTrayWindow {
public:
	HWND trayWnd;		// window this icon will be displayed in
	HWND tooltipWnd;
	HWND hWnd;
	int message;
	UINT uID;
	HICON hIcon;
	HICON hOriginalIcon;
	char szTip[256];
	int x,y;
};

typedef vector<LSTrayWindow> TW_vector;

class LSBar;

class LSTrayWindowManager {
	LSBar *owner;

public:
	HWND hTrayWnd;
	vector<LSTrayWindow> trayWnds;
	BOOL dontReleaseIcons;

public:
	void getRectangle(LPRECT r);
	~LSTrayWindowManager();
	HINSTANCE dllInst;
	bool paintedYet;
	HWND parent;
	LSTrayWindowManager(LSBar*);

	static LRESULT CALLBACK WndProcIcon(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcIcon(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	int getTrayByIcon(HWND trayIcon);
	int getTrayByWnd(HWND trayIcon);
	int getTrayByUID(UINT uid);
	int getTrayByWndAndUID(HWND hWnd, UINT uid);
	void removeAllTrays(void);
	const LSTrayWindow &addToTray(HWND trayWnd, HWND hWnd, int message, HICON hIcon, HICON hOriginalIcon, UINT uID, char *tip);
	void removeFromTray(HWND hWnd, UINT uID);
	int packScreenTray();
	int nTrayIcons(void);

	LSTrayWindow &operator[](int index);
private:
	int addIcon(NOTIFYICONDATA *data);
	int modifyIcon(NOTIFYICONDATA *data);
	HWND hBarWnd;
};

#endif //!defined LSTRAYWINDOW