/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __NTP_H
#define __NTP_H

#include "..\lsapi\common.h"
#include "..\lsapi\lswinbase.h"
#include <winsock.h>


#define MAX_LINE_LENGTH 4096

#define MINUTE 60000
#define JAN_1_1900 2415021L // January 1st 1900 (julian)

#define P1 ((double)2.0)
#define P2 (P1*P1)
#define P4 (P2*P2)
#define P8 (P4*P4)
#define P16 (P8*P8)
#define P32 (P16*P16)
#define CVT (((double)1000.0)/P32)

typedef struct {
	int li					: 2;
	int vn					: 3;
	int mode				: 3;
	int stratum				: 8;
	int poll				: 8;
	signed int precision	: 8;
} bits_data;

class NtpClient : public Window
{
private:
  _TCHAR hostname[256];
  int hostport;
  int maxderivation;
  int warnonmax;
  
  int notifyset;
  int notifyevents;

  _TCHAR xferdata[48];

	bits_data bits;
	unsigned int databits;

	unsigned int rootdelay;
	unsigned int rootdispersion;
	unsigned int referenceidentifier;
	unsigned int referencetimestamp_hi;
	unsigned int referencetimestamp_lo;
	unsigned int originatetimestamp_hi;
	unsigned int originatetimestamp_lo;
	unsigned int receivetimestamp_hi;
	unsigned int receivetimestamp_lo;
	unsigned int transmittimestamp_hi;
	unsigned int transmittimestamp_lo;

  int socketinit;
  bool wsainit;
  SOCKET mysocket;
  int pollfrequency;
  int lockNTPtimer;

  HANDLE tok_handle;
  TOKEN_PRIVILEGES tok_priv;
  int priv_modified;

  HWND NTPSetup;

public:

  NtpClient(HWND parentWnd, int& code);
  ~NtpClient();

  void doNTPSync();
  void showNTPSetup();

  static unsigned long doNtpStub(void* obj);


private:
  virtual void windowProc(Message& message);
  void onEndSession(Message& message);
  void onSysCommand(Message& message);
  void onTimer(Message& message);
  void onUser(Message& message);
  void onUser2(Message& message);

  void translatePacket(SYSTEMTIME received);
  int socketError(int dontquit);
  int closeup();

  unsigned long doNtp();

  void ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
				unsigned int *resi, unsigned int *resf);
  void ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
				 unsigned int *resi, unsigned int *resf);
  void ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
  void ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
  void ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);

  void enablePriviledge();
  void disablePriviledge();

  void convertTimeToFixed(SYSTEMTIME sys_time, unsigned int *integer, unsigned int *fractional);
  void convertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time);

  int julianDayNumber(WORD wYear, WORD wMonth, WORD wDay);
  void gregorianDate(long julian_time, WORD *wYear, WORD *wMonth, WORD *wDay);

  void ntpSetupOK(HWND hwndDlg);

};


#endif