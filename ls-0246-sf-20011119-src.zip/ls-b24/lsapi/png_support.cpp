#include "png_support.h"

void PNGErrorHandler(png_structp PngStruct, png_const_charp Message)
{
	PPNGERROR PngError = reinterpret_cast<PPNGERROR>(png_get_error_ptr(PngStruct));

	if (!PngError)
		throw Message;
	else
	{
		MessageBox(PngError->Wnd, Message, "LiteStep::LoadFromPNG:PngError", MB_OK | MB_ICONERROR);
		longjmp(PngError->ErrorJump, 1);
	}
}

HBITMAP LoadFromPNG(LPCSTR pszFilename)
{
 	if (strcmp(pszFilename, "") == 0)
		return NULL;

	FILE* File = fopen(pszFilename, "rb");
    if (File == NULL)
        return NULL;

	const size_t num_sig_bytes = 8;
	unsigned char sig[num_sig_bytes];
	fread(sig, 1, num_sig_bytes, File);

	int is_png = png_check_sig(sig, num_sig_bytes);
	if (!is_png)
	{
		fclose(File);
	}

	PNGERROR PngError = {GetForegroundWindow()};

 	png_structp Read = png_create_read_struct(PNG_LIBPNG_VER_STRING, &PngError, PNGErrorHandler, NULL);
	if (!Read)
		fclose(File);

	png_infop Info = png_create_info_struct(Read);
	if (!Info)
	{
		png_destroy_read_struct(&Read, NULL, NULL);
		fclose(File);
	}

	if (setjmp(PngError.ErrorJump))
	{
		png_destroy_read_struct(&Read, &Info, NULL);
	 	fclose(File);
		return NULL;
	}

	png_init_io(Read, File);
    png_set_sig_bytes(Read, num_sig_bytes);
    png_read_info(Read, Info);

	const unsigned char bit_depth = png_get_bit_depth(Read, Info);
	const unsigned char color_type = png_get_color_type(Read, Info);

	if (color_type == PNG_COLOR_TYPE_PALETTE)
	 	png_set_palette_to_rgb(Read);

	if ((color_type == PNG_COLOR_TYPE_GRAY) || (color_type == PNG_COLOR_TYPE_GRAY_ALPHA))
	{
		if (bit_depth < 8)
			png_set_gray_1_2_4_to_8(Read);
		png_set_gray_to_rgb(Read);
	}

 	if (png_get_valid(Read, Info, PNG_INFO_tRNS))
	 	png_set_tRNS_to_alpha(Read);

	if (color_type & PNG_COLOR_MASK_COLOR)
		png_set_bgr(Read);

	if (bit_depth == 16)
		png_set_strip_16(Read);

	double image_gamma = 1 / 2.2;
	png_get_gAMA(Read, Info, &image_gamma);
	png_set_gamma(Read, 2.2, image_gamma);

	const int num_passes = png_set_interlace_handling(Read);

	png_read_update_info(Read, Info);
	
	BITMAPINFO bmi = {0};
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = png_get_image_width(Read, Info);
	bmi.bmiHeader.biHeight = -(int)png_get_image_height(Read, Info);
	bmi.bmiHeader.biBitCount = png_get_channels(Read, Info) * png_get_bit_depth(Read, Info);
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;

	unsigned char* Bits;
	HBITMAP DibSection = CreateDIBSection(NULL, &bmi, 0, reinterpret_cast<LPVOID*>(&Bits), NULL, 0);
	if (!Bits)
		longjmp(PngError.ErrorJump, 1);

	unsigned int dib_bytes_per_scanline = (((bmi.bmiHeader.biWidth * bmi.bmiHeader.biBitCount) + 31) & ~31) >> 3;

 	for (int Pass = 0; Pass < num_passes; Pass++)
	{
		for (int y = 0; y < -bmi.bmiHeader.biHeight; y++)
		{
			unsigned char* Scanline = reinterpret_cast<unsigned char*>(Bits + (y * dib_bytes_per_scanline));
			png_read_row(Read, Scanline, NULL);
		}
	}

	png_read_end(Read, Info);
 	png_destroy_read_struct(&Read, &Info, NULL);
	fclose(File);

	return DibSection;
}
