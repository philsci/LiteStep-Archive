// StartupRunner.cpp: implementation of the StartupRunner class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <tchar.h>
#include <shlobj.h>
#include <io.h>
#include "../lsapi/lsapi.h"
#include "StartupRunner.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StartupRunner::StartupRunner()
{

}

StartupRunner::~StartupRunner()
{

}

// [Startup Handler Code]
//DWORD WINAPI StartupRunner::RunStartupStuff (void *underExplorer)
void StartupRunner::RunStartupStuff (void *underExplorer)
{
	const LPCTSTR szRunPath = _T("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
	const LPCTSTR szRunOncePath = _T("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce");

	if (!*(BOOL*)underExplorer) {
		// Run 'RunOnce' applications, and delete from register [eg, setup stuff]
		RunEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
		DeleteEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
		RunEntriesIn (HKEY_CURRENT_USER, szRunOncePath);
		DeleteEntriesIn (HKEY_CURRENT_USER, szRunOncePath);

		// Run Regular Perminant Applications
		RunEntriesIn (HKEY_LOCAL_MACHINE, szRunPath);
		RunEntriesIn (HKEY_CURRENT_USER, szRunPath);

		// Lastly run items in the Startup folder of the start menu
		RunStartupMenu ();
	}
  //return 0;
}

void StartupRunner::RunEntriesIn (HKEY key, LPCTSTR path) {
	HKEY    hKey = NULL;
	LONG    lResult;

	lResult = RegOpenKeyEx(key, path, 0, KEY_READ, &hKey);

	if (lResult == ERROR_SUCCESS) {
		TCHAR szNameBuffer[1024], szValueBuffer[1024];
		DWORD dwLoop, dwNameSize, dwValueSize;

		for (dwLoop = 0; ; ++dwLoop) {
			dwNameSize = sizeof (szNameBuffer);
			dwValueSize = sizeof (szValueBuffer);
			lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
				(LPBYTE) szValueBuffer, &dwValueSize);
			if (lResult == ERROR_NO_MORE_ITEMS) {break;}
			if (lResult == ERROR_SUCCESS) {WinExec (szValueBuffer, SW_SHOW);}
			else {break;}
		}
		RegCloseKey (hKey);
	}
}

void StartupRunner::DeleteEntriesIn (HKEY key, LPCTSTR path) {
	HKEY    hKey = NULL;
	LONG    lResult;
	
	lResult = RegOpenKeyEx(key, path, 0, KEY_ALL_ACCESS, &hKey);
	if (lResult == ERROR_SUCCESS) {
		TCHAR szNameBuffer[1024], szValueBuffer[1024];
		DWORD dwLoop, dwNameSize, dwValueSize;
		
		for (dwLoop = 0; ;) {
			dwNameSize = sizeof (szNameBuffer);
			dwValueSize = sizeof (szValueBuffer);
			
			lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
				(LPBYTE) szValueBuffer, &dwValueSize);
			if (lResult == ERROR_NO_MORE_ITEMS) {break;}
			if (lResult == ERROR_SUCCESS) {
				lResult = RegDeleteValue(hKey,szNameBuffer);
				if (lResult != ERROR_SUCCESS) {break;}
			}
			else {break;}
		}
		RegCloseKey (hKey);
	}
}

void StartupRunner::RunStartupMenu (void) {
	char szPath[256];
	LPITEMIDLIST item;
	SHGetSpecialFolderLocation(NULL, CSIDL_COMMON_STARTUP, &item);
	SHGetPathFromIDList(item, szPath);
	RunFolderContents(szPath);
	
	SHGetSpecialFolderLocation(NULL,CSIDL_STARTUP,&item);
	SHGetPathFromIDList(item, szPath);
	RunFolderContents(szPath);
}

void StartupRunner::RunFolderContents(LPCSTR szParams) {
	char szDir[256], szPath[256];
	WIN32_FIND_DATA findData;
	HANDLE hSearch;
	
	strcpy(szPath, szParams);
	strcpy(szDir, szPath);
	if (szPath[strlen(szPath)-1] != '\\') 
    strcat(szPath, "\\");
	strcat(szPath, "*.*");
	
	if (strcmp(szPath, "\\*.*") != 0) {
		hSearch = FindFirstFile(szPath, &findData);
		while (hSearch != INVALID_HANDLE_VALUE)
    {
			if (strcmp(findData.cFileName, ".") && strcmp(findData.cFileName, ".."))
				LSExecuteEx(NULL, NULL, findData.cFileName, NULL, szDir, SW_SHOWNORMAL);
			
      if (!FindNextFile(hSearch, &findData))
      {
				FindClose(hSearch);
				hSearch = INVALID_HANDLE_VALUE;
      }
		}
	}
}

