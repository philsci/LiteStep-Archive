/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <comdef.h>

#include "DLLModuleManager.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/macros.h"
#include "../lsapi/ThreadedBangCommand.h"
#include "resource.h"

extern HINSTANCE myInstance;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HANDLE DLLModuleManager::thread_event;
HANDLE DLLModuleManager::load_quit_event;

DLLModuleManager::DLLModuleManager(HWND hwnd, LPCSTR appPath)
{
	thread_event = CreateEvent(NULL, FALSE, TRUE, "ThreadEvent");
	thread_event = CreateEvent(NULL, FALSE, TRUE, "LoadQuitEvent");

	this->appPath = _bstr_t(appPath);
	this->hMainWindow = hwnd;

	refCount = 0;
}

DLLModuleManager::~DLLModuleManager()
{
	QuitModules();
	CloseHandle(DLLModuleManager::thread_event);
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE DLLModuleManager::QueryInterface(
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv)
{

	if (riid == IID_IUnknown)
	{
		*ppv = static_cast<IUnknown*>(this);
	}
	else if (riid == IID_IModuleManager)
	{
		*ppv = static_cast<IModuleManager*>(this);
	}
	else
	{
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE DLLModuleManager::AddRef( void)
{
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE DLLModuleManager::Release( void)
{
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0)
	{
		delete this;
	}

	return count;
}

#define B24

////////////////////////////////////////////////////////////////////////////
// From IModuleManager
HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModules(int __RPC_FAR *count)
{
	int myCount = 0;

#ifdef B24

	char buffer[4096];
	FILE *f;
	f = LCOpen (NULL);

	if (f)
	{
		while (LCReadNextCommand (f, buffer, sizeof (buffer)))
		{
			char *lpszBuffers[4];
			char token1[4096] = {0};
			char token2[4096] = {0};
			char token3[4096] = {0};
			char token4[4096] = {0};

			lpszBuffers[0] = token1;
			lpszBuffers[1] = token2;
			lpszBuffers[2] = token3;
			lpszBuffers[3] = token4;

			if (LCTokenize (buffer, lpszBuffers, 4, NULL) >= 2)
			{
				if (!stricmp (token1, "LoadModule"))
				{
					BOOL Add = TRUE;

					if (Add)
					{
						BOOL thread = FALSE;
						BOOL nopump = FALSE;
						int flags = 0;

						thread = strcmpi(token3, "threaded") == 0;
						if (!thread)
						{
							thread = strcmpi(token4, "threaded") == 0;
						}
						if (thread)
						{
							flags |= MODULE_THREADED;
							nopump = strcmpi(token4, "nopump") == 0;
							if (!nopump)
							{
								nopump = strcmpi(token3, "nopump") == 0;
							}
							if (nopump)
							{
								flags |= MODULE_NOTPUMPED;
							}
						}

						_bstr_t mystr(token2);
						LoadModule(mystr, flags);
						myCount++;
					}
				}
			}
		}
		LCClose (f);
	}

#else // new version using new settings
	for (int i = 0; i < 6; i++)
	{
		LoadModule(modules[i]);
	}
#endif // B24

	if (count)
	{
		*count = myCount;
	}

	return S_OK;
}


HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModule(BSTR location, int flags)
{
	// We're in the process of loading all modules,
	// make sure nobody is trying to do the same.
	WaitForSingleObject(DLLModuleManager::load_quit_event, INFINITE);

	DLLModule* dllMod = NULL;
	wchar_t* lowerLocation = _wcslwr(_wcsdup(location));

	if (dllModuleMap.find(lowerLocation) != dllModuleMap.end())
	{
		free(lowerLocation);
		return E_FAIL; // need message saying already loaded
	}

	try
	{
		// #pragma COMPILE_WARN(NOTE: Need to do threading stuff)
		dllMod = new DLLModule(lowerLocation, flags & MODULE_THREADED, !(flags & MODULE_NOTPUMPED));
	}
	catch (int error)
	{

		switch (error)
		{
			case BAD_MODULE:
			RESOURCE_STR(myInstance, IDS_DLLMGR_ERROR1,
			             "Error: Could not locate module.\nPlease check your configuration.");
			break;
			case BAD_INIT:
			RESOURCE_STR(myInstance, IDS_DLLMGR_ERROR2,
			             "Error: Could not find initModuleEx().\n\nPlease confirm that the dll is a Litestep module,\nand check with the author for updates.");
			break;
			case BAD_QUIT:
			RESOURCE_STR(myInstance, IDS_DLLMGR_ERROR3,
			             "Error: Could not find quitModule().\n\nPlease conirm that the dll is a Litestep module.");
			break;
		}

		MessageBox(NULL, resourceTextBuffer, _bstr_t(lowerLocation), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		delete dllMod;
		free(lowerLocation);
		return E_FAIL;
	}

	dllModuleMap[wstring(lowerLocation)] = dllMod;
	try
	{
		dllMod->Init(hMainWindow, appPath);
	}
	catch (...)
	{

		RESOURCE_MSGBOX(myInstance, IDS_DLLMGR_ERROR4,
		                "Error: Exception during module initialization.\n\nPlease contact the module writer.",
		                _bstr_t(lowerLocation))

		dllModuleMap.erase(dllModuleMap.find(wstring(lowerLocation)));

		free(lowerLocation);
		return E_FAIL;
	}

	// signal the event
	SetEvent(DLLModuleManager::load_quit_event);

	free(lowerLocation);
	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModules(void)
{
	wstring2module::iterator iter;

	iter = dllModuleMap.begin();

	while (iter != dllModuleMap.end())
	{
		if (iter->second)
		{
			try
			{
				iter->second->Quit();
				delete iter->second;
			}
			catch (...)
			{
				// quietly swallow exceptions
				// debugging/logging code should go here
			}
		}

		iter++;
	}

	dllModuleMap.clear();

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModule(BSTR location)
{
	// We're in the process of loading all modules,
	// make sure nobody is trying to do the same.
	WaitForSingleObject(DLLModuleManager::load_quit_event, INFINITE);

	DLLModule* dllMod;

	if (location != NULL)
	{
		wchar_t* lowerLocation = _wcslwr(_wcsdup(location));
		wstring newLoc = wstring(lowerLocation);
		free(lowerLocation);
		if (dllModuleMap.find(newLoc) != dllModuleMap.end())
		{
			dllMod = dllModuleMap[newLoc];

			try
			{
				dllMod->Quit();
				delete dllMod;
			}
			catch (...)
			{
				// Quietly swallow exceptions
				// debugging/logging code should go here
			}

			dllModuleMap.erase(newLoc);
		}
	}

	SetEvent(DLLModuleManager::load_quit_event);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleList(SAFEARRAY __RPC_FAR * strlist, int __RPC_FAR *count)
{
	long lBound;
	long uBound;
	long size;
	int i;

	BSTR *outList;

	SafeArrayGetLBound(strlist, 1, &lBound);
	SafeArrayGetUBound(strlist, 1, &uBound);

	size = uBound - lBound + 1;

	SafeArrayAccessData(strlist, (void**)&outList);

	wstring2module::iterator iter = dllModuleMap.begin();
	for (i = 0; i < size && iter != dllModuleMap.end(); i++, iter++)
	{
		outList[i] = SysAllocString(iter->first.c_str());
	}

	SafeArrayUnaccessData(strlist);

	*count = i;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleCount(int __RPC_FAR *count)
{
	*count = dllModuleMap.size();

	return S_OK;
}

//////////////////////////////////////////////////////////
// DLLModule class
DLLModule::DLLModule(BSTR loc, BOOL isThreaded, BOOL isPumped)
{
	location = loc;
	hThread = NULL;
	pInitEx = NULL;
	pQuit = NULL;
	threaded = isThreaded;
	pumped = isPumped;

	hInstance = LoadLibrary(_bstr_t(location.c_str()));

	if (hInstance)
	{
		pInitEx = (ModuleInitExFunc)GetProcAddress(hInstance, "initModuleEx");
		if (!pInitEx) // Might be a BC module, check for underscore
			pInitEx = (ModuleInitExFunc)GetProcAddress(hInstance, "_initModuleEx");

		pQuit = (ModuleQuitFunc)GetProcAddress(hInstance, "quitModule");
		if (!pQuit)   // Might be a BC module, check for underscore
			pQuit = (ModuleQuitFunc)GetProcAddress(hInstance, "_quitModule");

		if (!pInitEx)
		{
			throw BAD_INIT;
		}

		if (!pQuit)
		{
			throw BAD_INIT;
		}
	}
	else
	{
		throw BAD_MODULE;
	}
}

DLLModule::~DLLModule()
{
	if (hInstance)
	{
		FreeLibrary(hInstance);
		hInstance = 0;
	}
}

void DLLModule::Init(HWND hMainWindow, wstring theAppPath)
{
	if (hInstance)
	{
		if (pInitEx)
		{
			mainWindow = hMainWindow;
			appPath = theAppPath;

			if (threaded)
			{
				SECURITY_ATTRIBUTES sa;

				sa.nLength = sizeof(SECURITY_ATTRIBUTES);
				sa.lpSecurityDescriptor = NULL;
				sa.bInheritHandle = FALSE;

				CreateThread(&sa, 0, DLLModule::ThreadProc, this, NULL, (ULONG*)&hThread);
				WaitForThread(LM_THREADREADY);
			}
			else
			{
				CallInit();
			}
		}
	}
}

ULONG DLLModule::CallInit()
{
	try
	{
		pInitEx(mainWindow, hInstance, _bstr_t(appPath.c_str()));
	}
	catch (...)
	{
		FreeLibrary(hInstance);
		hInstance = NULL;

		return -1;
	}

	return 0;
}

ULONG __stdcall DLLModule::ThreadProc(void* dllModPtr)
{
	DLLModule* dllMod = (DLLModule*)dllModPtr;

	// Make sure modules load sequentially, and one at a time, to prevent dependency problems
	//WaitForSingleObject(DLLModuleManager::thread_event, INFINITE);

	dllMod->CallInit();
	PostMessage(GetLitestepWnd(), LM_THREADREADY, NULL, NULL);

	//SetEvent(DLLModuleManager::thread_event);

	if (dllMod->pumped)
	{
		WNDCLASS wndclass;

		memset(&wndclass, 0, sizeof(WNDCLASS));

		wndclass.lpfnWndProc = DLLModule::ThreadWndProc;
		wndclass.hInstance = dllMod->GetInstance();
		wndclass.lpszClassName = "LSThreadWnd";

		RegisterClass(&wndclass);

		// create thread handler window
		dllMod->hThreadWnd = CreateWindow(
		                         "LSThreadWnd",
		                         "Litestep Thread Handler Window",
		                         WS_CHILD,
		                         0,
		                         0,
		                         0,
		                         0,
		                         GetLitestepWnd(),
		                         NULL,
		                         dllMod->GetInstance(),
		                         (void*)dllMod);

		MSG msg;

		while (GetMessage(&msg, 0, 0, 0))
		{
			try
			{
				if (msg.hwnd == NULL)
				{
					// Thread message
					dllMod->HandleThreadMessage(msg);
				}
				else
				{
					// Window message
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
			catch (...)
			{
				// Quietly ignore exceptions?
				// #pragma COMPILE_WARN(Note: Need stronger exception-handling code here...restart the module or something)
			}
		}
	}

	PostMessage(GetLitestepWnd(), LM_THREADFINISHED, 0, 0);

	return 0;
}

HRESULT WINAPI DLLModule::ThreadWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	DLLModule *dll_mod = NULL;

	if (message == WM_CREATE)
	{
		dll_mod = (DLLModule*)((LPCREATESTRUCT)lParam)->lpCreateParams;
		SetWindowLong(hwnd, GWL_USERDATA, (LONG)dll_mod);
	}
	else
	{
		dll_mod = (DLLModule*)GetWindowLong(hwnd, GWL_USERDATA);
	}

	switch (message)
	{
		case WM_DESTROY:
		try
		{
			dll_mod->GetQuit()(dll_mod->GetInstance());
		}
		catch (...)
		{
			RESOURCE_MSGBOX(myInstance, IDS_DLLMGR_ERROR5,
			                "Exception while quitting module.", _bstr_t(dll_mod->location.c_str()))
		}

		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hwnd, message, wParam, lParam);
}

void DLLModule::Quit()
{
	if (hInstance)
	{
		if (hThread)
		{
			PostMessage(hThreadWnd, WM_DESTROY, 0, 0);
			WaitForThread(LM_THREADFINISHED);
		}
		else
		{
			if (pQuit)
			{
				try
				{
					pQuit(hInstance);
				}
				catch (...)
				{
					RESOURCE_MSGBOX(myInstance, IDS_DLLMGR_ERROR5,
					                "Exception while quitting module.", _bstr_t(location.c_str()))
				}
			}
		}
	}
}

HINSTANCE DLLModule::GetInstance()
{
	return hInstance;
}

HANDLE DLLModule::GetThread()
{
	return hThread;
}

wstring DLLModule::GetLocation()
{
	return location;
}

ModuleInitExFunc DLLModule::GetInitEx()
{
	return pInitEx;
}

ModuleQuitFunc DLLModule::GetQuit()
{
	return pQuit;
}

void DLLModule::HandleThreadMessage(MSG &msg)
{
	switch (msg.message)
	{
		case LM_THREAD_BANGCOMMAND:
		BangCommandInfo *bang_info = (BangCommandInfo*)msg.wParam;

		if (bang_info != NULL)
		{
			bang_info->bang->Execute(bang_info->caller, bang_info->params);
			bang_info->bang->Release();
			SysFreeString(bang_info->params);
			delete bang_info; //check ThreadedBangCommand.cpp for the reason
		}
		break;
	}
}

void DLLModule::WaitForThread(DWORD thread_msg)
{
	MSG msg;

	while (GetMessage(&msg, 0, 0, 0))
	{
		if (msg.message == thread_msg)
			break;

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}
