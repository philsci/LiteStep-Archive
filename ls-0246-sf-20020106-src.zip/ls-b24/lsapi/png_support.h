#pragma once

#pragma include_alias("zlib.h", "..\zlib\zlib.h")
#pragma comment(linker, "/NODEFAULTLIB:libc.lib")
#pragma comment(lib, "lpng120/projects/msvc/win32/libpng/lib/libpng.lib")
#pragma comment(lib, "lpng120/projects/msvc/win32/zlib/lib/zlib.lib")

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef STRICT
#define STRICT
#endif
#ifndef NOCRYPT
#define NOCRYPT
#endif

#include <windows.h>
#include "lpng120\png.h"

typedef struct _PNGERROR
{
	HWND Wnd;
	jmp_buf ErrorJump;
}
PNGERROR, *PPNGERROR;

void PNGErrorHandler(png_structp PngStruct, png_const_charp Message);
HBITMAP LoadFromPNG(LPCSTR pszFilename);
