/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
06/21/01 - Bobby G. Vinyard (Message)
  - Fixed it so that it closed an open file quicker when adding explorer
    hotkeys
10/02/00 - Joachim Calvert (NeXTer)
  - Enter, Mul, Div, Add, Sub and Dec (decimal key) are now supported
08/30/00 - Joachim Calvert (NeXTer)
  - Shouldn't reserve unused hotkeys anymore (specifically ctrl-esc), let me
    know if it doesn't work
08/17/00 - Joachim Calvert (NeXTer)
  - Now responds to the !Refresh command
04/25/00 - Bobby G. Vinyard (Message)
  - Ugh forgot to clear the hotkey maps when hotkeys were unloaded
04/20/00 - Joachim Calvert (NeXTer)
  - Now uses the LSWinBase library
04/18/00 - Bobby G. Vinyard (Message)
  - Rewrite based on the Desktop2 code
****************************************************************************/

#include "hotkey.h"
#include "resource.h"

const char rcsRevision[] = "$Revision: 1.6 $"; // Our Version
const char rcsId[] = "$Id: hotkey.cpp,v 1.6 2001/11/20 22:39:27 message Exp $"; // The Full RCS ID.

static const VKTable vkTable[] =
    {
        {"ESCAPE", VK_ESCAPE
        },
        {"F1", VK_F1},
        {"F2", VK_F2},
        {"F3", VK_F3},
        {"F4", VK_F4},
        {"F5", VK_F5},
        {"F6", VK_F6},
        {"F7", VK_F7},
        {"F8", VK_F8},
        {"F9", VK_F9},
        {"F10", VK_F10},
        {"F11", VK_F11},
        {"F12", VK_F12},
        {"PAUSE", VK_PAUSE},
        {"INSERT", VK_INSERT},
        {"DELETE", VK_DELETE},
        {"HOME", VK_HOME},
        {"END", VK_END},
        {"PAGEUP", VK_PRIOR},
        {"PAGEDOWN", VK_NEXT},
        {"LEFT", VK_LEFT},
        {"RIGHT", VK_RIGHT},
        {"UP", VK_UP},
        {"DOWN", VK_DOWN},
        {"TAB", VK_TAB},
        {"BACKSPACE", VK_BACK},
        {"SPACEBAR", VK_SPACE},
        {"APPS", VK_APPS},
        {"ENTER", VK_RETURN},
        {"NUM0", VK_NUMPAD0},
        {"NUM1", VK_NUMPAD1},
        {"NUM2", VK_NUMPAD2},
        {"NUM3", VK_NUMPAD3},
        {"NUM4", VK_NUMPAD4},
        {"NUM5", VK_NUMPAD5},
        {"NUM6", VK_NUMPAD6},
        {"NUM7", VK_NUMPAD7},
        {"NUM8", VK_NUMPAD8},
        {"NUM9", VK_NUMPAD9},
        {"MUL", VK_MULTIPLY},
        {"DIV", VK_DIVIDE},
        {"ADD", VK_ADD},
        {"SUB", VK_SUBTRACT},
        {"DEC", VK_DECIMAL},
    };

#define MAX_VKEYS (sizeof(vkTable) / sizeof(VKTable))

const char szAppName[] = "HotkeyWindow";

Hotkey *hotkey; // The module


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	Window::init(dllInst);
	hotkey = new Hotkey(parentWnd, code);

	return code;
}


void quitModule(HINSTANCE dllInst)
{
	delete hotkey;
}


//=========================================================
// Module code
//=========================================================
//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Hotkey::Hotkey(HWND parentWnd, int& code):
		Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "LSHotkey", WS_CHILD,
	                  0, 0, 0, 0, parentWnd))
	{
		RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR1,
		                "Error creating window", szAppName);

		code = 1;
		return ;
	}
	code = 0;
}


Hotkey::~Hotkey()
{
	destroyWindow();
}


void Hotkey::loadHotkeys()
{
	FILE* f;

	loadExplorerKeys = GetRCBool("HotkeyLoadExplorerKeys", TRUE) != FALSE;
	noWinKeyPopup = GetRCBool("HotkeyNoWinKeyPopup", TRUE) != FALSE;
	noShellWarning = GetRCBool("LSNoShellWarning", TRUE) != FALSE;
	explorerNoWarn = GetRCBool("ExplorerNoWarn", TRUE) != FALSE;

	f = LCOpen(NULL);
	if (f)
	{
		char	buffer[4096];
		char	token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
		LPSTR	tokens[4];

		tokens[0] = token1;
		tokens[1] = token2;
		tokens[2] = token3;
		tokens[3] = token4;

		buffer[0] = 0;

		while (LCReadNextConfig (f, "*Hotkey", buffer, sizeof (buffer)))
		{
			int count, i;

			token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';

			count = LCTokenize (buffer, tokens, 4, extra_text);

			if (count == 4)
			{
				char *tmp;
				HotkeyType tempHotkey;

				tempHotkey.sub = 0;
				tmp = strtok(token2, "+");

				while (tmp)
				{
					if (!strcmpi(tmp, "Win"))
						tempHotkey.sub |= MOD_WIN;
					if (!strcmpi(tmp, "Alt"))
						tempHotkey.sub |= MOD_ALT;
					if (!strcmpi(tmp, "Ctrl"))
						tempHotkey.sub |= MOD_CONTROL;
					if (!strcmpi(tmp, "Shift"))
						tempHotkey.sub |= MOD_SHIFT;
					tmp = strtok(NULL, "+");
				}

				if (lstrlen(token3) == 1)
					tempHotkey.ch = strupr(token3)[0];
				else
				{
					for (i = 0; i < MAX_VKEYS; i++)
					{
						if (!strcmpi(vkTable[i].key, token3))
						{
							tempHotkey.ch = vkTable[i].vKey;
							break;
						}
					}
				}

				tempHotkey.szCommand = token4;
				tempHotkey.szParameters = extra_text;
				hotKeys.push_back(tempHotkey);
				RegisterHotKey(hWnd, hotKeys.size(), tempHotkey.sub, tempHotkey.ch);
			}
		}
	}
	LCClose(f);
	// Load Explorer Hotkeys
	if (loadExplorerKeys)
	{
		loadExplorerHotkeys();
	}

	if (!noWinKeyPopup)
	{
		if ((!RegisterHotKey(hWnd, GlobalAddAtom("LWIN_KEY"), MOD_WIN, VK_LWIN)) ||
		        (!RegisterHotKey(hWnd, GlobalAddAtom("RWIN_KEY"), MOD_WIN, VK_RWIN)))
		{
			RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR2,
			                "Error registering Win Key", szAppName)
		}
		if (!(noShellWarning || explorerNoWarn))
		{
			if (!RegisterHotKey(hWnd, GlobalAddAtom("CTL_ESC"), MOD_CONTROL, VK_ESCAPE))
			{
				RESOURCE_MSGBOX(instance(), IDS_HOTKEY_ERROR3,
				                "Error registering Ctrl+Esc", szAppName)
			}
		}
	}
}


void Hotkey::loadExplorerHotkeys()
{
	HKEY shellFoldersKey;
	DWORD dataType, dataLength = 1024;

	char szAllStartMenu[1024];	// WinNT
	char szAllDesktop[1024];	// WinNT
	char szUserStartMenu[1024];
	char szUserDesktop[1024];

	// Hotkey Code
	RegisterHotKey(hWnd, GlobalAddAtom("REINIT"), MOD_CONTROL | MOD_ALT | MOD_SHIFT, 'R');

	RegOpenKey(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", &shellFoldersKey);
	dataLength = sizeof (szUserStartMenu);
	if (RegQueryValueEx(shellFoldersKey, "Start Menu", NULL, &dataType, (LPBYTE) szUserStartMenu, &dataLength) != ERROR_SUCCESS)
		strcpy(szUserStartMenu, "");
	dataLength = sizeof (szUserDesktop);
	if (RegQueryValueEx(shellFoldersKey, "Desktop", NULL, &dataType, (LPBYTE) szUserDesktop, &dataLength) != ERROR_SUCCESS)
		strcpy(szUserDesktop, "");
	RegCloseKey(shellFoldersKey);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", 0, KEY_READ, &shellFoldersKey);
	dataLength = sizeof (szAllStartMenu);
	if (RegQueryValueEx(shellFoldersKey, "Common Start Menu", NULL, &dataType, (LPBYTE) szAllStartMenu, &dataLength) != ERROR_SUCCESS)
		strcpy(szAllStartMenu, "");
	dataLength = sizeof (szAllDesktop);
	if (RegQueryValueEx(shellFoldersKey, "Common Desktop", NULL, &dataType, (LPBYTE) szAllDesktop, &dataLength) != ERROR_SUCCESS)
		strcpy(szAllDesktop, "");
	RegCloseKey(shellFoldersKey);

	if (strcmp(szUserStartMenu, ""))
	{
		SetCurrentDirectory(szUserStartMenu);
		findLnks(szUserStartMenu);
	}
	if (strcmp(szUserDesktop, ""))
	{
		SetCurrentDirectory(szUserDesktop);
		findLnks(szUserDesktop);
	}
	if (strcmp(szAllStartMenu, ""))
	{
		SetCurrentDirectory(szAllStartMenu);
		findLnks(szAllStartMenu);
	}
	if (strcmp(szAllDesktop, ""))
	{
		SetCurrentDirectory(szAllDesktop);
		findLnks(szAllDesktop);
	}
}


void Hotkey::findLnks(LPCSTR szBaseSearchDir)
{
	WIN32_FIND_DATA findDirData;
	WIN32_FIND_DATA findLnkData;
	HANDLE hDirFind;
	HANDLE hLnkFind;
	char szSearchDir[1024];

	SetCurrentDirectory(szBaseSearchDir);
	hLnkFind = FindFirstFile("*.lnk", &findLnkData);
	if (hLnkFind != INVALID_HANDLE_VALUE)
	{
		if (findLnkData.dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY)
		{
			addExplorerHotkey(szBaseSearchDir, findLnkData.cFileName);
		}
		while (FindNextFile(hLnkFind, &findLnkData))
		{
			if (findLnkData.dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY)
			{
				addExplorerHotkey(szBaseSearchDir, findLnkData.cFileName);
			}
		}
	}
	FindClose(hLnkFind);

	hDirFind = FindFirstFile("*.*", &findDirData);
	if (hDirFind != INVALID_HANDLE_VALUE)
	{
		if (findDirData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			if ((strcmp(findDirData.cFileName, ".") != 0) && (strcmp(findDirData.cFileName, "..") != 0))
			{
				strcpy(szSearchDir, szBaseSearchDir);
				strcat(szSearchDir, "\\");
				strcat(szSearchDir, findDirData.cFileName);
				findLnks(szSearchDir);
				SetCurrentDirectory(szBaseSearchDir);
			}
		}

		while (FindNextFile(hDirFind, &findDirData))
		{
			if (findDirData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				if (strcmp(findDirData.cFileName, ".") != 0 && strcmp(findDirData.cFileName, "..") != 0)
				{
					strcpy(szSearchDir, szBaseSearchDir);
					strcat(szSearchDir, "\\");
					strcat(szSearchDir, findDirData.cFileName);
					findLnks(szSearchDir);
					SetCurrentDirectory(szBaseSearchDir);
				}
			}
		}
	}
	FindClose(hDirFind);
}


void Hotkey::addExplorerHotkey(LPCSTR szBaseFileDir, LPCSTR szFileName)
{
	HANDLE hFile;
	BYTE btHotKey;
	BYTE btModifier;
	LONG lHotKeyOffset = 64;
	DWORD dwRead;
	char szLnkFile[1024];
	ATOM aHotKey;

	strcpy(szLnkFile, szBaseFileDir);
	strcat(szLnkFile, "\\");
	strcat(szLnkFile, szFileName);

	hFile = CreateFile(szLnkFile,
	                   GENERIC_READ,
	                   0,
	                   NULL,
	                   OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
	                   NULL);

	if (hFile != INVALID_HANDLE_VALUE)
	{
		SetFilePointer(hFile, lHotKeyOffset, NULL, FILE_BEGIN);
		ReadFile(hFile, &btHotKey, 1, &dwRead, NULL);
		ReadFile(hFile, &btModifier, 1, &dwRead, NULL);
		CloseHandle(hFile);

		aHotKey = GlobalAddAtom(szLnkFile);
		if (aHotKey)
		{
			atomHotkeys.push_back(aHotKey);
			if (btHotKey && btModifier)
			{

				switch (btModifier)
				{
					case 0x03:
					RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_SHIFT, btHotKey);
					break;
					case 0x05:
					RegisterHotKey(hWnd, aHotKey, MOD_SHIFT | MOD_ALT, btHotKey);
					break;
					case 0x06:
					RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_ALT, btHotKey);
					break;
					case 0x07:
					RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_SHIFT | MOD_ALT, btHotKey);
					break;
					default:
					break;
				}
			}
		}
	}
}


void Hotkey::freeHotkeys()
{
	UnregisterHotKey(hWnd, GlobalFindAtom("LWIN_KEY"));
	UnregisterHotKey(hWnd, GlobalFindAtom("RWIN_KEY"));
	UnregisterHotKey(hWnd, GlobalFindAtom("CTL_ESC"));
	GlobalDeleteAtom(GlobalFindAtom("LWIN_EY"));
	GlobalDeleteAtom(GlobalFindAtom("RWIN_KEY"));
	GlobalDeleteAtom(GlobalFindAtom("CTL_ESC"));

	for (size_t i = 0; i < hotKeys.size(); i++)
	{
		UnregisterHotKey(hWnd, i);
	}
	hotKeys.clear();

	if (loadExplorerKeys)
	{
		freeExplorerHotkeys();
	}
}


void Hotkey::freeExplorerHotkeys()
{
	ATOM aHotKey;

	aHotKey = GlobalFindAtom("REINIT");
	UnregisterHotKey(hWnd, aHotKey);
	GlobalDeleteAtom (aHotKey);

	for (size_t j = 0; j < atomHotkeys.size(); j++)
	{
		aHotKey = atomHotkeys[j];
		if (aHotKey != 0)
		{
			UnregisterHotKey(hWnd, aHotKey);
			GlobalDeleteAtom(aHotKey);
		}
	}
	atomHotkeys.clear();
}


//=========================================================
// Message handling
//=========================================================

void Hotkey::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	REJECT_MESSAGE(WM_ERASEBKGND)
	REJECT_MESSAGE(WM_PAINT)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onRefresh, LM_REFRESH)
	MESSAGE(onHotkey, WM_HOTKEY)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}


void Hotkey::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	loadHotkeys();
}


void Hotkey::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	freeHotkeys();
}


void Hotkey::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onGetRevId(Message& message)
{
	LPSTR buf = (LPSTR)(message.lParam);

	switch (message.wParam)
	{
		case 0:
		sprintf(buf, "hotkey.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
		default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void Hotkey::onRefresh(Message& message)
{
	freeHotkeys();
	loadHotkeys();
}


void Hotkey::onHotkey(Message& message)
{
	size_t num = message.wParam - 1;
	if (num < hotKeys.size())
	{
		if (hotKeys[num].szCommand.length())
		{
			if (hotKeys[num].szCommand[0] == '!')
			{
				KillTimer(hWnd, 1);
				ParseBangCommand(hWnd, hotKeys[num].szCommand.c_str(), hotKeys[num].szParameters.c_str());
			}
			else
			{
				char workDirectory[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR];

				_splitpath(hotKeys[num].szCommand.c_str(), drive, dir, NULL, NULL);
				strcpy(workDirectory, drive);
				strcat(workDirectory, dir);

				LSExecuteEx(GetDesktopWindow(), NULL, hotKeys[num].szCommand.c_str(), hotKeys[num].szParameters.c_str(), workDirectory, SW_SHOWNORMAL);

				KillTimer(hWnd, 1);
			}
		}
	}
	else
	{
		char szCommand[1024];

		if (GlobalGetAtomName((ATOM)message.wParam, szCommand, 1024) > 0)
		{
			if (!strcmp(szCommand, "CTL_ESC"))
				SendMessage(hParent, LM_POPUP, 0, 0);
			else if (!strcmp(szCommand, "REINIT") && loadExplorerKeys)
			{
				freeExplorerHotkeys();
				loadExplorerHotkeys();
			}
			else if (!strcmp(szCommand, "LWIN_KEY"))
			{
				SetTimer(hWnd, 1, 750, NULL);
			}
			else if (!strcmp(szCommand, "RWIN_KEY"))
			{
				SetTimer(hWnd, 1, 750, NULL);
			}
			else
			{
				KillTimer(hWnd, 1);
				if (loadExplorerKeys)
				{
					char workDirectory[_MAX_PATH];
					char drive[_MAX_DRIVE];
					char dir2[_MAX_DIR];

					_splitpath(szCommand, drive, dir2, NULL, NULL);
					strcpy(workDirectory, drive);
					strcat(workDirectory, dir2);

					LSExecuteEx(hWnd, NULL, szCommand, NULL, workDirectory, SW_SHOWNORMAL);
				}
			}
		}
	}
}

void Hotkey::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onTimer(Message& message)
{
	if (message.wParam == 1)
	{
		ParseBangCommand(hWnd, "!Popup", NULL);
		KillTimer(hWnd, 1);
	}
}

