/*
See LSBar.cpp for license and revision information
*/
#pragma warning(disable: 4786)

#include <vector>
#include <windows.h>
#include "../core/ifcs.h"
#include "LSToolTips.h"
#include "LSTrayWindowManager.h"
#include "../litestep/wharfdata.h"
#include "../lsutil/LSModule.h"
#include "../lsutil/LSBitmap.h"
#include "../lsutil/LSSettings.h"
#include "../lsapi/lsapi.h"

#include "LSTaskBar.h"
#include "LSBar.h"

extern void (__stdcall *SwitchToThisWindow)(HWND, int);

LSTaskBar::LSTaskBar(LSBar *theDesktop) {
   	WNDCLASSEX wc;
	int xwidth;

	owner = theDesktop;
	hWndParent = owner->hMainWnd;
	dll = owner->dll;
	settings = &owner->settings;
	desktopParent = owner->parent;
	ScreenWidth = owner->ScreenWidth;
	ScreenHeight = owner->ScreenHeight;
	currentButton = NULL;

	btnDrag=FALSE;
	lastStatePushed=FALSE;
	
	nWin = 0;

	// get window list info
    IWindowList *winList = (IWindowList*)SendMessage(desktopParent, LM_WINDOWLIST, 0, 0);

	// extra window memory for class pointers
	wc.cbWndExtra = 4;

	// Register MS taskbar window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
   	wc.lpfnWndProc = LSTaskBar::WndProcTasks;		// our window procedure
   	wc.hInstance = dll;								// hInstance of DLL
   	wc.lpszClassName = szTasks;						// our window class name
   	wc.style = CS_DBLCLKS;
   	
	if (!RegisterClassEx(&wc)) {
		MessageBox(desktopParent,"Error registering window class",szTasks,MB_OK);
		//return 1;
   	}
	// Register app button class
   	memset(&wc,0,sizeof(wc));
 	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
  	wc.lpfnWndProc = LSTaskButton::WndProcAppBtn;		// our window procedure
   	wc.hInstance = dll;								// hInstance of DLL
   	wc.lpszClassName = szAppBtn;					// our window class name
   	wc.style = CS_DBLCLKS;
   	
	if (!RegisterClassEx(&wc)) {
		MessageBox(desktopParent,"Error registering window class",szAppBtn,MB_OK);
		//return 1;
   	}
    
	if (settings->appBar) {
		if (settings->stripBar)
			xwidth = ScreenWidth - 73;
		else
			xwidth = ScreenWidth-10 - owner->barLeft;
		//else
			//xwidth = ScreenWidth-6;

		// Taskbar window creation
		hTasksWnd = CreateWindowEx(
			0,												// exstyles 
			szTasks,									    // our window class name
			"LSMSTaskBar",									// use description for a window title
			WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,	// styles
			settings->appBar ? owner->barLeft + 8 : 8, 3,	// position 
			xwidth, settings->trayIconSize + 6,				// width & height of window
			owner->hBarWnd,									// parent window 
			NULL,											// no menu
			dll,											// hInstance of DLL
			NULL);											// no window creation data
		if (!hTasksWnd) {						   
			MessageBox(desktopParent,"Error creating window",szTasks,MB_OK);
			//return 1;
		}

		ShowWindow(hTasksWnd,SW_SHOWNORMAL);
		SetWindowLong(hTasksWnd, LS_GWL_CLASSPOINTER, (LONG)this);

		// Enumerate the currently open windows
		long count;
		winList->EnumerateWindows(LSTaskBar::EnumWindowsProc, (LPARAM)this, &count);
		SendMessage(::FindWindow(TEXT("Hook Manager Window"), NULL), LM_REGISTERMESSAGE, (WPARAM)hTasksWnd, 0);
	}
}

LSTaskBar::~LSTaskBar() {
	DestroyWindow(hTasksWnd); // delete our window

    if (settings->appBar)
	{
		hwnd2LSTaskButton::iterator iter;

		iter = taskBtn.begin();
		while (iter != taskBtn.end()) {
            delete iter->second;
			iter++;
		}

		taskBtn.clear();
	}

	UnregisterClass(szTasks, dll); // unregister window class
	UnregisterClass(szAppBtn, dll); // unregister window class
}

// -------------------------------------------------------------------------------------------------------
// Add a window in the list
// -------------------------------------------------------------------------------------------------------
void LSTaskBar::addWindow(HWND hwnd) {
	RECT r;
	char clName[MAX_PATH];
	
	GetClassName(hwnd, clName, MAX_PATH);
	if (IsWindowVisible(hwnd) && !strstr(clName, "TWharfGlobalContainer")/* && !IsWindowLitestep(hwnd)*/) {
		taskBtn[hwnd] = new LSTaskButton(hwnd, this);

		if (IsIconic(hwnd)) {
			GetWindowRect(hwnd, &r);
			MoveWindow(hwnd, ScreenWidth*3+r.left, ScreenHeight*3+r.top, r.right-r.left, r.bottom-r.top, TRUE);
		}

		if (settings->appBar) {
			updateTasksView(1);
		}
	}
}

// -------------------------------------------------------------------------------------------------------
// Callback function. Integrates all enumerated windows
// -------------------------------------------------------------------------------------------------------
BOOL CALLBACK LSTaskBar::EnumWindowsProc(OLE_HANDLE hwnd, LPARAM lParam) {
	LSTaskBar *myTaskBar = (LSTaskBar*)lParam;

    BOOL i;
	if (myTaskBar) i = myTaskBar->inWinList((HWND)hwnd);
	
    if (!i) myTaskBar->addWindow((HWND)hwnd);

    return TRUE;
}

// -------------------------------------------------------------------------------------------------------
// Compact the window list
// -------------------------------------------------------------------------------------------------------
void LSTaskBar::RemoveWindow(HWND win) {
	if (settings->appBar) 
		destroyAppWnd(win);	

	if (settings->appBar) 
		updateTasksView(1);
}

// -------------------------------------------------------------------------------------------------------
// Returns true if a window is in the list
// -------------------------------------------------------------------------------------------------------
BOOL LSTaskBar::inWinList(HWND hwnd) {
	hwnd2LSTaskButton::iterator iter;

	if (!hwnd) 
		return -1;

	iter = taskBtn.find(hwnd);

	if (iter == taskBtn.end()) {
		return FALSE;
	} else {
		return TRUE;
	}
}

// -------------------------------------------------------------------------------------------------------
// Updates task buttons
// To do: remove flicker
// -------------------------------------------------------------------------------------------------------
void LSTaskBar::updateTasksView(int force)
{
	hwnd2LSTaskButton::iterator iter, oldIter;
	int y, h;
	float x,w;
	RECT r;
	
	if (!settings->appBar) return;
	
	GetClientRect(hTasksWnd, &r);
	
	h = r.bottom;
	if (nWin != 0)
		w = (r.right-6) / (float)nWin;
	else 
    {
		if (!settings->newStyle)
			w = (float)165;
		else
			w = (float)(r.right-6);
    }
	if (!settings->newStyle && (w > 165)) w = (float)165;
	x = (float)0;
	y = 0;
	
	iter = taskBtn.begin();
	//for (i=0;i<nWin;i++,x=x+w)
	while (iter != taskBtn.end())
    {
		if (::IsWindow(iter->second->hWnd)) {
			RECT r2;
			GetWinRect(iter->second->hWnd, &r2);
			GetClientRect(iter->second->hWnd, &r2);
			if (force || r2.left != x+4 || r2.top != y || (r2.right-r2.left) != w-2 || (r2.bottom-r2.top) != h)
			{
				char tooltip[256];
				SetWindowPos(iter->second->hWnd, NULL, (int)(x+4), y, (int)(w-2), h, SWP_NOZORDER);
				InvalidateRect(iter->second->hWnd, &r, TRUE);
				GetWindowText(iter->second->window, tooltip, 255);
				GetClientRect(iter->second->hWnd, &r);
				owner->toolTips->UpdateTooltip(iter->second->hWnd, tooltip, &r);
			}

			iter++;
			x = x + w;
		} else {
			delete iter->second;
			oldIter = iter;
			iter++;
			taskBtn.erase(oldIter);
		}
    } 
}

// -------------------------------------------------------------------------------------------------------
// Gets a windows icon
// -------------------------------------------------------------------------------------------------------
HICON LSTaskButton::GetWindowIcon(HWND Hwnd)
{
	HICON a;
	
	if (settings->trayIconSize <= 24) // we prefer to resize from the small icon (if available)
    {
		SendMessageTimeout(Hwnd, WM_GETICON, 0, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICONSM);
		if (!a) SendMessageTimeout(Hwnd, WM_GETICON, 1, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICON);
		if (!a) SendMessageTimeout(Hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
    }
	else // we prefer to resize from the 32x32 icon
    {
		SendMessageTimeout(Hwnd, WM_GETICON, 1, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICON);
		if (!a) SendMessageTimeout(Hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
		if (!a) SendMessageTimeout(Hwnd, WM_GETICON, 0, 0, 0, 1000, (unsigned long*)&a);
		if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICONSM);
    }
	
	return a;
}

// -------------------------------------------------------------------------------------------------------
// Removes a task button from the taskbar
// -------------------------------------------------------------------------------------------------------
void LSTaskBar::destroyAppWnd(HWND window)
{
	hwnd2LSTaskButton::iterator iter;

	iter = taskBtn.find(window);

	if (iter == taskBtn.end()) {
		return;
	}

	//owner->toolTips->RemoveTooltip(iter->second->hWnd);

	delete iter->second;
	taskBtn.erase(iter);
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for task buttons windows
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK LSTaskButton::WndProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LSTaskButton *theTaskButton = (LSTaskButton*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theTaskButton) {
		return theTaskButton->WindowProcAppBtn(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT LSTaskButton::WindowProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (!::IsWindow(window)) {
		DestroyWindow(hWnd);
		return 0;
	}

    switch (message)
    {
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(owner->desktopParent,message,wParam,lParam);
	case WM_CREATE:		return 0;
	case WM_ERASEBKGND: return 0;
	case WM_MOUSEMOVE:
		{
			/*MSG TooltipMessage;
			
			if (needTooltip)
			{
				TooltipMessage.hwnd=hWnd;
				TooltipMessage.message=WM_MOUSEMOVE;
				TooltipMessage.wParam=wParam;
				TooltipMessage.lParam=lParam;
				SendMessage(owner->owner->hToolTips,TTM_RELAYEVENT,0,(LPARAM)&TooltipMessage);
				SetWindowPos(owner->owner->hToolTips, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
			}*/

			if (btnDrag)
            {
				POINTS pts;
				pts = MAKEPOINTS(lParam);
				if (pts.x >= dragRect.left && pts.x <= dragRect.right && pts.y >= dragRect.top && pts.y <= dragRect.bottom)
                {
					if (!lastStatePushed) 
                    {
						drawPushed(dragDC, dragRect, hwnd, window);
						lastStatePushed = TRUE;
                    }
                }
				else
                {
					if (lastStatePushed)
                    {
						drawPopped(dragDC, dragRect, hwnd, window);
						lastStatePushed = FALSE;
                    }
                }
            }
		}
        return 0;
	case WM_LBUTTONUP:
        {
			POINTS pts;
			pts = MAKEPOINTS(lParam);
			
			ReleaseCapture();

			if (pts.x >= dragRect.left && pts.x <= dragRect.right && pts.y >= dragRect.top && pts.y <= dragRect.bottom) {
				if (IsIconic(window)) 
				{
					SwitchToThisWindow(window, 1);
				}
				else
				{
					//begin: code added by Jay Kramer (jkramer@depcoinc.com) (min/max update for start bar)
					//update: bug fix code by Jay Kramer - checks if system menu is enabled before acting
					if (current)
					{
						HMENU hMenu;
						hMenu = GetSystemMenu(window, FALSE);
						if(IsMenu(hMenu))
						{
							// check to see if the system menu is enabled or not, if it is not, then 
							// do not try to minimize the application
							if (GetWindowLong(window, GWL_STYLE) & WS_SYSMENU)
							{
								ShowWindow(window,SW_MINIMIZE);
							}
						}
					}
					else
					{
						if (!SendMessage(owner->desktopParent, LM_BRINGTOFRONT, 0, (long)window))
							SwitchToThisWindow(window, 1);
					}
				}
				//owner->DoEvents(5);
				if (owner->currentButton != this && owner->currentButton) {
					owner->currentButton->current = FALSE;
					SendMessage(owner->currentButton->hWnd, WM_PAINT, 0, 0);
				}
				current = TRUE;
				owner->currentButton = this;
				SendMessage(owner->hTasksWnd, WM_PAINT, 0, 0);
			}
			btnDrag = FALSE;
			debug = FALSE;
			ReleaseDC(hwnd, dragDC);
        }
        return 0;
	case WM_LBUTTONDOWN:
		{
            HDC hdc;
            RECT r;
            SetCapture(hwnd);
			
            hdc = GetDC(hwnd);
            GetClientRect(hwnd, &r);
            drawPushed(hdc, r, hwnd, window);
            btnDrag = TRUE;
            dragRect = r;
            lastStatePushed = TRUE;
            dragDC = hdc;
			debug = TRUE;
		}
        return 0;
        // code by Ryan Dalzell
	case WM_RBUTTONDOWN:
        {
			int x, y;
			POINT pt;
			BOOL result;
			HMENU hMenu;
			WINDOWPLACEMENT wp;
			
			GetCursorPos(&pt);
			x = pt.x;
			y = pt.y;

			hMenu = GetSystemMenu(window, FALSE);
			//bug fix by Jay Kramer - checks if system menu is enabled
			if(IsMenu(hMenu) && (GetWindowLong(window, GWL_STYLE) & WS_SYSMENU))
			{
				// Get Window state
				wp.length = sizeof(WINDOWPLACEMENT);
				GetWindowPlacement(window, &wp);
				switch(wp.showCmd)
				{
				case SW_SHOWNORMAL:
					EnableMenuItem(hMenu, SC_RESTORE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_MOVE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_SIZE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_MINIMIZE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_MAXIMIZE, MF_BYCOMMAND|MF_ENABLED);
					break;
				case SW_SHOWMAXIMIZED:
					EnableMenuItem(hMenu, SC_RESTORE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_MOVE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_SIZE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_MINIMIZE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_MAXIMIZE, MF_BYCOMMAND|MF_GRAYED);
					break;
				case SW_SHOWMINIMIZED:
					EnableMenuItem(hMenu, SC_RESTORE, MF_BYCOMMAND|MF_ENABLED);
					EnableMenuItem(hMenu, SC_MOVE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_SIZE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_MINIMIZE, MF_BYCOMMAND|MF_GRAYED);
					EnableMenuItem(hMenu, SC_MAXIMIZE, MF_BYCOMMAND|MF_ENABLED);
					break;
				}
				// Let application know also, belt and braces approach!
				SendMessage(window, WM_INITMENUPOPUP, (WPARAM)hMenu, MAKELPARAM(0, TRUE));
				SendMessage(window, WM_INITMENU, (WPARAM)hMenu, 0);
				result = TrackPopupMenu(hMenu, TPM_RETURNCMD|TPM_RIGHTBUTTON, x, y, 0, hwnd, NULL);
				
				if (result)
				{
					if (result != SC_MINIMIZE && result != SC_CLOSE)
						SetForegroundWindow(window);
					PostMessage(window, WM_SYSCOMMAND, (WPARAM)result, MAKELPARAM(x, y));
				}
			}
        }
        return 0;
	case WM_PAINT:
		Repaint();
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		{	
			PostMessage(owner->desktopParent,message,wParam,lParam);
		}
		return 0;
	case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(owner->desktopParent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				break;
			}
			
			break;
		}
    }
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Draws a pushed button
// -------------------------------------------------------------------------------------------------------
void LSTaskButton::drawPushed(HDC hdc, RECT r, HWND hwnd, HWND user) {
	HPEN old, pen;
	int clr1, clr2;
	
	// new style button: use LS color settings?
	if (settings->newStyle) {
		clr1 = settings->fore; 
	} else {
		clr1 = GetSysColor(COLOR_3DHILIGHT);
	}
	if (settings->newStyle) {
		clr2 = settings->fore2; 
	} else {
		clr2 = GetSysColor(COLOR_3DDKSHADOW);
	}

	// fill the button
	pen = CreatePen(PS_SOLID, 1, clr1);
	fillButton(hdc, hwnd, 1, r, user);
	old = (HPEN)SelectObject(hdc, pen);

	if (settings->newStyle && settings->taskBMP.bitmap==NULL) {
		int i;
		for (i = owner->owner->TRISIZE; i > 0; i--) {
			MoveToEx(hdc, r.right - 1, owner->owner->TRISIZE - i, NULL);
			LineTo(hdc, r.right - (1 + owner->owner->TRISIZE - (owner->owner->TRISIZE - i)), owner->owner->TRISIZE - i);
        }
    }

	MoveToEx(hdc, r.right-1, 0, NULL);
	
	//Taskbar skin
	if (settings->taskbtnskinBMP[1].bitmap == NULL) {
		LineTo(hdc, r.right-1, r.bottom-1);
		LineTo(hdc, 0, r.bottom-1);
	}

	//Taskbar skin
	SelectObject(hdc, old);
	DeleteObject(pen);
	pen = CreatePen(PS_SOLID, 1, clr2);
	old = (HPEN)SelectObject(hdc, pen);
	
	//Taskbar skin
	if (settings->taskbtnskinBMP[1].bitmap == NULL) {
		LineTo(hdc, 0, 0);
		LineTo(hdc, r.right-1, 0);
	}
	
	//Taskbar skin
	SelectObject(hdc, old);
	DeleteObject(pen);
}

// -------------------------------------------------------------------------------------------------------
// Draws a normal button
// -------------------------------------------------------------------------------------------------------
void LSTaskButton::drawPopped(HDC hdc, RECT r, HWND hwnd, HWND user) {
	HPEN old, pen;
	int clr1, clr2;
	
	if (settings->newStyle) 
		clr1 = settings->fore2; 
	else 
		clr1 = GetSysColor(COLOR_3DDKSHADOW);
	if (settings->newStyle) 
		clr2 = settings->fore; 
	else 
		clr2 = GetSysColor(COLOR_3DHILIGHT);
	pen = CreatePen(PS_SOLID, 1, clr1);
	fillButton(hdc, hwnd, 0, r, user);
	old = (HPEN)SelectObject(hdc, pen);
	MoveToEx(hdc, r.right-1, 0, NULL);
	//Taskbar skin
	if (settings->taskbtnskinBMP[0].bitmap == NULL) {
		LineTo(hdc, r.right-1, r.bottom-1);
		LineTo(hdc, 0, r.bottom-1);
	}
	//Taskbar skin
	SelectObject(hdc, old);
	DeleteObject(pen);
	pen = CreatePen(PS_SOLID, 1, clr2);
	old = (HPEN)SelectObject(hdc, pen);
	//Taskbar skin
	if (settings->taskbtnskinBMP[0].bitmap == NULL) {
		LineTo(hdc, 0, 0);
		LineTo(hdc, r.right-1, 0);
	}
	//Taskbar skin
	SelectObject(hdc, old);
	DeleteObject(pen);
}

// -------------------------------------------------------------------------------------------------------
// Fills the inside of a button with its icon & title
// -------------------------------------------------------------------------------------------------------
void LSTaskButton::fillButton(HDC hdc, HWND hwnd, int shift, RECT r, HWND user)
{
	int shiftText, shiftBg;
	//Taskbar skin
	HDC tmpDC;
	HBITMAP tmpBitmap, oldBMP, tBMP;
	tmpBitmap = CreateCompatibleBitmap( hdc, r.right, r.bottom );
	tmpDC = CreateCompatibleDC(hdc);
	oldBMP = (HBITMAP)SelectObject(tmpDC, tmpBitmap);
	
	shiftText = shiftBg = shift;
	if (settings->TaskbarNoTextShift == TRUE) 
		shiftText = 0;
	if (settings->TaskbarNoSkinShift == TRUE) 
		shiftBg = 0;
	//Taskbar skin
	if (settings->taskBMP.bitmap == NULL) {
		if (!settings->newStyle) {
			int tempclr = GetSysColor(COLOR_3DFACE);
			HBRUSH brush = CreateSolidBrush(tempclr);
			FillRect(tmpDC, &r, brush);
			DeleteObject(brush);
		} else {
			HBRUSH brush = CreateSolidBrush(settings->back);
			FillRect(tmpDC, &r, brush);
			DeleteObject(brush);
		}
	} else {
		HDC memDC;
		RECT r1;
		
		memDC = CreateCompatibleDC(hdc);
		tBMP = (HBITMAP)SelectObject(memDC, settings->taskBMP.bitmap);
		GetWindowRect(hwnd, &r1);
		BitBlt(tmpDC, r.left+shiftBg, r.top+shiftBg, r.right-shiftBg, r.bottom-shiftBg, memDC, r1.left, 3,SRCCOPY);
		SelectObject(memDC, tBMP);
		DeleteDC(memDC);
	}
	if (settings->taskbtnskinBMP[shift].bitmap != NULL) {
		HDC memDC;
		int xpos = r.left+shiftBg+settings->taskbtnleftBMP[shift].x,
			ypos = r.top+shiftBg;
		
		memDC = CreateCompatibleDC(hdc);
		tBMP = (HBITMAP)SelectObject(memDC, settings->taskbtnskinBMP[shift].bitmap);
		while (ypos < r.bottom) {
			xpos = r.left+shiftBg+settings->taskbtnleftBMP[shift].x;
			while (xpos < r.right-settings->taskbtnrightBMP[shift].x) {
				int drawxpos = settings->taskbtnskinBMP[shift].x;
				while (xpos + drawxpos > r.right-settings->taskbtnrightBMP[shift].x) 
					drawxpos--;
				TransparentBltLS(tmpDC, xpos, ypos, drawxpos, settings->taskbtnskinBMP[shift].y, memDC, 0, 0, RGB(255,0,255));
				xpos += settings->taskbtnskinBMP[shift].x;
			}
			ypos += settings->taskbtnskinBMP[shift].y;
		}
		SelectObject(memDC, tBMP);
		DeleteDC(memDC);
	}
	if (settings->taskbtnleftBMP[shift].bitmap != NULL) {
		HDC memDC;
		int xpos = r.left+shiftBg,
			ypos = r.top+shiftBg;
		memDC = CreateCompatibleDC(hdc);
		tBMP = (HBITMAP)SelectObject(memDC, settings->taskbtnleftBMP[shift].bitmap);
		while (ypos < r.bottom) {
			TransparentBltLS(tmpDC, xpos, ypos, settings->taskbtnleftBMP[shift].x, settings->taskbtnleftBMP[shift].y, memDC, 0, 0, RGB(255,0,255));
			ypos += settings->taskbtnleftBMP[shift].y;
		}
		SelectObject(memDC, tBMP);
		DeleteDC(memDC);
	}
	if (settings->taskbtnrightBMP[shift].bitmap != NULL) {
		HDC memDC;
		int xpos = r.right-settings->taskbtnrightBMP[shift].x,
			ypos = r.top+shiftBg;
		memDC = CreateCompatibleDC(hdc);
		tBMP = (HBITMAP)SelectObject(memDC, settings->taskbtnrightBMP[shift].bitmap);
		while (ypos < r.bottom) {
			TransparentBltLS(tmpDC, xpos, ypos, settings->taskbtnrightBMP[shift].x, settings->taskbtnrightBMP[shift].y, memDC, 0, 0, RGB(255,0,255));
			ypos += settings->taskbtnrightBMP[shift].y;
		}
		SelectObject(memDC, tBMP);
		DeleteDC(memDC);
	}
	BitBlt(hdc, 0, 0, r.right, r.bottom, tmpDC, 0, 0,SRCCOPY);
	SelectObject(tmpDC, oldBMP);
	DeleteDC(tmpDC);
	DeleteObject(tmpBitmap);

	char txt[256];
	HFONT oldFont, hf;
	RECT r2;
	SIZE s;
	
	StretchBlt(owner->owner->bufferDC, 0, 0, 32, 32, hdc, 4+shiftText, 4+shiftText, settings->trayIconSize, settings->trayIconSize, SRCCOPY);
	DrawIconEx(owner->owner->bufferDC, 0, 0, icon, 32, 32, 0, NULL, DI_NORMAL);
	StretchBlt(hdc, 4+shiftText, 3+shiftText, settings->trayIconSize, settings->trayIconSize, owner->owner->bufferDC, 0, 0, 32, 32, SRCCOPY);
	r2 = r;
	hf = (HFONT)GetStockObject(ANSI_VAR_FONT); 
	oldFont = (HFONT)SelectObject(hdc, hf); 
	SetBkMode(hdc, TRANSPARENT);
	GetWindowText(user, txt, 255);
	r2.left += 8+settings->trayIconSize+shiftText;
	r2.top += shiftText;
	if (settings->newStyle)
		SetTextColor(hdc, settings->text);
	else
		SetTextColor(hdc, GetSysColor(COLOR_BTNTEXT));
	DrawText(hdc, txt, strlen(txt), &r2, DT_LEFT | DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
	GetTextExtentPoint32(hdc, txt, strlen(txt), &s);
	if (s.cx > r.right - (settings->trayIconSize+8+shiftText+1))
		needTooltip = TRUE;
	else
		needTooltip = FALSE;
	SelectObject(hdc, oldFont);
}

// -------------------------------------------------------------------------------------------------------
// Gets a RECT for a task button
// -------------------------------------------------------------------------------------------------------
void LSTaskBar::GetWinRect(HWND wnd, RECT *r)
{
	RECT r1;
	RECT r2;
	
	GetWindowRect(wnd, &r1);
	GetWindowRect(GetParent(wnd), &r2);
	r->left = r1.left-r2.left;
	r->right = r1.right - r2.left;
	r->top = r1.top - r2.top;
	r->bottom = r1.bottom - r2.top;
}

// -------------------------------------------------------------------------------------------------------
// Get window title checksum
// -------------------------------------------------------------------------------------------------------
int LSTaskBar::getTxtSum(HWND wnd)
{
	char txt[256];
	int c=0;
	char *p = txt;
	GetWindowText(wnd, txt, 255);
	while (*p) c += *p++;
	return c;
}


void LSTaskBar::getRectangle(LPRECT r) {
	GetClientRect(hTasksWnd, r);
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for task buttons container windows
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK LSTaskBar::WndProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LSTaskBar *theTaskBar = (LSTaskBar*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theTaskBar) {
		return theTaskBar->WindowProcTasks(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT LSTaskBar::WindowProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(desktopParent,message,wParam,lParam);
	case WM_CREATE:		return 0;
	case WM_ERASEBKGND: return 0;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
            RECT r;
			HBITMAP oldBMP;
			
            GetClientRect(hwnd, &r);
            {
                HBRUSH br;
                int clr;
				
                if (settings->newStyle) 
					clr = settings->back; 
				else 
					clr = GetSysColor(COLOR_BTNFACE);
				if (settings->taskBMP.bitmap == NULL) {
					br = CreateSolidBrush(clr);
					FillRect(hdc, &r, br);
					DeleteObject(br);
				} else {
					RECT r1; //Taskbar skin
					HDC memDC;
					
					memDC = CreateCompatibleDC(hdc);
					oldBMP = (HBITMAP)SelectObject(memDC, settings->taskBMP.bitmap);
					GetWindowRect(hwnd, &r1);
					BitBlt(hdc, r.left, r.top, r.right, r.bottom, memDC, r1.left, 3,SRCCOPY);
					SelectObject(memDC, oldBMP);
					DeleteDC(memDC);
				}
            }
			EndPaint(hwnd,&ps);
		}
		updateTasksView(FALSE);
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		{	
			PostMessage(desktopParent,message,wParam,lParam);
		}
		return 0;
	case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(desktopParent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				return DefWindowProc(hwnd,message,wParam,lParam);
			}
		}
	case LM_ADDWINDOW:
		if (owner->settings.appBar) {
			BOOL i;
			i = inWinList((HWND)wParam);
			if (!i) {
				addWindow((HWND)wParam);
			}
		}
		break;
	case LM_REMOVEWINDOW:
		if (owner->settings.appBar) {
			BOOL i;
			i = inWinList((HWND)wParam);
			if (i) {
				RemoveWindow((HWND)wParam);
			}
		}
		break;
	case LM_REDRAW:
		if (owner->settings.appBar) {
			hwnd2LSTaskButton::iterator iter;
			iter = taskBtn.find((HWND)wParam);
			if (iter != taskBtn.end()) {
				iter->second->Repaint();
			}
		}
		break;
    }
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

LSTaskButton::LSTaskButton(HWND wnd, LSTaskBar *owner) {
	hWnd = NULL;
	icon = NULL;
	txtSum = NULL;
	window = wnd;
	settings = owner->settings;
	this->owner = owner;
	current = FALSE;
	btnDrag = FALSE;

	hWnd = CreateWindowEx(
		WS_EX_ACCEPTFILES,										// exstyles 
		szAppBtn,		    					// our window class name
		"",					    				// use description for a window title
		WS_CHILD,	
		0, 0,									// position 
		4, 2,									// width & height of window
		owner->hTasksWnd,								// parent window (winamp main window)
		NULL,									// no menu
		owner->dll,						    		// hInstance of DLL
		NULL);									// no window creation data

	SetWindowLong(hWnd, LS_GWL_CLASSPOINTER, (LONG)this);
	
	if (!hWnd) {
		MessageBox(owner->desktopParent,"Error creating window",szAppBtn,MB_OK);
	} else {
		ShowWindow(hWnd,SW_SHOWNORMAL);
		SetWindowLong(hWnd, GWL_USERDATA, (long)window);
		icon = CopyIcon(GetWindowIcon(window));
		char tooltip[256];
		//owner->owner->toolTips->CreateTooltip(hWnd, tooltip, &r);
    }
}

LSTaskButton::~LSTaskButton() {
	if (IsWindow(hWnd)) {
		DestroyWindow(hWnd); // delete our window
	}

	DestroyIcon(icon);
}

void LSTaskButton::Repaint()
{
	PAINTSTRUCT ps;
    HWND user;
	HDC hdc = BeginPaint(hWnd,&ps);
    RECT r;
    GetClientRect(hWnd, &r);
    
	user = (HWND)GetWindowLong(hWnd, GWL_USERDATA);

    if (current)
        drawPushed(hdc, r, hWnd, user);
    else
        drawPopped(hdc, r, hWnd, user);
	
	EndPaint(hWnd,&ps);
}
