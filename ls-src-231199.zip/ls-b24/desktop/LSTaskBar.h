#ifndef LSTASKBAR
#define LSTASKBAR

class LSBar;

class LSTaskButton {
public:
    HWND hWnd;
    HICON icon;
    int txtSum;
	HWND tooltipWnd;
	BOOL needTooltip;
	HWND targetWnd;
};

class LSTaskBar {
	HWND desktopParent;
	LSSettings *settings;

	LSTaskButton *taskBtn;

	int nWin, maxWin;

	BOOL btnDrag;
	RECT dragRect;
	BOOL lastStatePushed;
	HDC dragDC;
	HWND dragUser;

	HINSTANCE dll;

	LSBar *owner;

	HWND hWndParent;
	windowType *winList;

	HWND currentWindow;
public:
	int ScreenHeight;
	HWND hTasksWnd;

	LSTaskBar(LSBar *theDesktop);
	static LRESULT CALLBACK WndProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	virtual ~LSTaskBar();
	void addWindow(HWND hwnd);
	void integrateWindow(HWND hwnd);
	static BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
	void RemoveWindow(int win);
	int inWinList(HWND hwnd);
	void updateTasksView(int force);
	HICON GetWindowIcon(HWND Hwnd);
	void destroyAppWnd(int i);
	void drawPushed(HDC hdc, RECT r, HWND hwnd, HWND user);
	void drawPopped(HDC hdc, RECT r, HWND hwnd, HWND user);
	void fillButton(HDC hdc, HWND hwnd, int shift, RECT r, HWND user);
	int getTxtSum(HWND wnd);
	void getRectangle(LPRECT r);
	void GetWinRect(HWND wnd, RECT *r);
private:
	int ScreenWidth;
};

#endif