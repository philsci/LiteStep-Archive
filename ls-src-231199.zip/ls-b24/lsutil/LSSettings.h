// all settings for litestep.

#ifndef LSSETTINGS
#define LSSETTINGS

#include "../lsutil/LSBitmap.h"

class LSSettings {
public:
	int trayIconSize;

	int autoHideDelay;

	// disable default systray -- Maduin
	BOOL fNoSystray;
	BOOL isShell;
	BOOL dockToWharf;
	BOOL setDesktopArea;
    BOOL autoHideWharf;
	int sysTrayRight, sysTrayBottom, sysTrayVertical, sysTrayWrap;
	int sdaLeft, sdaRight, sdaBottom, sdaTop;
	
    BOOL autoHide;
	BOOL startButton;
   	LSBitmap taskBMP;

	BOOL appBar;
	
	BOOL newStyle;
	int stripBar;
	int startButtonSize;
	char startButtonText[256];
	char startButtonImage[MAX_PATH];

	int fore, fore2, back, text;

	LSBitmap taskbtnskinBMP[2], taskbtnleftBMP[2], taskbtnrightBMP[2],
		tasktrayskinBMP, tasktrayleftBMP, tasktrayrightBMP,
		startbuttonskinBMP, startbuttonleftBMP, startbuttonrightBMP;

	BOOL TaskbarNoTextShift;
	BOOL TaskbarNoSkinShift;
	char TaskbarSkin[256];
	char TaskbtnSkin[256];
	char TaskbtnSkinActive[256];
	char TaskbtnLeft[256];
	char TaskbtnLeftActive[256];
	char TaskbtnRight[256];
	char TaskbtnRightActive[256];
	char TasktraySkin[256];
	char TasktrayLeft[256];
	char TasktrayRight[256];
	char StartButtonSkin[256];
	char StartButtonLeft[256];
	char StartButtonRight[256];
		
	int sysTrayOffset;
public:
	LSSettings();
	int loadSettings();
};

#endif //!defined LSSETTINGS