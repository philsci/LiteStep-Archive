#ifndef LSBITMAP
#define LSBITMAP

#include <windows.h>

#define MAX_TEXT 256

//simple bitmap class
class LSBitmap {
public:
	HBITMAP bitmap;
	HRGN region;
	char name[MAX_TEXT];
	int x;
	int y;
	COLORREF backColor;
	COLORREF foreColor;

	LSBitmap();
	~LSBitmap() {destroy();}
protected:
	void destroy();
};

#endif //!defined LSBITMAP