// LSUtilities.cpp: implementation of the LSUtilities class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include "LSUtilities.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

LSUtilities::LSUtilities() {

}

LSUtilities::~LSUtilities() {

}

int LSUtilities::GetScreenWidth() {
	return GetSystemMetrics(SM_CXSCREEN);
}

int LSUtilities::GetScreenHeight() {
	return GetSystemMetrics(SM_CYSCREEN);
}
