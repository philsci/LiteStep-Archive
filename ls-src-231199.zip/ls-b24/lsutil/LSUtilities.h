// LSUtilities.h: interface for the LSUtilities class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LSUTILITIES_H__7332BED2_93A5_11D3_8E9D_0008C75CA3DB__INCLUDED_)
#define AFX_LSUTILITIES_H__7332BED2_93A5_11D3_8E9D_0008C75CA3DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class LSUtilities  
{
public:
	static int GetScreenHeight();
	static int GetScreenWidth();
	LSUtilities();
	virtual ~LSUtilities();

};

#endif // !defined(AFX_LSUTILITIES_H__7332BED2_93A5_11D3_8E9D_0008C75CA3DB__INCLUDED_)
