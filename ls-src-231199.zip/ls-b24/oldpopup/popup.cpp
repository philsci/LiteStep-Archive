 /*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/****************************************************************************
 12/20/98 - Fahim Farook
			Perfected subfolder pinning via a double-click on the titlebar and
			pinned popup closing via a click on the close button
 12/19/98 - Fahim Farook
			Removed the subList structure and modified popup navigation to use a
			linked list created via parent & child relationships
 12/10/98 - Fahim Farook
			Rewrote most of the popup code so that it used a single popup structure
			and was more object oriented
 12/02/98 - Fahim Farook
			Added fixed width popup menu support via PopupFixedWidth in step.rc
 12/01/98 - Fahim Farook
			Fixed the popups crashing on moving cursor to bottom pic bug
 11/24/98 - Edwin Man
            Changed default PopupNormalColor to A4A0A0; looks better
 11/24/98 - Fahim Farook
			Changed the popup navigation code to use standardized item heights
			so that the code is more readable and faster
 11/23/98 - Fahim Farook
			Streamlined the transparency code and made it setup and load the 
			region at start up then just set the region when a popup is created
 11/21/98 - Fahim Farook
			Added a working close button to the main popup when pinned
			Modified keyboard navigation so that left and right key functionality
			switches when the current folder is to the left of it's parent
 11/19/98 - Fahim Farook
			Modified popup displaying so that if a popup opens on the left all 
			subfolders will keep on opening to the left so as to avoid the
			clutter that resulted in earlier implementations
			Added the ability to specify colours instead of bitmaps for popup
			background via PopupTitleBack, PopupNormBack & PopupSelBack in
			step.rc
 11/18/98 - Fahim Farook
			Modified icon extraction based on code by Johan Redestig to make it
			more efficient and added an icon deletion routine when quitting to 
			free up resources.
 11/14/98 - Fahim Farook
			Added popup icons via ShowPopupIcons in step.rc and allowed customization
			via PopupDefaultIcon and PopupIconSize
 11/12/98 - Fahim Farook
			Added popup pinning functionality to the main popup and changed
			mouse click responses from LBUTTONDOWN to LBUTTONUP
 11/09/98 - Fahim Farook
			Merged in popup transparency code provided by mian and took out the
			old transparentBltLS stuff
 11/08/98 - Fahim Farook
			Added dynamic popup width sizing support & dynamic folder support
			via the !PopupDynamicFolder command
 11/08/98 - J Redestig
			Sets working directory. Added three utility functions for cleaner
			code (paintFolderArrow, paintPopupBevel, executeItem). Removed
			some flicker from displaySingleItem
 10/31/98 - Fahim Farook
			Added support for popup menu navigation via keyboard
 10/29/98 - Cyberian (Fahim Farook)
			Added support for popupmenu height customization. The title bar
			wouldn't change sizes earlier - now takes its value from PopupSubMenuHeight
			in step.rc
 09/11/98 - M. West
    		New popups created, limited functionality, will parse in a simple
    		1 layer popup menu, and run programs from it,
 30/10/98 - B. Kilian
			Fixed Fixed the popups repainting problem, and the setWindowPos 
			in the paint.
 30/10/98 - J Redestig
			Setforegroundwindow, so the popups get focus correctly, and <ESC> exits popups.
 30/10/98 - T Engel
			Environment substitution for !PopupFolders

****************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include <tchar.h>
#include <process.h>
#include "popup.h"

const char rcsRevision[] = "$Revision: 1.4 $"; // Our Version 
const char rcsId[] = "$Id: popup.cpp,v 1.4 1999/09/16 12:52:55 maduin Exp $"; // The Full RCS ID.
char popupFontFace[256];
char popupMenuName[256];
const char szAppName[] = "PopupMenu"; // Our window class, etc

int popupSubHeight = 20;
int popupMinWidth = 100;
int popupIconSize = 20;
int titleHeight = 20;
int popupFixedWidth = 0;
int popupLevel = 0;
int popupMenuDelay = 0;
int popupFontHeight;
int popupTextOffset;
int popupTop;
int popupID = 9999;

menuItem *timerPointer = NULL;

HFONT popupFont;
HICON popupDefaultIcon;
COLORREF titleColor, selColor, normColor;
COLORREF titleBack,selBack, normBack;
WNDCLASS wc;

Popup popup; //popup class struct
fileItem *popupFile, *treeItem;  //rc file info holder

HINSTANCE appInstance;
HWND itemCaller = NULL;
HWND parentWin;
HWND hMainWnd = NULL;

BOOL noPopupBevel;
BOOL noPopupPix = FALSE;
BOOL transBlt=TRUE;
BOOL popupFolderIcon=TRUE;
BOOL showPopupIcons = FALSE;
BOOL isFixedWidth = FALSE;
BOOL shrinkPopupBar = FALSE;

BitMP backBMP;
BitMP titleBMP;
BitMP selectBMP;
BitMP bottomBMP;

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
int fillDirectory(char *dirName, menuItem *target, BOOL oneLevel=FALSE);
void initializePopupMenu();
void executeItem(menuItem* pItem);
void GetItemIcon(void *item);
void RegistryLookup(char* subKey, char *value);
void buildPopupTree(Popup *pop);
void buildTaskList(menuItem *target);
void setPopupValues(Popup *pop);
void buildPopup(Popup *pop, BOOL rebuild=FALSE);
void deletePopup(Popup *pop);
void paintItem(menuItem *item, DRAWITEMSTRUCT *di);
LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
menuItem *GetItem(Popup *pop, int num);
HRGN GetRegion(menuItem *item);

////////////////////////////////////////////////////////////////////////////////
//BEGIN CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////

menuItem::~menuItem() {
   	if(next != NULL)
   		delete next;
   	if(SMenu != NULL)
   		delete SMenu;
	if (hIcon != NULL)
		DeleteObject(hIcon);
}

fileItem::fileItem()
{
    strcpy(itemName, "\0");
    strcpy(bmpName, " ");
    strcpy(popupCommand, " ");
    next = NULL;
    itemHeight = popupSubHeight;
}

fileItem::~fileItem()
{
    delete next;
}


BOOL Popup::newMenuItem()
{
    menuItem *temp = root;
    
    while(1) //finds the last node in the list
    {
    	if(temp == NULL)
    		break;
		else if(temp->next == NULL) {
    		break;
		} else {
			temp = temp->next;
		}
    }
    
    if(temp == NULL)
    {
    	root = new menuItem;
    	current = root;
    }
    else 
    {
    	temp->next = new menuItem;
    	current = temp->next;
    }
    
    return(TRUE);
}

////////////////////////////////////////////////////////////////////////////////
//END CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////

menuItem *GetItem(Popup *pop, int num) {
	menuItem *val;
	menuItem *temp = pop->root;
	while (temp != NULL) {
		if (temp->SMenu != NULL) {
			val = GetItem(temp->SMenu, num);
			if (val != NULL)
				return val;
		}
		if (temp->ID == num)
			return temp;
		temp = temp->next;
	}
	return NULL;
}

//cleanup, not much to do
int quitModule(HINSTANCE dllInst)
{
    DestroyWindow(hMainWnd);
    DeleteObject(popupFont);
	if (titleBMP.bitmap)
		DeleteObject(titleBMP.bitmap);
	if (backBMP.bitmap)
		DeleteObject(backBMP.bitmap);
	if (selectBMP.bitmap)
		DeleteObject(selectBMP.bitmap);
	if (bottomBMP.bitmap)
		DeleteObject(bottomBMP.bitmap);
	if (showPopupIcons) {
		DeleteObject(popupDefaultIcon);
	}
    UnregisterClass(szAppName,dllInst); // unregister window class
    return 1;
}

//now defunct entry point, will take it out if somone complains
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
    return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

//DLL entry point
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
    appInstance = dllInst;
    parentWin = ParentWnd;

    //parse file and fill popup class structure
    initializePopupMenu();
    
    memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc = (WNDPROC)wndProc;// our window procedure
    //wc.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wc.hInstance = appInstance;			
    wc.lpszClassName = szAppName;// our window class name
    wc.style = 0;

    if (!RegisterClass(&wc)) 
    {
    	MessageBox(NULL,"Error registering window class",szAppName,MB_OK);
    	return 1;
    }
	hMainWnd = CreateWindowEx(
			WS_EX_TOOLWINDOW|WS_EX_TOPMOST,
			szAppName,
			"",
			WS_POPUP|WS_SYSMENU,
			0, 0,
			1024, 768,
			NULL,
			NULL,
			appInstance,
			NULL
			);
    SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);

    //create the message id's that popup.dll will use
    int Msgs[10];
    Msgs[0] = LM_POPUP;
    Msgs[1] = LM_HIDEPOPUP;
    Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
    SendMessage (ParentWnd, LM_REGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	
    return 0;
}

void executeItem(menuItem* pItem)
{
	if (!stricmp(pItem->command, "t@sk")){
		windowType *winList;
		HWND hwnd;
		char title[MAX_PATH];
		int maxWin;

		winList = (windowType *)SendMessage(parentWin, LM_WINLIST, 0, 0);
		maxWin = (int) SendMessage(parentWin, LM_WINLIST, 1, 0);
		for (int n = 0; n < maxWin && winList[n].Handle; n++) {
			hwnd = winList[n].Handle;
			GetWindowText(hwnd, (char *)&title, MAX_PATH);
			if (!strcmp(pItem->name, (char *)&title)){
				if (IsIconic(hwnd))
					OpenIcon(hwnd);
				SetForegroundWindow(hwnd);
				break;
			}
		}
	} else {
		/*
    SHELLEXECUTEINFO si;
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];
		char fname[_MAX_FNAME]; // not used
		char ext[_MAX_EXT]; // not used

		_splitpath(pItem->command, drive, dir, fname, ext);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);

		ZeroMemory(&si, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);

		if(stricmp(ext, ".lnk") == 0)
			// the link files contain their own directory and
			// we should not force any other directory upon it.
			si.lpDirectory = NULL;
		else
			// .exe, .com, .bat, ... often need to be executed from their
			// directory
			si.lpDirectory = workDirectory;
		
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = pItem->command;
		si.lpParameters = pItem->params;
		ShellExecuteEx(&si);
    */

    char workDirectory[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR], ext[_MAX_EXT];

    _splitpath(pItem->command, drive, dir, NULL, ext);
    strcpy(workDirectory, drive);
    strcat(workDirectory, dir);

    LSExecuteEx(NULL, NULL, pItem->command, pItem->params, !stricmp(ext, ".lnk") ? NULL : workDirectory, SW_SHOWNORMAL);
	}
}

void initializePopupMenu() 
{
    FILE *f = NULL;
    char buffer[4096];
    char token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], extra_text[4096];
    char* tokens[5];
	char iname[MAX_PATH];
    fileItem * item = popupFile;
    
    GetRCString("HotListName", popupMenuName, "", 256);
    GetRCString("PopupTitlePix", titleBMP.name	, "", 256);
    GetRCString("PopupEntryPix", backBMP.name	, "", 256);
    GetRCString("PopupSelEntryPix", selectBMP.name	, "", 256);
	GetRCString("PopupBottomPix", bottomBMP.name, "", 256);
    GetRCString("PopupFontFace", popupFontFace, "Arial", 256);
	if (strlen(titleBMP.name)==0 || strlen(backBMP.name)==0 || strlen(selectBMP.name)==0) 
		noPopupPix = TRUE;
	popupFolderIcon = GetRCBool("NoPopupFolderIcon", FALSE);
	transBlt = GetRCBool("NoPopupTransparent", FALSE);
    noPopupBevel = GetRCBool("NoPopupBevel", TRUE);
    popupFontHeight = GetRCInt("PopupFontHeight", 16);
    titleColor = GetRCColor("PopupTitleColor", 0xffffff);
    normColor = GetRCColor("PopupEntryColor", 0x000000);
    selColor = GetRCColor("PopupSelEntryColor", 0x000000);
    popupMenuDelay = GetRCInt("PopupMenuDelay",0);
    popupMinWidth = GetRCInt("minpopupwidth", 100);
    popupSubHeight = GetRCInt("PopupSubmenuHeight", 20);
	titleHeight = GetRCInt("PopupSubmenuHeight", 20);
	popupFixedWidth = GetRCInt("PopupFixedWidth", 0);
	isFixedWidth = popupFixedWidth==0?FALSE:TRUE;
	popupTextOffset = GetRCInt("PopupTextOffset", 5);
	showPopupIcons = GetRCBool("ShowPopupIcons", TRUE);
	if (showPopupIcons) {
		popupIconSize = GetRCInt("PopupIconSize", 20);
		GetRCString("PopupDefaultIcon", iname, "default.ico", 256);
		popupDefaultIcon = LoadLSIcon(iname, NULL);
		popupIconSize = popupIconSize>popupSubHeight?popupSubHeight:popupIconSize;
		popupTop = (popupSubHeight-popupIconSize)/2;
	} else 
		popupIconSize = 0;
	// Bottom bitmap is loaded as there is no setting to indicate whether it is drawn or not - yet ...
	bottomBMP.bitmap = LoadLSImage(bottomBMP.name, NULL);
	if (!noPopupPix) {
	    //loads up images i will eventualy seperate this into its own function
		backBMP.bitmap = LoadLSImage(backBMP.name, NULL);
	    titleBMP.bitmap = LoadLSImage(titleBMP.name, NULL);
		selectBMP.bitmap = LoadLSImage(selectBMP.name, NULL); 

	    GetLSBitmapSize(selectBMP.bitmap, &selectBMP.x, &selectBMP.y);
		GetLSBitmapSize(backBMP.bitmap, &backBMP.x, &backBMP.y);
	    GetLSBitmapSize(titleBMP.bitmap, &titleBMP.x, &titleBMP.y);
		GetLSBitmapSize(bottomBMP.bitmap, &bottomBMP.x, &bottomBMP.y);

		//mian's transparency stuff
		selectBMP.region = BitmapToRegion(selectBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		titleBMP.region = BitmapToRegion(titleBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		backBMP.region = BitmapToRegion(backBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		bottomBMP.region = BitmapToRegion(bottomBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0); 
		//Bitmap shrink/tile option
		shrinkPopupBar = GetRCBool("ShrinkPopupBar", TRUE);
	} else {
	    titleBack = GetRCColor("PopupTitleBack", 0x000000);
            normBack = GetRCColor("PopupNormalBack", 0xa4a0a0);
	    selBack = GetRCColor("PopupSelBack", 0xffffff);
	}

    popupFile = new fileItem;
    item = popupFile;

    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;
    tokens[3] = token4;
    tokens[4] = token5;

    buffer[0] = 0;
    f = LCOpen (NULL);
    int keeper = 0;
    
    while (LCReadNextConfig (f, "*popup", buffer, sizeof (buffer)))
    {
     	int count = 0, count2 = 0;
    	char truly_extra_text[4096];
    	if(keeper == 0)
    		keeper = 1;
    	else
    	{
    		item->next = new fileItem;
    		item = item->next;
    	}
    	token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = extra_text[0] = truly_extra_text[0] = '\0';
    	count = LCTokenize (buffer, tokens, 3, extra_text);
    	
    	switch (count)
    	{
    	case 3:											// *Popup
    		strcpy(item->itemName, token2);				// "Name"
    		if (atoi(token3))
    		{
    			item->itemHeight = atoi(token3);			// Height
    			count2 = LCTokenize(extra_text, tokens, 2, truly_extra_text);
    			strcpy(item->bmpName, token1);				// Bitmap.bmp
    			strcpy(item->popupCommand, token2);			// Command.exe
    			strcpy(item->commandParam, truly_extra_text);		// -command_params
    		}
    		else
    		{
    			item->itemHeight = popupSubHeight;
    			strcpy(item->bmpName, backBMP.name);
    			if (!stricmp(token3, "Folder"))
    			{
    				strcpy(item->popupCommand, "!Folder");
    			}
    			else
    			{
    				strcpy(item->popupCommand, token3);
    			}
    			strcpy(item->commandParam, extra_text);
    		}
    		break;

    	case 2:
    		strcpy(item->popupCommand, token2);
    	}
    }		
    LCClose(f);
    //copys the popupFile structure into our popup strucure
    //in later revisions error checking will go here
    treeItem = popupFile;
	buildPopupTree(&popup);

    popupFont = CreateFont(
    		popupFontHeight,
    		0,
    		0,
    		0,
    		FW_NORMAL,
    		FALSE,
    		FALSE,
    		FALSE,
    		DEFAULT_CHARSET,
    		OUT_DEFAULT_PRECIS,
    		CLIP_DEFAULT_PRECIS,
    		DEFAULT_QUALITY,
    		DEFAULT_PITCH,
    		popupFontFace);

	if (showPopupIcons)
		_beginthread(GetItemIcon, 0, popup.root);
	buildPopup(&popup);
}

void buildPopup(Popup *pop, BOOL rebuild) {
	MENUITEMINFO min;
	int index = 0;
    menuItem *iTemp = pop->root;

	if (!rebuild)
		pop->hmenu = pop->root->itemLevel==0?CreatePopupMenu():CreateMenu();
    while(iTemp != NULL)
    {
		ZeroMemory(&min, sizeof(min));
		min.cbSize = sizeof(min);
		if (iTemp->SMenu != NULL) {
			buildPopup(iTemp->SMenu);
			min.fState = MFS_ENABLED;
			min.fType = MFT_STRING | MFT_OWNERDRAW;
			min.fMask = MIIM_TYPE | MIIM_STATE | MIIM_SUBMENU | MIIM_ID;
			min.hSubMenu = iTemp->SMenu->hmenu;
			min.dwTypeData = iTemp->name;
			min.wID = popupID;
		} else {
			if (iTemp->isBar == 1 || iTemp->isBar == 2) {
				min.fMask = MIIM_TYPE | MIIM_ID;
				min.fType = MFT_SEPARATOR | MFT_OWNERDRAW;
//				min.fState = MFS_GRAYED;
				min.wID = popupID;
			} else {
				min.fState = MFS_ENABLED;
				min.fType = MFT_STRING | MFT_OWNERDRAW;
				min.fMask = MIIM_TYPE | MIIM_STATE | MIIM_ID;
				min.dwTypeData = iTemp->name;
				min.wID = popupID;
			}
		}
		iTemp->ID = popupID;
		popupID--;
	    InsertMenuItem(pop->hmenu,index,FALSE, &min);
    	iTemp = iTemp->next;
		index++;
    }
}

void deletePopup(Popup *pop) {
	menuItem *temp = pop->root;

	while (temp != NULL) {
		if (temp->SMenu != NULL) {
			deletePopup(temp->SMenu);
		}
		DeleteMenu(temp->Menu->hmenu, temp->ID, MF_BYCOMMAND);
		temp = temp->next;
	}
}

void buildPopupTree(Popup *pop) {
	int count = 1;

	pop->newMenuItem();
	strcpy(pop->current->name, popupLevel==0?popupMenuName:" ");
	pop->current->itemLevel = popupLevel;
	pop->current->isBar = 1;
    while(treeItem != NULL) {
    	if(treeItem == NULL || !stricmp(treeItem->popupCommand, "~folder"))
    		break;
    	
    	pop->newMenuItem();
    	strcpy(pop->current->name, treeItem->itemName);
    	strcpy(pop->current->command, treeItem->popupCommand);
    	strcpy(pop->current->bmp, treeItem->bmpName);
    	strcpy(pop->current->params, treeItem->commandParam);
    	pop->current->itemLevel = popupLevel;
    	if(!strncmp(pop->current->command, "!PopupFolder", 12))
    	{
			char temp[MAX_PATH], real[MAX_PATH];
			strcpy(temp, pop->current->command+13);
			popupLevel++;
			ExpandEnvironmentStrings(temp, real, sizeof(real));
			fillDirectory(real, pop->current);
			popupLevel--;
			pop->current->hIcon = popupDefaultIcon;
    	}
		else if(!strncmp(pop->current->command, "!PopupDynamicFolder", 19))
		{
			char temp[MAX_PATH], real[MAX_PATH];
			pop->current -> isDynamic = TRUE;
			strcpy(temp, pop->current->command+20);
			popupLevel++;
			ExpandEnvironmentStrings(temp, real, sizeof(real));
			//Get the full directory structure the first time ...
			fillDirectory(real, pop->current);
			popupLevel--;
			pop->current->hIcon = popupDefaultIcon;
		}
		else if(!strncmp(pop->current->command, "!PopupTasks", 11))
		{
			pop->current -> isDynamic = TRUE;
			pop->current->hIcon = popupDefaultIcon;
			popupLevel++;
			buildTaskList(pop->current);
			popupLevel--;
		}
    	else if(!strncmp(pop->current->command, "!Folder", 7))
    	{
			pop->current->hIcon = popupDefaultIcon;
			Popup *sub = new Popup();
			pop->current->SMenu = sub;
			popupLevel++;
			treeItem = treeItem->next;
			buildPopupTree(sub);
			popupLevel--;
		} 
		if (treeItem != NULL)
    		treeItem = treeItem->next;
		count++;
    }
	if (bottomBMP.bitmap) {
		pop->newMenuItem();
		strcpy(pop->current->name, " ");
		pop->current->isBar = 2;
	}
	setPopupValues(pop);
}

void buildTaskList(menuItem *target) {
	windowType *winList;
	char title[MAX_PATH];
	BOOL noList = TRUE;
	int n, maxWin;

	target->SMenu = new Popup;
	target->SMenu->newMenuItem();
	strcpy(target->SMenu->current->name, "TaskList");
	target->SMenu->current->itemLevel = popupLevel;
	target->SMenu->current->isBar = 1;

	winList = (windowType *)SendMessage(parentWin, LM_WINLIST, 0, 0);
	maxWin = (int) SendMessage(parentWin, LM_WINLIST, 1, 0);
	for (n = 0; n < maxWin && winList[n].Handle; n++)
	{
		HICON hIcon = NULL;
		noList = FALSE;

		SendMessageTimeout(winList[n].Handle, WM_GETICON, 1, 0, 0, 250, (unsigned long *)&hIcon);
		if (!hIcon) 
			SendMessageTimeout(winList[n].Handle, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long *)&hIcon);
		if (!hIcon) 
			hIcon = (HICON)GetClassLong(winList[n].Handle, GCL_HICON);
		if (!hIcon) 
			hIcon = (HICON)GetClassLong(winList[n].Handle, GCL_HICONSM);
	    target->SMenu->newMenuItem();
		title[0] = 0;
		if (winList[n].Handle != NULL) {
			GetWindowText(winList[n].Handle, (char *)&title, MAX_PATH);
		    strcpy(target->SMenu->current->name, title);
			target->SMenu->current->hIcon = hIcon;
			strcpy(target->SMenu->current->command, "T@sk");
			target->SMenu->current->itemLevel = popupLevel;
		}
	}
	if (noList) {
		target->SMenu->newMenuItem();
    	strcpy(target->SMenu->current->name, "No Tasks");
		strcpy(target->SMenu->current->command,"!none");
		target->SMenu->current->itemLevel = popupLevel;
	}
	popupLevel++;
	setPopupValues(target->SMenu);
}

void setPopupValues(Popup *pop) {
    menuItem *counter = pop->root;
	int maxWidth = popupMinWidth;
	SIZE name;
	HDC popDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	SelectObject(popDC, popupFont);
	int count = 1;
	while(counter != NULL)
    {
		GetTextExtentPoint32(popDC,(LPCTSTR)&counter->name,strlen(counter->name),&name);
		if (name.cx+(popupTextOffset*2)+popupIconSize+15 > maxWidth)
			maxWidth = name.cx+(popupTextOffset*2)+popupIconSize+15;
		counter->Menu = pop;
//		counter->itemNo = count;
		counter = counter->next;
		count++;
	}
	pop->menuWidth = isFixedWidth?popupFixedWidth:maxWidth;
	if (transBlt && !noPopupPix) {
		pop->region = GetRegion(pop->root);
	}
	DeleteDC(popDC);
}

HRGN GetRegion(menuItem *item) {
	menuItem *temp;
	HRGN mainRgn, clipRgn;
	int height = titleHeight;

	mainRgn = CreateRectRgn(0, 0, 0, 0);
	CombineRgn(mainRgn, mainRgn, titleBMP.region, RGN_OR);
	temp = item;
	while (temp != NULL) {
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, backBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(mainRgn, mainRgn, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
		height = height + popupSubHeight;
		temp = temp->next;
	}
	if (bottomBMP.bitmap) {
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, bottomBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(mainRgn, mainRgn, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
	}
	return mainRgn;
}

int fillDirectorySortFunc(const void *a, const void *b)
{
    WIN32_FIND_DATA *f1 = (WIN32_FIND_DATA *)a;
    WIN32_FIND_DATA *f2 = (WIN32_FIND_DATA *)b;

    if (f1->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    {
    	if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    		return stricmp(f1->cFileName, f2->cFileName);
    	else
    		return -1;
    }
    if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    	return 1;

    return stricmp(f1->cFileName, f2->cFileName);
}

//parses a directory and fills the popup data structure with the results
int fillDirectory(char *dirName, menuItem *target, BOOL oneLevel)
{
    int j, k, still=1;

    WIN32_FIND_DATA fd;
    WIN32_FIND_DATA *fileTable=NULL;
    HANDLE h;
    char temp2[MAX_PATH];
    strcpy(temp2, dirName);
    strcat(temp2, "\\*");
    h = FindFirstFile(temp2, &fd);
    if (h == INVALID_HANDLE_VALUE)
    	return 1;
    
    target->SMenu = new Popup;
    menuItem *walker = target;
    
    for (j=0;still;j++)
    {
		if (!fileTable)
			fileTable = (WIN32_FIND_DATA *)malloc(sizeof(WIN32_FIND_DATA));
		else
			fileTable = (WIN32_FIND_DATA *)realloc(fileTable, (j+1)*sizeof(WIN32_FIND_DATA));
		fileTable[j] = fd;
    	still = FindNextFile(h, &fd);
    }

    qsort((void *)fileTable, j, sizeof(WIN32_FIND_DATA), fillDirectorySortFunc);

	walker->SMenu->newMenuItem();
	strcpy(walker->SMenu->current->name, " ");
	walker->SMenu->current->isBar = 1;
    for (k=j,j=0;j<k;j++)
    {
    	if (fileTable[j].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
    		if (!strcmp(fileTable[j].cFileName, ".") || !strcmp(fileTable[j].cFileName, ".."))
           	{
			} else {
    			char t[MAX_PATH];
    			walker->SMenu->newMenuItem();// = new menuItem;
    			strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
    			strcpy(t, dirName);
    			strcat(t, "\\");
    			strcat(t, fileTable[j].cFileName);
    			walker->SMenu->current->itemLevel = popupLevel;
				if (!oneLevel) {
    				popupLevel++;
	    			int temp2 = fillDirectory(t, walker->SMenu->current, FALSE);
					if(temp2)
    				{
    					delete walker->SMenu->current->SMenu;
    					walker->SMenu->current->SMenu = NULL;
    					strcpy(walker->SMenu->current->command, t);
    				}
    				popupLevel--;
				}
    		}
    	}
    	else
    	{
    		char temp[5];
    		
    		strcpy(temp2, "");
    	 	strcat(temp2, dirName);
    		strcat(temp2, "\\");
    		strcat(temp2, fileTable[j].cFileName);
       		
    		walker->SMenu->newMenuItem();			
    		strcpy(walker->SMenu->current->command,temp2);
    		strcpy(temp, fileTable[j].cFileName +(strlen(fileTable[j].cFileName) -4));
    		//stripping unwanted extentions from the name
			if(!stricmp(temp, ".lnk") || !stricmp(temp, ".exe") || !stricmp(temp, ".pif") || !stricmp(temp, ".com") || !stricmp(temp, ".rnk") || !stricmp(temp, ".bat")) 
    		{
    			strncpy(walker->SMenu->current->name, fileTable[j].cFileName, 
    				strlen(fileTable[j].cFileName) -4);
    			walker->SMenu->current->name[strlen(fileTable[j].cFileName) -4] = '\0';
    		}
    		else 
				strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
    		walker->SMenu->current->itemLevel = popupLevel;
		}
    }
	if (bottomBMP.bitmap) {
		walker->SMenu->newMenuItem();
		strcpy(walker->SMenu->current->name, " ");
		walker->SMenu->current->isBar = 2;
	}
    FindClose(h);
    if(target->SMenu->root == NULL)
    	return 1;
	else {
		setPopupValues(target->SMenu);
	    return 0;
	}
}
    
LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
	menuItem *item;
	POINT pt;

   	GetCursorPos(&pt);
    switch (msg) {
	case LM_GETREVID: {
		char *buf = (char *) lParam;

		if (wParam == 0) {
			strcpy(buf, "popup.dll: ");
			strcat(buf, &rcsRevision[11]);
			buf[strlen(buf)-1] = '\0';
		} else if (wParam == 1) {
			strcpy(buf, &rcsId[1]);
			buf[strlen(buf)-1] = '\0';
		} else {
			strcpy(buf, "");
		}
		return strlen(buf);
	}

	case LM_POPUP:
 		GetCursorPos(&pt);
		TrackPopupMenu(popup.hmenu, 0, pt.x, pt.y, 0, hwnd, NULL);
		return 0;

	case WM_MEASUREITEM:
		MEASUREITEMSTRUCT *mi;

		mi = (MEASUREITEMSTRUCT *)lParam;
		item = GetItem(&popup, mi->itemID);
		mi->itemWidth = item->Menu->menuWidth-10;
		mi->itemHeight = popupSubHeight;
		return TRUE;
	case WM_DRAWITEM:
		DRAWITEMSTRUCT *di;
		RECT r;

		di = (DRAWITEMSTRUCT *)lParam;
		item = GetItem(&popup, di->itemID);
		paintItem(item, di);
		if (item->Menu->region == NULL) {
			GetMenuItemRect(NULL, item->Menu->hmenu, 0, &r);
		}
		return TRUE;
	case WM_COMMAND:
		item = GetItem(&popup, LOWORD(wParam));
		if(item->command[0] != '!') {
			executeItem(item);
		} else
   			ParseBangCommand (hwnd, item->command, item->params);
		break;
	}
	return DefWindowProc(hwnd, msg, wParam, lParam);
}

void paintItem(menuItem *item, DRAWITEMSTRUCT *di) {
    HFONT oldFont;
    HDC memDC;
	RECT r;
	COLORREF tcBack, tcFore;
	BitMP tPic;
	HBRUSH hBrush;
	HMENU oldMenu;
	BOOL isBar = FALSE;
	char temp[MAX_PATH], full[MAX_PATH];
    int menuWidth, bWidth, bHeight, tHeight;
	static menuItem *previousItem=NULL;

	menuWidth = di->rcItem.right - di->rcItem.left;
	tHeight = di->rcItem.bottom - di->rcItem.top;
    memDC = CreateCompatibleDC(di->hDC);
    oldFont = (HFONT) SelectObject(di->hDC, popupFont);
	CopyRect(&r, &di->rcItem);
	if (item->isBar == 1 || item->isBar == 2)
		isBar = TRUE;
	if (isBar) {
		if (item->isBar == 1) {
			tPic.bitmap = titleBMP.bitmap;
			tPic.x = titleBMP.x;
			tPic.y = titleBMP.y;
		} else {
			tPic.bitmap = bottomBMP.bitmap;
			tPic.x = bottomBMP.x;
			tPic.y = bottomBMP.y;
		}
		tcBack = titleBack;
		tcFore = titleColor;
	} else {
		if (di->itemState == ODS_SELECTED) {
			tPic.bitmap = selectBMP.bitmap;
			tPic.x = selectBMP.x;
			tPic.y = selectBMP.y;
			tcBack = selBack;
			tcFore = selColor;
		} else {
			tPic.bitmap = backBMP.bitmap;
			tPic.x = backBMP.x;
			tPic.y = backBMP.y;
			tcBack = normBack;
			tcFore = normColor;
		}
	}
	if (!noPopupPix) {
		SelectObject(memDC, tPic.bitmap);
		if (shrinkPopupBar) {
			StretchBlt(di->hDC,r.left,r.top, menuWidth, tHeight, memDC, 0, 0,tPic.x, tPic.y, SRCCOPY);
		} else {
			for(int x=r.left; x<r.left+menuWidth; x+=tPic.x)
				for(int y=r.top; y<r.top+tHeight; y+=tPic.y) {
					bWidth = x+tPic.x<menuWidth?tPic.x:x<menuWidth?menuWidth-x:menuWidth;
					bHeight = y+tPic.y<tHeight?tPic.y:y<tHeight?tHeight-y:tHeight;
					BitBlt(di->hDC, x, y, bWidth, bHeight, memDC, 0, 0, SRCCOPY);
				}
		}
	} else {
		hBrush = CreateSolidBrush(tcBack);
		SetRect(&r, r.left, r.top, menuWidth, tHeight);
		FillRect(di->hDC, &r, hBrush);
		DeleteObject(hBrush);
	}
    SetBkMode(di->hDC, TRANSPARENT);
    SetTextColor(di->hDC,  tcFore);
	if (isBar) {
		r.left += popupTextOffset;
		DrawText(di->hDC, item->name, lstrlen(item->name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);
	} else {
		if (item->isDynamic && previousItem != item /*&& item->Menu->parent==NULL*/) {
			if (item->SMenu->hmenu == NULL)
				oldMenu = CreateMenu();
			else
				oldMenu = item->SMenu->hmenu;
			deletePopup(item->SMenu);
			delete(item->SMenu);
			popupLevel = item->itemLevel + 1;
			if (!strncmp(item->command, "!PopupTasks", 11)) {
				buildTaskList(item);
			} else {
				strcpy(temp, item->command+20);
				ExpandEnvironmentStrings(temp, full, sizeof(full));
				fillDirectory(full, item, TRUE);
				if (showPopupIcons)
					GetItemIcon(item);
			}
			item->SMenu->hmenu = oldMenu;
			buildPopup(item->SMenu, TRUE);
			previousItem = item;
		}
		if (showPopupIcons) {
			if (item->hIcon != NULL)
				DrawIconEx(di->hDC, r.left+popupTextOffset, r.top+popupTop, item->hIcon, popupIconSize, popupIconSize, 0, NULL, DI_NORMAL);
			r.left += popupTextOffset+popupIconSize+4;
		} else
			r.left += popupTextOffset;
    	DrawText(di->hDC, item->name, lstrlen(item->name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);
/*    	if (!noPopupBevel)
    	{
			paintPopupBevel(this->hwnd, item, totalHeight, menuWidth);
    	}
    	if (iTemp->SMenu != NULL && popupFolderIcon)
    	{
			paintFolderArrow(this->hwnd, item, totalHeight, menuWidth);
    	} */
	}
    SelectObject(di->hDC, oldFont);
    DeleteDC(memDC);
}

void GetItemIcon(void *pitem) {
	HICON hIcon;
	char *file;
	char icon[MAX_PATH];
	menuItem *item = (menuItem *) pitem;
	char dir[MAX_PATH];
	UINT dsize = MAX_PATH;

	if (!showPopupIcons)
		_endthread();
    while(item != NULL) {
		strcpy(icon, "");
		if (item->SMenu != NULL) {
			item->hIcon = popupDefaultIcon;
			GetItemIcon(item->SMenu->root);
		} else {
			file = strlwr(strdup(item->command));
			if (strstr(file, "explorer")) {
				file = strdup(item->params);
				if (strstr(file, "{21EC2020-3AEA-1069-A2DD-08002B30309D}")) {
					//Control Panel
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{21EC2020-3AEA-1069-A2DD-08002B30309D}\\DefaultIcon", file);
				} else if (strstr(file, "{208D2C60-3AEA-1069-A2D7-08002B30309D}")) {
					//Network Neigbourhood
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{208D2C60-3AEA-1069-A2D7-08002B30309D}\\DefaultIcon", file);
				} else if (strstr(file, "{992CFFA0-F557-101A-88EC-00DD010CCC48}")) {
					//Dial-up Networking
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{992CFFA0-F557-101A-88EC-00DD010CCC48}\\DefaultIcon", file);
				} else if (strstr(file, "{20D04FE0-3AEA-1069-A2D8-08002B30309D}")) {
					//My computer
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\DefaultIcon", file);
				}
				if (strlen(file) != 0) {
					strcpy(icon, ".extract=");
					if (!strstr(file, "\\")) {
						if (strstr(file, "explorer"))
							GetWindowsDirectory(dir, dsize);
						else
							GetSystemDirectory(dir, dsize);
						strcat(icon, dir);
							strcat(icon, "\\");
					}
					strcat(icon, file);
					hIcon = LoadLSIcon(icon, NULL);
					item->hIcon = hIcon;
				}
			} else {
				SHFILEINFO shf;

				SHGetFileInfo(item->command, NULL, &shf, sizeof(shf), SHGFI_ICON | SHGFI_SMALLICON);
				if (shf.hIcon != NULL)
					item->hIcon = shf.hIcon;
				else {
					_searchenv(item->command, "PATH", dir);
					if (strlen(dir) != 0) {
						SHGetFileInfo(dir, NULL, &shf, sizeof(shf), SHGFI_ICON | SHGFI_SMALLICON);
						item->hIcon = shf.hIcon;
					}
				}
			}
		}
		item = item->next;
    }
}

void RegistryLookup(char* subKey, char *value) {
	char regData[256];
	int regSize = 256;
	LONG res;
	HKEY hOpen;

	RegOpenKeyEx(HKEY_CLASSES_ROOT, subKey, 0, KEY_READ, &hOpen);
	res = RegQueryValueEx(hOpen, value, NULL, NULL, (LPBYTE)regData, (LPDWORD)&regSize);
	if (res == ERROR_SUCCESS)
		strcpy(value, regData);
	else
		strcpy(value, "");
	RegCloseKey(hOpen);
}
/*
	$Log: popup.cpp,v $
	Revision 1.4  1999/09/16 12:52:55  maduin
	Bugfix: LSExecuteEx needs to be given a real nShowCmd, not 0
	
*/
