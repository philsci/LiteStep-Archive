/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team
  
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
	
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 	  
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
04/13/00 - Bobby G. Vinyard (Message)
  Added setupBangs() to startup routine
04/08/00 - Bobby G. Vinyard. (Message)
  Reimplemented !about, !about detailed via void GetRevID();

****************************************************************************/
#pragma warning(disable: 4786)
#include <io.h>
#include <time.h>
#include <tchar.h>
#include <stdio.h>
#include <shlobj.h>
#include <crtdbg.h>
#include <windows.h>
#include <process.h>
#include <winuser.h>
#include <comdef.h>

#include <fstream>

#include "litestep.h"
#include "lsapi.h"
#include "wharfdata.h"
#include "StartupRunner.h"
#include "MessageManager.h"
#include "DataStore.h"
#include "../core/ifcs.h"

const char rcsRevision[] = "$Revision: 1.15 $"; // Our Version 
const char rcsId[] = "$Id: litestep.cpp,v 1.15 2000/04/14 06:38:53 message Exp $"; // The Full RCS ID.
const char LSRev[] = "0.24.5 ";

// Program Options
const LPCTSTR   szMainWindowClass = _T("TApplication");
const LPCTSTR   szMainWindowTitle = _T("LiteStep");

// Paths
CHAR szAppPath[256], szRcPath[256];

// Application instance
HINSTANCE hDLLInstance;

// Run startup items flag
BOOL bRunStartup = TRUE;

// Windows
HWND hMainWindow = NULL;

// Main window procedure
LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Show explorer warning? LS is the shell?
BOOL ShowWarning = TRUE, isShell = FALSE;

// Initialize/shutdown manager services
void InitializeManagers();
void ShutdownManagers();

// Read config from step.rc
void ReadConfig (void);

// Parse the command line
void ParseCmdLine(LPSTR lpCmdLine);

// The manager services
DataStore *globalDataStore = NULL;
IMessageManager *globalMsgManager = NULL;
IWindowList *globalWindowList = NULL;
IModuleManager *globalModuleManager = NULL;

// Start up anything that should be started
void start();

// Stop the stuff we started
void stop();

// Shut down litestep
void ShutDown(void);

// We are under explorer? recycling? ending the current session?
BOOL UnderExplorer = FALSE, gRecycle = FALSE, gEndSession = FALSE;

// Skip events (?)
BOOL skipEvents = FALSE;

// Get revision ID's
//HRESULT GetRevId(WPARAM wParam, LPARAM lParam);
void GetRevId(WPARAM wParam, LPARAM lParam);

// Tray data pointer for storage
static trayType *trayData = NULL;

// Undocumented API: Set/Get the shell window, Shutdown windows
FARPROC (__stdcall *SetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *GetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *MSWinShutdown)(HWND) = NULL;

//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//
// Code Starts Here

// [Main Litestep Code]
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow) {
	ATOM aClass;
	WNDCLASS wc;
	
	bRunStartup = TRUE;       
	szAppPath[0] = 0;
	hDLLInstance = hInstance;
	
	// Get undocumented APIs
	SetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "SetShellWindow");
	GetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "GetShellWindow");
	MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
	
	// Determine our application's path
	if (GetModuleFileName (hDLLInstance, szAppPath, sizeof (szAppPath)) > 0) {
		int len = lstrlen (szAppPath);
		while (len && szAppPath[len-1] != _T('\\')) {
			szAppPath[--len] = _T('\0');
		}
		
		if (len) {
			szAppPath[--len] = _T('\0');
		}
	}
	
	// Parse command line, setting appropriate variables
	ParseCmdLine(lpCmdLine);
	
	//Setup environment variables
	setupVars(szAppPath);

	// Read config and close the .rc file
	ReadConfig();
	CloseRC();
	
	// Check for explorer
	if (FindWindow("Shell_TrayWnd", NULL)) { // Running under Exploder
		if (ShowWarning)
			if (MessageBox(0, "You are currently running another shell, while Litestep b24 allows you\012to run under Explorer, we don't advise it for inexperienced users, and we\012will not support it, so do so at your own risk.\012\012If you continue, some of the advanced features of Litestep will be disabled\012such as the desktop. The wharf, hotkeys, and shortcuts will still work.\012\012To get rid of this message next time, put LSNoShellWarning in your step.rc\012\012Continue?", "WARNING", MB_YESNO|MB_ICONEXCLAMATION) == IDNO)
				exit(0);
			UnderExplorer = TRUE;
	}
	
	// Register Window Class
	memset (&wc, 0, sizeof (wc));
	
	wc.lpfnWndProc = MainWndProc;
	wc.hInstance = hDLLInstance;
	wc.lpszClassName = szMainWindowClass;
	aClass = RegisterClass(&wc);
	if (!aClass) return 0;

	// Create our main window
	hMainWindow = CreateWindowEx(WS_EX_TOOLWINDOW,
		szMainWindowClass, szMainWindowTitle, 0,
		0, 0, 0, 0, NULL, NULL, hDLLInstance, NULL);
	
	// Start up everything
	if (hMainWindow) {
		MSG message;
		
		// Set magic DWORD to prevent VWM from seeing main window
		SetWindowLong (hMainWindow, GWL_USERDATA, magicDWord);
		
		// Set Shell Window
		if (!UnderExplorer && isShell) SetShellWindow(hMainWindow);
		
		// init managers
		InitializeManagers();
		
		start();
		
		// Main message pump
		while (GetMessage(&message, 0, 0, 0)) {
			__try {
				TranslateMessage(&message);
				DispatchMessage (&message);
			} __except(1) {
				// debugging or logging code
			}
			
			//if (gRecycle || gEndSession) {break;}
		}
		
		stop();
		
		// Clean up remaining events in message queue
		if (!skipEvents) {
			while (GetMessage (&message, 0, 0, 0)) {
				TranslateMessage(&message);
				DispatchMessage (&message);
			}
		}
		
		// Destroy main window
		DestroyWindow(hMainWindow);
		hMainWindow = NULL;
		
		// Shutdown managers
		ShutdownManagers();
	}
	
	// Unreg class
	UnregisterClass (szMainWindowClass, hDLLInstance);
	return 0;
}

void start() {

	// Setup environment variables
	setupVars(szAppPath);

  // Setup bang commands in lsapi
  setupBangs();

	// Read config again
	ReadConfig();     // Load step.rc
	
	// Load the hook manager
	globalModuleManager->LoadModule(_bstr_t("hookmgr.dll"), 0); // dependency wackiness...we'll put up with it for now.

	// register for shell messages
	//SendMessageTimeout(::FindWindow(TEXT("Hook Manager Window"), NULL), LM_REGISTERMESSAGE, (WPARAM)hMainWindow, 0, SMTO_ABORTIFHUNG, 100, NULL);
	PostMessage(::FindWindow(TEXT("Hook Manager Window"), 0), LM_REGISTERMESSAGE, (WPARAM)hMainWindow, 0);

	// Load modules
	globalModuleManager->LoadModules(NULL);

	// Restore the system tray
	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_RESTORESYSTRAY, &exists);

	if (gRecycle && exists && trayData) {
		SendMessage(hMainWindow, LM_RESTORESYSTRAY, 0, (LONG)trayData);
		if (trayData) free(trayData);
	}
	
	// If not recycling, run startup items
	if (!gRecycle) {
		// Don't run startup items if the SHIFT key is down
		if(GetAsyncKeyState(VK_SHIFT) & 0x8000) bRunStartup = FALSE;
		if(bRunStartup) {
			_beginthread(StartupRunner::RunStartupStuff, 0, &UnderExplorer);
		}
	}
	gRecycle = FALSE;
	
	SendMessage(GetDesktopWindow(), 0x400, 0, 0); // Undocumented call: Shell Loading Finished
}

void stop() {
	// Save system tray data
	globalModuleManager->QuitModule(_bstr_t("hookmgr.dll")); // dependency wackiness...we'll put up with it for now.
	
	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_SAVESYSTRAY, &exists);

	if (gRecycle && exists) {
		trayData = (trayType *)calloc(200, sizeof(trayType));
		SendMessage(hMainWindow, LM_SAVESYSTRAY, 0, (LONG)trayData);
	}
	
	// Clear messages
	globalMsgManager->ClearMessages();

	// Quit all modules
	globalModuleManager->QuitModules();

	// Close the step.rc file
	CloseRC();
}

LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	switch (uMsg) {
	case WM_KEYDOWN: {
		if (wParam == LM_SHUTDOWN) {ParseBangCommand(hwnd, "!ShutDown", NULL);}
		return 0;
					 }
		
	case WM_SYSCOMMAND: {
		switch (wParam) {
		case SC_CLOSE:
			ParseBangCommand(hwnd, "!ShutDown", NULL);
			return 0;
		default:
			return DefWindowProc(hwnd,uMsg,wParam,lParam);
		}
						}
		
	case WM_QUERYENDSESSION: {
		return TRUE;
		break;
							 }
		
	case WM_ENDSESSION: {
		gEndSession = TRUE;
		break;
						}
		
	case LM_SAVEDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->StoreData(ident, data, len);
		}
		return 0;
					  }
		
	case LM_RESTOREDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->ReleaseData(ident, data, len);
		}
		return 0;
						 }
		
	case LM_REGISTERMESSAGE:  {   // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->AddMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
							  }
		
	case LM_UNREGISTERMESSAGE:  { // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->RemoveMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
								}
		
	case LM_WINDOWLIST:
		return (LONG)globalWindowList;

	case LM_DATASTORE:
		return (LONG)globalDataStore;
		
	case LM_RECYCLE: {
		if (wParam == 0) {
			gRecycle = TRUE;
			stop();
			start();
		} else if (wParam == 1) {
			if (ExitWindowsEx (EWX_LOGOFF, 0)) {
				PostQuitMessage(0);
			}
		} else if (wParam == 2) {
			PostQuitMessage(0);
			skipEvents = TRUE;
		} else {
			ShutDown();
		}
		break;
					 }
	case LM_UNLOADMODULE:       // Module Handler Message
	{
		LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		break;
	}
		
	case LM_RELOADMODULE:       // Module Handler Message
	{
		LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		globalModuleManager->LoadModule( wszPath, 0 );
		break;
	}
		
	case LM_BANGCOMMAND:
	{
		PLMBANGCOMMAND plmbc = (PLMBANGCOMMAND) lParam;

		if( !plmbc )
			return FALSE;
		
		if( plmbc->cbSize != sizeof(LMBANGCOMMAND) )
			return FALSE;
		
		ParseBangCommand( plmbc->hWnd, plmbc->szCommand, plmbc->szArgs );
		return TRUE;
	}
		
	case WM_COPYDATA:
	{
		PCOPYDATASTRUCT pcds = (PCOPYDATASTRUCT) lParam;
		
		switch( pcds->dwData )
		{
			case LM_BANGCOMMAND:
				
				return SendMessage( hwnd, LM_BANGCOMMAND, 0,
					(LPARAM) pcds->lpData );
		}
		
		return 0;
	}

  case LM_GETREVID:
  {
    GetRevId(wParam, lParam);
  }

	default:
		if (globalMsgManager) {
			BOOL exists = FALSE;
			globalMsgManager->HandlerExists(uMsg, &exists);
			
			if (exists) {
				return globalMsgManager->SendMessage(uMsg, wParam, lParam);
			}
		}
		
		return DefWindowProc (hwnd, uMsg, wParam, lParam);
 }
 return 0;
}


// [Config/Settings Code]
void InitializeManagers(void) {
	globalDataStore = new DataStore();

	// requires message registration, must come after message manager
	HINSTANCE msgMgrLib = ::LoadLibrary("msgmgr.dll");

	if (msgMgrLib == NULL) {
		MessageBox(NULL, "Unable to load msgmgr.dll", "Fatal error", MB_ICONEXCLAMATION);
		// do something
	}

	IMessageManager *(__stdcall *CreateMessageManager)(void) = (IMessageManager *(__stdcall *)())GetProcAddress(msgMgrLib, "CreateMessageManager");
	globalMsgManager = CreateMessageManager();

	// requires message registration, must come after message manager
	HINSTANCE winListLib = ::LoadLibrary("winlist.dll");

	if (winListLib == NULL) {
		MessageBox(NULL, "Unable to load winlist.dll", "Fatal error", MB_ICONEXCLAMATION);
		// do something
	}

	IWindowList *(__stdcall *CreateWindowList)(void) = (IWindowList *(__stdcall *)())GetProcAddress(winListLib, "CreateWindowList");
	globalWindowList = CreateWindowList();

	// DLL module manager
	HINSTANCE modManLib = ::LoadLibrary("dllmgr.dll");

	if (modManLib == NULL) {
		MessageBox(NULL, "Unable to load dllmgr.dll", "Fatal error", MB_ICONEXCLAMATION);
		// do something
	}

	IModuleManager *(__stdcall *CreateModuleManager)(HWND, LPCTSTR) = (IModuleManager *(__stdcall *)(HWND, LPCTSTR))GetProcAddress(modManLib, "CreateModuleManager");
	globalModuleManager = CreateModuleManager(hMainWindow, szAppPath);
}

void ShutdownManagers() {
	globalModuleManager->Release();
	globalModuleManager = NULL;

	globalWindowList->Release();
	globalWindowList = NULL;

	globalMsgManager->Release();
	globalMsgManager = NULL;

	globalDataStore->Clear();
	delete globalDataStore;
	globalDataStore = NULL;
}

void ReadConfig (void) {
	if (SetupRC(szRcPath)) {
		
		// Modified - Maduin, 10-20-1999
		//   Added "ExplorerNoWarn" and "SetAsShell" again to smooth
		//   the transition to the new style. Eventually these should
		//   be removed, but for now backwards compability is a good
		//   thing.
		
		ShowWarning = GetRCBool("LSNoShellWarning", FALSE) && GetRCBool("ExplorerNoWarn", FALSE);
		isShell = GetRCBool("LSSetAsShell", TRUE) || GetRCBool("SetAsShell", TRUE);
	}
}

void ParseCmdLine(LPSTR lpCmdLine) {
	char *ptr;
	ptr = lpCmdLine;
	
	while(1) {
		TCHAR szSwitch[32];
		int n;
		
		while (*ptr && (*ptr == ' ' || *ptr == '\t')) ptr++;
		
		if (*ptr && (*ptr == '/' || *ptr == '-')) {
			n = 0;
			ptr++;
			
			while (*ptr && *ptr != ' ' && *ptr != '\t') {
				if(n < 32) szSwitch[n++] = *ptr;
				ptr++;
			}
			szSwitch[n] = 0;
			if(!lstrcmpi(szSwitch, TEXT("nostartup"))) bRunStartup = FALSE;
		} else break;
	}
	
	if (*ptr != '\0') {
		BOOL isFullPath = FALSE;
		int i;
		
		for (i = 0; i < lstrlen(ptr); i++) if (ptr[i] == '\\') isFullPath = TRUE;
		
		if (!isFullPath) {
			wsprintf(szRcPath, "%s\\%s", szAppPath, ptr);
		} else {
			wsprintf(szRcPath, ptr);
		}
		
	} else wsprintf(szRcPath, "%s\\STEP.RC", szAppPath);
}

int ErrorBox( HWND hWnd, LPCTSTR pszText, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags )
{
	TCHAR szMessage[MAX_PATH];
	int nLen;
	
	lstrcpyn(szMessage, pszText, MAX_PATH - 1);
	lstrcat(szMessage, TEXT(" "));
	nLen = lstrlen(szMessage);
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, dwErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), szMessage + nLen,
		MAX_PATH - nLen, NULL);
	
	return MessageBox( hWnd, szMessage, pszTitle, nFlags );
}

void ShutDown(void) {
	
	MSWinShutdown(hMainWindow);
	return;
}

// [Misc Code]
void DoEvents(HWND hwnd, int n) {
	int i;
	unsigned int b=1;
	MSG msg;
	
	for (i=0;i<n && b;i++) {
		b = PeekMessage(&msg, hwnd, 0, 0, PM_REMOVE);
		if (b) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
}

void GetRevId(WPARAM wParam, LPARAM lParam) {
	char buf[256];

	if (wParam == 1) {
    		strcpy(buf, &rcsId[1]);
		buf[strlen(buf)-1] = '\0';
	} else {
		strcpy(buf, "litestep.exe: ");
		strcat(buf, (LPCSTR)&LSRev);
		buf[strlen(buf)-1] = '\0';
	}
  SendMessage((HWND)lParam, LM_GETREVID, 0, (long)buf);
  globalMsgManager->GetRevID(LM_GETREVID, wParam, lParam);
}
/*HRESULT GetRevId(WPARAM wParam, LPARAM lParam) {
	int i=0, j;
	int p = 0;
	char *buf = (char *) lParam;
	BOOL found = FALSE;
	HRESULT returnVal = 0;
	int bufLen = wParam >> 4;
	int RetType = wParam & 0x0000f;
	
	if (RetType == 0) {
		strcpy(buf, "litestep.exe: ");
		strcat(buf, (LPCSTR)&LSRev);
		buf[strlen(buf)-1] = '\0';
	}
	else if (RetType == 1) {
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf)-1] = '\0';
	} else {
		strcpy(buf, "");
	}
	
	while ((MSGCallbacks[i].Message) && (i < (MSGNUM))) {
		if (MSGCallbacks[i].Message == LM_GETREVID) {
			found = TRUE;
			break;
		}
		i++;
	}
	
	if (found) {
		char buffer[1024];
		for (j=0; j<HWNDNUM; j++) {
			if (MSGCallbacks[i].hwnd[j] != NULL) {
				strcpy(buffer, "");
				p = SendMessage(MSGCallbacks[i].hwnd[j], LM_GETREVID, (wParam & 0x0f), (LPARAM) buffer);
				if (p && *buffer) {
					strcat(buf, "\n");
					strncat(buf, buffer, bufLen - strlen(buf));
				}
			}
		}
	}
	buf[bufLen -1] = '\0';
	return (HRESULT)strlen(buf);
}*/

