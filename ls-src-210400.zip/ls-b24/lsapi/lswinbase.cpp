/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/20/00 - Joachim Calvert (NeXTer)
  - Most of said bumps have been smoothed out. Some were actually more or less
    fatal, but that should be fixed.
04/19/00 - Joachim Calvert (NeXTer)
  - First revision, it's working nicely, and I don't think we want any more
    features built in, perhaps smooth out a few bumps, but nothing major.
****************************************************************************/

#include "../lsapi/lswinbase.h"

#define GWL_CLASSPOINTER 0


struct CreationData
{
  SHORT cbExtra;
  Window* window;
};

typedef UNALIGNED CreationData UACreationData;


const char defaultClassName[] = "AutoWindowClass";
const HINSTANCE hInstance = 0;


LPCSTR Window::className = defaultClassName;
WNDCLASSEX Window::windowClass;
DWORD Window::instanceCount = 0;


//---------------------------------------------------------
// Constructor
//---------------------------------------------------------
Window::Window(LPCSTR szClassName):
hWnd(NULL),
hParent(NULL)
{
  WNDCLASSEX& wc = windowClass;

  instanceCount++;
  if (instanceCount > 1)
    return;

  if (className != defaultClassName)
  {
    delete[] const_cast<LPSTR>(className);
    className = defaultClassName;
  }

  if (szClassName)
  {
    className = new char[strlen(szClassName) + 1];
    strcpy((LPSTR)className, szClassName);
  }

  memset(&wc, 0, sizeof(WNDCLASSEX));
  wc.cbSize = sizeof(WNDCLASSEX);
  wc.cbWndExtra = sizeof(Window*);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.lpfnWndProc = Window::wndProc;
  wc.hInstance = hInstance;
  wc.lpszClassName = className;

  if (!RegisterClassEx(&wc))
  {
    MessageBox(NULL, "Unable to register window class.", className, MB_ICONEXCLAMATION | MB_TOPMOST);
    throw;
  }
}


//---------------------------------------------------------
// Destructor
//---------------------------------------------------------
Window::~Window()
{
  destroyWindow();
  if (instanceCount > 0)
    instanceCount--;
  if (instanceCount > 0)
    return;

  UnregisterClass(className, hInstance);
  if (className != defaultClassName)
    delete[] const_cast<LPSTR>(className);
}


//---------------------------------------------------------
// Associate the class with the window structure for easy
// message handling
//---------------------------------------------------------
bool Window::createWindow(DWORD dwExStyle, LPCTSTR lpWindowName, DWORD dwStyle,
                          int x, int y, int nWidth, int nHeight, HWND hWndParent)
{
  UACreationData creationData = {sizeof(UACreationData), this};

  const_cast<HWND>(hParent) = hWndParent;

  const_cast<HWND>(hWnd) = CreateWindowEx(dwExStyle, className, lpWindowName, dwStyle,
                                          x, y, nWidth, nHeight, hParent, NULL, hInstance, &creationData);
  if (!hWnd)
    return false;

  SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)this);

  return true;
}


bool Window::destroyWindow()
{
  if (hWnd && DestroyWindow(hWnd))
  {
    const_cast<HWND>(hWnd) = NULL;
    return true;
  }
  return false;
}


//---------------------------------------------------------
// If the window is associated with a class, call the
// messsage handler of the class
//---------------------------------------------------------
LRESULT CALLBACK Window::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  Message message = {uMsg, wParam, lParam, 0};
  Window* window = NULL;

  if (uMsg == WM_CREATE)
  {
    LPVOID& lpCreateParams = LPCREATESTRUCT(lParam)->lpCreateParams;

    if (lpCreateParams)
      window = ((UACreationData*)(lpCreateParams))->window;
  }
  else
    window = (Window*)(GetWindowLong(hWnd, GWL_CLASSPOINTER));

  if (window)
  {
    if (uMsg == WM_CREATE)
      const_cast<HWND>(window->hWnd) = hWnd;
    window->windowProc(message);
    if (uMsg == WM_DESTROY)
      const_cast<HWND>(window->hWnd) = NULL;
    return message.lResult;
  }
  return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


//---------------------------------------------------------
// Empty skeleton for messsage handling
//---------------------------------------------------------
void Window::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
  END_MESSAGEPROC
}

int WINAPI DllEntryPoint(HINSTANCE hInst, unsigned long reason, void* lpReserved)
{
  const_cast<HINSTANCE>(hInstance) = hInst;
  return 1;
}

