// DataStore.h: interface for the DataStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATASTORE_H__585A2B4A_0235_4663_931A_CA80611C13AB__INCLUDED_)
#define AFX_DATASTORE_H__585A2B4A_0235_4663_931A_CA80611C13AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <map>

using namespace std;

class DataHolder {
private:
	char len;
	void *data;
public:
	DataHolder();
	DataHolder(void *theData, WORD length);
	virtual ~DataHolder();

	int GetData(void *target, WORD length);
	int SetData(void *source, WORD length);
};

class DataStore {
	typedef map<WORD, DataHolder*> dataHolderMap;

	dataHolderMap dataMap;

public:
	void Clear();
	BOOL ReleaseData(WORD id, void *data, WORD len);
	BOOL StoreData(WORD id, void *data, WORD len);
	DataStore();
	virtual ~DataStore();

};

#endif // !defined(AFX_DATASTORE_H__585A2B4A_0235_4663_931A_CA80611C13AB__INCLUDED_)
