============================================================
hookctrl.dll v1.0
------------------------------------------------------------
Filename: 	hookctrl.dll
Authors	:	Chris Rempel, 
		Chao-Kuo Lin
E-mail	:	jugg@dylern.com , 
		chaokuo@iname.com
Webpage:	http://jugg.logicpd.com
		http://cklin.cjb.net
Purpose:
	This hook module is strictly for PureLS and other shells that support
	LiteStep modules but don't yet have a hook written yet.

	So what's cool about it? By loading it, you can enjoy the feature of ckVWM's
	*VWMStartWindowsOnDesktop and tasks' flashing ability.

	***REMINDER** No one is responsible if you crash your LiteStep by loading it.
------------------------------------------------------------
/****************** v1.0		2001/07/02************/
  Usage:
	LoadModule "c:\purels\hookctrl.dll"	
	*IMPORTANT: always load this module last, or you might get some
	unexpected outcome.

 Settings
	HookCtrlEnableShellHook	
		This is the only setting right now, and it would enable the shell
		hook and do everything that's described in the Purepose section.

