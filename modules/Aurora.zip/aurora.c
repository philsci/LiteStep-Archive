#include <windows.h>
#include <time.h>
#include "exports.h"
#include "lsapi.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();

void BangPulse(HWND caller, char* args);
void BangStopPulse(HWND caller, char* args);
void BangHide(HWND caller, char* args);
void BangShow(HWND caller, char* args);
void BangToggle(HWND caller, char* args);

HWND top, right, bottom, left;
int ScreenX, ScreenY;
char* szAppName = "Aurora";
POINT p;

COLORREF TColorIn, TColorOut, RColorIn, RColorOut;
COLORREF BColorIn, BColorOut, LColorIn, LColorOut;

BOOL PULSE=FALSE;
BOOL PULSE_RANDOM=FALSE;
BOOL HIDDEN=FALSE;
COLORREF PULSE_COLOR[20];
COLORREF CURRENT_COLOR;
int CURRENT_NUM=0;
int NUM_COLORS=0;
int COLOR_STEP=5;
int UPDATE_TIMER=25;

int X, Y, W, H;

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
    
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	X = GetRCInt("AuroraX", 0);
	Y = GetRCInt("AuroraY", 0);
	W = GetRCInt("AuroraWidth", ScreenX);
	H = GetRCInt("AuroraHeight", ScreenY);
	COLOR_STEP = GetRCInt("AuroraColorStep", 5);
	UPDATE_TIMER = GetRCInt("AuroraTimer", 25);
	
	top		= CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, X, Y, W, GetRCInt("AuroraTopWidth", 3), NULL, NULL, dllInst, 0);
	SetWindowLong(top, GWL_USERDATA, magicDWord);
	right	= CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, X+W-GetRCInt("AuroraRightWidth", 3), Y, GetRCInt("AuroraRightWidth", 3), H, NULL, NULL, dllInst, 0);
	SetWindowLong(right, GWL_USERDATA, magicDWord);
	bottom	= CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, X, Y+H-GetRCInt("AuroraBottomWidth", 3), W, GetRCInt("AuroraBottomWidth", 3), NULL, NULL, dllInst, 0);
	SetWindowLong(bottom, GWL_USERDATA, magicDWord);
	left	= CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, X, Y, GetRCInt("AuroraLeftWidth", 3), H, NULL, NULL, dllInst, 0);
	SetWindowLong(left, GWL_USERDATA, magicDWord);

	if (GetRCBool("AuroraStartHidden", FALSE))
	{
		HIDDEN=FALSE;
	}
	else
	{
		HIDDEN=TRUE;
		ShowWindow(top, SW_HIDE);
		ShowWindow(right, SW_HIDE);
		ShowWindow(bottom, SW_HIDE);
		ShowWindow(left, SW_HIDE);
	}

	if (GetRCBool("AuroraStartPulsing", TRUE))
	{
		char temp[256] = "";
		GetRCLine("AuroraPulse", temp, 256, "FFFFFF 000000");
		BangPulse(NULL, temp);
	}
	else
	{
		SetTimer(top, 0, UPDATE_TIMER, NULL);
	}

	LoadSetup();

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	KillTimer(top, 0);
	DestroyWindow(top);
	DestroyWindow(right);
	DestroyWindow(bottom);
	DestroyWindow(left);
	UnregisterClass(szAppName, dll);

	RemoveBangCommand("!AuroraPulse");
	RemoveBangCommand("!AuroraStopPulse");
	RemoveBangCommand("!AuroraHide");
	RemoveBangCommand("!AuroraShow");
	RemoveBangCommand("!AuroraToggle");

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			RECT cr;
			HBRUSH hbr;

			if (!HIDDEN)
			{
				GetClientRect(hwnd, &cr);

				if (!PULSE)
				{
					if (hwnd == top)
					{
						int fr = (GetRValue(TColorIn) - p.y * GetRValue(TColorIn) / ScreenY) + (p.y * GetRValue(TColorOut) / ScreenY);
						int fg = (GetGValue(TColorIn) - p.y * GetGValue(TColorIn) / ScreenY) + (p.y * GetGValue(TColorOut) / ScreenY);
						int fb = (GetBValue(TColorIn) - p.y * GetBValue(TColorIn) / ScreenY) + (p.y * GetBValue(TColorOut) / ScreenY);
						hbr = CreateSolidBrush(RGB(fr, fg, fb));
					}
					else if (hwnd == right)
					{
						int fr = (GetRValue(RColorOut) - p.x * GetRValue(RColorOut) / ScreenX) + (p.x * GetRValue(RColorIn) / ScreenX);
						int fg = (GetGValue(RColorOut) - p.x * GetGValue(RColorOut) / ScreenX) + (p.x * GetGValue(RColorIn) / ScreenX);
						int fb = (GetBValue(RColorOut) - p.x * GetBValue(RColorOut) / ScreenX) + (p.x * GetBValue(RColorIn) / ScreenX);
						hbr = CreateSolidBrush(RGB(fr, fg, fb));
					}
					else if (hwnd == bottom)
					{
						int fr = (GetRValue(BColorOut) - p.y * GetRValue(BColorOut) / ScreenY) + (p.y * GetRValue(BColorIn) / ScreenY);
						int fg = (GetGValue(BColorOut) - p.y * GetGValue(BColorOut) / ScreenY) + (p.y * GetGValue(BColorIn) / ScreenY);
						int fb = (GetBValue(BColorOut) - p.y * GetBValue(BColorOut) / ScreenY) + (p.y * GetBValue(BColorIn) / ScreenY);
						hbr = CreateSolidBrush(RGB(fr, fg, fb));
					}
					else if (hwnd == left)
					{
						int fr = (GetRValue(LColorIn) - p.x * GetRValue(LColorIn) / ScreenX) + (p.x * GetRValue(LColorOut) / ScreenX);
						int fg = (GetGValue(LColorIn) - p.x * GetGValue(LColorIn) / ScreenX) + (p.x * GetGValue(LColorOut) / ScreenX);
						int fb = (GetBValue(LColorIn) - p.x * GetBValue(LColorIn) / ScreenX) + (p.x * GetBValue(LColorOut) / ScreenX);
						hbr = CreateSolidBrush(RGB(fr, fg, fb));
					}
				}
				else
				{
					hbr = CreateSolidBrush(CURRENT_COLOR);
				}

				FillRect(hdc, &cr, hbr);
			}

			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
			DeleteObject(hbr);
		}
		break;

		case WM_TIMER:
		{
			switch ((int)wParam)
			{
				case 0:
				{
					POINT tp;
					GetCursorPos(&tp);

					if (tp.x == p.x && tp.y == p.y) break;

					p.x = tp.x;
					p.y = tp.y;

					InvalidateRect(top, NULL, TRUE);
					InvalidateRect(right, NULL, TRUE);
					InvalidateRect(bottom, NULL, TRUE);
					InvalidateRect(left, NULL, TRUE);
				}
				break;

				case 1:
				{
					static BOOL BUSY=FALSE;

					if (!BUSY)
					{
						int cr, cg, cb;
						int nr, ng, nb;

						BUSY=TRUE;

						if (!PULSE)
						{
							PULSE=TRUE;
							CURRENT_NUM=0;
							CURRENT_COLOR = PULSE_COLOR[0];
						}

						if (CURRENT_NUM == NUM_COLORS) 
						{
							CURRENT_NUM = 0;
							if (PULSE_RANDOM) 
							{
								PULSE_COLOR[0] = RGB(rand()%255, rand()%255, rand()%255);
								PULSE_COLOR[1] = RGB(rand()%255, rand()%255, rand()%255);
							}
						}

						cr = GetRValue(CURRENT_COLOR);
						cg = GetGValue(CURRENT_COLOR);
						cb = GetBValue(CURRENT_COLOR);

						if (CURRENT_NUM == NUM_COLORS-1)
						{
							nr = GetRValue(PULSE_COLOR[0]);
							ng = GetGValue(PULSE_COLOR[0]);
							nb = GetBValue(PULSE_COLOR[0]);
						}
						else
						{
							nr = GetRValue(PULSE_COLOR[CURRENT_NUM+1]);
							ng = GetGValue(PULSE_COLOR[CURRENT_NUM+1]);
							nb = GetBValue(PULSE_COLOR[CURRENT_NUM+1]);
						}

						if (cr == nr && cg == ng && cb == nb) 
						{ 
							CURRENT_NUM++; 
							BUSY=FALSE; 
							break;
						}

						if (abs(cr - nr) <= COLOR_STEP) cr = nr;
						else if (cr < nr) cr += COLOR_STEP;
						else if (cr > nr) cr -= COLOR_STEP;

						if (abs(cg - ng) <= COLOR_STEP) cg = ng;
						if (cg < ng) cg += COLOR_STEP;
						else if (cg > ng) cg -= COLOR_STEP;

						if (abs(cb - nb) <= COLOR_STEP) cb = nb;
						if (cb < nb) cb += COLOR_STEP;
						else if (cb > nb) cb -= COLOR_STEP;

						CURRENT_COLOR = RGB(cr, cg, cb);
						
						InvalidateRect(top, NULL, TRUE);
						InvalidateRect(right, NULL, TRUE);
						InvalidateRect(bottom, NULL, TRUE);
						InvalidateRect(left, NULL, TRUE);

						BUSY=FALSE;
					}
				}
				break;
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void LoadSetup()
{
	AddBangCommand("!AuroraPulse", BangPulse);
	AddBangCommand("!AuroraStopPulse", BangStopPulse);
	AddBangCommand("!AuroraHide", BangHide);
	AddBangCommand("!AuroraShow", BangShow);
	AddBangCommand("!AuroraToggle", BangToggle);

	TColorIn = GetRCColor("AuroraTopColorIn", 0x00FF0000);
	TColorOut = GetRCColor("AuroraTopColorOut", 0x00000000);
	
	RColorIn = GetRCColor("AuroraRightColorIn", 0x0000FF00);
	RColorOut = GetRCColor("AuroraRightColorOut", 0x00000000);

	BColorIn = GetRCColor("AuroraBottomColorIn", 0x000000FF);
	BColorOut = GetRCColor("AuroraBottomColorOut", 0x00000000);

	LColorIn = GetRCColor("AuroraLeftColorIn", 0x0000FFFF);
	LColorOut = GetRCColor("AuroraLeftColorOut", 0x00000000);
}

void BangPulse(HWND caller, char *args)
{
	char buffer[256] = "";
	char *endstr;
	char *p;

	strcpy(buffer, args);

	p = strtok(buffer, " ");

	NUM_COLORS=0;

	while (p)
	{
		if(!_strnicmp( p, "0x", 2 )) p += 2;
		else if (!_strnicmp(p, "!Random", 7 )) 
		{
			PULSE_RANDOM=TRUE;
			NUM_COLORS=2;
			srand(time(NULL));
			PULSE_COLOR[0] = RGB(rand()%255, rand()%255, rand()%255);
			PULSE_COLOR[1] = RGB(rand()%255, rand()%255, rand()%255);
			break;
		}

		PULSE_COLOR[NUM_COLORS++] = strtol( p, &endstr, 16 );
		p = strtok(NULL, " ");
	}

	KillTimer(top, 0);
	SetTimer(top, 1, UPDATE_TIMER, NULL);
}

void BangStopPulse(HWND caller, char* args)
{
	KillTimer(top, 1);
	PULSE=FALSE;
	SetTimer(top, 0, UPDATE_TIMER, NULL);

	InvalidateRect(top, NULL, TRUE);
	InvalidateRect(right, NULL, TRUE);
	InvalidateRect(bottom, NULL, TRUE);
	InvalidateRect(left, NULL, TRUE);
}

void BangHide(HWND caller, char* args)
{
	HIDDEN=TRUE;
	ShowWindow(top, SW_HIDE);
	ShowWindow(right, SW_HIDE);
	ShowWindow(bottom, SW_HIDE);
	ShowWindow(left, SW_HIDE);
	KillTimer(top, 0);
	KillTimer(top, 1);
}

void BangShow(HWND caller, char* args)
{
	HIDDEN=FALSE;
	ShowWindow(top, SW_SHOW);
	ShowWindow(right, SW_SHOW);
	ShowWindow(bottom, SW_SHOW);
	ShowWindow(left, SW_SHOW);
	if (PULSE) SetTimer(top, 1, UPDATE_TIMER, NULL);
	else SetTimer(top, 0, UPDATE_TIMER, NULL);
}

void BangToggle(HWND caller, char* args)
{
	if (HIDDEN) BangShow(caller, args);
	else BangHide(caller, args);
}