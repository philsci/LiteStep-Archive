TrashWharf 1.0 Beta 2

(c)1998 Charles Hacker (hacked@ix.netcom.com) LOMsT @EFNET
"Recycle Bin" for LiteStep Wharf.
Based on SDK by Lonerunnr/Aegis

I wrote this because of demand.

INSTALLATION:
-In step.rc:
  *Wharf "Trash" bzdefault.bmp @TrashWharf.app

-Move empty.bmp to your litestep IMAGES directory, or create your own, that
is 64x64 pixels

Drag Files or Directories in, They are deleted permanentaly, so be careful

Hopefully, someone will want to help (seriously).

I'm still learning to write modules, so wait up.

