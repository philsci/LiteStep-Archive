/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_REMOTEAMPITEM_H__5CAE4535_748B_11D2_B6A1_00C0DF466974__INCLUDED_)
#define AFX_REMOTEAMPITEM_H__5CAE4535_748B_11D2_B6A1_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MenuItem.h"

/**
Remote controller for winamp and similar programs
*/
class RemoteAmpItem : public MenuItem
{
public:
	/// constructs a remoteamp object
	RemoteAmpItem();

	/// destroys the remoteamp object
	virtual ~RemoteAmpItem();

	/**
	informs the object of mouse messages. this object is listening
	for WM_LBUTTONUP that occur over this object. when such a message is 
	passed it will invoke remotecontrol logic

	@param nMsg the mouse message
	@param x the location
	@param y the location
	*/
	void Mouse(int nMsg, int x, int y, WPARAM wParam);

	/**
	sets the current location of the object in a menu

	@param nLeft x location
	@param nTop y location
	*/
	void SetPosition(int nLeft, int nTop);

	/**
	RemoteAmp's can not be activated so the return FALSE

	@return FALSE
	*/
	BOOL Active(BOOL bActive)
	{
		return FALSE;
	};
protected:

	// RemoteAmpItems cannot have icons
	BOOL ShouldPaintIcon()
	{
		return FALSE;
	}

	/// the previous button
	RECT m_Button1;

	/// the play button
	RECT m_Button2;

	/// the pause button
	RECT m_Button3;

	/// the stop button
	RECT m_Button4;

	/// the next button
	RECT m_Button5;
};

/**
used to store the information about how to access
a mp3 player.
*/
typedef struct _RemoteControl
{
	/// the widow class name associated with the player
	LPSTR pszClassName;

	/// the window command to access the player
	int lParam;

	/// the message to go to the previous song
	int nPrevious;

	/// the message to start playing
	int nPlay;

	/// the message to pause
	int nPause;

	/// the message to stop playing
	int nStop;

	/// the message to go to the next song
	int nNext;
}
RemoteControl;

#endif // !defined(AFX_REMOTEAMPITEM_H__5CAE4535_748B_11D2_B6A1_00C0DF466974__INCLUDED_)
