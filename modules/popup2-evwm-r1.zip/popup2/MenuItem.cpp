/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"
#include "MenuItem.h"
#include "Painter.h"
#include "PopupMaker.h"
#include "PopupMenu.h"

extern PopupMaker *pPopupMaker;

BOOL MenuItem::m_bDrawBevel = TRUE;
DWORD MenuItem::m_nDarkColor = 0x00000000;
DWORD MenuItem::m_nLightColor = 0x00FFFFFF;
int MenuItem::m_nAlignment = DT_LEFT;
int MenuItem::m_nTitleAlignment = DT_LEFT;
int MenuItem::m_nIndent = 0;
int MenuItem::m_nRightIndent = 0;
int MenuItem::m_nIconSpacing = 0;
int MenuItem::m_nIconSize = 0;
BOOL MenuItem::m_bIconsOnRight = FALSE;
HBITMAP MenuItem::m_hbmArrow = NULL;
HBITMAP MenuItem::m_hbmSelArrow = NULL;

MenuItem::MenuItem()
{
	m_pParent = NULL;
	m_nShortcut = -1; // not a key code
	m_nWidth = 110; // todo: make dynamic
	m_nHeight = 18; // todo: make dynamic

	m_pForeground = NULL;
	m_pBackground = NULL;

	m_pActiveForeground = NULL;
	m_pActiveBackground = NULL;

	m_bActive = FALSE;

	m_hIcon = NULL;
	m_hImageList = NULL;
	m_iIcon = -1;

	m_nSortPriority = 0;
}

MenuItem::~MenuItem()
{
	if (m_hIcon != NULL)
	{
		DestroyIcon(m_hIcon);
		m_hIcon = NULL;
	}
}

// Paint the menu item att the dc.
// nState ::= SELECTED | DEFAULT
void MenuItem::Paint(HDC hDC)
{
	RECT rc;
	GetItemRect(&rc);
	DrawBackground(hDC, &rc);

	// SetBkMode(hDC, TRANSPARENT); // todo: move to a painter...
	/*
	// Paint the background
	if(m_bActive && m_pActiveBackground)
		m_pActiveBackground->Paint(this, hDC);
	else if(m_pBackground)
		m_pBackground->Paint(this, hDC);

	// Paint the foreground ...

	if(pPopupMaker->m_bIcons && ShouldPaintIcon())
{
		if(m_hIcon)
		{
			DrawIconEx(hDC, GetIndent() + 3, m_nTop + (GetHeight() - m_nIconSize) / 2,
				m_hIcon, m_nIconSize, m_nIconSize, 0, NULL, DI_NORMAL);
		}
		else if(m_hImageList && m_iIcon >= 0)
		{
			if(m_nIconSize == 16)
			{
				ImageList_Draw(m_hImageList, m_iIcon, hDC, GetIndent() + 3,
					m_nTop + (GetHeight() - 16) / 2, ILD_TRANSPARENT);
			}
			else
			{
				HICON hIcon = ImageList_GetIcon(m_hImageList, m_iIcon, ILD_TRANSPARENT);

				DrawIconEx(hDC, GetIndent() + 3,
					m_nTop + (GetHeight() - m_nIconSize) / 2,
					hIcon, m_nIconSize, m_nIconSize, 0, NULL, DI_NORMAL);

				DestroyIcon(hIcon);
			}
		}
} */
}

// Execute the command that is associated with the menu item
void MenuItem::Invoke()
{
	// default implementation is a nop
	return ;
}

// Execute the command that is associated with the menu item
void MenuItem::RInvoke()
{
	// default implementation is a nop
	return ;
}

// A key has been pressed
BOOL MenuItem::Key(int nKey)
{
	if (m_nShortcut == nKey)
		Invoke();
	return FALSE;
}

// Mouse command MOUSEMOVE, LB_PRESSED, ...
void MenuItem::Mouse(int nMsg, int x, int y, WPARAM wParam)
{
	RECT r;
	POINT p;
	p.x = x;
	p.y = y;
	GetItemRect(&r);

	if (PtInRect(&r, p))
	{
		switch (nMsg)
		{
			case WM_LBUTTONUP:
			Invoke();
			break;
			case WM_RBUTTONUP:
			RInvoke();
			break;
			case WM_MOUSEMOVE:
			Active(TRUE);
			break;
			default:
			break;
		}
	}
	else
		Active(FALSE);
}

void MenuItem::PaintBevel(HDC hDC, int nTop)
{
	/*	RECT r;
	 
		r.top = nTop;
		r.left = 0;
		r.right = r.left + GetWidth();
		r.bottom = r.top + Height();
	 
		DrawEdge(hDC, &r, EDGE_ETCHED, BF_ADJUST | BF_RECT);*/
	HPEN hPen;
	HPEN hOldPen;

	hPen = CreatePen(PS_SOLID, 1, m_nLightColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);

	// First we draw the white frame on the left/top
	MoveToEx(hDC, 0, nTop, NULL);
	LineTo(hDC, GetWidth(), nTop);
	MoveToEx(hDC, 0, nTop, NULL);
	LineTo(hDC, 0, nTop + GetHeight() - 1);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);

	// Now the black frame on the bottom/right
	hPen = CreatePen(PS_SOLID, 1, m_nDarkColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);
	MoveToEx(hDC, GetWidth() - 1, nTop, NULL);
	LineTo(hDC, GetWidth() - 1, nTop + GetHeight() - 1);
	MoveToEx(hDC, 0, nTop + GetHeight() - 1, NULL);
	LineTo(hDC, GetWidth() - 1, nTop + GetHeight() - 1);

	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
}

void MenuItem::Timer(int nTimer)
{
	// execute timer messages
}

int MenuItem::IsOver(int x, int y)
{
	POINT p;
	RECT r;

	p.x = x;
	p.y = y;

	r.top = m_nTop;
	r.left = 0;
	r.bottom = r.top + GetHeight();
	r.right = r.left + GetWidth();

	return PtInRect(&r, p); // TODO: this is wrong ....fix it -1 .. 0 .. 1
}

void MenuItem::Attached(PopupMenu* pMenu)
{
	m_pParent = pMenu;
}

BOOL MenuItem::Active(BOOL bActive)
{
	RECT r;

	if (m_bActive != bActive)
	{
		// only redraw the window if the state changes
		m_bActive = bActive;

		GetItemRect(&r);

		// todo: no need to repaint entire window ...
		//		InvalidateRect(m_pParent->GetWindow(),&r,TRUE);
		//		UpdateWindow(m_pParent->GetWindow());
		RedrawWindow(GetWindow(), &r, NULL, RDW_INVALIDATE);
	}

	return m_bActive;
}

void MenuItem::GetItemRect(LPRECT lpRect)
{
	lpRect->top = m_nTop;
	lpRect->left = 0;
	lpRect->right = lpRect->left + GetWidth();
	lpRect->bottom = lpRect->top + GetHeight();
}

void MenuItem::SetPainter(Painter* pBackground)
{
	m_pBackground = pBackground;
}

void MenuItem::SetActivePainter(Painter* pBackground)
{
	m_pActiveBackground = pBackground;
}

HWND MenuItem::GetWindow()
{
	if (m_pParent)
		return m_pParent->GetWindow();
	else
		return NULL;
}

void MenuItem::GetRegion(HRGN hRgn)
{
	RECT rc;
	SetRect(&rc, 0, 0, GetWidth(), GetHeight());
	m_pBackground->GetRegion(hRgn, &rc);

	// m_pBackground->GetRegion(hRgn, this);
}

void MenuItem::GetMinimumSize(HDC hDC, LPSIZE pMinSize)
{
	int nMinWidth = GetIndent() + GetRightIndent();

	if (pPopupMaker->m_bIcons && ShouldPaintIcon())
		nMinWidth = nMinWidth + m_nIconSize + m_nIconSpacing;

	if (pPopupMaker->m_bFolderArrow)
	{
		if (pPopupMaker->m_hbmArrow)
		{
			BITMAP bm;
			GetObject(pPopupMaker->m_hbmArrow, sizeof(BITMAP), &bm);
			nMinWidth = nMinWidth + bm.bmWidth + m_nIconSpacing;
		}
		else
		{
			nMinWidth = nMinWidth + 8 + m_nIconSpacing;
		}
	}

	pMinSize->cx = nMinWidth;
	pMinSize->cy = GetHeight();
}

void MenuItem::CalcRects(LPRECT prcItem, LPRECT prcContents, LPRECT prcIcon, LPRECT prcText, LPRECT prcArrow)
{
	RECT rcItem;
	RECT rc;
	RECT rcIcon;
	RECT rcText;
	RECT rcArrow;

	GetItemRect(&rcItem);

	CopyRect(&rc, &rcItem);
	rc.left = rc.left + GetIndent();
	rc.right = rc.right - GetRightIndent();

	CopyRect(&rcText, &rc);

	SetRect(&rcIcon, 0, 0, 0, 0);
	SetRect(&rcArrow, 0, 0, 0, 0);

	if (pPopupMaker->m_bFolderArrow)
	{
		int cxArrow = 8;
		int cyArrow = 9;

		if (pPopupMaker->m_hbmArrow)
		{
			BITMAP bm;
			GetObject(pPopupMaker->m_hbmArrow, sizeof(BITMAP), &bm);

			cxArrow = bm.bmWidth;
			cyArrow = bm.bmHeight;
		}

		rcArrow.right = rc.right;
		rcArrow.left = rcArrow.right - cxArrow;
		rcArrow.top = rc.top + ((rc.bottom - rc.top) - cyArrow) / 2;
		rcArrow.bottom = rcArrow.top + cyArrow;

		rcText.right = rcArrow.left - m_nIconSpacing;
	}

	if (pPopupMaker->m_bIcons && ShouldPaintIcon())
	{
		if (m_bIconsOnRight)
		{
			rcIcon.right = rcArrow.left - m_nIconSpacing;
			rcIcon.left = rcIcon.right - m_nIconSize;
			rcIcon.top = rc.top + ((rc.bottom - rc.top) - m_nIconSize) / 2;
			rcIcon.bottom = rcIcon.top + m_nIconSize;

			rcText.right = rcIcon.left - m_nIconSpacing;
		}
		else
		{
			rcIcon.left = rc.left;
			rcIcon.right = rcIcon.left + m_nIconSize;
			rcIcon.top = rc.top + ((rc.bottom - rc.top) - m_nIconSize) / 2;
			rcIcon.bottom = rcIcon.top + m_nIconSize;

			rcText.left = rcIcon.right + m_nIconSpacing;
		}
	}

	if (prcItem)
		CopyRect(prcItem, &rcItem);

	if (prcContents)
		CopyRect(prcContents, &rc);

	if (prcIcon)
		CopyRect(prcIcon, &rcIcon);

	if (prcText)
		CopyRect(prcText, &rcText);

	if (prcArrow)
		CopyRect(prcArrow, &rcArrow);
}

void MenuItem::DrawBackground(HDC hDC, CONST RECT *prc)
{
	if (m_bActive && m_pActiveBackground)
		m_pActiveBackground->Paint(hDC, prc);
	else if (m_pBackground)
		m_pBackground->Paint(hDC, prc);

	if (m_bDrawBevel)
		PaintBevel(hDC, prc->top);
}

void MenuItem::DrawIcon(HDC hDC, CONST RECT *prc)
{
	int x = prc->left;
	int y = prc->top;
	int nHeight = prc->bottom - prc->top;
	int nWidth = prc->right - prc->left;

	if (m_hIcon)
	{
		DrawIconEx(hDC, x, y, m_hIcon, nWidth, nHeight, 0, NULL, DI_NORMAL);
	}
	else if (m_hImageList && m_iIcon >= 0)
	{
		if (nWidth == 16 && nHeight == 16)
		{
			ImageList_Draw(m_hImageList, m_iIcon, hDC, x, y, ILD_TRANSPARENT);
		}
		else
		{
			HICON hIcon = ImageList_GetIcon(m_hImageList, m_iIcon, ILD_TRANSPARENT);
			DrawIconEx(hDC, x, y, hIcon, nWidth, nHeight, 0, NULL, DI_NORMAL);
			DestroyIcon(hIcon);
		}
	}
}

void MenuItem::DrawText(HDC hDC, CONST RECT *prc, LPCSTR pszText, UINT uFormat)
{
	Painter *pPainter;

	if (m_bActive && m_pActiveBackground)
		pPainter = m_pActiveBackground;
	else if (m_pBackground)
		pPainter = m_pBackground;
	else
		return ;

	HFONT hfnSave = (HFONT) SelectObject(hDC, pPainter->GetFont());
	COLORREF clrSave = SetTextColor(hDC, pPainter->GetFontColor());
	int nBkModeSave = SetBkMode(hDC, TRANSPARENT);

	RECT rcTemp;
	CopyRect(&rcTemp, prc);

	::DrawText(hDC, pszText, strlen(pszText), &rcTemp, uFormat);

	SelectObject(hDC, hfnSave);
	SetTextColor(hDC, clrSave);
	SetBkMode(hDC, nBkModeSave);
}

void MenuItem::DrawArrow(HDC hDC, CONST RECT *prc)
{
	if (!m_hbmArrow)
	{
		HPEN hpnDark = CreatePen(PS_SOLID, 1, m_nDarkColor);
		HPEN hpnLight = CreatePen(PS_SOLID, 1, m_nLightColor);
		HPEN hpnSave = (HPEN) SelectObject(hDC, hpnDark);

		MoveToEx(hDC, prc->left, prc->bottom - 1, NULL);
		LineTo(hDC, prc->left, prc->top);
		LineTo(hDC, prc->right - 1, ((prc->bottom - prc->top) / 2) + prc->top);
		SelectObject(hDC, hpnLight);
		LineTo(hDC, prc->left, prc->bottom - 1);

		SelectObject(hDC, hpnSave);
		DeleteObject(hpnLight);
		DeleteObject(hpnDark);
	}
	else
	{
		HBITMAP hbmArrow = m_bActive ? m_hbmSelArrow : m_hbmArrow;
		HDC hdcTemp = CreateCompatibleDC(hDC);
		HBITMAP hbmTemp = (HBITMAP) SelectObject(hdcTemp, hbmArrow);

		BITMAP bm;
		GetObject(hbmArrow, sizeof(BITMAP), &bm);

		int nWidth = prc->right - prc->left;
		int nHeight = prc->bottom - prc->top;
		int x = prc->left + (nWidth - bm.bmWidth) / 2;
		int y = prc->top + (nHeight - bm.bmHeight) / 2;

		TransparentBltLS(hDC, x, y, bm.bmWidth, bm.bmHeight, hdcTemp, 0, 0, RGB(255, 0, 255));

		SelectObject(hdcTemp, hbmTemp);
		DeleteDC(hdcTemp);
	}
}

LRESULT MenuItem::Command(WPARAM wParam, LPARAM lParam)
{
	return 0;
}

// returns true iif m1 < m2
bool MenuItem::Compare(MenuItem* m1, MenuItem* m2)
{
	int m1_sort = m1->GetSortPriority();
	int m2_sort = m2->GetSortPriority();

	if (m1_sort == m2_sort)
		return lstrcmpi(m1->GetSortString(), m2->GetSortString()) < 0;
	else
		return m1_sort > m2_sort;
}
