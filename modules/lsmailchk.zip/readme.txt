lsMailChk by ravEon>

This is Beta software and as such is not recommended
without parental guidance... 

lsMailChk is a Litestep Wharf module which checks
any number of POP3 accounts for new mail, in parallel.
When clicked it displays the new messages' headers.

The module assumes that your Litestep directory is 
C:\Litestep
you'll have to change it for it to work any other way.

There are probably other such hardcoded assumptions 
which i have forgotten about...
as well as all sorts of bugs, overlooked cases, misjudgements...
please feel free to mess about with the code...
or the executable...
(whichever suits your particular taste :)

if, sorry, When you find/fix/add anything, please let me
know at raveont@softhome.net


ok, so here's how it works:

Step.rc entry: 
*Wharf MailChk .none @C:\...\wMailChk.dll

To list accounts for the module to check, add entries 
of the following format into your Modules.ini 
(which is in your Litestep path... i.e. C:\Litestep\modules.ini)

[MailChk]
Interval=1  				;check every x minutes

;Account 1
Account SoftHome			;friendly name for the account
ServerName=pop.goestheweasle.com	;Server
UserName=SlimShady			;...
Password=DreSentMe			;...
Color=0x00FFFF				;color in which to display headers.

;Account 2
;... all over again


------------------------------------------------------------------------

License:

This software is released in the belief that it and/or it's source code 
might be useful to other people.
Please respect that, and keep it in mind if/when you make any alterations.

The Terms for distributing this software are those stated in 
The GNU General Public License.
See http://www.gnu.org for details.
In short, this means that in any redistribution of either the original 
or a modified version of the software, the related source code must be 
made available.

I take no responsibility, expressed or implied, for anything which may 
happen, either directly or indirectly, as a result of using the software 
and/or it's source code, 
or anything, including drugs,
now or ever, 
here or anywhere, 
to you, your PC, your family, friends, co-workers, pets, or anyone,
etc.

I love you all,
Peace.