#ifndef __CHDRSTORE_H
#define __CHDRSTORE_H

#include <stdio.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef WIN32_LEAN_AND_MEAN

class cHdrStore {

private:
	int acntlen;

public:

	char *AccountName;
	short HdIndex;
	char *Headers[50];
	unsigned short HeaderStrlens[50];
	COLORREF Color;

	cHdrStore(const char *acntName);
	~cHdrStore();

	void SetSystemHeader(char *Message, unsigned char MessageLen);
	void AddHeader(char *Sender, unsigned char SenderLen, char *Subject, unsigned char SubjectLen);
	void DeleteHeaders();
	int GetHeadersString(char**Dest);
};

#endif
