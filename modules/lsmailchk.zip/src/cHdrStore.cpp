#include "cHdrStore.h"

cHdrStore::cHdrStore(const char *acntName)
{
	acntlen = strlen(acntName);
	AccountName = new char[acntlen+1];
	memset(AccountName,0,acntlen+1);
	strncat(AccountName,acntName,acntlen);

	memset(Headers,0,50);
	memset(HeaderStrlens,0,50);
	HdIndex = (-1);	
	Color=RGB(0,255,255);
}

cHdrStore::~cHdrStore()
{
	DeleteHeaders();
	 delete[] AccountName;
	AccountName=0;
	acntlen=0;
}

void cHdrStore::DeleteHeaders()
{
	for ( ; HdIndex > (-1) ; HdIndex--) {
		if (Headers[HdIndex]) {
			delete[] Headers[HdIndex];
			Headers[HdIndex]=0;
			HeaderStrlens[HdIndex]=0;
		}
	}
	HdIndex=(-1);
}	

void cHdrStore::SetSystemHeader(char *Message, unsigned char MessageLen)
{	
	if (HdIndex==(-1)) HdIndex=0;
	if (Headers[0]) delete[] Headers[0];

	int ln = acntlen+MessageLen+14;
	Headers[0] = new char[ ln];
	memset(Headers[0],0,ln);
	HeaderStrlens[0] = ln-1; //strlen
	
	strncat(Headers[0]," ~~~ ",5);
	strncat(Headers[0],AccountName,acntlen);
	strncat(Headers[0]," - ",3);
	strncat(Headers[0],Message,MessageLen);
	strncat(Headers[0]," ~~~ ",5);
}

void cHdrStore::AddHeader(char *Sender, unsigned char SenderLen, char *Subject, unsigned char SubjectLen)
{
	if (HdIndex >= 49) return;	//otherwise incremented inside transaction loop
	if (HdIndex < 1) HdIndex = 1;
	if (Headers[HdIndex]) delete[] Headers[HdIndex];

	if (Sender[0] == '\"') { 	
		char *stp = (char*) (Sender + SenderLen);
		char *tmp = Sender;

		Sender++;  SenderLen--;
		do { tmp++; } while (*tmp != '\"');
		while (tmp != stp) { *tmp = *(tmp + 1);	tmp++;	}
		SenderLen--;
	}

	int ln = SenderLen+SubjectLen+10;
	Headers[HdIndex] = new char[ ln];
	memset(Headers[HdIndex],0,ln);
	HeaderStrlens[HdIndex] = ln-1; //strlen
	
	strncat(Headers[HdIndex],"  *",3);
	strncat(Headers[HdIndex],Sender,SenderLen);
	strncat(Headers[HdIndex],"  ",2);
	strncat(Headers[HdIndex],"\"",1);
	strncat(Headers[HdIndex],Subject,SubjectLen);
	strncat(Headers[HdIndex],"\"  ",3);
}


int cHdrStore::GetHeadersString(char **Dest)
{
	char *Str;
	int fln=0, i; 
	if (HdIndex < 0) return (-1);

	for (i=0; i<=HdIndex; i++) {
		if (i>0) fln+=2; //"\r\n"
		fln +=  HeaderStrlens[i];
	}

	Str = new char[fln+1];
	memset(Str,0,fln+1);	
	
	for (i=0; i<=HdIndex; i++) {
		if (i>0) strncat(Str,"\r\n",2);
		strncat (Str,Headers[i], HeaderStrlens[i]);
	}

	*Dest = Str;
	return fln;
}


