#ifndef __CACCOUNT_H
#define __CACCOUNT_H

#include <Winsock2.h > 
#include "cHdrStore.h"

#define ACERR_INVALIDPASS (-1)
#define ACERR_CONNLOST (-2)
#define ACERR_UNKNOWN (-3)

class cAccount {

private:

	enum eAccountState {
		eas_Connect,
		eas_RecvFirstResponse,
		eas_SendUserName,
		eas_RecvUserNameOK,
		eas_SendUserPass,
		eas_RecvUserPassOK,
		eas_SendStatRequest,
		eas_RecvStatResponse,
		eas_ChkStatResponse,
		eas_RequestHeader,
		eas_RecvHeader,
		eas_ChkHeader,
		eas_RecvMsgPart,
		eas_ChkMsgPart,
		eas_SendQuitMsg,
		eas_RecvQuitResponse,
		eas_Shutdown
	};

	int myState;
	int mySocket; 
	OVERLAPPED myOverlapped;
	struct sockaddr_in destAddr, myAddr;
	unsigned long myDestIP;
	int hostlen, userlen, passlen;
	char buffy[0x1000];
	DWORD rwbytes;
	FILE *CurMsgFile;

	inline int ChkRecv();
	
public:
	
	cHdrStore *HeaderStore;
	short NumMessages;
	char *HostName, *UserName, *UserPass;
	BOOL isFinished;
	HANDLE hEvent;
	static BOOL fRetrieveMsgs;
			
	cAccount(const char *hostName, const char *userName, const char *userPass, const char *acntName = 0);
	~cAccount();

	int InitActivate();
	int Shutdown();
	void Go();
};

#endif
