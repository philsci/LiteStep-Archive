#ifndef __MAILCHK_H
#define __MAILCHK_H

#define NO_STRICT

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#undef WIN32_LEAN_AND_MEAN
#include <stdlib.h>
#include <process.h>
#include "...\LS\wharfdata.h"

#ifndef EXTERN_C
  #ifdef __cplusplus
    #define EXTERN_C extern "C"
  #else
    #define EXTERN_C
  #endif
#endif

#define DEFAULT_CHK_INTERVAL 90000
#define MAX_ACCOUNTS 50

#define POPUP_MIN_HEIGHT 64
#define POPUP_MIN_WIDTH 256

LRESULT WINAPI WharfWndProc( HWND, UINT, WPARAM, LPARAM);
unsigned int _stdcall ChkMailThreadFunc(void* lpParameter);
void OldPopupHeaders(); //Not Used
void PopupHeaders();
int CreateBitmaps(HWND, HINSTANCE);
BOOL ReadModConfig();
BOOL GetModEntry(char* Entry, unsigned short lnEntry, char *Src, char *Dest, int *maxPos);
COLORREF HexClrStr2Int (char *HexClr);    //HexClr Must be of form 0xCCFF33  or CCFF33

#endif
