#include "MailChk.h"
#include "cAccount.h"

HWND hWharfWindow;
HWND hPopupWindow;
HINSTANCE hAppInstance;
HBITMAP hbmpEmptyBox=NULL, hbmpFullBox=NULL, hbmpEmptyErrBox=NULL, hbmpFullErrBox=NULL;

BOOL fIsConnected=0;
HANDLE hCnThread;
unsigned int ThreadID;
HANDLE hChkMailEvent;
BOOL fQuittingTime;

cAccount *MyAccounts[MAX_ACCOUNTS];
int rMsgs=0;
BOOL rErrs=FALSE;

unsigned long ChkTimeInterval;
int TimerID;
char StrHeaders[0x1000];
char *StrRetrievePath=NULL;

// initWharfModule
EXTERN_C __declspec( dllexport ) int initWharfModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	int retval=0, i;
	WNDCLASSEX wc = {0};
	
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = (WNDPROC) WharfWndProc;
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.hbrBackground = (HBRUSH)GetStockObject(GRAY_BRUSH);
	wc.lpszClassName = "WharfChkMail";
	RegisterClassEx( &wc );

	hWharfWindow = CreateWindowEx( WS_EX_TOOLWINDOW, "WharfChkMail",  "eMail Chkr",
													    WS_CHILD,0, 0, 64, 64, hParent,NULL,hInstance,NULL );

	if (CreateBitmaps(hWharfWindow,hInstance)==-1) {  retval=1;  goto ErrHandler; }
	for(i=0; i<MAX_ACCOUNTS; i++)	MyAccounts[i] = 0;   //treated as null-terminated all thru the code
	if ( ! ReadModConfig() )  {  retval=2;  goto ErrHandler; }

	hChkMailEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	hCnThread = (HANDLE)_beginthreadex(NULL,0,ChkMailThreadFunc,0,0,&ThreadID);
	TimerID = SetTimer(hWharfWindow,1,ChkTimeInterval,0);		

	SetWindowLong(hWharfWindow, GWL_USERDATA, magicDWord );
	ShowWindow( hWharfWindow, SW_SHOWNOACTIVATE );

Exit:
	return retval;

ErrHandler:
	if (retval==1)
		MessageBox (hWharfWindow,"Error Creating Bitmaps", "!",MB_OK); 
	else if (retval==2)
		MessageBox (hWharfWindow,"Error Getting Account Information", "!",MB_OK); 
	DestroyWindow(hWharfWindow);
	UnregisterClass( "WharfChkMail", hInstance );
	goto Exit;
}

EXTERN_C __declspec( dllexport ) void quitWharfModule( HINSTANCE hInstance )
{
	DestroyWindow( hWharfWindow);
	CloseHandle(hChkMailEvent);
	CloseHandle(hCnThread);
	for (int i=0; MyAccounts[i]; i++) {
		delete MyAccounts[i];
		MyAccounts[i]=0;
	}
	if (StrRetrievePath) free(StrRetrievePath);
	DeleteObject(hbmpEmptyBox);
	DeleteObject(hbmpFullBox);
	DeleteObject(hbmpEmptyErrBox);
	DeleteObject(hbmpFullErrBox);
	UnregisterClass( "WharfChkMail", hInstance );
}

EXTERN_C int APIENTRY DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )  
		DisableThreadLibraryCalls( hInstance );
	hAppInstance = hInstance;
	return 1;
}

LRESULT WINAPI WharfWndProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam )
{
	static int xPos, yPos;
	static PAINTSTRUCT ps;
	static HDC hDC, mDC;
	static HBITMAP hOldBmp;

	switch( nMessage )	{

		case WM_CREATE:
			fQuittingTime = FALSE;
			return 0;

		case WM_TIMER:
			PulseEvent(hChkMailEvent);
			return 0;

		case WM_PAINT: 
			hDC = BeginPaint( hWnd, &ps );
			mDC = CreateCompatibleDC(hDC);
			if (rMsgs>0) {
				if ( !rErrs) hOldBmp = SelectObject(mDC,hbmpFullBox);
				else hOldBmp = SelectObject(mDC,hbmpFullErrBox);
			} else {
				if ( !rErrs) hOldBmp = SelectObject(mDC,hbmpEmptyBox);
				else hOldBmp = SelectObject(mDC,hbmpEmptyErrBox);
			}
			BitBlt(hDC,0,0,64,64,mDC,0,0,SRCCOPY);
			SelectObject(mDC,hOldBmp);
			DeleteDC(mDC);
			EndPaint( hWnd, &ps );
			return 0;	

		case WM_LBUTTONDOWN:
			SetCapture(hWharfWindow);
			PopupHeaders();
			return 0;	

		case WM_LBUTTONUP:
			ShowWindow(hPopupWindow,SW_HIDE);
			DestroyWindow(hPopupWindow);
			ReleaseCapture();
			return 0;

		case WM_DESTROY:
			KillTimer(0,TimerID);
			if (hCnThread) {
				fQuittingTime = TRUE;
				PulseEvent(hChkMailEvent);
				WaitForSingleObject(hCnThread,INFINITE);
			}
			return 0;
	}

	return DefWindowProc( hWnd, nMessage, wParam, lParam );
}

unsigned int _stdcall ChkMailThreadFunc(void* lpParameter)
{
	WSADATA	Wdata={0};
	HANDLE hAccountEvents[MAX_ACCOUNTS + 1] = {0};
	int Events2Accounts[MAX_ACCOUNTS + 1] = {0};
	int NumActive=1, CurRet=0, acIndx=0, i=0;
	
	//Initialize
	Wdata.wHighVersion=2;
	Wdata.wVersion=2;
	if(WSAStartup(2,&Wdata))  goto CleanUp;

	fIsConnected = FALSE;

	hAccountEvents[0] = hChkMailEvent;
	Events2Accounts[0] = 0;

	for(;;) {

		CurRet=WaitForMultipleObjects(NumActive,hAccountEvents,0,INFINITE) - WAIT_OBJECT_0;
		if (fQuittingTime) break;

		if (CurRet==0 && NumActive==1) {   //if (CurRet==0 && NumActive > 1) do nothing... means we haven't finished last time

			if ( ! fIsConnected) {
				for (i=0; MyAccounts[i]; i++) {
					if (MyAccounts[i]->InitActivate()==(-1)) { 	
						for (int j=0; j<i; j++) MyAccounts[j]->Shutdown();
						fIsConnected = FALSE;		
						break;	
					} else 	fIsConnected = TRUE;
				}
			}

			if (fIsConnected) {
				for (i=0; MyAccounts[i]; i++)  {
					hAccountEvents[i+1] = MyAccounts[i]->hEvent;
					Events2Accounts[i+1] = i;
					NumActive++;
					MyAccounts[i]->Go();
				}
			} 
	
		} else if (CurRet>0) {
			acIndx = Events2Accounts[CurRet] ;

			if (MyAccounts[acIndx]->isFinished) {
				for (int i=CurRet+1; i<NumActive; i++) {
					hAccountEvents[ i-1] = hAccountEvents[i] ;
					Events2Accounts[ i-1] = Events2Accounts[i] ;
				}
				NumActive--;
				hAccountEvents[NumActive]=0;
				Events2Accounts[NumActive]=0;

			} else MyAccounts[acIndx]->Go();

		} else if (CurRet<0) {
			int err;
			if (CurRet==(-1)) err = GetLastError();
			MessageBox(hWharfWindow,"Error in MultipleWait", "!!!!!!!!!!!!!!!!!!!!!!!",MB_OK);
		}  
		
		if (NumActive==1) {
			rMsgs = 0;
			rErrs = FALSE;
			for (i=0; MyAccounts[i]; i++) {
				if (MyAccounts[i]->NumMessages <0) rErrs=TRUE;
				else rMsgs += MyAccounts[i]->NumMessages;
			}
			InvalidateRect(hWharfWindow,0,FALSE);
		}
	}
	
	//at Quitting Time...	
	for (i=0; MyAccounts[i]; i++)   MyAccounts[i]->Shutdown();

CleanUp:
	WSACleanup();
	_endthreadex (0);
}

void PopupHeaders()  
{
	HDC hDC;
	HFONT hFont;
	RECT winrect={0};
	BOOL fOpen2Right=FALSE;
	char *tmpHeaders[MAX_ACCOUNTS] = {0};
	RECT tmpRects[MAX_ACCOUNTS];
	int minx=0, miny=0, ln=0, i=0, yOffset=0;
	
	
	GetWindowRect(hWharfWindow,&winrect);  //Get the Wharf module window's position and turn it into the Popup window's position.
	if ( winrect.left + (winrect.right-winrect.left)/2 < (GetSystemMetrics(SM_CXSCREEN)/2) ) {   
		fOpen2Right = TRUE;
		winrect.left = winrect.right;
	} else	winrect.left = winrect.left-POPUP_MIN_WIDTH;

	hPopupWindow = CreateWindow("STATIC","Headers",
																SS_CENTER|SS_SUNKEN|SS_BLACKFRAME|SS_NOTIFY|WS_POPUP,
																winrect.left, winrect.top, POPUP_MIN_WIDTH, POPUP_MIN_HEIGHT, 
																hWharfWindow,NULL,hAppInstance,NULL);
		
	hDC = GetDC(hPopupWindow);	
	SetBkMode(hDC,TRANSPARENT);
	hFont = SelectObject ( hDC, CreateFont(14,0,0,0,200,0,0,0,ANSI_CHARSET, 
											 OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
											 DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE, 
											 "Comic Sans MS") );
	
	GetWindowRect(hPopupWindow,&winrect);

	for (i=0; MyAccounts[i]; i++) 
		if ( ( ln = MyAccounts[i]->HeaderStore->GetHeadersString(&tmpHeaders[i]) ) > 0 ) {
			memset(&tmpRects[i],0,sizeof(tmpRects[i]));
			DrawText(hDC, tmpHeaders[i], ln, &tmpRects[i], DT_CALCRECT);
			if (tmpRects[i].right > minx )  minx = tmpRects[i].right;
			miny += tmpRects[i].bottom;
		}

	if ( (winrect.bottom - winrect.top) < miny )
		winrect.bottom = winrect.top + miny;
	if ( (winrect.right - winrect.left) < minx ) {
		if (fOpen2Right)  winrect.right = winrect.left + minx;
		else  winrect.left = winrect.right - minx;
	}
	
	SetWindowPos(hPopupWindow, 0, winrect.left, winrect.top, winrect.right - winrect.left, winrect.bottom - winrect.top, SWP_NOZORDER);
	ShowWindow(hPopupWindow,SW_SHOWNA);	
	
	for (i=0; tmpHeaders[i] ; i++)  {
		SetTextColor(hDC,MyAccounts[i]->HeaderStore->Color);	
		if (i>0)  {  tmpRects[i].top += tmpRects[i-1].bottom;	tmpRects[i].bottom += tmpRects[i-1].bottom;	}
		DrawText(hDC, tmpHeaders[i], strlen(tmpHeaders[i]), &tmpRects[i], DT_NOCLIP|DT_WORD_ELLIPSIS|DT_WORDBREAK);
		delete[] tmpHeaders[i];
	}

	DeleteObject(SelectObject(hDC,hFont));
	ReleaseDC(hPopupWindow,hDC);
}

BOOL ReadModConfig()  //uses StrHeader as the File Buffer since it's not being used for headers yet.
{
	int ttl=0, skip=0, indx=0;
	FILE *modini;
	char *mrkstrt=0, *mrkend=0;
	char *AcntNm, *Server, *User, *Pass;

	modini = fopen("C:\\Litestep\\Modules.ini","rt");
	if (!modini) return FALSE;
	fseek(modini,0,SEEK_SET);

	AcntNm = (char*) malloc(0x40);
	Server = (char*) malloc(0x40);
	User = (char*) malloc(0x40);
	Pass = (char*) malloc(0x40);

	memset(StrHeaders,0,0x1000);
	ttl=fread(StrHeaders,sizeof(char),0x1000,modini);
	if (ttl < 0x1000  &&  !feof(modini)) return FALSE;
	fclose(modini);

	mrkstrt = strstr(StrHeaders,"[MailChk]");
	if (!mrkstrt)  {
		mrkstrt = strstr(StrHeaders,"[MAILCHK]");
		if (!mrkstrt) {
			mrkstrt = strstr(StrHeaders,"[mailchk]");
			if (!mrkstrt)   return FALSE;
		}
	}
	mrkend = strstr(mrkstrt+2,"[")-1;

	if ( GetModEntry("Interval",8,mrkstrt,AcntNm,&skip) )   // AcntNm used as temp...
		ChkTimeInterval = atol(AcntNm) * 60000;
	else 
		ChkTimeInterval = DEFAULT_CHK_INTERVAL;

	if ( GetModEntry("bRetrieve",9,mrkstrt,AcntNm,&skip)  &&  atoi(AcntNm) !=0 ) {
		cAccount::fRetrieveMsgs = TRUE;		
		StrRetrievePath = (char*)malloc(0x100);
		memset(StrRetrievePath,0,0x100);
		GetModEntry("RetrievedMsgsPath",17,mrkstrt,StrRetrievePath,&skip);
		int l=strlen(StrRetrievePath);
		if (StrRetrievePath[ l-1] != '\\') {
			StrRetrievePath[ l ]= '\\';
			StrRetrievePath[ l+1] = 0;
		}
	}	else  cAccount::fRetrieveMsgs = FALSE; 

	do{
		if ( ! GetModEntry("Account",7,mrkstrt,AcntNm,&skip) ) break;
		GetModEntry("ServerName",10,mrkstrt,Server,&skip);
		GetModEntry("UserName",8,mrkstrt,User,&skip);
		GetModEntry("Password",8,mrkstrt,Pass,&skip);
		
		if (indx < MAX_ACCOUNTS) {
			if (strlen(AcntNm)) 
				MyAccounts[indx++] = new cAccount(Server,User,Pass,AcntNm);
			else 
				MyAccounts[indx++] = new cAccount(Server,User,Pass);
		}
		if ( GetModEntry("Color",5,mrkstrt,AcntNm,&skip) )
			MyAccounts[indx-1]->HeaderStore->Color = HexClrStr2Int(AcntNm);
	
		mrkstrt += skip;

	} 	while ( mrkstrt<mrkend ) ;
	
	free(Server); free(User); free(Pass); free(AcntNm);
	memset(StrHeaders,0,0x1000); //reset it

	if (indx)  return TRUE;
	else return FALSE;
}

BOOL GetModEntry(char* Entry, unsigned short lnEntry, char *Src, char *Dest, int *maxPos)
{
	static unsigned short cnt;
	static char *walker; 
	
	walker =  strstr(Src,Entry) ;
	if (!walker) {
		char *tmp;
		tmp = _strupr( _strdup(Entry));
		walker =  strstr(Src,tmp);
		if (!walker) {
			tmp = _strlwr(tmp); 
			walker =  strstr(Src,tmp);
			free (tmp);
			if ( !walker) return FALSE;
		} else free (tmp);
	}
	
	cnt=0;
	walker += lnEntry;
	
	while (*walker==' ' || *walker=='=')  walker++;
	while(*walker != '\n' && *walker != '\r' && *walker != ';')
		Dest[cnt++] = *walker++;
	Dest[cnt]=0;
	while (isspace(Dest[cnt-1]))  cnt--;
	Dest[cnt]=0;

	if ( (walker-Src) > *maxPos )   *maxPos = (walker-Src);
	return TRUE;
}	

COLORREF HexClrStr2Int (char *HexClr)    //HexClr Must be of form 0xCCFF33  or CCFF33
{
	char *strt, *wlk;
	int tmpNum=0, plc=5;
	int clrs[3]={0}, cur=2;
	
	strt = HexClr;
	if (strt[0]=='0' && strt[1]=='x') strt+=2;
		
	do {
		wlk = strt+plc;
		if (isdigit(*wlk)) tmpNum=*wlk-48;
		else tmpNum = *wlk-55;
		if (plc%2) clrs[cur] = tmpNum;
		else { clrs[cur] += 16*tmpNum;  cur--; }
		plc--;
	} while (cur >= 0);
			 
	return (RGB(clrs[0],clrs[1],clrs[2]));
}

int CreateBitmaps(HWND hWnd, HINSTANCE hInstance)
{
	int retval=0;

	hbmpEmptyBox  = LoadImage(hInstance,MAKEINTRESOURCE(104),IMAGE_BITMAP,64,64,0);
	if (!hbmpEmptyBox)  goto ErrHandler;
	hbmpFullBox = LoadImage(hInstance,MAKEINTRESOURCE(105),IMAGE_BITMAP,64,64,0);
	if (!hbmpFullBox)  goto ErrHandler;
	hbmpEmptyErrBox = LoadImage(hInstance,MAKEINTRESOURCE(108),IMAGE_BITMAP,64,64,0);
	if (!hbmpEmptyErrBox)  goto ErrHandler;
	hbmpFullErrBox = LoadImage(hInstance,MAKEINTRESOURCE(107),IMAGE_BITMAP,64,64,0);
	if (!hbmpFullErrBox)  goto ErrHandler;
	
CleanUp:
	return retval;

ErrHandler:
	if(hbmpEmptyBox) DeleteObject(hbmpEmptyBox); 
	if(hbmpFullBox) DeleteObject(hbmpFullBox);
	if(hbmpEmptyErrBox) DeleteObject(hbmpEmptyErrBox);
	if(hbmpFullErrBox) DeleteObject(hbmpFullErrBox);
	retval = -1;
	goto CleanUp;
}
