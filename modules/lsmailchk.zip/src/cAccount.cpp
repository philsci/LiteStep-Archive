#include "cAccount.h"

#define CLEAR_BUFFY memset(buffy,0,sizeof(buffy))
#define SIZEOF_BUFFY sizeof(buffy)-1

BOOL cAccount::fRetrieveMsgs;

cAccount::cAccount(const char *hostName, const char *userName, const char *userPass, const char *acntName /*= 0*/)
{
	hostlen = strlen(hostName);
	userlen = strlen(userName);
	passlen = strlen(userPass);

	HostName = new char[hostlen+1];
	memset(HostName,0,hostlen+1);
	strncat(HostName,hostName,hostlen);

	if (acntName) 
		HeaderStore = new cHdrStore(acntName);
	else
		HeaderStore = new cHdrStore(HostName);
	HeaderStore->SetSystemHeader("Not Connected",13);

	UserName = new char[userlen+8];
	memset(UserName,0,userlen+8);
	strncat(UserName,"USER ",5);
	strncat(UserName,userName,userlen);
	strncat(UserName,"\r\n",2);
	userlen+=7;  //strlen("USER <username>\r\n")

	UserPass = new char[passlen+8];
	memset(UserPass,0,passlen+8);
	strncat(UserPass,"PASS ",5);
	strncat(UserPass,userPass,passlen);
	strncat(UserPass,"\r\n",2);
	passlen+=7;  //strlen("PASS <passwd>\r\n")

	memset(&myOverlapped,0,sizeof(myOverlapped));
	memset(&myAddr,0,sizeof(myAddr));
	memset(&destAddr,0,sizeof(destAddr));
	myState = (-1);	
	NumMessages=0;
	myDestIP = rwbytes = 0;
	isFinished=FALSE;
}

cAccount::~cAccount()
{
	delete HeaderStore;
	delete[] HostName;
	delete[] UserName;
	delete[] UserPass;
	HostName=UserName=UserPass=0;
	hostlen=userlen=passlen=0;
}

int cAccount::InitActivate()
{

	hostent *he = gethostbyname(HostName);
	if (!he) return (-1);
	myDestIP = *(unsigned long*)he->h_addr_list[0];

	hEvent = CreateEvent(NULL,FALSE,FALSE,0);
	myOverlapped.hEvent = hEvent;

	HeaderStore->SetSystemHeader("Connected - Mail not checked yet",32);
	myState = eas_Connect;

	return 0;
}

int cAccount::Shutdown()
{
	if (mySocket) {
		CancelIo((HANDLE)mySocket);
		shutdown(mySocket,SD_BOTH);
		closesocket(mySocket); 
		mySocket=0;
	}  
	CloseHandle(hEvent);
	return 0;
}

inline int cAccount::ChkRecv()
{
	if ( (rwbytes = strlen(buffy)) == 0 || buffy[0] =='-') {  
		if ( !rwbytes ) 
			NumMessages=ACERR_CONNLOST;
		else 
			NumMessages=ACERR_UNKNOWN;
		return (-1);
	} else {
		buffy[rwbytes]=0;
		return 0;
	}
}

void cAccount::Go()
{
	BOOL fNeedToPulse = FALSE;

	switch(myState) {
		
		case eas_Connect:	
			isFinished = FALSE;

			mySocket=socket(AF_INET,SOCK_STREAM,0);
			bind(mySocket,(sockaddr*)&myAddr,sizeof(myAddr));	

			destAddr.sin_family=AF_INET;
			destAddr.sin_port=htons(110);
			destAddr.sin_addr.S_un.S_addr= myDestIP;			
			if (connect(mySocket,(sockaddr*)&destAddr,sizeof(destAddr)) == SOCKET_ERROR) {
				NumMessages=ACERR_CONNLOST;
				goto ErrHandler;
			} 			
			fNeedToPulse = TRUE;
			break;

		case eas_RecvFirstResponse:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_SendUserName:
			if ( ! ChkRecv())  {
				WriteFile((HANDLE)mySocket,UserName,userlen,&rwbytes,&myOverlapped);
				break;
			} else goto ErrHandler;		

		case eas_RecvUserNameOK:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_SendUserPass:
			if ( ! ChkRecv())  {
				WriteFile((HANDLE)mySocket,UserPass,passlen,&rwbytes,&myOverlapped);
				break;
			} else goto ErrHandler;		

		case eas_RecvUserPassOK:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_SendStatRequest:
			if ( ! ChkRecv())  {
				WriteFile((HANDLE)mySocket,"STAT\r\n",6,&rwbytes,&myOverlapped);
				break;
			} else {
				NumMessages = ACERR_INVALIDPASS;
				goto ErrHandler;		
			}

		case eas_RecvStatResponse:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_ChkStatResponse:
			////////////////////////////////////////////////////////////////////////////////
			NumMessages=0;
			HeaderStore->DeleteHeaders();
			HeaderStore->SetSystemHeader("Now Receiving...",16);

			if ( ! ChkRecv() && rwbytes >= 4 &&  buffy[4] != '0') {
				for ( char steps=0;  buffy[4+steps] != ' '; steps++);
				if (steps>1) {
					for (; steps>=0; steps--) {
						int tens=1;
						for (int j=0; j<steps; j++)
							tens = tens*10;
						NumMessages += tens*(atoi(&buffy[4+steps]));
					}
				}
				NumMessages+=(atoi(&buffy[4]));
			}  
			if ( ! NumMessages )  {
				HeaderStore->SetSystemHeader("No New Messages",15);
				myState = eas_SendQuitMsg;
				goto QuitSeq;
			} else 	++myState; //fallthru

Ask4Hdr:
		case eas_RequestHeader: 
			CLEAR_BUFFY;
			HeaderStore->HdIndex++;
			sprintf(buffy,"TOP %d 0\r\n",(HeaderStore->HdIndex));
			WriteFile((HANDLE)mySocket,buffy,strlen(buffy),&rwbytes,&myOverlapped);
			break;

GetRead:
		case eas_RecvHeader:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_ChkHeader: 
			if ( ! ChkRecv() ) {
				char *sndr, *sndrln, *sbjct, *sbjctln;
				if ( (sndr = strstr(buffy,"From:")) != NULL) {
					sndr+=6;
					sndrln = strstr(sndr,"\r\n");
					sbjct = strstr(buffy,"Subject:");
					if (sbjct) {
						sbjct += 9;
						sbjctln = strstr(sbjct,"\r\n");
						HeaderStore->AddHeader ( sndr, (unsigned char)(strlen(sndr)-strlen(sndrln)), sbjct, (unsigned char)(strlen(sbjct)-strlen(sbjctln)));
					} else {
						HeaderStore->AddHeader ( sndr, (unsigned char)(strlen(sndr)-strlen(sndrln)), "No Subject", 10);
					}
				}  else if (buffy[0] == '+') {
					myState = eas_RecvHeader;
					goto GetRead;
				}
			} 
			if ( ! cAccount::fRetrieveMsgs ) {
				myState=eas_ChkMsgPart;
				goto CloseUpThisMsg;
			}
			CurMsgFile = fopen("C:\\Windows\\Temp\\lalala.msg","wb");
			CLEAR_BUFFY;
			sprintf(buffy,"RETR %d\r\n",(HeaderStore->HdIndex));
			WriteFile((HANDLE)mySocket,buffy,strlen(buffy),&rwbytes,&myOverlapped);
			break;

Retrieve:
		case eas_RecvMsgPart:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

		case eas_ChkMsgPart: 
			if ( ! ChkRecv()) {
				fwrite(buffy,sizeof(char),strlen(buffy),CurMsgFile);
				if ( strncmp((buffy+rwbytes-3), ".\r\n",3) ) {
					myState = eas_RecvMsgPart;
					goto Retrieve;
				} else {   fclose(CurMsgFile);  CurMsgFile=0; }				
			}

CloseUpThisMsg:
			if (HeaderStore->HdIndex < NumMessages) {
				myState = eas_RequestHeader;   
				goto Ask4Hdr;
			} else {
				if (NumMessages > 1) {
					CLEAR_BUFFY;
					sprintf(buffy,"Received %d messages",NumMessages);
					HeaderStore->SetSystemHeader(buffy,strlen(buffy));
				} else HeaderStore->SetSystemHeader("Received 1 message",18);
				++myState;		//fallthru
			}

QuitSeq:
		case eas_SendQuitMsg:
			WriteFile((HANDLE)mySocket,"QUIT\r\n",6,&rwbytes,&myOverlapped);
			break;

		case eas_RecvQuitResponse:
			CLEAR_BUFFY;
			ReadFile((HANDLE)mySocket,buffy,SIZEOF_BUFFY,&rwbytes,&myOverlapped);
			break;

Shutdown:
		case eas_Shutdown:
		default:
			if (mySocket) {   //group Shutdown and state overflow err...
				shutdown(mySocket,SD_BOTH);
				closesocket(mySocket); 
				mySocket=0;
			}  
			isFinished=TRUE;
			myState=(-1);
			fNeedToPulse = TRUE;
			break;
	}

	//out of the switch
	if (myState>=(-1)) myState++;
	if (fNeedToPulse) SetEvent(myOverlapped.hEvent);
	return;

ErrHandler:
	if (HeaderStore->HdIndex>(-1))  HeaderStore->DeleteHeaders();
	switch (NumMessages) {
		case ACERR_INVALIDPASS:
			HeaderStore->SetSystemHeader("Server won't let us in !!! (Chk u'r password, or try a lower checkmail rate)",76);
			break;
		case ACERR_CONNLOST:
			if (myState==eas_Connect)  HeaderStore->SetSystemHeader("Not Connected",13);
			else  HeaderStore->SetSystemHeader("Connection to server lost",25);
			break;
		case ACERR_UNKNOWN:
			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,0,WSAGetLastError(),5,buffy,SIZEOF_BUFFY,0);
			HeaderStore->SetSystemHeader(buffy,strlen(buffy));
			break;
	}
	goto Shutdown;
}
