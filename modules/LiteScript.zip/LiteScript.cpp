#include <windows.h>
#include "exports.h"
#include "lsapi.h"

const long magicDWord = 0x49474541;

struct Command
{
	char cmd[256];

	struct Command* next;
};

struct Variable
{
        char var[256];
        char val[256];
        struct Variable* next;
} *vars;

class NewBang
{
public:
	NewBang(char* p);
	void Execute();
	void AddCommand(char*);

	HWND hwnd;
	char name[256];
	Command* cmds;
	NewBang* next;
};

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void AddVariable(char* var, char* val);
void BangHandler(HWND caller, LPCTSTR args, LPCTSTR name);
char* ExpandVariable(char* cmd);
char* GetVariable(char* var);
void LoadSetup();
NewBang* FindBangByName(LPCTSTR name);

void BangReport(HWND caller, LPCTSTR name, LPCTSTR args);

char* szAppName = "LiteScript";

HWND parent, hwndMain;
HINSTANCE hInstance;
int ScreenX, ScreenY;
char lsdir[MAX_PATH] = "";
int msgs[] = {LM_GETREVID, LM_REPAINT, 0};
char* TERMINATORS = " \t\n\r\0";
int DELAY=0;

NewBang* head;

int initModuleEx(HWND hparent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	hInstance = dllInst;
	parent = hparent;
	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	hwndMain = CreateWindow(szAppName, szAppName, WS_POPUP, 0, 0, 0, 0, NULL, NULL, hInstance, NULL);
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

	LoadSetup();

	return 0;
}

int quitModule(HINSTANCE dll)
{
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	while (head)
	{
		NewBang* nb = head;
		head=head->next;
		RemoveBangCommand(nb->name);

		while (nb->cmds)
		{
			Command* c = nb->cmds;
			nb->cmds = nb->cmds->next;
			delete c;
		}

		delete nb;
	}

	head=NULL;
	RemoveBangCommand("!LiteScriptReport");

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);

			switch (wParam)
			{
				case 0:
					sprintf(buf, "LiteScript 1.2 (MrJukes)\0");
				break;
				case 1:
					sprintf(buf, "LiteScript 1.2 (MrJukes)\0");
				break;
				default:
					sprintf(buf, "LiteScript 1.2 (MrJukes)\0");
			}

			return strlen(buf);
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_MOUSEMOVE:
		{
			SetCursor(LoadCursor(NULL, IDC_ARROW));
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void LoadSetup()
{
	// *WM X Y W H back.bmp #T

	char temp[256] = "";
	FILE* step;
	char	token1[4096], token2[4096], extra_text[4096];
	char*	tokens[2];

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);
	
	AddBangCommandEx("!LiteScriptReport", BangReport);

	tokens[0] = token1;
	tokens[1] = token2;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	while (LCReadNextConfig(step, "*LiteScript", temp, 256)) 
	{ 
		int count;

		token1[0] = token2[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 2, extra_text);

		if (count == 2)
		{
			FILE* script = fopen(token2, "r");
			if (!script) continue;

			while (fgets(temp, 256, script))
			{
				if (feof(script)) break;

				char* line = _strdup(temp);
				char* p = strtok(temp, TERMINATORS);
				if (!p) continue;

				if (!_strnicmp(p, "Create", 6))
				{
					p = strtok(NULL, TERMINATORS);
					if (!p) continue;

					if (!_strnicmp(p, "Bang", 4))
					{
						p = strtok(NULL, TERMINATORS);
						if (!p) continue;

						NewBang* nb = new NewBang(p);
						
						while (fgets(temp, 256, script))
						{
							if (feof(script)) break;
							char buffer[256] = "";

							p=temp;
							while (*p == ' ' || *p == '\t') *p++;
							strcpy(buffer, p);

							p = strtok(temp, TERMINATORS);
							if (!p) continue;

							if (!_strnicmp(p, "End", 3))
							{
								p = strtok(NULL, TERMINATORS);
								if (!p) continue;

								if (!_strnicmp(p, "Bang", 4)) break;
							}

							nb->AddCommand(buffer);
						}

						if (!head) head = nb;
						else
						{
							nb->next = head->next;
							head->next = nb;
						}
					}
				}
				else
				{
					// VarName Value
					count = LCTokenize(line, tokens, 2, extra_text);
					AddVariable(token1, token2);
				}
			}

			fclose(script);
		}
	}
	LCClose(step);
}

void BangHandler(HWND caller, LPCTSTR name, LPCTSTR args)
{
	NewBang* nb = FindBangByName(name);
	if (nb) nb->Execute();
}

void BangReport(HWND caller, LPCTSTR name, LPCTSTR args)
{
	HWND hwnd;
	POINT p;
	char classname[256] = "";
	char caption[256] = "";
	char temp[550] = "";

	GetCursorPos(&p);
	hwnd = WindowFromPoint(p);
	if (hwnd)
	{
		GetClassName(hwnd, classname, 256);
		GetWindowText(hwnd, caption, 256);

		sprintf(temp, "Class = %s\nCaption = %s", classname, caption);
		MessageBox(NULL, temp, szAppName, MB_SYSTEMMODAL | MB_ICONINFORMATION);
	}
}

NewBang* FindBangByName(LPCTSTR name)
{
	NewBang* nb ;

	for (nb=head; nb; nb=nb->next)
	{
		if (!_stricmp(name, nb->name)) return nb;
	}

	return NULL;
}

NewBang::NewBang(char* p)
{
	next=NULL;
	strcpy(name, p);
	AddBangCommandEx(name, (void*)BangHandler);
}

void NewBang::Execute()
{
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], extra_text[4096];
	char*	tokens[6];
	int count;

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;

	if (cmds)
	{
		int REPEAT=1;
		int LOOP=0;
		BOOL EXECUTEIF=FALSE;
		BOOL WAITFORELSE=FALSE;
		BOOL WAITFORENDIF=FALSE;

		for (Command* c=cmds; c;)
		{
			char buffer[256] = "";
			strcpy(buffer, c->cmd);
			
			token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = extra_text[0] = '\0';

			char* p = strtok(buffer, TERMINATORS);
			if (!p) continue;

			if (WAITFORELSE)
			{
				if (!_strnicmp(p, "else", 4)) WAITFORELSE=FALSE;
				else if (!_strnicmp(p, "end", 3))
				{
					WAITFORELSE=FALSE;
					EXECUTEIF=FALSE;
					WAITFORENDIF=FALSE;
				}
				c=c->next;
				continue;
			}

			if (WAITFORENDIF)
			{
				if (!_strnicmp(p, "end", 3)) 
				{
					WAITFORELSE=FALSE;
					WAITFORENDIF=FALSE;
					EXECUTEIF=FALSE;
				}
				c=c->next;
				continue;
			}

			if (!_strnicmp(p, "Capture", 7))
			{
				count = LCTokenize (c->cmd, tokens, 3, extra_text);

				if (count == 2)
				{
					hwnd = FindWindow(ExpandVariable(token2), NULL);
				}
				else if (count == 3)
				{
					hwnd = FindWindow(ExpandVariable(token2), ExpandVariable(token3));
				}
			}
			else if (!_strnicmp(p, "Show", 4))
			{
				ShowWindow(hwnd, SW_SHOW);
			}
			else if (!_strnicmp(p, "Hide", 4))
			{
				ShowWindow(hwnd, SW_HIDE);
			}
			else if (!_strnicmp(p, "OnTop", 5))
			{
				SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
			}
			else if (!_strnicmp(p, "NotOnTop", 8))
			{
				SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
			}
			else if (!_strnicmp(p, "Sticky", 6))
			{
				SetWindowLong(hwnd, GWL_USERDATA, magicDWord);
			}
			else if (!_strnicmp(p, "NotSticky", 9))
			{
				SetWindowLong(hwnd, GWL_USERDATA, 0);
			}
			else if (!_strnicmp(p, "Repeat", 6))
			{
				count = LCTokenize(c->cmd, tokens, 2, extra_text);

				if (count == 2)
				{
					REPEAT=atoi(ExpandVariable(token2));
					c=c->next;
					continue;
				}
			}
			else if (!_strnicmp(p, "SetDelay", 8))
			{
				count = LCTokenize(c->cmd, tokens, 2, extra_text);

				if (count == 2)
				{
					DELAY=atoi(ExpandVariable(token2));
				}
			}
			else if (!_strnicmp(p, "Move", 4))
			{
				int x,y;

				// Move A X Y
				count = LCTokenize(c->cmd, tokens, 4, extra_text);
				
				if (count == 4)
				{
					x = atoi(ExpandVariable(token3));
					y = atoi(ExpandVariable(token4));

					if (!_stricmp(ExpandVariable(token2), "A")) // Absolute
					{
						SetWindowPos(hwnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
					}
					else if (!_stricmp(ExpandVariable(token2), "R")) // Relative
					{
						RECT r;
						GetWindowRect(hwnd, &r);
						SetWindowPos(hwnd, NULL, r.left+x, r.top+y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
					}

					InvalidateRect(hwnd, NULL, TRUE);
				}
			}
			else if (!_strnicmp(p, "Size", 4))
			{
				int w,h;

				// Size A X Y
				count = LCTokenize(c->cmd, tokens, 4, extra_text);

				if (count == 4)
				{
					w = atoi(ExpandVariable(token3));
					h = atoi(ExpandVariable(token4));

					if (!_stricmp(ExpandVariable(token2), "A")) // Absolute
					{
						SetWindowPos(hwnd, NULL, 0, 0, w, h, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
					}
					else if (!_stricmp(ExpandVariable(token2), "RR") || // Relative Right
							 !_stricmp(ExpandVariable(token2), "RB"))   // Relative Bottom
					{
						RECT r;
						GetWindowRect(hwnd, &r);
						SetWindowPos(hwnd, NULL, r.left-w, r.top-h, r.right-r.left+w, r.bottom-r.top+h, SWP_NOACTIVATE | SWP_NOZORDER);
					}
					else if (!_stricmp(ExpandVariable(token2), "RL") || // Relative Left
							 !_stricmp(ExpandVariable(token2), "RT"))   // Relative Top
					{
						RECT r;
						GetWindowRect(hwnd, &r);
						SetWindowPos(hwnd, NULL, 0, 0, r.right-r.left+w, r.bottom-r.top+h, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
					}
				}
			}
			else if (!_strnicmp(p, "Exec", 4))
			{
				p = c->cmd + 5;
				if (!p) continue;
				LSExecute(NULL, ExpandVariable(p), SW_SHOWNORMAL);
			}
			else if (!_strnicmp(p, "if", 2))
			{
				// if Visible, Hidden, OnTop, NotOnTop
				//   Exec !Hide
				// else
				//   Exec !Show
				// end if

				count = LCTokenize(c->cmd, tokens, 2, extra_text);
				
				if (count == 2)
				{
					if (!_stricmp(ExpandVariable(token2), "Visible"))
					{
						if (IsWindowVisible(hwnd)) EXECUTEIF=TRUE;
						else WAITFORELSE=TRUE;
					}
					else if (!_stricmp(ExpandVariable(token2), "Hidden"))
					{
						if (!IsWindowVisible(hwnd)) EXECUTEIF=TRUE;
						else WAITFORELSE=TRUE;
					}
					else if (!_stricmp(ExpandVariable(token2), "OnTop"))
					{
						
					}
					else if (!_stricmp(ExpandVariable(token2), "NotOnTop"))
					{
					}
				}
			}
			else if (!_strnicmp(p, "else", 4))
			{
				if (EXECUTEIF) WAITFORENDIF=TRUE;
			}
			else if (!_strnicmp(p, "Prompt", 6))
			{
				// Prompt "Caption" "Text" "Question" "!Yes" "!No"
				// Prompt "Caption" "Text" "Information" "!OK"
				count = LCTokenize(c->cmd, tokens, 6, extra_text);

				if (count == 5) // ok box
				{
					DWORD style = MB_SYSTEMMODAL | MB_OK;

					if (!_strnicmp(ExpandVariable(token4), "Question", 8)) style |= MB_ICONQUESTION;
					else if (!_strnicmp(ExpandVariable(token4), "Information", 11)) style |= MB_ICONINFORMATION;
					else if (!_strnicmp(ExpandVariable(token4), "Exclamation", 11)) style |= MB_ICONEXCLAMATION;
					else if (!_strnicmp(ExpandVariable(token4), "Warning", 7)) style |= MB_ICONWARNING;
					else if (!_strnicmp(ExpandVariable(token4), "Asterisk",8)) style |= MB_ICONASTERISK;
					else if (!_strnicmp(ExpandVariable(token4), "Error", 5)) style |= MB_ICONSTOP;

					if (MessageBox(hwnd, ExpandVariable(token3), ExpandVariable(token2), style) == IDOK)
						LSExecute(NULL, ExpandVariable(token5), SW_SHOWNORMAL);
				}
				else if (count == 6) // yes/no box
				{
					DWORD style = MB_SYSTEMMODAL | MB_YESNO;
					
					if (!_strnicmp(ExpandVariable(token4), "Question", 8)) style |= MB_ICONQUESTION;
					else if (!_strnicmp(ExpandVariable(token4), "Information", 11)) style |= MB_ICONINFORMATION;
					else if (!_strnicmp(ExpandVariable(token4), "Exclamation", 11)) style |= MB_ICONEXCLAMATION;
					else if (!_strnicmp(ExpandVariable(token4), "Warning", 7)) style |= MB_ICONWARNING;
					else if (!_strnicmp(ExpandVariable(token4), "Asterisk",8)) style |= MB_ICONASTERISK;
					else if (!_strnicmp(ExpandVariable(token4), "Error", 5)) style |= MB_ICONSTOP;

					if (MessageBox(hwnd, ExpandVariable(token3), ExpandVariable(token2), style) == IDYES)
						LSExecute(NULL, ExpandVariable(token5), SW_SHOWNORMAL);
					else
						LSExecute(NULL, ExpandVariable(token6), SW_SHOWNORMAL);
				}
			}
			else if (!_strnicmp(p, "End", 3))
			{
				p = strtok(NULL, TERMINATORS);
				if (!p) continue;

				if (!_strnicmp(p, "Capture", 7)) hwnd=NULL;
				else if (!_strnicmp(p, "if", 2))
				{
					WAITFORENDIF=FALSE;
					EXECUTEIF=FALSE;
				}
			}
			else
			{
				// VarName Value
				count = LCTokenize(c->cmd, tokens, 2, extra_text);
				AddVariable(token1, token2);
			}

			Sleep(DELAY);
		
			if (++LOOP >= REPEAT) 
			{
				c=c->next;
				LOOP=0;
				REPEAT=1;
			}
		}
	}
}

void NewBang::AddCommand(char* cmd)
{
	Command* c = new Command;
	strcpy(c->cmd, cmd);
	c->next=NULL;

	if (!cmds) cmds = c;
	else
	{
		for (Command* p = cmds; p->next; p=p->next);
		p->next = c;
	}
}

void AddVariable(char* var, char* val)
{
	Variable* v = new Variable;
	strcpy(v->var, var);
	strcpy(v->val, val);
	v->next=NULL;

	for (Variable* p = vars; p; p=p->next)
	{
		if (!strcmp(p->var, var))
		{
			memset(&p->val, 0, sizeof(p->val));
			strcpy(p->val, val);
			return;
		}
	}

	if (vars) v->next = vars;
	vars = v;
}

char* GetVariable(char* var)
{
	for (Variable* p = vars; p; p=p->next)
	{
		if (!strcmp(p->var, var)) return p->val;
	}

	return NULL;
}

char* ExpandVariable(char* cmd)
{
	char* buffer = _strdup(cmd);
	char retcmd[256] = "";
	int x=0;
	
	for (char* c=buffer; *c; c++)
	{
		if (*c == '%')
		{
			char* end = strstr(c+1, "%");
			char temp[256] = "";
			if (end) 
			{
				strncpy(temp, c+1, end-c-1);
				char* var = GetVariable(temp);
				if (var) 
				{
					strcat(retcmd, var);
					x+=strlen(var);
					c+=strlen(temp)+1;
				}
			}
		}
		else retcmd[x++] = *c;
	}

	return _strdup(retcmd);
}