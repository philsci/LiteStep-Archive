Switch.dll v1
idea by Shadowlin
code by limpid
http://www.v-active.com/litestep/
----------------------

***BACK UP YOUR CURRENT STEP.RC AND MODULES.INI***

Switch.dll is a loadmodule that will allow you to switch themes (and bg images) quickly and easily in
litestep using a !bang command.

be sure to load the module in your step.rc:
LoadModule c:\path\to\switch.dll

settings for the themes are stored in the switch configuration file - switch.rc, which
should be put in your litestep directory (wherever litestep.exe is). the theme definitions
work like this:

in switch.rc:
*theme <name> <steprc> <modulesini> [wallpaper]
heres an example:
*theme "gnome" "c:\litestep\themes\gnome\step.rc" "c:\litestep\themes\gnome\modules.ini" "c:\litestep\themes\gnome\imamges\bg.bmp"
(note that the last entry, the wallpaper image, is optional)

this will copy c:\litestep\themes\gnome\step.rc to your litestep directory, overwriting your current steprc(!)
make sure you have it all set up right and back up your step.rc and modules.ini just to be safe.

the switch.rc file can hold up to 32 theme definitions.

to switch to a theme, from litestep, call !Switch "themename" where themename matches the name of the theme
defined in the switch.rc file that would like to switch to.

so to switch to the example theme entry above, you would use !Switch "gnome"

im gonna add support for theme.rc and also an option to chose if you want your bg tiled or centered or stretched.