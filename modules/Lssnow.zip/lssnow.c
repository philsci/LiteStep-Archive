#include <windows.h>
#include <stdio.h>
#include <wininet.h>
#include <commctrl.h>
#include <time.h>
#include "lsapi.h"
#include "LSSnow.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LSSnow"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Structs
struct
{
	POINT p;
	int weight;
	int wind;
} Flake[20];

// Function Prototypes
void DrawFlake(HDC, int);
void LoadSetup();

// Litestep Stuff
HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
HINSTANCE Instance;

// Handles
HWND desktop;

// Fonts

// COLORREFS

// Rects

// Character Strings

// Dwords
DWORD MB = MB_OK | MB_SETFOREGROUND;

// Ints
int ScreenX=1024, ScreenY=768;

// BOOLs

////////////////////////////////////////////////////////////////////////


// It has begun
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	parent = ParentWnd; // Save parent window
	Instance = dllInst;

	{    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = 0;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }
	
	LoadSetup();

	hMainWnd = CreateWindowEx(
        WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD | WS_CLIPSIBLINGS,                                   // window style
        0, 0,									// position 
        ScreenX, ScreenY,                        // width & height of window
        desktop,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	SetTimer(hMainWnd, 0, 25, NULL);

	return 0;
}

void quitWharfModule(HINSTANCE dllInst)
{
	quitModule(dllInst);
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitModule(HINSTANCE dllInst)
{
	KillTimer(hMainWnd, 0);
	DestroyWindow(hMainWnd);                // delete our window
	UnregisterClass(szAppName, dllInst);    // unregister window class
}

void LoadSetup()
{
	int x;

	srand( (unsigned)time( NULL ) );

	for (x=0; x<20; x++)
	{
		Flake[x].p.x = rand() % ScreenX;
		Flake[x].p.y = -2;
		Flake[x].weight = rand() % 3 + 2;
	}

	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
	{
		desktop = GetDesktopWindow();
	}

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
		
        case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(hdc);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, ScreenX, ScreenY);
			int x;

			SelectObject(buf, bufbmp);
			PaintDesktop(buf);

			SelectObject(buf, GetStockObject(WHITE_PEN));

			for (x=0; x<20; x++)
			{
				DrawFlake(buf, x);
			}

			BitBlt(hdc, 0, 0, ScreenX, ScreenY, buf, 0, 0, SRCCOPY);

			EndPaint(hwnd, &ps);
			DeleteDC(buf);
			DeleteObject(bufbmp);
		}
		return 0;

		case WM_TIMER:
		{
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return 0;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			pos->flags |= SWP_NOZORDER;
		}
		return 0;

    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

void DrawFlake(HDC hdc, int x)
{
	HWND hwnd;
	
	MoveToEx(hdc, Flake[x].p.x, Flake[x].p.y, NULL);
	LineTo(hdc, Flake[x].p.x+6, Flake[x].p.y);
	MoveToEx(hdc, Flake[x].p.x+3, Flake[x].p.y+3, NULL);
	LineTo(hdc, Flake[x].p.x+3, Flake[x].p.y-3);

	hwnd = WindowFromPoint(Flake[x].p);

	if (hwnd)
	{
		if (hwnd != desktop && hwnd != hMainWnd)
		{
			Flake[x].p.x = rand() % 1024;
			Flake[x].p.y = -2;
			Flake[x].weight = rand() % 3 + 2;
			return;
		}
	}

	Flake[x].wind = rand() % 2;
	(rand() % 2)? Flake[x].p.x += Flake[x].wind : (Flake[x].p.x -= Flake[x].wind);
	Flake[x].p.y += Flake[x].weight;
}


