_______________________________________________________________
chronos 1.4                                         03 nov 1999

                            abstract

chronos is  a Litestep  loadable module  which can  display the
current  date and  time anywhere  on the  desktop.  it supports
background bitmaps, variable font styles, and user-defined date
and time formats.

                         release notes

chronos 1.2 uses features recently added to lsapi.dll. you must
have a build of lsapi.dll from august 23 or later.  the chronos
page on my site [maduin.dasoft.org/chronos] has a zip file with
a recent lsapi.dll. if you do not have the august 23 (or later)
devbuild installed you can just replace your lsapi.dll with the
one supplied in the zip.


                          installation

copy chronos.dll to your Litestep directory and add a line like
the following to your step.rc file:

  LoadModule C:\Litestep\chronos.dll

or to load chronos as a wharf module, use:

  *Wharf "Chronos" . @C:\Litestep\chronos.dll

after  recycling Litestep,  chronos should  appear as a desktop
or wharf module with the default settings. however, most likely
you'll want to customize chronos to your liking, which leads us
to...


                         configuration

you can add commands to your  step.rc file to customize chronos
to look and function  any way you like.  none of these commands
need to be present,  in which case appropriate defaults will be
used.  a chronos.rc file is  also provided that  can be used as
template for customizing chronos.

  ChronosAlignH (center | left | right)
   
   specifies the horizontal text alignment. the default value
   is "center".
   
  ChronosAlignV (center | top | bottom)
   
   specifies the vertical text alignment. the default value is
   also "center".
   
  ChronosAlwaysOnTop
   
   if present, chronos will appear above all normal windows;
   else chronos remains below all normal windows. this command
   has no effect when loaded as a wharf module.
   
  ChronosBitmap <bitmap-file>
  
   specifies a bitmap file to use to paint the background. if
   this command is not present a default background based on
   system colors is used.
  
  ChronosEdgeScaling <left> <top> <right> <bottom>
  
   sets the edge scaling widths for the bitmap (ChronosBitmap).
   edge scaling lets you prevent some pixels at the edge of the
   bitmap from being scaled. this is the same effect as used in
   the Enlightenment window manager and it also used in one of
   my other modules: systray.dll. the default is 0 0 0 0.
  
  ChronosFloat
  
   if present this allows chronos to float above other windows
   without being always on top. you can also use !ChronosShow
   to bring chronos to the top. if docked to the wharf or if
   ChronosAlwaysOnTop is enabled this command has no effect.
  
  ChronosFont <font-name>
  
   sets the name of the font used to display the time and date
   text. the default is "Arial".
   
  ChronosFontBold
  
   if present, the date and time font is bold; else the font is
   displayed with normal weight.
  
  ChronosFontColor <color>
  
   sets the main color of date and time font. if font shadow is
   enabled, the default is white; else the default is black.
  
  ChronosFontItalic
  
   if present, the date and time font is italic; else the font
   is displayed normally.
  
  ChronosFontShadow
  
   if present, this command enables font shadow. a second image
   of the date and time is painted behind and offset from the
   main image in the shadow color; else only a single image of
   the text is displayed.
  
  ChronosFontShadowColor <color>
  
   sets the color of the font shadow if shadow is enabled. the
   default color is black.
  
  ChronosFontShadowDepth <X> <Y>
  
   sets the depth of the shadow (the distance, in pixels, that
   the shadow image is offset from the main image) for both the
   horizontal (X) and vertical (Y) directions. the default is
   2 2.
  
  ChronosFontSize <N>
  
   sets the size (in points) of the font used to display the
   date and time. the default value is 8.
  
  ChronosFormat <format-text>
  
   this command determines how the date and time are formatted
   on screen. the format text can contain normal characters and
   escape sequences. the escape sequences are formed by a
   percent sign (%) followed by a single character. this method
   is similar to that used by strftime, though the set of
   escape sequences is not exactly the same. the following are
   support by chronos:
   
     %%  - inserts a single percent sign (%)
     %;  - inserts a semicolon (;)
     %a  - abbreviated weekday name
     %A  - full weekday name
     %b  - abbreviated month name
     %B  - full month name
     %c  - locale-specific date and time
     %C  - centibeats, hundreths of a beat [%@] (00-99)
     %d  - day of month (01-31)
     %H  - hour, 24-hour format (00-23)
     %I  - hour, 12-hour format (01-12)
     %j  - day of year (001-366)
     %m  - month (01-12)
     %M  - minute (00-59)
     %n  - inserts a new line
     %p  - locale-specific AM/PM indicator
     %S  - second (00-59)
     %TZ - sets the timezone used for subsequent commands
     %Ud - uptime: days
     %UH - uptime: hours (00-23)
     %UM - uptime: minutes (00-59)
     %US - uptime: seconds (00-59)
     %w  - day of week (0-6), 0 = Sun, 6 = Sat
     %x  - locale-specific date
     %X  - locale-specific time
     %y  - 2-digit year (00-99)
     %Y  - full year
     %@  - Swatch internet time (000-999)
   
   the %TZ command lets you set the timezone for commands that
   follow it. this specifier is unique in that is takes an
   offset specification in parenthesis. for example:
   
     %TZ(+4)    - 4 hours after local time
     %TZ(-2:30) - 2.5 hours before local time
     %TZ(GMT)   - GMT time
     %TZ(GMT-8) - 8 hours before GMT
     %TZ()      - local time (used to reset timezone)
   
   you can also place a hash mark (#) between the percent sign
   and the character to modify how the values are formatted
   (eg, "%#I"). for numeric values that have a leading zero,
   the hash mark removes it. also the following are special
   uses of the hash mark modifier:
   
     %#c - locale-specific date/time with a long date
     %#x - locale-specific date in long format
   
   here are some example format strings:
   
     format: "%a, %d %b %y %H:%M:%S"
     displays: "Fri, 01 Jan 99 16:56:24"
     
     format: "%B %#d, %Y %I: %I:%M %p"
     displays: "January 1, 1999 04:56 PM"
     
     format: "%#I o'clock and %#M minutes %p"
     displays: "4 o'clock and 56 minutes PM"
     
     format: "Local: %H:%M, GMT: %TZ(GMT)%H:%M"
     displays: "Local: 16:56, GMT: 21:56"
   
   you can also specify multiple formats by seperating them
   with semicolons (;). then you can switch formats by right-
   clicking chronos or invoking the !ChronosNext command. for
   example, "%x;%X" lets you switch between displaying the date
   and the time. you can have up to 8 different formats. the
   default value for ChronosFormat is "%#I:%M %p".
  
  ChronosHidden
  
   if present, chronos starts hidden. use the !ChronosShow or
   !ChronosToggle commands to make it visible.
  
  ChronosHideOnUnfocus
  
   if present, chronos will hide when it loses focus. you can
   then use !ChronosShow or !ChronosToggle to reshow chronos.
  
  ChronosInterval <N>
  
   sets the update interval in milliseconds. the default value
   is 1000 (1 second). a larger value reduces the rate at which
   chronos updates its display; a smaller value increases it.
   in almost all cases the default is fine.
  
  ChronosNoAutoSave
  
   normally if you drag chronos to a new location that location
   is saved and chronos returns there on restart/recycle. if
   this command is present, that behavior is disabled and
   chronos will always appear at the location specified by the
   ChronosX and ChronosY commands.
  
  ChronosNoDrag
  
   normally you can drag chronos to a new location on the
   screen. if this command is present dragging is disabled.
  
  ChronosOnLeftClick
  ChronosOnLeftDoubleClick
  ChronosOnMiddleClick
  ChronosOnMiddleDoubleClick
  ChronosOnRightClick
  ChronosOnRightDoubleClick
  
   these commands let you assign any application or bang
   command to a mouse button for chronos. you can also use the
   standard LSExecute style ([!foo][!bar]) for multiple actions
   for one button. if any of these commands is not present, the
   default for the mouse button is used instead. for a left
   double click the default is !ChronosControlPanel and for a
   right click the default is !ChronosNext. the rest do nothing
   by default. using both a click action and a double click
   action for a mouse button will not work.
  
  ChronosPadding <left> <top> <right> <bottom>
  
   sets the amount of padding between the text and the edge of
   the window. text which extends beyond this padding area is
   clipped. the default is 0 0 0 0.
  
  ChronosToolTip <format>
  
   if present this command adds a tooltip for chronos and sets
   the format of the tooltip text. the format parameter can have
   any of the format specifiers for ChronosFormat except for the
   multiformat (;) or new line (%n).
  
  ChronosTransparent
  
   this command enables transparency support. if a bitmap is
   also specified (ChronosBitmap) the areas of that bitmap that
   are pink (RGB 255 0 255) will be transparent (will let the
   desktop wallpaper show through). if no bitmap is given, the
   entire background will be transparent. currently, this will
   not work if loaded as a wharf module.
  
  ChronosX <N>
  
   sets the horizontal position in pixels that chronos starts
   at, unless overridden by autosave. the default is 0. this
   command has no effect if loaded as a wharf module.
  
  ChronosY <N>
  
   sets the vertical position in pixels that chronos starts at,
   unless overriden by autosave. the default is 0. this command
   has no effect if loaded as a wharf module.
  
  ChronosWidth <N>
  
   sets the width of the chronos window in pixels. the default
   value is 72. this command has no effect if loaded as a wharf
   module.
  
  ChronosHeight <N>
  
   sets the height of the chronos window in pixels. the default
   value is 24. this command has no effect is loaded as a wharf
   module.


                         bang commands

chronos also defines  the following bang  commands which can be
called in the usual manner:

  !ChronosControlPanel
  
   brings up the Windows time and date control panel applet.
  
  !ChronosHide
  
   hides chronos
  
  !ChronosMove [<X> <Y> [<W> <H>]]
  
   moves chronos to the position specified by X and Y and sets
   the size to WxH if the parameters are present. if none are
   given chronos moves to the current mouse position.
  
  !ChronosMoveHome
  
   moves chronos to its home position, that is, the position
   specified by ChronosX and ChronosY.
  
  !ChronosNext
  
   switches to the next format if multiple formats have been
   specified by ChronosFormat.
  
  !ChronosShow
  
   shows chronos
  
  !ChronosToggle
  
   toggles the show/hide state of chronos


                            feedback

if you have a bug report, feature request, or any kind of feed-
back, feel free to email it to me at maduin@dasoft.org.  I will
read all the mail I receive,  but I don't guarentee  I'll reply
to them all.


                           disclaimer

Copyright (C) 1999, Kevin Schaffer

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY,  FITNESS FOR A  PARTICULAR PURPOSE AND NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL  THE  AUTHORS OR  COPYRIGHT
HOLDERS BE  LIABLE FOR ANY CLAIM,  DAMAGES OR  OTHER LIABILITY,
WHETHER IN AN  ACTION OF CONTRACT,  TORT OR OTHERWISE,  ARISING
FROM,  OUT OF OR IN CONNECTION WITH THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

_______________________________________________________________
maduin                                        maduin@dasoft.org
