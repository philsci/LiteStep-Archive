# ShellSwap32 Version 1.0
# By: MrJukes
# Release Date: Saturday June 13 1998

This is just something quick that I threw out there.  If you have any
suggestions, I'll work on them.  Just e-mail me at mrjukes@purdue.edu

For you to do:
1) Add this to your win.ini:
	[Litestep]
	Location=c:\litestep\litestep.exe
2) Add this to your step.rc
	*Wharf "ShellSwap32" default.bmp "c:\litestep\shellswap32.exe"

Obviously change the stuff above to your own litestep directory
and wherever you unzip shellswap32.exe to.

Have fun.