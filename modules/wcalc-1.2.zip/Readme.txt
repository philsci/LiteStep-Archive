-*= WCalc v1.2 =*-

Introduction

Well, this is WCalc, a module for the absolutely fabu, tremendously spectacular LiteStep.
Sorry about the size of this thing.  I wrote it in Delphi3, so Delphi had to include
all on it's libs in the dll.  It work great, though.

What does it do?

It's a calculator, you silly dolt.  It's calculates things.

How does it work?

All the setup info is contained in the Modules.ini and setup through a popup menu
on the calc itself.  Just right click and config away.  Things you can change:

Answer Font (including Color)
Answer Background Color
Answer Background 3D (or not)
Button Font (including Color)
Button Color
Button 3D (or not)
Module Background Color
Module Background 3d (or not)
You can also reset to the defaults.

The buttons are small and kind of annoying to click, so if you click on the Wharf once
you can then use the keypad for your calculations.

Clear = <esc>, <space>, <click in answer area>
Del one character = <backspace>
Decimal Point = <.>, <,> <=Comma click NEW
0..9 = <0..9>
+,-,*,/ = same

To put it on the Wharf, just stick this in the Wharf Section:

*Wharf Test .none @c:\litestep\WCalc.dll

Unfortunately you have to have a modules.ini file in the c:\litestep dir for the saving 
and loading to work.  A later version will let you change or autodetect your litestep dir.
Until then, just make a c:\litestep and copy your modules.ini file there.

Note: if Wcalc cannot find your modules.ini file it will display an error message.  You 
can still use the calc normally, but your configurations will not be saved.

This is the second release, so it may, and probably still has a bunch of bugs.  So, if
you find any, PLEASE Email me.  In fact, if you have anything to say about WCalc, or 
you want the source, or you want my home address so you can send me letter bombs, or 
whatever, mail me at:

--Bloater Paste--
dcordes@gte.net

Released v1.2 09/10/98

Comming Soon
============
-Autodetect litestep dir so it will work no matter where litestep is installed.
-Autodetect Math Setup so if you are in a country where ',' is used instead of '.' as
the decimal seperator, you won't get errors and it will work correctly.
-Skin Support
-Cut/Copy/Paste Support.
-A Memory Function

Version History
===============
V1.2 09/10/1998 
Bugs Fixed
-Fixed 'Access Violation' on some systems.
-Fixed oversized buttons on some systems.
-Other Small things...

Functionality Added
-Buttons/Answer/Module 3d/flat
-Module Color
-Update 'Default setting'
-Recognizes Comma as a decimal for foreign keyboards

V1.0 09/06/1998 Initial release

Thanks
======
Everyone who helped me test and those of you who sent in great ideas.  
Especially Ayrton Mercado and Jeremy Brown...