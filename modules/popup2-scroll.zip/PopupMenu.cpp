/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "PopupMenu.h"
#include "MenuItem.h"
#include "Painter.h"
#include "Re5ources.h"

#include "../lsapi/lsapi.h"

#include <algorithm>

#define RELEASE_NO "R8"

#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lp)   ((int)(short)LOWORD(lp))
#endif

#ifndef GET_Y_LPARAM
#define GET_Y_LPARAM(lp)   ((int)(short)HIWORD(lp))
#endif

#define TRACK_MOUSE_TIMEOUT 4437
#define SNAPP_DIST 10

char popupName[] = "Re5ources_PopupMenu";

vector<PopupMenu*> g_PopupMenues;

BOOL PopupMenu::m_bPopupMenuBevel;

DWORD PopupMenu::m_nDarkColor = 0x00000000;
DWORD PopupMenu::m_nLightColor = 0x00FFFFFF;

int PopupMenu::m_nInstances=0;

int PopupMenu::m_nMaxWidth = 500;
int PopupMenu::m_nMinWidth = 100;
int PopupMenu::m_nScrollSpeed = SCROLL_SPEED;

LRESULT CALLBACK PopupMenuWindowProc(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam);

PopupMenu::PopupMenu(HINSTANCE hInstance)
{
	m_bValidated = FALSE;
	m_pParent = NULL;
	m_hInstance = hInstance;
	m_hWnd = NULL;
	
	if(m_nInstances == 0)		
	{	
		WNDCLASS wc;
		ZeroMemory(&wc, sizeof(wc));
		wc.lpfnWndProc = PopupMenuWindowProc;
		wc.hInstance = m_hInstance;			
		wc.lpszClassName = popupName;
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	
		if(!RegisterClass(&wc))
			OutputDebugString("Error registering popup window class");	
	}

	g_PopupMenues.push_back(this);

	m_hWnd =  CreateWindowEx(WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
							popupName, popupName, WS_POPUP,	0, 0, 0, 0,	
							NULL, NULL,	m_hInstance, NULL);		

	SetWindowLong(m_hWnd, GWL_USERDATA, 0x49474541);
	m_nInstances++;
	m_bMouseOver = false;
	m_bPinned = false;
}

PopupMenu::~PopupMenu()
{
	// remove this object from the global window-object map
	for(int i=0; i<g_PopupMenues.size(); i++)
	{
		if(g_PopupMenues[i] == this)
		{
			g_PopupMenues.erase(g_PopupMenues.begin()+i);
			break;
		}
	}

	// delete the window
	if(m_hWnd) DestroyWindow(m_hWnd);
	m_hWnd = NULL;

	DeleteMenuItems();

	// decrease the count of popupmenu objects
	m_nInstances--;
	if(m_nInstances==0)
	{
		// this is the last instance of popupmenu so we can 
		// unregister the window class
		UnregisterClass(popupName, m_hInstance);
	}
}

void PopupMenu::Paint()
{
	PAINTSTRUCT p;
	RECT itemRect;
	RECT tempRect;
	MENUITERATOR i; 

	BeginPaint(m_hWnd, &p);

	for(i=m_MenuItems.begin(); i != m_MenuItems.end(); ++i)
	{
		(*i)->GetItemRect(&itemRect);

		// Only call paint if the item is within the update region
		if(IntersectRect(&tempRect, &p.rcPaint, &itemRect))
			(*i)->Paint(p.hdc);
	}

	if(m_bPopupMenuBevel)
		PaintBevel(p.hdc);

	EndPaint(m_hWnd, &p);
}

void PopupMenu::Key(int nKey)
{
	MENUITERATOR item;
	MENUITERATOR lastActive;
	MenuItem* pActive = NULL;
	int nSize = m_MenuItems.size();	

	switch(nKey)
	{
	case VK_LEFT:
		if(m_pParent == NULL) break;
		// else fall through..
	case VK_ESCAPE:
		Hide(HIDE_CHILDREN); // hide this popup
		if(m_pParent) // if i have a parent set focus on him
			SetFocus(m_pParent->GetWindow());
		break;
	case VK_UP:
		{
			BOOL bFound;
			BOOL bExit=FALSE;

			// if the folder does not contain any elements break.
			if(nSize <= 0)
				break;

			bFound = FindActiveAndDeactivate(&item);

			if(bFound)
				lastActive = item;
			else
				item = m_MenuItems.end();
				

			--item;

			for(;item!=m_MenuItems.begin() && item!=m_MenuItems.end()&& !bExit;--item)
				if((*item)->Active(TRUE))
					bExit = TRUE;
			
			item=m_MenuItems.end();
			--item;
			for(;item!=m_MenuItems.begin() && item!=lastActive && !bExit;--item)
				if((*item)->Active(TRUE))
					bExit = TRUE;
		}
		break;
	case VK_DOWN:
		{
			BOOL bFound;
			BOOL bExit=FALSE;

			// if the folder does not contain any elements break.
			if(nSize <= 0)
				break;

			bFound = FindActiveAndDeactivate(&item);

			if(bFound)
				lastActive = item;				
			else
				item = m_MenuItems.begin();

			item++;

			for(;item!=m_MenuItems.end()&&!bExit;++item)
				if((*item)->Active(TRUE))
					bExit=TRUE;
			
			for(item=m_MenuItems.begin();
				item!=lastActive&&!bExit&&item!=m_MenuItems.end();
				++item)
				if((*item)->Active(TRUE))
					bExit=TRUE;
		}
		break;
	case VK_RETURN:
		// Find the currently active menu item, and call
		// invoke on it
		if(FindActiveAndDeactivate(&item))
		{
			(*item)->Invoke();
			if(m_pParent) // if i have a parent set focus on him
				SetFocus(m_pParent->GetWindow());
		}
		break;
	default:
		{
			BOOL bConsumed = FALSE;
			for(item = m_MenuItems.begin(); item != m_MenuItems.end() && !bConsumed; item++)
				bConsumed = (*item)->Key(nKey);

			// if the keypress was not consumed by any menu item then
			// try to find one item that begins with the letter and highlight that
			if(!bConsumed)
			{
				for(item = m_MenuItems.begin(); item != m_MenuItems.end(); item++)
				{
					char* pszText = (*item)->GetSortString();
					if(pszText != NULL)
					{
						if(pszText[0] == nKey)
						{
							MENUITERATOR notUsed;
							FindActiveAndDeactivate(&notUsed);
							if((*item)->Active(TRUE))
								return;
						}
					}

				}
			}
		}
		break;
	}
}

void PopupMenu::Show(int x, int y)
{
	SetWindowPos(m_hWnd, HWND_TOPMOST, x, y, 0,0, 
		SWP_SHOWWINDOW|SWP_NOACTIVATE|SWP_NOSIZE);
}

void PopupMenu::Show()
{
	POINT p;
	GetCursorPos(&p);

	if(m_pParent != NULL)
	{
		RECT r;
		GetWindowRect(m_pParent->GetWindow(), &r);
		Show(r.right-5,p.y-5);
	}
	else
	{
		Show(p.x, p.y);
	}
}

HWND PopupMenu::GetWindow()
{
	return m_hWnd;
}

// Syl's Touch

void PopupMenu::Mouse(int nMsg, int x, int y)
{	
	MENUITERATOR item;

	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
		(*item)->Mouse(nMsg, x, y);

	if(nMsg == WM_MOUSEMOVE)
	{	
		int height;
		bool repaint = false;
		RECT r;
		GetWindowRect(m_hWnd, &r);

		RECT workArea;
		SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);

		height = GetSystemMetrics(SM_CYSCREEN) - 20;
		if ((r.top + y >= height) && (y >= height))
		{
			// the popup is larger than the screen and the cursor is at the bottom
			// so scroll the window up a bit
			r.top -= m_nScrollSpeed;
			repaint = true;
		}
		else if (r.top + y <= 0)
		{
			// the popup is larger than the screen and the cursor is at the top
			// so scroll the window down at bit
			r.top += m_nScrollSpeed;
			repaint = true;
		}
		else if(r.right >= GetSystemMetrics(SM_CXSCREEN))
			// to faar to the right
			MoveWindow(m_hWnd, r.left - SCROLL_SPEED, r.top, (r.right-r.left), (r.bottom-r.top),TRUE);

		if (repaint)
		{
			MoveWindow(m_hWnd, r.left, r.top, (r.right-r.left), (r.bottom-r.top),TRUE);
			Paint();
		}
		// Track mouse ..
		if(!m_bMouseOver)
		{
			m_bMouseOver = true;
			SetTimer(m_hWnd, TRACK_MOUSE_TIMEOUT, 100, PopupMenu::TrackMouseProc);
		}
	}
}

void PopupMenu::TrackMouseProc(HWND hWnd,UINT uMsg,UINT idEvent,DWORD dwTime)
{
	POINT pt;
	HWND hWndNew;

	GetCursorPos(&pt);
	hWndNew = WindowFromPoint(pt);

	if(::GetParent(hWndNew) != hWnd)
	{
		RECT rect;

		GetClientRect(hWnd,&rect);
		MapWindowPoints(hWnd,NULL,(LPPOINT)&rect,2);

		if (!PtInRect(&rect,pt) || (hWndNew != hWnd)) 
		{
			KillTimer(hWnd,idEvent);
			PostMessage(hWnd,WM_MOUSELEAVE,0,0);
		}
	}
}

void PopupMenu::MouseLeave()
{
	POINT p;
	HWND hWnd;
	MENUITERATOR notUsed;
	
	GetCursorPos(&p);
	hWnd = WindowFromPoint(p);
	if(!IsChildWindow(hWnd))
		FindActiveAndDeactivate(&notUsed);

	m_bMouseOver = false;
}

void PopupMenu::AddMenuItem(MenuItem* m)
{
	m_MenuItems.push_back(m);

	// notify the menu item that it has been attached
	m->Attached(this);
}

void PopupMenu::DeleteMenuItems()
{	
	MENUITERATOR item;

	// remove the popup menu from the set of global mennues
	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
		delete *item;
	m_MenuItems.clear();
}

void PopupMenu::Activate(int fActive, HWND hWnd)
{
	MENUITERATOR item;

	if(fActive == WA_INACTIVE) 
	{
//		BOOL bDoHide = TRUE;
		char pszWindowClassName[256];

		// another window entirely is obtainig focus
		if(GetCurrentThreadId() != GetWindowThreadProcessId(hWnd, NULL))
		{
			Hide(HIDE_CHILDREN);
			Hide(HIDE_PARENTS);
			return;
		}
		else if(GetClassName(hWnd, pszWindowClassName, sizeof(pszWindowClassName)))
		{
			if(strcmp(pszWindowClassName, popupName) != 0)
			{
				Hide(HIDE_CHILDREN);
				Hide(HIDE_PARENTS);
				return;
			}
		}

		// If a child window is receiving the focus then we do not care
		if(IsChildWindow(hWnd))
			return;

		Hide(HIDE_CHILDREN);
		
		for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
			(*item)->Active(FALSE);
	}
}

BOOL PopupMenu::IsChildWindow(HWND hWnd)
{
	for(int i=0; i<m_Children.size(); i++)
	{
		if(hWnd == m_Children[i]->m_hWnd)
			return TRUE;
		else
			if(m_Children[i]->IsChildWindow(hWnd))
				return TRUE;
	}

	return FALSE;
}

BOOL PopupMenu::IsActive()
{
//	BOOL bRet = FALSE;
	return GetActiveWindow() == m_hWnd;// || bRet;
}

void PopupMenu::PaintBevel(HDC hDC)
{
	HPEN hPen;
	HPEN hOldPen;
	RECT r;
	int w,h;
	
	GetWindowRect(m_hWnd, &r);
	w = r.right - r.left;
	h = r.bottom - r.top;

	hPen = CreatePen(PS_SOLID, 1, m_nLightColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);

	// First we draw the white frame on the left/top
	MoveToEx(hDC, 0, 0, NULL);
	LineTo(hDC, w, 0);
	MoveToEx(hDC, 0, 0, NULL);
	LineTo(hDC, 0, h-1);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);

	// Now the black frame on the bottom/right
	hPen = CreatePen(PS_SOLID, 1, m_nDarkColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);
	MoveToEx(hDC, w-1, 0, NULL);
	LineTo(hDC, w-1, h);
	MoveToEx(hDC, 0, h-1, NULL);
	LineTo(hDC, w-1, h-1);

	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
}

void PopupMenu::Time(int nTimer)
{
	MENUITERATOR item;
	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
		(*item)->Timer(nTimer);
}

void PopupMenu::Hide(int h)
{
	BOOL bDoHide = TRUE;
	MENUITERATOR item;
//	for(item=m_MenuItems.begin(); item!=m_MenuItems.end(); ++item)
		// ask all menuitems if they accept that
		// the menu shoud be closed
//		if((bDoHide = (*item)->Hide()) == FALSE)
//			break;
	
	//if(bDoHide)
	if(!IsPinned())
		ShowWindow(m_hWnd, SW_HIDE);

	for(item=m_MenuItems.begin(); item!=m_MenuItems.end(); ++item)
		(*item)->Active(FALSE);

	if(h == HIDE_CHILDREN) 
	{
		for(int i=0; i<m_Children.size(); i++)
			m_Children[i]->Hide(h);
	}
	else if(h == HIDE_PARENTS) 
		if(m_pParent) m_pParent->Hide(h);
}

LRESULT PopupMenu::NcHitTest(int x, int y)
{
	LRESULT r;
	MENUITERATOR item;

	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
		if((r = (*item)->NcHitTest(x, y)) != 0)
			return r;

	return 0;
}

void PopupMenu::SetParent(PopupMenu* pParent)
{
	m_pParent = pParent;
}

void PopupMenu::AddChild(PopupMenu* pChild)
{
	m_Children.push_back(pChild);
}

void PopupMenu::RemoveChild(PopupMenu* pChild)
{
	for(int i=0; i<m_Children.size(); i++)
	{
		if(m_Children[i] == pChild)
			m_Children.erase(m_Children.begin()+i);
	}
}

void PopupMenu::Moving()
{	
	MENUITERATOR item;
	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); item++)
		(*item)->Moving();
}

PopupMenu* PopupMenu::GetParent()
{
	return m_pParent;
}

BOOL PopupMenu::FindActiveAndDeactivate(MENUITERATOR* pItem)
{
	for(*pItem = m_MenuItems.begin(); *pItem != m_MenuItems.end(); ++(*pItem))
	{
		if((**pItem)->IsActive())
		{
			(**pItem)->Active(FALSE);
			return TRUE;
		}
	}
	// did not find any active item
	return FALSE;
}

LRESULT PopupMenu::Command(WPARAM wParam, LPARAM lParam)
{
	LRESULT l=0;
	MENUITERATOR item;
	for(item=m_MenuItems.begin(); item != m_MenuItems.end(); ++item)
	{
		l = (*item)->Command(wParam, lParam);
		if(l != 0)
			break;
	}
	return l;
}

void PopupMenu::Sort()
{
	// Sort the menu items
	sort(m_MenuItems.begin(), m_MenuItems.end(), MenuItem::Compare);
}

void PopupMenu::Invalidate()
{
	m_bValidated = FALSE;
}

void PopupMenu::Validate()
{
	int w=0,h=0;
	HRGN rgnWnd;
	HRGN rgnItem;
	MENUITERATOR m;
	HDC hDC;

	if(m_bValidated)
		return;

	hDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	
	for(m = m_MenuItems.begin(); m != m_MenuItems.end(); ++m)
	{
		SIZE size;
		char* pszText = (*m)->GetSortString();

		if(pszText != NULL)
		{
			// Set the desired width of this menu item
			SelectObject(hDC, (*m)->GetPainter()->GetFont());
			GetTextExtentPoint32(hDC, pszText, lstrlen(pszText), &size);
      if ((*m)->IsLeaf())
			  (*m)->SetWidth(size.cx + (*m)->GetIndent() + 10);
      else
			  (*m)->SetWidth(size.cx + (*m)->GetIndent() + 25);
		}

		// find the widest element
		w = max((*m)->GetWidth(), w);
	}

	DeleteDC(hDC);

	// make sure that w is not wider than max and not less than min
	w = min(w, m_nMaxWidth);
	w = max(w, m_nMinWidth);

	rgnWnd = CreateRectRgn(0,0,0,0);
	for(m = m_MenuItems.begin(); m != m_MenuItems.end(); ++m)
	{
		(*m)->SetWidth(w);
		(*m)->SetPosition(0, h); 

		// now find out what region that the item is going to cover
		rgnItem = CreateRectRgn(0,0,0,0);
		(*m)->GetRegion(rgnItem);
		OffsetRgn(rgnItem, 0, h);
		CombineRgn(rgnWnd, rgnWnd, rgnItem, RGN_OR);
		DeleteObject(rgnItem);

		h += (*m)->GetHeight();
	}

	SetWindowRgn(m_hWnd, rgnWnd, TRUE);
	SetWindowPos(m_hWnd, HWND_TOP, 0, 0, w, h, 
		SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOCOPYBITS|SWP_NOSENDCHANGING);

	m_bValidated = TRUE;
}

// Wind prof for the popup menues
LRESULT CALLBACK PopupMenuWindowProc(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	POINT point;
	PopupMenu* p = NULL;
	LRESULT ret = 0;

	// find the popup menu object that is interested in the message
	for(int i=0; i < g_PopupMenues.size(); i++)
	{
		if(hwnd == (g_PopupMenues[i])->GetWindow())
		{
			p = g_PopupMenues[i];
			break;
		}
	}

	// if no popup menu object was foud then simply call the defwindowproc
	if(p == NULL)
		return DefWindowProc(hwnd, uMsg, wParam, lParam);

	switch(uMsg)
	{
	case WM_NCHITTEST:
		point.x = GET_X_LPARAM(lParam);
		point.y = GET_Y_LPARAM(lParam);
		ScreenToClient(hwnd, &point);
		ret = p->NcHitTest(point.x, point.y);
		
		if(ret == 0)
			ret = HTCLIENT;
		break;
	case WM_NCMOUSEMOVE:
		point.x = GET_X_LPARAM(lParam);
		point.y = GET_Y_LPARAM(lParam);
		ScreenToClient(hwnd, &point);

		{// hack to make keyboard navigation work when the mouse
		  // is above the window
			static lastX=0;
			static lastY=0;

			if(lastX == point.x && lastY == point.y)
				return 0;
		
			lastX = point.x;
			lastY = point.y;
		}

		p->Mouse(WM_MOUSEMOVE, point.x, point.y);
		break;
	case WM_NCLBUTTONUP:			
		point.x = GET_X_LPARAM(lParam);
		point.y = GET_Y_LPARAM(lParam);
		ScreenToClient(hwnd, &point);
		p->Mouse(uMsg, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
		break;
	case WM_NCLBUTTONDOWN:
		DefWindowProc(hwnd, uMsg, wParam, lParam);
		break;
	case WM_MOUSEMOVE:
		{ // hack to make keyboard navigation work when the mouse
		  // is above the window
			static lastX=0;
			static lastY=0;

			if(lastX == GET_X_LPARAM(lParam) && lastY == GET_Y_LPARAM(lParam))
				return 0;
		
			lastX = GET_X_LPARAM(lParam);
			lastY = GET_Y_LPARAM(lParam);
		}
		// fall through
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		p->Mouse(uMsg, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
		break;
	case WM_PAINT:
		p->Paint();
		break;
	case WM_KEYDOWN: // catches arrow keys etc.
	case WM_CHAR:  // catches small letters and swedish keys..
		p->Key(wParam);
		break;			
	case WM_ACTIVATE:
		p->Activate(LOWORD(wParam), (HWND)lParam);
		break;
	case WM_TIMER:
		p->Time(wParam);
		break;
	case WM_MOVING:
		p->Moving();
		break;
	case WM_WINDOWPOSCHANGING:
		if(IsWindowVisible(hwnd))
			SnappWindow((WINDOWPOS*)lParam, SNAPP_DIST, FALSE);
		break;
	case WM_ERASEBKGND:
		return TRUE;
	case WM_COMMAND:
		p->Command(wParam, lParam);
		break;
	case WM_MOUSELEAVE:
		p->MouseLeave();
		break;
	case LM_POPUP:
		{
			RECT r;
			RECT workArea;
			SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0);

			GetWindowRect(p->GetWindow(), &r);
			GetCursorPos(&point);

			if((point.y + (r.bottom-r.top)) > workArea.bottom)
				point.y = workArea.bottom - (r.bottom - r.top);

			p->Show(point.x, point.y);
			SetForegroundWindow(p->GetWindow());
		}
		break;
	case LM_HIDEPOPUP:
		p->Hide(HIDE_CHILDREN);
		p->Hide(HIDE_PARENTS);
		break;
	case LM_GETREVID:
		{
			char *buf = (char *) lParam;

			if (wParam == 0)
			{
				lstrcpy(buf, "Popup.dll (Johan Redestig): ");
				lstrcat(buf, RELEASE_NO);
				buf[lstrlen(buf)] = '\0';
			}
			else if (wParam == 1)
			{
				lstrcpy(buf, RELEASE_NO);
				buf[lstrlen(buf)] = '\0';
			} 
			else
			{
				lstrcpy(buf, "");
			}

			return lstrlen(buf);

		}
		break;
	default:
		ret = DefWindowProc(hwnd, uMsg, wParam, lParam);
		
	}

	return ret;
}
