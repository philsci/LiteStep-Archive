******************************************************************************
		GeekJofol version 1.0
******************************************************************************
******************************************************************************
This file was created on 1:57 AM 11/30/98 by GeekMaster
******************************************************************************
(	
	Lowell Heddings
	http://skyscraper.fortunecity.com/coding/739
	lheddings@geocities.com
	AIM: lheddin
	IRC: Geekmasta / GeekMastr
	ICQ: 17869937
)
******************************************************************************
	This .dll file is used to control Kjofol via !<commands> in the step.rc
file of litestep.
******************************************************************************

To use: Simply add a line to your step.rc file that looks like the following:

	LoadModule c:\litestep\geekjofol.dll

I think this has to be loaded after the other modules, but I'm not sure.

******************************************************************************

Once you have loaded the module, you can use any of the commands anywhere
in litestep. This could be either a Shortcut or a Hotkey or a Wharf.

For Instance:
	*Hotkey Win F9 !Kjofol_Play
	This line would assign the combo of Win + F9 to Play the current song
The commands are not case sensitive, either

All the commands currently check whether Kjofol is running, and launch it if
its not. The Default path is c:\progra~1\kjofol\kjofol, but you can change
that by using Kjofolpath in the step.rc. This needs to be the full path, along
with the kjofol.exe (cause I'm lazy)

For instance:
KjofolPath c:\audio\kjofol\kjofol.exe

If you do not specify a path, it will try and launch it from the default path.
******************************************************************************
Commands:
******************************************************************************

!Kjofol_Play
		This plays the current song
!Kjofol_Stop
		This stops the current song
!Kjofol_Pause
		This pauses the current song
!Kjofol_Next
		This skips to the next song on the playlist
!Kjofol_Previous
		This skips to the previous song on the playlist
!Kjofol_LoadFile
		This opens the loadfile box
!Kjofol_Quit
		This closes Kjofol
!Kjofol_Minimize
		This minimizes Kjofol
!Kjofol_FastRewind
		This FastRewinds through the current song
!Kjofol_FastForward
		This FastForwards through the current song
!Kjofol_Preferences
		This toggles the Preferences Dialog
!Kjofol_DoubleSize
		Use this with caution.. it freaked on my machine

******************************************************************************
Future
******************************************************************************

I have a real lot more commands to add, and I will do so.
