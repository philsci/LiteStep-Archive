#include "common.h"

HANDLE openPort(const char *name);
vector<byte> readPort(HANDLE serialPort, int numberToRead);
int writePort(HANDLE serialPort, const vector<byte> &data);
void closePort(HANDLE serialPort);

vector<byte> decode(const vector<byte> &rawData);
vector<byte> encode(const vector<byte> &byteCode);

byte lastOpCode = 0;

void DebugHex(const string &prefix, const vector<byte> &data)
{
	string output = prefix;

	for(int i = 0; i < data.size(); i++)
	{
		char oneByte[8];
		sprintf(oneByte, "%02X", data[i]);
		output += string(oneByte);

		if(i != data.size() - 1)
			output += " ";
	}

	OutputDebugString(output.c_str());
}

// opens and configures the serial port
HANDLE openPort(const char *name)
{
	// open the serial port
	HANDLE serialPort = CreateFile(name,
		GENERIC_READ | GENERIC_WRITE,
		0,
		0,
		OPEN_EXISTING,
		0,
		0);

	if(serialPort != INVALID_HANDLE_VALUE)
	{
		// set serial port configuration
		DCB dcb;
		GetCommState(serialPort, &dcb);

		dcb.BaudRate = CBR_2400;
		dcb.ByteSize = 8;
		dcb.Parity = ODDPARITY;
		dcb.StopBits = ONESTOPBIT;

		if(SetCommState(serialPort, &dcb))
		{
			// set timeout values
			COMMTIMEOUTS timeouts;
			memset(&timeouts, 0, sizeof(COMMTIMEOUTS));
			
			timeouts.ReadTotalTimeoutConstant = 300;
			
			if(SetCommTimeouts(serialPort, &timeouts))
				return serialPort;
		}

		CloseHandle(serialPort);
	}

	return INVALID_HANDLE_VALUE;
}

// read raw data from the serial port
vector<byte> readPort(HANDLE serialPort, int numberToRead)
{
	vector<byte> data;
	byte *buffer = new byte[numberToRead];
	unsigned long readCount;

	if(!ReadFile(serialPort, buffer, numberToRead, &readCount, 0))
	{
		COMSTAT comStat;
		unsigned long errors;

		ClearCommError(serialPort, &errors, &comStat);

		delete buffer;
		return data;
	}

	for(int i = 0; i < (int) readCount; i++)
		data.push_back(buffer[i]);

	delete buffer;
	return data;
}

// write a block of raw data to the serial port
int writePort(HANDLE serialPort, const vector<byte> &data)
{
	int length = data.size();
	byte *dataArray = new byte[length];

	for(int i = 0; i < length; i++)
		dataArray[i] = data[i];

	unsigned long writeCount;

	if(!WriteFile(serialPort, dataArray, length, &writeCount, 0))
	{
		delete dataArray;
		return -1;
	}

	FlushFileBuffers(serialPort);

	delete dataArray;
	return (int) writeCount;
}

// closes the serial port
void closePort(HANDLE serialPort)
{
	CloseHandle(serialPort);
}

// decodes an RCX reply packet
vector<byte> decode(const vector<byte> &rawData)
{
	vector<byte> byteCode;

	// there must be at least a header (3), an opcode (2) and a checksum (2)
	if(rawData.size() < 7)
		return byteCode;

	// header must be 55 FF 00
	if(rawData[0] != 0x55 || rawData[1] != 0xFF || rawData[2] != 0x00)
		return byteCode;

	// actual byte code length
	int length = (rawData.size() - 5) / 2;
	int i = 3;

	while(length--)
	{
		byteCode.push_back(rawData[i]);
		i = i + 2;
	}

	// clear the sequence bit in the opcode if set
	byteCode[0] = byteCode[0] & ~0x08;

	return byteCode;
}

// encodes RCX bytecode for transmission to the RCX
vector<byte> encode(const vector<byte> &byteCode)
{
	vector<byte> rawData;

	// packet header is 55 FF 00
	rawData.push_back(0x55);
	rawData.push_back(0xFF);
	rawData.push_back(0x00);

	int length = byteCode.size();
	int i = 0;

	byte checksum = 0;

	// for each byte write it and its complement and update checksum
	while(length--)
	{
		byte aByte = byteCode[i++];

		rawData.push_back(aByte);
		rawData.push_back(~aByte);

		checksum = checksum + aByte;
	}

	// write the checksum
	rawData.push_back(checksum);
	rawData.push_back(~checksum);

	return rawData;
}

// sends a sequence of bytecode to the RCX and optionally waits for a reply
int rcxSend(vector<byte> &byteCode, boolean expectReply)
{
	boolean succeeded = false;
	int replyValue = 1;

	if(byteCode.size() < 1)
		return 0;

	byte opCode = byteCode[0];

	char port[8];
	GetRCString("RCXPort", port, "COM1", 8);
	HANDLE serialPort = openPort(port);

	if(serialPort != INVALID_HANDLE_VALUE)
	{
		if(opCode == lastOpCode)
			byteCode[0] = byteCode[0] ^ 0x08;

		lastOpCode = byteCode[0];

		vector<byte> rawData = encode(byteCode);
		DebugHex("Sending: ", rawData);

		if(writePort(serialPort, rawData) > 0)
		{
			if(expectReply)
			{
				// skip echo
				readPort(serialPort, rawData.size());

				// read reply
				vector<byte> reply = decode(readPort(serialPort, 64));
				DebugHex("Received: ", reply);
				byte replyCode = (~opCode) & ~0x08;

				// check reply code
				if(reply.size() > 0 && reply[0] == replyCode)
				{
					succeeded = true;

					// get the return value
					if(reply.size() == 2)
						replyValue = (int) reply[1];
					else if(reply.size() == 3)
						replyValue = ((int) reply[1]) | (((int) reply[2]) << 8);
				}
			}
			else
			{
				succeeded = true;
			}
		}

		closePort(serialPort);
	}

	if(succeeded)
		return replyValue;
	else
		return 0;
}

// send an opcode with no parameters
int rcxSend(byte opCode, boolean expectReply)
{
	vector<byte> byteCode;

	byteCode.push_back(opCode);

	return rcxSend(byteCode, expectReply);
}

// send an opcode with 1 parameter
int rcxSend(byte opCode, byte parameterA, boolean expectReply)
{
	vector<byte> byteCode;

	byteCode.push_back(opCode);
	byteCode.push_back(parameterA);

	return rcxSend(byteCode, expectReply);
}

// send an opcode with 2 parameters
int rcxSend(byte opCode, byte parameterA, byte parameterB, boolean expectReply)
{
	vector<byte> byteCode;

	byteCode.push_back(opCode);
	byteCode.push_back(parameterA);
	byteCode.push_back(parameterB);

	return rcxSend(byteCode, expectReply);
}

// send an opcode with 3 parameters
int rcxSend(byte opCode, byte parameterA, byte parameterB, byte parameterC, boolean expectReply)
{
	vector<byte> byteCode;

	byteCode.push_back(opCode);
	byteCode.push_back(parameterA);
	byteCode.push_back(parameterB);
	byteCode.push_back(parameterC);

	return rcxSend(byteCode, expectReply);
}
