#include "common.h"
#include "bangCommands.h"

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	AddBangCommands();
	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommands();
}
