#if !defined(__RCX_H)
#define __RCX_H

int rcxSend(vector<byte> &byteCode, boolean expectReply = true);

int rcxSend(byte opCode, boolean expectReply = true);
int rcxSend(byte opCode, byte parameterA, boolean expectReply = true);
int rcxSend(byte opCode, byte parameterA, byte parameterB, boolean expectReply = true);
int rcxSend(byte opCode, byte parameterA, byte parameterB, byte parameterC, boolean expectReply = true);

#endif
