#include "common.h"
#include "bangCommands.h"

void RCXBatteryStatus(HWND caller, const char *arguments);
void RCXBeep(HWND caller, const char *arguments);
void RCXFloat(HWND caller, const char *arguments);
void RCXOff(HWND caller, const char *arguments);
void RCXOn(HWND caller, const char *arguments);
void RCXSelectProgram(HWND caller, const char *arguments);
void RCXSendMessage(HWND caller, const char *arguments);
void RCXSetTxPower(HWND caller, const char *arguments);
void RCXSleep(HWND caller, const char *arguments);
void RCXStart(HWND caller, const char *arguments);
void RCXStop(HWND caller, const char *arguments);
void RCXTest(HWND caller, const char *arguments);

// bang commands implemented by this module
struct { const char *name; BangCommand *function; } bangCommands[] = {
	{ "!RCXBatteryStatus", RCXBatteryStatus },
	{ "!RCXBeep", RCXBeep },
	{ "!RCXFloat", RCXFloat },
	{ "!RCXOff", RCXOff },
	{ "!RCXOn", RCXOn },
	{ "!RCXSelectProgram", RCXSelectProgram },
	{ "!RCXSendMessage", RCXSendMessage },
	{ "!RCXSetTxPower", RCXSetTxPower },
	{ "!RCXSleep", RCXSleep },
	{ "!RCXStart", RCXStart },
	{ "!RCXStop", RCXStop },
	{ "!RCXTest", RCXTest }
};

const int bangCommandCount = sizeof(bangCommands) / sizeof(bangCommands[0]);

// register bang commands with LSAPI
void AddBangCommands()
{
	for(int i = 0; i < bangCommandCount; i++)
		AddBangCommand(bangCommands[i].name, bangCommands[i].function);
}

// clean up
void RemoveBangCommands()
{
	for(int i = 0; i < bangCommandCount; i++)
		RemoveBangCommand(bangCommands[i].name);
}

// display the RCX battery status (PBBattery)
void RCXBatteryStatus(HWND caller, const char *arguments)
{
	float voltage = (float) rcxSend(0x30) / 1000;

	char message[64];
	sprintf(message, "Battery Voltage: %1.1fV", voltage);

	MessageBox(caller, message, "RCX", MB_SETFOREGROUND);
}
	
// play one of the predefined sounds (PlaySystemSound)
void RCXBeep(HWND caller, const char *arguments)
{
	int whichOne = atoi(arguments) - 1;
	rcxSend(0x51, (byte) whichOne);
}

// switch the given outputs to the float state
void RCXFloat(HWND caller, const char *arguments)
{
	byte parameter = 0x00;

	while(*arguments)
	{
		if(*arguments == 'A' || *arguments == 'a')
			parameter = parameter | 0x01;
		else if(*arguments == 'B' || *arguments == 'b')
			parameter = parameter | 0x02;
		else if(*arguments == 'C' || *arguments == 'c')
			parameter = parameter | 0x04;

		arguments++;
	}

	rcxSend(0x21, parameter);
}

// switch the given outputs off (brake)
void RCXOff(HWND caller, const char *arguments)
{
	byte parameter = 0x40;

	while(*arguments)
	{
		if(*arguments == 'A' || *arguments == 'a')
			parameter = parameter | 0x01;
		else if(*arguments == 'B' || *arguments == 'b')
			parameter = parameter | 0x02;
		else if(*arguments == 'C' || *arguments == 'c')
			parameter = parameter | 0x04;

		arguments++;
	}

	rcxSend(0x21, parameter);
}

// switch the given outputs on
void RCXOn(HWND caller, const char *arguments)
{
	byte parameter = 0xB0;

	while(*arguments)
	{
		if(*arguments == 'A' || *arguments == 'a')
			parameter = parameter | 0x01;
		else if(*arguments == 'B' || *arguments == 'b')
			parameter = parameter | 0x02;
		else if(*arguments == 'C' || *arguments == 'c')
			parameter = parameter | 0x04;

		arguments++;
	}

	rcxSend(0x21, parameter);
}

// change the current program slot (SelectProgram)
void RCXSelectProgram(HWND caller, const char *arguments)
{
	int whichOne = atoi(arguments) - 1;
	rcxSend(0x91, (byte) whichOne);
}

// sends a numerical message to the RCX (...)
void RCXSendMessage(HWND caller, const char *arguments)
{
	int message = atoi(arguments);
	rcxSend(0xF7, (byte) message, false);
}

// sets the IR transmitter power level (PBTxPower)
void RCXSetTxPower(HWND caller, const char *arguments)
{
	int level = atoi(arguments);
	rcxSend(0x31, (byte) level);
}

// turn off the RCX (PBTurnOff)
void RCXSleep(HWND caller, const char *arguments)
{
	rcxSend(0x60);
}

// start the current program (StartTask 0)
void RCXStart(HWND caller, const char *arguments)
{
	rcxSend(0x71, 0x00, true);
}

// stop the current program (StopAllTasks)
void RCXStop(HWND caller, const char *arguments)
{
	rcxSend(0x50);
}

// check for a good connection to the RCX (PBAliveOrNot)
void RCXTest(HWND caller, const char *arguments)
{
	if(rcxSend(0x10) == 0)
	{
		MessageBox(caller,
			"Could not communicate with the RCX, check that it is in range and turned on.",
			"RCX",
			MB_SETFOREGROUND | MB_ICONERROR);
	}
	else
	{
		MessageBox(caller,
			"Test successful, RCX is ready.",
			"RCX",
			MB_SETFOREGROUND);
	}
}
