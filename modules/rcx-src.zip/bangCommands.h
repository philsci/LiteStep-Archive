#if !defined(__BANGCOMMANDS_H)
#define __BANGCOMMANDS_H

void AddBangCommands();
void RemoveBangCommands();

#endif
