DropBoxay V0.2
--------------
Written by MrJukes, Modified by Jonnay

Gushes and Thanks
-----------------
Because this work stands on the shoulders of so many other individuals, It would be massively unfair for me 
to not say something.

So, big extra big big big thanks to MrJukes.  I sent him email awhile ago, he never replied, I don't know if 
he got it, but yea.  I hope he is ok with the fact that I mod(ifi)ed his mod(ule).  

Mr Jukes:  Your modules rule! LOTS AND LOTS! AWWWWWWWWWOOOOOOOO!

Also, big extra huge big big big thanks to Chaku, whom, whilst probably working on more important things 
(like the next version of litestep, or ckvwm, or any number of kickass modules that man is producing) took the
time to help me, a complete newbie to C/C++, let alone module programming, and "teaching me to fish".

90% of the code of this module is written by MrJukes.  In fact, I grabbed the magic pink transparency from
one of his other modules, XProp (also a quite slick module, that is on the hit-list of old-modules-to-be-modded)

So if all goes well, this is going to be going under active development.  

A big thanks to Floach for testing the module.  Awwooo!

Also thanks to Shadoline, who is helping test the thing under Win98. WHOOT!

DISCLAIMER:
-----------
	I don't know what I am doing.  Sorry.  If there is a bug, I am going to try my damnest to fix it, but...
		I am so new to this whole programming in C/C++ thing, it might take me hours to fix a relatively
		straightforward bug.
		
	I don't know if this is going to work on your system.  It has been tested on a WinNT 4.0 Sp6, latest 
		build from shellfront (24.6 - 05-29-01). Any other system, and well, who knows, try it!  If it doesn't work, we will 
		see about making it go.
		
	I did not ask to use MrJukes's source.  its just that simple.  The source was in fact available.  If he
		decides that its bad that I changed his module, for whatever reason, I'm just gonna tuck it away, and 
		not release it.  I probably will end up writing my own drop-box if it does come to that.
		
Scared yet?  Good.  I just wanna impress upon you that it might just not work as advertized.  Batteries not Included, and alladat.
		
To Do Features:
---------------

	- Change the way commands work.  Instead of using winexec, support for actual bangs  i.e.
			*dropbox 300 100 db_normal.bmp db_over.bmp db_click.bmp "!amp_loadfile $1"
	
	- Support for classid's (specifically the recycle bin, but there might be other classid's that would benefit
		from having files dropped into them)

	- A complete re-write (eventually)
	
	- Add some kinda toggle bangs.
	
	- Dropboxes can be on all VWM's or on certain VWM's.
	
Fixed Bugs/Changes:
-------------------
	v.02	-	Now the dropboxes follow you around on vwms.  Whoot!
			-	Added an extra argument, so that when you click on the dropbox, it can actually do something
			-	Added 2 bang commands, !dropboxShow amd !dropboxHide
			-	Fixed the Documentation/Dumbssity bug.  Dropbox has always been able to execute other programs. 8P
			-	Killed the dumb idea of seperate boxes for seperate vwm's.  Less dependancys on which vwm module you use.
				if you want it, you can do it yourself, easylike, in your step.rc.
			-	Added Drop Box Groups.
				
Known Bugs:
-----------
	v 0.2	-	On recycle, the dropbox seems to go to the top.  This only happens once, after a window is put on top of it, 
				everything behaves.
			-	Every once in awhile on recycle, It can't seem to initalize itself.  This is beyond my ability to debug, but
				I'll get it going soon.
				
Actual Documentation:
----------------------
As the man, MrJukes said:
"DropBox is a load module that will put an icon on your desktop.  When you
drag a file onto the icon, DropBox will perform the specified action upon
that file."

Three new features have been added to the module, Magic Pink Transparency, negative x and y values, and 
informative error messages when you misconjecture the step.rc.  Also, since v.02 if you read the changes, you can
show and hide the dropboxes from bang commands, and there is a seperate command for when the drop box is clicked, 
as apposed to hving something dragged on it.  Hopefully this will soon pave the way for this module to be used as a 
recycle bin of some kind.  I need more classid mojo before I tackle that.


These were not all that difficult.  As i said before.  Most of this is Mr. jukes doing.  NOT mine.  ;)

Install
--------
First toss this in your step.rc with all the other load module lines:

LoadModule "$LiteStepDir$dropbox.dll"

The next is to add something like this to your step.rc
DropBoxImageDir "$PixMapPath$dropbox"


Finally, make the actual DropBoxes.  This is alot like making a shortcut.  You can copy this right to your setp rc
comments and all, for handy dandy easy editing.

;DropBox 	 x	 y	 normal_bitmap	 over_bitmap	 click_bitmap		Group	Drag and Drop Command							Click Command
;--------  	--- --- --------------- --------------- ------------------- -----	-------------------------------------------		-----------------------
*DropBox 	2 	-50 misc.bmp		misc_over.bmp 	misc_click.bmp 		  1		"copy $1 X:\jonny.sanriowasteland.net\misc" 	"explorer /n, x:\jonny.sanriowasteland.net\misc"



There ya go! Have fun! SEND ME EMAIL! TELL ME ABOUT THIS THING IF YOU USE IT!  I wanna know.  I mean, what's
the point in developing/modifying a module that no-one uses right?  Gimmi your feature requests.  If I can't
implement them right away, I'll tell you, and I will keep it in mind for the future.

Bang Commands
--------------

!dropboxShow - shows all drop boxes
!dropboxHide - hides all drop boxes
!dropboxShowGroup x - shows dropboxes in group x
!dropboxHideGroup x - hides dropboxes in group x

pretty simple huh?

Contact Jonnay
---------------

jonny@sanriowasteland.net
icq 3423013
Jonny on irc.openprojects.org.  usually in #ls2k, #lshelp

And now, the original documentation:

///////////////////////////
// DropBox B1
// Written By: MrJukes
// Released: 1/10/00
///////////////////////////

// What is DropBox?
DropBox is a load module that will put an icon on your desktop.  When you
drag a file onto the icon, DropBox will perform the specified action upon
that file.

LoadModule c:\litestep\dropbox.dll

//Step.rc entries
*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "C:\program files\accessories\wordpad.exe $1"

*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "copy $1 c:\temp"
*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "move $1 c:\temp\"

That is:
*DropBox X Y normal over click "action"

DropBoxImageDir c:\litestep\images\dropbox

*Note* The width and height of the dropbox icon are the width of height of
the bitmap specified as the normal bitmap.

Have fun,
	MrJukes