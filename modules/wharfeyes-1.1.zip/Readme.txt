WharfEye's v1.1 (c) 1998 Marlon West
WTF is this:
A Wharf Module that sits on your Wharf bar and follows your mouse around
with a pair of eyes.

Installation:
put the dll in your litestep directory, make an entry in the RC as normal.
Copy the images to your litestep\images dir.
In your modules.ini be sure and put these following lines in(or it won't work.)

[WharfEyes]
EYEBMP0=c:\litestep\images\eye01.bmp
EYEBMP1=c:\litestep\images\eye02.bmp
EYEBMP2=c:\litestep\images\eye03.bmp
EYEBMP3=c:\litestep\images\eye04.bmp
EYEBMP4=c:\litestep\images\eye05.bmp
EYEBMP5=c:\litestep\images\eye06.bmp
EYEBMP6=c:\litestep\images\eye07.bmp
EYEBMP7=c:\litestep\images\eye08.bmp
EYEBMP8=c:\litestep\images\eye09.bmp
EYEBMP9=c:\litestep\images\eye10.bmp
EYEBMP10=c:\litestep\images\eye11.bmp
EYEBMP11=c:\litestep\images\eye12.bmp
EYEBMP12=c:\litestep\images\eye13.bmp
EYEBMP13=c:\litestep\images\eye14.bmp
EYEBMP14=c:\litestep\images\eye15.bmp
EYEBMP15=c:\litestep\images\eye16.bmp
EYEBMP16=c:\litestep\images\eye17.bmp
EYEBMP17=c:\litestep\images\eye18.bmp
EYEBMP18=c:\litestep\images\eye19.bmp
EYEBMP19=c:\litestep\images\eye20.bmp
EYEBMP20=c:\litestep\images\eye21.bmp

Upgrading: 
Remember that you must coment Wharfeye's *Wharf line out, and recycle
before you copy the new DLL over, or else you'll get a sharing violation.
Also note that the images have changed, these where made by Quarx and 
considerably better than the ones i had made.



Configuration:
You can replace the skin for this app simply by specifying different bitmaps
in the ini entry's, please keep the number to 21, and treat the EYEBMP1 as the
first frame. If you decide to use/make a diffrent set of bitmaps, i recomend 
using 64x64, as bitmap size.


Revision list:
v1.1 - added support for different size bitmaps, instead of just
	29x32

v1.0 - Wharfeye's released.



Other crap that has nothing to do with this Module:
if you have any problems/questions feel free to email me at:
aquari@surfnetusa.com

