/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeasureNet.h"

CMeasureNet::CMeasureNet() : CMeasure()
{
	m_Table = NULL;
	m_NumOfTables = 0;
	m_UpdateCounter = 0;
}

CMeasureNet::~CMeasureNet()
{
	delete [] m_Table;
}

void CMeasureNet::UpdateTable(int counter)
{
	if(counter == m_UpdateCounter)
	{
		// The table is already up-to-date
		return;
	}

	m_UpdateCounter = counter;

	if(m_Table == NULL)
	{
		// Gotta reserve few butes for the tables
		DWORD value;
		if(GetNumberOfInterfaces(&value) == NO_ERROR)
		{
			m_NumOfTables = value;

			if(m_NumOfTables > 0)
			{
				DWORD size = sizeof(MIB_IFTABLE) + sizeof(MIB_IFROW) * m_NumOfTables;
				m_Table = (MIB_IFTABLE*)new char[size];
			}
		}
	}

	if(m_Table)
	{
		DWORD size = sizeof(MIB_IFTABLE) + sizeof(MIB_IFROW) * m_NumOfTables;
		if(GetIfTable(m_Table, &size, false) != NO_ERROR)
		{
			delete [] m_Table;
			m_Table = (MIB_IFTABLE*)new char[size];
			if(GetIfTable(m_Table, &size, false) != NO_ERROR)
			{
				// Something's wrong. Unable to get the table.
				delete [] m_Table;
				m_Table = NULL;
			}
		}
	}
}
