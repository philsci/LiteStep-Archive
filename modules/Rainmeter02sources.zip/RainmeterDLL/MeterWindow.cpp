/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/


#include "MeterWindow.h"
#include "Rainmeter.h"
#include "Error.h"
#include <math.h>
#include <time.h>
#include "MeterHistogram.h"

#define METERTIMER 1

/* 
** CMeterWindow
**
** Constructor
**
*/
CMeterWindow::CMeterWindow()
{
	m_DC = NULL;
	m_Background = NULL;
	m_DoubleBuffer = NULL;
	m_Window = NULL;
	m_Instance = NULL;

	m_WindowX = 0;
	m_WindowY = 0;
	m_WindowW = 0;
	m_WindowH = 0;
	m_WindowAlwaysOnTop = false;
	m_WindowDraggable = false;
	m_WindowUpdate = 1000;
	m_WindowHide = false;
	m_Hidden = false;
}

/* 
** ~CMeterWindow
**
** Destructor
**
*/
CMeterWindow::~CMeterWindow()
{
	// Destroy the meters
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		delete (*i);
	}

	if(m_DC) DeleteObject(m_DC);
	if(m_Background) DeleteObject(m_Background);
	if(m_DoubleBuffer) DeleteObject(m_DoubleBuffer);

	if(m_Window) DestroyWindow(m_Window);

	BOOL Result;
	int counter = 0;
	do {
		// Wait for the window to die
		Result = UnregisterClass("RainmeterMeterWindow", m_Instance);
		Sleep(100);
		counter += 1;
	} while(!Result && counter < 10);
}

/* 
** Initialize
**
** Initializes the window, creates the class and the window.
**
*/
int CMeterWindow::Initialize(CRainmeter& Rainmeter, HWND Parent, HINSTANCE Instance)
{
	WNDCLASSEX wc;

	if(Parent==NULL || Instance==NULL) 
	{
		CError::SetError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
		throw true;
	}

	m_Instance = Instance;

	// Register the windowclass
	memset(&wc, 0, sizeof(WNDCLASSEX));
	wc.style = CS_NOCLOSE;
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.lpfnWndProc = WndProc;
	wc.hInstance = Instance;
	wc.lpszClassName = "RainmeterMeterWindow";
	
	if(!RegisterClassEx(&wc))
	{
		CError::SetError(CError::ERROR_REGISTER_WINDOWCLASS, __LINE__, __FILE__);
		throw true;
	}

	m_Window = CreateWindowEx(WS_EX_TOOLWINDOW, 
							"RainmeterMeterWindow", 
							NULL, 
							WS_POPUP,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							CW_USEDEFAULT,
							Parent,
							NULL,
							Instance,
							this);

	if(m_Window == NULL) 
	{ 
		CError::SetError(CError::ERROR_CREATE_WINDOW, __LINE__, __FILE__);
		throw true;
	}

	SetWindowLong(m_Window, GWL_USERDATA, magicDWord);

	ReadConfig(Rainmeter.GetCommandLine());
	InitializeMeters();

	// Handle negative coordinates
	RECT r;
	GetClientRect(GetDesktopWindow(), &r); 
	if(m_WindowX < 0) m_WindowX += r.right;
	if(m_WindowY < 0) m_WindowY += r.bottom;

	if(m_WindowAlwaysOnTop && !Rainmeter.IsWharf()) 
	{
		SetWindowPos(m_Window, HWND_TOPMOST, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOACTIVATE | SWP_SHOWWINDOW);
	} 
	else 
	{
		SetWindowPos(m_Window, HWND_BOTTOM, m_WindowX, m_WindowY, m_WindowW, m_WindowH, SWP_NOACTIVATE | SWP_SHOWWINDOW);
	}

	Update();

	if(0 == SetTimer(m_Window, METERTIMER, m_WindowUpdate, NULL)) 
	{
		CError::SetError("Unable to create a timer!", __LINE__, __FILE__);
		throw true;
	}

	return 0;
}

void CMeterWindow::Hide()
{
	if(m_Window) SetWindowPos(m_Window, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_HIDEWINDOW);
}

void CMeterWindow::Show()
{
	if(m_Window) SetWindowPos(m_Window, NULL, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_SHOWWINDOW);
}

void CMeterWindow::ReadConfig(LPCSTR cmdLine)
{
	char tmpSz[MAX_LINE_LENGTH];
	char iniFile[MAX_LINE_LENGTH];

	if(cmdLine == NULL || cmdLine[0]=='\0') 
	{
		// No arguments, so we'll try to use the DLL's directory
		GetModuleFileName(GetModuleHandle("Rainmeter.dll"), iniFile, MAX_LINE_LENGTH);

		// Remove the module's name from the path
		char* pos = strrchr(iniFile, '\\');
		if(pos) 
		{
			*(pos + 1)='\0';
		} 
		else 
		{
			iniFile[0]='\0';
		}

		// Add the filename
		if(strlen(iniFile) < MAX_LINE_LENGTH - 15) 
		{ 
			strcat(iniFile, "Rainmeter.ini");
		}
	} 
	else 
	{
		strncpy(iniFile, cmdLine, MAX_LINE_LENGTH);
		iniFile[MAX_LINE_LENGTH - 1] = '\0';
	}

	// Global settings
	if(GetPrivateProfileString( "Rainmeter", "Background", "", tmpSz, 255, iniFile) > 0) 
	{
		VarExpansion(tmpSz, tmpSz);		// Expand litestep variables
 		m_BackgroundName = tmpSz;
	}

	m_WindowX = GetPrivateProfileInt( "Rainmeter", "WindowX", 0, iniFile);
	m_WindowY = GetPrivateProfileInt( "Rainmeter", "WindowY", 0, iniFile);

	m_WindowAlwaysOnTop = 0!=GetPrivateProfileInt( "Rainmeter", "AlwaysOnTop", 0, iniFile);
	m_WindowDraggable = 0!=GetPrivateProfileInt( "Rainmeter", "Draggable", 0, iniFile);
	m_WindowUpdate = GetPrivateProfileInt( "Rainmeter", "Update", 1000, iniFile);
	m_WindowHide = 0!=GetPrivateProfileInt( "Rainmeter", "HideOnMouseOver", 0, iniFile);

	// Create the meters

	// Get all the sections (i.e. different meters)
	GetPrivateProfileString( NULL, NULL, NULL, tmpSz, MAX_LINE_LENGTH, iniFile);
	char* pos = tmpSz;
	while(strlen(pos) > 0)
	{
		if(strcmp("Rainmeter", pos) != 0)
		{
			CMeter* meter = CreateMeter(iniFile, pos);
			meter->ReadConfig(iniFile, pos);
			m_Meters.push_back(meter);
		}
		pos = pos + strlen(pos) + 1;
	}
}

CMeter* CMeterWindow::CreateMeter(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read the type of the meter and create such
	if(GetPrivateProfileString( section, "Type", "HISTOGRAM", tmpSz, 255, filename) > 0) 
	{
		if(_stricmp("HISTOGRAM", tmpSz) == 0)
		{
			return new CMeterHistogram;
		} 
	}

	std::string errorSz("No such meter: ");
	errorSz += tmpSz;
	CError::SetError(errorSz, __LINE__, __FILE__);
	throw true;

	return NULL;
}

void CMeterWindow::InitializeMeters()
{
	// Load the bitmaps
	if(!m_BackgroundName.empty())
	{
		char tmpSz[256];
		strcpy(tmpSz, m_BackgroundName.c_str());
		m_Background = LoadLSImage(tmpSz, NULL);

		if(m_Background == NULL)
		{
			std::string errorSz("Background not found: ");
			errorSz += m_BackgroundName;
			CError::SetError(errorSz, __LINE__, __FILE__);
			throw true;
		}
	}

	// Calculate the window dimensions
	if(m_Background)
	{
		// Get the size form the background bitmap
		BITMAP bm;
		GetObject(m_Background, sizeof(BITMAP), &bm);

		m_WindowW = bm.bmWidth;
		m_WindowH = bm.bmHeight;
	} 
	else
	{
		// No background -> Get the largest meter point
		std::list<CMeter*>::iterator i = m_Meters.begin();
		for( ; i != m_Meters.end(); i++)
		{
			m_WindowW = max(m_WindowW , (*i)->GetX() + (*i)->GetW());
			m_WindowH = max(m_WindowH , (*i)->GetY() + (*i)->GetH());
		}
	}

	if(m_WindowW == 0 || m_WindowH == 0)
	{
		CError::SetError("The window's dimensions are zero.", __LINE__, __FILE__);
		throw true;
	}

	// Create DC and doublebuffer
	HWND desktop = GetDesktopWindow();
	HDC DDC = GetDC(desktop);
	m_DC = CreateCompatibleDC(DDC);
	m_DoubleBuffer = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
	
	// If Background is not set, take a copy from the desktop
	if(m_Background == NULL) 
	{
		m_Background = CreateCompatibleBitmap(DDC, m_WindowW, m_WindowH);
		HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);
		BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, DDC, m_WindowX, m_WindowY, SRCCOPY);
		SelectObject(m_DC, oldBM);
	}

	ReleaseDC(desktop, DDC);

	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_Background);
	// Initalize all meters
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		(*i)->Initialize(*this);
	}
	SelectObject(m_DC, oldBM);

	// Set window region if needed
	if(!m_BackgroundName.empty()) 
	{
		// m_Background must not be in any DC when calling BitmapToRegion
		HRGN region = BitmapToRegion(m_Background, RGB(255,0,255), 0x101010, 0, 0);
		SetWindowRgn(m_Window, region, FALSE);
	}
}

void CMeterWindow::Update()
{
	// Copy the background over the doublebuffer
	HDC tmpDC = CreateCompatibleDC(m_DC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_Background);
	HBITMAP oldBM2 = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);
	BitBlt(m_DC, 0, 0, m_WindowW, m_WindowH, tmpDC, 0, 0, SRCCOPY);
	SelectObject(tmpDC, oldBM);
	DeleteDC(tmpDC);

	// Update all meters (m_DC must hold the Doublebuffer)
	std::list<CMeter*>::iterator i = m_Meters.begin();
	for( ; i != m_Meters.end(); i++)
	{
		(*i)->Update(*this);
	}

	SelectObject(m_DC, oldBM2);
}

LRESULT CMeterWindow::OnPaint(WPARAM wParam, LPARAM lParam) 
{
	PAINTSTRUCT ps;
	RECT rect;
	HDC winDC = BeginPaint(m_Window, &ps);

	GetClientRect(m_Window, &rect);

	// Just blit the doublebuffer to the window
	HBITMAP oldBM = (HBITMAP)SelectObject(m_DC, m_DoubleBuffer);
	BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
	SelectObject(m_DC, oldBM);

	EndPaint(m_Window, &ps);
	return 0;
}

LRESULT CMeterWindow::OnTimer(WPARAM wParam, LPARAM lParam) 
{
	static int Count=1;

	if(wParam == METERTIMER) 
	{
		ToggleWindowIfNecessary();
		
		Update();

		// Just blit the doublebuffer to the window
		RECT rect;
		GetClientRect(m_Window, &rect);
		HDC winDC = GetWindowDC(m_Window);
		SelectObject(m_DC, m_DoubleBuffer);
		BitBlt(winDC, 0, 0, rect.right, rect.bottom, m_DC, 0, 0, SRCCOPY);
		ReleaseDC(m_Window, winDC);
	}

	return 0;
}

void CMeterWindow::ToggleWindowIfNecessary()
{
	if(m_WindowHide)
	{
		if(GetKeyState(VK_CONTROL) & 0x8000 || GetKeyState(VK_SHIFT) & 0x8000 || GetKeyState(VK_MENU) & 0x8000)
		{
			// If Alt, shift or control is down, do not hide the window
			return;
		}

		bool inside = false;
		POINT pos;
		RECT rect;

		GetCursorPos(&pos);
		GetWindowRect(m_Window, &rect);

		if(rect.left <= pos.x && rect.right >= pos.x &&
		   rect.top <= pos.y && rect.bottom >= pos.y) inside = true;

		if(m_Hidden && !inside)
		{
			// Show window
			ShowWindow(m_Window, SW_SHOWNOACTIVATE);
			m_Hidden = false;
		}
		else if(!m_Hidden && inside)
		{
			// Hide window if it is visible
			if(IsWindowVisible(m_Window))
			{
				ShowWindow(m_Window, SW_HIDE);
				m_Hidden = true;
			}
		}
	}
}


LRESULT CMeterWindow::OnCreate(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

LRESULT CMeterWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

LRESULT CMeterWindow::OnNcHitText(WPARAM wParam, LPARAM lParam) 
{
	if(m_WindowDraggable)
	{
		return HTCAPTION;
	}
	return HTCLIENT;
}

LRESULT CMeterWindow::OnWindowPosChanging(WPARAM wParam, LPARAM lParam) 
{
	if(!m_WindowAlwaysOnTop)
	{
		LPWINDOWPOS wp=(LPWINDOWPOS)lParam;
		wp->flags|=SWP_NOZORDER;
	}

	return 0;
}

LRESULT CMeterWindow::OnDestroy(WPARAM wParam, LPARAM lParam) 
{
	return 0;
}

/* 
** WndProc
**
** The window procedure for the Meter
**
*/
LRESULT CALLBACK CMeterWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static CMeterWindow* Window=NULL;

	if(uMsg==WM_CREATE) {
		// Fetch this window-object from the CreateStruct
		Window=(CMeterWindow*)((LPCREATESTRUCT)lParam)->lpCreateParams;
	}

	BEGIN_MESSAGEPROC
		MESSAGE(OnPaint, WM_PAINT)
		MESSAGE(OnCreate, WM_CREATE)
		MESSAGE(OnDestroy, WM_DESTROY)
		MESSAGE(OnTimer, WM_TIMER)
		MESSAGE(OnCommand, WM_COMMAND)
		MESSAGE(OnNcHitText, WM_NCHITTEST)
		MESSAGE(OnWindowPosChanging, WM_WINDOWPOSCHANGING)
//    MESSAGE(onEndSession,        WM_ENDSESSION)
//    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
//    MESSAGE(onGetRevId,          LM_GETREVID)
//    MESSAGE(onMouseButtonDown,   WM_RBUTTONDOWN)
//    MESSAGE(onTimer,             WM_TIMER)
//    MESSAGE(onMouseButtonDBL,    WM_LBUTTONDBLCLK)
//    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
//    MESSAGE(onMouseButtonUp,     WM_RBUTTONUP)
	END_MESSAGEPROC
}

bool CMeterWindow::IsNT()
{
	// Check if you are running a real OS

	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx((OSVERSIONINFO*)&osvi))
	{
		// Something's wrong, lets assime Win9x
		return false;
	}

	if(osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		return true;	// You got NT
	}
	
	return false;	// Wintendo alert!
}

