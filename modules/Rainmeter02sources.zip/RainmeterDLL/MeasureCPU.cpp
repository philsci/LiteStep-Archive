/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeasureCPU.h"

#define SystemBasicInformation       0
#define SystemPerformanceInformation 2
#define SystemTimeInformation        3

#define Li2Double(x) ((double)((x).HighPart) * 4.294967296E9 + (double)((x).LowPart))

typedef struct
{
    DWORD   dwUnknown1;
    ULONG   uKeMaximumIncrement;
    ULONG   uPageSize;
    ULONG   uMmNumberOfPhysicalPages;
    ULONG   uMmLowestPhysicalPage;
    ULONG   uMmHighestPhysicalPage;
    ULONG   uAllocationGranularity;
    PVOID   pLowestUserAddress;
    PVOID   pMmHighestUserAddress;
    ULONG   uKeActiveProcessors;
    BYTE    bKeNumberProcessors;
    BYTE    bUnknown2;
    WORD    wUnknown3;
} SYSTEM_BASIC_INFORMATION;

typedef struct
{
    LARGE_INTEGER   liIdleTime;
    DWORD           dwSpare[76];
} SYSTEM_PERFORMANCE_INFORMATION;

typedef struct
{
    LARGE_INTEGER liKeBootTime;
    LARGE_INTEGER liKeSystemTime;
    LARGE_INTEGER liExpTimeZoneBias;
    ULONG         uCurrentTimeZoneId;
    DWORD         dwReserved;
} SYSTEM_TIME_INFORMATION;


// ntdll!NtQuerySystemInformation (NT specific!)
//
// The function copies the system information of the
// specified type into a buffer
//
// NTSYSAPI
// NTSTATUS
// NTAPI
// NtQuerySystemInformation(
//    IN UINT SystemInformationClass,    // information type
//    OUT PVOID SystemInformation,       // pointer to buffer
//    IN ULONG SystemInformationLength,  // buffer size in bytes
//    OUT PULONG ReturnLength OPTIONAL   // pointer to a 32-bit
//                                       // variable that receives
//                                       // the number of bytes
//                                       // written to the buffer 
// );
typedef LONG (WINAPI *PROCNTQSI)(UINT,PVOID,ULONG,PULONG);

PROCNTQSI NtQuerySystemInformation = NULL;

CMeasureCPU::CMeasureCPU() : CMeasure()
{
	m_CPUFromRegistry = false;
}

CMeasureCPU::~CMeasureCPU()
{
	if(m_CPUFromRegistry)
	{
		// Stop the counter if it was started
		HKEY hkey;
		DWORD dwDataSize;
		DWORD dwType;
		DWORD dwDummy;

		RegOpenKeyEx(HKEY_DYN_DATA, "PerfStats\\StopStat", 0, KEY_ALL_ACCESS, &hkey); 
		dwDataSize = sizeof(dwDummy); 
		RegQueryValueEx(hkey, "KERNEL\\CPUUsage", NULL, &dwType, (LPBYTE)&dwDummy, &dwDataSize); 
		RegCloseKey(hkey); 
	}
}

void CMeasureCPU::Update(CMeterWindow& meterWindow)
{
	static bool firstTime = true;

	if(meterWindow.IsNT())
	{
		// This code is 'borrowed' form http://www.codepile.com/tric21.shtml

		static SYSTEM_PERFORMANCE_INFORMATION SysPerfInfo;
		static SYSTEM_TIME_INFORMATION        SysTimeInfo;
		static SYSTEM_BASIC_INFORMATION       SysBaseInfo;
		double                                dbIdleTime;
		double                                dbSystemTime;
		LONG				                  status;
		static LARGE_INTEGER                  liOldIdleTime = {0,0};
		static LARGE_INTEGER                  liOldSystemTime = {0,0};

		if(firstTime)
		{
			NtQuerySystemInformation = (PROCNTQSI)GetProcAddress(
												  GetModuleHandle("ntdll"),
												 "NtQuerySystemInformation"
												 );

			if (!NtQuerySystemInformation) return;

			// get number of processors in the system
			status = NtQuerySystemInformation(SystemBasicInformation, &SysBaseInfo, sizeof(SysBaseInfo), NULL);
			if (status != NO_ERROR) return;
		}

		// get new system time
	    status = NtQuerySystemInformation(SystemTimeInformation, &SysTimeInfo, sizeof(SysTimeInfo), 0);
        if (status!=NO_ERROR) return;

        // get new CPU's idle time
        status = NtQuerySystemInformation(SystemPerformanceInformation,&SysPerfInfo,sizeof(SysPerfInfo),NULL);
        if (status != NO_ERROR) return;

        // if it's a first call - skip it
       if(!firstTime)
       {
            // CurrentValue = NewValue - OldValue
            dbIdleTime = Li2Double(SysPerfInfo.liIdleTime) - Li2Double(liOldIdleTime);
            dbSystemTime = Li2Double(SysTimeInfo.liKeSystemTime) - Li2Double(liOldSystemTime);

            // CurrentCpuIdle = IdleTime / SystemTime
            dbIdleTime = dbIdleTime / dbSystemTime;

            // CurrentCpuUsage% = 100 - (CurrentCpuIdle * 100) / NumberOfProcessors
            dbIdleTime = 100.0 - dbIdleTime * 100.0 / (double)SysBaseInfo.bKeNumberProcessors + 0.5;

            m_Value = (UINT)dbIdleTime;
       }

        // store new CPU's idle and system time
        liOldIdleTime = SysPerfInfo.liIdleTime;
        liOldSystemTime = SysTimeInfo.liKeSystemTime;
	}
	else
	{
		// It's a wintendo!
		HKEY hkey;
		DWORD dwDataSize;
		DWORD dwType;
		DWORD dwCpuUsage;

		if(firstTime)
		{
			RegOpenKeyEx(HKEY_DYN_DATA, "PerfStats\\StartStat", 0, KEY_ALL_ACCESS, &hkey); 
		}
		else
		{
			RegOpenKeyEx(HKEY_DYN_DATA, "PerfStats\\StatData", 0, KEY_ALL_ACCESS, &hkey); 
		}
		dwDataSize = sizeof(dwCpuUsage); 
		RegQueryValueEx(hkey, "KERNEL\\CPUUsage", NULL, &dwType, (LPBYTE)&dwCpuUsage, &dwDataSize); 
		RegCloseKey(hkey); 

		m_Value = dwCpuUsage;
		m_CPUFromRegistry = true;
	}

	firstTime = false;
}

/* Alternative way to read the CPU in NT
		static DWORD oldCPU = 0;
		CPerfObject* pPerfObj;
		CPerfObjectInstance* pObjInst;
		CPerfCounter* pPerfCntr;
		BYTE data[256];
		DWORD newValue;

		CPerfSnapshot snapshot( &m_CounterTitles );
		CPerfObjectList objList( &snapshot, &m_CounterTitles );

		snapshot.TakeSnapshot( "Processor" );

		pPerfObj = objList.GetPerfObject("Processor");
		pObjInst = pPerfObj->GetFirstObjectInstance();
		pPerfCntr = pObjInst->GetCounterByName("% Processor Time");
		pPerfCntr->GetData(data, 256, NULL);

		newValue = *(DWORD*)data;
		if(!firstTime) 
		{
			m_Value = 100 - (newValue - oldCPU) / 100000;
			m_Value = min(100, m_Value);
			m_Value = max(0, m_Value);
		}
		oldCPU = newValue;

		delete pPerfCntr;
		delete pObjInst;
		delete pPerfObj;

*/