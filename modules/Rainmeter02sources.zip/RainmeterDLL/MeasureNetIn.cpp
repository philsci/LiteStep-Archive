/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeasureNetIn.h"

CMeasureNetIn::CMeasureNetIn() : CMeasureNet()
{
	m_NetInSpeed = 1;
}

CMeasureNetIn::~CMeasureNetIn()
{
}

void CMeasureNetIn::Update(CMeterWindow& meterWindow)
{
	static bool firstTime = true;
	static int counter = 1;
	static DWORD inOctets;
	int i;

	UpdateTable(counter++);

	if(m_Table == NULL) return;

	if(!firstTime) 
	{
		m_Value = 0;
		for(i = 0; i < m_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)m_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				m_Value += m_Table->table[i].dwInOctets;
			}
		}
		DWORD tmpValue = m_Value;
		m_Value -= inOctets;
		inOctets = tmpValue;
		m_Value *= 8;
	}
	else
	{
		inOctets = 0;
		for(i = 0; i < m_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)m_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				inOctets += m_Table->table[i].dwInOctets;
			}
		}

		firstTime = false;
	}
}

void CMeasureNetIn::ReadConfig(const char* filename, const char* section)
{
	m_NetInSpeed = GetPrivateProfileInt(section, "NetInSpeed", 1, filename);
}
