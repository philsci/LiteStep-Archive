/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeasureMemory.h"

CMeasureMemory::CMeasureMemory() : CMeasure()
{
}

CMeasureMemory::~CMeasureMemory()
{
}

void CMeasureMemory::Update(CMeterWindow& meterWindow)
{
	MEMORYSTATUS stat;

	GlobalMemoryStatus(&stat);
	m_Value = stat.dwTotalPageFile + stat.dwTotalPhys - stat.dwAvailPageFile - stat.dwAvailPhys;
}

int CMeasureMemory::GetDefaultMaxValue()
{
	MEMORYSTATUS stat;

	GlobalMemoryStatus(&stat);
	return stat.dwTotalPageFile + stat.dwTotalPhys;
}

/* Alternative way to read the allocated mem in NT

	CPerfObject* pPerfObj;
	CPerfObjectInstance* pObjInst;
	CPerfCounter* pPerfCntr;
	BYTE data[256];

	CPerfSnapshot snapshot( &m_CounterTitles );
	CPerfObjectList objList( &snapshot, &m_CounterTitles );

	snapshot.TakeSnapshot( "Memory" );

	pPerfObj = objList.GetPerfObject("Memory");
	pObjInst = pPerfObj->GetFirstObjectInstance();
	pPerfCntr = pObjInst->GetCounterByName("% Committed Bytes In Use");
	pPerfCntr->GetData(data, 256, NULL);

	m_Value = *(DWORD*)data;
	m_Value /= 1000;

	delete pPerfCntr;
	delete pObjInst;
	delete pPerfObj;
*/
