/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "Error.h"
#include "Meter.h"
#include "MeasureCPU.h"
#include "MeasureMemory.h"
#include "MeasurePhysicalMemory.h"
#include "MeasureVirtualMemory.h"
#include "MeasureNetIn.h"
#include "MeasureNetOut.h"

CMeter::CMeter()
{
	m_Measure = NULL;
	m_X = 0;
	m_Y = 0;
	m_W = 0;
	m_H = 0;
}

CMeter::~CMeter()
{
	delete m_Measure;
}

void CMeter::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// This one reads the common configs for all meters

	m_X = GetPrivateProfileInt(section, "X", 0, filename);
	m_Y = GetPrivateProfileInt(section, "Y", 0, filename);
	m_W = GetPrivateProfileInt(section, "W", 0, filename);
	m_H = GetPrivateProfileInt(section, "H", 0, filename);

	if(GetPrivateProfileString(section, "Measure", "", tmpSz, 255, filename) > 0) 
	{
		m_Measure = CreateMeasure(tmpSz);
		if(m_Measure) m_Measure->ReadConfig(filename, section);
	}

	if(m_W == 0 || m_H == 0)
	{
		std::string errorSz;
		errorSz = "The meter ";
		errorSz += section;
		errorSz += " has zero dimensions.";
		CError::SetError(errorSz, __LINE__, __FILE__);
		throw true;
	}
}

CMeasure* CMeter::CreateMeasure(const char* measure)
{
	// Comparson is caseinsensitive

	if(_stricmp("", measure) == 0)
	{
		return NULL;
	}
	else if(_stricmp("CPU", measure) == 0)
	{
		return new CMeasureCPU;
	} 
	else if(_stricmp("Memory", measure) == 0)
	{
		return new CMeasureMemory;
	}
	else if(_stricmp("NetIn", measure) == 0)
	{
		return new CMeasureNetIn;
	}
	else if(_stricmp("NetOut", measure) == 0)
	{
		return new CMeasureNetOut;
	}
	else if(_stricmp("PhysicalMemory", measure) == 0)
	{
		return new CMeasurePhysicalMemory;
	}
	else if(_stricmp("SwapMemory", measure) == 0)
	{
		return new CMeasureVirtualMemory;
	}

	std::string errorSz("No such measure: ");
	errorSz += measure;
	CError::SetError(errorSz, __LINE__, __FILE__);
	throw true;

	return NULL;
}

void CMeter::Update(CMeterWindow& meterWindow)
{
	if(m_Measure)
	{
		m_Measure->Update(meterWindow);
	}
}

