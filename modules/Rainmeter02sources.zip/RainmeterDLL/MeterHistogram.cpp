/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeterHistogram.h"
#include "Measure.h"
#include <lsapi\lsapi.h>

CMeterHistogram::CMeterHistogram() : CMeter()
{
	m_SecondaryMeasure = NULL;
	m_PrimaryColor = 0;
	m_SecondaryColor = 0;
	m_BothColor = 0;
	m_MaxPrimaryValue = 0;
	m_MaxSecondaryValue = 0;
	m_HistogramBitmap = NULL;
	m_MeterPos = 0;
	m_PrimaryPen = NULL;
	m_SecondaryPen = NULL;
	m_BothPen = NULL;
	m_TransparentPen = NULL;
}

CMeterHistogram::~CMeterHistogram()
{
	delete m_SecondaryMeasure;

	DeleteObject(m_HistogramBitmap);
	DeleteObject(m_PrimaryPen);
	DeleteObject(m_SecondaryPen);
	DeleteObject(m_BothPen);
	DeleteObject(m_TransparentPen);
}

void CMeterHistogram::Initialize(CMeterWindow& meterWindow)
{
	RECT rect;
	rect.left = 0;
	rect.right = m_W;
	rect.top = 0;
	rect.bottom = m_H;

	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);

	// Create the bitmap for the Histogram graph
	m_HistogramBitmap = CreateCompatibleBitmap(bufferDC, m_W, m_H);

	// Fill it with pink so it'll be transparent
	HBRUSH brush = CreateSolidBrush( RGB(255, 0, 255) );
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
	FillRect(tmpDC, &rect, brush);

	m_PrimaryPen = CreatePen(PS_SOLID, 0, m_PrimaryColor);
	m_SecondaryPen = CreatePen(PS_SOLID, 0, m_SecondaryColor);
	m_BothPen = CreatePen(PS_SOLID, 0, m_BothColor);
	m_TransparentPen = CreatePen(PS_SOLID, 0, RGB(255, 0, 255));

	DeleteObject(brush);
	SelectObject(tmpDC, oldBM);
	DeleteObject(tmpDC);
}

void CMeterHistogram::ReadConfig(const char* filename, const char* section)
{
	char tmpSz[256];

	// Read common configs
	CMeter::ReadConfig(filename, section);

	// Read configs for Histogram meter
	if(GetPrivateProfileString(section, "PrimaryColor", "0, 255, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_PrimaryColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "SecondaryColor", "255, 0, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_SecondaryColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "BothColor", "255, 255, 0", tmpSz, 255, filename) > 0) 
	{
		int R, G, B;
		sscanf(tmpSz, "%i, %i, %i", &R, &G, &B);
		m_BothColor = RGB(R, G, B);
	}

	if(GetPrivateProfileString(section, "SecondaryMeasure", "", tmpSz, 255, filename) > 0) 
	{
		m_SecondaryMeasure = CreateMeasure(tmpSz);
		if(m_SecondaryMeasure) m_SecondaryMeasure->ReadConfig(filename, section);
	}

	if(m_Measure) m_MaxPrimaryValue = m_Measure->GetDefaultMaxValue();
	if(m_SecondaryMeasure) m_MaxSecondaryValue = m_SecondaryMeasure->GetDefaultMaxValue();
}

void CMeterHistogram::Update(CMeterWindow& meterWindow)
{
	int primaryValue = 0;
	int secondaryValue = 0;

	CMeter::Update(meterWindow);

	if(m_SecondaryMeasure)
	{
		m_SecondaryMeasure->Update(meterWindow);
	}

	// Update the graph as well
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HDC tmpDC = CreateCompatibleDC(bufferDC);
	HBITMAP oldBM = (HBITMAP)SelectObject(tmpDC, m_HistogramBitmap);
	HPEN oldPen = (HPEN)SelectObject(tmpDC, m_BothPen);

	// Draw a line
	int X = m_MeterPos;
	int Y = m_H;
	MoveToEx(tmpDC, X, Y, NULL);

	primaryValue = m_H * ((double)m_Measure->GetValue() / (double)m_MaxPrimaryValue);
	primaryValue = min(m_H, primaryValue);

	if(m_SecondaryMeasure)
	{
		secondaryValue = m_H * ((double)m_SecondaryMeasure->GetValue() / (double)m_MaxSecondaryValue);
		secondaryValue = min(m_H, secondaryValue);

		Y = max( m_H - primaryValue, m_H - secondaryValue);
		LineTo(tmpDC, X, Y);

		if(primaryValue < secondaryValue) 
		{
			SelectObject(tmpDC, m_SecondaryPen);
			Y = m_H - secondaryValue;
		} 
		else 
		{
			SelectObject(tmpDC, m_PrimaryPen);
			Y = m_H - primaryValue;
		}
	}
	else
	{
		SelectObject(tmpDC, m_PrimaryPen);
		Y = m_H - primaryValue;
	}
	LineTo(tmpDC, X, Y);

	SelectObject(tmpDC, m_TransparentPen);
	Y = 0;
	LineTo(tmpDC, X, Y);

	m_MeterPos++;
	m_MeterPos %= m_W;

	Paint(meterWindow, tmpDC);

	SelectObject(tmpDC, oldBM);
	SelectObject(tmpDC, oldPen);
	DeleteObject(tmpDC);
}

void CMeterHistogram::Paint(CMeterWindow& meterWindow, HDC dc)
{
	HDC bufferDC = meterWindow.GetDoubleBuffer();
	HBITMAP oldBM = (HBITMAP)SelectObject(dc, m_HistogramBitmap);

	// Blit the graph in two phases so that we'll get scrolling

	if(m_MeterPos > 0) 
	{
		TransparentBltLS(bufferDC,
						 m_X + m_W - m_MeterPos,
						 m_Y,
						 m_MeterPos,
						 m_H,
						 dc,
						 0,
						 0,
						 RGB(255,0,255));
	}

	if(m_MeterPos < m_W) 
	{
		TransparentBltLS(bufferDC,
						 m_X,
						 m_Y,
						 m_W - m_MeterPos,
						 m_H,
						 dc,
						 m_MeterPos,
						 0,
						 RGB(255,0,255));
	}

	SelectObject(dc, oldBM);
}
