/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __ERROR_H__
#define __ERROR_H__

#include <windows.h>
#include <string>

class CError
{
public:
	// Few predefined errors
	enum RAINERROR 
	{
		ERROR_USER,
		ERROR_OUT_OF_MEM,
		ERROR_NULL_PARAMETER,
		ERROR_REGISTER_WINDOWCLASS,
		ERROR_CREATE_WINDOW
	};

	static const std::string& GetString(); 

	static void SetError(const std::string& String) { c_Error = ERROR_USER; c_String = String; };
	static void SetError(const char* String ) { c_Error = ERROR_USER; c_String = String; };

	static void SetError(const std::string& String, int Line, const char* File) { c_Error = ERROR_USER; c_String = String; c_Line = Line; c_File = File; };
	static void SetError(const char* String, int Line, const char* File) { c_Error = ERROR_USER; c_String = String; c_Line = Line; c_File = File; };

	static void SetError(CError::RAINERROR Error) { c_Error = Error; c_File = NULL; };
	static void SetError(CError::RAINERROR Error, int Line, const char* File) { c_Error = Error; c_Line = Line; c_File = File; };

private:
	static std::string c_String;
	static int c_Line;
	static const char* c_File;
	static RAINERROR c_Error;

	static const char* c_ErrorStrings[];
};

#endif
