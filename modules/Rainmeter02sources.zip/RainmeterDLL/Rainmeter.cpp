/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "Rainmeter.h"
#include "Error.h"
#include <assert.h>

CRainmeter* Rainmeter; // The module

bool CRainmeter::c_DummyLitestep=false;
LPCSTR CRainmeter::c_CmdLine=NULL;

/* 
** Interface to Litestep
*/

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	int Result=1;
	
	try {
		Rainmeter=new CRainmeter;

		if(Rainmeter) {
			Result=Rainmeter->Initialize(ParentWnd, dllInst, wd, NULL);
		}

	} catch(bool) {
		MessageBox(ParentWnd, CError::GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return Result;
}


void quitWharfModule(HINSTANCE dllInst)
{
	quitModule(dllInst);
}

HRGN getLSRegion(int xOffset, int yOffset)
{
	if(Rainmeter) return Rainmeter->GetRegion(xOffset, yOffset);

	return NULL;
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int Result=1;
	
	try {
		Rainmeter=new CRainmeter;

		if(Rainmeter) {
			Result=Rainmeter->Initialize(ParentWnd, dllInst, NULL, szPath);
		}

	} catch(bool) {
		MessageBox(ParentWnd, CError::GetString().c_str(), APPNAME, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);
	}

	return Result;
}

void quitModule(HINSTANCE dllInst)
{
	if(Rainmeter) {
		Rainmeter->Quit(dllInst);
		delete Rainmeter;
		Rainmeter=NULL;
	}
}

void Initialize(bool DummyLS, LPCSTR CmdLine)
{
	CRainmeter::SetDummyLitestep(DummyLS);
	CRainmeter::SetCommandLine(CmdLine);

}


extern "C" DLLDECL void RainmeterHide(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Hide();
}

extern "C" DLLDECL void RainmeterShow(HWND, const char* arg)
{
	if(Rainmeter) Rainmeter->Show();
}

/* 
** CRainmeter
**
** Constructor
**
*/
CRainmeter::CRainmeter()
{
	m_Wharf=false;
}

/* 
** ~CRainmeter
**
** Destructor
**
*/
CRainmeter::~CRainmeter()
{
}

/* 
** Initialize
**
** The main initialization function for the module.
** May throw CErrors !!!!
**
*/
int CRainmeter::Initialize(HWND Parent, HINSTANCE Instance, wharfDataType* wd, LPCSTR szPath)
{
	int Result=0;

	if(Parent==NULL || Instance==NULL) {
		CError::SetError(CError::ERROR_NULL_PARAMETER, __LINE__, __FILE__);
		throw true;
	}	

	if(wd!=NULL) {
		// Started as Wharf-module
		m_Wharf=true;
	} else {
		// Started as loadmodule
		m_Wharf=false;
	}

	// Create the meter
	Result = m_Meter.Initialize(*this, Parent, Instance);

	if(!c_DummyLitestep) 
	{
		AddBangCommand("!RainmeterHide", RainmeterHide);
		AddBangCommand("!RainmeterShow", RainmeterShow);
	}

	return Result;	// Alles OK
}

/* 
** Quit
**
** Called when the module quits
**
*/
void CRainmeter::Quit(HINSTANCE dllInst)
{
	if(!c_DummyLitestep) {
		RemoveBangCommand("!RainmeterHide");
		RemoveBangCommand("!RainmeterShow");
	}
}

/* 
** GetRegion
**
** Function returns the window region for the Wharf
**
*/
HRGN CRainmeter::GetRegion(int xOffset, int yOffset)
{
	return NULL;
}

/* 
** SetDummyLitestep
**
** 
**
*/
void CRainmeter::SetDummyLitestep(bool Dummy)
{
	c_DummyLitestep=Dummy;
}

/* 
** SetCommandLine
**
** 
**
*/
void CRainmeter::SetCommandLine(LPCSTR CmdLine)
{
	c_CmdLine=CmdLine;
}

/* 
** GetCommandLine
**
** 
**
*/
LPCSTR CRainmeter::GetCommandLine()
{
	return c_CmdLine;
}

