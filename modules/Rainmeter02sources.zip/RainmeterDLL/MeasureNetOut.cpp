/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "MeasureNetOut.h"

CMeasureNetOut::CMeasureNetOut() : CMeasureNet()
{
	m_NetOutSpeed = 1;
}

CMeasureNetOut::~CMeasureNetOut()
{
}

void CMeasureNetOut::Update(CMeterWindow& meterWindow)
{
	static bool firstTime = true;
	static int counter = 1;
	static DWORD outOctets;
	int i;

	UpdateTable(counter++);

	if(m_Table == NULL) return;

	if(!firstTime) 
	{
		m_Value = 0;
		for(i = 0; i < m_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)(m_Table->table[i].bDescr), "MS TCP Loopback interface") != 0)
			{
				m_Value += m_Table->table[i].dwOutOctets;
			}
		}
		DWORD tmpValue = m_Value;
		m_Value -= outOctets;
		outOctets = tmpValue;
		m_Value *= 8;
	}
	else
	{
		outOctets = 0;
		for(i = 0; i < m_NumOfTables; i++)
		{
			// Ignore the loopback
			if(strcmp((char*)m_Table->table[i].bDescr, "MS TCP Loopback interface") != 0)
			{
				outOctets += m_Table->table[i].dwOutOctets;
			}
		}

		firstTime = false;
	}
}

void CMeasureNetOut::ReadConfig(const char* filename, const char* section)
{
	m_NetOutSpeed = GetPrivateProfileInt(section, "NetOutSpeed", 1, filename);
}
