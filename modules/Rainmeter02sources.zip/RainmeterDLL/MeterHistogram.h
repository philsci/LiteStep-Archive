/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __METERHISTOGRAM_H__
#define __METERHISTOGRAM_H__

#include "Meter.h"
#include "MeterWindow.h"

class CMeterHistogram : public CMeter
{
public:
	CMeterHistogram();
	virtual ~CMeterHistogram();

	virtual void ReadConfig(const char* filename, const char* section);
	virtual void Initialize(CMeterWindow& meterWindow);
	virtual void Update(CMeterWindow& meterWindow);

private:
	void Paint(CMeterWindow& meterWindow, HDC dc);

	CMeasure* m_SecondaryMeasure;
	COLORREF m_PrimaryColor;
	COLORREF m_SecondaryColor;
	COLORREF m_BothColor;
	int m_MaxPrimaryValue;
	int m_MaxSecondaryValue;

	HBITMAP m_HistogramBitmap;
	int m_MeterPos;
	HPEN m_PrimaryPen;
	HPEN m_SecondaryPen;
	HPEN m_BothPen;
	HPEN m_TransparentPen;
};

#endif
