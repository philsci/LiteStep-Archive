/*
  Copyright (C) 2001 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "resource.h"
#include <lsapi\lsapi.h>
#include "RainmeterDLL\Rainmeter.h"

/*
** Protos
*/
BOOL InitApplication(HINSTANCE hInstance, const char* WinClass);
HWND InitInstance(HINSTANCE hInstance, const char* WinClass, const char* WinName);
LONG APIENTRY MainWndProc(HWND, UINT, UINT, LONG);
BOOL AddTrayIcon(HINSTANCE hInstance, HWND hWnd);
BOOL RemoveTrayIcon(HWND hWnd);

/*
** Stuff from the DLL
*/
extern "C" DLLDECL int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR);
extern "C" DLLDECL void quitModule(HINSTANCE dllInst);
extern "C" DLLDECL void Initialize(bool DummyLS, LPCSTR CmdLine);
extern "C" DLLDECL void RainmeterHide(HWND, const char* arg);
extern "C" DLLDECL void RainmeterShow(HWND, const char* arg);
extern "C++" CRainmeter* Rainmeter;


// Notification from trayicon
#define MYWM_NOTIFYICON WM_USER

/*
** Globals
*/
static HMENU g_Menu=NULL;

/* 
** WinMain
**
** The Main-function
**
*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	char* WinClass=NULL;
	char* WinName=NULL;
	HWND hWnd;

	// If Litestep is not running disquise this window as Litestep so that LoadBitmap works
	if(NULL==GetLitestepWnd()) 
	{
		WinClass="TApplication";
		WinName="LiteStep";
	} else {
		WinClass="DummyRainWClass";
		WinName="Rainmeter control window";
	}

	if(!hPrevInstance) {
		if (!InitApplication(hInstance, WinClass)) return FALSE;
	}

	hWnd=InitInstance(hInstance, WinClass, WinName);
	if(!hWnd) return FALSE;

	// Create the traymenu
//	g_Menu=LoadMenu(hInstance, MAKEINTRESOURCE(IDR_TRAYMENU));
//	AddTrayIcon(hInstance, hWnd);

	// Initialize from exe
	Initialize(true, lpCmdLine);

	LitestepAPIInit();

	// Initialize the DLL
	initModuleEx(hWnd, hInstance, NULL);

	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg); 
	} 

	return msg.wParam; 
} 

/* 
** InitApplication
**
** Creates the windowclass
**
*/
BOOL InitApplication(HINSTANCE hInstance, const char* WinClass)
{
	WNDCLASS  wc;

	wc.style = 0;
	wc.lpfnWndProc = (WNDPROC) MainWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, MAKEINTRESOURCE(IDI_RAINMETER));
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH); 
	wc.lpszMenuName =  NULL;
	wc.lpszClassName = WinClass;

	return RegisterClass(&wc);
}


/* 
** InitInstance
**
** Creates the window
**
*/
HWND InitInstance(HINSTANCE hInstance, const char* WinClass, const char* WinName)
{
	return CreateWindowEx(
		WS_EX_TOOLWINDOW,
		WinClass,
		WinName,
		WS_POPUP,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		hInstance,
		NULL
	);
}

/* 
** AddTrayIcon
**
** Adds the trayicon
**
*/
BOOL AddTrayIcon(HINSTANCE hInstance, HWND hWnd) 
{ 
    BOOL res; 
    NOTIFYICONDATA tnid; 
 
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = hWnd; 
    tnid.uID = IDI_RAINMETER; 
    tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
    tnid.uCallbackMessage = MYWM_NOTIFYICON; 
    tnid.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_RAINMETER));
    lstrcpyn(tnid.szTip, "Rainmeter", sizeof(tnid.szTip)); 
 
    res = Shell_NotifyIcon(NIM_ADD, &tnid); 
 
    return res; 
}

/* 
** RemoveTrayIcon
**
** Removes the trayicon
**
*/
BOOL RemoveTrayIcon(HWND hWnd) 
{ 
    BOOL res; 
    NOTIFYICONDATA tnid; 
 
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = hWnd; 
    tnid.uID = IDI_RAINMETER; 
         
    res = Shell_NotifyIcon(NIM_DELETE, &tnid); 

    return res; 
} 


/* 
** MainWndProc
**
** The main window procedure
**
*/
LONG APIENTRY MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam)
{
	switch(message) {

	case WM_DESTROY:
		{
			quitModule(NULL);
			if(g_Menu) DestroyMenu(g_Menu);
			RemoveTrayIcon(hWnd);
			PostQuitMessage(0);
		}
		break;

	case MYWM_NOTIFYICON:
		{
			UINT uID; 
			UINT uMouseMsg; 
 
			uID = (UINT) wParam; 
			uMouseMsg = (UINT) lParam; 
 
			if(g_Menu) {
				HMENU SubMenu=GetSubMenu(g_Menu, 0);
				SetMenuDefaultItem(SubMenu, 0, TRUE);
				if(SubMenu) {
					if (uMouseMsg == WM_LBUTTONDBLCLK) {
						SendMessage(hWnd, WM_COMMAND, GetMenuItemID(SubMenu, 0), 0);
					} else if(uMouseMsg == WM_RBUTTONDOWN) {
						POINT Point;
						GetCursorPos(&Point);
						TrackPopupMenu(SubMenu, TPM_RIGHTBUTTON | TPM_RIGHTALIGN | TPM_BOTTOMALIGN, Point.x, Point.y, 0, hWnd, NULL);
 					}
				}
			}
		}
		break;

	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case ID_TRAYMENU_QUIT:
				DestroyWindow(hWnd);
				break;

			case ID_TRAYMENU_REFRESH:
				quitModule(NULL);
				initModuleEx(hWnd, (HINSTANCE)GetWindowLong(hWnd, GWL_HINSTANCE), NULL);
				break;

			case ID_TRAYMENU_HIDE:
				RainmeterHide(hWnd, NULL);
				break;

			case ID_TRAYMENU_SHOW:
				RainmeterShow(hWnd, NULL);
				break;

			}
		}
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}
