#include <windows.h>
#include <stdio.h>
#include "resource.h"

// Function Prototypes
BOOL CALLBACK DialogProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void DrawIt();

// Globals
char* AppName = "TrueColorsMainWindow";
char temp[5] = "";
char imagename[MAX_PATH] = "";
HINSTANCE hinst;
HWND hwndMain; 
HWND channel;
HBITMAP deskbmp;
COLORREF color = 0x0000FF00;
HWND sx, sy, xoff, yoff;
DWORD OldFileSize;
int x = 4, y = 25;
int bmpx=1024, bmpy=768;

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg; 
    UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;  // save instance handle 
  
	GetProfileString("TrueColors", "Background", "", imagename, MAX_PATH);
	bmpx = GetProfileInt("TrueColors", "BGx", 1024);
	bmpy = GetProfileInt("TrueColors", "BGy", 768);

	channel = FindWindow("channel", NULL);
	deskbmp = LoadImage(NULL, imagename, IMAGE_BITMAP, bmpx, bmpy, LR_LOADFROMFILE);

	hwndMain = CreateDialog(hinst, MAKEINTRESOURCE(IDD_TRUE_COLORS), NULL,  DialogProc);
	sx = GetDlgItem(hwndMain, IDC_SCROLLX);
	sy = GetDlgItem(hwndMain, IDC_SCROLLY);
	xoff = GetDlgItem(hwndMain, IDC_OFFSETX);
	yoff = GetDlgItem(hwndMain, IDC_OFFSETY);
	sprintf(temp, "%d", x);
	SetWindowText(xoff, temp);
	sprintf(temp, "%d", y);
	SetWindowText(yoff, temp);

	SetTimer(hwndMain, 0, 25, NULL);

    while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg);
	} 
 
    KillTimer(hwndMain, 0);
 
    return msg.wParam; 
} 

BOOL CALLBACK DialogProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;
		case WM_VSCROLL:
		{
			HWND sb = (HWND)lParam;
			switch (LOWORD(wParam))
			{
				case SB_LINEDOWN:
				{
					if (sb == sx) { sprintf(temp, "%d", --x); SetWindowText(xoff, temp); }		
					else if (sb == sy) { sprintf(temp, "%d", --y); SetWindowText(yoff, temp); }
					DrawIt();
				}
				return TRUE;
				case SB_LINEUP:
				{
					if (sb == sx) { sprintf(temp, "%d", ++x); SetWindowText(xoff, temp); }		
					else if (sb == sy) { sprintf(temp, "%d", ++y); SetWindowText(yoff, temp); }
					DrawIt();
				}
				return TRUE;
			}
		}
		break;
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDB_CHANGE_MASK:
				{
					if (color == 0x0000FF00) color = 0x00FF0000;
					else if (color == 0x00FF0000) color = 0x000000FF;
					else if (color == 0x000000FF) color = 0x00FF00FF;
					else if (color == 0x00FF00FF) color = 0x0000FFFF;
					else if (color == 0x0000FFFF) color = 0x00FFFF00;
					else if (color == 0x00FFFF00) color = 0x00FF0000;

					DrawIt();
				}
				return TRUE;
			}
		}
		break;
		case WM_TIMER:
		{
			RECT r;
			GetWindowRect(channel, &r);
			if (GetPixel(GetDC(channel), 0, 0) == 0x00FF00FF) DrawIt();
		}
		return TRUE;
	}
    return FALSE;
}

void DrawIt()
{
	HDC channeldc = GetDC(channel);
	HDC desktopdc = CreateCompatibleDC(NULL);
	HDC buf = CreateCompatibleDC(NULL);
	HDC buf2 = CreateCompatibleDC(NULL);
	HDC mask = CreateCompatibleDC(NULL);
	HDC trans = CreateCompatibleDC(NULL);
	HBITMAP bufbmp, buf2bmp;
	HBITMAP maskbmp;
	HBITMAP transbmp;
	HBRUSH hbr = CreateSolidBrush(color);
	RECT wr, cr;

	GetWindowRect(channel, &wr);
	GetClientRect(channel, &cr);
	bufbmp = CreateCompatibleBitmap(channeldc, cr.right, cr.bottom);
	buf2bmp = CreateCompatibleBitmap(channeldc, cr.right, cr.bottom);
	maskbmp = CreateCompatibleBitmap(channeldc, cr.right, cr.bottom);
	transbmp = CreateBitmap( cr.right, cr.bottom, 1, 1, NULL );
	SelectObject(buf, bufbmp);
	SelectObject(buf2, buf2bmp);
	SelectObject(desktopdc, deskbmp);
	SelectObject(mask, maskbmp);
	SelectObject(trans, transbmp);
	FillRect(mask, &cr, hbr);
				
	BitBlt(buf, 0, 0, cr.right, cr.bottom, channeldc, cr.left, cr.top, SRCCOPY);
	SetBkColor(buf, RGB(255,0,255));
	BitBlt( trans, 0, 0, cr.right, cr.bottom, buf, 0, 0, SRCCOPY );
	SetBkColor( buf, RGB(0,0,0) );
	SetTextColor( buf, RGB(255,255,255) );
	BitBlt( buf, 0, 0, cr.right, cr.bottom, trans, 0, 0, SRCAND );
	SetBkColor( buf2, RGB(255,255,255) );
	SetTextColor( buf2, RGB(0,0,0) );
	BitBlt(buf2, 0, 0, cr.right, cr.bottom, desktopdc, wr.left+x, wr.top+y, SRCCOPY);
	BitBlt(buf2, 0, 0, cr.right, cr.bottom, mask, 0, 0, SRCAND);
	BitBlt( buf2, 0, 0, cr.right, cr.bottom, trans, 0, 0, SRCAND );
	BitBlt( buf2, 0, 0, cr.right, cr.bottom, buf, 0, 0, SRCPAINT);
	BitBlt(channeldc, 0, 0, cr.right, cr.bottom, buf2, 0, 0, SRCCOPY);

	ReleaseDC(channel, channeldc);
	DeleteDC(buf);
	DeleteDC(buf2);
	DeleteDC(desktopdc);
	DeleteDC(mask);
	DeleteDC(trans);
	DeleteObject(bufbmp);
	DeleteObject(buf2bmp);
	DeleteObject(maskbmp);
	DeleteObject(transbmp);
	DeleteObject(hbr);
}
