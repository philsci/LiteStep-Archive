
This Wharf module will run your current Windows screen saver in a Wharf 
module window.  Add the following to STEP.RC to enable it:

*Wharf "Modsaver" .none @c:\litestep\modsaver.dll

This module is free for all to distribute.  Share and enjoy.


Andy Rudnitsky 	-- rudnitsky@voyager.net -- Netwalker on #litestep