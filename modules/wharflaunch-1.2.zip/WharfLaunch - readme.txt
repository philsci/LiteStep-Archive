////////////////////////
// WharfLaunch V1.2
// By: MrJukes
// Released: 11/3/98

// V1.2
	- Hopefully finally fixed the number 9 problem

// V1.1
	- Fixed the number 9 problem
	- Made it so bmps line up side by side, so if grid is off, there
	  is no space left between them. 

// Installation
        1) Unzip WharfLaunch.app to your Litestep directory
        2) Put the normal *Wharf line in your step.rc
                *Wharf "WharfLaunch" default.bmp @c:\litestep\WharfLaunch.app
        3) Refresh Litestep

// Modules.ini
        
        [WharfLaunch]

        // Don't touch this (internal use only)
        HaveRun=1       

        // Whether or not to highlight after being clicked
        HighLight=1

        // The color of the highlight (Format: 0x00BBGGRR)
        HighLightColor=0x00000000
        
        // Whether ot not to show the grid
        Grid=1

        // Color of the grid (Format: 0x00BBGGRR)
        GridColor=0x00000000

        // Path to executable
        Program1=c:\program files\netscape\communicator\program\netscape.exe -mail      

        // Path to bitmap you want to show in square 1 (Absolute, not relative)
        Bitmap1=c:\litestep\images\netscape.bmp 

        // etc..
        Program2=       
        Bitmap2=
        Program3=
        Bitmap3=
        Program4=
        Bitmap4=
        Program5=
        Bitmap5=        
        Program6=
        Bitmap6=
        Program7=
        Bitmap7=
        Program8=
        Bitmap8=
        Program9=
	Bitmap9=

Have fun,
        MrJukes
	mrjukes@litestep.net
