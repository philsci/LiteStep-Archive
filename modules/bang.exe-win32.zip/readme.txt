bang.exe by azathoth 2000

this is just a win32 version of the !.exe program written by maduin (maduin@dasoft.org)....

syntax: bang.exe !about

runs bang commands on a command line prompt...
well, i dunno, tnl wanted it so i wrote it up...

later everyone
azathoth

http://www.intricatechaos.com/ & http://www.ls2k.org/
mailto:azathoth@itnricatechaos.com
icq: 25810657