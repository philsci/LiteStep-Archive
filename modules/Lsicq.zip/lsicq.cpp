#include <windows.h>
#include "exports.h"
#include <commctrl.h>
#include "ICQAPIInterface.h"
#include "lsapi.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();

void WINAPI ListChange(int iType);

void BangSetStateOnline(HWND caller, char* args);
void BangSetStateChat(HWND caller, char* args);
void BangSetStateAway(HWND caller, char* args);
void BangSetStateNA(HWND caller, char* args);
void BangSetStateOccupied(HWND caller, char* args);
void BangSetStateDND(HWND caller, char* args);
void BangSetStateInvisible(HWND caller, char* args);
void BangSetStateOffline(HWND caller, char* args);

HWND hwndMain;
int ScreenX, ScreenY;
char* szAppName = "LSICQ";
int X, Y, W, H, ENTRY_HEIGHT=16;

int USER_COUNT=0;
int ICQ_VERSION=0;

HBITMAP IMAGE_TOP, IMAGE_BOT, IMAGE_ENTRY, IMAGE_SELENTRY;
BPSICQAPI_User* USER_LIST;
HWND ICQ_LIST=NULL;
int CURRENT_MOUSE=-1;

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	
	if (!ICQAPICall_SetLicenseKey("Bret", "suckit00", "AAAD67AA91AAC1BA")) return 1;

	if (!ICQAPICall_GetVersion(ICQ_VERSION))
	{
		char icqpath[MAX_PATH] = "";
		char cd[MAX_PATH] = "";
		STARTUPINFO si;
		PROCESS_INFORMATION pi;

		GetRCString("LSICQICQDirectory", icqpath, "c:\\program files\\icq", MAX_PATH);
		GetCurrentDirectory(MAX_PATH, cd);
		SetCurrentDirectory(icqpath);
		memset(&si, 0, sizeof(si)); 
		si.cb = sizeof(si); 
		if (CreateProcess(NULL, "icq.exe", NULL, NULL, TRUE, 0, NULL, icqpath, &si, &pi))
		{
			while (!ICQAPICall_GetVersion(ICQ_VERSION));
		}
		SetCurrentDirectory(cd);
	}

	ICQAPICall_GetOnlineListDetails(USER_COUNT, &USER_LIST);
	for (int x=0; x < USER_COUNT; x++)
	{
		ICQAPICall_GetFullUserData(USER_LIST[x], ICQ_VERSION);
	}

	LoadSetup();

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	wc.style = CS_DBLCLKS;
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
    
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	X = GetRCInt("LSICQX", 0);
	Y = GetRCInt("LSICQY", 0);
	W = GetRCInt("LSICQWidth", 200);
	H = GetRCInt("LSICQHeight", (USER_COUNT*ENTRY_HEIGHT) + ENTRY_HEIGHT*2);
	
	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, X, Y, W, H, NULL, NULL, dllInst, 0);
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);
	
	RemoveBangCommand("!LSICQOnline");
	RemoveBangCommand("!LSICQChat");
	RemoveBangCommand("!LSICQAway");
	RemoveBangCommand("!LSICQNA");
	RemoveBangCommand("!LSICQOccupied");
	RemoveBangCommand("!LSICQDND");
	RemoveBangCommand("!LSICQInvisible");
	RemoveBangCommand("!LSICQOffline");

	ICQAPIUtil_FreeUsers(USER_COUNT, USER_LIST);

	DeleteObject(IMAGE_TOP);
	DeleteObject(IMAGE_BOT);
	DeleteObject(IMAGE_ENTRY);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCHITTEST: 
		{
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			RECT r;

			GetWindowRect(hwnd, &r);
			x -= r.left;
			y -= r.top;

			if (x < 8 || x > W-8 || y < 9 || y > H-9) return HTCAPTION;
			else return HTCLIENT;
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, W, H);
			HBITMAP oldbuf, oldsrc;
			RECT r;

			SetTextColor(buf, 0x00FFFFFF);
			SetBkMode(buf, TRANSPARENT);

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrc = (HBITMAP)SelectObject(src, IMAGE_TOP);
			BitBlt(buf, 0, 0, W, ENTRY_HEIGHT, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrc);

			oldsrc = (HBITMAP)SelectObject(src, IMAGE_BOT);
			BitBlt(buf, 0, (USER_COUNT*ENTRY_HEIGHT)+ENTRY_HEIGHT, W, ENTRY_HEIGHT, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrc);

			for (int x=0; x<USER_COUNT; x++)
			{
				if (x == CURRENT_MOUSE) oldsrc = (HBITMAP)SelectObject(src, IMAGE_SELENTRY);
				else oldsrc = (HBITMAP)SelectObject(src, IMAGE_ENTRY);
				BitBlt(buf, 0, (x+1)*ENTRY_HEIGHT, W, ENTRY_HEIGHT, src, 0, 0, SRCCOPY);
				SelectObject(src, oldsrc);

				SetRect(&r, 15, ENTRY_HEIGHT*(x+1), W-15, ENTRY_HEIGHT*(x+2));
				DrawTextEx(buf, USER_LIST[x]->m_szNickname, strlen(USER_LIST[x]->m_szNickname), &r, DT_WORD_ELLIPSIS, NULL);
			}
			
			BitBlt(hdc, 0, 0, W, H, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbuf);
			SelectObject(src, oldsrc);
			DeleteObject(src);
			DeleteObject(oldsrc);
			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
		}
		break;

		case WM_LBUTTONDBLCLK:
		{
			 ICQAPICall_SendMessage(USER_LIST[CURRENT_MOUSE]->m_iUIN, "");
		}
		break;

		case WM_MOUSEMOVE:
		{
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			int cm = CURRENT_MOUSE;

			CURRENT_MOUSE = (y / ENTRY_HEIGHT) - 1;

			if (cm != CURRENT_MOUSE) InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			if (!(pos->flags & SWP_NOMOVE))
			{
				
				if (pos->x+W >= ScreenX-5) pos->x = ScreenX - W;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+H >= ScreenY-5) pos->y = ScreenY - H;
				else if (pos->y <= 5) pos->y = 0;
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void LoadSetup()
{
	char temp[256] = "";
	
	AddBangCommand("!LSICQOnline", BangSetStateOnline);
	AddBangCommand("!LSICQChat", BangSetStateChat);
	AddBangCommand("!LSICQAway", BangSetStateAway);
	AddBangCommand("!LSICQNA", BangSetStateNA);
	AddBangCommand("!LSICQOccupied", BangSetStateOccupied);
	AddBangCommand("!LSICQDND", BangSetStateDND);
	AddBangCommand("!LSICQInvisible", BangSetStateInvisible);
	AddBangCommand("!LSICQOffline", BangSetStateOffline);

	GetRCString("LSICQTop", temp, "lsicq-top.bmp", 256);
	IMAGE_TOP = LoadLSImage(temp, "");
	GetRCString("LSICQBottom", temp, "lsicq-bottom.bmp", 256);
	IMAGE_BOT = LoadLSImage(temp, "");
	GetRCString("LSICQEntry", temp, "lsicq-entry.bmp", 256);
	IMAGE_ENTRY = LoadLSImage(temp, "");
	GetRCString("LSICQSelEntry", temp, "lsicq-selentry.bmp", 256);
	IMAGE_SELENTRY = LoadLSImage(temp, "");

	ICQAPIUtil_SetUserNotificationFunc(ICQAPINOTIFY_ONLINELIST_CHANGE, ListChange);
	
	BYTE piEvents[1];
	piEvents[0] = ICQAPINOTIFY_ONLINELIST_CHANGE;
	ICQAPICall_RegisterNotify(ICQ_VERSION, 1, piEvents);
}

void WINAPI ListChange(int iType)
{
	ICQAPIUtil_FreeUsers(USER_COUNT, USER_LIST);
	ICQAPICall_GetOnlineListDetails(USER_COUNT, &USER_LIST);
	for (int x=0; x < USER_COUNT; x++)
	{
		ICQAPICall_GetFullUserData(USER_LIST[x], ICQ_VERSION);
	}

	H = (USER_COUNT*ENTRY_HEIGHT) + ENTRY_HEIGHT*2;
	SetWindowPos(hwndMain, NULL, 0, 0, W, H, SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangSetStateOnline(HWND caller, char* args)
{
	 ICQAPICall_SetOwnerState(0);
}

void BangSetStateChat(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(1);
}

void BangSetStateAway(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(2);
}

void BangSetStateNA(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(3);
}

void BangSetStateOccupied(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(4);
}

void BangSetStateDND(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(5);
}

void BangSetStateInvisible(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(6);
}

void BangSetStateOffline(HWND caller, char* args)
{
	ICQAPICall_SetOwnerState(7);
}