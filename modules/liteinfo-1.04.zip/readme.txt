                    [ Installation ]

Install like any other Litestep module:

    *Wharf LiteInfo .none @c:\litestep\liteinfo.dll

Left click on the module to cycle through availible modes.



                    [ Monitor Mode ]

    PHY - Percentage of physical memory in use
    SWP - Percentage of swap file in use
    CPU - CPU processor usage



                    [ Dial-Up Networking Mode ]

NOTE: For Dial-Up Networking Mode to function properly you need DUN v1.2 Update.
      The version that comes with Windows95 or OSr2 will not work.
      You can find the update at: http://www.microsoft.com/windows/downloads/contents/updates/w95dialupnetw/default.asp

    BPS - This is your current BPS connection rate.
     IN - Bytes/sec recieved
    OUT - Bytes/sec sent



                    [ Themes ]

I have included minimal theme support in LiteInfo.  To take advatange just
keep all your themes in their own directory.  Eg: C:\LiteStep\LiteInfo\<theme>
You can then change themes by editing the Theme line in modules.ini.
Example MODULES.INI:

    [LiteInfo]
    Theme=C:\LiteStep\LiteInfo\CoolBlue\Theme.ini




                    [ History ]

 v1.04
 -----
    - Added transparency support
    - Added user defineable themes
    - Added CoolBlue theme

 v1.03
 -----
    - Fixed DUN crash bug when not connected, shame it has to take down
      litestep with it

 v1.02
 -----
    - Added bar meter to DUN bytes/sec
    - Added transparent percentage readout
    - Fixed uptime problem over 1 day

 v1.01
 -----
    - Uptime now uses Windows uptime instead of local app counter
    - Added Dial-Up Networking mode
    - Mode is saved in MODULES.INI
    - Fixed inaccurate CPU readouts

 v1.00
 -----
    - Started keeping history
    - Added double buffering to display to prevent flicker
