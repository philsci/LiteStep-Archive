This is just an idea I had about a less annoying way to configure paths.
Basically we all have a web browser/email client/irc client/text editor/file
manager.

If we all called them by the same names, keeping our own paths.rc file
everything would be cool.

This dll is meant more as an idea.  A better inplementation would involve
modifying how step.rc is parsed.

Anyhow, entries like the following go into a file called paths.rc in your
litestep directory:

*Bang ftp "D:\Other stuff\CuteFTP\Cutftp32.exe"
*Bang fileman explorer.exe
*Bang web "C:\Program Files\Netscape\Communicator\Program\Netscape.exe"
*Bang mp3 "C:\Program Files\Winamp\winamp.exe"
*Bang irc D:\mirc\mirc32.exe
*Bang network explorer ::{208D2C60-3AEA-1069-A2D7-08002B30309D}
*Bang mycomputer explorer ::{20D04FE0-3AEA-1069-A2D8-08002B30309D}
*Bang display control.exe desk.cpl
*Bang controlpanel explorer ::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\::{21EC2020-3AEA-1069-A2DD-08002B30309D}

Then you can use these new bang commands in step.rc:

LoadModule bangpath.dll ;don't forget this...
...   
*Shortcut "" -43 156 m_mail.bmp  m_mail_cl.bmp  m_mail_cl.bmp  #2  !X mail   
*Shortcut "" -43 175 m_web.bmp   m_web_cl.bmp   m_web_cl.bmp   #2  !X web 
*Shortcut "" -43 194 m_irc.bmp   m_irc_cl.bmp   m_irc_cl.bmp   #2  !X irc  
*Popup "My computer" !X mycomp

Hope someone finds this useful.
Source code is a modified version of hotkeys =)
Cheers.

Crank