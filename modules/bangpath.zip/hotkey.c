/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************
 18/10/99 - crank
		Hacked the crap out of hotkey.c to prove a point 

 19/02/99 - D. Monk
 		Added virtual keys Num0 - Num 9 suggested by Ben Gruver<JesusFreke@usa.net>
 09/11/98 - Fahim Farook
		Added support for the WIN key to run popup menu
 16/09/98 - J. Vaughn
            Added support for F keys, cursor keys, etc
			broken tho, cant seem to get it to work?
 17/07/98 - D. Hodgkiss
            This file contains the source code for the hotkeys module

****************************************************************************/


#include <windows.h>
#include <windef.h>
#include <stdio.h>
#include <malloc.h>

#include "hotkey.h"
#include "lsapi.h"

const char rcsRevision[] = "$Revision: 1.22 $"; // Our Version 
const char rcsId[] = "$Id: hotkey.c,v 1.22 1999/09/16 12:52:53 maduin Exp $"; // The Full RCS ID.
void Xbangs (HWND caller,char* args);

const char szAppName[] = "BangPath";

char szLitestepPath[256];

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT KeyHook(int code, WPARAM wParam, LPARAM lParam);
void loadHotkeys();
void freeHotkeys();

hotkeyType *hotkeys = NULL;
HWND hMainWnd = NULL; // main window handle
HWND parent = NULL;
HINSTANCE dll = NULL;
HHOOK hSystemHook;  // Handle to keyboard hook
int numHotkeys = 0;
DWORD desktopThread;

// -------------------------------------------------------------------------------------------------------

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int Msgs[10];
	strcpy (szLitestepPath, szPath);
	dll = dllInst;
	parent = ParentWnd;

    {
		WNDCLASS wc;

		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppName;
		wc.style = 0;

		if (!RegisterClass(&wc))
		{  
			MessageBox(parent, "Error registering window class", szAppName, MB_OK);
			return 1;
		}
	}

	loadHotkeys();

	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		szAppName,
		"BangPath",
		WS_CHILD,
		0,
		0,
		0,
		0,
		parent,
		NULL,
		dllInst,
		NULL);
	
	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	int Msgs[10];
	
	Msgs[0] = LM_GETREVID;
	Msgs[1] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	freeHotkeys();

	UnhookWindowsHookEx(hSystemHook);
	DestroyWindow(hMainWnd);
	UnregisterClass(szAppName, dllInst);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case LM_GETREVID:
		{
			char *buf = (char *) lParam;

			if (wParam == 0)
			{
				strcpy(buf, "bangpath.dll: ");
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = '\0';
			}
			else if (wParam == 1)
			{
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = '\0';
			} else
			{
				strcpy(buf, "");
			}
			return strlen(buf);

		}
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_SYSCOMMAND:
		{
		switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				return DefWindowProc(hwnd,message,wParam,lParam);
			}
		}


	case WM_DESTROY:
		return 0;

	case WM_ERASEBKGND: 
		return 0;

	case WM_PAINT:  
		return 0;

	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void freeHotkeys()
{
	if (hotkeys != NULL)
		free(hotkeys);
}

void loadHotkeys()
{
    FILE *f;
	char progrc[512];
	strcpy(progrc,szLitestepPath);
	strcat(progrc,"\\paths.rc");
	f = LCOpen(progrc);
	if (f)
	{
		char	buffer[4096];
		char	token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
		char*	tokens[4];
		
		tokens[0] = token1;
		tokens[1] = token2;
		tokens[2] = token3;
		tokens[3] = token4;

		buffer[0] = 0;

		while (LCReadNextConfig (f, "*Bang", buffer, sizeof (buffer)))
		{
			int count;

			token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';

			count = LCTokenize (buffer, tokens, 3, extra_text);
			
			switch(count)
			{
			case 3:
				{

					if (!hotkeys)
						hotkeys = (hotkeyType *)malloc(sizeof(hotkeyType));
					else
						hotkeys = realloc(hotkeys, (numHotkeys+1)*sizeof(hotkeyType));

					strcpy(hotkeys[numHotkeys].szBang, token2);
					strcpy(hotkeys[numHotkeys].szCommand, token3);
					strcpy(hotkeys[numHotkeys].szParameters, extra_text);
					numHotkeys++;
				}
			}
			AddBangCommand("!X",Xbangs);
		}
		LCClose(f);
	}
}

void Xbangs (HWND caller,char* args)
{
	int num=-1,i;
	char workDirectory[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR];

	// Don't ask, don't tell
	for (i=0;i<(int)strlen(args);i++)
		if(!isalpha(args[i]))
			args[i]=0;
	for (i = 0; i < numHotkeys; i++)
	{
		if (!strcmpi(hotkeys[i].szBang, args))
		{
			num = i;
			break;
		}
	}
	if (num == -1) return;

	_splitpath(hotkeys[num].szCommand, drive, dir, NULL, NULL);
	strcpy(workDirectory, drive);
	strcat(workDirectory, dir);

	LSExecuteEx(GetDesktopWindow(), NULL, hotkeys[num].szCommand, 
		hotkeys[num].szParameters, workDirectory, SW_SHOWNORMAL);
}