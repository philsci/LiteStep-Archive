///////////////////////
// LSNotes v2.1
// Author: MrJukes
// Released: 8/2/00

// Step.rc
NoteDefWidth 150	// Default width
NoteDefHeight 150	// Default height
NoteDefX 100		// Default X (where new notes show up)
NoteDefY 100		// Default Y
NoteDefFontSize 12	// Default font size
NoteDefFontFace Arial	// Default font face
NoteConfirmDelete 	// True if present
NoteDefBG lsnotes.bmp	// This bmp can have FF00FF around the borders
NoteBorderTop 15
NoteBorderRight 5
NoteBorderBottom 5
NoteBorderLeft 5
NoteScrollTrackBmp lsnotes-track.bmp 			// The scroll track
NoteScrollUp 10						// The height of the scroll up area
NoteScrollDown 10					// The height of the scroll down area
NoteScrollBmp lsnotes-scroll.bmp			// The scroll handle
NoteCloseButtonBmp lsnotes-close.bmp			// The close button
NoteCloseButtonClickedBmp lsnotes-close-clicked.bmp	// The close button while clicked
NoteCloseX -15						// X position of close button
NoteCloseY 3						// Y position of close button

// You can have up to 10 custom colors
*NoteColor Grey C0C0C0
*NoteColor Purple BB00BB
etc...

// Bangs
!NewNote
!HideNote
!DeleteNote