---------------------------------
alphaLS .rc editor - beta 4.00
2002.Jan.09
---------------------------------
allelimo@jumpy.it
http://digilander.iol.it/alphaos/
---------------------------------


------------
INSTALLATION
------------

To install alphaLS .rc editor, extract the zip to C:\, and please keep all the 
configuration files in C:\alphaedit\code\

Installing in a different directory will crash the program, hope I'll fix this in next
releases.

If you have installed any prevoius beta of alphaLS .rc editor, you better search your registry 
for "alphae", delete any key referring to alphaeditor, then you can run the alpha.reg to 
associate .rc files with alphaedit: this should open any .rc in a New tab of alpaedit, 
from explorer as from every other file manager. 


------------------------
WRITING A CODE BAR FILE:
------------------------

Write one command or bang or whatever on each line, like this: 

	00.YourCommand
	01.Another Command
	02.!Bang
	03.___Section Title___
	...
	99.The Last Command

You can write up to line n. 99 (See the enclosed files for examples). 

Save the file as a plain text file with .alc extension in C:\alphaedit\code\,
then open "codelist.alc" and add a line with the name of the file you created, 
without the extension, save and restart alphaLS .rc editor.

If you add to "codelist.alc" the name of a non-existing file, or a bad-spelled name,
or a name with blank spaces after it, the program will crash.

If you want to remove any "codefile" from the list, remove the name of the file in
"codelist.alc"


------------------
HIGHLIGHT FEATURES
------------------

alphaedit highlights a step.rc file with the following formats:

1.	keywords (blue): bmp png rc x y n nn nnn nnnnnn icon ico 
2. structure: (bold black): If Else ElseIf EndIf Include New Folder
3. bangs: (bold red): !bang [!bang] "!bang"
4. E-vars: (light blue): $evar$
5. numbers: (red): 123 -123
6. comments: (green): ;this is a comment
7. strings: "Strings are not highlighted" 
8. all other words: (black)


------------
OPTIONS MENU
------------

1. toggle on/off the line numbers (on by default)
2. toggle on/off the word wrap
3. reformat line numbers If they go out of sync


---------
CODE MENU
---------

1. Most commonly used commands for Step.rc.
2. Selecting a menu voice will insert the code (shown on the status bar) 
   at the current cursor position.


-----------
WIZARD MENU
-----------

1. Some code template to start with in writing a theme.


--------
CODE BAR
--------

1. Commands, bangs, etc. for writing a theme, with default values, etc.
2. Double-clicking on a line will insert the code at the current 
   cursor position
3. Included codefiles ("*.alc"):
 * Litestep core commands/bangs
	* Desktop2
	* Popup2
	* Popup2 - bangs
	* Systray2
	* Shortcut2
	* SysVWM 6.3a
	* SysTray 1.05b

4. codefiles I'm still writing:  
	* Tasks 0.92
	* SciScript 0.1
	* Label 1.7
	* VWM2
	* Hotkey2

These are, of course, the modules I use more. Every New codefile file will be
available as soon as I write it.
If you write any other codefile, please mail it to me and I'll make it
available for download at alphaLS site.
 

--------------------------
KNOWN BUGS OR LIMITATIONS
--------------------------

* line numbers:
  1) Line numbers works with Win2k, Xp
  2) If you run Win9x, WinMe or WinNT4, you may not have the correct version of richedxx.dll 
     on your system. At alphaLS site is available an update to fix this. 
  3) The line numbering works fine all the way up to 255, where it stops. 
	  After line number 255, all the lines are marked as number 255.
	  This is a limitation in "paraformat" (the function I use to display the line numbers, 
	  that in fact are paragraph numbers). 
	  And, for the same reason, sometimes the line numbers get out of sync, 
	  so I added the "Reformat line numbers" button. 
		
* Installing in a different path from C:\alphaedit\ will crash the program.
* Adding to codelist.rc the name of a non-existing file, or a bad-typed filename,
  or a filename with blank spaces after it will crash the program.

* Anyway, these are limitations I can live with until I find a way to fix.

* The "Undo" function does not work. No idea how to fix it.


----------------
VERSIONS HISTORY
----------------


beta 4.00 - 2002.Jan.09
-----------------------

Changes:
* Re-added the code bar, now it is customizable
* Some fixes to line numbers with word wrap


beta 3.01 - 2001.Dec.31
-----------------------

Changes:
* Fixed a small bug in beta 3.00 with "Reformat Line Numbers"


beta 3.00 - 2001.Dec.28 
-----------------------

Changes:
* Added line numbers (enabled by default, can be turned off) 
  This works on Win2K, not tested on 9x and Xp, let me know...
* Added line and column number in status bar
* Added wizard menu, it gives some basic templates to start with
* Fixed paste from other application
* More code cleaning


beta 2.00 - 2001.Dec.18
-----------------------

Changes:
* Removed code bar (Can't get it work properly...)
* Added code menu and code buttons (only a start... )
* Added full screen edit
* All bars are toggleable
* Fixed highlighting for !bangs
* Fixed a memory leak with font implementation
* Code menu on right-click in document
* Word-wrap is disabled by deafult, can be turned on
* Removed some useless code


beta 1.00 - 2001.Dec.04
-----------------------

First public beta


-------
CREDITS
-------
This program is wide-based on free sourcedcode I found at two great programmer's site:
http://codeguru/earthweb.com and http://www.codeproject.com, 
so all the credits for the good parts of the code goes to:
Juraj Rojko and Chris Losinger (Syntax Highlight)
Paul Selormey, Iuri Apollonio, Ivan Zhakov, Chris Maunder, Adolf Szabo (Tabbed interface)
Cristi Posea and Hans B�hler (Docking Bar)
and to all the people in the Forums, where I found so much answers
The bad parts of the code are written by me.