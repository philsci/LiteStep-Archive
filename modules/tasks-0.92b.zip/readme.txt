Tasks 0.92b

It's a hack of jugg's tasks.dll mod by MrJukes that allows you to tint and colour the icons within the tasks tiles ala grdTray. There are three new commands ...
TasksIconHueColor
TasksIconHueIntensity
TasksIconSaturation
... there isn't a readme so I'd advise you to grab a copy of grdTray to see how it works.

--
taken from litestep.net (2002.01.07)
http://www.litestep.net/comment.php?id=64&type=news
--

"readme" compiled by rootrider, www.shellfront.org