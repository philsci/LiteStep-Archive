                    ***********************************
                    *             AutoRun             *
                    *           by Visigoth           *
                    *   gandhimail@worldnet.att.net   *
                    *         ==============          *
                    *          Version: 1.0           *
                    *         August 17, 1999         *
                    *         ==============          *
                    * http://home.att.net/~gandhimail *
                    ***********************************

Table of Contents
=================
i     Quick & Dirty Install
I.    About AutoRun
II.   How to use AutoRun

      II.1 RC Commands
           Version 1.0
           -----------
           - AutoRunDisabled

      II.3 !Bang Commands

           Version 1.0:
           ------------------
           - !AutoRunEnable
           - !AutoRunDisable
           - !AutoRunToggle
           - !AutoRunExecute

III.  Known Bugs / Limitations
IV.   Comments / Questions / Flames / Bug Reports
V.    Source Code
VI.   Source Code License


i. Quick & Dirty Install
========================

   i.1 For separate use
   --------------------
   AutoRun is intended to be used separately.  Meaning, Litestep's
   original desktop.dll provides some AutoRun / AutoPlay support, but
   AutoRun's is a bit more comprehensive.  AutoRun is ideal for use
   with jugg's jDesk module.  I don't recommend trying to use AutoRun
   with the original desktop.dll as you will probably get multiple
   copies of the program that is autorun.
   
   i.2 Installation
   ----------------
   Just copy autorun.dll into your modules directory and add the
   LoadModule <path to autorun.dll> line to your step.rc.  That's all
   - no further action is required.  There are some advanced features
   however, so you might want to refer to section II for more details.


I. About AutoRun
================
   AutoRun is a simple module intended to act as a separate module for
   AutoRunning / AutoPlaying media.  AutoRun also imitates Explorer's
   ability to temporarily stop AutoRun by holding down the Shift key
   upon inserting media.  Beyond that, !Bang Commands have been added
   to control the state of AutoRun.


II. How to use AutoRun
=========================
   AutoRun is a seamless module - it requires no interaction on the
   part of the user to operate.  However, if you would like to control
   the state of AutoRun (ie whether it is enabled or disabled), you
   may do so by using !Bang Commands outlined below.


   II.1 RC Commands
   ----------------

     AutoRunDisabled
     ```````````````
     Description: This sets AutoRun's initial state to disabled.  It
     may be enabled by using the !Bang Commands !AutoRunEnable and
     !AutoRunToggle

     
   II.3 Added !Bang Commands
   -------------------------
     
     !AutoRunEnable
     ``````````````
     Description: Enables AutoRun.


     !AutoRunDisable
     ```````````````
     Description: Disables AutoRun.  Note that !AutoRunExecute still
     works even if AutoRun is disabled.
     
     
     !AutoRunToggle
     ``````````````
     Description: Toggles the states of AutoRun (Enabled/Disabled).
     Note that regardless of AutoRun's state, !AutoRunExecute still
     works.
     
     
     !AutoRunExecute
     ```````````````
     Description: !AutoRunExecute executes the appropriate autorun
     command on the specified drive.  For instance,
     
       !AutoRunExecute D
       !AutoRunExecute D:
       !AutoRunExecute D:\
     
     all execute the appropriate action on the media in drive D.


III. Known Bugs / Limitations
=============================
   None known - bound to be many :)  J/K - but if you find any,
   see section IV for instructions about reporting them.


IV. Comments/Questions/Flames/Bug Reports
=========================================
   All of these should be sent directly to me, visigoth.  My e-mail
   address is:  gandhimail@worldnet.att.net


V. Source Code
==============
   Yes, source code is available.  All you have to do is send me an
   e-mail for it.  My e-mail is gandhimail@worldnet.att.net
   However, if you are going to edit the code, *please* read the
   Source Code License below.  There are certain restrictions.


VI. Source Code License
=======================

   Article I. Sure, Have the Code!
   -------------------------------
   I don't want to stop progress on this module.  So, I'm going to
   let anyone who wants to edit the code, do so at his/her free will.
   However, there are restrictions, as noted by the rest of the
   license.

   Article II. Redistribution
   --------------------------
   This file *must* be redistributed with the source code, with duly
   noted changes to sections I, II, III, and IV.  However, I request
   that my name be left in Section I as the original author of the
   module.

   Article III. Leave Credit where It's Due!
   -----------------------------------------
   All I ask is that Section I still have my name in it as the
   original author.  Besides this file and the comments, there isn't
   much to say that I did anything... :)

   Article IV. Send Me Your Cool Stuff
   -----------------------------------
   I don't know what innovation is left for AutoRun, but I'd like to
   know if there is any.. Just drop me a line telling me what you're
   doing..

   Article V. Have Fun
   -------------------
   Remember, I'm not going to stop progress on this module, so go
   ahead and do what you want to it.  Just don't take credit for
   what I've already done.