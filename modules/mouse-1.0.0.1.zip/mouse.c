#include <windows.h>
#include "resource.h"
#include "exports.h"
#include "mouse.h"
#include "lsapi.h"

char *szApp = "Mouse";
struct MouseSettings *cs;
//TCHAR tchBuffer[BUFFER]; // buffer for expanded string 
//int nSize;               // size of string 
BOOL fResult;            // system shutdown flag 
int aMouseInfo[3];       // array for mouse information
int hscSpeed;

struct MouseSettings *ReadSettings(LPCSTR szPath)
{
    struct MouseSettings *settings = (struct MouseSettings *)malloc(sizeof(struct MouseSettings));
    
    
    // Is there a mouse? 
    fResult = GetSystemMetrics(SM_MOUSEPRESENT); 
    
    
    return settings;
}

void BangSwapMouseBtn(HWND caller, char *args)
{
    if (fResult) {
        SystemParametersInfo(   SPI_SETMOUSEBUTTONSWAP,
            !(GetSystemMetrics(SM_SWAPBUTTON)),
            NULL,
            SPIF_SENDCHANGE
            );
    }
    return;
}

void BangMouseSpeedX(HWND caller, char *args)
{

    hscSpeed = atoi(args);
    if (fResult) {
        if (hscSpeed > 3) {
            aMouseInfo[0] = 4;
            aMouseInfo[1] = 3 * (8 - hscSpeed);
            aMouseInfo[2] = 2;
        }
        else {
            if (hscSpeed) {
                aMouseInfo[0] = 13 - (3 * hscSpeed);
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 1;
            }
            else {
                aMouseInfo[0] = 0;
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 0;
            }
        }
        SystemParametersInfo(   SPI_SETMOUSE,
                                0,
                                &aMouseInfo[0],
                                SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE
                            );

    }

    return;
}

void BangMouseSpeedUp(HWND caller, char *args)
{

    if (hscSpeed < 6) hscSpeed++;
    if (fResult) {
        if (hscSpeed > 3) {
            aMouseInfo[0] = 4;
            aMouseInfo[1] = 3 * (8 - hscSpeed);
            aMouseInfo[2] = 2;
        }
        else {
            if (hscSpeed) {
                aMouseInfo[0] = 13 - (3 * hscSpeed);
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 1;
            }
            else {
                aMouseInfo[0] = 0;
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 0;
            }
        }
        SystemParametersInfo(   SPI_SETMOUSE,
                                0,
                                &aMouseInfo[0],
                                SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE
                            );

    }

    return;
}

void BangMouseSpeedDown(HWND caller, char *args)
{

    if (hscSpeed > 0) hscSpeed--;
    if (fResult) {
        if (hscSpeed > 3) {
            aMouseInfo[0] = 4;
            aMouseInfo[1] = 3 * (8 - hscSpeed);
            aMouseInfo[2] = 2;
        }
        else {
            if (hscSpeed) {
                aMouseInfo[0] = 13 - (3 * hscSpeed);
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 1;
            }
            else {
                aMouseInfo[0] = 0;
                aMouseInfo[1] = 0;
                aMouseInfo[2] = 0;
            }
        }
        SystemParametersInfo(   SPI_SETMOUSE,
                                0,
                                &aMouseInfo[0],
                                SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE
                            );

    }

    return;
}

int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
    
    cs = ReadSettings(szPath);
    
    AddBangCommand("!SwapMouseBtn",BangSwapMouseBtn);
    AddBangCommand("!MouseSpeedX",BangMouseSpeedX);
    AddBangCommand("!MouseSpeedUp",BangMouseSpeedUp);
    AddBangCommand("!MouseSpeedDown",BangMouseSpeedDown);

    SystemParametersInfo(SPI_GETMOUSE, 0, &aMouseInfo[0], 0);
    if (aMouseInfo[1]) hscSpeed = (aMouseInfo[1] / 3);
    else {
        if (aMouseInfo[0]) hscSpeed = 4 - ((aMouseInfo[0] - 1) / 3);
        else hscSpeed = 0;
    }
    return 0;
}


/***********************************************************
* int initModule()                                         *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND parent                                         *
*      The HWND of the parent window to this module        *
*    - HINSTANCE dll                                       *
*      The HINSTANCE of this DLL.                          *
*    - wharfDataType *wd                                   *
*      A pointer to a structure of info about litestep     *
*                         *  *  *  *                       *
* Handles all initialization of Mouse.  Returns 0         *
***********************************************************/

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
    return initModuleEx(parent, dll, wd->lsPath);

}


/***********************************************************
* int quitModule()                                         *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HINSTANCE dll                                       *
*      The HINSTANCE of this DLL.                          *
*                         *  *  *  *                       *
* Handles all of the unloading of this DLL.                *
***********************************************************/

int quitModule(HINSTANCE dll)
{
    free(cs);
    return 0;
}