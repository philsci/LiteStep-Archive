/*
This is a part of the Random LiteStep module source code.

Copyright (C) 2001 Erik Christiansson

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "random.h"

void bangRandom(HWND caller, LPCSTR args);

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!Random", bangRandom);

	FILE *f;
	f = LCOpen(NULL);
	if (f)
	{
		char buffer[4096];
		char token1[4096], command[4096];
		char* tl[1];

		tl[0] = token1;
		buffer[0] = 0;
		while (LCReadNextConfig(f, "*Random", buffer, sizeof(buffer)))
		{
			token1[0] = command[0] = 0;
			LCTokenize(buffer, tl, 1, command);
			bangRandom(NULL, command);
		}
		LCClose(f);
	}

	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!Random");
}

void bangRandom(HWND caller, LPCSTR args)
{
	LPSTR token;
	int i, c=0;

	for(i=0; i<(int)strlen(args); i++) if(args[i] == '|') c++; c++;
	srand((unsigned)GetTickCount());
	c = (int)(((float)rand()/(float)RAND_MAX)*c)+1;

	token = strtok((LPSTR)args, "|");
	for(i=1; token; i++)
	{
		if(i == c)
		{
			LSExecute(NULL, token, SW_SHOWNORMAL);
			break;
		}
		token = strtok(NULL, "|");
	}
}
