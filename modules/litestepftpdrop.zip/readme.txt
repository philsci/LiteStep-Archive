LiteStepFTPDrop
(C)1998 Something Decent.
All Rights Reserved.
http://somedec.com


License & Warranty Info
-----------------------
This software is distributed as Freeware.  You may NOT sell this software or in any way make a profit from the sale and/or use of this product.  You may distribute it freely, with this readme file.

There are NO warranties implicit or implied on this product.  You must use it AT YOUR OWN RISK.  The author will not be held liable for any damages or loss caused directly or indirectly by this product.

This product can only be used in conjunction with Net Vampire.  This product is also distributed as freeware.  You can get it from http://kulichki.rambler.ru/~vampire/.  Net Vampire is NOT written or distributed by Something Decent.

Purpose
-------

This Wharf module works with the LiteStep Win32 shell.  It continually searches for and captures the Net Vampire "Drop Basket" so that it will stay in your wharf bar no matter what virtual screen you move to.  Great for web browsing on multiple screens!


Author
------

Send all comments, bug reports, questions, praise, etc. to chet@somedec.com.

Thank you for using LiteStepFTPDrop.
