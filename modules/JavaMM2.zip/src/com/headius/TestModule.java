package com.headius;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import litestep.Litestep;
import litestep.Module;

/**
 * This is a very simple module to help you get started. Add the TestModule jar
 * file to your classpath, and you should be able to load the module
 * appropriately.
 *
 * @author Charles Oliver Nutter
 */
public class TestModule implements Module, ActionListener {
    Frame myFrame;
    Litestep myLitestep;
    TextField myField;

    public void startModule(Litestep ls) {
	myLitestep = ls;

	myFrame = new Frame("Test Module");

	myFrame.setBounds(100, 100, 300, 50);
	
	Button myButton = new Button("execute");
	myButton.addActionListener(this);
	myField = new TextField();
	
	myFrame.setLayout(new BorderLayout());
	myFrame.add(myButton, BorderLayout.EAST);
	myFrame.add(myField, BorderLayout.CENTER);
	
	myFrame.show();
    }

    public void stopModule() {
	myFrame.hide();
	myFrame = null;
    }

    public void actionPerformed(ActionEvent evt) {
	String command = myField.getText();
	myField.setText("");
	myLitestep.execute(command, Litestep.SW_SHOWNORMAL);
    }
}
