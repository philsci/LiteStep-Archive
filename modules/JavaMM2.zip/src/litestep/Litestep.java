package litestep;

import java.awt.Color;

/**
 * The Litestep class provides access to some of the basic LSAPI functions.
 * You can use it to read settings from step.rc, execute commands, and other
 * useful functions.
 * <p>
 * The jar file containing this class (JavaMM.jar) must be in the classpath
 * that you specify to Litestep using the "JavaClassPath" directive. For
 * example, if the jar file is in C:\Java\ you would want to add
 * "JavaClassPath C:\Java\JavaMM.jar" to your step.rc. Any modules
 * you plan to load using "LoadJavaModule" must also be in your class path.
 * 
 * @see litestep.Module
 * @author Charles Oliver Nutter
 */
public class Litestep {
    /**
     * Constants for the calls to execute and executeEx. These constants
     * specify how the executed command's window should be displayed.
     */
    public static final String SW_HIDE;
    public static final String SW_MINIMIZE;
    public static final String SW_MAXIMIZE;
    public static final String SW_RESTORE;
    public static final String SW_SHOW;
    public static final String SW_SHOWDEFAULT;
    public static final String SW_SHOWMAXIMIZED;
    public static final String SW_SHOWMINIMIZED;
    public static final String SW_SHOWMINNOACTIVE;
    public static final String SW_SHOWNA;
    public static final String SW_SHOWNOACTIVATE;
    public static final String SW_SHOWNORMAL;

    static {
	SW_HIDE = "hide";
	SW_MINIMIZE = "minimize";
	SW_MAXIMIZE = "maximize";
	SW_RESTORE = "restore";
	SW_SHOW = "show";
	SW_SHOWDEFAULT = "show_default";
	SW_SHOWMAXIMIZED = "show_maximized";
	SW_SHOWMINIMIZED = "show_minimized";
	SW_SHOWMINNOACTIVE = "show_min_no_active";
	SW_SHOWNA = "show_na";
	SW_SHOWNOACTIVATE = "show_no_activate";
	SW_SHOWNORMAL = "show_normal";

	System.loadLibrary("javamm");
    }

    /**
     * Get a string from the step.rc file using the specified key.
     * @param key The key to look up
     * @param defValue The default value if the key is not found
     * @return The value from step.rc, or the default
     */
    public native String getRCString(String key, String defValue);

    /**
     * Get an integer from the step.rc file using the specified key.
     * @param key The key to look up
     * @param defValue The default value if the key is not found
     * @return The value from step.rc, or the default
     */
    public native int getRCInt(String key, int defValue);

    /**
     * Get a boolean from the step.rc file using the specified key.
     * @param key The key to look up
     * @param defValue The default value if the key is not found
     * @return The value from step.rc, or the default
     */
    public native boolean getRCBool(String key, boolean ifFound);

    /**
     * Get a full line from the step.rc file that starts with the string in 'command'.
     * @param command The command to look up
     * @param defValue The default value if the command cannot be found
     * @return The value from step.rc, or the default
     */
    public native String getRCLine(String command, String defValue);
    
    /**
     * Get a color from the step.rc file using the specified key.
     * @param key The key to look up
     * @param defValue The default color if the key is not found
     * @return The value from step.rc, or the default
     */
    public native Color getRCColor(String key, Color defValue);

    /**
     * Expand any variables in 'value' and return the expanded string.
     * @param value The string to expand
     * @return The fully-expanded string
     */
    public native String varExpansion(String value);

    /**
     * Set the desktop area to the specified dimensions.
     * Use negative numbers for distances from the bottom right corner.
     * @param left The left side coordinate of the desktop
     * @param top The top side coordinate of the desktop
     * @param right The right side coordinate of the desktop
     * @param bottom The bottom coordinate of the desktop
     */
    public native void setDesktopArea(int left, int top, int right, int bottom);

    /**
     * Get the path to the Litestep directory.
     * @return The path to the Litestep directory
     */
    public native String getLitestepPath();

    /**
     * Get the path to the default image directory
     * @return The path to the default image directory
     */
    public native String getImagePath();

    /**
     * Execute a command. If the command displays a window, show that window
     * as specified in 'show'.
     * @param command The command to execute
     * @param show Specifies how to show the window the command produces
     * @return A handle to the process associated with the executed command.
     */
    public native int execute(String command, String show);

    /**
     * Execute a command in the specified way (function) with the specified
     * arguments (args) in the specified directory (directory). If the command
     * displays a window, show that window as specified in 'show'.
     * @param function The function to perform on the command. Can be "open", "print", or "explore".
     * @param command The command to execute.
     * @param args The arguments to pass to the command.
     * @param directory The directory to execute the command in.
     * @param show Specified how to show the window the command produces.
     * @return A handle to the process associated with the executed command.
     */
    public native int executeEx(String function, String command, String args, String directory, String show);
}
