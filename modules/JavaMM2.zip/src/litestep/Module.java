package litestep;

/**
 * This interface specifies that a class is a loadable Litestep module.
 * The two functions provided tell the module to start or stop. When the module
 * is started, it is passed an instance of the litestep.Litestep class, which
 * provides basic LSAPI functions.
 * <p>
 * To load java modules into Litestep, you must first have loaded the Java
 * Module Manager using "LoadModule <path to litestep>\JavaMM.dll". Once this
 * is done, you can load modules by adding "LoadJavaModule" lines to your
 * step.rc file. For example, if I have my com.headius.TestModule class in
 * C:\Java\com\headius, and I have added the "JavaClassPath" line to step.rc
 * (pointing at the JavaMM.jar and TestModule.jar files) I can load TestModule
 * with the following line:
 * <code>LoadJavaModule com/headius/TestModule</code>
 * <p>
 * Your java modules should implement this interface. Startup code should be 
 * in startModule, and shutdown code should be in stopModule.
 *
 * @see litestep.Litestep
 * @author Charles Oliver Nutter
 */
public interface Module {
    public void startModule(Litestep ls);
    public void stopModule();
}
