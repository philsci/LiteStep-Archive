----------------------------------------------------------------
hotspots.dll   v0.4a                            January 24, 2000
----------------------------------------------------------------
Pavel Vitis



What the hell is "hotspots.dll"?
================================================================

With Hotspots you can define rectangular areas on the screen
called "hotspots" that will trigger event (run program or !bang
command) when the mouse pointer passes into or out of the defined
area.

I programmed this to simulate "active borders", nice feature
included in Pointix (Pop-Mouse) utility by Pointix Company
(http://www.pointix.com/). That was the original idea. Anyway
there is much more possibilities how to use this module. You can
define hot-corners to control screensaver, toggle visibility of
shortcut groups or other modules, etc...


What's new
================================================================

v0.4a / January 24, 2000
	* Hotspots tested under WinNT, removed key-modifiers
	  actions in WinNT/2K.

v0.4 / November 10, 1999
	* Fixed bug that caused crashes on WinNT (timerproc)
	+ Hotspots are automatically disabled when screensaver is
	  running
	+ Hotspots.dll now returns RevisionID string
	+ Added some items into to-do list

v0.3 / September 26, 1999
	* Optimizations
	* Format of hotspot definition slightly changed
	+ Added separate actions for Ctrl/Shift/Alt key modifiers
	+ Added mouse-out action

v0.2 / September 07, 1999
	* Fixed some ugly bugs
	* Fixed some minor bugs
	* Some internal optimizations
	+ Coordinates can be negative values
	+ Sizes can be zero - they are recalculated to maximum
	+ Option to start hotspots disabled
	+ Added params to hotspots
	+ Added !HotspotsEnable
	+ Added !HotspotsDisable
	+ Added !HotspotUpdate

v0.1 / September 06, 1999
	+ First release



Installation
================================================================

(1) Installation is simple. Load the module in your step.rc:

LoadModule "c:\litestep\hotspots.dll"

Copy hotspots.dll directly into your Litestep directory.



(2) Then edit your step.rc and define some hotspots.
The syntax is:

*Hotspot "Name" "Params" X-position Y-position Width Height Delay "In_Action"

-  "Name" is the unique identifier of the hotspot. Use some
descriptive name here. Multiple hotspots can share same name.
This name is used to identify the hotspots in further operations.

-  Position is in pixels. You can use negative values.
-  Width, Height are in pixels. Zero value "0" means maximum
size (hotspot width/height reaches opposite screen border).

-  Delay is the time interval (in 1/10 sec) that defines how
long should mouse pointer stay in the hotspot area before
triggering associated action. It is here to avoid accidental
actions when working with mouse.
Delay is between 0..10.

- "In_Action" can be any executable, file, or !bang command. If the
non-executable file is specified, it will activate application
associated to file-type, if any. This action will be executed when
mouse enters the hotspot area. This parameter is optional, you can
leave it off or add it later (same as other actions - see below) with
*HotspotUpdate command or !HotspotUpdate bang.

- "Params" is string of additional parameters. Empty "" will
result in default behavior.

Params are:
  S - Silent mode - this hotspot doesn't beep
  D - Disabled mode - this hotspot is initially disabled
  X - Start application maximized
  M - Start application minimized


(3) Update defined hotspots

Now you can add "out" action, add shift-modifier actions, or modify
params:

*HotspotUpdate Name Params Action_type Action

This command will update data of already defined hotspot.
"Action_type" can be one of following constants:

  action_in
  action_out
  action_shift
  action_alt
  action_ctrl

They are self explanatory enough, I think.


(4) You can also define sound that will play when action is triggered:

  HotspotBeep "path_to\beep.wav"


You can disable hotspots functionality at startup by specifying:

  HotspotsDisabled


And there are some !Bangs:

  !HotspotsEnable
  !HotspotsDisable

Update hotstpot's params:

  !HotspotUpdate Name Params Action_type Action

For example:
to disable hotspot:	 !HotspotUpdate LeftBar "D"
to mute hotspot:	 !HotspotUpdate LeftBar "S"
to add Shift key action: !HotspotUpdate LeftBar "" action_shift "notepad.exe"


Example	step.rc entries:
================================================================

There I provide some example settings.
I define three active borders on the left, right and top of
the screen to run frequently used applications (substitute
yours). Next I define four hot corners, top-left to instantly
activate screen saver, top-right to disable screen saver,
bottom-left to shutdown windows and bottom-right to run step.rc
editor.
First two hotspots provide simple functionality of hiding
taskbar like in explorer. "HideTaskbar" is defined over whole
desktop area and will hide taskbar after the mouse leaves
taskbar	strip. Taskbar will be shown when touching bottom
edge of screen ("ShowTaskbar").	Use geekfunk.dll for taskbar
bangs. This cool tip was first introduced by Jorje from Modulo -
http://chunkymunky.com/modulo/.
You can use my scrsaver.dll for screen saver controlling bangs.

;==============================================================
; SAMPLE STEP.RC SECTION
;==============================================================

;HotspotsDisabled
HotspotBeep "c:\sounds\tick.wav"

*Hotspot HTaskbar "S" 0 0 0 -20 10 !Hide_Taskbar
*Hotspot STaskbar "S" 0 -1 0 0 2 !Show_Taskbar

*Hotspot Left "MS" 0 2 2 0 4 "notepad.exe"
*Hotspot Right "" -2 2 0 0 4 "calc.exe"
*Hotspot Top "" 2 0 -2 2 10 "explorer.exe"

*Hotspot TopLeft "S" 0 0 2 2 8 !ScreenSaver
*Hotspot TopRight "S" -2 0 0 2 8 !ScreenSaverDisable
; Add mouse out-action to TopRight hotspot
*HotspotUpdate TopRight "S" action_out !ScreenSaverEnable

*Hotspot BottomLeft "" 0 -2 2 0 10 !Shutdown
*Hotspot BottomRight "" -2 -2 0 0 10 "notepad c:\litestep\step.rc"



Features, limitations
================================================================

Under WinNT/2K, the key-modifiers actions (action_shift/alt/ctrl)
are not supported yet.

If any of your hotspots will overlap, the control over overlapped
region takes hotspot that is defined later. They are defined
"from bottom to topmost".

You can define up to maximum of 50 hotspots.
"This should be enough for everyone..." ;)


Plans for future versions - TO-DO list
================================================================

1. Allow Shift/Alt/Ctrl actions in WinNT/2K
2. Specify flags for starting of applications - start minimized,
   hidden, only one instance, etc. - partially done.
3. Rewrite this blahblah to html format to make it more readable.
4. Catch these remaining bugs (WinNT thingy)
5. Add ability to auto-disable hotspots when any app runs in
   fullscreen
6. Optional list of excluded apps (especially games running in
   fullscreen)
7. Optional cursor change when hotspot activated/touched


Bugs
================================================================

None in this release, except limitations noted above.

Any suggestions will be welcome too, don't hesitate and email me.



Contact & additional info, resources
================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www   : http://floach.pimpin.net/pavel/

Programmed in Delphi 4, using LSDevKit (modified TR3) by Murphy:
http://www.dev0.de/
