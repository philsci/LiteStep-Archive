LoneRunnr version 1.0 by cael (caelur@innocent.com)

this is a simple program to check if litestep is running and if it is not to run it,
it is to protect against crashes.

just put it anywhere and make a short cut in your startup folder then restart (or just run the program the first time ;-)

never worry about litestep crashes again ;-)

enjoy,
cael