#include <windows.h>
#include "exports.h"
#include "lsapi.h"

const long magicDWord = 0x49474541;

struct WM
{
	int num;
	int X, Y, W, H;
	char bgp[MAX_PATH];
	char desktopbackground[MAX_PATH];
	char flags[50];
	HBITMAP bmp, bg;
};

struct SmallWnd
{
	HWND parent;
	HWND bighwnd;
	HWND hwnd;
	int bx, by, bw, bh;
	int x, y, w, h;
	HBITMAP bmp;
	BOOL UPDATE;
};

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK SmallWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SaveDesktopEnumProc(HWND hwnd, LPARAM lParam);
BOOL CALLBACK SetDesktopEnumProc(HWND hwnd, LPARAM lParam);
BOOL CALLBACK SetDesktopHandleEnumProc(HWND hwnd, LPARAM lParam);
BOOL CALLBACK HandleWindowsEnumProc(HWND hwnd, LPARAM lParam);
BOOL CALLBACK CleanupEnumProc(HWND hwnd, LPARAM lParam);
void LoadSetup();
void SwitchTo(int num);

void BangPrev(HWND caller, char* args);
void BangNext(HWND caller, char* args);
void BangGoto(HWND caller, char* args);

char* szAppName = "xVWMx";
char* szSmallWndName = "xVWMx - Small Window";

HWND parent;
HINSTANCE hInstance;
int ScreenX, ScreenY;
char lsdir[MAX_PATH] = "";
int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

int VALID_WMS=0;
int CurrentDesktop=1;
HWND hCurrentDesktop=NULL;
int UpdateInterval=1000;

int initModuleEx(HWND hparent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	hInstance = dllInst;
	parent = hparent;
	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = SmallWndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szSmallWndName;   // our window class name
    
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szSmallWndName, MB_OK);
		return 1;
	}

	LoadSetup();

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	return 0;
}

int quitModule(HINSTANCE dll)
{
	HWND hwnd;

	KillTimer(hCurrentDesktop, 0);

	while ((hwnd = FindWindow(szAppName, szAppName)) != NULL)
	{
		WM* p = (WM*)GetProp(hwnd, szAppName);
		if (p)
		{
			if (p->num == 1) SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			if (p->bmp) DeleteObject(p->bmp);
			if (p->bg) DeleteObject(p->bg);
			delete p;
		}

		RemoveProp(hwnd, szAppName);
		DestroyWindow(hwnd);
	}

	EnumWindows((WNDENUMPROC)CleanupEnumProc, NULL);

	UnregisterClass(szAppName, dll);
	UnregisterClass(szSmallWndName, dll);

	RemoveBangCommand("!XVWMXNext");
	RemoveBangCommand("!XVWMXPrev");
	RemoveBangCommand("!XVWMXGoto");

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	WM* p = (WM*)GetProp(hwnd, szAppName);
	if (!p) return DefWindowProc(hwnd, msg, wParam, lParam);

	switch (msg)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);

			switch (wParam)
			{
				case 0:
					sprintf(buf, "xVWMx 1.1 (MrJukes)\0");
				break;
				case 1:
					sprintf(buf, "xVWMx 1.1 (MrJukes)\0");
				break;
				default:
					sprintf(buf, "xVWMx 1.1 (MrJukes)\0");
			}

			return strlen(buf);
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP oldbuf;
			BOOL NEWBMP=FALSE;

			if (!p->bmp) 
			{
				HDC src = CreateCompatibleDC(NULL);
				HBITMAP oldsrc, bgbmp;
			
				p->bmp = CreateCompatibleBitmap(hdc, p->W, p->H);

				if (p->desktopbackground)
				{
					bgbmp = (HBITMAP)LoadImage(NULL, p->desktopbackground, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
				}
				else
				{
					// Find it in the registry
				}

				oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				oldbuf = (HBITMAP)SelectObject(buf, p->bmp);
				SetStretchBltMode(buf, COLORONCOLOR);
				StretchBlt(buf, 0, 0, p->W, p->H, src, 0, 0, ScreenX, ScreenY, SRCCOPY);
				SelectObject(src, oldsrc);
				DeleteDC(src);
			}
			else
			{
				oldbuf = (HBITMAP)SelectObject(buf, p->bmp);
			}
			
			BitBlt(hdc, 0, 0, p->W, p->H, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_TIMER:
		{
			EnumWindows((WNDENUMPROC)HandleWindowsEnumProc, NULL);
		}
		break;

		case WM_MOUSEMOVE:
		{
			SetCursor(LoadCursor(NULL, IDC_ARROW));
		}
		break;

		case WM_RBUTTONUP:
		{
			if (CurrentDesktop != p->num)
			{
				SwitchTo(p->num);
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

LRESULT CALLBACK SmallWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	SmallWnd* s = (SmallWnd*)GetProp(hwnd, szSmallWndName);
	if (!s) return DefWindowProc(hwnd, msg, wParam, lParam);

	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP oldbuf;

			if (!s->bmp && s->parent == hCurrentDesktop || s->UPDATE)
			{
				HDC bhdc = GetWindowDC(s->bighwnd);
				if (s->bmp) DeleteObject(s->bmp);
				s->bmp = CreateCompatibleBitmap(hdc, s->w, s->h);
				oldbuf = (HBITMAP)SelectObject(buf, s->bmp);
				SetStretchBltMode(buf, COLORONCOLOR);
				StretchBlt(buf, 0, 0, s->w, s->h, bhdc, 0, 0, s->bw, s->bh, SRCCOPY);
				ReleaseDC(s->bighwnd, bhdc);
			}
			else
			{
				oldbuf = (HBITMAP)SelectObject(buf, s->bmp);
			}

			BitBlt(hdc, 0, 0, s->w, s->h, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteDC(buf);

			EndPaint(hwnd, &ps);
		}
		break;

		case WM_TIMER:
		{
			if (s->parent == hCurrentDesktop)
			{
				RECT r;
				GetWindowRect(s->bighwnd, &r);

				if (s->bx != r.left ||
					s->by != r.top ||
					s->bw != r.right-r.left ||
					s->bh != r.bottom-r.top)
				{
					s->bx = r.left;
					s->by = r.top;
					s->bw = r.right-r.left;
					s->bh = r.bottom-r.top;

					GetClientRect(s->parent, &r);
					s->x = (s->bx * r.right) / ScreenX;
					s->y = (s->by * r.bottom) / ScreenY;
					s->w = (s->bw * r.right) / ScreenX;
					s->h = (s->bh * r.bottom) / ScreenY;
					
					SetWindowPos(hwnd, NULL, s->x, s->y, s->w, s->h, SWP_NOZORDER | SWP_NOACTIVATE);
				}

				s->UPDATE=TRUE;
				InvalidateRect(hwnd, NULL, TRUE);
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

BOOL CALLBACK HandleWindowsEnumProc(HWND hwnd, LPARAM lParam)
{
	DWORD dwStyle = GetWindowLong(hwnd, GWL_STYLE);
	SmallWnd* s = (SmallWnd*)GetProp(hwnd, szSmallWndName);

	if (!s)
	{
		if (!IsIconic(hwnd) && (dwStyle & WS_VISIBLE)
			&& hwnd != FindWindow("progman", NULL)
			&& hwnd != GetDesktopWindow()
			&& hwnd != FindWindow("DesktopBackgroundClass", NULL))
		{
		
			char temp[256] = "";
			GetWindowText(hwnd, temp, 256);

			RECT r;

			s = new SmallWnd;
			s->parent = hCurrentDesktop;
			s->bighwnd = hwnd;
			s->UPDATE=FALSE;
				
			GetWindowRect(hwnd, &r);
			s->bx = r.left;
			s->by = r.top;
			s->bw = r.right-r.left;
			s->bh = r.bottom-r.top;

			GetClientRect(s->parent, &r);
			s->x = (s->bx * r.right) / ScreenX;
			s->y = (s->by * r.bottom) / ScreenY;
			s->w = (s->bw * r.right) / ScreenX;
			s->h = (s->bh * r.bottom) / ScreenY;

			s->hwnd = CreateWindow(szSmallWndName, szSmallWndName, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS, s->x, s->y, s->w, s->h, s->parent, NULL, hInstance, NULL);

			SetProp(s->hwnd, szSmallWndName, (HANDLE)s);
			SetProp(hwnd, szSmallWndName, (HANDLE)s);
			SetTimer(s->hwnd, 0, UpdateInterval, NULL);
		}
	}
	else if (s->parent != hCurrentDesktop)
	{
		SetParent(s->hwnd, hCurrentDesktop);
		s->parent = hCurrentDesktop;
		InvalidateRect(hCurrentDesktop, NULL, TRUE);
		//SetTimer(s->hwnd, 0, UpdateInterval, NULL);
	}
	else
	{
		//KillTimer(s->hwnd, 0);
	}

	return TRUE;
}

BOOL CALLBACK CleanupEnumProc(HWND hwnd, LPARAM lParam)
{
	SmallWnd* s = (SmallWnd*)GetProp(hwnd, szSmallWndName);

	if (s)
	{
		KillTimer(s->hwnd, 0);
		if (s->bmp) DeleteObject(s->bmp);
		RemoveProp(hwnd, szSmallWndName);
	}

	// Remove the desktop number?
	// Maybe make it an option cause I kind of like it

	return TRUE;
}

BOOL CALLBACK SaveDesktopEnumProc(HWND hwnd, LPARAM lParam)
{
	DWORD dwStyle = GetWindowLong(hwnd, GWL_STYLE);
	LONG userdata = (LONG)GetWindowLong(hwnd, GWL_USERDATA);

	if (!IsIconic(hwnd) && (dwStyle & WS_VISIBLE) && !(userdata & magicDWord))
	{
		SetProp(hwnd, "xVWMx Desktop", (HANDLE)CurrentDesktop);
		ShowWindow(hwnd, SW_HIDE);
		SendMessage(hwnd, WM_SYSCOMMAND, (WPARAM)SC_MINIMIZE, 0);
		if (!IsIconic(hwnd)) ShowWindow(hwnd, SW_MINIMIZE);
		ShowWindow(hwnd, SW_SHOW);
	}
	else if (IsIconic(hwnd) && (int)GetProp(hwnd, "xVWMx Desktop") == CurrentDesktop)
	{
		SetProp(hwnd, "xVWMx Desktop", (HANDLE)0);
	}

	return TRUE;
}

BOOL CALLBACK SetDesktopEnumProc(HWND hwnd, LPARAM lParam)
{
	if ((int)GetProp(hwnd, "xVWMx Desktop") == CurrentDesktop)
	{
		ShowWindow(hwnd, SW_HIDE);
		ShowWindow(hwnd, SW_RESTORE);
		ShowWindow(hwnd, SW_SHOW);
	}

	return TRUE;
}

void LoadSetup()
{
	// *WM X Y W H back.bmp #T

	char temp[256] = "";
	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], token7[4096], token8[4096], extra_text[4096];
	char*	tokens[8];
	int num=1;
			
	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	tokens[6] = token7;
	tokens[7] = token8;

	UpdateInterval = GetRCInt("XVWMXUpdateInterval", 1000);
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	while (LCReadNextConfig(step, "*WM", temp, 256)) { VALID_WMS++; }
	LCClose(step);

	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	while (LCReadNextConfig(step, "*WM", temp, 256)) 
	{ 
		int count;
		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = token7[0] = token8[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 8, extra_text);

		if (count >= 6)
		{
			WM* p = new WM;
			DWORD dwStyle = WS_VISIBLE | WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
			DWORD dwStyleEx = WS_EX_TOOLWINDOW;
			BOOL SetMagicDWord=FALSE, SetTopMost=FALSE;
			HWND hwnd;

			p->num = num++;
			p->X = atoi(token2);
			p->Y = atoi(token3);
			p->W = atoi(token4);
			p->H = atoi(token5);
			strcpy(p->bgp, token6);
			if (_strnicmp(p->bgp, ".none", 5)) p->bg = LoadLSImage(p->bgp, p->bgp);
			strcpy(p->flags, token7);
			strcpy(p->desktopbackground, token8);
			p->bmp = NULL;

			for (int x=1; x<(int)strlen(p->flags); x++)
			{
				if (tolower(p->flags[x]) == 't') SetTopMost=TRUE;
				else if (tolower(p->flags[x]) == 'a') SetMagicDWord=TRUE;
			}

			hwnd = CreateWindowEx(dwStyleEx, szAppName, szAppName, dwStyle, p->X, p->Y, p->W, p->H, NULL, NULL, hInstance, NULL);
			if (p->num == 1) SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			
			if (SetMagicDWord) SetWindowLong(hwnd, GWL_USERDATA, magicDWord);
			if (SetTopMost) SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
			
			SetProp(hwnd, szAppName, (HANDLE)p);
			if (p->num == 1) 
			{
				if (_strnicmp(p->desktopbackground, ".none", 5))
				{
					SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, p->desktopbackground, SPIF_UPDATEINIFILE);
				}

				hCurrentDesktop = hwnd;
				SetTimer(hwnd, 0, UpdateInterval, NULL);
			}
		}
	}
	LCClose(step);

	AddBangCommand("!XVWMXNext", BangNext);
	AddBangCommand("!XVWMXPrev", BangPrev);
	AddBangCommand("!XVWMXGoto", BangGoto);
}

void BangGoto(HWND caller, char* args)
{
	if (args) SwitchTo(atoi(args));
	else SwitchTo(1);
}

void BangPrev(HWND caller, char* args)
{
	SwitchTo(CurrentDesktop-1);
}

void BangNext(HWND caller, char* args)
{
	SwitchTo(CurrentDesktop+1);
}

BOOL CALLBACK SetDesktopHandleEnumProc(HWND hwnd, LPARAM lParam)
{
	WM* p = (WM*)GetProp(hwnd, szAppName);

	if (p)
	{
		if (p->num == CurrentDesktop) 
		{
			hCurrentDesktop = hwnd;
			return FALSE;
		}
	}

	return TRUE;
}

void SwitchTo(int num)
{
	// Minimize all visible windows and set prop
	EnumWindows((WNDENUMPROC)SaveDesktopEnumProc, NULL);
	KillTimer(hCurrentDesktop, 0);

	if (num < 1) CurrentDesktop = VALID_WMS;
	else if (num > VALID_WMS) CurrentDesktop = 1;
	else CurrentDesktop = num;

	EnumWindows((WNDENUMPROC)SetDesktopHandleEnumProc, NULL);

	WM* p = (WM*)GetProp(hCurrentDesktop, szAppName);
	if (p)
	{
		if (_strnicmp(p->desktopbackground, ".none", 5))
		{
			SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, p->desktopbackground, SPIF_UPDATEINIFILE);
		}
	}

	// Restore all windows with new desktop prop
	EnumWindows((WNDENUMPROC)SetDesktopEnumProc, NULL);
	SetTimer(hCurrentDesktop, 0, UpdateInterval, NULL);
}