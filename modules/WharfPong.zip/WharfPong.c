#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "WharfPong.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "WharfPong"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void LoadSetup();
void SaveSetup();

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HMENU Popup;
HBITMAP backImage = NULL;

int START=0;
int LEFT=0;
int RIGHT=0;
int UP=0;
int DOWN=0;
int NEVERSTARTED=1;
int PIXELS=1;
int VOLLEYS=0;
int ORIGPIXELS=1;
int LSCORE=0;
int LGAMES=0;
int RSCORE=0;
int RGAMES=0;
int SHOWSCORES=1;
int SHOWGAMES=1;
int DEMO=0;
int NUMPOINTS=21;

int Timer=0;
int CursorTimer=0;
int first=1;
RECT lpaddle;
RECT rpaddle;
RECT pong;
RECT r;

PAINTSTRUCT ps;
char temp[100] = "";
char ini[25] = "";
HBRUSH hbrback, hbrleft, hbrright, hbrpong;
COLORREF cback, cleft, cright, cpong, clscore, crscore, clgames, crgames;
HFONT hf,oldFont;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    if (wharfData.borderSize < 0)
        wharfData.borderSize = 0;
	wndSize = 64-wharfData.borderSize*2;

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Restart Game");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 105, "&Show Scores");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 109, "Show &Games");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 107, "R&eset Scores");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, "&Demo Mode");
	AppendMenu(Popup, MF_SEPARATOR, 101, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "S&low");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 103, "&Medium");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 104, "&Fast");
	AppendMenu(Popup, MF_SEPARATOR, 101, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 108, "&About WharfPong");

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }
	
	sprintf(ini, "%smodules.ini", wharfData.lsPath);
	LoadSetup();

	if (SHOWSCORES) CheckMenuItem(Popup, 105, MF_CHECKED);
	if (SHOWGAMES) CheckMenuItem(Popup, 109, MF_CHECKED);

	GetClientRect(hMainWnd, &r);
    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));

    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	ORIGPIXELS = PIXELS;
	switch (PIXELS)
	{
	case 1:
		CheckMenuItem(Popup, 102, MF_CHECKED);
		break;
	case 2:
		CheckMenuItem(Popup, 103, MF_CHECKED);
		break;
	case 3:
		CheckMenuItem(Popup, 104, MF_CHECKED);
		break;
	}

	if (DEMO)
	{
		CheckMenuItem(Popup, 106, MF_CHECKED);
		SendMessage(hMainWnd, WM_LBUTTONUP, 0, 0);
	}

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	SaveSetup();
    DeleteObject(backImage);
    DeleteObject(hbrback);
    DeleteObject(hbrleft);
    DeleteObject(hbrright);
	DeleteObject(hbrpong);
	DeleteObject(hf);
    DeleteObject(oldFont);
    DestroyMenu(Popup);
    DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
	KillTimer(hMainWnd, Timer);
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{
				if (!backImage)
				{
					HDC hdc = GetDC(parent);
					HDC buf = CreateCompatibleDC(NULL);

					backImage = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, backImage);
					BitBlt(buf, 0, 0, 64, 64, hdc, 0, 0, SRCCOPY);

					ReleaseDC(hdc,hwnd);
					DeleteDC(buf);
				}
				{
					HDC hdc = BeginPaint(hwnd,&ps);
									
					// Buffer DC - we draw everything to this
					HDC buf = CreateCompatibleDC(NULL);
					// Source DC - we use this to copy from
					// the back image
					HDC src = CreateCompatibleDC(NULL);
					// Buffer BMP - holds the data
					HDC bufBMP = CreateCompatibleBitmap(hdc, 64, 64);

					SelectObject(buf, bufBMP);

					
					// Setup the base background
					FillRect(buf, &r, hbrback);
					if (backImage)
					{
						SelectObject(src, backImage);
						BitBlt(buf, 0, 0, 64, 64, src, 0, 0, SRCCOPY);
					}
			
					if (first)
					{
						lpaddle.left = r.left + 5;
						lpaddle.top = r.top + 10;
						lpaddle.bottom = lpaddle.top + 15;
						lpaddle.right = lpaddle.left + 3;	
					}
                
					if (first)
					{
						rpaddle.right = r.right - 5;
						rpaddle.bottom = r.bottom - 10;
						rpaddle.left = rpaddle.right - 3;
						rpaddle.top = rpaddle.bottom - 15;
					}

					if (first)
					{
						pong.left = rpaddle.left - 4;
						pong.right = rpaddle.left;
						pong.top = rpaddle.top + 6;
						pong.bottom = pong.top + 4;
						first = 0;
					}
                
					if (pong.right > rpaddle.left)
					{
						pong.right = rpaddle.left;
						pong.left = rpaddle.left - 4;
					}
					else if (pong.left < lpaddle.right)
					{
						pong.left = lpaddle.right;
						pong.right = lpaddle.right + 4;
					}
					FillRect(buf, &pong, hbrpong);
					FillRect(buf, &lpaddle, hbrleft);
					FillRect(buf, &rpaddle, hbrright);

					if (SHOWSCORES)
					{
						hf = GetStockObject(ANSI_FIXED_FONT); 
						oldFont = SelectObject(buf, hf); 
						SetBkMode(buf, TRANSPARENT);
						SetTextColor(buf, clscore);
						sprintf(temp, "%d", LSCORE);
						TextOut( buf, 1, 50, temp, strlen(temp));
						SetTextColor(buf, crscore);
						sprintf(temp, "%d", RSCORE);
						TextOut( buf, 45, 50, temp, strlen(temp));
					}

					if (SHOWGAMES)
					{
						if (!SHOWSCORES)
						{
							hf = GetStockObject(ANSI_FIXED_FONT); 
							oldFont = SelectObject(buf, hf); 
							SetBkMode(buf, TRANSPARENT);
						}
						SetTextColor(buf, clgames);
						sprintf(temp, "%d", LGAMES);
						TextOut( buf, 1, 1, temp, strlen(temp));
						SetTextColor(buf, crgames);
						sprintf(temp, "%d", RGAMES);
						TextOut(buf, 45, 1, temp, strlen(temp));
					}
					// Paint contents to screen DC
					// 1 nice clean blt
					BitBlt(hdc, 0, 0, 64, 64, buf, 0, 0, SRCCOPY);
                               
					EndPaint(hwnd,&ps);
					DeleteDC(buf);
					DeleteDC(src);
					DeleteObject(bufBMP);
				}
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	    case WM_RBUTTONUP:
        {
			PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
		}
		return 0;
		case WM_LBUTTONUP:
		{
			if (!START)
			{
				Timer = SetTimer(hwnd, 1, 50, NULL);
				START = 1;
				if (NEVERSTARTED)
				{
					LEFT = 1;
					if (rpaddle.top % 2)
					{
						UP = 1;
						DOWN = 0;
					}
					else
					{
						UP = 0;
						DOWN = 1;
					}
				}
			}
			else
			{
				KillTimer(hwnd, Timer);
				START = 0;
				if (NEVERSTARTED)
				{
					LEFT = 0;
					UP = 0;
				}
			}
			NEVERSTARTED = 0;
		}
		return 0;
        case WM_RBUTTONDOWN:
			{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			}
			return 0;
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_MOUSEMOVE:
		{
			SetCursor(NULL);
			CursorTimer = SetTimer(hwnd, 2, 50, NULL);

			if (!DEMO)
			{
				rpaddle.top = r.top+(int)HIWORD(lParam);
				rpaddle.bottom = rpaddle.top + 15;
				if (!START && NEVERSTARTED)
				{
					pong.right = rpaddle.left;
					pong.left = pong.right - 4;
					pong.top = rpaddle.top + 6;
					pong.bottom = pong.top + 4;
				}
				InvalidateRect(hwnd, &r, TRUE);
			}
		}
		return 0;
		case WM_TIMER:
		{
			switch (wParam)
			{
				case 1:
				{
					int RAND_UPDOWN = 0;
					int PADDLE_SPEED = 0;
					int PONG_SPEED = 0;
					srand( (unsigned)time( NULL ) );
					PADDLE_SPEED = rand() % 5 + 2;
					RAND_UPDOWN = rand() % 2;
					
					if (DEMO) { PIXELS = ORIGPIXELS + 2; }

					if (VOLLEYS == 6 && PIXELS < 6 && !DEMO)
					{
						VOLLEYS = 0;
						PIXELS++;
					}
					
					if (pong.left <= r.left || pong.right >= r.right)
					{
						SendMessage(hwnd, WM_COMMAND, 100, 0);
						return 0;
					}

					if (pong.left > lpaddle.right && LEFT)
					{
						pong.left -= PIXELS;
						pong.right -= PIXELS;
					}
					else if (pong.right < rpaddle.left && RIGHT)
					{
						pong.left += PIXELS;
						pong.right += PIXELS;
					}
					else if (pong.left <= lpaddle.right)
					{
						if (pong.top <= lpaddle.bottom && pong.bottom >= lpaddle.top)
						{
							LEFT = 0;
							RIGHT = 1;
							pong.left += PIXELS;
							pong.right += PIXELS;
							
							if (pong.top < lpaddle.top + (lpaddle.bottom - lpaddle.top)/2)
							{
								UP = 1;
								DOWN = 0;
							}
							else
							{
								UP = 0;
								DOWN = 1;
							}
						}
						else
						{
							if (RSCORE == NUMPOINTS-1) 
							{ 
								RSCORE = -1;
								LSCORE = 0;
								if (RGAMES == 99) { RGAMES = -1; }
								RGAMES++; 
							}
							RSCORE++;
							SendMessage(hwnd, WM_COMMAND, 100, 0);
							return 0;
						}
					}
					else if (pong.right >= rpaddle.left)
					{
						if (pong.top <= rpaddle.bottom && pong.bottom >= rpaddle.top)
						{
							LEFT = 1;
							RIGHT = 0;
							pong.left -= PIXELS;
							pong.right -= PIXELS;
							VOLLEYS++;
							if (pong.top < rpaddle.top + (rpaddle.bottom - rpaddle.top)/2)
							{
								UP = 1;
								DOWN = 0;
							}
							else
							{
								UP = 0;
								DOWN = 1;
							}
						}
						else
						{
							if (LSCORE == NUMPOINTS-1)
							{ 
								LSCORE = -1;
								RSCORE = 0;
								if (LGAMES == 99) { LGAMES = -1; }
								LGAMES++; 
							}
							LSCORE++;
							SendMessage(hwnd, WM_COMMAND, 100, 0);
							return 0;
						}
					}

					if (pong.top > r.top && UP)
					{
						pong.top -= PIXELS;
						pong.bottom -= PIXELS;
					}
					else if (pong.bottom < r.bottom && DOWN)
					{
						pong.top += PIXELS;
						pong.bottom += PIXELS;
					}
					else if (pong.top <= r.top)
					{
						UP = 0;
						DOWN = 1;
						pong.top += PIXELS;
						pong.bottom += PIXELS;
					}
					else if (pong.bottom >= r.bottom)
					{
						UP = 1;
						DOWN = 0;
						pong.top -= PIXELS;
						pong.bottom -= PIXELS;
					}
					
					if (LEFT && pong.left < 44)
					{
						if ((lpaddle.top + ((lpaddle.bottom - lpaddle.top)/2)) < pong.top)
						{
							lpaddle.top += PADDLE_SPEED;
							lpaddle.bottom += PADDLE_SPEED;
						}
						else if ((lpaddle.top + ((lpaddle.bottom - lpaddle.top)/2)) > pong.top)
						{
							lpaddle.top -= PADDLE_SPEED;
							lpaddle.bottom -= PADDLE_SPEED;
						}
						else if ((lpaddle.top + ((lpaddle.bottom - lpaddle.top)/2)) == pong.top) { }
					}
					else if (RIGHT && DEMO && pong.right > 20)
					{
						if ((rpaddle.top + ((rpaddle.bottom - rpaddle.top)/2)) < pong.top)
						{
							rpaddle.top += PADDLE_SPEED;
							rpaddle.bottom += PADDLE_SPEED;
						}
						else if ((rpaddle.top + ((rpaddle.bottom - rpaddle.top)/2)) > pong.top)
						{
							rpaddle.top -= PADDLE_SPEED;
							rpaddle.bottom -= PADDLE_SPEED;
						}
						else if ((rpaddle.top + ((rpaddle.bottom - rpaddle.top)/2)) == pong.top) { }
					}
					InvalidateRect(hwnd, &r, TRUE);
				}
				return 0;
				case 2:
				{
					POINT pos;
					RECT rtemp;

					KillTimer(hwnd, CursorTimer);
					GetCursorPos(&pos);
					GetWindowRect(hwnd, &rtemp);
					if (((pos.x < rtemp.left)||(pos.x > rtemp.right))||
						((pos.y < rtemp.top)|| (pos.y > rtemp.bottom)))
					{
						SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
					}
					else
					{
						SetCursor(NULL);
					}
				}
				return 0;
			}
		}
		case WM_COMMAND:
		{
			switch (wParam)
			{
			case 100:
				{
					KillTimer(hwnd,Timer);
					START = 0;
					NEVERSTARTED = 1;
					LEFT = 0;
					RIGHT = 0;
					UP = 0;
					DOWN = 0;
					PIXELS = ORIGPIXELS;
					VOLLEYS = 0;
					if (DEMO) 
					{
						Sleep(250);
						SendMessage(hwnd, WM_LBUTTONUP, 0, 0);
					}

					pong.right = rpaddle.left;
					pong.left = pong.right - 4;
					pong.top = rpaddle.top + 6;
					pong.bottom = pong.top + 4;

					InvalidateRect(hwnd, &r, TRUE);
				}
				return 0;
			case 102:
				{
					CheckMenuItem(Popup, 102, MF_CHECKED);
					CheckMenuItem(Popup, 103, MF_UNCHECKED);
					CheckMenuItem(Popup, 104, MF_UNCHECKED);
					ORIGPIXELS = PIXELS = 1;
					SendMessage(hwnd, WM_COMMAND, 100, 0);
				}
				return 0;
			case 103:
				{
					CheckMenuItem(Popup, 103, MF_CHECKED);
					CheckMenuItem(Popup, 102, MF_UNCHECKED);
					CheckMenuItem(Popup, 104, MF_UNCHECKED);
					ORIGPIXELS = PIXELS = 2;
					SendMessage(hwnd, WM_COMMAND, 100, 0);
				}
				return 0;
			case 104:
				{
					CheckMenuItem(Popup, 104, MF_CHECKED);
					CheckMenuItem(Popup, 103, MF_UNCHECKED);
					CheckMenuItem(Popup, 102, MF_UNCHECKED);
					ORIGPIXELS = PIXELS = 3;
					SendMessage(hwnd, WM_COMMAND, 100, 0);
				}
				return 0;
			case 105:
				{
					if (SHOWSCORES)
					{
						CheckMenuItem(Popup, 105, MF_UNCHECKED);
						SHOWSCORES = 0;
						InvalidateRect(hwnd, &r, TRUE);
					}
					else
					{
						CheckMenuItem(Popup, 105, MF_CHECKED);
						SHOWSCORES = 1;
						InvalidateRect(hwnd, &r, TRUE);
					}
				}
				return 0;
			case 106:
				{
					if (DEMO)
					{
						CheckMenuItem(Popup, 106, MF_UNCHECKED);
						DEMO = 0;
						SendMessage(hwnd, WM_COMMAND, 100, 0);
					}
					else
					{
						CheckMenuItem(Popup, 106, MF_CHECKED);
						DEMO = 1;
						SendMessage(hwnd, WM_COMMAND, 100, 0);
					}
				}
				return 0;
			case 107:
				{
					LSCORE = RSCORE = LGAMES = RGAMES = 0;;
					InvalidateRect(hwnd, &r, TRUE);
				}
				return 0;
			case 108:
				{
					MessageBox(NULL, "WharfPong V1.4\n\n - Written By: MrJukes\n - Helped: mian\n\nE-Mail me at mrjukes@purdue.edu\n","WharfPong V1.4", MB_OK | MB_SETFOREGROUND | MB_ICONINFORMATION);
				}
				return 0;
			case 109:
				{
					if (SHOWGAMES)
					{
						CheckMenuItem(Popup, 109, MF_UNCHECKED);
						SHOWGAMES = 0;
						InvalidateRect(hwnd, &r, TRUE);
					}
					else
					{
						CheckMenuItem(Popup, 109, MF_CHECKED);
						SHOWGAMES = 1;
						InvalidateRect(hwnd, &r, TRUE);
					}
				}
				return 0;
			}
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

void LoadSetup()
{
	SHOWSCORES = GetPrivateProfileInt("WharfPong", "ShowScores", 1, ini);
	if (SHOWSCORES != 0 && SHOWSCORES != 1) { SHOWSCORES = 1; }
	SHOWGAMES = GetPrivateProfileInt("WharfPong", "ShowGames", 1, ini);
	if (SHOWGAMES != 0 && SHOWGAMES != 1) { SHOWGAMES = 1; }
	NUMPOINTS = GetPrivateProfileInt("WharfPong", "PointsInGame", 21, ini);
	if (NUMPOINTS > 99) { NUMPOINTS = 21; }
	DEMO = GetPrivateProfileInt("WharfPong", "Demo", 0, ini);
	if (DEMO != 0 && DEMO != 1) { DEMO = 0; }
	LSCORE = GetPrivateProfileInt("WharfPong", "LeftScore", 0, ini);
	if (LSCORE > NUMPOINTS-1 && LSCORE != 69) LSCORE = 0;
	RSCORE = GetPrivateProfileInt("WharfPong", "RightScore", 0, ini);
	if (RSCORE > NUMPOINTS-1 && RSCORE != 69) RSCORE = 0;
	LGAMES = GetPrivateProfileInt("WharfPong", "LeftGames", 0, ini);
	if (LGAMES > 99) LGAMES = 0;
	RGAMES = GetPrivateProfileInt("WharfPong", "RightGames", 0, ini);
	if (RGAMES > 99) RGAMES = 0;
	PIXELS = GetPrivateProfileInt("WharfPong", "Speed", 1, ini);
	if (PIXELS > 3) PIXELS=1;

	cleft = GetPrivateProfileInt("WharfPong", "LeftPaddleColor", 0x00FFFFFF, ini);
	cright = GetPrivateProfileInt("WharfPong", "RightPaddleColor", 0x00FFFFFF, ini);
	cpong = GetPrivateProfileInt("WharfPong", "PongColor", 0x00FFFFFF, ini);
	clscore = GetPrivateProfileInt("WharfPong", "LeftScoreColor", 0x00FFFFFF, ini);
	crscore = GetPrivateProfileInt("WharfPong", "RightScoreColor", 0x00FFFFFF, ini);
	clgames = GetPrivateProfileInt("WharfPong", "LeftGamesColor", 0x00FFFFFF, ini);
	crgames = GetPrivateProfileInt("WharfPong", "RightGamesColor", 0x00FFFFFF, ini);

	cback = 0x00000000;
	hbrback = CreateSolidBrush(cback);
	hbrleft = CreateSolidBrush(cleft);
	hbrright = CreateSolidBrush(cright);
	hbrpong = CreateSolidBrush(cpong);
}

void SaveSetup()
{
	char localtemp[10];
	
	sprintf(localtemp, "%d", SHOWSCORES);
	WritePrivateProfileString("WharfPong", "ShowScores", localtemp, ini);
	sprintf(localtemp, "%d", SHOWGAMES);
	WritePrivateProfileString("WharfPong", "ShowGames", localtemp, ini);
	sprintf(localtemp, "%d", DEMO);
	WritePrivateProfileString("WharfPong", "Demo", localtemp, ini);
	sprintf(localtemp, "%d", LSCORE);
	WritePrivateProfileString("WharfPong", "LeftScore", localtemp, ini);
	sprintf(localtemp, "%d", RSCORE);
	WritePrivateProfileString("WharfPong", "RightScore", localtemp, ini);
	sprintf(localtemp, "%d", LGAMES);
	WritePrivateProfileString("WharfPong", "LeftGames", localtemp, ini);
	sprintf(localtemp, "%d", RGAMES);
	WritePrivateProfileString("WharfPong", "RightGames", localtemp, ini);
	sprintf(localtemp, "%d", ORIGPIXELS);
	WritePrivateProfileString("WharfPong", "Speed", localtemp, ini);
}