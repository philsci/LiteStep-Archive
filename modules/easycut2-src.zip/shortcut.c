// EasyCuts modified source. All latest EasyCuts additions are
// marked inside '//EasyCuts1.5' comments

/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************
  29/01/99 - A. Heath
                Added Shortcut hiding using groups and 4 bang commands to
				select which groups to make visible
  30/10/89 - Cyberian (Fahim Farook)
				Added hints support for shortcuts
  19/09/98 - C. Boyda
                Fixed it so shortcuts can now overlay each other, and not
                overdraw each other, problem is ppl have to put the one
                they want to overlay the one in the background before it in
                step.rc unless we reverse the config file read for them.

 09/09/98 - C. Boyda
                Added transparent regions, removing double buffer bitmaps and
                fixed regions so overlapping shortcuts will work now.

 11/08/98 - D. Hodgkiss
                Added drag & drop support.  The filename is appeneded to the
                command line found in step.rc and then run

 01/08/98 - D. Hodgkiss
                Added ShortcutMouseOverSound and ShortcutClickSound commands

 31/07/98 - D. Hodgkiss
                This file contains the source for desktop shortcuts
 30/10/98 - T. Engel
 		Better Shortcut behaviour.

****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <time.h>
#include <stdio.h>
#include <malloc.h>
#include <commctrl.h>
#include <dbt.h>

#include "shortcut.h"
#include "lsapi.h"

// -------------------------------------------------------------------------------------------------------

const char szAppName[] = "ShortcutClass"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.37 $"; // Our Version 
const char rcsId[] = "$Id: shortcut.c,v 1.37 1999/04/11 17:38:07 cyberian Exp $"; // The Full RCS ID.

// our window procedures
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// -------------------------------------------------------------------------------------------------------

void ReadConfig(void);
void CreateHints(HWND hWnd, char *txt, RECT *r);
void RemoveHints(HWND hWnd);
int GetShortcutByWnd(HWND hwnd);
BOOL CreateShortcut(int i);

// EasyCut
BOOL ReadLine(FILE *f, LPSTR szBuffer, DWORD dwLength);
char* StripLine(LPSTR szBuffer);
void SnapShot(HWND caller ,char* args);
void AddHook(void);
void DeleteHook(void);
void NewShortcut(char* file, POINT drop_point);
HBITMAP LoadPic(LPCSTR szImage, LPCSTR szFile, int snum);
LRESULT CALLBACK DesktopWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
long DesktopOldWndProc;
// EasyCut

// EasyCuts1.5
BOOL noShortcutMenu,AlwaysOnTop;
int Shortcutmode;
// EasyCuts1.5

/* Prototype for Bang Commands */
void BangShowShortcutGroup (HWND caller,char* args);
void BangHideShortcutGroup (HWND caller,char* args);
void BangToggleShortcutGroup (HWND caller,char* args);
void BangSwitchToShortcutGroups (HWND caller,char* args);

char szLitestepPath[256];
char szImagePath[256];
HINSTANCE dll;
HWND parent;
HWND desktop = NULL;
HWND refToplevel;
HWND shortcutHints = NULL;
int cnt = 0;
BOOL windowsHidden = TRUE;
BOOL noShortcutHints = FALSE;
int ScreenWidth = 1152, ScreenHeight = 864;
int numShortcuts = 0;
shortcutType *shortcuts = NULL;
char szMouseOverSound[256], szClickSound[256];

// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	
	dll = dllInst;
	parent = ParentWnd;
	
	strcpy(szLitestepPath, szPath);
	ReadConfig();
	if (!noShortcutHints) {
		shortcutHints = CreateWindow
			(TOOLTIPS_CLASS,
			(LPSTR) NULL,
			TTS_ALWAYSTIP,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			(HMENU) NULL,
			dll,
			NULL
			);
		if (!shortcutHints) {
			MessageBox(parent, "Error creating hints window", "Shortcut Hints Error", MB_OK);
			return 1;
		}
		SetWindowPos(shortcutHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	}
	
	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;
	
	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
	{
/*		MessageBox(ParentWnd, "Unable to find desktop", "Shortcuts", 0);
		return 1; */
		desktop = GetDesktopWindow();
	}
	
	{	// Register our window class
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.lpszClassName = szAppName;			   // our window class name
		wc.style = CS_DBLCLKS;
		
		if (!RegisterClass(&wc)) 
		{
			// Quick&dirty fix for nt
			MessageBox(parent,"Error registering window class","Shell_TickerClass",MB_OK);
			return 1;
		}
	}
	
	{
		FILE *f;
		
		f = LCOpen(NULL);
		if (f)
		{
			char	buffer[4096];
			char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], token7[4096], token8[4096], token9[4096], token10[4096], token11[4096], extra_text[4096], temp_token[4096], short_temp[5];
			char*	tokens[11];

			tokens[0] = token1;
			tokens[1] = token2;
			tokens[2] = token3;
			tokens[3] = token4;
			tokens[4] = token5;
			tokens[5] = token6;
			tokens[6] = token7;
			tokens[7] = token8;
			tokens[8] = token9;
			tokens[9] = token10;
			tokens[10] = token11;

			buffer[0] = 0;

			while (LCReadNextConfig (f, "*Shortcut", buffer, sizeof (buffer)))
			{
				int count;

				token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = token7[0] = token8[0] = token9[0] = token10[0] = token11[0] = extra_text[0] = temp_token[0] = short_temp[0] = '\0';

				count = LCTokenize (buffer, tokens, 11, extra_text);

				if (count >= 8) {

					BITMAP bmInfo;

					if (!shortcuts)
						shortcuts = (shortcutType *)malloc(sizeof(shortcutType));
					else
						shortcuts = realloc(shortcuts, (numShortcuts+1)*sizeof(shortcutType));

					memset(&shortcuts[numShortcuts], 0, sizeof(shortcutType));
					strcpy(shortcuts[numShortcuts].szName, token2);
					shortcuts[numShortcuts].x = atoi(token3);
					shortcuts[numShortcuts].y = atoi(token4);
					if (shortcuts[numShortcuts].x < 0) shortcuts[numShortcuts].x += ScreenWidth;
					if (shortcuts[numShortcuts].y < 0) shortcuts[numShortcuts].y += ScreenHeight;
					// EasyCut
					strcpy(shortcuts[numShortcuts].sz_bmpOff, token5);
					strcpy(shortcuts[numShortcuts].sz_bmpOn, token6);
					strcpy(shortcuts[numShortcuts].sz_bmpClick, token7);
					// EasyCut

					/* Default group allocation */
					shortcuts[numShortcuts].bVisible = TRUE;
					shortcuts[numShortcuts].uGroup = 0;

					/* Check if next token is group entry */
					if(token8[0] == '#')
					{
						shortcuts[numShortcuts].uGroup = atoi(&token8[1]);
						// EasyCut
						strcpy(shortcuts[numShortcuts].sz_Group, token8);
						// EasyCut
						/* Check for hide character */

                                            // EasyCuts1.5
                                            if (strstr(strlwr(token8), "h")) {
                                             shortcuts[numShortcuts].bVisible = FALSE;
                                            }
                                            if (strstr(strlwr(token8), "t")) {                                            
                                            shortcuts[numShortcuts].alwaysontop = TRUE;
                                            }
                                            if (strstr(strlwr(token8), "m")) {shortcuts[numShortcuts].mouseover = TRUE;}

						if(token8[strlen(token8) - 1] == 'H')
						{
							shortcuts[numShortcuts].bVisible = FALSE;
						}
                                            // EasyCuts1.5

						/* Now carry on as before with next token */
						strcpy(short_temp, token9 +(strlen(token9) -4));

						if (!stricmp(short_temp, ".wav") || !stricmp(token9, ".none")) {
							strcpy(shortcuts[numShortcuts].szSoundOnMouseOver, token9);
							strcpy(shortcuts[numShortcuts].szSoundOnMouseClicked, token10);
							strcpy(shortcuts[numShortcuts].szCommand, token11);
							strcpy(shortcuts[numShortcuts].szParameters, extra_text);
						} else {
							temp_token[0] = '\0';
							strcpy(temp_token,token10);
							strcat(temp_token," ");
							strcat(temp_token,token11);
							strcat(temp_token," ");
							strcat(temp_token,extra_text);
							strcpy(shortcuts[numShortcuts].szCommand, token9);
							strcpy(shortcuts[numShortcuts].szParameters, temp_token);
						}
					}
					else
					{
						strcpy(short_temp, token8 +(strlen(token8) -4));

						if (!stricmp(short_temp, ".wav") || !stricmp(token8, ".none")) {
							strcpy(shortcuts[numShortcuts].szSoundOnMouseOver, token8);
							strcpy(shortcuts[numShortcuts].szSoundOnMouseClicked, token9);
							strcpy(shortcuts[numShortcuts].szCommand, token10);
							temp_token[0] = '\0';
							strcpy(temp_token,token11);
							strcat(temp_token," ");
							strcat(temp_token,extra_text);
							strcpy(shortcuts[numShortcuts].szParameters, temp_token);
						} else {
							temp_token[0] = '\0';
							strcpy(temp_token,token9);
							strcat(temp_token," ");
							strcat(temp_token,token10);
							strcat(temp_token," ");
							strcat(temp_token,token11);
							strcat(temp_token," ");
							strcat(temp_token,extra_text);
							strcpy(shortcuts[numShortcuts].szCommand, token8);
							strcpy(shortcuts[numShortcuts].szParameters, temp_token);
						}
					}
					// EasyCut
					shortcuts[numShortcuts].bmpOff = LoadPic(token5, NULL, numShortcuts);
					shortcuts[numShortcuts].bmpOn = LoadPic(token6, NULL, numShortcuts);
					shortcuts[numShortcuts].bmpClick = LoadPic(token7, NULL, numShortcuts);
					// EasyCut
					if (shortcuts[numShortcuts].bmpOff)
					{
						int res = GetObject(shortcuts[numShortcuts].bmpOff, sizeof(bmInfo), &bmInfo);
						if (res > 0)
						{
							shortcuts[numShortcuts].offSize.cx = bmInfo.bmWidth;
							shortcuts[numShortcuts].offSize.cy = bmInfo.bmHeight;
						} else {
							shortcuts[numShortcuts].offSize.cx = 64;
							shortcuts[numShortcuts].offSize.cy = 64;
						}
					}
					if (shortcuts[numShortcuts].bmpOn)
					{
						int res = GetObject(shortcuts[numShortcuts].bmpOn, sizeof(bmInfo), &bmInfo);
						if (res > 0)
						{
							shortcuts[numShortcuts].onSize.cx = bmInfo.bmWidth;
							shortcuts[numShortcuts].onSize.cy = bmInfo.bmHeight;
						} else {
							shortcuts[numShortcuts].onSize.cx = 64;
							shortcuts[numShortcuts].onSize.cy = 64;
						}
					}
					if (shortcuts[numShortcuts].bmpClick)
					{
						int res = GetObject(shortcuts[numShortcuts].bmpClick, sizeof(bmInfo), &bmInfo);
						if (res > 0)
						{
							shortcuts[numShortcuts].clickSize.cx = bmInfo.bmWidth;
							shortcuts[numShortcuts].clickSize.cy = bmInfo.bmHeight;
						} else {
							shortcuts[numShortcuts].clickSize.cx = 64;
							shortcuts[numShortcuts].clickSize.cy = 64;
						}
					}

					shortcuts[numShortcuts].uTimer = 0;

					CreateShortcut(numShortcuts);
					numShortcuts++;
				}
			}
			LCClose(f);
		}
	}

	/* Regsiter the Bang Commands */
	AddBangCommand("!SHOWSHORTCUTGROUP", BangShowShortcutGroup);
	AddBangCommand("!HIDESHORTCUTGROUP", BangHideShortcutGroup);
	AddBangCommand("!TOGGLESHORTCUTGROUP", BangToggleShortcutGroup);
	AddBangCommand("!SWITCHTOSHORTCUTGROUP", BangSwitchToShortcutGroups);
	// EasyCut
	AddBangCommand("!Snapshot", SnapShot);
	AddHook();
	// EasyCut
	return 0;
}

// -------------------------------------------------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case LM_GETREVID:
			{
				char *buf = (char *) lParam;

				if (wParam == 0)
				{
					strcpy(buf, "shortcut.dll: ");
					strcat(buf, &rcsRevision[11]);
					buf[strlen(buf)-1] = '\0';
				}
				else if (wParam == 1)
				{
					strcpy(buf, &rcsId[1]);
					buf[strlen(buf)-1] = '\0';
				} else
				{
					strcpy(buf, "");
				}
				return strlen(buf);

			}

	case WM_MOUSEMOVE:
		{
			MSG TooltipMessage;
			int i = GetShortcutByWnd(hwnd);

			if (i == -1) return 0;

                   //EasyCuts1.5
                   if ((Shortcutmode == 1) && (wParam == MK_LBUTTON)) {
                    int t = GetTickCount() + 1000;
                    while (GetTickCount() < t) {;}
                     if (GetKeyState(VK_LBUTTON))
                     {
                      SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE | 2, 0);
                      return 0;
                     }
                   }                 
                   //EasyCuts1.5

			if (!strcmpi(shortcuts[i].szCommand, ".none")) return 0;
			if (!shortcuts[i].state)
			{
				if (!noShortcutHints) {
					if (i >= 0) {
						TooltipMessage.hwnd=shortcuts[i].hwnd;
						TooltipMessage.message=message;
						TooltipMessage.wParam=wParam;
						TooltipMessage.lParam=lParam;
						SendMessage(shortcutHints,TTM_RELAYEVENT,0,(LPARAM)&TooltipMessage);
						SetWindowPos(shortcutHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
					}
				}

				if (shortcuts[i].szSoundOnMouseOver[0])
				{
					sndPlaySound(NULL, 0);
					sndPlaySound(shortcuts[i].szSoundOnMouseOver, SND_ASYNC|SND_NODEFAULT);
				} 
				else if (szMouseOverSound[0]) {
					sndPlaySound(NULL, 0);
					sndPlaySound(szMouseOverSound, SND_ASYNC|SND_NODEFAULT);
				}

				if (shortcuts[i].bmpOn)
				{
					RECT r;
					HRGN h;

					h = CreateRectRgn(0, 0, 0, 0);
					
					CombineRgn(h, shortcuts[i].transOnRgn, NULL, RGN_COPY);
					SetWindowRgn(shortcuts[i].hwnd, h, TRUE);

					shortcuts[i].state = 1;
					GetClientRect(hwnd, &r);
					InvalidateRect(hwnd, &r, TRUE);

					if (!shortcuts[i].uTimer)
					{
						shortcuts[i].uTimer = i;
						SetTimer (shortcuts[i].hwnd, i, 5, NULL);
					}
				}
			}
		}
		return 0;
		
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_CREATE:
		return 0;
	case WM_ERASEBKGND:
		return 1;
		
	case WM_TIMER:
		{
			int i = GetShortcutByWnd(hwnd);
		
			if (i == -1) return 0;
			if (!strcmpi(shortcuts[i].szCommand, ".none")) return 0;

			if (shortcuts[i].state)
			{
				POINT pos;
				RECT r;
				HRGN h = CreateRectRgn(0, 0, 0, 0);
				
				GetCursorPos(&pos);
				GetWindowRgn(hwnd, h);
				/* let's not do this if it's in state 3 (clicked), this way mouse over sounds won't play twice
				and we can actually view the clicked image till we move the mouse off - C. Boyda */
				if ((!PtInRegion(h, pos.x-shortcuts[i].x, pos.y-shortcuts[i].y))/* || (shortcuts[i].state == 3)*/)
				{
					if (shortcuts[i].bmpOff)
					{
						CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
						SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
					}

					shortcuts[i].state = 0;
					GetClientRect(hwnd, &r);
					InvalidateRect(hwnd, &r, TRUE);

					if (shortcuts[i].uTimer)
					{
						KillTimer (shortcuts[i].hwnd, i);
						shortcuts[i].uTimer = 0;
					}
				}
				else
					DeleteObject(h);
			}
		}
		return 0;
		
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			int i = GetShortcutByWnd(hwnd);
			HDC hdc = BeginPaint(hwnd,&ps);
			HDC src = CreateCompatibleDC(NULL);
			
			if (i != -1)
			{
				if (shortcuts[i].state == 0 && shortcuts[i].bmpOff)
				{
					SelectObject(src, shortcuts[i].bmpOff);
					BitBlt(hdc, 0, 0, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy, src, 0, 0, SRCCOPY);
				}
				if (shortcuts[i].state == 1 && shortcuts[i].bmpOn)
				{
					SelectObject(src, shortcuts[i].bmpOn);
					BitBlt(hdc, 0, 0, shortcuts[i].onSize.cx, shortcuts[i].onSize.cy, src, 0, 0, SRCCOPY);
				}
				if (shortcuts[i].state == 3 && shortcuts[i].bmpClick)
				{
					SelectObject(src, shortcuts[i].bmpClick);
					BitBlt(hdc, 0, 0, shortcuts[i].clickSize.cx, shortcuts[i].clickSize.cy, src, 0, 0, SRCCOPY);
				}
			}
			EndPaint(hwnd,&ps);
			DeleteDC(src);
		}
		return 0;
		
		
	case WM_LBUTTONDOWN:
		{                  
			int i;
			RECT r;

			i = GetShortcutByWnd(hwnd);
			if (i == -1)
                                return 0;

			if (shortcuts[i].bmpClick) {
				HRGN h;
				h = CreateRectRgn(0, 0, 0, 0);
				CombineRgn(h, shortcuts[i].transClickRgn, NULL, RGN_COPY);
				SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
			}
				
			shortcuts[i].state = 3;
			GetClientRect(hwnd, &r);
			InvalidateRect(hwnd, &r, TRUE);
			
			if (!shortcuts[i].uTimer) {
				shortcuts[i].uTimer =  i;
				SetTimer (shortcuts[i].hwnd, i, 5, NULL);
			}

			if (shortcuts[i].szSoundOnMouseClicked[0]) {
				sndPlaySound(NULL, 0);
				sndPlaySound(shortcuts[i].szSoundOnMouseClicked, SND_ASYNC|SND_NODEFAULT);
			}
			else if (szClickSound[0]) {
				sndPlaySound(NULL, 0);
				sndPlaySound(szClickSound, SND_ASYNC|SND_NODEFAULT);
			}

		}
		return 0;

	case WM_LBUTTONUP:
		{
			int i;
			RECT r;

			i = GetShortcutByWnd(hwnd);
			if (i == -1)
				return 0;

			shortcuts[i].state = 0;
			GetClientRect(hwnd, &r);
			InvalidateRect(hwnd, &r, TRUE);

			if (shortcuts[i].bmpOff) {
				HRGN h;
				h = CreateRectRgn(0, 0, 0, 0);
				CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
				SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
			}

			if (!shortcuts[i].uTimer) {
				shortcuts[i].uTimer =  i;
				SetTimer (shortcuts[i].hwnd, i, 5, NULL);
			}

			if (!strcmpi(shortcuts[i].szCommand, ".none"))
				return 0;
			else {
				SHELLEXECUTEINFO si;

				if (shortcuts[i].szCommand[0] == '!') {
					ParseBangCommand(shortcuts[i].hwnd, shortcuts[i].szCommand, shortcuts[i].szParameters);
				} else {
					char workDirectory[MAX_PATH];
					char drive[_MAX_DRIVE];
					char dir[_MAX_DIR];
		
					_splitpath(shortcuts[i].szCommand, drive, dir, NULL, NULL);
					strcpy(workDirectory, drive);
					strcat(workDirectory, dir);
					memset(&si, 0, sizeof(si));
					si.cbSize = sizeof(SHELLEXECUTEINFO);
					si.lpDirectory = workDirectory;
					si.lpVerb = NULL;
					si.nShow = 1;
					si.fMask = SEE_MASK_DOENVSUBST;
					si.lpFile = shortcuts[i].szCommand;
					si.lpParameters = shortcuts[i].szParameters;
					ShellExecuteEx(&si);
				}
			}
		}
		return 0;
	
	case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS *lpwp = (WINDOWPOS*)lParam;
			lpwp->flags |= SWP_NOZORDER;
		}
		return 0;
		
	case WM_MOUSEACTIVATE:
		PostMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam)); // Close any popup open
		if (HIWORD(lParam) == WM_LBUTTONDOWN) // te 10/30/98, Windows seems to be eating this?
			PostMessage(hwnd, WM_LBUTTONDOWN, 0, 0);
		return MA_ACTIVATE;
	case WM_ACTIVATE:
		SendMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		if (LOWORD(wParam)) SetActiveWindow(parent);
		return 0;
	case WM_RBUTTONUP: // Open popup menu
		// EasyCut
		/*SendMessage(parent, LM_POPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_RBUTTONDOWN: */
        // EasyCuts1.5
            if (Shortcutmode == 0) {SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE, 0);}
            return 0;
        // EasyCuts1.5
		// EasyCut
	case WM_MBUTTONDOWN:
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		{	
			PostMessage(parent,message,wParam,lParam);
		}
		return 0;
	// EasyCut
	/*case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(parent,WM_KEYDOWN,8889,0);
				return 0;
			default:
				break;
			}
		}
		break;*/
	case WM_MOVE:
	{
		int i = GetShortcutByWnd(hwnd);
		if (i == -1) return 0;

		shortcuts[i].x = LOWORD(lParam);
		shortcuts[i].y = HIWORD(lParam);
		return 0;
	}
	// EasyCut
	case WM_DROPFILES:
		{
			int numDropped, i;
			int numShort = GetShortcutByWnd(hwnd);
			char szFname[256], szArgs[256];
			SHELLEXECUTEINFO si;
			
			if (numShort == -1)
				return 0;
			numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
			for (i = 0; i < numDropped; i++)
			{
				DragQueryFile((HDROP) wParam, i, (char *)&szFname, sizeof(szFname));
				if (szFname && szFname[0])
				{
					char workDirectory[MAX_PATH];
					char drive[_MAX_DRIVE];
					char dir[_MAX_DIR];
		
					_splitpath(shortcuts[numShort].szCommand, drive, dir, NULL, NULL);
					strcpy(workDirectory, drive);
					strcat(workDirectory, dir);
					memset(&si, 0, sizeof(si));
					si.cbSize = sizeof(SHELLEXECUTEINFO);
					si.lpDirectory = workDirectory;
					si.lpVerb = NULL;
					si.nShow = 1;
					si.fMask = SEE_MASK_DOENVSUBST;
					si.lpFile = shortcuts[numShort].szCommand;
					strcpy(szArgs, shortcuts[numShort].szParameters);
					strcat(szArgs, " ");
					strcat(szArgs, szFname);
					si.lpParameters = szArgs;
					ShellExecuteEx(&si);
				}
			}
			DragFinish((HDROP) wParam);
		}
		return 0;
	}
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

int GetShortcutByWnd(HWND hwnd)
{
	int i;
	
	for (i=0;i<numShortcuts;i++)
		if (shortcuts[i].hwnd == hwnd)
			return i;
		return -1;
}

// -------------------------------------------------------------------------------------------------------
BOOL CreateShortcut(int i)
{
	HWND hWnd = NULL;
	RECT r;
	HRGN h;

	h = CreateRectRgn(0, 0, 0, 0);

// EasyCuts1.5
//        hWnd = CreateWindowEx(
//                WS_EX_TOOLWINDOW,                                       // exstyles 
//                szAppName,                                                      // our window class name
//                "",                                                                     // use description for a window title
//                WS_CHILD|WS_CLIPSIBLINGS,
//                0, 0,                                                           // position 
//                shortcuts[i].offSize.cx, shortcuts[i].offSize.cy,
//                desktop,                                                        // parent window
//                NULL,                                                           // no menu
//                dll,                                                            // hInstance of DLL
//                NULL);                                                          // no window creation data
if ((AlwaysOnTop) || shortcuts[i].alwaysontop)
{
 hWnd = CreateWindowEx(WS_EX_TOPMOST|WS_EX_TOOLWINDOW,szAppName,"",WS_POPUP,0, 0,shortcuts[i].offSize.cx, shortcuts[i].offSize.cy,desktop,NULL,dll,NULL);
} else {
 hWnd = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, "", WS_CHILD|WS_CLIPSIBLINGS,0, 0,shortcuts[i].offSize.cx, shortcuts[i].offSize.cy, desktop, NULL, dll, NULL);
}
// EasyCuts1.5

	if (!hWnd) 
	{						   
		MessageBox(parent,"Error creating window","Shortcuts",MB_OK);
		return FALSE;
	}
	if (i == 0)
	{
		int Msgs[10];
		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM) hWnd, (LPARAM) Msgs);
	}
	shortcuts[i].hwnd = hWnd;
	if (!noShortcutHints) {
		if (hWnd) {
			RECT r;
			GetClientRect (hWnd, &r);
			CreateHints (hWnd, shortcuts[i].szName, &r);
		}
	}
	
	shortcuts[i].transOnRgn = BitmapToRegion(shortcuts[i].bmpOn, RGB(255,0,255), 0x101010, 0, 0);
	shortcuts[i].transOffRgn = BitmapToRegion(shortcuts[i].bmpOff, RGB(255,0,255), 0x101010, 0, 0);
	shortcuts[i].transClickRgn = BitmapToRegion(shortcuts[i].bmpClick, RGB(255,0,255), 0x101010, 0, 0);

	if (shortcuts[i].bmpOff)
	{
		CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
		SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
	} else
	if (shortcuts[i].bmpOn)
	{
		CombineRgn(h, shortcuts[i].transOnRgn, NULL, RGN_COPY);
		SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
	} else
	if (shortcuts[i].bmpClick)
	{
		CombineRgn(h, shortcuts[i].transClickRgn, NULL, RGN_COPY);
		SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
	} else
		DeleteObject(h);

	SetWindowLong(shortcuts[i].hwnd, GWL_USERDATA, magicDWord);
	SetWindowPos(shortcuts[i].hwnd, 0, shortcuts[i].x, shortcuts[i].y, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	DragAcceptFiles(shortcuts[i].hwnd, TRUE);
	shortcuts[i].state = 0;
//	SetTimer(shortcuts[i].hwnd, i, 1, NULL);

	if(shortcuts[i].bVisible)	/* Only Show window if not initially hidden */
	{
		ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
		GetClientRect (shortcuts[i].hwnd, &r);
		InvalidateRect(shortcuts[i].hwnd, &r, TRUE);
	}
	
	return TRUE;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
	int i;

// EasyCuts1.5
//      int Msgs[10];   
// EasyCuts1.5

	if (!noShortcutHints) {
		if (shortcutHints) {
			DestroyWindow (shortcutHints);
			shortcutHints = NULL;
		}
	}
	if (shortcuts)
	{
		for (i = 0; i < numShortcuts; i++)
		{
			DragAcceptFiles(shortcuts[i].hwnd, FALSE);
			if (shortcuts[i].uTimer)
			{
				KillTimer (shortcuts[i].hwnd, i);
				shortcuts[i].uTimer = 0;
			}
			if (shortcuts[i].hwnd)
				DestroyWindow(shortcuts[i].hwnd);
			if (shortcuts[i].bmpOff)
				DeleteObject(shortcuts[i].bmpOff);
			if (shortcuts[i].bmpOn)
				DeleteObject(shortcuts[i].bmpOn);
			if (shortcuts[i].bmpClick)
				DeleteObject(shortcuts[i].bmpClick);
			if (shortcuts[i].transOnRgn)
				DeleteObject(shortcuts[i].transOnRgn);
			if (shortcuts[i].transOffRgn)
				DeleteObject(shortcuts[i].transOffRgn);
			if (shortcuts[i].transClickRgn)
				DeleteObject(shortcuts[i].transClickRgn);
		}
		free(shortcuts);
	}
	RemoveBangCommand("!SHOWSHORTCUTGROUP");
	RemoveBangCommand("!HIDESHORTCUTGROUP");
	RemoveBangCommand("!TOGGLESHORTCUTGROUP");
	RemoveBangCommand("!SWITCHTOSHORTCUTGROUP");
	RemoveBangCommand("!Snapshot");
	DeleteHook();
	UnregisterClass(szAppName,dllInst); // unregister window class
}


BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (!refToplevel && !(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
		refToplevel = hwnd;
		return FALSE; // !refTopmost;
	}
	return TRUE;
}

void ReadConfig (void)
{
	GetRCString("PixmapPath", szImagePath, "c:\\litestep\\images\\", 256);
	GetRCString("ShortcutMouseOverSound", szMouseOverSound, "", 256);
	GetRCString("ShortcutClickSound", szClickSound, "", 256);
	noShortcutHints = GetRCBool("NoShortcutHints", TRUE);
        // EasyCuts1.5
        noShortcutMenu = GetRCBool("NoShortcutMenu", TRUE); 
        AlwaysOnTop = GetRCBool("ShortcutsAlwaysOnTop", FALSE);
        Shortcutmode = GetRCInt("ShortcutDragMode", 0);
        // EasyCuts1.5
}

void CreateHints(HWND hWnd, char *txt, RECT *r) {
	TOOLINFO ti;    // tool information

	if (noShortcutHints)
	{
		return;
	}

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = *r;

	SendMessage(shortcutHints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void RemoveHints(HWND hWnd) {
	TOOLINFO ti;    // tool information
	RECT r={0,0,0,0};

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;

	SendMessage(shortcutHints, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void BangShowShortcutGroup (HWND caller,char* args)
{
	if (shortcuts)
	{
		int pGroup = atoi(args);
		int i;

		for (i = 0; i < numShortcuts; i++)
		{
			if(!shortcuts[i].bVisible && shortcuts[i].uGroup == pGroup)
			{
				if(shortcuts[i].hwnd)
				{
					ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
					shortcuts[i].bVisible = TRUE;
				}
			}
		}
	}
}

void BangHideShortcutGroup (HWND caller,char* args)
{
	if (shortcuts)
	{
		int pGroup = atoi(args);
		int i;

		if(pGroup)		/* Don't allow hiding of Group 0 */
		{
			for (i = 0; i < numShortcuts; i++)
			{
				if(shortcuts[i].bVisible && shortcuts[i].uGroup == pGroup)
				{
					if(shortcuts[i].hwnd)
					{
						ShowWindow(shortcuts[i].hwnd, SW_HIDE);
						shortcuts[i].bVisible = FALSE;
					}
				}
			}
		}	/* end if group */
	}
}

void BangToggleShortcutGroup (HWND caller,char* args)
{
	if (shortcuts)
	{
		int pGroup = atoi(args);
		int i;

		if(pGroup)
		{
			for (i = 0; i < numShortcuts; i++)
			{
				if(shortcuts[i].hwnd && shortcuts[i].uGroup == pGroup)
				{
					if(shortcuts[i].bVisible)
					{
						ShowWindow(shortcuts[i].hwnd, SW_HIDE);
						shortcuts[i].bVisible = FALSE;
					}
					else
					{
						ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
						shortcuts[i].bVisible = TRUE;
					}
				}
			}
		}	/* end if group */
	}
}

void BangSwitchToShortcutGroups (HWND caller,char* args)
{
	// Switch to group 0 will hide all other groups

	if (shortcuts)
	{
		int pGroup = atoi(args);
		int i;

		for (i = 0; i < numShortcuts; i++)
		{
			if(shortcuts[i].hwnd)
			{
				if(shortcuts[i].uGroup == pGroup && !shortcuts[i].bVisible)
				{
					ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
					shortcuts[i].bVisible = TRUE;
				}
				else if(shortcuts[i].uGroup != pGroup && shortcuts[i].uGroup != 0)
				{
					ShowWindow(shortcuts[i].hwnd, SW_HIDE);
					shortcuts[i].bVisible = FALSE;
				}
			}
		}		/* End for */
	}
}

// EasyCut
void SnapShot(HWND caller, char* args) {
  FILE *f, *sr;
  char line[256];
  char source[256];
  char target[256];
  int i, prefix_length;
  i = prefix_length = 0;

  strcpy(source, szLitestepPath);
  strcat(source, "\\step.rc");
  sr = fopen(source, "r");

  strcpy(target, szLitestepPath);
  strcat(target, "\\shortcut.rc");
  f = fopen(target, "w");

  prefix_length = strlen ("*shortcut");

// This bit copys the existing step.rc, and replaces existing *shortcut's
// (Replaces/updates in the same position they were already in)

  while (ReadLine(sr, line, sizeof (line)))
   {
    if (!strnicmp (StripLine(line), "*shortcut", prefix_length))
     {
      if (i < numShortcuts)
       {
        fprintf(f,"*Shortcut \"%s\" %d %d %s %s %s %s %s %s \"%s\" %s\n", shortcuts[i].szName ,shortcuts[i].x, shortcuts[i].y, shortcuts[i].sz_bmpOff, shortcuts[i].sz_bmpOn, shortcuts[i].sz_bmpClick, shortcuts[i].sz_Group ,shortcuts[i].szSoundOnMouseOver, shortcuts[i].szSoundOnMouseClicked,shortcuts[i].szCommand, shortcuts[i].szParameters);
        i++;
       }
     } else {fprintf(f, "%s", line);}
   }

// This bit adds any new shortcuts to the end of the file
for (i=i; i<numShortcuts; i++)
 {fprintf(f,"*Shortcut \"%s\" %d %d %s %s %s %s %s %s \"%s\" %s\n", shortcuts[i].szName ,shortcuts[i].x, shortcuts[i].y, shortcuts[i].sz_bmpOff, shortcuts[i].sz_bmpOn, shortcuts[i].sz_bmpClick, shortcuts[i].sz_Group ,shortcuts[i].szSoundOnMouseOver, shortcuts[i].szSoundOnMouseClicked,shortcuts[i].szCommand, shortcuts[i].szParameters);}

  fclose(f);
fclose(sr);
strcpy(line, szLitestepPath);
strcat(line, "\\step.org");

CopyFile(source, line, 0);
CopyFile(target, source, 0);
DeleteFile(target);
}

BOOL ReadLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	while (f && !feof (f))
	{
		if (!fgets (szBuffer, dwLength, f))
		{
			break;
		}
        return TRUE;
	}

	return FALSE;
}

char* StripLine (LPSTR szBuffer)
{
 char strip[256];
 int length;
 length = strlen (szBuffer);
 strcpy(strip, szBuffer);

 while (length && isspace (strip[0]))
 {
  length--;
  strcpy (strip, strip + 1);
 }

 while (length && isspace (strip[length-1]))
 {
  strip[--length] = '\0';
 }

return strip;
}
// Ender - END ADD

void AddHook(void)  // Ender - Added V1
{
	SetWindowLong(desktop, GWL_EXSTYLE, GetWindowLong(desktop, GWL_EXSTYLE) | WS_EX_ACCEPTFILES);
	DesktopOldWndProc = GetWindowLong(desktop, GWL_WNDPROC);
// EasyCuts1.5
//        SetWindowLong(desktop, GWL_WNDPROC, &DesktopWndProc);
        SetWindowLong(desktop, GWL_WNDPROC, (LONG) DesktopWndProc); // V1.1xxx
// EasyCuts1.5
}

void DeleteHook(void)  // Ender - Added V1
{
	SetWindowLong(desktop, GWL_WNDPROC, DesktopOldWndProc);
}

LRESULT CALLBACK DesktopWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) // Ender - Added V1
{
 switch (message)
 {
  case WM_DROPFILES:
  {
   int numDropped;
   char szFname[256];
   POINT drop_point; // V1 - (Edited for V1b)
               
   numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
   if (numDropped > 1)
   {
    MessageBox(0, "Please only drag one shortcut (to the desktop) at a time", "Error adding shortcut!", MB_OK|MB_TOPMOST);
    return 0;
   }

   DragQueryFile((HDROP) wParam, 0, szFname, sizeof(szFname));  // Edit - v1b
   if (szFname && szFname[0])
   {   
    DragQueryPoint((HDROP) wParam, &drop_point);
    NewShortcut(szFname, drop_point);
   }
   DragFinish((HDROP) wParam);
   return 0;
  }

// EasyCuts1.5
//   default: CallWindowProc(DesktopOldWndProc, hwnd, message, wParam, lParam);
   default: CallWindowProc((WNDPROC) DesktopOldWndProc, hwnd, message, wParam, lParam); // V1.1xxx
// EasyCuts1.5
 }
}

void NewShortcut(char* file, POINT drop_point) // Edited v1b
{
char sysdir[256], windir[256];
BITMAP bmInfo;
shortcuts = realloc(shortcuts, (numShortcuts+1)*sizeof(shortcutType));
memset(&shortcuts[numShortcuts], 0, sizeof(shortcutType));

GetWindowsDirectory(windir, 256);
GetSystemDirectory(sysdir, 256);

strcpy(shortcuts[numShortcuts].szName, file);
strcpy(shortcuts[numShortcuts].szCommand, file);

shortcuts[numShortcuts].x = drop_point.x; // Edited v1b
shortcuts[numShortcuts].y = drop_point.y; // Edited v1b

strcpy(shortcuts[numShortcuts].sz_bmpOff, ".winicon");
strcpy(shortcuts[numShortcuts].sz_bmpOn, ".winicon");
strcpy(shortcuts[numShortcuts].sz_bmpClick, ".winicon");

shortcuts[numShortcuts].bmpOff = LoadPic(shortcuts[numShortcuts].sz_bmpOff, NULL, numShortcuts);
shortcuts[numShortcuts].bmpOn = LoadPic(shortcuts[numShortcuts].sz_bmpOn, NULL, numShortcuts);
shortcuts[numShortcuts].bmpClick = LoadPic(shortcuts[numShortcuts].sz_bmpClick, NULL, numShortcuts);

shortcuts[numShortcuts].bVisible = TRUE;
shortcuts[numShortcuts].uGroup = 0;

if (shortcuts[numShortcuts].bmpOff)
{
 int res = GetObject(shortcuts[numShortcuts].bmpOff, sizeof(bmInfo), &bmInfo);
 if (res > 0)
 {
  shortcuts[numShortcuts].offSize.cx = bmInfo.bmWidth;
  shortcuts[numShortcuts].offSize.cy = bmInfo.bmHeight;
 } else {
  shortcuts[numShortcuts].offSize.cx = 64;
  shortcuts[numShortcuts].offSize.cy = 64;
 }
}

shortcuts[numShortcuts].uTimer = 0;

CreateShortcut(numShortcuts);
numShortcuts++;
}

HBITMAP LoadPic(LPCSTR szImage, LPCSTR szFile, int snum)
{
	HBITMAP hBitmap;
	char szImageBuf[MAX_PATH];

	strcpy(szImageBuf, szImage);

	if (!strnicmp (szImageBuf, ".winicon", 8))
	{
		// Returns the ASSOCIATED icon for this file/type
		HICON hIcon;
		SHFILEINFO shf;
		CHAR dir[255];
// EasyCuts1.5
//                SHGetFileInfo(shortcuts[snum].szCommand, NULL, &shf, sizeof(shf), SHGFI_ICON);
                SHGetFileInfo(shortcuts[snum].szCommand, 0, &shf, sizeof(shf), SHGFI_ICON);
// EasyCuts1.5

		if (shf.hIcon != NULL)
			hIcon = shf.hIcon;
		else {
			_searchenv(shortcuts[snum].szCommand, "PATH", dir);
			if (strlen(dir) != 0) {
// EasyCuts1.5
//                                SHGetFileInfo(dir, NULL, &shf, sizeof(shf), SHGFI_ICON);
                                SHGetFileInfo(dir, 0, &shf, sizeof(shf), SHGFI_ICON);
// EasyCuts1.5
				hIcon = shf.hIcon;
			}
		}
		if (hIcon) {
			hBitmap = BitmapFromIcon(hIcon);
			DestroyIcon (hIcon);
			return hBitmap;
		}
	} else {
		hBitmap = LoadLSImage(szImage, szFile);
		return hBitmap;
	}
	return NULL;
}
// EasyCut
/*
	$Log: shortcut.c,v $
	Revision 1.37  1999/04/11 17:38:07  cyberian
	
	Merged in load module unloading and reloading by Adrian Heath and changed all modules to accommodate the change
	
	Revision 1.33  1998/12/17 14:47:45  bryan
	Fixed a bug in shortcuts.
	
	Revision 1.32  1998/12/10 15:22:53  cyberian
	
	Changed all instances using SHELLEXECUTEINFO to set the working directory to the application directory unless otherwise specified
	
	Revision 1.29  1998/11/08 18:56:55  nerraw
	oops..my bad....it didn't do params right..but fixed now...
	
 */

