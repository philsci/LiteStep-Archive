#ifndef __ACTIVESHORTCUTS_H_
#define __ACTIVESHORTCUTS_H_

#include "../litestep/wharfdata.h"

typedef struct {
    char szCommand[256];
	char szParameters[256];
    char szName[256];
	char szSoundOnMouseOver[256];
	char szSoundOnMouseClicked[256];
    int x, y, state;
    HBITMAP bmpOff, bmpOn, bmpClick;
	HRGN transOnRgn, transOffRgn, transClickRgn;
    SIZE onSize, offSize, clickSize;
    HWND hwnd;
	UINT uTimer;
	// EasyCut
	char sz_bmpOn[256], sz_bmpOff[256], sz_bmpClick[256];
	char sz_Group[10];
	// EasyCut
	int uGroup;	/*Shortcut group*/
	BOOL bVisible;	/*Is window visible at present - Quicker than using IsWindowVisible*/

        // EasyCuts2
           BOOL alwaysontop, mouseover;
        // EasyCuts2 
    } shortcutType;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif


#endif

