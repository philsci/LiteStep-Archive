Autorecycle.dll

A simple module to recycle litestep everytime you save your step.rc. To use Autorecycle.dll unzip to you modules directory, load it in your step using a command like "Loadmodule $moduledir$autorecycle.dll", save your step and recycle. It should now work. Have fun.

Galois-
galois@techie.com
