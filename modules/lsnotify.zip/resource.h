//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mail.rc
//
#define IDB_BITMAP1                     101
#define IDB_OPEN1                       101
#define IDB_OPEN2                       111
#define IDB_OPEN3                       112
#define IDB_OPEN4                       113
#define IDB_OPEN5                       114
#define IDB_OPEN6                       115
#define IDB_CHECK1                      119
#define IDB_CHECK2                      124
#define IDB_CHECK3                      126
#define IDB_CHECK4                      127
#define IDB_CHECK5                      128
#define IDB_OPEN79                      141
#define IDB_OPEN72                      142
#define IDB_OPEN73                      143
#define IDB_OPEN74                      144
#define IDB_OPEN75                      145
#define IDB_OPEN76                      146
#define IDB_OPEN77                      147
#define IDB_OPEN78                      148
#define IDB_OPEN71                      149
#define IDB_OPEN7P                      151

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
