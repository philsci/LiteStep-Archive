/* This program was written by Bret Anderson aka MrJukes */

#include <windows.h>
#include <Winsock.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <commctrl.h>
#include "lsnotify.h"
#include "resource.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LsNotify"; // Name of Application, Window class...

// Function Prototypes
void CheckMail();
void LoadSettings();
void Add(char *s);
void Setup(HINSTANCE dllInst);
void DoAnimF(HWND hWnd);
void DoAnimB(HWND hWnd);
void DrawImage(HWND hWnd);
HIMAGELIST AddBitmapsToImageList(HINSTANCE dllInst);
void MakePaint();
void MakeBuffer(HWND hWnd);
char* strip(char *s);

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Globals
HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

HIMAGELIST himList = NULL;
HANDLE hBMBuffer = NULL;
HANDLE hBitmap;
int First = 1;
int currentImage = 0;
int LowestIndex = 0;
int HighestIndex = 0;

char uidl[500][30];
char server[30];
char user[15];
char pass[15];
char email[100];
char cline[25];
char theme_dir[100];
int freq;
int newmail=0;
int up=0;
int timer;
int Base,Base0,Base1,Base2,Base3,Base4,Base5,Base6,Base7,Base8,Base9,BaseP;
HMENU popup;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
    	}
	   }


    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);
	
	popup = CreatePopupMenu();
    AppendMenu(popup, MF_ENABLED | MF_STRING, 100, "&Check Mail Now");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 101, "&Launch E-Mail Client");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 102, "&Edit Settings");
    AppendMenu(popup, MF_ENABLED | MF_STRING, 103, "&Put Flag Down");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 104, "&About LSNotify");
    
	LoadSettings();
	SetCurrentDirectory(theme_dir);
	Setup(dllInst);

	{
		int thread;
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)hMainWnd, 0, &thread);
	}

	timer=SetTimer(hMainWnd,freq, freq-5000, NULL);
	
	return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	DestroyMenu(popup);
	DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_COMMAND:
			{
				switch (wParam)
				{
					case 100:
					{
						KillTimer(hWnd,timer);
						{
							int thread;
							CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)hMainWnd, 0, &thread);
						}
						timer=SetTimer(hWnd,freq, freq-5000, NULL);
						return 0;
					}
					case 101:
					{
						if (cline[0] != '\0') {	_spawnl( _P_NOWAIT, email, email, cline, NULL ); }
						else 
						{
							_spawnl( _P_NOWAIT, email, email, NULL ); 
						}
						if (up == 1)
						{
							int thread;
							CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DoAnimB, hWnd, 0, &thread);
						}
						up=0;
						newmail=0;
						return 0;
					}
					case 102:
					{
						_spawnl( _P_NOWAIT, "c:\\windows\\notepad.exe", "c:\\windows\\notepad.exe", "c:\\windows\\lsnotify.ini", NULL );
						return 0;
					}
					case 103:
					{
						int thread;
						if (up == 1)
						{
							CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DoAnimB, hWnd, 0, &thread);
						}
						up=0;
						newmail=0;
						return 0;
					}
					case 104:
					{
						MessageBox(0,"LSNotify: By MrJukes\n-  Thanks to: Nerraw, Floach, LoneRunnr, MHolmesIV, and all of #Litestep\n-  Email me at: mrjukes@purdue.edu","LSNotify", MB_OK | MB_ICONINFORMATION | MB_SETFOREGROUND );
						return 0;
					}
				}
			}
		case WM_PAINT:      
			{
				if (First)
				{
					MakeBuffer(parent);
					First = 0;
				}
				DrawImage(hWnd);
			}
			return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                //RECT r;
                //GetWindowRect(hWnd, &r);
                //PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
			{
			    DWORD dw = GetMessagePos();
				TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
				return 0;
			}
        case WM_LBUTTONDOWN:
			{
			PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
			if (cline[0] != '\0') {	_spawnl( _P_NOWAIT, email, email, cline, NULL ); }
			else 
			{
				_spawnl( _P_NOWAIT, email, email, NULL ); 
			}
			if (up == 1)
			{
				int thread;
				CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DoAnimB, hWnd, 0, &thread);
			}
			up=0;
			newmail=0;
			}
			return 0;
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_TIMER:
			{
				int thread;
				CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)hMainWnd, 0, &thread);
			}
			return 0;
    }
    return DefWindowProc(hWnd,message,wParam,lParam);
}

void LoadSettings()
{
  char temp[100];
  int x=0,a=0,b=0,keep=1;
  
  for (a=0;a<30;a++) {server[x] = '\0';}
  for (a=0;a<15;a++) {user[x] = pass[x] = cline[x] = '\0';}
  for (a=0;a<100;a++) {email[x] = '\0'; theme_dir[x] = '\0'; }
  a=0;
  {
    // Get the settings
    FILE *fp=fopen("c:\\windows\\lsnotify.ini","r");
	if (fp != NULL)
	{
      fseek( fp, 0L, SEEK_SET );
      while (fscanf( fp, "%s", temp ) != EOF)
	  {
        if (temp[0] == 's') { strcpy(server,strip(temp));  }
        else if (temp[0] == 'u') { strcpy(user,strip(temp)); }
        else if (temp[0] == 'p') { strcpy(pass,strip(temp)); }
	    else if (temp[0] == 'e') { strcpy(email,strip(temp)); }
		else if (temp[0] == 'c') { strcpy(cline,strip(temp)); }
		else if (temp[0] == 't') { strcpy(theme_dir,strip(temp)); }
		else if (temp[0] == 'f') { freq = atoi(strip(temp)) * 60000; }
	    else if (temp[0] == '/') { }
	    else { }
	  }
      fclose(fp);
	}
    else
	{
      strcpy(server,"postoffice.purdue.edu");
      strcpy(user,"dumbass");
      strcpy(pass,"stupid");
      strcpy(email,"d:\\eudora\\eudora.exe");
	  cline[0] = '\0';
	  strcpy(theme_dir,"c:\\windows\\");
	  freq = 180000;
	} 
	// Initialize uidl
    for (a=0;a<500;a++)
	{
	  for (b=0;b<30;b++)
	  {
		  uidl[a][b]='.';
	  }
	}
  }
}

char* strip(char *s)
{
int x=0,y=0;
char blah[100];
while (s[x] != '=') { x++; }
x++;
x++;
while(s[x] != '\"') { blah[y] = s[x]; x++; y++; }
blah[y] = '\0';
return blah;
}


void CheckMail()
{
	struct sockaddr_in A;
    WSADATA W;
    SOCKET S;
    char aa[60000];
	char see[2];
    int thread;
	int i;
    int x=0,y=0,z=0,allgood=1;
    struct hostent *H = NULL;
    char R[60000];
    char tuidl[500][30];
    int match=0;
	FILE *log=fopen("c:\\windows\\lsnlog.txt","w");
    for (x=0;x<60000;x++) {R[x]='\0'; aa[x]='\0';}
	
    WSAStartup (0x101, &W);
    S = socket(AF_INET, SOCK_STREAM,0);
    A.sin_family=AF_INET;
    A.sin_port = htons(110);
	H=gethostbyname(server);

	if (H != NULL)
	{
	  A.sin_addr.s_addr=*((unsigned long *) H->h_addr);
      fprintf(log,"%s\n","We're Online");
	  // Connect
	  i=connect(S,(struct sockaddr *) &A,sizeof(A));
	  i=recv(S,R,10000,0);
      fprintf(log,"%s\n",R);
	  if (R[0] == '+')
	  {
		// Login
        strcpy(R,"USER ");
	    i=send(S,R,strlen(R),0);
	    strcpy(R,user);
	    i=send(S,R,strlen(R),0);
	    strcpy(R,"\r\n");
	    i=send(S,R,strlen(R),0);
		see[0]='\n';
		i=recv(S,see,1,0);
		fprintf(log,"%s: %c\n","This is see after sending login",see[0]);
		if (see[0] == '+')
		{
		  fprintf(log,"%s\n","Login Accepted");
		  while (see[0] != '\n') { i=recv(S,see,1,0); }
		  // Password
	      strcpy(R,"PASS ");
	      i=send(S,R,strlen(R),0);
	      strcpy(R,pass);
	      i=send(S,R,strlen(R),0);
	      strcpy(R,"\r\n");
	      i=send(S,R,strlen(R),0);
          i=recv(S,see,1,0);
		  fprintf(log,"%s: %s\n","This is see after sending password",see);
		  if (see[0] == '+')
		  {
			fprintf(log,"%s\n","Password Accepted");
		    while (see[0] != '\n') { i=recv(S,see,1,0); }
			// UIDL
	        strcpy(R,"UIDL\r\n");
	        i=send(S,R,strlen(R),0);
			i=recv(S,see,1,0);
			if (see[0] == '+')
			{
              while (see[0] != '\n') { i=recv(S,see,1,0); }
			  for (x=0;x<60000;x++) {R[x]='\0';}
			  i=recv(S,R,59999,0);
			  fprintf(log,"%s: %s\n","This is UIDL:\n",R);
              strcpy(aa,R);
			}
			else { allgood=0; }
          }
		  else { allgood=0; }
		}
		else { allgood=0; }
      }
	  else { allgood=0; }
	  // quit
	  strcpy(R,"quit\r\n");
	  i=send(S,R,strlen(R),0);
	  i=recv(S,R,10000,0);
	  fprintf(log,"%s\n%s\n","This is aa:",aa);
	  closesocket(S);
	  
	  if (allgood == 1)
	  {
	    x=y=0;
		while (aa[x] != '.')
		  {
		    while (aa[x] != ' ') { x++; }
		    x++;
		    while (aa[x] != '\n') { tuidl[y][z] = aa[x]; x++; z++; }
		    y++;
		    x++;
		    z=0;
		  }
		strcpy(tuidl[y],".");
	    fprintf(log,"%s\n%s\n","This is tuidl:",tuidl);
		fclose(log);
	    x=y=z=0;
	    match=0;	  
	    while (tuidl[x][0] != '.')
		{
		  if (uidl[0][0] == '.') { match=0; }
		  else
		  {
		  	while (uidl[y][0] != '.' && match != 1)
			{
				if (strcmp(uidl[y],tuidl[x]) == 0) { match=1; }
				else { y++; }
			}
		  }
		  if (match != 1) { newmail++; Add(tuidl[x]); }
		  x++;
		  match=0;
		}
		if (newmail > 0 && up != 1) { DoAnimF(hMainWnd); up=1; }
	    
        // Set uidl = tuidl
        x=0;
	    while (tuidl[x][0] != '.')
		{
		  strcpy(uidl[x],tuidl[x]);
		  x++;
		}
	    strcpy(uidl[x],".");
	    // Clean tuidl
        x=0;
        while (tuidl[x][0] != '.')
		{
          tuidl[x][0] = '\0';
          x++;
		}
	  }
	  else { fclose(log); }
	}
	else { fclose(log); }
	allgood=1;
}


void Add(char *s)
{
	int x=0;
	while (uidl[x][0] != '.') { x++; }
	strcpy(uidl[x],s);
	uidl[x+1][0] = '.';
}

/* Pretty much the basic concept of everything below here is thanks to MHolmesIV.  
   I would have gotten it eventually, but he helped speed the process up greatly */

void Setup(HINSTANCE dllInst)
{
	himList = AddBitmapsToImageList(dllInst);
}

HIMAGELIST AddBitmapsToImageList(HINSTANCE dllInst)
{
    HIMAGELIST himlBitmap; // handle of new image list
    HANDLE hBitmap;        // handle of icon

    // Ensure that the common control DLL is loaded.
    InitCommonControls();
    // Create a masked image list large enough to hold the icons.
    himlBitmap = ImageList_Create(64, 64, ILC_COLOR8 | ILC_MASK, 21, 1);

    // Load the Bitmap resources, and add the icons to the image list.
	hBitmap = LoadImage( dllInst,"base0.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE | LR_SHARED);
        currentImage = Base = Base0 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base1.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base1 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base2.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base2 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base3.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base3 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base4.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base4 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base5.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base5 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base6.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base6 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base7.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base7 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base8.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base8 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base9.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
        Base9 = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"base+.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);// | LR_CREATEDIBSECTION);
        BaseP = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	
    hBitmap = LoadImage( dllInst,"mail1.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		LowestIndex = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
    hBitmap = LoadImage( dllInst,"mail2.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
    hBitmap = LoadImage( dllInst,"mail3.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
    hBitmap = LoadImage( dllInst,"mail4.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
    hBitmap = LoadImage( dllInst,"mail5.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE); 
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"mail6.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"mail7.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"mail8.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"mail9.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	hBitmap = LoadImage( dllInst,"mail10.bmp",IMAGE_BITMAP,64,64,LR_LOADFROMFILE);
		HighestIndex = ImageList_AddMasked(himlBitmap, hBitmap, 0x00ff00ff);
	
	DeleteObject(hBitmap);

    return himlBitmap;
}


void MakeBuffer(HWND hWnd)
{
        RECT r;
        HDC hdc = GetDC(hWnd), tempDC;
        HBITMAP bOld;
        GetClientRect(hWnd,&r);
        hBMBuffer = CreateCompatibleBitmap(hdc, 64, 64);
        tempDC = CreateCompatibleDC(NULL);
        bOld = (HANDLE)SelectObject(tempDC, hBMBuffer);
        BitBlt(tempDC, 0, 0, r.right, r.bottom, hdc, wharfData.borderSize, wharfData.borderSize, SRCCOPY);
        DeleteDC(tempDC);
        ReleaseDC(hWnd, hdc);
}

void DoAnimF(HWND hWnd)
{
	currentImage = LowestIndex;
	DrawImage(hWnd);
	MakePaint();
	MakePaint();
	while (currentImage <= HighestIndex)
    {
		DrawImage (hWnd);
		Sleep(500);
		MakePaint();
		MakePaint();
		currentImage++;
    }
    currentImage = HighestIndex;

}

void DoAnimB(HWND hWnd)
{
        DrawImage (hWnd);
        MakePaint();
        MakePaint();
        while (currentImage >= LowestIndex)
		{
                DrawImage (hWnd);
                Sleep(500);
                MakePaint();
                MakePaint();
                currentImage--;
        }
        currentImage = LowestIndex;
}

void DrawImage(HWND hWnd)
{
	PAINTSTRUCT ps;
	RECT r;
	HDC hdc = BeginPaint(hWnd, &ps), tempDC;
	HANDLE bOld;
	GetClientRect(hWnd,&r);
	tempDC = CreateCompatibleDC(NULL);
	bOld = (HANDLE)SelectObject(tempDC, hBitmap);
	BitBlt(hdc, r.left, r.top, 64, 64, tempDC, 0, 0, SRCCOPY);
	ImageList_Draw(himList, currentImage, hdc, r.left, r.top, ILD_TRANSPARENT);
	DeleteDC(tempDC);
	ReleaseDC(hWnd, hdc);
	EndPaint(hWnd, &ps);
}

void MakePaint()
{
	RECT r;
	GetClientRect(hMainWnd, &r);
	InvalidateRect(hMainWnd, &r, TRUE);
}
