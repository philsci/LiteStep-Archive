install:
extract to litestep directory and load with LoadModule

step.rc commands:
AlarmTime - the time to exec the command
            ex: AlarmTime 1:00AM
AlarmCommand - the command to exec, can be a bang command.
               ex: AlarmCommand !popup
bang commands:
!togglealarm - toggles the alarm on/off
!disablealarm - disables the alarm
!enablealarm - enables the alarm
!alarmstat - shows some status information

please email me with comments/suggestions/bugs

- pod (danielb@vnet.net)
