Access to LiteStep Cvs via Anonymous login

1) Unzip the contents of this zip file to c:\cvs

NOTE: You may use a different directory but then you will need to edit
      start.bat manually and change all references to c:\cvs to the
      directory of your choice

2) Start a commant prompt

3) Cd to c:\cvs

4) Type "start.bat" and press the enter key

You wil be presented with the following:

     C:\cvs>start.bat
     (Logging in to litestep@lsdev.org)
     CVS password:

NOTE: There is no password for user "litestep"

5) Press the enter key and you will be returned to the c:\cvs prompt

6) Type "checkout.bat" and press the enter key

It will checkout the cvs source to the current directory

That is it.