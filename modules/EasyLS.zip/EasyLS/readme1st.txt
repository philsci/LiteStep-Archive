EasyLS 1st Release 27-JUN-2001
a Litestep distro
by Eduardo Vazquez
E-mail: eduardo.harte@terra.es
Web: http://blake.prohosting.com/eduv/
IRC: my nick is Master_ed in #litestep channel

Welcome to EasyLS!
Extract the zip to c:\easyls\

The idea of this distro is that LS users can use LS with any theme and that
people that want to make themes like myself can make themes without worring
about what programs the users have or don't have.
Example 1:

A theme maker has made a "must have" theme users X Y and Z have download
it and installed but there is a problem.

Theme maker has all these appz:
Windoze with accesories (notepad, mspaint, wordpad ...)
MS Office
MS Frontpage
15 Deadly games
Winamp
Mozilla
IE
ICQ
and Adobe Paint Shop

Uesr X
Windoze with accesories (notepad, mspaint, wordpad ...)
MS Office
5 Games
Winamp
Quick Time
IE

Uesr X
Windoze with accesories (notepad, mspaint, wordpad ...)
MS Office
25 Games
Winamp
IE

Uesr Z
Windoze with accesories (notepad, mspaint, wordpad ...)
20 Games
Real player
IE

Well may be is not a good example but what I mean is as everyone dosen't have the same software and as Litestep is a open source project based not only on afterstep but a cracy idea of freedom, GNU, Linux and what ever the user wants so since I tryed KDE and others windows managers in Linux I notice that they have a standard not so strong as M$'s standards but it was better than Litestep's standards when it comes to addid a theme so I decide to go back to M$ Windoze and make this distro.
Now there are some requirements for users and specially theme makers.
A part from a PC with 16 or 32 megas of ram to use win9x/ME

1. You must have Win9x/ME with accesories install

Since LS is not compatible with M$ IE I like to use MS replacements
but there are some people that use IE and windows Explorer while using LS
so I figured out that is best to have the following apps.

2. You must have

   Alternative Programs      M$ appz
   ====================      =======
   Any File manager          Windoze Explorer
   Any text editor           Notepad
   Any video player          Windoze Media player
   Any audio player          Windoze Media player
   Any paint editor          M$Paint
   Any dialer                Windoze dialer
   Any browser               IE
   Any email client          Outlook Exprees
   Any IRC client            only if you have M$Chat come in IE 4.0 only
                             if you don't have it don't worry, get bersirc
                             or mirc or use none.
   Any Ftp client            M$-DOZ in a windoze box
   Any HTML editor           Notepad

For more details read user.rc in personal that does for users and specilly
theme makers.

Now the dir structure is the same one as gello series and LitestepGL
but as you read up has a nice list of types of appz that the user has
when buys a PC and he/she must not have any other apps for enjoying a
Litestep theme based on KDE, Beos or any other fancy os theme.

About the popup you have two choices
1. You use the one that come with EasyLS.
Or
2. You edit popup.rc and you make your own one.

About the hotkeys you have two choices
1. You use the ones that come with EasyLS.
Or
2. You edit hotkey.rc and you add your own ones.

I hope Litestep users like and understand what I'm trying to do here
if you have any questions, comments, suggestions just e-mail ne at
eduardo.harte@terra.es