#include <windows.h>
#include <stdlib.h>
#include <math.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

char* szAppName = "SysWave";
HWND hwndMain;

int W = 838;
int H = 151;
int WL = 20;
HPEN cpupen=NULL, zeropen=NULL, gridpen=NULL;
HPEN mincpupen=NULL, maxcpupen=NULL;

HKEY key;
HKEY startkey;

int maxamp=0;
int minamp=100;
			

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{
    MSG msg;
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = szAppName;

	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
	
	if (RegOpenKeyEx(HKEY_DYN_DATA, "PerfStats\\StartStat", 0, KEY_READ, &startkey) != ERROR_SUCCESS) return 1;
	if (RegOpenKeyEx(HKEY_DYN_DATA, "PerfStats\\StatData", 0, KEY_READ, &key) != ERROR_SUCCESS) return 1;

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, 0, 0, W, H, NULL, NULL, hInstance, NULL);
	if (!hwndMain) return 1;
	
	SendMessage(hwndMain, WM_TIMER, 0, 0);
	SetTimer(hwndMain, 0, 25, NULL);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}

	RegCloseKey(startkey);
	RegCloseKey(key);
	KillTimer(hwndMain, 0);
	DestroyWindow(hwndMain);
	DeleteObject(cpupen);
	DeleteObject(zeropen);
	DeleteObject(gridpen);
	DeleteObject(maxcpupen);
	DeleteObject(mincpupen);

	return 0;
}

void DrawSin(HDC buf, HPEN pen, int offset, int amp)
{
	SelectObject(buf, pen);
	for (int x=0; x < W; x++)
	{
		double y = (sin((x+offset)/(float)WL) * amp) + (H/2);
		if (!x) MoveToEx(buf, x, (int)y, NULL);
		LineTo(buf, x, (int)y);
	}
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, W, H);
			HBITMAP oldbuf;
			RECT r;
			int amp;
			static int offset=0;
			char temp[256] = "";
			DWORD size=256;

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			GetClientRect(hwnd, &r);
			FillRect(buf, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));
			
			// Draw grid
			if (!gridpen) gridpen = CreatePen(PS_SOLID, 0, 0x00202020);
			SelectObject(buf, gridpen);

			for (int ly=0; ly<H; ly += H/10)
			{
				MoveToEx(buf, 0, ly, NULL);
				LineTo(buf, W, ly);
			}

			for (int lx=0; lx<W; lx += W/50)
			{
				MoveToEx(buf, lx, 0, NULL);
				LineTo(buf, lx, H);
			}

			// Draw zero line
			if (!zeropen) zeropen = CreatePen(PS_SOLID, 0, 0x00404040);
			SelectObject(buf, zeropen);
			MoveToEx(buf, 0, H/2, NULL);
			LineTo(buf, W, H/2);
			
			// Get CPU Usage
			if (RegQueryValueEx(key, "KERNEL\\CPUUsage", NULL, NULL, (unsigned char*)temp, &size) == ERROR_SUCCESS)
			{
				amp = (int)(H*(*temp)/200);
			}

			// Check for min and max
			if (amp > maxamp) maxamp = amp;
			if (amp < minamp) minamp = amp;

			// Draw Max CPU Usage
			if (!maxcpupen) maxcpupen = CreatePen(PS_SOLID, 0, 0x00000040);
			DrawSin(buf, maxcpupen, offset, maxamp);

			// Draw Min CPU Usage
			if (!mincpupen) mincpupen = CreatePen(PS_SOLID, 0, 0x00004000);
			DrawSin(buf, mincpupen, offset, minamp);

			// Draw CPU Usage
			if (!cpupen) cpupen = CreatePen(PS_SOLID, 0, 0x00544413);
			DrawSin(buf, cpupen, offset, amp);

			BitBlt(hdc, 0, 0, W, H, buf, 0, 0, SRCCOPY);

			offset++;
			if (offset == (WL*6)+5) offset=0;

			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbuf);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wparam)
			{
				case SC_CLOSE: PostQuitMessage(0); break;
			}
		}
		break;

		case WM_MOUSEMOVE: SetCursor(LoadCursor(NULL, IDC_ARROW)); break;

		case WM_TIMER:
		{
			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;

		case WM_LBUTTONUP:
		{
			maxamp=0;
			minamp=100;
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wparam, lparam);
}