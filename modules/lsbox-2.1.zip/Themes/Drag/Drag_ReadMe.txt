"Drag" Readme by Phil Varcoe
-----------------------------------------

This is one example of the power and flexibility of
lsbox. It allows one to include many elements used
in a litestep theme, into one (or more) boxes.

----------------------------------------

For ease of installation (expecially in terms of paths) I 
recommend you install this lsbox example as a regular
(complete) theme. Copy or move the entire "drag" 
directory (folder) into your "themes" directory. Copy 
the supplied step.rc and the drag.box file into your main 
litestep directory and recycle. 

One note: You need to be runnig a very recent version 
of litestep for lsbox to work (as far as I know).

The included step.rc uses the following directory structure:
- Main Litestep Directory:
  C:\Litestep\
- Theme Directory:
  C:\Litestep\Themes\Drag\  

-----------------------------------------

Once you recycle, the "DragBox" should be on-screen. 
The drag box contains lsxcommand with clock, a sysvwm 
and a systray with tasks included in it. It also includes controls
for winamp with lssliders for volume and song progress.

-----------------------------------------

This is just the tip of the iceberg in terms of what you can include
in a lsbox. All sort of shotcuts can be included to do any number
of litestep functions. Experiment and have fun.

-----------------------------------------

Major, major thanks to Blkhawk for this excellent module. 
Major thanks as well to the entire litestep dev team for 
the current versions of litestep.

-----------------------------------------