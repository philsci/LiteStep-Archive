Razrez.dll by Azathoth (2000) version 0.2

I was writing an app to hack the resolutions on the pc's at school (they're locked out) when i got bored :)
This is the result. I just took the ole DEVMODE code and stuck it somewhere new.

usage:
loadmodule c:\path_to_dll\razrez.dll

change resolution by using:
!razrez <bpp> <width> <height>
ie. !razrez 16 800 600

or put:
*razrez <bpp> <width> <height> 
in yer step to have razrez.dll change the display on startup..
btw, this function is to the best of my knowledge useless, i was just bored...

new funtion:
*razrezout <bpp> <width> <height>
use this to change the resolution on quitting litestep. This enables you to change the res on entry and exit of ls allowing youto use different res' for ls and other shells.

well that's it i think...

thanks to no-one really... i did it all on my lonesome...

btw. the name razrez comes from A Clockwork Orange by Anthony Burgess and means "cut-up". It also derives from Az & Rez.
neways...

contact info: 
e-mail: azathoth@intricatechaos.com
web: http://www.intricatechaos.com/
icq: 25810657