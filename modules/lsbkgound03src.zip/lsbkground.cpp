/*******************************************************************

	LSbkground v0.3

    Bassed on LSWallpaper Jeb Crouson/aka TrOgI(crouson@inreach.com)
    Hacked by Hideki Fujita (hidfjt@ss.iij4u.or.jp)

*******************************************************************/
/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
					aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA	 02111-1307, USA.

*/
/*********************************************************************
 * Thanks.
 *	Independent JPEG Group
 *			jpeg6b
 *********************************************************************/
#include <windows.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <setjmp.h>
#include "lsbkground.h"
#ifdef __cplusplus
extern "C" {
#endif
#include "jpeglib.h"
#ifdef __cplusplus
}
#endif

/* ----------------------------------------------------------------- */
char szAppName[] = "LSBkground"; // Name of Application, Window class...
// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
//
void jpegconv( char	*, char	*);
int SaveBMPFile(char*);
int LoadJEGFile(char*);
void			getFileName(char*,int);
void getBitmapInfo(char	*);
void	createRmenu();
void	createLmenu();
void registryLookup(char *);
void	drawBitmap (char*);

HWND hMainWnd;					  // main window handle
HWND parent;					  // parent window
wharfDataType wharfData;		  // Setup data passed to the DLL
int wndSize;					  // Size of the wharf client
HBITMAP background;
HINSTANCE ghInst;
HMENU hRMenu;
HMENU hLMenu;
char iniPath[MAX_PATH],homePath[MAX_PATH],curDir[MAX_PATH], curPic[MAX_PATH], picName[MAX_PATH];
char curBMP[MAX_PATH];
char *pntr;
POINT p, dim;
POINT picSize;
double width,hight;
F_INFO	*picInfo = NULL;
F_INFO	*dirInfo = NULL;
char	lsPath[128];
#define	DEFAULT_DIR		"Wallpaper"
#define	DEFAULTBMP		"_current.bmp"
#define	EntryBMP		"DEFAULTBMP"
#define	DIRITEM_MAX		100
#define	HOMEDIR			"WallpaperDIR"
int		maxID = 0;
int		maxDIR = 0;
static	IMG_BUFFER	image;
int				row_stride;
unsigned char *	pImageBuffer;
long	rowDlm4 = 0;
struct my_error_mgr {
	struct jpeg_error_mgr pub;	/* "public" fields */
	jmp_buf setjmp_buffer;	/* for return to caller */
};
BITMAPFILEHEADER	BitmapFileHeader;
BITMAPINFOHEADER	BitmapInfoHeader;
typedef struct my_error_mgr * my_error_ptr;
//char	szMsg[256];             // for debug
/*********************************************************************/
/* DLL Entry point													 */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	int	dirSize;
	char	bmpFileName[256];

	parent = ParentWnd; // Save parent window
	// Duplicate wharfData since the one we get will be destroyed
	memcpy(&wharfData, wd, sizeof(wharfDataType));
	wndSize = 64-wharfData.borderSize*2;
	ghInst = dllInst;

	hRMenu = NULL;
	hLMenu = NULL;

	{	 // Register the Window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;		// our window procedure
		wc.hInstance = dllInst;			// hInstance of DLL
		wc.lpszClassName = szAppName;	// our window class name

		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,
					   "Error registering window class",
					   szAppName,
					   MB_OK);
			return 1;
		}
	}

	hMainWnd = CreateWindowEx(
							  0,				// exstyles 
							  szAppName,		// our window class name
							  szAppName,		// use description
							                    // for a window title
							  WS_CHILD,			// window style
							  wharfData.borderSize,
							  wharfData.borderSize,   // position 
							  wndSize,wndSize,	// width & height of window
							  parent,			// parent window
							                    //(litestep wharf window)
							  NULL,				// no menu
							  dllInst,			// hInstance of DLL
							  0);				// no window creation data

	if (!hMainWnd) 
	{						   
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		return 1;
	}

	dirSize = GetModuleFileName(NULL, iniPath, sizeof(iniPath));
	while(iniPath[--dirSize] != '\\')
		iniPath[dirSize] = '\0';
	strcpy(lsPath, iniPath);
	strcat(iniPath, "modules.ini");

	dim.x = GetPrivateProfileInt("LSBkground", "Width", 64, iniPath);
	dim.y = GetPrivateProfileInt("LSBkground", "Height", 64, iniPath);
	p.x = GetPrivateProfileInt("LSBkground", "PointX", 0, iniPath);
	p.y = GetPrivateProfileInt("LSBkground", "PointY", 0, iniPath);

	// Wallpaper file name read from refistry
	registryLookup(curPic);
	drawBitmap (curPic);

	/* Pic Directory Get	*/
	GetPrivateProfileString("LSBkground", HOMEDIR, "Q", homePath, sizeof(homePath), iniPath);
	if (!(strcmp("Q", homePath))){
		strcpy (homePath, lsPath);
		strcat (homePath, DEFAULT_DIR);
	}
	// File Type is JPEG
	GetPrivateProfileString("LSBkground", EntryBMP, "Q", bmpFileName, sizeof(bmpFileName), iniPath);
	if (!(strcmp("Q", bmpFileName))){
		sprintf (curBMP,"%s\\%s\0",homePath,DEFAULTBMP);
	}
	else{
		sprintf (curBMP,"%s\\%s\0",homePath,bmpFileName);
	}

	getFileName(homePath,0);

	createLmenu();
	createRmenu();

	// Set normal cursor
	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
	// DO NOT REMOVE ! Set magicDWord - required!
	// Used by some modules & litestep internals
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	return 0;
}

/*********************************************************************/
/* Create Left click menu (Dirctry List)     						 */
/*********************************************************************/
void	createLmenu()
{

	if (hLMenu)	DestroyMenu(hLMenu);
	hLMenu = NULL;
	hLMenu = CreatePopupMenu();
	if (maxDIR == 0)
		AppendMenu(hLMenu, MF_ENABLED | MF_STRING, 1, "NO SUB DIR");

	for (int dirID = 1;dirID <= maxDIR;dirID++)
	{
		strcpy(picName, (dirInfo+dirID-1)->picName);
		AppendMenu(hLMenu, MF_ENABLED | MF_STRING, dirID , picName);
	}
	return;
}

/*********************************************************************/
/* Create Right click menu (Bitmap List)     						 */
/*********************************************************************/
void	createRmenu()
{
	int	picID = 1;

	if (hRMenu)	DestroyMenu(hRMenu);
	hRMenu = NULL;
	hRMenu = CreatePopupMenu();
	if (maxID == 0)
		AppendMenu(hRMenu, MF_ENABLED | MF_STRING, picID, "NO PIC");

	while(picID <= maxID)
	{
		strcpy(picName, (picInfo+picID-1)->picName);
		AppendMenu(hRMenu, MF_ENABLED | MF_STRING, picID + DIRITEM_MAX , picName);
		picID++;
	}
	return;
}

/*********************************************************************/
/* Dll closeup request												 */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	KillTimer(hMainWnd,1);
	if (picInfo)	free (picInfo);
	if (dirInfo)	free (dirInfo);
	DeleteObject(background);
	if (hRMenu)	DestroyMenu(hRMenu);
	hRMenu = NULL;
	if (hLMenu)	DestroyMenu(hLMenu);
	hLMenu = NULL;
	DestroyWindow(hMainWnd);				// delete our window
	UnregisterClass(szAppName, dllInst);	// unregister window class
}


/*********************************************************************/
/* Window procedure for our window									 */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static struct	_stat oldstat,newstat;
	char	tmpString[MAX_PATH];
	switch (message)
	{
		case WM_CREATE:		return 0;
		case WM_ERASEBKGND: return 0;
		case WM_PAINT:
			{
				POINT	amari;
				PAINTSTRUCT ps;

				amari.x = (dim.x - picSize.x) / 2;
				amari.y = (dim.y - picSize.y) / 2;

				HDC hdc = BeginPaint(hwnd,&ps);
				HDC src = CreateCompatibleDC(NULL);
				HDC dst = CreateCompatibleDC(NULL);
				HBITMAP hBuf = CreateCompatibleBitmap(hdc, dim.x, dim.y);

				SelectObject(dst, hBuf);

				SelectObject(src, background);
				BitBlt(dst, amari.x, amari.y, picSize.x , picSize.y , src, 0, 0, SRCCOPY);

				BitBlt(hdc, p.x - wharfData.borderSize, p.y - wharfData.borderSize, dim.x, dim.y, dst, 0, 0, SRCCOPY);
				EndPaint(hwnd,&ps);

				DeleteDC(src);
				DeleteDC(dst);
				DeleteObject(hBuf);
			}
			return 0;
		case WM_KEYDOWN:	// forward keyboard messages to parent window 
		case WM_KEYUP:
			PostMessage(parent,message,wParam,lParam);
			return 0;
		case WM_LBUTTONUP:
				{
					DWORD dw = GetMessagePos();
					TrackPopupMenu(hLMenu, TPM_LEFTALIGN | TPM_LEFTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
				}
			return 0;
		case WM_RBUTTONUP:
				{
					DWORD dw = GetMessagePos();
					TrackPopupMenu(hRMenu, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
				}
			return 0;
		case WM_RBUTTONDOWN:
		case WM_LBUTTONDOWN:
		case WM_MBUTTONDOWN:
			PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
			return 0;
		case WM_COMMAND:
			if (wParam > DIRITEM_MAX ){
				if (wParam -DIRITEM_MAX > maxID){
					break;
				}else{
					strcpy (curPic ,(picInfo+wParam-DIRITEM_MAX-1)->picPath);
				}
				drawBitmap (curPic);
				SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, curPic, SPIF_SENDWININICHANGE | SPIF_UPDATEINIFILE);
			}
			else{
				if (maxDIR == 0)
					break;
				getFileName ((dirInfo+wParam-1)->picPath,1);
				createRmenu();
			}
			return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

/*********************************************************************/
/* Bitmap set		`					     						 */
/*********************************************************************/
void drawBitmap(char *curPic)
{
	getBitmapInfo (curPic);
	width = BitmapInfoHeader.biWidth / dim.x;
	hight = BitmapInfoHeader.biHeight / dim.y;
	if (width > hight ){
		picSize.x = BitmapInfoHeader.biWidth / width;
		picSize.y = BitmapInfoHeader.biHeight / width;
	}
	else{
		picSize.x = BitmapInfoHeader.biWidth / hight;
		picSize.y = BitmapInfoHeader.biHeight / hight;
	}
	background = LoadImage(ghInst, curPic, IMAGE_BITMAP, picSize.x, picSize.y, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
}

/*********************************************************************/
/* get Dirctry/Bitmap List 				     						 */
/*********************************************************************/
void	getFileName(
					char	*searchPath,
					int				flg)
{
	WIN32_FIND_DATA fd;
	HANDLE h;
	char	srcPath[256];

	if (picInfo)	free(picInfo);
	picInfo = NULL;
	maxID = 0;
	if (flg == 0 && dirInfo != NULL){
		free(dirInfo);
		dirInfo =NULL;
		maxDIR = 0;
	}

	strcpy(srcPath,searchPath);
	strcat(srcPath, "\\*");
	h = FindFirstFile(srcPath, &fd);
	if (h == INVALID_HANDLE_VALUE) {
		MessageBox(hMainWnd, srcPath,"error!", MB_OK );
		return;
	}

	char  tmpString[256];
	F_INFO	*wk_Info;
	do {
		if (fd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)
			continue;
		if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
		    ;
			if (!strcmp(fd.cFileName, ".."))
				continue;
			if (flg == 0){
				wk_Info = dirInfo;
				dirInfo = (F_INFO*)realloc (wk_Info, sizeof (F_INFO) * (maxDIR + 1));
				if (NULL == dirInfo ){
					maxDIR = 0;
					return;
				}
				else{
					(dirInfo+maxDIR)->picID = maxDIR;
					strcpy ((dirInfo+maxDIR)->picName, fd.cFileName);
					wsprintf((dirInfo+maxDIR)->picPath, "%s\\%s", searchPath, fd.cFileName);
					maxDIR++;
				}
			}
		} else {
			strcpy ((char*)tmpString, (char*)fd.cFileName);
			strlwr ((char*)tmpString);
			if ( !memcmp (fd.cFileName, "_", 1))
			    continue;
			if (strlen(tmpString) <= 3) continue;
			if (0 != memcmp(&(tmpString[strlen(tmpString) - 3]), "jpg",3) &&
				0 != memcmp(&(tmpString[strlen(tmpString) - 3]), "bmp",3) )
				continue;
			wk_Info = picInfo;
			picInfo = (F_INFO*)realloc (wk_Info, sizeof (F_INFO) * (maxID + 1));
			if (NULL == picInfo ){
				maxID = 0;
				return;
			}
			else{
				(picInfo+maxID)->picID = maxID;
				strcpy ((picInfo+maxID)->picName, fd.cFileName);
				wsprintf((picInfo+maxID)->picPath, "%s\\%s", searchPath, fd.cFileName);
				maxID++;
			}

		}
	} while (FindNextFile(h, &fd));

	FindClose(h);
}
/*********************************************************************/
/* get Bmp info(height/width) (if filetype is jpg then JPG->BMP)	 */
/*********************************************************************/
void getBitmapInfo(
 char	*picFileName)
{
	FILE	*picFd;
	size_t		ret;

	memset (&BitmapInfoHeader,0x00,sizeof (BITMAPINFOHEADER));
	if (NULL == (picFd = fopen(picFileName,"rb")))
		// File Open Error
		return;

	ret = fread(&BitmapFileHeader,sizeof (BITMAPFILEHEADER),1,picFd);
	if (ret != 1)
	{
		fclose (picFd);
		// File Read Error
		return;
	}
	if (!memcmp (&BitmapFileHeader.bfType,"BM",2))
	{
		ret = fread(&BitmapInfoHeader,sizeof (BITMAPINFOHEADER),1,picFd);
		fclose (picFd);
		if (ret != 1)
			return;
	}
	else{
		fclose (picFd);
		jpegconv (picFileName,curBMP);
		strcpy (picFileName,curBMP);
		return;
	}
	return;
}

int SaveBMPFile( char filepath[] )
{
	FILE *			outfile;
	int				imgSize = 0;
	char			errString[ 256 ];
	long	i;
	long			rowSize;

	if	( (outfile = fopen(filepath, "wb")) == NULL ) {
		sprintf( errString, "BMP�G���[: %s ���J���܂���B\n", filepath);
		MessageBox( hMainWnd, errString, "error!", MB_OK );
		return 0;
	}
	long	bmp_size;

	bmp_size = sizeof (BITMAPFILEHEADER)
				+ sizeof (BITMAPINFOHEADER)
				+ image.size;

	long	ret;

	memset (&BitmapFileHeader, 0x00, sizeof (BITMAPFILEHEADER));
	memcpy ( (char*)&(BitmapFileHeader.bfType), "BM", 2);
	BitmapFileHeader.bfSize =	sizeof (BITMAPFILEHEADER)
						+ sizeof (BITMAPINFOHEADER)
						+ image.size;

	BitmapFileHeader.bfOffBits = sizeof (BITMAPFILEHEADER)
						+ sizeof (BITMAPINFOHEADER);
	ret = fwrite( &BitmapFileHeader, sizeof (BITMAPFILEHEADER), (size_t)1, outfile );

	memset (&BitmapInfoHeader, 0x00,sizeof (BITMAPINFOHEADER));
	BitmapInfoHeader.biSize = sizeof (BITMAPINFOHEADER);
	BitmapInfoHeader.biWidth = image.width;
	BitmapInfoHeader.biHeight = image.hight;
	BitmapInfoHeader.biPlanes = 1;
	BitmapInfoHeader.biBitCount = 0x18;
	BitmapInfoHeader.biCompression = BI_RGB;
	BitmapInfoHeader.biSizeImage = 0;
	BitmapInfoHeader.biXPelsPerMeter = 0;
	BitmapInfoHeader.biYPelsPerMeter = 0;
	BitmapInfoHeader.biClrUsed = 0;
	BitmapInfoHeader.biClrImportant = 0;
	ret = fwrite( &BitmapInfoHeader, sizeof (BITMAPINFOHEADER), (size_t)1, outfile );

	rowDlm4 = row_stride % 4;
	if (rowDlm4 == 0)
		rowSize = row_stride;
	else
		rowSize = row_stride + (4-rowDlm4);
	for	( i = image.hight-1;i >=0 ;i--)
		ret = fwrite( image.buffer + i*rowSize,rowSize , (size_t)1, outfile );

	ret = fclose(outfile);

	return 1;
}

METHODDEF(void)
jpeg_err_exit (j_common_ptr cinfo)
{
	/* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
	my_error_ptr myerr = (my_error_ptr) cinfo->err;

	/* Always display the message. */
	/* We could postpone this until after returning, if we chose. */
	(*cinfo->err->output_message) (cinfo);

	/* Return control to the setjmp point */
	longjmp(myerr->setjmp_buffer, 1);
}


int LoadJPEGFile( char filepath[] )
{

	struct jpeg_decompress_struct cinfo;


	struct my_error_mgr jerr;

	FILE *			infile;
	JSAMPARRAY		buffer;
	int				rowCount;
	int				imgSize = 0;
	unsigned char * pImg;

	if	( (infile = fopen(filepath, "rb")) == NULL ) {
		return 0;
	}


	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = jpeg_err_exit;

	if	( setjmp( jerr.setjmp_buffer ) ) {
		jpeg_destroy_decompress( &cinfo );
		fclose( infile );
		return 0;
	}

	jpeg_create_decompress(&cinfo);

	jpeg_stdio_src( &cinfo, infile );

	(void) jpeg_read_header( &cinfo, TRUE );

	(void) jpeg_start_decompress(&cinfo);

	image.width = cinfo.output_width	;
	image.hight = cinfo.output_height	;

	row_stride = cinfo.output_width * cinfo.output_components;

	buffer = (*cinfo.mem->alloc_sarray)
			 ((j_common_ptr) &cinfo, JPOOL_IMAGE, row_stride, 1);

	rowDlm4 = row_stride % 4;
	if (rowDlm4 == 0)
		imgSize = cinfo.output_height * row_stride;
	else
		imgSize = cinfo.output_height * (row_stride+4-rowDlm4);
	image.size = imgSize;

	if	( ( pImageBuffer = (unsigned char *)malloc( (unsigned int)imgSize ) ) == (unsigned char *)NULL ) {
		return 0;
	}

	long	rowPix;
	long	rowDlm;
	image.buffer = (char*)pImageBuffer;
	pImg	 = pImageBuffer;
	while (cinfo.output_scanline < cinfo.output_height) {

		(void) jpeg_read_scanlines(&cinfo, buffer, 1);

		rowPix = row_stride / 3;
		rowDlm = row_stride % 3;
		for ( rowCount =  0; rowCount < row_stride - rowDlm ; rowCount++ ,rowCount++ ,rowCount++) {
			*pImg = *( buffer[0] + rowCount +2);
			pImg++;
			*pImg = *( buffer[0] + rowCount +1);
			pImg++;
			*pImg = *( buffer[0] + rowCount );
			pImg++;
		}
		for ( rowCount = 0; rowCount < rowDlm ; rowCount--, pImg++ )
			*pImg = *( buffer[0] + rowPix * 3 + rowCount );
		// Boundry set
		if (rowDlm4 != 0)
		{
			for (rowCount = 0;rowCount < 4 - rowDlm4;rowCount++){
				*pImg = 0x00;
				pImg++;
			}
		}
	}

	(void) jpeg_finish_decompress(&cinfo);

	jpeg_destroy_decompress(&cinfo);
	fclose(infile);
	return 1;
}
void jpegconv(
			  char	*infile,
			  char	*outfile)
{
	if ( pImageBuffer )	free( pImageBuffer );
	pImageBuffer = NULL;
	LoadJPEGFile( infile);
	SaveBMPFile(outfile);
	if ( pImageBuffer )	free( pImageBuffer );
	pImageBuffer = NULL;
}
void registryLookup(char *filename)
{
	char value[256];
	char regData[256];
	long regSize = 256;
	LONG res;
	HKEY hOpen;
	char* subKey = "Control Panel\\Desktop\0";

	RegOpenKeyEx(HKEY_CURRENT_USER, subKey, 0, KEY_READ, &hOpen);
	strcpy(value, "Wallpaper\0");
	res = RegQueryValueEx(hOpen, value, NULL, NULL, (LPBYTE)regData, (LPDWORD)&regSize);
	if (res == ERROR_SUCCESS)
		strcpy(filename, regData);
	else
		strcpy(filename, "");
	RegCloseKey(hOpen);
}
