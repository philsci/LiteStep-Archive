/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
/*********************************************************************/
/*                                                                   */
/* LiteSTEP Wharf Module SDK 1.4                                     */
/*                                                                   */
/*********************************************************************/
/*                                                                   */
/* Header file                                                       */
/*                                                                   */
/* ----------------------------------------------------------------- */

#ifndef __LSSDK_H
#define __LSSDK_H

/* ----------------------------------------------------------------- */

#include <windows.h>
#include <stdio.h>
//#include <math.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <gl\glaux.h>


/* ----------------------------------------------------------------- */

typedef struct {
    HWND Handle;
    BOOL Visible;
    RECT Position;
    } windowType;

typedef struct {
    int borderSize;
    int pos;
    int winListSize;
    windowType *winList;
    int trayIconSize;
    int lm78Unit;
    int lm78MaxCpu;
    int lm78MaxMb;
    int lm78Cpu;
    int taskBar;
    int msTaskBar;
    int taskBarFore;
    int taskBarBack;
    int taskBarText;
    int vwmVelocity;
    int autoHideWharf;
    int autoHideTaskbar;
    int VWMDistance;
    int autoHideDelay;
    int showBeta;
    int usClock;
    int VWMNoGathering;
    int VWMNoAuto;
    int xmouseDelay;
    int xmouseBringToTop;
    char *pixmapDir;
    char *defaultBmp;
    int vwmBackColor;
    int vwmSelBackColor;
    int vwmForeColor;
    int vwmBorderColor;
    char *backsaver;
    int taskBarFore2;
    int stripBar;
    char *lsPath;
    } wharfDataType;

typedef struct {
	int		picID;
	char	picName[256];
	char	picPath[256];
} F_INFO;
/* ----------------------------------------------------------------- */

long magicDWord = 0x49474541;

/* ----------------------------------------------------------------- */
typedef struct	{
	long	width;
	long	hight;
	long	size;
	char	*buffer;
}	IMG_BUFFER;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif

#endif
