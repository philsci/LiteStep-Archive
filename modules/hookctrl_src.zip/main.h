#if !defined(_MAIN_H)
	#define _MAIN_H

	extern BOOL SetKeyboardHook( HINSTANCE );
	extern BOOL SetMouseHook( HINSTANCE );
	extern BOOL SetShellHook( HINSTANCE );

	typedef __declspec( dllimport ) HWND (*LSAPI_GetLitestepWnd) ( VOID );
	typedef __declspec( dllimport ) BOOL (*LSAPI_GetRCBool) ( LPCTSTR, BOOL );

	#ifdef __cplusplus
		extern "C" {
	#endif

			__declspec( dllexport ) INT initModuleEx( HWND, HINSTANCE, LPCTSTR );
			__declspec( dllexport ) VOID quitModule( HINSTANCE );

	#ifdef __cplusplus
		}
	#endif
#endif /* _MAIN_H */