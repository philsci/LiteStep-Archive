#include <tchar.h>
#include <windows.h>

extern HWND g_ShellWnd;
extern HHOOK g_MouseHook;


LRESULT CALLBACK MouseProc( INT nCode, WPARAM wParam, LPARAM lParam )
{
	return CallNextHookEx( g_MouseHook, nCode, wParam, lParam );
}

// Hook (un)installation management
BOOL SetMouseHook( HINSTANCE dll )
{
	
	if (dll && !g_MouseHook)
		g_MouseHook = SetWindowsHookEx(WH_MOUSE, (HOOKPROC)MouseProc, dll, 0);
	else if (g_MouseHook && !dll){
		if (UnhookWindowsHookEx(g_MouseHook))
			g_MouseHook = NULL;
	}

	return g_MouseHook != NULL;
}
