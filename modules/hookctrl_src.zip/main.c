#include <tchar.h>
#include <windows.h>

#include "main.h"

#pragma data_seg(".DATAHK")
	HWND g_ShellWnd = NULL;
	HHOOK g_ShellHook = NULL;
	HHOOK g_MouseHook = NULL;
	HHOOK g_KeyboardHook = NULL;
#pragma data_seg()

BOOL kHook, mHook, sHook;


INT initModuleEx(HWND owner, HINSTANCE dll, LPCTSTR shellPath)
{
	_TCHAR lsapiPath[MAX_PATH] = {0};
	HINSTANCE hLSAPI = NULL;
	DWORD pathLen = 0;

	LSAPI_GetLitestepWnd GetLitestepWnd = NULL;
	LSAPI_GetRCBool GetRCBool = NULL;

	pathLen = GetModuleFileName( NULL, lsapiPath, MAX_PATH );
	while (pathLen && lsapiPath[pathLen-1] != _T('\\'))
		lsapiPath[--pathLen] = 0;

	if (!pathLen)
	{

		_tcscpy( lsapiPath, shellPath );
		pathLen = _tcslen(lsapiPath);
	
		if ( lsapiPath[pathLen-1] != _T('\\') )
		{

			lsapiPath[pathLen] = _T('\\');
			lsapiPath[pathLen+1] = 0;

		}

	}

	_tcscat( lsapiPath, _T("lsapi.dll") );

	hLSAPI = LoadLibrary( lsapiPath );
	if (hLSAPI != NULL)
	{

		GetRCBool = (LSAPI_GetRCBool)GetProcAddress( hLSAPI,  "GetRCBool" );
		GetLitestepWnd = (LSAPI_GetLitestepWnd)GetProcAddress( hLSAPI,  "GetLitestepWnd" );

		if (GetRCBool != NULL && GetLitestepWnd != NULL)
		{

			if ((g_ShellWnd = GetLitestepWnd()) != NULL)
			{

					/* Enable Keyboard Hook */
                //should probably activate them in later builds
                /*
				if ((kHook = GetRCBool( _T("HookCtrlEnableKeyboardHook"), TRUE)) == TRUE)
					SetKeyboardHook( dll );
                */

					/* Enable Mouse Hook */
                /*
				if ((mHook = GetRCBool( _T("HookCtrlEnableMouseHook"), TRUE)) == TRUE)
					SetMouseHook( dll );
                */
        
					/* Enable Shell Hook */
				if ((sHook = GetRCBool( _T("HookCtrlEnableShellHook"), TRUE)) == TRUE)
				{

					MINIMIZEDMETRICS mm;

					memset(&mm, 0, sizeof(MINIMIZEDMETRICS));
					mm.cbSize = sizeof(MINIMIZEDMETRICS);
					SystemParametersInfo(SPI_GETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, 0);
					mm.iArrange |= ARW_HIDE; // ARW_HIDE == 8
					SystemParametersInfo(SPI_SETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, 0);

					SetShellHook( dll );

				}

			}		

		}

		FreeLibrary( hLSAPI );

	}
	
	return 0;

		UNREFERENCED_PARAMETER(owner);
}

void quitModule(HINSTANCE dll)
{

	if (kHook)
		SetKeyboardHook( NULL );

	if (mHook)
		SetMouseHook( NULL );

	if (sHook)
	{

		MINIMIZEDMETRICS mm;

		memset(&mm, 0, sizeof(MINIMIZEDMETRICS));
		mm.cbSize = sizeof(MINIMIZEDMETRICS);
		SystemParametersInfo(SPI_GETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, 0);
		mm.iArrange = ARW_BOTTOMLEFT|ARW_RIGHT;
		SystemParametersInfo(SPI_SETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, 0);

		SetShellHook(NULL);

	}

	g_ShellWnd = NULL;

	return;

		UNREFERENCED_PARAMETER(dll);
}
