#include <tchar.h>
#include <windows.h>

extern HWND g_ShellWnd;
extern HHOOK g_KeyboardHook;


LRESULT CALLBACK KeyboardProc( INT nCode, WPARAM wParam, LPARAM lParam )
{
	return CallNextHookEx( g_KeyboardHook, nCode, wParam, lParam );
}


// Hook (un)installation management
BOOL SetKeyboardHook( HINSTANCE dll )
{
	
	if (dll && !g_KeyboardHook)
		g_KeyboardHook = SetWindowsHookEx(WH_KEYBOARD, (HOOKPROC)KeyboardProc, dll, 0);
	else if (g_KeyboardHook && !dll){
		if (UnhookWindowsHookEx(g_KeyboardHook))
			g_KeyboardHook = NULL;
	}

	return g_KeyboardHook != NULL;
}
