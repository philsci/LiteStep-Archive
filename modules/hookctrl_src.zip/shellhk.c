#include <tchar.h>
#include <windows.h>

#define LM_WINDOWCREATED 9501
#define LM_WINDOWDESTROYED 9502
#define LM_WINDOWACTIVATED 9504
#define LM_REDRAW 9506

extern HWND g_ShellWnd;
extern HHOOK g_ShellHook;


// Callback ShellProc
LRESULT CALLBACK ShellProc(INT nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode >= 0 && g_ShellWnd != NULL)
	{
		switch (nCode) 
		{
            /*
			case HSHELL_WINDOWCREATED:
				PostMessage(g_ShellWnd, LM_WINDOWCREATED, wParam, lParam );
				break;

			case HSHELL_WINDOWDESTROYED:
				PostMessage(g_ShellWnd, LM_WINDOWDESTROYED, wParam, lParam );
				break;

			case HSHELL_WINDOWACTIVATED:
				PostMessage(g_ShellWnd, LM_WINDOWACTIVATED, wParam, lParam );
				break;

			case HSHELL_REDRAW:
				PostMessage(g_ShellWnd, LM_REDRAW, wParam, lParam );
				break;
            */
            case HSHELL_TASKMAN:
            case HSHELL_ACTIVATESHELLWINDOW:
            case HSHELL_LANGUAGE:
              break;

            default:
            PostMessage(g_ShellWnd, nCode + 9500, wParam, lParam );
		}
	}

	return CallNextHookEx( g_ShellHook, nCode, wParam, lParam );
}

 
// Hook (un)installation management
BOOL SetShellHook( HINSTANCE dll )
{
	
	if (dll && !g_ShellHook)
		g_ShellHook = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellProc, dll, 0);
	else if (g_ShellHook && !dll){
		if (UnhookWindowsHookEx(g_ShellHook))
			g_ShellHook = NULL;
	}

	return g_ShellHook != NULL;
}
