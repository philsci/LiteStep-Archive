LSTetris (v1.1) by WhiteShadow (changty@muohio.edu) on 06-07-00
*******************************************************************

The game tetris.

Installation:

	1. Copy lstetris.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\lstetris.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep

Usage:

	Bang Commands
	-------------

	!LSTetrisShow
	!LSTetrisHide
	!LSTetrisToggle
	   These three bang commands control the visibility of the
	   game window.

	!LSTetrisFocus
	   Gives LSTetris keyboard focus.

	Step.rc Options
	---------------

	LSTetrisStartHidden
	   Makes LSTetris hidden when Litestep starts.

	LSTetrisX <num>
	LSTetrisY <num>
	   The X and Y coordinates of the upper left hand corner of 
	   the game window.

	LSTetrisWidth <num>
	LSTetrisHeight <num>
	   The size of the game window.

	LSTetrisBlockSize <num>
	   The size of a block.  This is used to determine the number
	   of rows and colums (hight/blocksize and width/blocksize).

	LSTetrisBackColor <BBGGRR>
	   The color of the background.

	LSTetrisTextColor <BBGGRR>
	   The color of text.

	LSTetrisTextSize <num>
	   The size of text in pixels.

	LSTetrisRotateClockwise
	   Add this to rotate the piece clockwise.  Omit it to rotate
	   the pieces counter-clockwise.

	LSTetrisSpeed <num>
	   The number of milliseconds before the piece falls another
	   row.  500 is default and is pretty slow.

	LSTetrisFadeLines
	   Lines fade away when cleared.

	Keys
	----
	User arrow keys or Num pad to move the piece.  Up or CTRL
	rotates the piece.  Space or 0 on the Num pad drops a
	piece.  Press Enter to start a new game.

To Be Done:
	picking block colors

History:

	v1.1 (06-07-00)
	+Text when game is over
	+LSTetrisTextColor
	+LSTetrisTextSize
	+LSTetrisRotateClockwise
	+LSTetrisSpeed
	+LSTetrisFadeLines

	v1.0 (06-05-00)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
