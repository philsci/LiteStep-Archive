//% $Id: Gandharva.h,v 1.8.2.2 2001/05/15 11:13:07 Yoshi Exp $

#ifndef _H_GANDHARVA
#define _H_GANDHARVA

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "GandharvaSettings.h"
#include "winampfunc.h"
#include "ampcmd.h"

#define WC_LSDESKTOP		"DesktopBackgroundClass"
#define WINDOWCLASS_DLL		"GandharvaClass"

#define MAGICDWORD         0x49474541

#define TIMERID		DWORD

#define USERBM_TOGGLE	0
#define USERBM_SHOW 	1
#define USERBM_HIDE 	2
#define USERBM_TOGGLE_TIME 3

#define USERBM_AMP_POWER 10000
#define USERBM_AMP_COMMANDEX 10001

#define PCM_TIME	0x0001
#define PCM_TITLE	0x0002
#define PCM_OTHER	0x0000

//macros
#define REDIRECT_BANG(__OWNER,__HANDLER,__MESSAGE) \
void __OWNER::__HANDLER(HWND caller, char* args){\
  HWND hwnd=FindWindow(WINDOWCLASS_DLL, 0);\
  if(hwnd)PostMessage(hwnd, WM_USER, __MESSAGE, (LPARAM)args);\
}

#define BEGIN_MESSAGE_PROC(__OWNER)\
  LRESULT __OWNER::WindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam){\
    LRESULT lresult;\
    switch(message){

#define MESSAGEFUNC(__HANDLER, __MESSAGE)\
    case __MESSAGE: __HANDLER(message, wparam, lparam, &lresult);break

#define END_MESSAGE_PROC\
    default: lresult=DefWindowProc(hwnd, message, wparam, lparam);\
    break;\
    }\
  return lresult;}


class Gandharva
{
public:
  Gandharva( HWND parent, HINSTANCE lsinstance );
  ~Gandharva();

  static void bangToggleVisible(HWND caller, char *args);
  static void bangToggleTime(HWND caller, char *args);
  static void bangShow(HWND caller, char *args);
  static void bangHide(HWND caller, char *args);

  static void bangAmpPrev(HWND hwnd, char *args);
  static void bangAmpPlay(HWND hwnd, char *args);
  static void bangAmpPause(HWND hwnd, char *args);
  static void bangAmpStop(HWND hwnd, char *args);
  static void bangAmpNext(HWND hwnd, char *args);
  static void bangAmpPLEdit(HWND hwnd, char *argv);
  static void bangAmpOpenFile(HWND hwnd, char *argv);
  static void bangAmpPower(HWND hwnd, char *argv);

  static void bangAmpCommand(HWND hwnd, char *argv);

private:
  DWORD ParseClickMap(int x, int y);

  void onUser(UINT, WPARAM, LPARAM, LRESULT *);
  void onPaint(UINT, WPARAM, LPARAM, LRESULT *);
  void onTimer(UINT, WPARAM, LPARAM, LRESULT *);
  void onLmGetRevid(UINT, WPARAM, LPARAM, LRESULT *);
  void onDisplayChange(UINT, WPARAM, LPARAM, LRESULT *);
  void onMouse(UINT, WPARAM, LPARAM, LRESULT *);

  CWinampFunction* m_pWinampFunc;
  GandharvaSettings* m_pSettings;

  //timer id
  UINT m_rtimer,m_stimer;

  void SetWndPos();
  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
  LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  LRESULT ParseAmpCommand(DWORD command);

  HINSTANCE	m_hInstance;
  HWND	m_hLitestep;
  HWND	m_hDesktop;
  HWND	m_hWnd;
};

#endif //_H_GANDHARVA
