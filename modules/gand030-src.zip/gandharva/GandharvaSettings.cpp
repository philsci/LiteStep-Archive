//% $Id: GandharvaSettings.cpp,v 1.13.2.2 2001/05/15 11:13:07 Yoshi Exp $

#include "GandharvaSettings.h"
#include "lsapi.h"
#include <stdlib.h>

#if defined _A2UNVLIB
#include <a2unvlib.h>
#endif


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^�Őݒ��ǂݍ���
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
GandharvaSettings::GandharvaSettings(HWND owner)
{
  LPSTR lpszbuf = new char[1024];
  char token[4][4];
  char *tokens[]={token[0], token[1], token[2], token[3], 0};

  //xxxxxxxxxxxxxxxxxxxx �V�X�e���p�����[�^������
  m_hWnd = owner;
  m_hbmBack = NULL;
  m_hbmTitle= NULL;
  m_hbmTime = NULL;

  //xxxxxxxxxxxxxxxxxxxx TextLogFont
//m_TextLogFont.lfHeight;
  m_TextLogFont.lfWidth = 0;
  m_TextLogFont.lfEscapement = 0;
  m_TextLogFont.lfOrientation = 0;
//m_TextLogFont.lfWeight;
//m_TextLogFont.lfItalic;
  m_TextLogFont.lfUnderline = FALSE;
  m_TextLogFont.lfStrikeOut = FALSE;
  m_TextLogFont.lfCharSet = DEFAULT_CHARSET;
  m_TextLogFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
  m_TextLogFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
  m_TextLogFont.lfQuality = DEFAULT_QUALITY;
  m_TextLogFont.lfPitchAndFamily = DEFAULT_PITCH|FF_DONTCARE;
//m_TextLogFont.lfFaceName[LF_FACESIZE];

  //xxxxxxxxxxxxxxxxxxxx ��{�ݒ�
  GetRCString("GandharvaFont", m_TextLogFont.lfFaceName, "MS UI Gothic", LF_FACESIZE);
  m_TextLogFont.lfHeight =GetRCInt("GandharvaFontSize", 16);
  m_FontColor	=GetRCColor("GandharvaFontColor", 0x00FFFFFF);
  m_BGColor		=GetRCColor("GandharvaBGColor", 0x000000);
  m_BorderColor	=GetRCColor("GandharvaBorderColor", 0x888888);
//  m_bTranspBack	= (m_BGColor == 0xFF00FF || m_BorderColor == 0xFF00FF) ? TRUE : FALSE;

  m_bTitleScroll = GetRCBool("GandharvaAutoScroll", TRUE);

  m_TextLogFont.lfItalic = GetRCBool("GandharvaFontItalic", TRUE);
  if(GetRCBool("GandharvaFontBold", TRUE))
    m_TextLogFont.lfWeight = 700;
  else
    m_TextLogFont.lfWeight = 400;
  
  m_PosX = GetRCInt("GandharvaX", 0);
  m_PosY = GetRCInt("GandharvaY", 0);
  m_Width= GetRCInt("GandharvaWidth", 180);
  m_Height=GetRCInt("GandharvaHeight", 20);

  // bitmap
  GetRCString("GandharvaBitmap", lpszbuf, "", MAX_PATH);

  if(*lpszbuf){
    m_hbmBack = LoadLSImage(lpszbuf, NULL);

    //�r�b�g�}�b�v�ɂ��킹�ăT�C�Y�C��
    if(m_hbmBack)
      GetLSBitmapSize(m_hbmBack, &m_Width, &m_Height);
  }

  //xxxxxxxxxxxxxxxxxxxx�g���ݒ�
  GetRCString("GandharvaDefaultString", m_lpszTitleDefault, "", 128);

  //window style
  m_bAlwaysOnTop = GetRCBool("GandharvaAlwaysOnTop", TRUE);
  m_bVisible = GetRCBool("GandharvaHidden", FALSE);

  //border
  GetRCLine("GandharvaBorderSize", lpszbuf, MAX_RCCOMMAND, "0");

  if(4 == LCTokenize(lpszbuf, NULL, 0, NULL)){
    LCTokenize(lpszbuf, tokens, 4, NULL);

    m_nBorderTop   =atoi(token[0]);
    m_nBorderRight =atoi(token[1]);
    m_nBorderBottom=atoi(token[2]);
    m_nBorderLeft  =atoi(token[3]);
  }else
    m_nBorderTop = m_nBorderRight = m_nBorderBottom = m_nBorderLeft = GetRCInt("GandharvaBorderSize", 0);

  //for compatibility with old ver.
  m_nBorderTop   =GetRCInt("GandharvaBorderTop"   , m_nBorderTop);
  m_nBorderRight =GetRCInt("GandharvaBorderRight" , m_nBorderRight);
  m_nBorderBottom=GetRCInt("GandharvaBorderBottom", m_nBorderBottom);
  m_nBorderLeft  =GetRCInt("GandharvaBorderLeft"  , m_nBorderLeft);

  //padding
  GetRCLine("GandharvaPadding", lpszbuf, MAX_RCCOMMAND, "0");

  if(4 == LCTokenize(lpszbuf, NULL, 0, NULL)){
    LCTokenize(lpszbuf, tokens, 4, NULL);

    m_nPaddingTop   =atoi(token[0]);
    m_nPaddingRight =atoi(token[1]);
    m_nPaddingBottom=atoi(token[2]);
    m_nPaddingLeft  =atoi(token[3]);
  }else
    m_nPaddingTop = m_nPaddingRight = m_nPaddingBottom = m_nPaddingLeft = atoi(lpszbuf);

  //scroll
  m_nScrollInterval = GetRCInt("GandharvaScrollInterval", 500);
  if(m_nScrollInterval < 0)
    m_nScrollInterval = 500;

  m_nScrollStep = GetRCInt("GandharvaScrollStep", 4);
  if(m_nScrollStep < 1)
    m_nScrollStep = 4;

  //prefix suffix
  m_bKeepPrefix = GetRCBool("GandharvaKeepPrefix", TRUE);
  m_bKeepSuffix = GetRCBool("GandharvaKeepSuffix", TRUE);

  //!command mode
  GetRCString("GandharvaCommandMode", lpszbuf, "basic", 64);

  if(!strcmpi(lpszbuf, "none"))	m_swCmdMode=CMDMODE_NONE;
  if(!strcmpi(lpszbuf, "basic"))	m_swCmdMode=CMDMODE_BASIC;
  if(!strcmpi(lpszbuf, "extension")) m_swCmdMode=CMDMODE_BASIC; //old version

  //text align
  GetRCString("GandharvaTextAlignH", lpszbuf, "left", 64);

  if(!strcmpi(lpszbuf, "left")) m_swTextAlignH=ALIGN_LEFT;
  if(!strcmpi(lpszbuf, "right")) m_swTextAlignH=ALIGN_RIGHT;
  if(!strcmpi(lpszbuf, "center")) m_swTextAlignH=ALIGN_CENTER;

  //xxxxxxxxxxxxxxxxxxxx time display
  memcpy(&m_TimeLogFont, &m_TextLogFont, sizeof(LOGFONT));

  GetRCString("GandharvaTime", lpszbuf, "", MAX_RCCOMMAND);

  if(!stricmp(lpszbuf, "elapsed")){
    m_bTimeEnable = TRUE;
    m_bTimeRemain = FALSE;
  }else if(!stricmp(lpszbuf, "remain")){
    m_bTimeEnable = TRUE;
    m_bTimeRemain = TRUE;
  }else{
    m_bTimeEnable = FALSE;
    m_bTimeRemain = FALSE;
  }

  if(GetRCString("GandharvaTimeFont", lpszbuf, "", LF_FACESIZE))
    strcpy(m_TimeLogFont.lfFaceName, lpszbuf);

  m_TimeFontColor =GetRCColor("GandharvaTimeFontColor", m_FontColor);

  m_TimeLogFont.lfHeight = GetRCInt("GandharvaTimeFontSize",    m_TextLogFont.lfHeight);
  if(GetRCBool("GandharvaTimeFontItalic", TRUE))
    m_TimeLogFont.lfItalic = TRUE;

  if(GetRCBool("GandharvaTimeFontBold", TRUE))
    m_TimeLogFont.lfWeight = 700;

  GetRCLine("GandharvaTimePadding", lpszbuf, MAX_RCCOMMAND, "0");

  if(4 == LCTokenize(lpszbuf, NULL, 0, NULL)){
    LCTokenize(lpszbuf, tokens, 4, NULL);

    m_nATPaddingTop   =atoi(token[0]);
    m_nATPaddingRight =atoi(token[1]);
    m_nATPaddingBottom=atoi(token[2]);
    m_nATPaddingLeft  =atoi(token[3]);
  }else
    m_nATPaddingTop = m_nATPaddingRight = m_nATPaddingBottom = m_nATPaddingLeft = atoi(lpszbuf);

  //xxxxxxxxxxxxxxxxxxxx �ꎞ�o�b�t�@�̔j��
  delete lpszbuf;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
GandharvaSettings::~GandharvaSettings()
{
  if(m_hbmBack)
    DeleteObject(m_hbmBack);
  if(m_hbmTitle)
    DeleteObject(m_hbmTitle);
  if(m_hbmTime)
    DeleteObject(m_hbmTime);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̏o��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintBG(HDC hdcdst)
{
  HDC hdc;
  HBITMAP hbmold;
  
  //xxxxxxxxxxxxxxxxxxxx �w�i�̍쐬�͂܂��H
  if( !m_hbmBack )
    CreateBG();

  //xxxxxxxxxxxxxxxxxxxx �w�i���R�s�[
  hdc    = CreateCompatibleDC(hdcdst);
  hbmold = (HBITMAP)SelectObject(hdc, m_hbmBack);

  BitBlt(hdcdst, 0, 0, m_Width, m_Height, hdc, 0, 0, SRCCOPY);

  SelectObject(hdc, hbmold);
  DeleteDC(hdc);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̍쐬
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::CreateBG()
{
  HDC	hdcScreen,hdcBack;
  HBITMAP hbmBackOld;
  RECT rect;
  HBRUSH hbrush;

  //xxxxxxxxxxxxxxxxxxxx �E�C���h�E�R���p�`��DC,BMP
  hdcScreen = GetDC(m_hWnd);
  hdcBack = CreateCompatibleDC(hdcScreen);
  m_hbmBack = CreateCompatibleBitmap(hdcScreen, m_Width, m_Height);

  hbmBackOld = (HBITMAP)SelectObject(hdcBack, m_hbmBack);

  //xxxxxxxxxxxxxxxxxxxx �ǎ���؂����ăE�B���h�E�ɒ���t����i�Ȃ񂿂���ē��߁j
  PaintDesktop(hdcScreen);
  BitBlt(hdcBack, 0, 0, m_Width, m_Height, hdcScreen, 0, 0, SRCCOPY);

  ReleaseDC(m_hWnd, hdcScreen);

  //xxxxxxxxxxxxxxxxxxxx �g
  if(m_BorderColor != 0xFF00FF){
    hbrush = CreateSolidBrush(m_BorderColor);

    rect.left = 0;
    rect.top = 0;
    rect.right = m_Width;
    rect.bottom = m_nBorderTop;

    if(m_nBorderTop)
      FillRect(hdcBack, &rect, hbrush);

    rect.top = m_Height - m_nBorderBottom;
    rect.bottom = m_Height;

    if(m_nBorderBottom)
      FillRect(hdcBack, &rect, hbrush);

    rect.top = 0;
    rect.right = m_nBorderLeft;

    if(m_nBorderLeft)
      FillRect(hdcBack, &rect, hbrush);

    rect.left = m_Width - m_nBorderRight;
    rect.right = m_Width;

    if(m_nBorderRight)
      FillRect(hdcBack, &rect, hbrush);

    DeleteObject(hbrush);
  }

  //xxxxxxxxxxxxxxxxxxxx �o�b�N�O���E���h
  if(m_BGColor != 0xFF00FF){
    rect.left = m_nBorderLeft;
    rect.top = m_nBorderTop;
    rect.right = m_Width - m_nBorderRight;
    rect.bottom = m_Height - m_nBorderBottom;

    hbrush = CreateSolidBrush(m_BGColor);
    FillRect(hdcBack, &rect, hbrush);
    DeleteObject(hbrush);
  }

  //xxxxxxxxxxxxxxxxxxxx �㏈��
  SelectObject(hdcBack, hbmBackOld);
  DeleteDC(hdcBack);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	������̃r�b�g�}�b�v���쐬
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
HBITMAP GandharvaSettings::CreateTextBitmap(LPSTR lpszTextStr, LOGFONT lf, COLORREF color)
{
  HDC hdcwnd,hmemdc;
  HBITMAP hbitmap,hbmold;
  HFONT hfont,hfontold;
  SIZE size;
  long textlen;

  //������͓K�����H
  if(!lpszTextStr)
    return NULL;

  textlen= strlen(lpszTextStr);
  if(!textlen)
    return NULL;

  //�r�b�g�}�b�v�̃T�C�Y�𒲂ׂ�
  hmemdc = CreateCompatibleDC(NULL);

#if defined _A2UNVLIB
  hfont = CreateFontIndirectC(&lf);
#else
  hfont = CreateFontIndirect(&lf);
#endif
  
  hfontold = (HFONT)SelectObject(hmemdc, hfont);
  GetTextExtentPoint32(hmemdc, lpszTextStr, textlen, &size);
  SelectObject(hmemdc, hfontold);
  DeleteDC(hmemdc);

  //���߂�
  hmemdc = CreateCompatibleDC(NULL);
  hfontold = (HFONT)SelectObject(hmemdc, hfont);

  hdcwnd = GetDC(m_hWnd);
  hbitmap = CreateCompatibleBitmap(hdcwnd, size.cx, size.cy);
  ReleaseDC(m_hWnd, hdcwnd);

  if(hbitmap) {
    hbmold = (HBITMAP)SelectObject(hmemdc, hbitmap);

    //�F�w��i�w�i�F�����ߐF�͐摗��^^;�j
    SetTextColor(hmemdc, color);
    SetBkColor(hmemdc, m_BGColor);

    //�`��
    TextOut(hmemdc, 0, 0, lpszTextStr, textlen);

    SelectObject(hmemdc, hbmold);
  }
  
  //��n��
  SelectObject(hmemdc, hfontold);

  DeleteObject(hfont);
  DeleteDC(hmemdc);

  return hbitmap;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���Ԃ�\��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintTime(HDC hdcDst)
{
  int cx,cy;
  HDC hdctemp = CreateCompatibleDC(NULL);
  HBITMAP hbmold = (HBITMAP)SelectObject(hdctemp, m_hbmTime);

  GetLSBitmapSize(m_hbmTime, &cx, &cy);

  TransparentBltLS(hdcDst,
                   m_nATPaddingLeft,
                   m_nATPaddingTop,
                   min(m_Width-(m_nATPaddingRight+m_nATPaddingLeft), cx),
                   min(m_Height-(m_nATPaddingBottom+m_nATPaddingTop), cy),
                   hdctemp,
                   0,
                   0,
                   m_BGColor);

  SelectObject(hdctemp, hbmold);
  DeleteDC(hdctemp);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�^�C�g����\���i�X�N���[������j
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintText(HDC hdcDst)
{
  HDC hdctext;
  HBITMAP hbmold;
  int dx,dy,dcx,dcy;
  RECT clippedRECT;
  SIZE textSIZE,clippedSIZE;

  int SeparateWidth,SecondOffset;

  if(!m_hbmTitle)
    return;

  GetLSBitmapSize(m_hbmTitle, (int *)&textSIZE.cx, (int *)&textSIZE.cy);

  //xxxxxxxxxxxxxxxxxxxx PaddingSize�����ɃN���b�s���O�̈��ݒ�
  clippedRECT.left = m_nPaddingLeft;
  clippedRECT.top = m_nPaddingTop;
  clippedRECT.right = m_Width - m_nPaddingRight;
  clippedRECT.bottom = m_Height - m_nPaddingBottom;

  clippedSIZE.cx = clippedRECT.right - clippedRECT.left;
  clippedSIZE.cy = clippedRECT.bottom - clippedRECT.top;

  //xxxxxxxxxxxxxxxxxxxx �X�N���[���̌v�Z
  SeparateWidth = clippedSIZE.cx/4;
  SecondOffset = textSIZE.cx - m_nScrollOffset + SeparateWidth;

  //�Z�J���h�����֐؂�n�߂���A���C���ƌ��
  if(SecondOffset <= 0){
    m_nScrollOffset = -SecondOffset;
    SecondOffset = textSIZE.cx - m_nScrollOffset + SeparateWidth;
  }

  //�R�s�[������
  hdctext = CreateCompatibleDC(NULL);
  hbmold = (HBITMAP)SelectObject(hdctext, m_hbmTitle);

  //  [TTTTTTTT]
  //  |---->��������������
  if(m_nScrollOffset < textSIZE.cx){
    dx = clippedRECT.left;
    dy = clippedRECT.top;
    dcx = min(clippedSIZE.cx, textSIZE.cx-m_nScrollOffset);
    dcy = min(clippedSIZE.cy, textSIZE.cy);

    TransparentBltLS(hdcDst, dx, dy, dcx, dcy, hdctext, m_nScrollOffset, 0, m_BGColor);
  }
  //        |-------->[TTTTTTT]
  //        ��������������
  if(SecondOffset < clippedSIZE.cx){
    dx = clippedRECT.left+SecondOffset;
    dy = clippedRECT.top;
    dcx = clippedSIZE.cx-SecondOffset;
    dcy = min(clippedSIZE.cy, textSIZE.cy);

    TransparentBltLS(hdcDst, dx, dy, dcx, dcy, hdctext, 0, 0, m_BGColor);
  }

  //xxxxxxxxxxxxxxxxxxxxBMP��߂�
  SelectObject(hdctext, hbmold);

  //xxxxxxxxxxxxxxxxxxxx�j��
  DeleteDC(hdctext);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�^�C�g����\���i�X�N���[�������j
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintTextNoScroll(HDC hdcDst)
{
  HDC hdctext;
  HBITMAP hbmold;
  int offset,txtcx,txtcy,clipcx,clipcy;

  if(!m_hbmTitle)
    return;

  GetLSBitmapSize(m_hbmTitle, &txtcx, &txtcy);

  //�N���b�s���O�T�C�Y��ݒ�
  clipcx = m_Width - (m_nPaddingRight+m_nPaddingLeft);
  clipcy = m_Height- (m_nPaddingBottom+m_nPaddingTop);
  
  //align
  switch(m_swTextAlignH){ 
  case ALIGN_RIGHT:
    offset = clipcx - txtcx;
    break;
  case ALIGN_CENTER:
    offset = (clipcx - txtcx)/2;
    break;
  default:
    offset = 0;
    break;
  }

  //xxxxxxxxxxxxxxxxxxxx �R�s�[
  hdctext = CreateCompatibleDC(NULL);
  hbmold = (HBITMAP)SelectObject(hdctext, m_hbmTitle);

  //
  TransparentBltLS(hdcDst,
                   max(m_nPaddingLeft, m_nPaddingLeft+offset),
                   m_nPaddingTop,
                   min(clipcx,txtcx),
                   min(clipcy,txtcy),
                   hdctext,
                   0,
                   0,
                   m_BGColor);
  //xxxxxxxxxxxxxxxxxxxxBMP��߂�
  SelectObject(hdctext, hbmold);

  //xxxxxxxxxxxxxxxxxxxx�j��
  DeleteDC(hdctext);
}
