/*============================================================================
%	$Id: winampFunc.h,v 1.7 2001/05/15 11:38:08 Yoshi Exp $

  Winamp control class header.
		copyright (C) 2000,2001 Yoshifumi Hoshino,(Yoshi)   all right reserved.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA



============================================================================*/
#ifndef _CLASS_WINAMP_FUNCTION
#define _CLASS_WINAMP_FUNCTION

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#define WC_WINAMP "Winamp v1.x"
#define WC_WINAMP3 "STUDIO"


#define DEFAULT_WINAMP_SUFFIX "- Winamp"

#define GWT_REFRESH  TRUE
#define GWT_COPYONLY FALSE

#define IPC_ISPLAYING 104
#define GPS_PLAYING	1
#define GPS_PAUSED	2
#define GPS_STOPPED	0
#define GPS_MISSING 9

#define IPC_GETOUTPUTTIME 105
#define GPT_ELAPSED	0
#define GPT_REMAIN		1
#define GPT_TOTAL		10
#define GPT_ELAPSED_MILLISEC 20



#include "ampcmd.h"

class CWinampFunction 
{
public:
  CWinampFunction(LPSTR DefaultStr =NULL);
  ~CWinampFunction();

  BOOL Execute(HWND owner);
  virtual BOOL Close(){  return PostCommand(AMPAPI_CMD_CLOSE);}
  HWND FindWindow();
  BOOL GetTitle(LPSTR, BOOL);
  long GetPlaybackTime(DWORD mode);
  UINT GetPlaybackStatus();
  BOOL PostCommand(DWORD command);
  void DisplayMainMenu();
  void SetFormat(LPSTR TitleBuffer, BOOL Prefix, BOOL Suffix);

  /*Compatible with old ver*/
  virtual HWND FindWinamp() { return FindWindow();}
  virtual BOOL GetWinampTitle(LPSTR str, BOOL mode){ return GetTitle(str, mode);}
  virtual BOOL CloseWinamp() { return PostCommand(AMPAPI_CMD_CLOSE);}
  virtual BOOL ExecuteWinamp(HWND owner) { return Execute(owner);}
  virtual BOOL SendWinampCommand(DWORD cmd) { return PostCommand(cmd);}

private:
  BOOL GetWinampPath(LPSTR);

#ifdef _WINAMP3_ALPHA
  BOOL m_bSenceWA3;
#endif

  LPSTR m_lpszWinampTitle;
  LPSTR m_lpszDefaultTitle;
};

#endif  //_CLASS_WINAMP_FUNCTION