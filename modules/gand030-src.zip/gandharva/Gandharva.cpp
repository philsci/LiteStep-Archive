//% $Id: Gandharva.cpp,v 1.17.2.2 2001/05/15 11:13:07 Yoshi Exp $
#include "lsapi.h"
#include "Gandharva.h"

#define BUILD_NAME		TEXT("Gandharva.dll")
#define BUILD_VERSION	TEXT("v0.30")
#define BUILD_DATE		TEXT("2001/05/15")
#define BUILD_AUTHOR	TEXT("Yoshi")


UINT nMessages[] = {
  LM_GETREVID,
  0
};


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^
		�E�B���h�E�̃Z�b�g�A�b�v
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
Gandharva::Gandharva( HWND parent, HINSTANCE lsinstance )
{
  LRESULT lresult;

  //xxxxxxxxxxxxxxxxxxxx�V�X�e�����̏�����
  m_hLitestep = GetLitestepWnd();
  m_hInstance = lsinstance;
  m_hDesktop = FindWindow(WC_LSDESKTOP, NULL);

  m_pSettings = NULL;
  m_pWinampFunc = NULL;

  if(!m_hDesktop)
    m_hDesktop = GetDesktopWindow();

  //xxxxxxxxxxxxxxxxxxxx�E�C���h�E�N���X
  WNDCLASSEX wc;

  wc.cbSize = sizeof(WNDCLASSEX);
  wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
  wc.lpfnWndProc = (WNDPROC) Gandharva::WndProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 4;
  wc.hInstance = m_hInstance;
  wc.hCursor = LoadCursor( NULL, IDC_ARROW );
  wc.hIcon = NULL;
  wc.hIconSm = NULL;
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NULL;
  wc.lpszClassName = WINDOWCLASS_DLL;

  if (!RegisterClassEx( &wc ) ) {
    MessageBox(0,TEXT("failed to register window class."),WINDOWCLASS_DLL,MB_OK|MB_SYSTEMMODAL);
    return;
  }

  //xxxxxxxxxxxxxxxxxxxx�E�C���h�E�̍쐬
  m_hWnd = CreateWindowEx( WS_EX_TOOLWINDOW,//|WS_EX_TRANSPARENT,
                         WINDOWCLASS_DLL, NULL, WS_POPUP,
                         0, 0, 0, 0,
                         m_hDesktop, NULL, m_hInstance, (LPVOID)this);

  if (!m_hWnd) {
    MessageBox(0,TEXT("failed to create window."),WINDOWCLASS_DLL,MB_OK|MB_SYSTEMMODAL);
    return;
  }

  //xxxxxxxxxxxxxxxxxxxxLITESTEP �Ƀ��W���[���o�^
  SendMessage( m_hLitestep, LM_REGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );
  SetWindowLong( m_hWnd, GWL_USERDATA, (LONG)MAGICDWORD );

  //xxxxxxxxxxxxxxxxxxxx�ݒ�̓ǂݍ��݂Ɣ��f
  m_pSettings = new GandharvaSettings(m_hWnd);

  if(!m_pSettings){
    MessageBox(0, "failed to load settings.", WINDOWCLASS_DLL, MB_OK|MB_SYSTEMMODAL);
    return;
  }

  SetWindowPos(m_hWnd,
               (m_pSettings->m_bAlwaysOnTop) ? HWND_TOPMOST : HWND_TOP,
               0,
               0,
               m_pSettings->m_Width,
               m_pSettings->m_Height,
               SWP_NOMOVE|SWP_NOACTIVATE);

  SetWndPos();

  //xxxxxxxxxxxxxxxxxxxx �I�a�`�m�f�̒ǉ�
  AddBangCommand("!GandharvaToggle", bangToggleVisible);
  AddBangCommand("!GandharvaToggleTime", bangToggleTime);
  AddBangCommand("!GandharvaShow", bangShow);
  AddBangCommand("!GandharvaHide", bangHide);

  if(m_pSettings->m_swCmdMode){
    AddBangCommand("!GandharvaCmdPrev", bangAmpPrev);
    AddBangCommand("!GandharvaCmdPlay", bangAmpPlay);
    AddBangCommand("!GandharvaCmdPause", bangAmpPause);
    AddBangCommand("!GandharvaCmdStop", bangAmpStop);
    AddBangCommand("!GandharvaCmdNext", bangAmpNext);
    AddBangCommand("!GandharvaCmdPLEdit", bangAmpPLEdit);
    AddBangCommand("!GandharvaCmdOpenFile", bangAmpOpenFile);
    AddBangCommand("!GandharvaCmdPower", bangAmpPower);
    AddBangCommand("!GandharvaCmdExtension", bangAmpCommand);
  }
  //xxxxxxxxxxxxxxxxxxxx winamp�t�@���N�V����
  char *buf=new char[256];

  //�f�t�H���g������
  if(NULL == *m_pSettings->m_lpszTitleDefault)
    onLmGetRevid(LM_GETREVID, 0, (LPARAM)buf, &lresult);
  else
    strcpy(buf, m_pSettings->m_lpszTitleDefault);

  m_pWinampFunc = new CWinampFunction(buf);

  delete buf;

  //xxxxxxxxxxxxxxxxxxxx�^�C�}�[
  if(NULL == (m_rtimer = SetTimer(m_hWnd, TIMERID_RECYCLE_DISPLAY, 1000, NULL)))
    MessageBox(0,TEXT("Fail to create timer for title refresh."),WINDOWCLASS_DLL,MB_OK|MB_SYSTEMMODAL);

  m_stimer = NULL;

  //�����؂�Ă�ǂ��H
  onTimer(WM_TIMER, TIMERID_RECYCLE_DISPLAY, 0, &lresult);

  //xxxxxxxxxxxxxxxxxxxx�E�B���h�E�̕\��
  ShowWindow( m_hWnd,  !m_pSettings->m_bVisible ? SW_HIDE : SW_SHOWNOACTIVATE );

  return;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
		�E�C���h�E�̔j��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
Gandharva::~Gandharva()
{
  //xxxxxxxxxxxxxxxxxxxx winamp�t�@���N�V����
  if(m_pWinampFunc)
    delete m_pWinampFunc;

  //xxxxxxxxxxxxxxxxxxxx �I�a�`�m�f�̍폜
  if(m_pSettings && m_pSettings->m_swCmdMode){
    RemoveBangCommand("!GandharvaCmdExtension");
    RemoveBangCommand("!GandharvaCmdPower");
    RemoveBangCommand("!GandharvaCmdOpenFile");
    RemoveBangCommand("!GandharvaCmdPLEdit");
    RemoveBangCommand("!GandharvaCmdNext");
    RemoveBangCommand("!GandharvaCmdStop");
    RemoveBangCommand("!GandharvaCmdPause");
    RemoveBangCommand("!GandharvaCmdPlay");
    RemoveBangCommand("!GandharvaCmdPrev");
  }

  RemoveBangCommand("!GandharvaHide");
  RemoveBangCommand("!GandharvaShow");
  RemoveBangCommand("!GandharvaToggleTime");
  RemoveBangCommand("!GandharvaToggle");

  //xxxxxxxxxxxxxxxxxxxx ���W���[���o�^�̔j��
  SendMessage( m_hLitestep, LM_UNREGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );

  //xxxxxxxxxxxxxxxxxxxx �^�C�}�[�̍폜���ݒ�N���X�̍폜
  if(m_rtimer)
    KillTimer(m_hWnd, TIMERID_RECYCLE_DISPLAY);
  if(m_stimer)
    KillTimer(m_hWnd, TIMERID_SCROLL_INTERVAL);

  if(m_pSettings){
    delete m_pSettings;
    m_pSettings = NULL;
  }
  //xxxxxxxxxxxxxxxxxxxx �E�C���h�E�i�N���X�j�̔j��
  DestroyWindow( m_hWnd );
  m_hWnd = NULL;

  UnregisterClass( WINDOWCLASS_DLL, m_hInstance );

  return;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̈ړ�
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::SetWndPos()
{
  SetWindowPos(m_hWnd,
               NULL,
               m_pSettings->m_PosX +((m_pSettings->m_PosX < 0) ? GetSystemMetrics(SM_CXSCREEN) : 0),
               m_pSettings->m_PosY +((m_pSettings->m_PosY < 0) ? GetSystemMetrics(SM_CYSCREEN) : 0),
               0,0,
               SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOZORDER);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�v���V�[�W��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
LRESULT CALLBACK Gandharva::WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
  Gandharva *pGandharva;

  // �E�C���h�E�쐬�O��
  if(message == WM_NCCREATE){
    LPCREATESTRUCT lpcs = (LPCREATESTRUCT)lparam;
    pGandharva = (Gandharva *)lpcs->lpCreateParams;

    SetWindowLong(hwnd, 0, (long)pGandharva);
  }else
    pGandharva = (Gandharva *)GetWindowLong(hwnd, 0);

  if(pGandharva)
    //�v���V�[�W������
    return pGandharva->WindowProc(hwnd, message, wparam, lparam);

  // ���C���̃|�C���^�����߂Ȃ��ꍇ
  return DefWindowProc(hwnd, message, wparam, lparam);
}

//Gandharva::WindowProc
BEGIN_MESSAGE_PROC(Gandharva)
  MESSAGEFUNC(onPaint,			WM_PAINT);
  MESSAGEFUNC(onTimer,			WM_TIMER);
  MESSAGEFUNC(onDisplayChange,	WM_DISPLAYCHANGE);
  MESSAGEFUNC(onMouse,			WM_LBUTTONDBLCLK);
  MESSAGEFUNC(onMouse,			WM_LBUTTONUP);
  MESSAGEFUNC(onMouse,			WM_RBUTTONUP);
  MESSAGEFUNC(onUser,			WM_USER);
  MESSAGEFUNC(onLmGetRevid,		LM_GETREVID);
END_MESSAGE_PROC




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���W���[���̃o�[�W������n��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onLmGetRevid(UINT message, WPARAM wparam, LPARAM lparam, LRESULT *plresult)
{
  UINT mode = (UINT)wparam;
  char *buffer = (char *)lparam;

  //xxxxxxxxxxxxxxxxxxxx �}���ʎq�̐ݒ�
#if defined _A2UNVLIB

#if defined _WINAMP3_ALPHA
 #define _BRANCH TEXT("(uw3)")
#else
 #define _BRANCH TEXT("(u)")
#endif

#else //_A2UNVLIB

#if defined _WINAMP3_ALPHA
 #define _BRANCH TEXT("(w3)")
#endif

#endif //_A2UNVLIB

  //xxxxxxxxxxxxxxxxxxxx �o�[�W����������
  switch(mode){
#if defined _DEBUG
  case 0:
    sprintf(buffer, "%s:debug%s %s %s", BUILD_NAME, _BRANCH, __DATE__, __TIME__);
    break;
#else
  case 0:
    sprintf(buffer, "%s:%s%s", BUILD_NAME, BUILD_VERSION, _BRANCH);
    break;
#endif //_DEBUG

  case 1:
    sprintf(buffer, "Id:%s %s%s %s %s", BUILD_NAME, BUILD_VERSION, _BRANCH, BUILD_DATE, BUILD_AUTHOR);
    break;

  default:
    strcpy(buffer, "");
    break;
  }

  *plresult = (LRESULT)strlen(buffer);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̕`��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onPaint(UINT message, WPARAM wparam, LPARAM lparam, LRESULT *plresult)
{
  HDC hdcScreen;
  HDC hdcTemp;
  HBITMAP hbmTemp,hbmOld;

  //xxxxxxxxxxxxxxxxxxxx �`����J�n����
  PAINTSTRUCT ps;
  hdcScreen = BeginPaint(m_hWnd, &ps);

  //xxxxxxxxxxxxxxxxxxxx �e�n���h���̍쐬
  hdcTemp = CreateCompatibleDC(hdcScreen);
  hbmTemp = CreateCompatibleBitmap(hdcScreen, m_pSettings->m_Width, m_pSettings->m_Height);

  //xxxxxxxxxxxxxxxxxxxx �r�b�g�}�b�v�̓K�p�ƃo�b�N�A�b�v
  hbmOld = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

  //xxxxxxxxxxxxxxxxxxxx �w�i�̕`��
  m_pSettings->PaintBG(hdcTemp);

  //xxxxxxxxxxxxxxxxxxxx �e�L�X�g���d�ˍ��킹��
  if(m_pWinampFunc) {
    //winamp ���ԕ\��
    if(m_pSettings->m_bTimeEnable){
      m_pSettings->PaintTime(hdcTemp);
    }
  }
  //�^�C�g���\��
  int bcx,bcy;
  GetLSBitmapSize(m_pSettings->m_hbmTitle, &bcx, &bcy);
  if(m_pSettings->m_bTitleScroll && bcx > m_pSettings->m_Width -(m_pSettings->m_nPaddingRight+m_pSettings->m_nPaddingLeft)){
    m_pSettings->PaintText(hdcTemp);
    //�^�C�}�[���N��
    if(!m_stimer)
      m_stimer = SetTimer(m_hWnd, TIMERID_SCROLL_INTERVAL, m_pSettings->m_nScrollInterval, NULL);
  } else {
    m_pSettings->PaintTextNoScroll(hdcTemp);
    //�X�N���[���^�C�}�[�͂���Ȃ�
    if(m_stimer){
      KillTimer(m_hWnd, TIMERID_SCROLL_INTERVAL);
      m_stimer = NULL;
    }
  }

  //xxxxxxxxxxxxxxxxxxxx �w�i���߂���H

  //xxxxxxxxxxxxxxxxxxxx �E�B���h�E�ɓ]��
  BitBlt(hdcScreen, 0, 0, m_pSettings->m_Width, m_pSettings->m_Height, hdcTemp, 0, 0, SRCCOPY);

  //xxxxxxxxxxxxxxxxxxxx �e��n���h���̔j��
  EndPaint(m_hWnd, &ps);

  SelectObject(hdcTemp, hbmOld);

  DeleteObject(hbmTemp);
  DeleteDC(hdcTemp);

  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�^�C�}�[����
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onTimer(UINT message, WPARAM wparam, LPARAM lparam, LRESULT *plresult)
{
  char lpszbuf[2048];
  long amptime;
  
  switch(wparam) {
  case TIMERID_RECYCLE_DISPLAY:
    // ���ԕ\���̍X�V
    if(m_pSettings->m_bTimeEnable) {
      if(m_pSettings->m_bTimeRemain) {
        amptime = m_pWinampFunc->GetPlaybackTime(GPT_REMAIN);
        if(-1 == amptime)
          strcpy(lpszbuf, "-00:00");
        else
          sprintf(lpszbuf, "-%02d:%02d", amptime/60, amptime%60);
      } else {
        amptime = m_pWinampFunc->GetPlaybackTime(GPT_ELAPSED);
        if(-1 == amptime)
          strcpy(lpszbuf, " 00:00");
        else
          sprintf(lpszbuf, " %02d:%02d", amptime/60, amptime%60);
      }
      if(m_pSettings->m_hbmTime)
        DeleteObject(m_pSettings->m_hbmTime);
      m_pSettings->m_hbmTime = m_pSettings->CreateTextBitmap(lpszbuf, m_pSettings->m_TimeLogFont, m_pSettings->m_TimeFontColor);
    }
    // �^�C�g���\���̍X�V
    if(m_pWinampFunc) {
      if(m_pWinampFunc->GetTitle(lpszbuf, GWT_REFRESH)) {
        //�^�C�g�����X�V���ꂽ��
        m_pSettings->m_nScrollOffset = 0;
        m_pWinampFunc->SetFormat(lpszbuf, !m_pSettings->m_bKeepPrefix, !m_pSettings->m_bKeepSuffix);
        if(m_pSettings->m_hbmTitle)
          DeleteObject(m_pSettings->m_hbmTitle);
        m_pSettings->m_hbmTitle = m_pSettings->CreateTextBitmap(lpszbuf, m_pSettings->m_TextLogFont, m_pSettings->m_FontColor);
      }
    } else {
      //winamp class error
      if(m_pSettings->m_hbmTitle)
        DeleteObject(m_pSettings->m_hbmTitle);
      m_pSettings->m_hbmTitle = m_pSettings->CreateTextBitmap("winamp class error.", m_pSettings->m_TextLogFont, m_pSettings->m_FontColor);
    }
    InvalidateRect(m_hWnd, NULL, FALSE);
    break;

  case TIMERID_SCROLL_INTERVAL:
    m_pSettings->m_nScrollOffset += m_pSettings->m_nScrollStep;
    InvalidateRect(m_hWnd, NULL, FALSE);
    break;
  }

  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�B�X�v���C�̉𑜓x���ύX���ꂽ�Ƃ�
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onDisplayChange(UINT message, WPARAM wparam, LPARAM lparam, LRESULT *plresult)
{
  SetWndPos();
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�}�E�X�C�x���g
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onMouse(UINT message, WPARAM wparam, LPARAM lparam, LRESULT *plresult)
{
  switch(message){
  case WM_LBUTTONUP:
    if(PCM_TIME & ParseClickMap(LOWORD(lparam), HIWORD(lparam))) {
      m_pSettings->m_bTimeRemain=(m_pSettings->m_bTimeRemain)?FALSE:TRUE;
      onTimer(WM_TIMER, TIMERID_RECYCLE_DISPLAY, 0, plresult);
    }
    break;

  case WM_RBUTTONUP:
    m_pWinampFunc->DisplayMainMenu();
    break;

  case WM_LBUTTONDBLCLK:
    if(PCM_TITLE & ParseClickMap(LOWORD(lparam), HIWORD(lparam))) {
      HWND hwnd = FindWindow("Volume Control", NULL);

      if(!hwnd)
        ShellExecute(m_hWnd, NULL, "sndvol32.exe", NULL, NULL, SW_SHOWNORMAL);
      else
        SetForegroundWindow(hwnd);
    }
    break;
  }
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�}�E�X�C�x���g�̍��W�����
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
DWORD Gandharva::ParseClickMap(int mx, int my)
{
  DWORD dwresult=0;

  if(m_pSettings->m_nPaddingLeft <= mx &&
     m_pSettings->m_Width - m_pSettings->m_nPaddingRight >= mx &&
     m_pSettings->m_nPaddingTop <= my &&
     m_pSettings->m_Height - m_pSettings->m_nPaddingBottom >= my)
      dwresult |= PCM_TITLE;
      
  if(m_pSettings->m_nATPaddingLeft <= mx &&
     m_pSettings->m_Width - m_pSettings->m_nATPaddingRight >= mx &&
     m_pSettings->m_nATPaddingTop <= my &&
     m_pSettings->m_Height - m_pSettings->m_nATPaddingBottom >= my)
      dwresult |= PCM_TIME;

  return dwresult;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	!bang ����
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
REDIRECT_BANG(Gandharva,bangToggleVisible,	USERBM_TOGGLE)
REDIRECT_BANG(Gandharva,bangToggleTime,	USERBM_TOGGLE_TIME)
REDIRECT_BANG(Gandharva,bangShow,		USERBM_SHOW)
REDIRECT_BANG(Gandharva,bangHide,		USERBM_HIDE)
REDIRECT_BANG(Gandharva,bangAmpPower,	USERBM_AMP_POWER)
REDIRECT_BANG(Gandharva,bangAmpCommand,	USERBM_AMP_COMMANDEX)

void Gandharva::onUser(UINT message, WPARAM wparam, LPARAM lparam, LRESULT* plresult)
{
  // winamp �R�}���h
  if(wparam>40000){
    *plresult = ParseAmpCommand(wparam);
    return;
  }

  //!bang �����{��
  switch(wparam){
  case USERBM_SHOW: //!GandharvaShow
    ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
    break;

  case USERBM_HIDE: //!GandharvaHide
    ShowWindow(m_hWnd, SW_HIDE);
    break;

  case USERBM_TOGGLE: //!GandharvaToggle
    if( IsWindowVisible(m_hWnd) )
      ShowWindow(m_hWnd, SW_HIDE);
    else
      ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
    break;

  case USERBM_TOGGLE_TIME: //toggletime
    m_pSettings->m_bTimeRemain=(m_pSettings->m_bTimeRemain)?FALSE:TRUE;
    break;

  case USERBM_AMP_POWER: //cmdpower
    if( m_pWinampFunc->FindWindow() )
      m_pWinampFunc->Close();
    else
      m_pWinampFunc->Execute(NULL);
    break;

  case USERBM_AMP_COMMANDEX: //cmdextension
    *plresult = ParseAmpCommand( atol((LPSTR)lparam) );
    break;

  default:
    *plresult=1;
    return;
  }
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	!bang ���� winamp message
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
REDIRECT_BANG(Gandharva, bangAmpPrev,	AMPAPI_CMD_PREV)
REDIRECT_BANG(Gandharva, bangAmpPlay,	AMPAPI_CMD_PLAY)
REDIRECT_BANG(Gandharva, bangAmpPause,	AMPAPI_CMD_PAUSE)
REDIRECT_BANG(Gandharva, bangAmpStop,	AMPAPI_CMD_STOP)
REDIRECT_BANG(Gandharva, bangAmpNext,	AMPAPI_CMD_NEXT)
REDIRECT_BANG(Gandharva, bangAmpPLEdit,	AMPAPI_CMD_PLEDIT)
REDIRECT_BANG(Gandharva, bangAmpOpenFile,AMPAPI_CMD_OPENFILE)

LRESULT Gandharva::ParseAmpCommand(DWORD command)
{
  //xxxxxxxxxxxxxxxxxxxx ���J����Ă��Ȃ��͈͂̃��b�Z�[�W�̓t�B���^�����O
  if(command <= 40000 && 40298 <= command)
    return 1;

  //xxxxxxxxxxxxxxxxxxxx ������
  HWND hwinamp = m_pWinampFunc->FindWindow();

  switch(command){
  case AMPAPI_CMD_PLAY: //cmdplay
    if(!hwinamp){
      m_pWinampFunc->Execute(NULL);
      return 0;
    }
    break;
  case AMPAPI_CMD_PLEDIT: //cmdpledit
  case AMPAPI_CMD_OPENFILE: //cmpopenfile
    if(hwinamp)
      SetWindowPos(hwinamp, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
    break;
  }

  //xxxxxxxxxxxxxxxxxxxx�R�}���h�𑗂�
  m_pWinampFunc->PostCommand(command);
  return 0;
}
