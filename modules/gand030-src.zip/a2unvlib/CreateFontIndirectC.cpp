#include <windows.h>
#include "a2unvlib.h"

HFONT CreateFontIndirectC(LOGFONT *lplf)
{
  //BYTE nCharSet = (BYTE)GetTextCharset(hTargetDC);
  CHARSETINFO csi;
  TranslateCharsetInfo((LPDWORD)GetACP(), &csi, TCI_SRCCODEPAGE);

  lplf->lfCharSet = csi.ciCharset;

  return CreateFontIndirect(lplf);
}
