// ----------------------------
//  LiteStep Wallpaper Changer
// ----------------------------

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdio.h>
#include "lsapi.h"
#include "wharfdata.h"

//
// display error message box
//

int errorBox( HWND hWnd, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags )
{
	LPTSTR pszErrorMessage;
	int nResult;
	
	if( !FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER, 0, dwErrorCode,
		MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ), (LPTSTR) &pszErrorMessage, 0, 0 ) )
	{
		return MessageBox( hWnd, TEXT("Unexpected error, no description available."),
			pszTitle, nFlags );
	}
	
	nResult = MessageBox( hWnd, pszErrorMessage, pszTitle, nFlags );
	LocalFree( pszErrorMessage );
	
	return nResult;
}

//
// parse next token
//

LPCSTR nextToken( LPCSTR s, LPSTR d, UINT m )
{
	while( *s && *s <= 32 )
		s++;
	
	if( *s == 34 )
	{
		s++;
		
		while( *s && *s != 34 && --m )
			*d++ = *s++;
		
		s++;
	}
	else
	{
		while( *s && *s > 32 && --m )
			*d++ = *s++;
	}
	
	*d = 0;
	return s;
}

//
// bang command handler
//

void wallpaper( HWND hWnd, LPCSTR pszCmdLine )
{
	if( pszCmdLine && *pszCmdLine )
	{
		CHAR szBitmapFile[MAX_PATH];
		pszCmdLine = nextToken( pszCmdLine, szBitmapFile, MAX_PATH );
		
		if( szBitmapFile[0] )
		{
			if( !SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (LPVOID) szBitmapFile, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE ) )
				errorBox( hWnd, GetLastError(), TEXT("Wallpaper"), MB_OK | MB_ICONERROR );
		}
	}
}

//
// initialize LS module
//

extern "C" __declspec(dllexport) int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCSTR szPath )
{
	AddBangCommand( "!wallpaper", wallpaper );
	return 1;
}

//
// initialize LS module
//

extern "C" __declspec(dllexport) int initModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	return initModuleEx( hParent, hInstance, wd->lsPath );
}

//
// terminate LS module
//

extern "C" __declspec(dllexport) void quitModule( HINSTANCE hInstance )
{
	return;
}

//
// DLL entry point
//

extern "C" int APIENTRY entryPoint( HINSTANCE, DWORD, LPVOID )
{
	return 1;
}

////
/// maduin (maduin@dasoft.org)
//
