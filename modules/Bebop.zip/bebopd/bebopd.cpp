#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <wininet.h>
#include "../resource.h"

class SONGLIST
{
public:
	SONGLIST() { next=NULL; song=NULL; }
	char* song;
	SONGLIST* next;
};

class CONNECTION
{
public:
	CONNECTION() { user=NULL; next=NULL; sl=NULL; }
	SOCKET sock;
	sockaddr_in addr;
	char* user;
	int index;
	
	SONGLIST* sl;
	CONNECTION* prev;
	CONNECTION* next;
} *head=NULL;

HINSTANCE hinst = NULL; 
HWND hwndMain, hwndUsers;
char* szAppName = "bebopd";
BOOL QUITTING=FALSE;

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK UsersProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

CONNECTION* GetConnectionByUser(char* user)
{
	for (CONNECTION* c=head; c; c=c->next)
	{
		if (!strcmp(c->user, user)) return c;
	}

	return NULL;
}

int AddUser(CONNECTION* c)
{
	HWND lv = GetDlgItem(hwndUsers, IDC_LIST_USERS);
	LVITEM item;
	int index;

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = c->user;
	index = ListView_InsertItem(lv, &item);

	item.iItem = index;
	item.iSubItem = 1;
	item.pszText = inet_ntoa(c->addr.sin_addr);
	ListView_SetItem(lv, &item);

	return index;
}

void HandleSocket(CONNECTION* c)
{
	BOOL LISTING=FALSE;
	char cont[256] = "";

	c->prev=NULL;
	c->next=head;
	if (head) head->prev = c;
	head=c;

	while (!QUITTING)
	{
		char recvbuf[256] = "";
		char* temp = new char[strlen(cont) + 256];
		int n=0;

		if ((n=recv(c->sock, recvbuf, 256, 0)) > 0)
		{
			if (temp[strlen(temp)-2] == '\r') temp[strlen(temp)-2] = '\0';
			int nc=0;

			sprintf(temp, "%s", cont);
			char* src = recvbuf;
			char* dest = temp + strlen(cont);
			while (nc < n) { *dest++ = *src++; nc++; }
			memset(&cont, 0, sizeof(cont));
			nc=0;

			char* ptemp = temp;
			while (nc < n)
			{
				if (nc + strlen(ptemp) >= 256)
				{
					strcpy(cont, ptemp);
				}
				else
				{
					if (LISTING)
					{
						if (!strcmp(ptemp, "\r\n")) 
						{
							LISTING=FALSE;
						}
						else
						{
							SONGLIST* s = new SONGLIST;
							s->song = _strdup(ptemp);
							s->next = c->sl;
							c->sl = s;
						}
					}
					else
					{
						if (!_strnicmp(ptemp, "exit", 4)) break;
						else if (!_strnicmp(ptemp, "user: ", 6)) 
						{
							if (!c->user)
							{
								c->user = _strdup(ptemp+6);
								c->index = AddUser(c);
							}
						}
						else if (!_strnicmp(ptemp, "beginlist", 9))
						{
							LISTING=TRUE;
						}
						else if (!_strnicmp(ptemp, "printlist", 9))
						{
							for (SONGLIST* s = c->sl; s; s=s->next)
							{
								if (s)
								{
									char* sendbuf = new char[strlen(s->song)+3];
									sprintf(sendbuf, "%s\0", s->song);
									send(c->sock, sendbuf, strlen(sendbuf)+1, 0);
								}
							}
						}
						else if (!_strnicmp(ptemp, "search", 6))
						{
							char* query = ptemp+7;

							for (CONNECTION* t=head; t; t=t->next)
							{
								if (t == c) continue;

								for (SONGLIST* s = t->sl; s; s=s->next)
								{
									if (strstr(s->song, query))
									{
										char* sendbuf = new char[strlen(s->song) + 25];
										sprintf(sendbuf, "%s:%s\0", inet_ntoa(t->addr.sin_addr), s->song);
										send(c->sock, sendbuf, strlen(sendbuf)+1, 0);
									}
								}
							}
						}
					}
				}

				nc += strlen(ptemp)+1;
				ptemp += strlen(ptemp)+1;
			}
		}
		else break;
	}
	
	closesocket(c->sock);

	HWND lv = GetDlgItem(hwndUsers, IDC_LIST_USERS);
	ListView_DeleteItem(lv, c->index);

	if (c->prev)
	{
		if (c->next) c->next->prev = c->prev;
		c->prev->next = NULL;
	}
	else
	{
		head = c->next;
	}
	delete c;
}

BOOL InitServer()
{
	WSADATA wsaData;
	SOCKET sockfd, new_fd;
	struct sockaddr_in my_addr;    /* my address information */
	struct sockaddr_in their_addr; /* connector's address information */
	int sin_size, optval;
	
	// Startup Sockets
	if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
	{ 
		WSACleanup(); 
		return FALSE;
	}

	// Initialize socket
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		return FALSE;
	}

	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(420);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&optval, sizeof(int)) < 0)
	{
		return FALSE;
	}

	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) < 0)
	{
		return FALSE;
	}

	if (listen(sockfd, 5) < 0)
	{
		return FALSE;
	}

	while(!QUITTING)
	{
		sin_size = sizeof(struct sockaddr_in);
		if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) < 0)
		{
			continue;	
		}

		DWORD threadID;
		CONNECTION* c = new CONNECTION;
		c->sock = new_fd;
		c->addr = their_addr;
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)HandleSocket, (LPVOID)c, 0, &threadID);
	}

	return TRUE;
}

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow) 
{ 
	HANDLE thread=NULL;
	DWORD threadID;
    MSG msg;

	UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;

	INITCOMMONCONTROLSEX icc;
	icc.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icc.dwICC = ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES;
	InitCommonControlsEx(&icc);

	hwndMain = CreateDialog(hinst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DlgProc);
	if (!hwndMain) return 0;

	hwndUsers = CreateDialog(hinst, MAKEINTRESOURCE(IDD_USERS), hwndMain, (DLGPROC)UsersProc);
	if (!hwndUsers) return 0;

	ShowWindow(hwndMain, SW_SHOW);

	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InitServer, (LPVOID)NULL, 0, &threadID);
	
	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	QUITTING=TRUE;
	if (hwndMain) DestroyWindow(hwndMain);
	TerminateThread(thread, 0);

	return msg.wParam; 
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
		{
			HWND tab = GetDlgItem(hwnd, IDC_TAB);
			TCITEM ti;

			ti.mask = TCIF_TEXT;
			
			ti.pszText = "Users";
			ti.cchTextMax = 5;
			TabCtrl_InsertItem(tab, 0, &ti);
			
			ti.pszText = "MOTD";
			ti.cchTextMax = 4;
			TabCtrl_InsertItem(tab, 1, &ti);

			ti.pszText = "Raw";
			ti.cchTextMax = 3;
			TabCtrl_InsertItem(tab, 2, &ti);
		}
		break;

		case WM_NOTIFY:
		{
			LPNMHDR lpnmhdr = (LPNMHDR) lParam; 

			switch (lpnmhdr->code)
			{
				case TCN_SELCHANGING:
				{
					int index = TabCtrl_GetCurSel(lpnmhdr->hwndFrom);

					switch (index)
					{
						case 0: ShowWindow(hwndUsers, SW_HIDE); break;
					}
				}
				break;

				case TCN_SELCHANGE:
				{
					int index = TabCtrl_GetCurSel(lpnmhdr->hwndFrom);
					switch (index)
					{
						case 0: ShowWindow(hwndUsers, SW_SHOW); break;
					}
				}
				break;
			}
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hwndMain);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;
	}

	return FALSE;
}

BOOL CALLBACK UsersProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			HWND lv = GetDlgItem(hwnd, IDC_LIST_USERS);
			LVCOLUMN col;
			RECT r;
			GetClientRect(lv, &r);
			col.cx = r.right/2;
			col.iSubItem = 0;
			col.pszText = "User";
			col.cchTextMax = 4;
			col.mask = LVCF_SUBITEM | LVCF_WIDTH | LVCF_TEXT;
			ListView_InsertColumn(lv, 0, &col);

			col.iSubItem = 1;
			col.pszText = "IP";
			col.cchTextMax = 2;
			ListView_InsertColumn(lv, 1, &col);
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					case IDC_KILL:
					{
						HWND lv = GetDlgItem(hwnd, IDC_LIST_USERS);
						int index = ListView_GetSelectionMark(lv);
						if (index >= 0)
						{
								char user[50] = "";
								ListView_GetItemText(lv, index, 0, user, 50);
								
								CONNECTION* c = GetConnectionByUser(user);
								if (c) 
								{
									closesocket(c->sock);
								}
						}
					}
					break;
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}
