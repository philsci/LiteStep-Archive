#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <wininet.h>
#include "../resource.h"

class FILELIST
{
public:
	FILELIST() { next=NULL; file=NULL; }
	char* file;
	int index;
	FILELIST* next;
};

class CONNECTION
{
public:
	CONNECTION() { user=NULL; fl=NULL; }
	SOCKET sock;
	sockaddr_in addr;
	char* user;
	int index;
	
	FILELIST* fl;
};

HINSTANCE hinst = NULL; 
HWND hwndMain, hwndSearch, hwndClient;
char* szAppName = "bebop";
BOOL QUITTING=FALSE;
SOCKET  conn_socket;

char DIR_SHARED[MAX_PATH] = "";
char DIR_DLOAD[MAX_PATH] = "";

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ClientProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SearchProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

void SendFile(CONNECTION* c, char* file)
{
}

int AddFile(char* filename, char* user)
{
/*	HWND lv = GetDlgItem(hwndFiles, IDC_LIST_FILES);
	LVITEM item;
	int index;

	item.mask = LVIF_TEXT;
	item.iItem = 0;
	item.iSubItem = 0;
	item.pszText = filename;
	index = ListView_InsertItem(lv, &item);

	item.iItem = index;
	item.iSubItem = 1;
	item.pszText = user;
	ListView_SetItem(lv, &item);

	return index;*/
	return 0;
}

void HandleSocket(CONNECTION* c)
{
	while (!QUITTING)
	{
		char temp[256] = "";
		if (recv(c->sock, temp, 256, 0) > 0)
		{
			temp[strlen(temp)-2] = '\0';

			if (!_strnicmp(temp, "exit", 4)) break;
			else if (!_strnicmp(temp, "user: ", 6)) 
			{
				if (!c->user)
				{
					c->user = _strdup(temp+6);
				}
			}
			else if (!_strnicmp(temp, "get", 3))
			{
				SendFile(c, temp+3);
			}
		}
		else break;
	}
	
	closesocket(c->sock);
	delete c;
}

void SendFileList(SOCKET sock, char* match)
{
	HANDLE fff = NULL;
	WIN32_FIND_DATA* fd = new WIN32_FIND_DATA;
	char path[256] = "";
	
	sprintf(path, "%s\\*", match);

	fff = FindFirstFile(path, fd);
	if (fff == INVALID_HANDLE_VALUE) return;

	while (FindNextFile(fff, fd))
	{
		if (fd->dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (strcmp(fd->cFileName, ".") && strcmp(fd->cFileName, ".."))
			{
				char newpath[MAX_PATH] = "";
				sprintf(newpath, "%s\\%s", match, fd->cFileName);
				SendFileList(sock, newpath);
			}
		}
		else
		{
			//if (strstr(fd->cFileName, ".mp3"))
			//{
			char filename[256] = "";
			char* name;
			sprintf(filename, "%s\\%s\0", match, fd->cFileName);
			name = filename + strlen(DIR_SHARED) + 1;
			send(sock, name, strlen(name)+1, 0);
			//}
		}
	}
}

BOOL InitServer()
{
	WSADATA wsaData;
	SOCKET sockfd, new_fd;
	struct sockaddr_in my_addr;    /* my address information */
	struct sockaddr_in their_addr; /* connector's address information */
	int sin_size, optval;
	
	// Startup Sockets
	if (WSAStartup(0x202,&wsaData) == SOCKET_ERROR)
	{ 
		WSACleanup(); 
		return FALSE;
	}

	// Initialize socket
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	{
		return FALSE;
	}

	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(1337);
	my_addr.sin_addr.s_addr = INADDR_ANY;
	//bzero(&(my_addr.sin_zero), 8);

	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&optval, sizeof(int)) < 0)
	{
		return FALSE;
	}

	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) < 0)
	{
		return FALSE;
	}

	if (listen(sockfd, 5) < 0)
	{
		return FALSE;
	}

	while(!QUITTING)
	{
		sin_size = sizeof(struct sockaddr_in);
		if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) < 0)
		{
			continue;	
		}

		DWORD threadID;
		CONNECTION* c = new CONNECTION;
		c->sock = new_fd;
		c->addr = their_addr;
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)HandleSocket, (LPVOID)c, 0, &threadID);
	}

	return TRUE;
}

BOOL ConnectToServer(char* server, int port)
{
	unsigned int addr; 
	int	socket_type = SOCK_STREAM; 
	struct sockaddr_in sad; 
	struct hostent *hp; 
	char temp[256] = "";
	char sendbuf[256] = "";

	// Check to see if server_name is an alpha or ip
	if (isalpha(*server)) hp = gethostbyname(server); 
	else  
	{
		addr = inet_addr(server); 
		hp = gethostbyaddr((char *)&addr,4,AF_INET); 
	} 

	// Couldn't resolve
	if (hp == NULL) return FALSE;

	// Copy the resolved information into the sockaddr_in structure 
	memset(&sad,0,sizeof(sad)); 
	memcpy(&(sad.sin_addr),hp->h_addr,hp->h_length); 
	sad.sin_family = hp->h_addrtype; 
	sad.sin_port = htons((u_short)port); 

	// Open a socket
	conn_socket = socket(AF_INET,socket_type,0);
	if (conn_socket < 0 ) return FALSE;

	// Connect to the server
	if (connect(conn_socket,(struct sockaddr*)&sad,sizeof(sad)) == SOCKET_ERROR) return FALSE;

	GetDlgItemText(hwndClient, IDC_USERNAME, temp, 25);
	sprintf(sendbuf, "user: %s\0", temp);
	if (send(conn_socket, sendbuf, strlen(sendbuf)+1, 0) < 0) return FALSE;

	GetDlgItemText(hwndClient, IDC_DIR_SHARED, DIR_SHARED, MAX_PATH);
	GetDlgItemText(hwndClient, IDC_DIR_DOWNLOAD, DIR_DLOAD, MAX_PATH);

	if (send(conn_socket, "beginlist\0", 10, 0) < 0) return FALSE;
	SendFileList(conn_socket, DIR_SHARED);
	if (send(conn_socket, "\r\n\0", 3, 0) < 0) return FALSE;

	return TRUE;
}

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow) 
{ 
	HANDLE thread=NULL;
	DWORD threadID;
    MSG msg;

	UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;

	INITCOMMONCONTROLSEX icc;
	icc.dwSize = sizeof(INITCOMMONCONTROLSEX);
	icc.dwICC = ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES;
	InitCommonControlsEx(&icc);

	hwndMain = CreateDialog(hinst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)DlgProc);
	if (!hwndMain) return 0;

	hwndClient = CreateDialog(hinst, MAKEINTRESOURCE(IDD_CLIENT), hwndMain, (DLGPROC)ClientProc);
	if (!hwndClient) return 0;

	hwndSearch = CreateDialog(hinst, MAKEINTRESOURCE(IDD_SEARCH), hwndMain, (DLGPROC)SearchProc);
	if (!hwndSearch) return 0;

	ShowWindow(hwndMain, SW_SHOW);

	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)InitServer, (LPVOID)NULL, 0, &threadID);
	
	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	QUITTING=TRUE;
	if (hwndMain) DestroyWindow(hwndMain);
	TerminateThread(thread, 0);
	WSACleanup();

	return msg.wParam; 
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
		{
			HWND tab = GetDlgItem(hwnd, IDC_TAB);
			TCITEM ti;

			ti.mask = TCIF_TEXT;
			
			ti.pszText = "Main";
			ti.cchTextMax = 4;
			TabCtrl_InsertItem(tab, 0, &ti);
			
			ti.pszText = "Search";
			ti.cchTextMax = 6;
			TabCtrl_InsertItem(tab, 1, &ti);

			ti.pszText = "Downloads";
			ti.cchTextMax = 9;
			TabCtrl_InsertItem(tab, 2, &ti);

			ti.pszText = "Uploads";
			ti.cchTextMax = 7;
			TabCtrl_InsertItem(tab, 3, &ti);
		}
		break;

		case WM_NOTIFY:
		{
			LPNMHDR lpnmhdr = (LPNMHDR) lParam; 

			switch (lpnmhdr->code)
			{
				case TCN_SELCHANGING:
				{
					int index = TabCtrl_GetCurSel(lpnmhdr->hwndFrom);

					switch (index)
					{
						case 0: ShowWindow(hwndClient, SW_HIDE); break;
						case 1: ShowWindow(hwndSearch, SW_HIDE); break;
					}
				}
				break;

				case TCN_SELCHANGE:
				{
					int index = TabCtrl_GetCurSel(lpnmhdr->hwndFrom);
					switch (index)
					{
						case 0: ShowWindow(hwndClient, SW_SHOW); break;
						case 1: ShowWindow(hwndSearch, SW_SHOW); break;
					}
				}
				break;
			}
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hwndMain);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;
	}

	return FALSE;
}

BOOL CALLBACK ClientProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			// CHANGE TO USE REGISTRY!
			GetPrivateProfileString(szAppName, "SharedDirectory", "", DIR_SHARED, MAX_PATH, "bebop.ini");
			SetDlgItemText(hwnd, IDC_DIR_SHARED, DIR_SHARED);

			GetPrivateProfileString(szAppName, "DownloadDirectory", "", DIR_DLOAD, MAX_PATH, "bebop.ini");
			SetDlgItemText(hwnd, IDC_DIR_DOWNLOAD, DIR_DLOAD);
		}
		break;

		case WM_DESTROY:
		{
			GetDlgItemText(hwnd, IDC_DIR_SHARED, DIR_SHARED, MAX_PATH);
			WritePrivateProfileString(szAppName, "SharedDirectory", DIR_SHARED, "bebop.ini");

			GetDlgItemText(hwnd, IDC_DIR_DOWNLOAD, DIR_DLOAD, MAX_PATH);
			WritePrivateProfileString(szAppName, "DownloadDirectory", DIR_DLOAD, "bebop.ini");
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDC_CONNECT:
						{
							char server[256] = "";
							HWND cb = GetDlgItem(hwndClient, IDC_COMBO_SERVERS);
							GetWindowText(cb, server, 256);

							if (strlen(server))
							{
								int port=420;

								if (SendMessage(cb, CB_FINDSTRINGEXACT, 0, (LPARAM)server) == CB_ERR)
								{
									SendMessage(cb, CB_ADDSTRING, 0, (LPARAM)server);
								}

								char* p = strstr(server, ":");
								if (p)
								{
									*p = '\0';
									p++;
									port = atoi(p);
								}

								if (ConnectToServer(server, port))
								{
									ShowWindow(GetDlgItem(hwnd, IDC_DISCONNECT), SW_SHOW);
									ShowWindow(GetDlgItem(hwnd, IDC_CONNECT), SW_HIDE);
								}
								else
								{
									closesocket(conn_socket);
									conn_socket=0;
								}
							}
							else
							{
								MessageBox(hwndMain, "You must specify a server to connect to", szAppName, MB_ICONERROR | MB_OK);
							}
						}
						break;

						case IDC_DISCONNECT:
						{
							send(conn_socket, "exit\0", 5, 0);
							closesocket(conn_socket);
							conn_socket=0;
							ShowWindow(GetDlgItem(hwnd, IDC_CONNECT), SW_SHOW);
							ShowWindow(GetDlgItem(hwnd, IDC_DISCONNECT), SW_HIDE);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

BOOL CALLBACK SearchProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			HWND lv = GetDlgItem(hwnd, IDC_LIST_SEARCH);
			LVCOLUMN col;
			RECT r;
			GetClientRect(lv, &r);
			col.cx = r.right/2;
			col.iSubItem = 0;
			col.pszText = "Filename";
			col.cchTextMax = 8;
			col.mask = LVCF_SUBITEM | LVCF_WIDTH | LVCF_TEXT;
			ListView_InsertColumn(lv, 0, &col);

			col.iSubItem = 1;
			col.pszText = "IP";
			col.cchTextMax = 2;
			ListView_InsertColumn(lv, 1, &col);
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDC_SEARCH:
						{
							char pattern[256] = "";
							GetDlgItemText(hwndSearch, IDC_SEARCH_STRING, pattern, 256);

							if (strlen(pattern))
							{
								char sendbuf[256] = "";
								char recvbuf[256] = "";

								sprintf(sendbuf, "search %s\0", pattern);
								if (send(conn_socket, sendbuf, strlen(sendbuf)+1, 0) < 0)
								{
									// disconnected!
									break;
								}

								HWND lv = GetDlgItem(hwndSearch, IDC_LIST_SEARCH);
								ListView_DeleteAllItems(lv);
								int n;
								DWORD dwStartTicks = GetTickCount();
								BOOL INSIDE=FALSE;
								
								while (1)
								{
									struct fd_set fds;
									struct timeval timeout = {0, 0};
								
									if ((GetTickCount() - dwStartTicks) > 30000) break;

									FD_ZERO(&fds);
									FD_SET(conn_socket, &fds);
									n = select(0, &fds, NULL, NULL, &timeout);
									if (n == SOCKET_ERROR)
									{
										// disconnected!
										break;
									}
									else if (n > 0)
									{
										char* p;
										int cn=0;
										
										INSIDE=TRUE;
										n = recv(conn_socket, recvbuf, 256, 0);
										p = recvbuf;
										
										while (cn < n)
										{
											LVITEM item;
											int index;
											char* filename = strstr(p, ":");

											if (filename)
											{
												*filename = '\0';
												filename++;

												item.mask = LVIF_TEXT;
												item.iItem = 0;
												item.iSubItem = 0;
												item.pszText = filename;
												index = ListView_InsertItem(lv, &item);

												item.iItem = index;
												item.iSubItem = 1;
												item.pszText = p;
												ListView_SetItem(lv, &item);

												*(filename-1) = ':';
											}

											cn += strlen(p) + 1;
											p += strlen(p) + 1;
										}
									}
									else 
									{
										if (INSIDE) break;
										else Sleep(250);
									}
								}
							}
						}
						break;

						case IDC_DOWNLOAD:
						{
						}
						break;

						case IDC_SEARCH_CLEAR:
						{
							HWND lv = GetDlgItem(hwndSearch, IDC_LIST_SEARCH);
							ListView_DeleteAllItems(lv);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}