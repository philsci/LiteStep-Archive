//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bebopd.rc
//
#define IDD_MAIN                        101
#define IDD_USERS                       102
#define IDD_FILES                       103
#define IDD_CLIENT                      104
#define IDD_SEARCH                      105
#define IDC_LIST1                       1009
#define IDC_LIST_USERS                  1009
#define IDC_TAB                         1010
#define IDC_KILL                        1011
#define IDC_LIST_FILES                  1012
#define IDC_LIST_SEARCH                 1012
#define IDC_MOTD                        1013
#define IDC_COMBO_SERVERS               1014
#define IDC_CONNECT                     1015
#define IDC_USERNAME                    1016
#define IDC_DISCONNECT                  1017
#define IDC_DIR_SHARED                  1018
#define IDC_DIR_DOWNLOAD                1019
#define IDC_SEARCH                      1019
#define IDC_DOWNLOAD                    1020
#define IDC_SEARCH_CLEAR                1021
#define IDC_SEARCH_STRING               1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
