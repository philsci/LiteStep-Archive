#ifndef _UNIMSGS_H_
#define _UNIMSGS_H_

#define MSG_UNITITLE	"UniWharf"
#define MSG_ERROR		"UniWharf Error"
#define MSG_QUITWHARF	"Unable to load module 'quit' function."
#define MSG_INITWHARF	"Unable to load module 'init' function."
#define MSG_LOADWHARF	"Unable to load wharf module."
#define MSG_ERRMOD		"Error writing to modules.ini"
#define MSG_OFFTOP		"Always on top Turned off."
#define MSG_ONTOP		"Always on top Turned On."
#define MSG_USAGE		"No wharf module specified.\n\nUsage: uniwharf.exe <modulename>\n"

#endif /* _UNIMSGS_H_ */
