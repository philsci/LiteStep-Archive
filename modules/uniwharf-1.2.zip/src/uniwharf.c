/************ UniWharf v1.2 (***************
 * Source is freely distributed under GNU  *
 * Public Distribution license.            *
 * Re-distribution after modification pro- *
 * hibited without Author's approval.      *
 *******************************************/

/* Old notice */
/************ LSFloater v1.0 ***************
 * Copyright (c) 1998, Marek "RaV" Gorecki *
 * --------------------------------------- *
 * Source is freely distributed under GNU  *
 * Public Distribution license.            *
 * Re-distribution after modification pro- *
 * hibited without Author's approval.      *
 *******************************************/

#include <windows.h>
#include <stdio.h>
#include "lsapi.h"
#include "wharfdata.h"
#include "unimsgs.h"

/* Class and Window names of windows */
static LPCTSTR lpszClassName = "TApplication";
static LPCTSTR lpszWindowName = "UniWharf";

/* Global Variables */
static char modules_ini[MAX_PATH];	/* Path to modules.ini */
static char step_rc[MAX_PATH];		/* Path to step.rc */
static int ontop = 1;				/* Module is on top */
LPSTR pluginName;					/* Module Name */
HBITMAP defaultBackImage = NULL;	/* Background */

/* Declaration for Window procedure */
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM	lParam);

/* Type definitions for external function calls to the module DLL */
typedef int (FAR *INITWHARFMODULEPROC)(HWND, HINSTANCE, wharfDataType *);
typedef int (FAR *QUITWHARFMODULEPROC)(HINSTANCE);

/* Loads the Module */
void loadWharfModule(HWND Wnd, char *moduleName, int x, int y)
{
	int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
	int (FAR *quitWharfModule)(HINSTANCE);

	HINSTANCE moduleInst;
	wharfDataType wd;
	char temp[MAX_PATH];

/* Fill in the wharf data structure with either values from
 * the modules.ini or defaults. */
	SetupRC(step_rc);

	wd.borderSize		= GetRCInt("WharfBevelWidth",0);
	wd.pos				= GetRCInt("pos",0);
	wd.winListSize		= GetRCInt("WinListSize",200);
	wd.winList			= NULL;
	wd.trayIconSize		= GetRCInt("TrayIconSize",16);
	wd.lm78Unit			= GetRCInt("lm78Unit",0);
	wd.lm78MaxCpu		= GetRCInt("lm78MaxCpu",0);
	wd.lm78MaxMb		= GetRCInt("lm78MaxMb",0);
	wd.lm78Cpu			= GetRCInt("lm78Cpu",0);
	wd.taskBar			= GetRCInt("NoTaskBar",0);
	wd.msTaskBar		= GetRCInt("MSTaskBar",0);
	wd.taskBarFore		= GetRCColor("LSTaskBarFore",0x000000);
	wd.taskBarFore2		= GetRCColor("LSTaskBarFore2",0x3f3f3f);
	wd.taskBarBack		= GetRCColor("LSTaskBarBack",0x7f7f7f);
	wd.taskBarText		= GetRCColor("LSTaskBarText",0xffffff);
	wd.autoHideWharf	= GetRCInt("AutoHideWharf",0);
	wd.autoHideTaskbar	= GetRCInt("AutoHideTaskbar",0);
	wd.autoHideDelay	= GetRCInt("AutoHideDelay",300);
	wd.showBeta			= GetRCInt("NoShowBeta",1);
	wd.usClock			= GetRCInt("UsClock",1);
	wd.vwmVelocity		= GetRCInt("VWMVelocity",300);
	wd.VWMDistance		= GetRCInt("VWMSecurityDistance",5);
	wd.VWMNoGathering	= GetRCInt("VWMNoGathering",0);
	wd.VWMNoAuto		= GetRCInt("VWMNoAuto",1);
	wd.vwmBackColor		= GetRCColor("VWMBackColor",0x000000);
	wd.vwmSelBackColor	= GetRCColor("VWMSelBackColor",0x3f3f3f);
	wd.vwmForeColor		= GetRCColor("VWMForeColor",0x906090);
	wd.vwmBorderColor	= GetRCColor("VWMBorderColor",0xffffff);
	wd.xmouseDelay		= GetRCInt("xmouseDelay",0);
	wd.xmouseBringToTop	= GetRCInt("BringToTop",0);
	wd.stripBar			= GetRCInt("stripBar",0);

	GetRCString("PixmapPath",temp,".\\",sizeof(temp));
	wd.pixmapDir=(char *)malloc(strlen(temp)+1);
	strcpy(wd.pixmapDir,temp);

	GetRCString("DefaultBackPix",temp,"default.bmp",sizeof(temp));
	wd.defaultBmp=(char *)malloc(strlen(temp)+1);
	strcpy(wd.defaultBmp,temp);

	GetRCString("backsaver",temp,"",sizeof(temp));
	wd.backsaver=(char *)malloc(strlen(temp)+1);
	strcpy(wd.backsaver,temp);

	GetRCString("lsPath",temp,".\\",sizeof(temp));
	wd.lsPath=(char *)malloc(strlen(temp)+1);
	strcpy(wd.lsPath,temp);

	/* Load the module */
	moduleInst = LoadLibrary(moduleName);

	if ((UINT)moduleInst > HINSTANCE_ERROR) {
		/* Get exported functions addresses */
		initWharfModule = (INITWHARFMODULEPROC)GetProcAddress(moduleInst, "initWharfModule");
		quitWharfModule = (QUITWHARFMODULEPROC)GetProcAddress(moduleInst, "quitWharfModule");

		if (initWharfModule) {
			if (quitWharfModule) {
				/* Run module startup */
				(*initWharfModule)(Wnd, moduleInst, &wd);
			} else {
				MessageBox(0, MSG_QUITWHARF, MSG_ERROR, MB_OK);
			}
		} else {
			MessageBox(0, MSG_INITWHARF, MSG_ERROR, MB_OK);
		}
	} else {
		MessageBox(0, MSG_LOADWHARF, MSG_ERROR, MB_OK);
	}

	free(wd.pixmapDir);
	free(wd.defaultBmp);
	free(wd.backsaver);
	free(wd.lsPath);

	CloseRC();
}

/* Window Procedure for the module */
LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	static BOOL dragging=FALSE;
	static int dragX,dragY;	/* position of the cursor relative to the upper left corner */
	   						/* of the window, when dragging == TRUE */
	char cx[10];
	POINT pt;

	switch(iMessage) {
	case WM_CREATE:
		return TRUE;
		break;
	case WM_PAINT:
		if (defaultBackImage != NULL) {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd,&ps);
			HDC src = CreateCompatibleDC(NULL);
			SelectObject(src, defaultBackImage);
			TransparentBltLS(hdc, 0, 0, 64, 64, src, 0, 0, RGB(255, 0, 255));
			EndPaint(hWnd,&ps);
			DeleteDC(src);
		}
		return 0;
		break;
	case WM_NCLBUTTONDOWN: 
	case WM_NCLBUTTONUP: 
		return 0;
		break;
	case WM_NCRBUTTONDOWN:
		/* since the only non-client area of the module is the border, */
		/* then start right-dragging when the right mouse button is down in an nc area */
		dragging = TRUE;
		pt.x = MAKEPOINTS(lParam).x;
		pt.y = MAKEPOINTS(lParam).y;
		ScreenToClient(hWnd,&pt);
		dragX = pt.x;
		dragY = pt.y;
		SetCapture(hWnd);
		return 0;
		break;
	case WM_NCRBUTTONUP:
		{
			RECT Rect;
			char cy[9], cx[9];
			if (dragging) {
				dragging = FALSE;
				ReleaseCapture();
				GetWindowRect(hWnd,&Rect);
				if (WritePrivateProfileString(pluginName,"top",itoa(Rect.top,cy,10),modules_ini)==0)
					MessageBox(0,MSG_ERRMOD,MSG_ERROR,MB_OK);
				WritePrivateProfileString(pluginName,"left",itoa(Rect.left,cx,10),modules_ini);
			}
		}
		return 0;
		break;
	case WM_MOUSEMOVE:
		if (dragging) {
			GetCursorPos(&pt);
			SetWindowPos(hWnd,NULL,pt.x-dragX,pt.y-dragY,0,0,SWP_NOZORDER | SWP_NOSIZE);
			return 0;
		}
		return 0;
		break;
	case WM_RBUTTONUP:
		{
			RECT Rect;
			char cy[9], cx[9];
			if (dragging) {
				dragging = FALSE;
				ReleaseCapture();
				GetWindowRect(hWnd,&Rect);
				if (WritePrivateProfileString(pluginName,"top",itoa(Rect.top,cy,10),modules_ini)==0)
					MessageBox(0,MSG_ERRMOD,itoa(Rect.top,cy,10),MB_OK);
				WritePrivateProfileString(pluginName,"left",itoa(Rect.left,cx,10),modules_ini);        
				return 0;
			}
		}
		return 0;
		break;
	case WM_NCLBUTTONDBLCLK:
		/* Left Double click toggles always on top mode */
		if (ontop) {
			MessageBox(0,MSG_OFFTOP,MSG_UNITITLE,MB_OK);
			ontop = 0;
			SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
			if (WritePrivateProfileString(pluginName,"ontop",itoa(ontop,cx,10),modules_ini)==0)
				MessageBox(0,MSG_ERROR,itoa(ontop,cx,10),MB_OK);
			return 0;
		}
		MessageBox(0,MSG_ONTOP,MSG_UNITITLE,MB_OK);
		SetWindowPos(hWnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
		ontop = 1;
		if (WritePrivateProfileString(pluginName,"ontop",itoa(ontop,cx,10),modules_ini)==0)
			MessageBox(0,MSG_ERROR,itoa(ontop,cx,10),MB_OK);
		return 0;
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
		break;
	default: 
		return(DefWindowProc(hWnd,iMessage,wParam,lParam));
	}
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	WNDCLASS wc;
	HWND hWnd;
	RECT r;
	char cy[9], cx[9];
	char temp[MAX_PATH];
	int modX = 0, modY = 0;
	unsigned long modSize = 0;

	/* No command line specified */
	if (strlen(lpCmdLine)==0) {
		MessageBox(0,MSG_USAGE,MSG_ERROR,MB_OK);
		return 0;
	}
	
	/* Register Window style */
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	wc.lpfnWndProc		= (WNDPROC) WndProc;
	wc.cbClsExtra		= 0;
	wc.cbWndExtra		= 0;
	wc.hInstance 		= hInstance;
	wc.hIcon			= NULL;
	wc.hCursor			= NULL; /*LoadCursor(NULL, IDC_ARROW); */
	wc.hbrBackground	= (HBRUSH)(COLOR_BACKGROUND+1);
	wc.lpszMenuName		= NULL;
	wc.lpszClassName	= lpszClassName;

	/* Register the window class */
	if(RegisterClass(&wc) == 0)
		return FALSE;

	modX = 64+2*(GetSystemMetrics(SM_CXSIZEFRAME)-1);
	modY = 64+2*(GetSystemMetrics(SM_CYSIZEFRAME)-1);

	/* Create the main application window */
	/* hack: look for real litestep wind and if not there
	then call ourselves the ls wind name so GetLitestepWnd()
	works */
	hWnd = CreateWindowEx(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, lpszClassName,
				(FindWindow("TApplication", "LiteStep") == NULL) ? "LiteStep" : lpszWindowName,
				WS_DLGFRAME | WS_POPUP, 100, 100, modX, modY,
				NULL, NULL, hInstance, NULL);

	SetWindowLong(hWnd, GWL_USERDATA, 0x49474541);
	pluginName = lpCmdLine;
	modSize = GetModuleFileName(NULL, modules_ini, sizeof(modules_ini));
	while (modules_ini[--modSize] != '\\')
		modules_ini[modSize] = '\0';
	strcpy(step_rc, modules_ini);
	strcat(modules_ini,"modules.ini");
	strcat(step_rc, "step.rc");
	
	/* If window was not created, quit */
	if(hWnd == NULL)
		return FALSE;
	
	/* Set position of the module to the place in the ini file */
	SetWindowPos(hWnd,NULL,GetPrivateProfileInt(lpCmdLine,"left",0,modules_ini),
		GetPrivateProfileInt(lpCmdLine,"top",0,modules_ini),0,0,SWP_NOZORDER | SWP_NOSIZE);
	
	/* Get ontop info for the window */
	ontop = GetPrivateProfileInt(lpCmdLine,"ontop",1,modules_ini);

	/* our background */
	GetPrivateProfileString(lpCmdLine, "backpix", NULL, temp, sizeof(temp), modules_ini);
	if (temp[0] != '\0') {
		defaultBackImage = (HBITMAP)LoadImage(NULL,temp,
			IMAGE_BITMAP, 0, 0,	LR_DEFAULTCOLOR | LR_LOADFROMFILE);
	}

	/* Set window not always ontop */
	if (!ontop)
		SetWindowPos(hWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE | SWP_NOSIZE);
				
	/* Here we check if the window is not on the screen */
	/* Like if you change resolutions after saving. */
	/* We thus move the window back onto the screen. */
	GetWindowRect(hWnd,&r);

	if (r.left >= (GetSystemMetrics(SM_CXSCREEN)))
		r.left = GetSystemMetrics(SM_CXSCREEN) - modX;
	if (r.top >= (GetSystemMetrics(SM_CYSCREEN)))
		r.top = GetSystemMetrics(SM_CYSCREEN) - modY;

	if (r.top < 0)
		r.top = 0;
	if (r.left < 0)
		r.left = 0;

	r.bottom = r.top + modX;
	r.right = r.left + modY;

	/* Save the new position */
	if (WritePrivateProfileString(pluginName,"top",itoa(r.top,cy,10),modules_ini)==0)
		MessageBox(0,MSG_ERRMOD,itoa(r.top,cy,10),MB_OK);
    WritePrivateProfileString(pluginName,"left",itoa(r.left,cx,10),modules_ini);        
	
	if (WritePrivateProfileString(pluginName,"ontop",itoa(ontop,cx,10),modules_ini)==0)
		MessageBox(0,MSG_ERRMOD,itoa(ontop,cx,10),MB_OK);

	/* Load the module */
	loadWharfModule(hWnd,lpCmdLine,0,0);
	
	/* Show the window */
	ShowWindow(hWnd,SW_SHOW);
	MoveWindow(hWnd,r.left,r.top,modX,modY,TRUE);
	UpdateWindow(hWnd);

	/* Process application messages until the application closes */
	while( GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	
	if (defaultBackImage)
		DeleteObject(defaultBackImage);

	return 0;
}
