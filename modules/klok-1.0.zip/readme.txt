klok v. 1.0 readme
==================

klok is an analog clock running as a wharf module for Litestep. It was
originally made for Codename 2, and later extended to work under Litestep
and PureLS.

It works under PureLS, LiteStep and Codename 2 (is anyone still using it?).
It might work under DarkStep and other LS compatible shells, but I haven't
tried it.

It's been a while since I made it, and I've used it ever since, but I never
got around releasing it to the public. Recently, I made a homepage for a
little PalmOS game I made, which turned out to be quite popular, and I
thought it might be time to put this little mod out.

Features:
 - Analog clock with hour, minute and second hands
 - Shows day of week, date and month
 - Highly configurable
 - Skinnable
 - Antialiased hands

Files included in this package:
  klok.dll         the module itself
  readme.txt       you're reading it!
  modules.ini      sample configuration
  days.bmp         bitmap file for the sample configuration
  digits.bmp       bitmap file for the sample configuration
  klokbg.bmp       bitmap file for the sample configuration  

klok is freeware - hope you like it.

niboan
(Niels Bo Andersen)


Contact:
--------
New releases and updates:   http://niboan.dhs.org/klok.shtml
Main site:                  http://niboan.dhs.org/
email:                      niels@niboan.dhs.org


Installation:
-------------
Place klok.dll in the LS dir, the images in the LS image dir and merge the
modules.ini file with your existing one.
Insert the following line (or something similar) in step.rc (or whereever
your wharf is configured):

*Wharf "Date & Time" klokbg.bmp @C:\PureLS\klok.dll

(of course you should replace 'C:\PureLS\' with your LS dir).

Edit the *BMP entries in modules.ini to point to your LS image dir, and you
should be ready to recycle.

If you use Codename 2, you're pretty much on your own. I haven't used it
for almost 2 years, and I really can't remember how to configure it.
If you do have problems, feel free to drop me a mail.


Configuration:
--------------
Here is a short explanation of the configuration options. Try looking at the
included sample files as well.

AntiAliasing
  Value: 0|1
  Turns Antialiasing on (1) or off (0).

HHandCenter
MHandCenter
SHandCenter
  Value: x,y (pixels)
  Sets origin of the (H)our (M)inute or (S)econd hands.

HHandStart
MHandStart
SHandStart
  Value: l (pixels)
  Sets the length of the 'tail' of the hands from the origin.

HHandEnd
MHandEnd
SHandEnd
  Value: l (pixels)
  Sets the length of the hands from the origin.

HHandWidth
MHandWidth
SHandWidth
  Value: w (pixels)
  Sets the width of the hands in pixels.

HHandColor
MHandColor
SHandColor
  Value: r,g,b (0-255)
  Sets the color of the hands.

ShowSHand
  Value: 0|1
  Turns the second hand on (1) or off (0).

ShowDOW
  Value: 0|1
  Turns the day of week on (1) or off (0).

DOWPos
  Value: x,y (pixels)
  Sets the position of the day of week bitmap.

DOWBMP
  Value: file
  Full path to the day of week bitmap. The bitmap is divided into 7 bitmaps,
  and the first bitmap is showed for monday, the second for tuesday and so on.
  The bitmap can be any size, but the width should be divideable by 7.

ShowDay
ShowMonth
ShowYear
  Value: 0|1
  Turns the date, month or year on (1) or off (0).

DayPos
MonthPos
YearPos
  Value: x,y (pixels)
  Sets the position of the date, month or year.

DayPadZero=0
MonthPadZero=1
  Value: 0|1
  If 1, the date or month will be padded with zeros to a length of 2
  chars (01,02,...).

DayBMP
MonthBMP
YearBMP
  Value: file
  Full path to the digit bitmap, which is used to draw the numbers. The
  bitmap should contain the digits from 0 to 9 (or whatever you want to
  represent the digits) The bitmap can be any size, but the width should
  be divideable by 10.

YearDigits
  Value: 2|4
  Show the year with 2 or 4 digits.
