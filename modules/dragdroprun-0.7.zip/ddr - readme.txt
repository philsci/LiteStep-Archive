////////////////////////
// Drag, Drop & Run V0.7
// By: Duff
// Released: 3/09/98

// Speach
	A few thing to say
	DD&R is a wharf module to launch program
	Fully drag & drop

	Based on an old developpement of mine(Duff's launch) and the WharfLaunch module by MrJukes
	Thanks to Bryan Kilian for the Delphi SDK

// How to
	Just drag your program on one of the cell
	You can drag any document on cell with program on it
	You can't directly drag document
	At this time, you must edit modules.ini to erase an entry.

// V0.7
	- Fix some minor bugs
	- Fix long file name bug
	- added: the default background picture is the litestep wharf background picture

// V0.6
	- First public release

// Know problems
	- A graphic problem with background pictures
	- Don't know about cpu and ram usage, need help about it

// Installation
        1) Unzip ddr.dll where you want
	2) put ddr.bmp where you want
        3) Put the normal *Wharf line in your step.rc
                *Wharf "WharfLaunch" default.bmp @c:\litestep\ddr.dll
        4) Refresh Litestep

// Modules.ini
        
        [wharfddr]

	// you can use this line to change the default background bitmap
	picture=c:\litestep\images\ddr.bmp


Have fun,
        Duff
	arn@Francenet.fr
