//#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <commdlg.h>
#include "resource.h"

#define MYWM_NOTIFYICON (WM_APP+100)

HINSTANCE hinst = NULL; 
HWND hwndMain = NULL; 
char* AppName = "DirWatch";
HANDLE thread=NULL;
HANDLE notify=NULL;

HICON IDLE, BUSY;
char WATCH_DIRECTORY[MAX_PATH] = "";
char OUT_FILE[MAX_PATH] = "";

void PrintDirectoryStructure(char*, char*);
void Watch();

BOOL CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg;
	DWORD threadID;
	NOTIFYICONDATA id;

    UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;  // save instance handle 

	hwndMain = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, WndProc);
	if (!hwndMain) 
	{
		LPVOID lpMsgBuf;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
		MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
		LocalFree( lpMsgBuf );
		return -1;
	}

	IDLE = LoadIcon(hinst, MAKEINTRESOURCE(IDI_IDLE));
	BUSY = LoadIcon(hinst, MAKEINTRESOURCE(IDI_BUSY));

	id.cbSize = sizeof(NOTIFYICONDATA);
	id.hWnd = hwndMain;
	id.uID = 1000;
	id.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
	id.hIcon = IDLE;
	strcpy(id.szTip, "Idle");
	id.uCallbackMessage = MYWM_NOTIFYICON;
	Shell_NotifyIcon(NIM_ADD, &id);

	GetPrivateProfileString("DirWatch", "Directory", "", WATCH_DIRECTORY, MAX_PATH, ".\\dirwatch.ini");
	GetPrivateProfileString("DirWatch", "OutputFile", ".\\dirwatch.log", OUT_FILE, MAX_PATH, ".\\dirwatch.ini");

	notify = FindFirstChangeNotification(WATCH_DIRECTORY, TRUE, FILE_NOTIFY_CHANGE_DIR_NAME);
	if (notify == INVALID_HANDLE_VALUE) 
	{
		LPVOID lpMsgBuf;
		FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
		MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
		LocalFree( lpMsgBuf );
		return -1;
	}
	
	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Watch, (LPVOID)NULL, 0, &threadID);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	Shell_NotifyIcon(NIM_DELETE, &id);
	DeleteObject(IDLE);
	DeleteObject(BUSY);
	TerminateThread(thread, 0);
	FindCloseChangeNotification(notify);
	DestroyWindow(hwndMain);

	return msg.wParam; 
}

BOOL CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hwndMain);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;

		/*case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDC_BROWSE:
						{
						}
						break;
					}
				}
				break;
			}
		}
		break;*/

		case MYWM_NOTIFYICON:
		{
			if (wParam == 1000)
			{
				switch (lParam)
				{
					case WM_LBUTTONDBLCLK:
					{
						ShowWindow(hwndMain, SW_SHOW);
					}
					break;

					case WM_RBUTTONUP:
					{
						if (MessageBox(hwndMain, "Are you sure you would like to exit?", AppName, MB_SYSTEMMODAL | MB_YESNO | MB_ICONQUESTION) == IDYES) PostQuitMessage(0);
					}
					break;
				}
			}
		}
		break;
	}

	return FALSE;
}

void Watch()
{
	while (1)
	{
		NOTIFYICONDATA id;

		id.cbSize = sizeof(NOTIFYICONDATA);
		id.hWnd = hwndMain;
		id.uID = 1000;
		id.uFlags = NIF_ICON | NIF_TIP | NIF_MESSAGE;
		id.hIcon = IDLE;
		strcpy(id.szTip, "Idle");
		id.uCallbackMessage = MYWM_NOTIFYICON;
		Shell_NotifyIcon(NIM_MODIFY, &id);

		WaitForSingleObject(notify, INFINITE);
		
		id.hIcon = BUSY;
		strcpy(id.szTip, "Busy");
		Shell_NotifyIcon(NIM_MODIFY, &id);
		
		DeleteFile(OUT_FILE);
		PrintDirectoryStructure(WATCH_DIRECTORY, "");
		FindNextChangeNotification(notify);
	}
}

void PrintDirectoryStructure(char* match, char* spacing)
{
	HANDLE fff = NULL;
	char path[MAX_PATH] = "";
	WIN32_FIND_DATA* fd = (WIN32_FIND_DATA*)malloc(sizeof(WIN32_FIND_DATA));

	sprintf(path, "%s*", match);
	fff = FindFirstFile(path, fd);

	while (FindNextFile(fff, fd))
	{
		if (fd->dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (strcmp(fd->cFileName, ".") && strcmp(fd->cFileName, ".."))
			{
				FILE* file = fopen(OUT_FILE, "a");
				char temp[MAX_PATH] = "";
				int x;

				strcpy(temp, fd->cFileName);
				for (x=0; x < (int)strlen(temp); x++) { if (temp[x] == '_') temp[x] = ' '; }
				fprintf(file, "%s%s\n", spacing, temp);
				fclose(file);

				sprintf(path, "%s%s\\", match, fd->cFileName);

				sprintf(temp, "%s    ", spacing);
				PrintDirectoryStructure(path, temp);

				if (!strlen(spacing))
				{
					FILE* file = fopen(OUT_FILE, "a");
					fprintf(file, "\n");
					fclose(file);
				}
			}
		}
	}

	FindClose(fff);
}