		**********************************************
		* Bang scripting module - Version 1.0 readme *
		**********************************************

0. Contents
*******************

	1. Introduction
	2. Installation
	3. Reference
	4. About
	
	1. Introduction
***********************
	
	First of all, sorry for my bad grammatical errors, I hope you'll understand 
this piece! 

	This module enables You to write bang scripts. Sample use in included in
LSRC - readme.txt.

	2. Installation
***********************

	1) Unzip bscript.dll
	2) Copy the file in Your LiteStep modules path
	3) Add lswchanger.dll to the list with modules loaded with 
LiteStep in step.rc
	4) Create script.rc file with some scripts and put it into your LiteStep 
directory. Sample script.rc file is included in this archive
	5) Recycle LiteStep
	
	3. Reference
********************

!bscript <script_name>				- executes the script

Each script can have !bang and console commands. Each script body has the foloving
format:

*bscript <script_name>

... ; some commands

*end <script_name>

Sample script:

*bscript popup_red
	!rc-set PopupGradientTitle 0000FF
	!rc-set PopupTitleColor FFFFFF
	!rc-set PopupTitleBgColor 000000
	!rc-set PopupGradientEntry FF0000
	!rc-set PopupEntryColor FFF000
	!rc-set PopupEntryBgColor 200000
*end popup_red

4. About
****************

	I am Tzvetan Raikov, I am from Bulgaria and now I am study at Sofia university. 
To send a bug reports, when you have good ideas, or to contact with me you can use:

	e-mail:	craikov@hotmail.com
	www:	http://www.geocities.com/wchangerbg
