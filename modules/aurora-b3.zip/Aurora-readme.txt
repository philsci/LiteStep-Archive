/////////////////////////
// Aurora B3
// Written By: MrJukes
// Released: 1/11/00
/////////////////////////

/////////////////////////
// What's new in B3
/////////////////////////
Bang Commands:
- !AuroraPulse 0000FF 000000... ; You can define up to 20 colors (BBGGRR)
- !AuroraStopPulse		; Stops pulsing and goes back to normal mode
- !AuroraHide			; Hides Aurora
- !AuroraShow			; Shows Aurora
- !AuroraToggle			; Toggles Visiblity

Step.rc commands:
AuroraStartHidden		; Starts Aurora hidden
AuroraStartPulsing		; Starts Aurora in Pulse mode 
				; (Can be used with AuroraStartHidden)
AuroraPulse 77670A 000000...	; Up to 20 colors, 
				; Default pulse if AuroraStartPulse is used
AuroraColorStep 5		; How quickly Aurora switches through colors (1-255)
AuroraTimer 25			; How often in milliseconds that Aurora updates
/////////////////////////

/////////////////////////
// What's new in B2
/////////////////////////
Step.rc commands:
- AuroraX 100
- AuroraY 200
- AuroraWidth 150
- AuroraHeight 400
/////////////////////////


LoadModule c:\litestep\aurora.dll

/////////////////////////
// Step.rc
/////////////////////////
AuroraTopWidth 3
AuroraTopColorIn FF0000
AuroraTopColorOut 00FF00

AuroraRightWidth 3
AuroraRightColorIn 00FF00
AuroraRightColorOut FF0000

AuroraBottomWidth 3
AuroraBottomColorIn 0000FF
AuroraBottomColorOut 00FFFF

AuroraLeftWidth 3
AuroraLeftColorIn 00FFFF
AuroraLeftColorOut FF0000

Have fun,
	MrJukes