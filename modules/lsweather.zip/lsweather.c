#include <windows.h>
#include <stdio.h>
#include <wininet.h>
#include <commctrl.h>
#include "lsapi.h"
#include "LSWeather.h"
#include "resource.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LSWeather"; // Name of Application, Window class...

void BrowseForFile(HWND hwnd, DWORD editbox, char* filter);
void ClearAllValues();
BOOL ConstructURL(char* FULL_URL);
void DisplayValue(HDC buf, char* val);
BOOL GetValue(const char* pointer, char* temp, char* delim);
void GetWeather();
void GetWind(const char* pointer, char* temp);
void LoadSetup();
void LoadThemeInfo();
void ParseFormat(char*, char*);
char* ReportCondition(char* what);
void SaveDlgConfigValues(HWND hwnd);
void SetActiveCity(int);
void SetConfigDlgValues(hwnd);
void SetDlgConfigDisplayValue(HWND hwnd, char* section, DWORD button, DWORD format, DWORD x, DWORD y, char* thmfile);
void SetupBitmapListView(HWND hwnd);
void SetupStateBox(HWND hwnd, DWORD, char*);
void WritePrivateProfileInt(char* appname, char* keyname, int val, char* file);
int WritePrivateProfileDlgInt(char* appname, char* keyname, HWND hwnd, DWORD item, char* file);
void WritePrivateProfileDlgString(char* appname, char* keyname, HWND hwnd, DWORD item, char* file);

// Conversion Functions
int FTOC(int);
int FTOK(int);
int ITOH(int);
int MTOK(int);

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AddConditionDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AddFavoriteDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ConfigDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HelpDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ReportDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
HWND ZIP_WND = NULL;
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HINSTANCE Instance;
HMENU Popup;
HMENU FavPopup;

HBITMAP BGBMP = NULL;
HANDLE thread=NULL;

BOOL ACTIVE = TRUE;
BOOL CHANGED=TRUE;
BOOL CHECKING = FALSE;
BOOL ERR = FALSE;
BOOL FIRST=FALSE;
BOOL HIDDEN=FALSE;
BOOL LOADMODULE = FALSE;
BOOL LOADED=FALSE;
BOOL QUITTING = FALSE;
BOOL TOP=FALSE;

BOOL DISPLAY_TEMPERATURE=FALSE, DISPLAY_CONDITIONS=FALSE, DISPLAY_PRESSURE=FALSE;
BOOL DISPLAY_HUMIDITY=FALSE, DISPLAY_DEWPOINT=FALSE, DISPLAY_VISIBILITY=FALSE;
BOOL DISPLAY_SUNRISE=FALSE, DISPLAY_SUNSET=FALSE, DISPLAY_MOONRISE=FALSE;
BOOL DISPLAY_MOONSET=FALSE, DISPLAY_MOONPHASES=FALSE, DISPLAY_WIND=FALSE;

char ini[MAX_PATH] = "";
char thm[MAX_PATH] = "";
char ZIP_CODE[6] = "";
char SPECIFIC[50] = "";
char STATION[15] = "";
char STATE[5] = "";
char CITY[50] = "";
char IMAGE_DIR[MAX_PATH] = "";
char FontName[MAX_PATH] = "System";
char ReportString[256] = "";

char CURRENT_CONDITIONS[50]	= "";
char CURRENT_DOUBLE_CLICK[30] = "";
char CURRENT_WIND[50]		= "";
char CURRENT_SUNRISE[25]	= "";
char CURRENT_SUNSET[25]		= "";
char CURRENT_MOONRISE[25]	= "";
char CURRENT_MOONSET[25]	= "";

DWORD MB = MB_OK | MB_SETFOREGROUND;
DWORD threadID=0;

int CURRENT_TEMP		= 0;
int CURRENT_HUMIDITY	= 0;
int CURRENT_DEWPOINT	= 0;
int CURRENT_PRESSURE	= 0;
int CURRENT_VISIBILITY	= 0;
DWORD CURRENT_HELP=0;
int USE_METHOD = 0;   // 0 = Zip, 1 = City/State, 2 = Global Station
int FAV=0;
int TIMER=60000;
int XPos=0, YPos=0;
int WndWidth=64, WndHeight=64;
int R,G,B,CR,CG,CB;
int FontSize=10;
int ScreenX=1024, ScreenY=768;

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	LOADMODULE=TRUE;
	parent = ParentWnd; // Save parent window
	Instance = dllInst;
	sprintf(ini, "%s\\modules.ini", szPath);

	{    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }
	
	LoadSetup();

	hMainWnd = CreateWindowEx(
        WS_EX_TOOLWINDOW,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_POPUP,                                   // window style
        XPos, YPos,									// position 
        WndWidth, WndHeight,                        // width & height of window
        GetDesktopWindow(),                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	// Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));

    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
	SetTimer(hMainWnd, 0, TIMER, NULL);

	return 0;
}

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	parent = ParentWnd; // Save parent window
	// Duplicate wharfData since the one we get will be destroyed
	memcpy(&wharfData, wd, sizeof(wharfDataType));
	if (wharfData.borderSize < 0)
		wharfData.borderSize = 0;
	wndSize = 64-wharfData.borderSize*2;
	Instance = dllInst;

    {    // Register the Window class
        WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;       // our window procedure
		wc.hInstance = dllInst;         // hInstance of DLL
		wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class",szAppName, MB_OK);
			return 1;
		}
    }

	LoadSetup();

	hMainWnd = CreateWindowEx(
				0,                          // exstyles 
				szAppName,                                  // our window class name
				szAppName,                                  // use description for a window title
				WS_CHILD,                                   // window style
				wharfData.borderSize, wharfData.borderSize, // position 
				wndSize,wndSize,                            // width & height of window
				parent,                                     // parent window (litestep wharf window)
				NULL,                                       // no menu
				dllInst,                                    // hInstance of DLL
				0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));	
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
	SetTimer(hMainWnd, 0, TIMER, NULL);
	
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	quitWharfModule(dllInst);
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	QUITTING = TRUE;
	TerminateThread(thread, 0);
	KillTimer(hMainWnd, 0);
	DestroyMenu(Popup);
	DestroyMenu(FavPopup);
	DeleteObject(BGBMP);
	DestroyWindow(hMainWnd);                // delete our window
	UnregisterClass(szAppName, dllInst);    // unregister window class
}

void LoadSetup()
{
	char temp[256] = "";
	int x=0;

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!LSWHide",BangHide);
	AddBangCommand("!LSWShow",BangShow);
	AddBangCommand("!LSWToggle",BangToggle);
	AddBangCommand("!LSWUpdate",BangUpdate);
	AddBangCommand("!LSWReport",BangReport);
	AddBangCommand("!LSWChangeSettings",BangChangeSettings);
	AddBangCommand("!LSWLaunchWebpage",BangLaunchWebpage);
	AddBangCommand("!LSWAlwaysOnTop",BangAlwaysOnTop);

	// Make sure we know where the modules.ini is
	if (!LOADMODULE) sprintf(ini, "%smodules.ini", wharfData.lsPath);
	
	// Find the theme file we are to use
	GetPrivateProfileString(szAppName, "ThemeFile", "NO THEME HONKY", thm, MAX_PATH, ini);
	if (!strcmp(thm, "NO THEME HONKY"))
	{
		MessageBox(parent, "Thank you for trying out LSWeather.  It seems as though you do not have a theme file specified in your modules.ini.  Please hit \"Ok\" and configure LSWeather to your liking.", szAppName, MB);
		(!LOADMODULE)? sprintf(thm, "%slsweather.thm", wharfData.lsPath) : sprintf(thm, "c:\\litestep\\lsweather.thm");
		DialogBox(Instance, MAKEINTRESOURCE(IDD_CONFIG), parent, ConfigDialogProc);
	}

	// The modules.ini only holds XY coords, Location Info, DisplayType, Timer info, Usage Type, Active Toggle. and Favorites
	GetPrivateProfileString(szAppName, "ZipCode", "47906", ZIP_CODE, 6, ini);
	GetPrivateProfileString(szAppName, "City", "Lafayette", CITY, 50, ini);
	GetPrivateProfileString(szAppName, "State", "IN", STATE, 5, ini);
	GetPrivateProfileString(szAppName, "GlobalStation", "", STATION, 15, ini);
	XPos = GetPrivateProfileInt(szAppName, "DesktopX", 50, ini);
	YPos = GetPrivateProfileInt(szAppName, "DesktopY", 50, ini);
	TIMER = GetPrivateProfileInt(szAppName, "Timer", 1, ini) * 60000;
	USE_METHOD = GetPrivateProfileInt(szAppName, "UseMethod", 0, ini);
	ACTIVE = GetPrivateProfileInt(szAppName, "Active", 1, ini);

	LoadThemeInfo();

	FavPopup = CreatePopupMenu();
	for (x=0; x<10; x++)
	{
		char name[256] = "";
		
		sprintf(temp, "Favorite%d", x);
		GetPrivateProfileString(szAppName, temp, "", name, 256, ini);
		
		if (strlen(name))
		{
			AppendMenu(FavPopup, MF_ENABLED | MF_STRING, 200 + x, name);
			FAV++;
		}
		else break;
	}

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, M_UPDATE, "&Update");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_ACTIVE, "&Active");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_REPORT, "&Report Current Conditions");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_SETTINGS, "Change &Settings");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_LAUNCH, "&Launch Webpage");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_ABOUT, "About &LSWeather");
	AppendMenu(Popup, MF_SEPARATOR, 0, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)FavPopup, "Favorites");
	AppendMenu(Popup, MF_SEPARATOR, 0, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_USEZIP, "Use &Zip Code");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_USECITY, "Use Cit&y");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, M_USESTATION, "Use &Global Station");

	(ACTIVE)? CheckMenuItem(Popup, M_ACTIVE, MF_CHECKED) : CheckMenuItem(Popup, M_ACTIVE, MF_CHECKED);
	
	if (USE_METHOD == 0) CheckMenuItem(Popup, M_USEZIP, MF_CHECKED);
	else if (USE_METHOD == 1) CheckMenuItem(Popup, M_USECITY, MF_CHECKED);
	else if (USE_METHOD == 2) CheckMenuItem(Popup, M_USESTATION, MF_CHECKED);
}

void LoadThemeInfo()
{
	char rgb[15] = "";
	char bg[MAX_PATH] = "";

	if (LOADMODULE)
	{
		WndWidth = GetPrivateProfileInt("Main", "Width", 64, thm);
		WndHeight = GetPrivateProfileInt("Main", "Height", 64, thm);
	}
	else
	{
		WndWidth = WndHeight = wndSize;
	}

	GetPrivateProfileString("Main", "ImageDir", "", IMAGE_DIR, MAX_PATH, thm);
	if (IMAGE_DIR[strlen(IMAGE_DIR)-1] != '\\') strcat(IMAGE_DIR, "\\");
	GetPrivateProfileString("Main", "BackGroundPix", "", bg, MAX_PATH, thm);
	if (bg[0])
	{
		char temp[256] = "";
		sprintf(temp, "%s%s", IMAGE_DIR, bg);
		BGBMP = LoadImage(Instance, temp, IMAGE_BITMAP, WndWidth, WndHeight, LR_LOADFROMFILE);
	}

	DISPLAY_TEMPERATURE = GetPrivateProfileInt("Main", "DisplayTemperature", 0, thm);
	DISPLAY_CONDITIONS = GetPrivateProfileInt("Main", "DisplayConditions", 0, thm);
	DISPLAY_PRESSURE = GetPrivateProfileInt("Main", "DisplayPressure", 0, thm);
	DISPLAY_HUMIDITY = GetPrivateProfileInt("Main", "DisplayHumidity", 0, thm);
	DISPLAY_DEWPOINT = GetPrivateProfileInt("Main", "DisplayDewPoint", 0, thm);
	DISPLAY_VISIBILITY = GetPrivateProfileInt("Main", "DisplayVisibility", 0, thm);
	DISPLAY_SUNRISE = GetPrivateProfileInt("Main", "DisplaySunrise", 0, thm);
	DISPLAY_SUNSET = GetPrivateProfileInt("Main", "DisplaySunset", 0, thm);
	DISPLAY_MOONRISE = GetPrivateProfileInt("Main", "DisplayMoonrise", 0, thm);
	DISPLAY_MOONSET = GetPrivateProfileInt("Main", "DisplayMoonset", 0, thm);
	DISPLAY_MOONPHASES = GetPrivateProfileInt("Main", "DisplayMoonPhases", 0, thm);
	DISPLAY_WIND = GetPrivateProfileInt("Main", "DisplayWind", 0, thm);
	
	GetPrivateProfileString("Main", "FontRGB", "255 255 255", rgb, 15, thm);
	R = atoi(strtok(rgb, " "));
	G = atoi(strtok(NULL, " "));
	B = atoi(strtok(NULL, ""));
	
	memset(&rgb, 0, sizeof(rgb));
	GetPrivateProfileString("Main", "FontCheckRGB", "255 0 0", rgb, 15, thm);
	CR = atoi(strtok(rgb, " "));
	CG = atoi(strtok(NULL, " "));
	CB = atoi(strtok(NULL, ""));
	
	FontSize = GetPrivateProfileInt("Main", "FontSize", 10, thm);
	GetPrivateProfileString("Main", "Font", "System", FontName, MAX_PATH, thm);

	GetPrivateProfileString("Main", "DoubleClick", "Report Conditions", CURRENT_DOUBLE_CLICK, 30, thm);
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
		
		case WM_NCHITTEST:
		{
			if (LOADMODULE) return HTCAPTION;
			else return HTCLIENT;
		}
		return 0;

		case WM_NCPAINT:
        case WM_PAINT:
		{
			__try {
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC back = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, WndWidth, WndHeight);
			HFONT font=NULL;
			char temp[256] = "";

			SelectObject(back, BGBMP);
			SelectObject(buf, bufbmp);
			BitBlt(buf, 0, 0, WndWidth, WndHeight, back, 0, 0, SRCCOPY);
			
			SetBkMode(buf, TRANSPARENT);
			(CHECKING)? SetTextColor(buf, RGB(CR,CG,CB)) : SetTextColor(buf, RGB(R,G,B));
				
			font = CreateFont(FontSize, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, FontName);
			SelectObject(buf, font);

			if (GetPrivateProfileInt("Conditions", "DisplayBmp", 0, thm))
			{
				HDC chdc = CreateCompatibleDC(NULL);
				HBITMAP cbmp = NULL;
				char buffer[MAX_PATH] = "";
				char bmp[MAX_PATH] = "";

				if (strlen(CURRENT_CONDITIONS))
				{
					if (!ERR)
					{
						GetPrivateProfileString("Conditions", CURRENT_CONDITIONS, "NO FINDY", buffer, MAX_PATH, thm);
						if (!strcmp(buffer, "NO FINDY")) GetPrivateProfileString("Conditions", "Unknown", "lsweather.bmp", buffer, MAX_PATH, thm);
					}
					else
					{
						GetPrivateProfileString("Conditions", "Error", "NO FINDY", buffer, MAX_PATH, thm);
						if (!strcmp(buffer, "NO FINDY")) GetPrivateProfileString("Conditions", "Unknown", "lsweather.bmp", buffer, MAX_PATH, thm);
					}
						
					sprintf(bmp, "%s%s", IMAGE_DIR, buffer);
					cbmp = LoadImage(Instance, bmp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

					if (cbmp)
					{
						SelectObject(chdc, cbmp);
						BitBlt(buf, 
							   GetPrivateProfileInt("Conditions", "BmpX", 0, thm), 
							   GetPrivateProfileInt("Conditions", "BmpY", 0, thm), 
							   GetPrivateProfileInt("Conditions", "BmpWidth", 0, thm),
							   GetPrivateProfileInt("Conditions", "BmpHeight", 0, thm),
							   chdc, 0, 0, SRCCOPY);
					}
				}

				DeleteDC(chdc);
				DeleteObject(cbmp);
			}

			if (GetPrivateProfileInt("Conditions", "DisplayText", 0, thm))
			{
				char out[256] = "";
				char holdme[256] = "";

				strcpy(holdme, CURRENT_CONDITIONS);
				// Text Replacement
				sprintf(out, "%s Text Replacement", CURRENT_CONDITIONS);
				GetPrivateProfileString("Conditions", out, "", temp, 256, thm);
				if (strlen(temp)) strcpy(CURRENT_CONDITIONS, temp);

				DisplayValue(buf, "Conditions");
				strcpy(CURRENT_CONDITIONS, holdme);
			}

			if (DISPLAY_TEMPERATURE) DisplayValue(buf, "Temperature");
			if (DISPLAY_PRESSURE) DisplayValue(buf, "Pressure");
			if (DISPLAY_HUMIDITY) DisplayValue(buf, "Humidity");
			if (DISPLAY_DEWPOINT) DisplayValue(buf, "DewPoint");					
			if (DISPLAY_VISIBILITY) DisplayValue(buf, "Visibility");
			if (DISPLAY_SUNRISE) DisplayValue(buf, "Sunrise");
			if (DISPLAY_SUNSET) DisplayValue(buf, "Sunset");
			if (DISPLAY_MOONRISE) DisplayValue(buf, "Moonrise");
			if (DISPLAY_MOONSET) DisplayValue(buf, "Moonset");
			if (DISPLAY_WIND) DisplayValue(buf, "Wind");

			BitBlt(hdc, 0, 0, WndWidth, WndHeight, buf, 0, 0, SRCCOPY);
				
			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
			DeleteDC(buf);
			DeleteDC(back);
			DeleteObject(bufbmp);
			DeleteObject(font);
			}__except(1) { ERR=TRUE; }
		}
		return 0;

		case WM_TIMER:
		{
			thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
		}
		return 0;

		case WM_WINDOWPOSCHANGING:
		{
			if (LOADMODULE)
			{
				WINDOWPOS* pos = (WINDOWPOS*)lParam;
				char temp[15]= "";

				if (!(pos->flags & SWP_NOMOVE))
				{
					if (pos->x+WndWidth >= ScreenX-5) pos->x = ScreenX - WndWidth;
					else if (pos->x <= 5) pos->x = 0;
					if (pos->y+WndHeight >= ScreenY-5) pos->y = ScreenY - WndHeight;
					else if (pos->y <= 5) pos->y = 0;

					XPos = pos->x;
					YPos = pos->y;
				}

				sprintf(temp, "%d", XPos);
				WritePrivateProfileString(szAppName, "DesktopX", temp, ini);
				sprintf(temp, "%d", YPos);
				WritePrivateProfileString(szAppName, "DesktopY", temp, ini);
			}
		}
		return 0;

        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        
		case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;

		case WM_NCLBUTTONDBLCLK:
		case WM_LBUTTONDBLCLK:
		{
			if (!strcmp(CURRENT_DOUBLE_CLICK, "Launch Webpage")) SendMessage(hwnd, WM_COMMAND, (WPARAM)M_LAUNCH, 0);
			else if (!strcmp(CURRENT_DOUBLE_CLICK, "Change Settings")) SendMessage(hwnd, WM_COMMAND, (WPARAM)M_SETTINGS, 0);
			else if (!strcmp(CURRENT_DOUBLE_CLICK, "Report Conditions")) SendMessage(hwnd, WM_COMMAND, (WPARAM)M_REPORT, 0);
			else if (!strcmp(CURRENT_DOUBLE_CLICK, "Update")) SendMessage(hwnd, WM_COMMAND, (WPARAM)M_UPDATE, 0);
		}
		return 0;

		case WM_NCRBUTTONUP:
		case WM_RBUTTONUP:
        {
			RECT r;
            GetWindowRect(hwnd, &r);
            PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
		}
        return 0;

		case WM_NCRBUTTONDOWN:
        case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
		}
		return 0;

		case WM_NCMOUSEMOVE:
		case WM_MOUSEMOVE:
		{
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return 0;

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case M_UPDATE: // Update
				{
					thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
				}
				break;

				case M_ACTIVE: // Active
				{
					if (ACTIVE)
					{
						ACTIVE=FALSE;
						CheckMenuItem(Popup, M_ACTIVE, MF_UNCHECKED);
						KillTimer(hwnd, 0);
					}
					else
					{
						ACTIVE=TRUE;
						CheckMenuItem(Popup, M_ACTIVE, MF_CHECKED);
						thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
						SetTimer(hwnd, 0, TIMER, NULL);
					}
				}
				break;

				case M_SETTINGS: // Change Settings
				{
					DialogBox(Instance, MAKEINTRESOURCE(IDD_CONFIG), hMainWnd, ConfigDialogProc);
				}
				break;

				case M_LAUNCH: // Launch wunderground
				{
					char FULL_URL[256] = "";
					BOOL GO = ConstructURL(FULL_URL);
					if (GO) ShellExecute(NULL, "open", FULL_URL, NULL, NULL, SW_SHOWNORMAL);
				}
				break;

				case M_ABOUT: // About
				{
					DialogBox(Instance, MAKEINTRESOURCE(IDD_ABOUT), hMainWnd, AboutDialogProc);
				}
				break;

				case M_USEZIP: // Use Zip
				{
					USE_METHOD = 0;
					WritePrivateProfileString(szAppName, "UseMethod", "0", ini);
					CheckMenuItem(Popup, M_USEZIP, MF_CHECKED);
					CheckMenuItem(Popup, M_USECITY, MF_UNCHECKED);
					CheckMenuItem(Popup, M_USESTATION, MF_UNCHECKED);
					thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
				}
				break;

				case M_USECITY: // Use City/State
				{
					USE_METHOD = 1;
					WritePrivateProfileString(szAppName, "UseMethod", "1", ini);
					CheckMenuItem(Popup, M_USEZIP, MF_UNCHECKED);
					CheckMenuItem(Popup, M_USECITY, MF_CHECKED);
					CheckMenuItem(Popup, M_USESTATION, MF_UNCHECKED);
					thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
				}
				break;

				case M_USESTATION: // Use Global Station
				{
					USE_METHOD = 2;
					WritePrivateProfileString(szAppName, "UseMethod", "2", ini);
					CheckMenuItem(Popup, M_USEZIP, MF_UNCHECKED);
					CheckMenuItem(Popup, M_USECITY, MF_UNCHECKED);
					CheckMenuItem(Popup, M_USESTATION, MF_CHECKED);
					thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
				}
				break;

				case M_REPORT: // Weather Report
				{
					DialogBox(Instance, MAKEINTRESOURCE(IDD_REPORT), hMainWnd, ReportDialogProc);
				}
				break;

				// The Favorites
				case 200: SetActiveCity(0); break;
				case 201: SetActiveCity(1); break;
				case 202: SetActiveCity(2); break;
				case 203: SetActiveCity(3); break;
				case 204: SetActiveCity(4); break;
				case 205: SetActiveCity(5); break;
				case 206: SetActiveCity(6); break;
				case 207: SetActiveCity(7); break;
				case 208: SetActiveCity(8); break;
				case 209: SetActiveCity(9); break;
			}
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

void GetWeather()
{
	HINTERNET hint = NULL;
	HINTERNET http = NULL;
	DWORD ConnectionType=0;
	BOOL GO = TRUE;
	
	//if (InternetGetConnectedState(&ConnectionType, 0) && !CHECKING && TIMER >= 60000)
	__try 
	{
		if (!CHECKING && TIMER >= 60000)
		{
			CHECKING = TRUE;
			ERR=FALSE;
			InvalidateRect(hMainWnd, NULL, TRUE);

			hint = InternetOpen(szAppName, INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
			if (hint)
			{
				char FULL_URL[256] = "";

				GO = ConstructURL(FULL_URL);

				if (GO)
				{
					http = InternetOpenUrl(hint, FULL_URL, NULL, 0, INTERNET_FLAG_TRANSFER_ASCII | INTERNET_FLAG_RELOAD | INTERNET_FLAG_DONT_CACHE, 0);

					if (http)
					{
						DWORD dwRead;
						DWORD dwSize;
						TCHAR szTemp[30000];
						char temp[256] = "";

						ClearAllValues();

						InternetQueryDataAvailable(http, &dwSize, 0, 0);

						while (InternetReadFile(http, (LPVOID)szTemp, 30000, &dwRead))
						{
							char* pointer;

							if (!dwRead) break;

							if ((pointer = strstr(szTemp, "<tr ><td>Temperature</td>")) != NULL)
							{
								char data[256] = "";

								if (GetValue(pointer, data, "&"))
								{
									CURRENT_TEMP = atoi(data);
									CHANGED=TRUE;
								} else break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Humidity</td>")) != NULL)
							{
								char data[256] = "";
								if (GetValue(pointer, data, "%"))
								{
									CURRENT_HUMIDITY = atoi(data);
								} else break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Dewpoint</td>")) != NULL)
							{
								char data[256] = "";
								
								if (GetValue(pointer, data, "&"))
								{
									CURRENT_DEWPOINT = atoi(data);
								} else break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Wind</td>")) != NULL)
							{
								memset(&CURRENT_WIND, 0, sizeof(CURRENT_WIND));
								GetWind(pointer, CURRENT_WIND);
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Pressure</td>")) != NULL)
							{
								char data[256] = "";
						
								if (GetValue(pointer, data, "<"))
								{
									CURRENT_PRESSURE = atoi(data);
								} else break;
							}	

							if ((pointer = strstr(szTemp, "<tr ><td>Conditions</td>")) != NULL)
							{
								memset(&CURRENT_CONDITIONS, 0, sizeof(CURRENT_CONDITIONS));
								if (!GetValue(pointer, CURRENT_CONDITIONS, "<")) break;
							}
							
							if ((pointer = strstr(szTemp, "<tr ><td>Visibility</td>")) != NULL)
							{
								char data[256] = "";
								
								if (GetValue(pointer, data, "<"))
								{
									CURRENT_VISIBILITY = atoi(data);
								} else break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Sunrise</td>")) != NULL)
							{
								memset(&CURRENT_SUNRISE, 0, sizeof(CURRENT_SUNRISE));
								if (!GetValue(pointer, CURRENT_SUNRISE, "<")) break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Sunset</td>")) != NULL)
							{
								memset(&CURRENT_SUNSET, 0, sizeof(CURRENT_SUNSET));
								if (!GetValue(pointer, CURRENT_SUNSET, "<")) break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Moon Rise</td>")) != NULL)
							{
								memset(&CURRENT_MOONRISE, 0, sizeof(CURRENT_MOONRISE));
								if (!GetValue(pointer, CURRENT_MOONRISE, "<")) break;
							}

							if ((pointer = strstr(szTemp, "<tr ><td>Moon Set</td>")) != NULL)
							{
								memset(&CURRENT_MOONSET, 0, sizeof(CURRENT_MOONSET));
								if (!GetValue(pointer, CURRENT_MOONSET, "<")) break;

								break;
							}
						}
						InternetCloseHandle(http);
					}
				}
			}

			InternetCloseHandle(hint);
			CHECKING = FALSE;
			InvalidateRect(hMainWnd, NULL, TRUE);
		}
	}__except(1) { ERR=TRUE; }
}

BOOL CALLBACK ConfigDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			char st[5] = "";
			SetDlgItemText(hwnd, IDC_THEME_FILE, thm);
			SetupBitmapListView(hwnd);
			SetConfigDlgValues(hwnd);
			GetPrivateProfileString(szAppName, "State", "", st, 5, ini);
			SetupStateBox(hwnd, IDC_STATE, st);
			LOADED=TRUE;
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
					LOADED=FALSE;
			}
		}
		break;
		
		case WM_NOTIFY:
		{
			return TRUE;
		}
		break;

		case WM_HELP:
		{
			HELPINFO* hi = (LPHELPINFO)lParam;

			CURRENT_HELP = hi->iCtrlId;
			DialogBox(Instance, MAKEINTRESOURCE(IDD_HELP), hwnd, HelpDialogProc);
		}
		return TRUE;

		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					BOOL APPLY=FALSE;
					switch LOWORD(wParam)
					{
						case IDC_APPLY:
							APPLY=TRUE;
						case IDOK:
						{
							SaveDlgConfigValues(hwnd);

							SetWindowPos(hMainWnd, 0, 0, 0, WndWidth, WndHeight, SWP_NOZORDER | SWP_NOMOVE);

							KillTimer(hMainWnd, 0);
							thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
							SetTimer(hMainWnd, 0, TIMER, NULL);
						}
						case IDCANCEL:
						{
							if (!APPLY)
							{
								EndDialog(hwnd, 0);
								LOADED=FALSE;
							}
						}
						break;

						case IDC_BITMAP_NEW:
						{
							DialogBox(Instance, MAKEINTRESOURCE(IDD_ADD_CONDITION), hwnd, AddConditionDialogProc);
						}
						break;

						case IDC_THEME_BROWSE:
						{
							BrowseForFile(hwnd, IDC_THEME_FILE , "Theme Files (*.thm)\0*.thm\0All Files (*.*)\0*.*\0\0");
						}
						break;

						case IDC_BITMAP_REMOVE:
						{
							HWND lv = GetDlgItem(hwnd, IDC_CONDITION_LIST);
							int index = ListView_GetSelectionMark(lv);
							char temp[256] = "";
							char temp2[256] = "";

							ListView_GetItemText(lv, index, 0, temp, 256);
							WritePrivateProfileString("Conditions", temp, NULL, thm);
							sprintf(temp2, "%s Text Replacement", temp);
							WritePrivateProfileString("Conditions", temp2, NULL, thm);
							ListView_DeleteItem(lv, index);
						}
						break;

						case IDC_USE_ZIPCODE:
						{
							SendMessage(GetDlgItem(hwnd, IDC_USE_CITY_STATE), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
							SendMessage(GetDlgItem(hwnd, IDC_USE_GLOBAL_STATION), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
						}
						break;
						case IDC_USE_CITY_STATE:
						{
							SendMessage(GetDlgItem(hwnd, IDC_USE_ZIPCODE), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
							SendMessage(GetDlgItem(hwnd, IDC_USE_GLOBAL_STATION), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
						}
						break;
						case IDC_USE_GLOBAL_STATION:
						{
							SendMessage(GetDlgItem(hwnd, IDC_USE_ZIPCODE), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
							SendMessage(GetDlgItem(hwnd, IDC_USE_CITY_STATE), BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
						}		
						break;

						case IDC_ADD_TO_FAVORITES:
						{
							DialogBox(Instance, MAKEINTRESOURCE(IDD_ADD_FAVORITE), hwnd, AddFavoriteDialogProc);
						}
						break;

						case IDC_LOAD_THEME:
						{
							SetupBitmapListView(hwnd);
							SetConfigDlgValues(hwnd);
						}
						break;

						case IDC_EXPORT_THEME:
						{
							SaveDlgConfigValues(hwnd);
						}
						break;
					}
				}
			}
		}
	}
	return FALSE;
}

BOOL CALLBACK AddConditionDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			SetFocus(GetDlgItem(hwnd, IDC_ADD_CONDITION));
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		break;
		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					switch LOWORD(wParam)
					{
						case IDOK:
						{
							LVITEM item;
							HWND parent = GetParent(hwnd);
							HWND lv = GetDlgItem(parent, IDC_CONDITION_LIST);
							int iItem = ListView_GetItemCount(lv);
							char condition[256] = "";
							char bitmap[256] = "";
							char replace[256] = "";
							
							GetDlgItemText(hwnd, IDC_ADD_CONDITION, condition, 256);
							GetDlgItemText(hwnd, IDC_ADD_BITMAP, bitmap, 256);
							GetDlgItemText(hwnd, IDC_ADD_REPLACE, replace, 256);

							if (!strlen(condition))
							{
								MessageBox(hwnd, "You must supply a condition.", szAppName, MB | MB_ICONEXCLAMATION);
								break;
							}

							if (!strlen(bitmap) && !strlen(replace))
							{
								MessageBox(hwnd, "You must supply a bitmap or replacement text.", szAppName, MB | MB_ICONEXCLAMATION);
								break;
							}

							item.mask = LVIF_TEXT;
							
							item.iItem = iItem;
							item.iSubItem = 0;
							item.pszText = condition;
							ListView_InsertItem(lv, &item);

							item.iItem = iItem;
							item.iSubItem = 1;
							item.pszText = bitmap;
							ListView_SetItem(lv, &item);

							item.iItem = iItem;
							item.iSubItem = 2;
							item.pszText = replace;
							ListView_SetItem(lv, &item);

							ListView_RedrawItems(lv, 0, iItem);
							UpdateWindow(hwnd);
							WritePrivateProfileString("Conditions", condition, bitmap, thm);
							sprintf(bitmap, "%s Text Replacement", condition);
							WritePrivateProfileString("Conditions", bitmap, replace, thm);
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
	}
	return FALSE;
}

BOOL CALLBACK AddFavoriteDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			HWND parent = GetParent(hwnd);
			char temp[100] = "";

			GetDlgItemText(parent, IDC_ZIPCODE, temp, 100);
			SetDlgItemText(hwnd, IDC_FAV_ZIP, temp);

			GetDlgItemText(parent, IDC_CITY, temp, 100);
			SetDlgItemText(hwnd, IDC_FAV_CITY, temp);
			
			GetDlgItemText(parent, IDC_STATE, temp, 100);
			SetupStateBox(hwnd, IDC_FAV_STATE, temp);

			GetDlgItemText(parent, IDC_GLOBAL_STATION, temp, 100);
			SetDlgItemText(hwnd, IDC_FAV_STATION, temp);
			

			SetFocus(GetDlgItem(hwnd, IDC_FAV_NAME));
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		break;
		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					switch LOWORD(wParam)
					{
						case IDOK:
						{
							char temp[256] = "";
							char name[50] = "";
							char zip[15] = "";
							char city[50] = "";
							char state[5] = "";
							char station[15] = "";

							if (FAV<10)
							{
								GetDlgItemText(hwnd, IDC_FAV_NAME, name, 50);
								GetDlgItemText(hwnd, IDC_FAV_ZIP, zip, 15);
								GetDlgItemText(hwnd, IDC_FAV_CITY, city, 50);
								GetDlgItemText(hwnd, IDC_FAV_STATE, state, 5);
								GetDlgItemText(hwnd, IDC_FAV_STATION, station, 15);

								sprintf(temp, "Favorite%d", FAV);
								if (strlen(name))
								{
									WritePrivateProfileString(szAppName, temp, name, ini);
									AppendMenu(FavPopup, MF_ENABLED | MF_STRING, 200+FAV, name);
								}
								else
								{
									MessageBox(hMainWnd, "Please specify a name that will appear in the popup menu.", szAppName, MB);
									break;
								}

								sprintf(temp, "FavoriteZip%d", FAV);
								WritePrivateProfileString(szAppName, temp, zip, ini);

								sprintf(temp, "FavoriteCity%d", FAV);
								WritePrivateProfileString(szAppName, temp, city, ini);

								sprintf(temp, "FavoriteState%d", FAV);
								WritePrivateProfileString(szAppName, temp, state, ini);

								sprintf(temp, "FavoriteStation%d", FAV);
								WritePrivateProfileString(szAppName, temp, station, ini);
								
								FAV++;
							}
							else
							{
								MessageBox(hMainWnd, "You can only have 10 Favorite Cities. If this is a problem, e-mail mrjukes@purdue.edu and let me know how many you would like.", szAppName, MB);
							}
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
	}
	return FALSE;
}

BOOL CALLBACK ReportDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			char buffer[1024] = "";
			char location[256] = "";

			switch (USE_METHOD)
			{
				case 0: // Zipcode
				{
					sprintf(location, "Zip Code %s", ZIP_CODE);
				}
				break;
				case 1: // City/State
				{
					sprintf(location, "%s, %s", CITY, STATE);
				}
				break;
				case 2: // Global Station
				{
					sprintf(location, "Global Station %s", STATION);
				}
				break;
			}

			sprintf(buffer, "Current Weather Conditions For:\r\n%s\r\n\r\n", location);
			strcat(buffer, ReportCondition("Temperature"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Conditions"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Wind"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Humidity"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Pressure"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Visibility"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("DewPoint"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Sunrise"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Sunset"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Moonrise"));
			strcat(buffer, "\r\n");
			strcat(buffer, ReportCondition("Moonset"));
							 
			SetDlgItemText(hwnd, IDC_REPORT, buffer);
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		break;
		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					switch LOWORD(wParam)
					{
						case IDOK:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
	}
	return FALSE;
}

BOOL CALLBACK HelpDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			char help[512] = "";
			switch (CURRENT_HELP)
			{
				case IDC_THEME_FILE:	sprintf(help, "This is the name of the theme file."); break;
				case IDC_LOAD_THEME:	sprintf(help, "Click this button to load the theme file that is specified in the theme edit box."); break;
				case IDC_EXPORT_THEME:	sprintf(help, "Click this button to save the current settings to the theme file specified in the theme edit box."); break;
				case IDC_TIMER:			sprintf(help, "This is the amount of time that LSWeather will wait in between checking the weather."); break;
				case IDC_DISPLAY_TEMPERATURE:
				case IDC_DISPLAY_PRESSURE:
				case IDC_DISPLAY_HUMIDITY:
				case IDC_DISPLAY_DEWPOINT:
				case IDC_DISPLAY_VISIBILITY:
				case IDC_DISPLAY_WIND:
				case IDC_DISPLAY_SUNRISE:
				case IDC_DISPLAY_SUNSET:
				case IDC_DISPLAY_MOONRISE:
				case IDC_DISPLAY_MOONSET: 
				case IDC_CONDITIONS_SHOW_TEXT: 
				case IDC_CONDITIONS_SHOW_BMP: 
				case IDC_USE_ZIPCODE:
				case IDC_USE_CITY_STATE:
				case IDC_USE_GLOBAL_STATION: sprintf(help, "Depressed = Visibile\r\nUnpressed = Hidden"); break;
				
				case IDC_TEMPERATURE_FORMAT:	sprintf(help, "Valid Variables: %%T[fck] %%d\r\n\r\nExamples:\r\nTemp: %%Tf%%dF\r\nT: %%Tc%%dC\r\n%%Tk%%dK\r\nTemp: %%T%%dF"); break;
				case IDC_PRESSURE_FORMAT:		sprintf(help, "Valid Variables: %%P[ih]\r\n\r\nExamples:\r\nPres: %%Pi inches\r\nPres: %%Ph hPa\r\nP: %%P in."); break;
				case IDC_HUMIDITY_FORMAT:		sprintf(help, "Valid Variables: %%H\r\n\r\nExamples:\r\nHum: %%H%\r\nH: %%H %"); break;
				case IDC_DEWPOINT_FORMAT:		sprintf(help, "Valid Variables: %%D[fck] %%d\r\n\r\nExamples:\r\nDew: %%Tf%%dF\r\nDew: %%Tc%%dC\r\nDew: %%Tk%%dK\r\nDew: %%T%%dF"); break;
				case IDC_VISIBILITY_FORMAT:		sprintf(help, "Valid Variables: %%V[mk]\r\n\r\nExamples:\r\nVis: %%Vm miles\r\nVis: %%Vk km\r\nVis: %%V miles"); break;
				case IDC_WIND_FORMAT:			sprintf(help, "Valid Variables: %%W[sd]\r\n\r\nExamples:\r\n%%Wd at %%Ws\r\nWind: %%Ws\r\nWind Direction: %%Wd"); break;
				case IDC_SUNRISE_FORMAT:		sprintf(help, "Valid Variables: %%MS[hmwz]\r\n\r\nExamples:\r\n%%MSh:%%MSm %%MSw (%%MSz)\r\n%%MSh:%%MSm%%MSw"); break;
				case IDC_SUNSET_FORMAT:			sprintf(help, "Valid Variables: %%SS[hmwz]\r\n\r\nExamples:\r\n%%SSh:%%SSm %%SSw (%%SSz)\r\n%%SSh:%%SSm%%SSw"); break;
				case IDC_MOONRISE_FORMAT:		sprintf(help, "Valid Variables: %%MS[hmwz]\r\n\r\nExamples:\r\n%%MSh:%%MSm %%MSw (%%MSz)\r\n%%MSh:%%MSm%%MSw"); break;
				case IDC_MOONSET_FORMAT:		sprintf(help, "Valid Variables: %%MS[hmwz]\r\n\r\nExamples:\r\n%%MSh:%%MSm %%MSw (%%MSz)\r\n%%MSh:%%MSm%%MSw"); break;
				case IDC_CONDITIONS_FORMAT:		sprintf(help, "Valid Variables: %%C\r\n\r\nExamples:\r\n%%C\r\nCond: %%C"); break;

				case IDC_TEMPERATURE_X:
				case IDC_PRESSURE_X:
				case IDC_HUMIDITY_X:
				case IDC_DEWPOINT_X:
				case IDC_VISIBILITY_X:
				case IDC_WIND_X:
				case IDC_SUNRISE_X:
				case IDC_SUNSET_X:
				case IDC_MOONRISE_X:
				case IDC_MOONSET_X:
				case IDC_CONDITIONS_TEXT_X:
				case IDC_CONDITIONS_BMP_X: sprintf(help, "The X-Coordinate where LSWeather will put the upper left corner of the cooresponding value."); break;

				case IDC_TEMPERATURE_Y:
				case IDC_PRESSURE_Y:
				case IDC_HUMIDITY_Y:
				case IDC_DEWPOINT_Y:
				case IDC_VISIBILITY_Y:
				case IDC_WIND_Y:
				case IDC_SUNRISE_Y:
				case IDC_SUNSET_Y:
				case IDC_MOONRISE_Y:
				case IDC_MOONSET_Y:
				case IDC_CONDITIONS_TEXT_Y:
				case IDC_CONDITIONS_BMP_Y: sprintf(help, "The Y-Coordinate where LSWeather will put the upper left corner of the cooresponding value."); break;

				case IDC_FONT:				sprintf(help, "The font face name that you would like LSWeather to use.\r\n\r\nExamples:\r\nArial, System, Tahoma, Times New Roman, etc..."); break;
				case IDC_FONT_SIZE:			sprintf(help, "The size of the font that you would like LSWeather to use.\r\n\r\nExamples:\r\n8,10,12,14,16, etc..."); break;
				case IDC_FONT_NORMAL_R:		sprintf(help, "The red value of the font during normal LSWeather operation.\r\nValid Range: 0-255"); break;
				case IDC_FONT_NORMAL_G:		sprintf(help, "The green value of the font during normal LSWeather operation.\r\nValid Range: 0-255"); break;
				case IDC_FONT_NORMAL_B:		sprintf(help, "The blue value of the font during normal LSWeather operation.\r\nValid Range: 0-255"); break;
				case IDC_FONT_CHECKING_R:	sprintf(help, "The red value of the font while LSWeather is updating its current conditions.\r\nValid Range: 0-255"); break;
				case IDC_FONT_CHECKING_G:	sprintf(help, "The green value of the font while LSWeather is updating its current conditions.\r\nValid Range: 0-255"); break;
				case IDC_FONT_CHECKING_B:	sprintf(help, "The blue value of the font while LSWeather is updating its current conditions.\r\nValid Range: 0-255"); break;
					
				case IDC_CONDITIONS_BMP_WIDTH: sprintf(help, "The width of each bitmap used for displaying weather conditions."); break;
				case IDC_CONDITIONS_BMP_HEIGHT: sprintf(help, "The height of each bitmap used for displaying weather conditions."); break;

				case IDC_IMAGE_DIR: sprintf(help, "The directory where all the LSWeather images are located."); break;
				case IDC_BG_IMAGE:  sprintf(help, "The bitmap that is to be displayed in the background."); break;

				case IDC_CONDITION_LIST:	sprintf(help, "This is a list of all the possible weather conditions that LSWeather will display bitmap images for.  The left column is how the weather condition would show up on wunderground.com. The middle column is the bitmap to use when the condition is found. The right column is used to replace the condition text displayed."); break;
				case IDC_BITMAP_NEW:		sprintf(help, "Click this button to add a new weather condition to the list."); break;
				case IDC_BITMAP_REMOVE:		sprintf(help, "Click this button to remove the currently selected weather condition from the list."); break;

				case IDC_ZIPCODE:	sprintf(help, "Specify your zip code here."); break;
				case IDC_CITY:		sprintf(help, "Specify your city name here."); break;
				case IDC_STATE:		sprintf(help, "Pick which state you would like to use here."); break;
				case IDC_GLOBAL_STATION:	sprintf(help, "Specify your global station here. This is mostly for people outside of the USA.\r\nTo find your global station, you will have to visit http://www.wunderground.com"); break;
				case IDC_ADD_TO_FAVORITES:	sprintf(help, "Click this button to add an entry to your Favorites Menu. For now the only way to delete a favorite item is to edit your modules.ini with notepad. You can only have 10 favorites."); break;

				case IDC_WINDOW_WIDTH: sprintf(help, "Specify the width of the window that you would like LSWeather to use.  This is for LoadModule only."); break;
				case IDC_WINDOW_HEIGHT: sprintf(help, "Specify the height of the window that you would like LSWeather to use.  This is for LoadModule only."); break;

				case IDC_DOUBLE_CLICK: sprintf(help, "Here is where you choose what the default double-click action is. It is pretty straight foward I believe."); break;
				case IDC_THEME_BROWSE: sprintf(help, "Click this button to browse for a .thm file.  Once you find it click the load button to load it to be edited or used."); break;

				default:				sprintf(help, "Help is not available for this control."); break;
			}
			SetDlgItemText(hwnd, IDC_HELPME, help);
			return TRUE;
		}
		return TRUE;

		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		break;

		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					switch LOWORD(wParam)
					{
						case IDOK:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
		break;
	}
	return FALSE;
}

BOOL CALLBACK AboutDialogProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			char buffer[512] = "";

			sprintf(buffer, "LSWeather B4\r\n\r\nWritten By: MrJukes\r\n\r\nTheme By: Tritian\r\n\r\nSpecial thanks to Tritian, [TheBORG], phejom, Visigth, GeekMaster, Floach, the guys at http://www.wunderground.com, and Steve Irwin (that guy is nuts by-crocky).\r\n\r\nE-mail any question/comments/complaints/bugs to mrjukes@purdue.edu.\r\n\r\nHave Fun,\r\n\t- MrJukes");
			SetDlgItemText(hwnd, IDC_ABOUT_TEXT, buffer);
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		break;
		case WM_COMMAND:
		{
			switch HIWORD(wParam)
			{
				case BN_CLICKED:
				{
					switch LOWORD(wParam)
					{
						case IDOK:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
	}
	return FALSE;
}

int FTOC(int F)
{
	return (((F-32) * 5) / 9);
}

int FTOK(int F)
{
	return FTOC(F) + 273;
}

int MTOK(int M)
{
	return (int)(M * 1.6093);
}

int ITOH(int I)
{
	return (int)(I * 32.8);
}

void SetActiveCity(int x)
{
	int y=0;
	char temp[25] = "";
	
	sprintf(temp, "FavoriteZip%d", x);
	GetPrivateProfileString(szAppName, temp, "", ZIP_CODE, 6, ini);
	sprintf(temp, "FavoriteCity%d", x);
	GetPrivateProfileString(szAppName, temp, "", CITY, 50, ini);
	sprintf(temp, "FavoriteState%d", x);
	GetPrivateProfileString(szAppName, temp, "", STATE, 5, ini);
	sprintf(temp, "FavoriteStation%d", x);
	GetPrivateProfileString(szAppName, temp, "", STATION, 15, ini);

	WritePrivateProfileString(szAppName, "ZipCode", ZIP_CODE, ini);
	WritePrivateProfileString(szAppName, "City", CITY, ini);
	WritePrivateProfileString(szAppName, "State", STATE, ini);
	WritePrivateProfileString(szAppName, "GlobalStation", STATION, ini);

	for (y=0; y<10; y++)
	{
		(y == x)? CheckMenuItem(FavPopup, 200 + x, MF_CHECKED) : CheckMenuItem(FavPopup, 200 + y, MF_UNCHECKED);
	}

	thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetWeather, (LPVOID)NULL, 0, &threadID);
}

BOOL GetValue(const char* pointer, char* temp, char* delim)
{
	__try 
	{
		char* start;
		char* end;

		start = strstr(pointer, "<td><b>");
		if (start)
		{
			start += 7;
			end = strstr(start, delim);
			strncpy(temp, start, (int)(end-start));
		} else return FALSE;
		
		return TRUE;
	}__except(1) { ERR=TRUE; return FALSE; }
}

void GetWind(const char* pointer, char* temp)
{
	__try
	{
		char type[45] = "";
		char mph[5] = "";
		char* start;
		char* end;

		start = strstr(pointer, "<td><b>");
		start += 7;
		end = strstr(start, "<");
		strncpy(type, start, (int)(end-start));

		if (_stricmp(type, "calm"))
		{
			start = end + 11;
			end = strstr(start, "<");
			strncpy(mph, start, (int)(end-start));
			sprintf(temp, "%s at %s mph", type, mph);
		}
		else sprintf(temp, "Calm");
	}__except(1) { ERR=TRUE; }
}

void ClearAllValues()
{
	__try 
	{
		memset(&CURRENT_CONDITIONS, 0, sizeof(CURRENT_CONDITIONS));
		memset(&CURRENT_WIND, 0, sizeof(CURRENT_WIND));
		memset(&CURRENT_SUNRISE, 0, sizeof(CURRENT_SUNRISE));
		memset(&CURRENT_SUNSET, 0, sizeof(CURRENT_SUNSET));
		memset(&CURRENT_MOONRISE, 0, sizeof(CURRENT_MOONRISE));
		memset(&CURRENT_MOONSET, 0, sizeof(CURRENT_MOONSET));
		CURRENT_TEMP		= 0;
		CURRENT_HUMIDITY	= 0;
		CURRENT_DEWPOINT	= 0;
		CURRENT_PRESSURE	= 0;
		CURRENT_VISIBILITY	= 0;
	}__except(1) { ERR=TRUE; }
}

void SetupBitmapListView(HWND hwnd)
{
	LVCOLUMN col;
	char buffer[2048] = "";
	char thmfile[MAX_PATH] = "";
	HWND lv = GetDlgItem(hwnd, IDC_CONDITION_LIST);

	GetDlgItemText(hwnd, IDC_THEME_FILE, thmfile, MAX_PATH);
	if (!lv) return;

	ListView_DeleteAllItems(lv);

	if (!LOADED)
	{
		col.cx = 90;
		col.pszText = "Conditions";
		col.iSubItem = 0;
		col.mask = LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
		ListView_InsertColumn(lv, 0, &col);

		col.cx = 90;
		col.pszText = "Images";
		col.iSubItem = 1;
		ListView_InsertColumn(lv, 1, &col);

		col.cx = 90;
		col.pszText = "Replace Text";
		col.iSubItem = 2;
		ListView_InsertColumn(lv, 2, &col);
	}

	GetPrivateProfileSection("Conditions", buffer, 2047, thmfile);

	if (buffer[0])
	{
		char* p = buffer;

		while (p[0] != '\0')
		{
			if (_strnicmp(p, "DisplayText=", 12) &&
				_strnicmp(p, "Format=", 7) &&
				_strnicmp(p, "TextX=", 6) &&
				_strnicmp(p, "TextY=", 6) &&
				_strnicmp(p, "DisplayBmp=", 11) &&
				_strnicmp(p, "BmpX=", 5) &&
				_strnicmp(p, "BmpY=", 5) &&
				_strnicmp(p, "BmpWidth=", 9) &&
				_strnicmp(p, "BmpHeight=", 10)&&
				!strstr(p, "Text Replacement"))
			{
				char temp[256] = "";
				char temp2[256] = "";
				LVITEM item;
				int iItem = ListView_GetItemCount(lv);
				
				strcpy(temp, p);
				item.mask = LVIF_TEXT;
				
				item.iItem = iItem;
				item.iSubItem = 0;
				item.pszText = strtok(temp, "=");
				ListView_InsertItem(lv, &item);

				strcpy(temp2, temp);

				item.iItem = iItem;
				item.iSubItem = 1;
				item.pszText = strtok(NULL, "");
				ListView_SetItem(lv, &item);

				sprintf(temp, "%s Text Replacement", temp2);
				GetPrivateProfileString("Conditions", temp, "", temp2, 256, thmfile);

				item.iItem = iItem;
				item.iSubItem = 2;
				item.pszText = temp2;
				ListView_SetItem(lv, &item);
			}

			p += strlen(p) + 1;
		}
	}
	
}

void SetConfigDlgValues(HWND hwnd)
{
	char thmfile[MAX_PATH] = "";
	char temp[256] = "";
	int num=0;
	
	GetDlgItemText(hwnd, IDC_THEME_FILE, thmfile, MAX_PATH);
	SetDlgItemInt(hwnd, IDC_TIMER, GetPrivateProfileInt(szAppName, "Timer", 1, ini), FALSE);

	// Display
	SetDlgConfigDisplayValue(hwnd, "Temperature", IDC_DISPLAY_TEMPERATURE, IDC_TEMPERATURE_FORMAT, IDC_TEMPERATURE_X, IDC_TEMPERATURE_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Pressure", IDC_DISPLAY_PRESSURE, IDC_PRESSURE_FORMAT, IDC_PRESSURE_X, IDC_PRESSURE_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Humidity", IDC_DISPLAY_HUMIDITY, IDC_HUMIDITY_FORMAT, IDC_HUMIDITY_X, IDC_HUMIDITY_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "DewPoint", IDC_DISPLAY_DEWPOINT, IDC_DEWPOINT_FORMAT, IDC_DEWPOINT_X, IDC_DEWPOINT_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Visibility", IDC_DISPLAY_VISIBILITY, IDC_VISIBILITY_FORMAT, IDC_VISIBILITY_X, IDC_VISIBILITY_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Wind", IDC_DISPLAY_WIND, IDC_WIND_FORMAT, IDC_WIND_X, IDC_WIND_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Sunrise", IDC_DISPLAY_SUNRISE, IDC_SUNRISE_FORMAT, IDC_SUNRISE_X, IDC_SUNRISE_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Sunset", IDC_DISPLAY_SUNSET, IDC_SUNSET_FORMAT, IDC_SUNSET_X, IDC_SUNSET_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Moonrise", IDC_DISPLAY_MOONRISE, IDC_MOONRISE_FORMAT, IDC_MOONRISE_X, IDC_MOONRISE_Y, thmfile);
	SetDlgConfigDisplayValue(hwnd, "Moonset", IDC_DISPLAY_MOONSET, IDC_MOONSET_FORMAT, IDC_MOONSET_X, IDC_MOONSET_Y, thmfile);

	// Font
	GetPrivateProfileString("Main", "Font", "System", temp, 256, thmfile);
	SetDlgItemText(hwnd, IDC_FONT, temp);
	SetDlgItemInt(hwnd, IDC_FONT_SIZE, GetPrivateProfileInt("Main", "FontSize", 12, thmfile), FALSE);
	GetPrivateProfileString("Main", "FontRGB", "255 255 255", temp, 256, thmfile);
	SetDlgItemInt(hwnd, IDC_FONT_NORMAL_R, atoi(strtok(temp, " ")), FALSE);
	SetDlgItemInt(hwnd, IDC_FONT_NORMAL_G, atoi(strtok(NULL, " ")), FALSE);
	SetDlgItemInt(hwnd, IDC_FONT_NORMAL_B, atoi(strtok(NULL, " ")), FALSE);
	GetPrivateProfileString("Main", "FontCheckRGB", "255 0 0", temp, 256, thmfile);
	SetDlgItemInt(hwnd, IDC_FONT_CHECKING_R, atoi(strtok(temp, " ")), FALSE);
	SetDlgItemInt(hwnd, IDC_FONT_CHECKING_G, atoi(strtok(NULL, " ")), FALSE);
	SetDlgItemInt(hwnd, IDC_FONT_CHECKING_B, atoi(strtok(NULL, " ")), FALSE);

	// Weather Conditions
	(GetPrivateProfileInt("Conditions", "DisplayText", 0, thmfile))? SendDlgItemMessage(hwnd, IDC_CONDITIONS_SHOW_TEXT, BM_SETCHECK, (WPARAM)BST_CHECKED, 0) : SendDlgItemMessage(hwnd, IDC_CONDITIONS_SHOW_TEXT, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	SetDlgConfigDisplayValue(hwnd, "Conditions", 0, IDC_CONDITIONS_FORMAT, IDC_CONDITIONS_TEXT_X, IDC_CONDITIONS_TEXT_Y, thmfile);
	(GetPrivateProfileInt("Conditions", "DisplayBmp", 0, thmfile))? SendDlgItemMessage(hwnd, IDC_CONDITIONS_SHOW_BMP, BM_SETCHECK, (WPARAM)BST_CHECKED, 0) : SendDlgItemMessage(hwnd, IDC_CONDITIONS_SHOW_BMP, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	SetDlgItemInt(hwnd, IDC_CONDITIONS_BMP_X, GetPrivateProfileInt("Conditions", "BmpX", 0, thmfile), TRUE);
	SetDlgItemInt(hwnd, IDC_CONDITIONS_BMP_Y, GetPrivateProfileInt("Conditions", "BmpY", 0, thmfile), TRUE);
	SetDlgItemInt(hwnd, IDC_CONDITIONS_BMP_WIDTH, GetPrivateProfileInt("Conditions", "BmpWidth", 0, thmfile), TRUE);
	SetDlgItemInt(hwnd, IDC_CONDITIONS_BMP_HEIGHT, GetPrivateProfileInt("Conditions", "BmpHeight", 0, thmfile), TRUE);

	// General
	GetPrivateProfileString("Main", "ImageDir", "", temp, 256, thmfile);
	SetDlgItemText(hwnd, IDC_IMAGE_DIR, temp);
	GetPrivateProfileString("Main", "BackGroundPix", "", temp, 256, thmfile);
	SetDlgItemText(hwnd, IDC_BG_IMAGE, temp);
	SetDlgItemInt(hwnd, IDC_WINDOW_WIDTH, GetPrivateProfileInt("Main", "Width", 64, thmfile), TRUE);
	SetDlgItemInt(hwnd, IDC_WINDOW_HEIGHT, GetPrivateProfileInt("Main", "Height", 64, thmfile), TRUE);
	if (!LOADED)
	{
		SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_ADDSTRING, (WPARAM)0, (LPARAM)"Launch Webpage");
		SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_ADDSTRING, (WPARAM)0, (LPARAM)"Change Settings");
		SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_ADDSTRING, (WPARAM)0, (LPARAM)"Report Conditions");
		SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_ADDSTRING, (WPARAM)0, (LPARAM)"Update");
		SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCSTR)CURRENT_DOUBLE_CLICK);
	}

	// Location
	num = GetPrivateProfileInt(szAppName, "UseMethod", 0, ini);
	
	SendDlgItemMessage(hwnd, IDC_USE_ZIPCODE, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	SendDlgItemMessage(hwnd, IDC_USE_CITY_STATE, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	SendDlgItemMessage(hwnd, IDC_USE_GLOBAL_STATION, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	if (num == 0) // Zip Code
		SendDlgItemMessage(hwnd, IDC_USE_ZIPCODE, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
	else if (num == 1) // City/State
		SendDlgItemMessage(hwnd, IDC_USE_CITY_STATE, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);
	else if (num == 2) // Global Station
		SendDlgItemMessage(hwnd, IDC_USE_GLOBAL_STATION, BM_SETCHECK, (WPARAM)BST_CHECKED, 0);

	SetDlgItemInt(hwnd, IDC_ZIPCODE, GetPrivateProfileInt(szAppName, "ZipCode", 0, ini), FALSE);
	SetDlgItemText(hwnd, IDC_CITY, CITY);	
	SetDlgItemText(hwnd, IDC_GLOBAL_STATION, STATION);

	// Finish it
	SetFocus(GetDlgItem(hwnd, IDC_THEME_FILE));
	SendMessage(GetDlgItem(hwnd, IDC_THEME_FILE), EM_SETSEL, 0, -1);	
}

void SetDlgConfigDisplayValue(HWND hwnd, char* section, DWORD button, DWORD format, DWORD X, DWORD Y, char* thmfile)
{
	char temp[256] = "";

	sprintf(temp, "Display%s", section);
	(GetPrivateProfileInt("Main", temp, 0, thmfile))? SendDlgItemMessage(hwnd, button, BM_SETCHECK, (WPARAM)BST_CHECKED, 0) : SendDlgItemMessage(hwnd, button, BM_SETCHECK, (WPARAM)BST_UNCHECKED, 0);
	GetPrivateProfileString(section, "Format", "", temp, 256, thmfile);
	SetDlgItemText(hwnd, format, temp);
	SetDlgItemInt(hwnd, X, GetPrivateProfileInt(section, "TextX", 0, thmfile), TRUE);
	SetDlgItemInt(hwnd, Y, GetPrivateProfileInt(section, "TextY", 0, thmfile), TRUE);
}

void WritePrivateProfileInt(char* appname, char* keyname, int val, char* file)
{
	char temp[256] = "";
	sprintf(temp, "%d", val);
	WritePrivateProfileString(appname, keyname, temp, file);
}

void WritePrivateProfileDlgString(char* appname, char* keyname, HWND hwnd, DWORD item, char* file)
{
	char temp[256] = "";
	GetDlgItemText(hwnd, item, temp, 256);
	WritePrivateProfileString(appname, keyname, temp, file);
}

int WritePrivateProfileDlgInt(char* appname, char* keyname, HWND hwnd, DWORD item, char* file)
{
	char temp[256] = "";
	int val = GetDlgItemInt(hwnd, item, NULL, TRUE);
	sprintf(temp, "%d", val);
	WritePrivateProfileString(appname, keyname, temp, file);
	return val;
}

void SaveDlgConfigValues(HWND hwnd)
{
	char temp[256] = "";
	char thmfile[256] = "";

	GetDlgItemText(hwnd, IDC_THEME_FILE, thm, MAX_PATH);
	WritePrivateProfileString(szAppName, "ThemeFile", thm, ini);
	TIMER = GetDlgItemInt(hwnd, IDC_TIMER, NULL, FALSE) * 60000;
	WritePrivateProfileInt(szAppName, "Timer", TIMER/60000, ini);
	
	// Display
	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_TEMPERATURE), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayTemperature", (DISPLAY_TEMPERATURE = 1), thm) : WritePrivateProfileInt("Main", "DisplayTemperature", (DISPLAY_TEMPERATURE = 0), thm);
	WritePrivateProfileDlgString("Temperature", "Format", hwnd, IDC_TEMPERATURE_FORMAT, thm);
	WritePrivateProfileDlgInt("Temperature", "TextX", hwnd, IDC_TEMPERATURE_X, thm);
	WritePrivateProfileDlgInt("Temperature", "TextY", hwnd, IDC_TEMPERATURE_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_PRESSURE), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayPressure", (DISPLAY_PRESSURE = 1), thm) : WritePrivateProfileInt("Main", "DisplayPressure", (DISPLAY_PRESSURE = 0), thm);
	WritePrivateProfileDlgString("Pressure", "Format", hwnd, IDC_PRESSURE_FORMAT, thm);
	WritePrivateProfileDlgInt("Pressure", "TextX", hwnd, IDC_PRESSURE_X, thm);
	WritePrivateProfileDlgInt("Pressure", "TextY", hwnd, IDC_PRESSURE_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_HUMIDITY), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayHumidity", (DISPLAY_HUMIDITY = 1), thm) : WritePrivateProfileInt("Main", "DisplayHumidity", (DISPLAY_HUMIDITY = 0), thm);
	WritePrivateProfileDlgString("Humidity", "Format", hwnd, IDC_HUMIDITY_FORMAT, thm);
	WritePrivateProfileDlgInt("Humidity", "TextX", hwnd, IDC_HUMIDITY_X, thm);
	WritePrivateProfileDlgInt("Humidity", "TextY", hwnd, IDC_HUMIDITY_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_DEWPOINT), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayDewPoint", (DISPLAY_DEWPOINT = 1), thm) : WritePrivateProfileInt("Main", "DisplayDewPoint", (DISPLAY_DEWPOINT = 0), thm);
	WritePrivateProfileDlgString("DewPoint", "Format", hwnd, IDC_DEWPOINT_FORMAT, thm);
	WritePrivateProfileDlgInt("DewPoint", "TextX", hwnd, IDC_DEWPOINT_X, thm);
	WritePrivateProfileDlgInt("DewPoint", "TextY", hwnd, IDC_DEWPOINT_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_VISIBILITY), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayVisibility", (DISPLAY_VISIBILITY = 1), thm) : WritePrivateProfileInt("Main", "DisplayVisibility", (DISPLAY_VISIBILITY = 0), thm);
	WritePrivateProfileDlgString("Visibility", "Format", hwnd, IDC_VISIBILITY_FORMAT, thm);
	WritePrivateProfileDlgInt("Visibility", "TextX", hwnd, IDC_VISIBILITY_X, thm);
	WritePrivateProfileDlgInt("Visibility", "TextY", hwnd, IDC_VISIBILITY_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_WIND), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayWind", (DISPLAY_WIND = 1), thm) : WritePrivateProfileInt("Main", "DisplayWind", (DISPLAY_WIND = 0), thm);
	WritePrivateProfileDlgString("Wind", "Format", hwnd, IDC_WIND_FORMAT, thm);
	WritePrivateProfileDlgInt("Wind", "TextX", hwnd, IDC_WIND_X, thm);
	WritePrivateProfileDlgInt("Wind", "TextY", hwnd, IDC_WIND_Y, thm);
	
	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_SUNRISE), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplaySunrise", (DISPLAY_SUNRISE = 1), thm) : WritePrivateProfileInt("Main", "DisplaySunrise", (DISPLAY_SUNRISE = 0), thm);
	WritePrivateProfileDlgString("Sunrise", "Format", hwnd, IDC_SUNRISE_FORMAT, thm);
	WritePrivateProfileDlgInt("Sunrise", "TextX", hwnd, IDC_SUNRISE_X, thm);
	WritePrivateProfileDlgInt("Sunrise", "TextY", hwnd, IDC_SUNRISE_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_SUNSET), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplaySunset", (DISPLAY_SUNSET = 1), thm) : WritePrivateProfileInt("Main", "DisplaySunset", (DISPLAY_SUNSET = 0), thm);
	WritePrivateProfileDlgString("Sunset", "Format", hwnd, IDC_SUNSET_FORMAT, thm);
	WritePrivateProfileDlgInt("Sunset", "TextX", hwnd, IDC_SUNSET_X, thm);
	WritePrivateProfileDlgInt("Sunset", "TextY", hwnd, IDC_SUNSET_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_MOONRISE), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayMoonrise", (DISPLAY_MOONRISE = 1), thm) : WritePrivateProfileInt("Main", "DisplayMoonrise", (DISPLAY_MOONRISE = 0), thm);
	WritePrivateProfileDlgString("Moonrise", "Format", hwnd, IDC_MOONRISE_FORMAT, thm);
	WritePrivateProfileDlgInt("Moonrise", "TextX", hwnd, IDC_MOONRISE_X, thm);
	WritePrivateProfileDlgInt("Moonrise", "TextY", hwnd, IDC_MOONRISE_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_DISPLAY_MOONSET), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Main", "DisplayMoonset", (DISPLAY_MOONSET = 1), thm) : WritePrivateProfileInt("Main", "DisplayMoonset", (DISPLAY_MOONSET = 0), thm);
	WritePrivateProfileDlgString("Moonset", "Format", hwnd, IDC_MOONSET_FORMAT, thm);
	WritePrivateProfileDlgInt("Moonset", "TextX", hwnd, IDC_MOONSET_X, thm);
	WritePrivateProfileDlgInt("Moonset", "TextY", hwnd, IDC_MOONSET_Y, thm);

	// Font
	GetDlgItemText(hwnd, IDC_FONT, FontName, MAX_PATH);
	WritePrivateProfileString("Main", "Font", FontName, thm);
	FontSize = GetDlgItemInt(hwnd, IDC_FONT_SIZE, NULL, FALSE);
	WritePrivateProfileInt("Main", "FontSize", FontSize, thm);
	R = GetDlgItemInt(hwnd, IDC_FONT_NORMAL_R, NULL, FALSE);
	G = GetDlgItemInt(hwnd, IDC_FONT_NORMAL_G, NULL, FALSE);
	B = GetDlgItemInt(hwnd, IDC_FONT_NORMAL_B, NULL, FALSE);
	sprintf(temp, "%d %d %d", R, G, B);
	WritePrivateProfileString("Main", "FontRGB", temp, thm);

	CR = GetDlgItemInt(hwnd, IDC_FONT_CHECKING_R, NULL, FALSE);
	CG = GetDlgItemInt(hwnd, IDC_FONT_CHECKING_G, NULL, FALSE);
	CB = GetDlgItemInt(hwnd, IDC_FONT_CHECKING_B, NULL, FALSE);
	sprintf(temp, "%d %d %d", CR, CG, CB);
	WritePrivateProfileString("Main", "FontCheckRGB", temp, thm);
	
	// Weather Conditions
	(SendMessage(GetDlgItem(hwnd, IDC_CONDITIONS_SHOW_TEXT), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Conditions", "DisplayText", 1, thm) : WritePrivateProfileInt("Conditions", "DisplayText", 0, thm);
	WritePrivateProfileDlgString("Conditions", "Format", hwnd, IDC_CONDITIONS_FORMAT, thm);
	WritePrivateProfileDlgInt("Conditions", "TextX", hwnd, IDC_CONDITIONS_TEXT_X, thm);
	WritePrivateProfileDlgInt("Conditions", "TextY", hwnd, IDC_CONDITIONS_TEXT_Y, thm);

	(SendMessage(GetDlgItem(hwnd, IDC_CONDITIONS_SHOW_BMP), BM_GETCHECK, 0, 0) == BST_CHECKED)? WritePrivateProfileInt("Conditions", "DisplayBmp", 1, thm) : WritePrivateProfileInt("Conditions", "DisplayBmp", 0, thm);
	WritePrivateProfileDlgInt("Conditions", "BmpX", hwnd, IDC_CONDITIONS_BMP_X, thm);
	WritePrivateProfileDlgInt("Conditions", "BmpY", hwnd, IDC_CONDITIONS_BMP_Y, thm);
	WritePrivateProfileDlgInt("Conditions", "BmpWidth", hwnd, IDC_CONDITIONS_BMP_WIDTH, thm);
	WritePrivateProfileDlgInt("Conditions", "BmpHeight", hwnd, IDC_CONDITIONS_BMP_HEIGHT, thm);

	// General
	GetDlgItemText(hwnd, IDC_IMAGE_DIR, IMAGE_DIR, MAX_PATH);
	if (IMAGE_DIR[strlen(IMAGE_DIR)-1] != '\\') strcat(IMAGE_DIR, "\\");
	WritePrivateProfileString("Main", "ImageDir", IMAGE_DIR, thm);

	if (LOADMODULE)
	{
		WndWidth = WritePrivateProfileDlgInt("Main", "Width", hwnd, IDC_WINDOW_WIDTH, thm);	
		WndHeight = WritePrivateProfileDlgInt("Main", "Height", hwnd, IDC_WINDOW_HEIGHT, thm);
	}
	else
	{
		WndWidth = WndHeight = wndSize;
	}

	GetDlgItemText(hwnd, IDC_BG_IMAGE, temp, 256);
	WritePrivateProfileString("Main", "BackGroundPix", temp, thm);
	if (temp[0])
	{
		char bmp[256] = "";
		sprintf(bmp, "%s%s", IMAGE_DIR, temp);
		if (BGBMP) DeleteObject(BGBMP);
		BGBMP = LoadImage(Instance, bmp, IMAGE_BITMAP, WndWidth, WndHeight, LR_LOADFROMFILE);
	}

	SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_GETLBTEXT, (WPARAM)SendMessage(GetDlgItem(hwnd, IDC_DOUBLE_CLICK), CB_GETCURSEL, 0, 0), (LPARAM)(LPCSTR)CURRENT_DOUBLE_CLICK);
	WritePrivateProfileString("Main", "DoubleClick", CURRENT_DOUBLE_CLICK, thm);

	// Location
	if (SendMessage(GetDlgItem(hwnd, IDC_USE_ZIPCODE), BM_GETCHECK, 0, 0) == BST_CHECKED)
		SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_USEZIP, (LPARAM)0);
	else if (SendMessage(GetDlgItem(hwnd, IDC_USE_CITY_STATE), BM_GETCHECK, 0, 0) == BST_CHECKED)
		SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_USECITY, (LPARAM)0);
	else if (SendMessage(GetDlgItem(hwnd, IDC_USE_GLOBAL_STATION), BM_GETCHECK, 0, 0) == BST_CHECKED)
		SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_USESTATION, (LPARAM)0);

	GetDlgItemText(hwnd, IDC_ZIPCODE, ZIP_CODE, 6);
	WritePrivateProfileString(szAppName, "ZipCode", ZIP_CODE, ini);
	GetDlgItemText(hwnd, IDC_CITY, CITY, 50);
	WritePrivateProfileString(szAppName, "City", CITY, ini);
	
	SendMessage(GetDlgItem(hwnd, IDC_STATE), CB_GETLBTEXT, (WPARAM)SendMessage(GetDlgItem(hwnd, IDC_STATE), CB_GETCURSEL, 0, 0), (LPARAM)(LPCSTR)STATE);
	WritePrivateProfileString(szAppName, "State", STATE, ini);
	GetDlgItemText(hwnd, IDC_GLOBAL_STATION, STATION, 15);
	WritePrivateProfileString(szAppName, "GlobalStation", STATION, ini);
}

void SetupStateBox(HWND hwnd, DWORD cbox, char* st)
{
	HWND cb = GetDlgItem(hwnd, cbox);

	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"AL");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"AK");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"AZ");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"AR");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"CA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"CO");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"CT");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"DE");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"DC");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"FL");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"GA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"HI");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"ID");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"IL");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"IN");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"IA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"KS");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"KY");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"LA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"ME");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MD");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MI");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MN");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MS");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MO");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"MT");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NE");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NV");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NH");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NJ");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NM");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NY");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"NC");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"ND");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"OH");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"OK");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"OR");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"PA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"RI");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"SC");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"SD");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"TN");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"TX");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"UT");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"VT");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"VA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"WA");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"WV");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"WI");
	SendMessage(cb, CB_ADDSTRING, (WPARAM)0, (LPARAM)"WY");

	SendMessage(cb, CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCSTR)st);
}

void ParseFormat(char* in, char* out)
{
	__try {
	int CURRENT_VALUE=0;
	BOOL MOON=FALSE;
	char temp[256] = "";
	int x=0, y=0;

	for (x=0; in[x]; x++)
	{
		switch (in[x])
		{
			case '%':
			{
				x++;

				switch (in[x])
				{
					case 'd': sprintf(temp, "�"); break;

					case 'D': CURRENT_VALUE = CURRENT_DEWPOINT;
					case 't':
					case 'T':
					{
						if (toupper(in[x]) == 'T') CURRENT_VALUE = CURRENT_TEMP;
						x++;
						
						switch (toupper(in[x]))
						{
							default: x--;
							case 'F': sprintf(temp, "%d", CURRENT_VALUE); break;
							case 'C': sprintf(temp, "%d", FTOC(CURRENT_VALUE)); break;
							case 'K': sprintf(temp, "%d", FTOK(CURRENT_VALUE)); break;
						}
					}
					break;

					case 'p':
					case 'P':
					{
						x++;
						
						switch (toupper(in[x]))
						{
							default: x--;
							case 'I': sprintf(temp, "%d", CURRENT_PRESSURE); break;
							case 'H': sprintf(temp, "%d", ITOH(CURRENT_PRESSURE)); break;
						}
					}
					break;

					case 'h':
					case 'H': sprintf(temp, "%d", CURRENT_HUMIDITY); break;

					case 'c':
					case 'C': sprintf(temp, "%s", CURRENT_CONDITIONS); break;

					case 'v':
					case 'V':
					{
						x++;
						
						switch (toupper(in[x]))
						{
							default: x--;
							case 'M': sprintf(temp, "%d", CURRENT_VISIBILITY); break;
							case 'K': sprintf(temp, "%d", MTOK(CURRENT_VISIBILITY)); break;
						}
					}
					break;

					case 'w':
					case 'W':
					{
						x++;
						strcpy(temp, CURRENT_WIND);

						switch(toupper(in[x]))
						{
							default: x--;
							case 'M':
							{
								if (_strnicmp(temp, "Calm", 4))
								{
									char* s = strtok(temp, " ");
									strtok(NULL, " ");
									s = strtok(NULL, " ");

									if (s) sprintf(temp, "%d", atoi(s));
									else sprintf(temp, "0");
								} 
								else sprintf(temp, "0");
							}
							break;

							case 'K':
							{
								if (_strnicmp(temp, "Calm", 4))
								{
									char* s = strtok(temp, " ");
									strtok(NULL, " ");
									s = strtok(NULL, " ");

									if (s) sprintf(temp, "%d", MTOK(atoi(s)));
									else sprintf(temp, "0");
								} 
								else sprintf(temp, "0");
							}
							break;

							case 'D':
							{
								char* d = strtok(temp, " ");
								if (d) sprintf(temp, "%s", d);
								else sprintf(temp, "NA");
							}
							break;
						}
					}
					break;

					case 'm':
					case 'M': MOON=TRUE;
					case 's':
					case 'S':
					{
						if (toupper(in[x]) == 'S') MOON=FALSE;
						x++;
						switch (toupper(in[x]))
						{
							default:
							case 'R': (MOON)? strcpy(temp, CURRENT_MOONRISE) : strcpy(temp, CURRENT_SUNRISE);
							case 'S':
							{
								if (toupper(in[x]) == 'S') (MOON)? strcpy(temp, CURRENT_MOONSET) : strcpy(temp, CURRENT_SUNSET);
								
								x++;
								switch (toupper(in[x]))
								{
									default: x--;
									case 'H':
									{
										char* hour = strtok(temp, ":");
										if (hour) sprintf(temp, "%d", atoi(hour));
										else sprintf(temp, "0");
									}
									break;

									case 'M':
									{
										char* min = strtok(temp, ":");
										min = strtok(NULL, " ");

										if (min) 
										{
											int m = atoi(min);
											if (m < 10) sprintf(temp, "0%d", m);
											else sprintf(temp, "%d", m);
										}
										else sprintf(temp, "00");
									}
									break;

									case 'W':
									{
										if (strstr(temp, "AM")) sprintf(temp, "AM");
										else if (strstr(temp, "PM")) sprintf(temp, "PM");
										else sprintf(temp, "NA");
									}
									break;

									case 'Z':
									{
										char* zone = strtok(temp, "(");
										zone = strtok(NULL, ")");
										sprintf(temp, "%s", zone);
									}
									break;
								}
							}
							break;
						}
					}
					break;

					default:
					{
						x--;
						sprintf(temp, "%c", in[x]);
					}
					break;
				}

				strcat(out, temp);
				y = strlen(out);
			}
			break;

			default:
			{
				out[y] = in[x];
				y++;
			}
		}
	}
	}__except(1) { ERR=TRUE; }
}

BOOL ConstructURL(char* FULL_URL)
{
	__try {
	BOOL GO=TRUE;

	sprintf(FULL_URL, "http://www.wunderground.com/");
	
	if (USE_METHOD == 0) 
	{
		if (ZIP_CODE[0])
		{
			strcat(FULL_URL, "US/");
			strcat(FULL_URL, ZIP_CODE);
		}
		else GO=FALSE;
	}
	else if (USE_METHOD == 1)
	{
		if (STATE[0] && CITY[0])
		{
			char temp[75] = "";
			strcpy(temp, CITY);

			strcat(FULL_URL, "US/");
			strcat(FULL_URL, STATE);
					
			while (strstr(temp, " "))
			{
				temp[strcspn(temp, " ")] = '_';
			}

			strcat(FULL_URL, "/");
			strcat(FULL_URL, temp);
		}
		else GO=FALSE;
	}
	else if (USE_METHOD == 2)
	{
		if (STATION[0])
		{
			strcat(FULL_URL, "global/stations/");
			strcat(FULL_URL, STATION);
		}
		else GO=FALSE;
	}
	else GO=FALSE;

	if (GO) strcat(FULL_URL, ".html");

	return GO;
	}__except(1) { ERR=TRUE; return FALSE; }
}

char* ReportCondition(char* what)
{
	__try
	{
		char temp[256] = "";
		
		memset(ReportString, '\0', sizeof(ReportString));
		GetPrivateProfileString(what, "Format", "", temp, 256, thm);
		ParseFormat(temp, ReportString);

		return ReportString;
	}__except(1) { ERR=TRUE; return ""; }
}

void BangHide(HWND w, char* a) { ShowWindow(hMainWnd, SW_HIDE); HIDDEN=TRUE; }
void BangShow(HWND w, char* a) { ShowWindow(hMainWnd, SW_SHOW); HIDDEN=FALSE; }
void BangToggle(HWND w, char* a) { (HIDDEN)? BangShow(NULL, "") : BangHide(NULL, ""); }
void BangUpdate(HWND w, char* a) { SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_UPDATE, 0); }
void BangReport(HWND w, char* a) { SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_REPORT, 0); }
void BangChangeSettings(HWND w, char* a) { SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_SETTINGS, 0); }
void BangLaunchWebpage(HWND w, char* a) { SendMessage(hMainWnd, WM_COMMAND, (WPARAM)M_LAUNCH, 0); }
void BangAlwaysOnTop(HWND w, char* a)
{
	if (TOP) { SetWindowPos(hMainWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE); TOP=FALSE; }
	else { SetWindowPos(hMainWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE); TOP=TRUE; }
}

void DisplayValue(HDC buf, char* val)
{
	__try 
	{
		char temp[256] = "";
		char out[256] = "";
		GetPrivateProfileString(val, "Format", "", temp, 256, thm);

		if (strlen(temp)) ParseFormat(temp, out);

		TextOut(buf, 
				GetPrivateProfileInt(val, "TextX", 5, thm),
				GetPrivateProfileInt(val, "TextY", 5, thm), 
				out, strlen(out));
	}__except(1) { ERR=TRUE; }
}

void BrowseForFile(HWND hwnd, DWORD editbox, char* filter)
{
	char thmfile[256] = "";
	OPENFILENAME* of	= malloc(sizeof(OPENFILENAME));

	of->lStructSize	= sizeof(OPENFILENAME);
	of->hwndOwner	= hwnd;
	of->hInstance	= NULL;
	of->lpstrFilter	= filter;
	of->lpstrCustomFilter = NULL;
	of->nMaxCustFilter	= 0;
	of->nFilterIndex	= 0;
	of->lpstrFile		= thmfile;
	of->nMaxFile		= MAX_PATH;
	of->lpstrFileTitle	= NULL;
	of->lpstrInitialDir	= NULL;
	of->lpstrTitle		= "LSWeather Browse";
	of->Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;

	__try { if (GetOpenFileName(of)) SetDlgItemText(hwnd, editbox, thmfile); }
	__except(1) { }

	free(of);
}