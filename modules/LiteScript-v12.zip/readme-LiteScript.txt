/////////////////////////////
// Module: LiteScript 1.2
// Written By: MrJukes
// Released: 9/19/00
/////////////////////////////

// New to 1.2
- Added variable expansion
- Added OnTop, NotOnTop, Sticky, and NotSticky commands
- Added Prompt command

// New to 1.1
- Fixed hanging during recycle
- Added if statement
//

LoadModule c:\litestep\litescript.dll

step.rc
==========
; You can have as many of these as you would like
*LiteScript c:\litestep\litescript.scr

bangs
=======
!LiteScriptReport ; This bang will pop up a messagebox containing the class
		  ; and caption of the window the cursor is currently over
		  ; This bang is useful for making litescript scripts

*NOTE*
Anything in []'s is required.
Anything in ()'s is optional.
Do not actually put the []'s and ()'s in your script.

scripts
=========
The general format to create a bang is as follows:

  Create Bang !BangName
    Capture "Window Class" "Window Caption"  (You can obtain these using !LiteScriptReport)
      <Insert commands from below here>
    End Capture
  End Bang

  Create Bang !BangName2
  ...

variabe expansion
===================
There are 2 different kinds of variable expansion that you can use:
LiteScript variable expansion and LiteSTEP variable expansion.

To define LiteScript variables just put lines like the one below at the top of your script file.
  LitestepDir  "c:\litestep\"
  ModulesDir   "c:\litestep\modules"
To access these in the scripts you would do something like:
  Prompt "Litestep Directory" "You're litestep directory is %LitestepDir%" "Information" ""
All you have to do is enclose the litescript variable name in %'s.

To define LiteSTEP variables just put the lines from above at the top of your step.rc file.
To access litestep variables in the scripts you would do something like:
  Prompt "Litestep Directory" "You're litestep directory is $LitestepDir$" "Information" ""
All you have to do is enclose the litestep variable name in $'s.

commands
==========
These are the commands you can put in the capture section from above.

  ; Move the currently captured window
  ; A = Absolute = Moves the windows to X,Y on the screen
  ; R = Relative = Moves the window X,Y pixels from the current location
  Move [A|R] (-)X (-)Y

  ; Resize the currently captured window
  ; A = Absolute = Resizes the window so that it is WxH
  ; RR = Relative Right = The right border is fixed and the left border is resized
  ; RL = Relative Left = The left border is fixed and the right border is resized
  ; RT = Relative Top = The top border is fixed and the bottom border is resized
  ; RB = Relative Bottom = The bottom border is fixed and the top border is resized
  Size [A|RR|RL|RT|RB] (-)W (-)H

  ; Hide the currently captured window
  Hide

  ; Show the currently captured window
  Show

  ; Makes the currently captured window always on top
  OnTop

  ; Makes the currently captured window not always on top
  NotOnTop

  ; Makes the currently captured window appear on all desktops
  Sticky

  ; Makes the currently captured window not appear on all desktops
  NotSticky

  ; Repeat the next command X times
  ; Example:
  ;  Repeat 11
  ;    Move R 5 0
  ; This would move the currently captured window relatively to the right 5 pixels 11 times
  Repeat X

  ; Set the delay between commands
  ; Once set, it stays set until the next call to SetDelay
  SetDelay X

  ; Execute a bang command or an executable
  Exec !Bang
  Exec notepad.exe

  ; Pops up a message box with all the specified options
  ; Prompt "Caption" "Text" "Icon" "YesAction" "NoAction"
  ; Prompt "Caption" "Text" "Icon" "OkAction"
  ;   Caption = Text that appears in the message box title bar
  ;   Test = Text that appears in the message box itself
  ;   Icon = The icon to use. Options are: Question, Information, Warning, Exclamation, Asterisk, and Error
  ;   YesAction = Action to be performed if user clicks yes
  ;   NoAction = Action to be performed if user clicks no
  ;   OkAction = Action to be performed if user clicks ok
  ;   Actions can either be !bang commands are executables
  ;   If 2 bangs are specified as result actions, the messagebox appears as a Yes/No messagebox
  ;   If 1 bang is specified as a result action, the messagebox appears as an OK messagebox
  ;
  ; Example:
  ;   Prompt "Yes/No Question?" "Are you sure you want to do that?" "Question" !About ""
  ;   Prompt "Ok Box" "I am about to do this" "Information" notepad.exe

  ; A basic if statement
  ; You cannot nest if statements
  ; Only 2 things may directly follow "if".  They are "Visible" or "Hidden".
  if Visible
    Exec !Bang
    Show
  else
    Hide
  end if

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes