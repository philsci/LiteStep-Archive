This module adds one !bang command:

!rules

and that's it. It has no function other than this.