//% $Id: exports.h,v 1.1.1.1.2.2 2001/04/22 09:38:23 Yoshi Exp $

#ifndef EXPORTS_H
#define EXPORTS_H

#ifdef __cplusplus
extern "C" {
#endif
    
/* LOAD-MODULE Functions */
__declspec( dllexport ) int initModuleEx( HWND lswnd, HINSTANCE lsinstance, LPCTSTR lspath );
__declspec( dllexport ) int quitModule( HINSTANCE lsinstance );

#ifdef __cplusplus
}
#endif

#endif