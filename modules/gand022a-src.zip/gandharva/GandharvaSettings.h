//% $Id: GandharvaSettings.h,v 1.8.2.1 2001/04/23 12:54:33 Yoshi Exp $

#ifndef _H_GANDHARVA_SETTINGS
#define _H_GANDHARVA_SETTINGS

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

//!bang command mode
#define CMDMODE_NONE	0
#define CMDMODE_BASIC	1
#define CMDMODE_DEBUG	2

//textalign
#define ALIGN_RIGHT		0
#define ALIGN_LEFT		1
#define ALIGN_CENTER	2

//timer id
#define TIMERID_RECYCLE_DISPLAY		0x00000001
#define TIMERID_SCROLL_INTERVAL		0x00000002

//macros
#define SWITCH DWORD


class GandharvaSettings
{
public:
  GandharvaSettings(HWND owner);
  ~GandharvaSettings();

  //window param
  HWND		m_hWnd;
  HBITMAP	m_hbmBack;
  
  BOOL	m_bTranspBack;
  int	m_nScrollOffset;

  //font and color
  LOGFONT m_TextLogFont;
  
  COLORREF m_FontColor;
  COLORREF m_BGColor;
  COLORREF m_BorderColor;

  //display
  char m_lpszTitleDefault[130];

  int m_PosX,m_PosY,m_Width,m_Height;
  int m_nBorderLeft, m_nBorderRight, m_nBorderTop, m_nBorderBottom;
  int m_nPaddingLeft, m_nPaddingRight, m_nPaddingTop, m_nPaddingBottom;
  BOOL	m_bTitleScroll;
  BOOL	m_bAlwaysOnTop;
  BOOL	m_bVisible;
  SWITCH	m_swTextAlignH;

  //amp
  BOOL	m_bKeepPrefix;
  BOOL	m_bKeepSuffix;
  SWITCH	m_swCmdMode;

  //scroll
  int m_nScrollInterval;
  int m_nScrollStep;

  //functions
  void CreateBG();
  void PaintBG(HDC hdc);
  void PaintText(HDC hdc, LPSTR lpszTextString);

  //timer id
  UINT m_rtimer,m_stimer;
};

#endif //_H_GAHDHARVA_SETTINGS
