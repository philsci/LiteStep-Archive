//% $Id: Gandharva.h,v 1.6.2.1 2001/04/23 12:54:33 Yoshi Exp $
#ifndef _H_GANDHARVA
#define _H_GANDHARVA

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "GandharvaSettings.h"
#include "winampfunc.h"
#include "ampcmd.h"

#define WC_LSDESKTOP		"DesktopBackgroundClass"
#define WINDOWCLASS_DLL		"GandharvaClass"

#define TIMERID		DWORD

#define USERBM_TOGGLE	0
#define USERBM_SHOW 	1
#define USERBM_HIDE 	2

#define MAGICDWORD         0x49474541

class Gandharva{

public:
  Gandharva( HWND parent, HINSTANCE lsinstance );
  ~Gandharva();

  static void bangToggleVisible(HWND caller, char *args);
  static void bangShow(HWND caller, char *args);
  static void bangHide(HWND caller, char *args);

  static void bangAmpPrev(HWND hwnd, char *args);
  static void bangAmpPlay(HWND hwnd, char *args);
  static void bangAmpPause(HWND hwnd, char *args);
  static void bangAmpStop(HWND hwnd, char *args);
  static void bangAmpNext(HWND hwnd, char *args);
  static void bangAmpPLEdit(HWND hwnd, char *argv);
  static void bangAmpOpenFile(HWND hwnd, char *argv);
  static void bangAmpPower(HWND hwnd, char *argv);

  static void bangAmpCommand(HWND hwnd, char *argv);

private:
  void onUser(UINT, WPARAM, LPARAM, LRESULT *);
  void onPaint(UINT, WPARAM, LPARAM, LRESULT *);
  void onTimer(UINT, WPARAM, LPARAM, LRESULT *);
  void onLmGetRevid(UINT, WPARAM, LPARAM, LRESULT *);
  void onDisplayChange(UINT, WPARAM, LPARAM, LRESULT *);
  void onLButtonDblclk(UINT, WPARAM, LPARAM, LRESULT *);
  void onRButtonUp(UINT, WPARAM, LPARAM, LRESULT *);

  CWinampFunction* m_pWinampFunc;
  GandharvaSettings* m_pSettings;

  void SetWndPos();
  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  HINSTANCE	m_hInstance;
  HWND	m_hLitestep;
  HWND	m_hDesktop;
  HWND	m_hWnd;
};

#endif //_H_GANDHARVA
