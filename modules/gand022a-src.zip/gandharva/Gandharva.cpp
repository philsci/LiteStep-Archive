//% $Id: Gandharva.cpp,v 1.15.2.2 2001/04/23 12:55:23 Yoshi Exp $

#include "lsapi.h"
#include "Gandharva.h"

#define BUILD_NAME		TEXT("Gandharva.dll")
#define BUILD_VERSION	TEXT("v0.22a")
#define BUILD_DATE		TEXT("2001/04/23")
#define BUILD_AUTHOR	TEXT("Yoshi")

UINT nMessages[] = {
  LM_GETREVID,
  0
};

/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^
		�E�B���h�E�̃Z�b�g�A�b�v
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
Gandharva::Gandharva( HWND parent, HINSTANCE lsinstance )
{

  //sssssssssssssssssssssssssssssssss�V�X�e�����̏�����
  m_hLitestep = GetLitestepWnd();
  m_hInstance = lsinstance;
  m_hDesktop = FindWindow(WC_LSDESKTOP, NULL);

  if(!m_hDesktop)
    m_hDesktop = GetDesktopWindow();

  m_hWnd = NULL;

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�N���X
  WNDCLASSEX wc;

  wc.cbSize = sizeof(WNDCLASSEX);
  wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
  wc.lpfnWndProc = (WNDPROC) Gandharva::WndProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 4;
  wc.hInstance = m_hInstance;
  wc.hCursor = LoadCursor( NULL, IDC_ARROW );
  wc.hIcon = NULL;
  wc.hIconSm = NULL;
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NULL;
  wc.lpszClassName = WINDOWCLASS_DLL;

  if (!RegisterClassEx( &wc ) ) {
    ::MessageBox(0,TEXT("failed to register window class."),WINDOWCLASS_DLL,MB_OK);
    return;
  }

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�̍쐬

  m_hWnd = CreateWindowEx( WS_EX_TOOLWINDOW,//|WS_EX_TRANSPARENT,
                         WINDOWCLASS_DLL, NULL, WS_POPUP,
                         0, 0, 0, 0,
                         m_hDesktop, NULL, m_hInstance, (LPVOID)this);

  if (!m_hWnd) {
    ::MessageBox(0,TEXT("failed to create window."),WINDOWCLASS_DLL,MB_OK);
    return;
  }

  //ssssssssssssssssssssssssssssssssssLITESTEP �Ƀ��W���[���o�^
  SendMessage( m_hLitestep, LM_REGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );
  SetWindowLong( m_hWnd, GWL_USERDATA, (LONG)MAGICDWORD );

  //ssssssssssssssssssssssssssssssssss�ݒ�̓ǂݍ��݂Ɣ��f
  m_pSettings = new GandharvaSettings(m_hWnd);

  if(!m_pSettings){
    ::MessageBox(0, "failed to load settings.", WINDOWCLASS_DLL, MB_OK);
    return;
  }

  SetWindowPos(m_hWnd,
               (m_pSettings->m_bAlwaysOnTop) ? HWND_TOPMOST : HWND_TOP,
               0,
               0,
               m_pSettings->m_Width,
               m_pSettings->m_Height,
               SWP_NOMOVE|SWP_NOACTIVATE);

  SetWndPos();

  //ssssssssssssssssssssssssssssssssss�E�B���h�E�̕\��
  ShowWindow( m_hWnd,  !m_pSettings->m_bVisible ? SW_HIDE : SW_SHOWNOACTIVATE );

  //ssssssssssssssssssssssssssssssssss�^�C�}�[
  if(NULL == (m_pSettings->m_rtimer = SetTimer(m_hWnd, TIMERID_RECYCLE_DISPLAY, 1000, NULL)))
    MessageBox(0,TEXT("Fail to create timer for title refresh."),WINDOWCLASS_DLL,MB_OK);

//  if(NULL == (m_pSettings->m_stimer = SetTimer(m_hWnd, TIMERID_SCROLL_INTERVAL, m_pSettings->m_nScrollInterval, NULL)))
//    MessageBox(0,TEXT("Fail to create timer for scroll interval."),WINDOWCLASS_DLL,MB_OK);

  //ssssssssssssssssssssssssssssssssss�I�a�`�m�f�̒ǉ�
  AddBangCommand("!GandharvaToggle", bangToggleVisible);
  AddBangCommand("!GandharvaShow", bangShow);
  AddBangCommand("!GandharvaHide", bangHide);

  if(m_pSettings->m_swCmdMode){
    AddBangCommand("!GandharvaCmdPrev", bangAmpPrev);
    AddBangCommand("!GandharvaCmdPlay", bangAmpPlay);
    AddBangCommand("!GandharvaCmdPause", bangAmpPause);
    AddBangCommand("!GandharvaCmdStop", bangAmpStop);
    AddBangCommand("!GandharvaCmdNext", bangAmpNext);
    AddBangCommand("!GandharvaCmdPLEdit", bangAmpPLEdit);
    AddBangCommand("!GandharvaCmdOpenFile", bangAmpOpenFile);
    AddBangCommand("!GandharvaCmdPower", bangAmpPower);
    AddBangCommand("!GandharvaCmdExtension", bangAmpCommand);
  }
  //ssssssssssssssssssssssssssssssssss winamp�t�@���N�V����
  char *buf=new char[256];

  //�f�t�H���g������
  if(NULL == *m_pSettings->m_lpszTitleDefault)
    SendMessage(m_hWnd, LM_GETREVID, 0, (LPARAM)buf);
  else
    strcpy(buf, m_pSettings->m_lpszTitleDefault);

  m_pWinampFunc = new CWinampFunction(buf);

  delete buf;

  return;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
		�E�C���h�E�̔j��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
Gandharva::~Gandharva()
{
  //ssssssssssssssssssssssssssssssssss winamp�t�@���N�V����
  if(m_pWinampFunc)
    delete m_pWinampFunc;

  //ssssssssssssssssssssssssssssssssss�I�a�`�m�f�̍폜
  if(m_pSettings->m_swCmdMode){
    RemoveBangCommand("!GandharvaCmdExtension");
    RemoveBangCommand("!GandharvaCmdPower");
    RemoveBangCommand("!GandharvaCmdOpenFile");
    RemoveBangCommand("!GandharvaCmdPLEdit");
    RemoveBangCommand("!GandharvaCmdNext");
    RemoveBangCommand("!GandharvaCmdStop");
    RemoveBangCommand("!GandharvaCmdPause");
    RemoveBangCommand("!GandharvaCmdPlay");
    RemoveBangCommand("!GandharvaCmdPrev");
  }
  
  RemoveBangCommand("!GandharvaHide");
  RemoveBangCommand("!GandharvaShow");
  RemoveBangCommand("!GandharvaToggle");

  //ssssssssssssssssssssssssssssssssss���W���[���o�^�̔j��
  SendMessage( m_hLitestep, LM_UNREGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );

  //ssssssssssssssssssssssssssssssssss�^�C�}�[�̍폜���ݒ�N���X�̍폜
  if( m_pSettings ){
    if(m_pSettings->m_rtimer)
      KillTimer(m_hWnd, TIMERID_RECYCLE_DISPLAY);
    if(m_pSettings->m_stimer)
      KillTimer(m_hWnd, TIMERID_SCROLL_INTERVAL);

    delete m_pSettings;
    m_pSettings = NULL;
  }

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�i�N���X�j�̔j��
  DestroyWindow( m_hWnd );
  m_hWnd = NULL;

  UnregisterClass( WINDOWCLASS_DLL, m_hInstance );

  return;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̈ړ�
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::SetWndPos()
{
  int x=m_pSettings->m_PosX, y=m_pSettings->m_PosY;

  if(x < 0)
    x = GetSystemMetrics(SM_CXSCREEN)+x;

  if(y < 0)
    y = GetSystemMetrics(SM_CYSCREEN)+y;

  SetWindowPos(m_hWnd, NULL, x, y, 0, 0, SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOZORDER);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�v���V�[�W��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
LRESULT CALLBACK Gandharva::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  LRESULT lResult = 0;
  Gandharva *pGandharva;

  //sssssssssssssssssssssssssssssssss�E�C���h�E�쐬�O��
  if(message == WM_NCCREATE){
    LPCREATESTRUCT lpcs = (LPCREATESTRUCT)lParam;
    pGandharva = (Gandharva *)lpcs->lpCreateParams;

    SetWindowLong(hwnd, 0, (long)pGandharva);
  }else
    pGandharva = (Gandharva *)GetWindowLong(hwnd, 0);

  //sssssssssssssssssssssssssssssssss���C���̃|�C���^�����߂Ȃ��ꍇ
  if(!pGandharva)
    return DefWindowProc(hwnd, message, wParam, lParam);

  //sssssssssssssssssssssssssssssssss���b�Z�[�W�̏���

  switch(message){
  case WM_PAINT:
    pGandharva->onPaint(message, wParam, lParam ,&lResult); break;

  case WM_TIMER:
    pGandharva->onTimer(message, wParam, lParam, &lResult); break;

  case WM_DISPLAYCHANGE:
    pGandharva->onDisplayChange(message, wParam, lParam, &lResult); break;

  case WM_LBUTTONDBLCLK:
    pGandharva->onLButtonDblclk(message, wParam, lParam, &lResult); break;

  case WM_RBUTTONUP:
    pGandharva->onRButtonUp(message, wParam, lParam, &lResult); break;

  case WM_USER:
    pGandharva->onUser(message, wParam, lParam, &lResult); break;

  case LM_GETREVID:
    pGandharva->onLmGetRevid(message, wParam, lParam, &lResult); break;

  default:
    lResult = DefWindowProc( hwnd, message, wParam, lParam );
    break;
  }

  return lResult;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���W���[���̃o�[�W������n��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onLmGetRevid(UINT message,
                             WPARAM wparam,
                             LPARAM lparam,
                             LRESULT *plresult)
//  int mode, char* buffer, LPINT result)
{
  UINT mode = (UINT)wparam;
  char *buffer = (char *)lparam;
  char *tmpbuf = new char[64];
  memset(tmpbuf, 0, 64);

  //ssssssssssssssssssss�}���ʎq�̐ݒ�
#if defined _A2UNVLIB
  #if defined _WINAMP3_ALPHA
    strcpy(tmpbuf, "(uw3)");
  #else
    strcpy(tmpbuf, "(u)");
  #endif //w3
#else
  #if defined _WINAMP3_ALPHA
    strcpy(tmpbuf, "(w3)");
  #endif
#endif //u

  //ssssssssssssssssssss�o�[�W����������
  switch(mode){
#if defined _DEBUG
  case 0:
    sprintf(buffer, "%s:debug%s %s %s", BUILD_NAME, tmpbuf, __DATE__, __TIME__);
    break;
#else
  case 0:
    sprintf(buffer, "%s:%s%s", BUILD_NAME, BUILD_VERSION, tmpbuf);
    break;
#endif

  case 1:
    sprintf(buffer, "Id:%s %s%s %s %s", BUILD_NAME, BUILD_VERSION, tmpbuf, BUILD_DATE, BUILD_AUTHOR);
    break;

  default:
    strcpy(buffer, "");
    break;
  }

  delete tmpbuf;
  *plresult = (LRESULT)strlen(buffer);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̕`��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onPaint(UINT message,
                        WPARAM wparam,
                        LPARAM lparam,
                        LRESULT *plresult)
{
  HDC hdcScreen;// = (HDC)wparam;
  HDC hdcTemp;
  HBITMAP hbmTemp,hbmOld;

  //ssssssssssssssssssssssssssssssssss�`����J�n����
  PAINTSTRUCT ps;
  hdcScreen = BeginPaint(m_hWnd, &ps);

  //sssssssssssssssssssssssssssssssss�e�n���h���̍쐬
  hdcTemp = CreateCompatibleDC(hdcScreen);
  hbmTemp = CreateCompatibleBitmap(hdcScreen, m_pSettings->m_Width, m_pSettings->m_Height);

  //sssssssssssssssssssssssssssssssss�r�b�g�}�b�v�̓K�p�ƃo�b�N�A�b�v
  hbmOld = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

  //sssssssssssssssssssssssssssssssss�w�i�̕`��
  m_pSettings->PaintBG(hdcTemp);

  //sssssssssssssssssssssssssssssssss�e�L�X�g���d�ˍ��킹��
  char *TitleString = new char [512];

  if(m_pWinampFunc){
    this->m_pWinampFunc->GetWinampTitle(TitleString, GWT_COPYONLY);
    this->m_pWinampFunc->SetFormat(TitleString, !m_pSettings->m_bKeepPrefix, !m_pSettings->m_bKeepSuffix);

    m_pSettings->PaintText(hdcTemp, TitleString);
  }else
    m_pSettings->PaintText(hdcTemp, "WinampFuncError");

  delete TitleString;
  //sssssssssssssssssssssssssssssssss�w�i���߂���H

  //sssssssssssssssssssssssssssssssss�E�B���h�E�ɓ]��
  BitBlt(hdcScreen, 0, 0, m_pSettings->m_Width, m_pSettings->m_Height, hdcTemp, 0, 0, SRCCOPY);

  //sssssssssssssssssssssssssssssssss�e��n���h���̔j��
  EndPaint(m_hWnd, &ps);

  SelectObject(hdcTemp, hbmOld);

  DeleteObject(hbmTemp);
  DeleteDC(hdcTemp);

  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�^�C�}�[����
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onTimer(UINT message,
                        WPARAM wparam,
                        LPARAM lparam,
                        LRESULT *plresult)
{
  switch(wparam){
  case TIMERID_RECYCLE_DISPLAY:
    if(TRUE == this->m_pWinampFunc->GetWinampTitle(NULL, GWT_REFRESH))
      m_pSettings->m_nScrollOffset = 0;

    InvalidateRgn(m_hWnd, NULL, TRUE);
    UpdateWindow(m_hWnd);
    break;
  case TIMERID_SCROLL_INTERVAL:
    m_pSettings->m_nScrollOffset += m_pSettings->m_nScrollStep;
    InvalidateRgn(m_hWnd, NULL, TRUE);
    UpdateWindow(m_hWnd);
    break;
  }

  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�B�X�v���C�̉𑜓x���ύX���ꂽ�Ƃ�
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onDisplayChange(UINT message,
                                WPARAM wparam,
                                LPARAM lparam,
                                LRESULT *plresult)
{
  SetWndPos();
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�N���b�N
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onRButtonUp(UINT message,
                            WPARAM wparam,
                            LPARAM lparam,
                            LRESULT *plresult)
{
  m_pWinampFunc->DisplayMainMenu();
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���_�u���N���b�N
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onLButtonDblclk(UINT message,
                                WPARAM wparam,
                                LPARAM lparam,
                                LRESULT *plresult)
{
  ShellExecute(m_hWnd, NULL, "sndvol32.exe", NULL, NULL, SW_SHOWNORMAL);
  *plresult =0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̕\������\��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::onUser(UINT message,
                       WPARAM wparam,
                       LPARAM lparam,
                       LRESULT *plresult)
{
  switch(wparam){
  case USERBM_SHOW: //!nornirshow
    ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
    break;
  case USERBM_HIDE: //!nornirhide
    ShowWindow(m_hWnd, SW_HIDE);
    break;
  case USERBM_TOGGLE: //!nornirtoggle
    if(IsWindowVisible(m_hWnd))
      ShowWindow(m_hWnd, SW_HIDE);
    else
      ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
  }
  *plresult = 0;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�I�a�`�m�f
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void Gandharva::bangToggleVisible(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WINDOWCLASS_DLL, NULL);
  if(hwnd) PostMessage(hwnd, WM_USER, USERBM_TOGGLE, 0);
}


void Gandharva::bangShow(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WINDOWCLASS_DLL, NULL);
  if(hwnd) PostMessage(hwnd, WM_USER, USERBM_SHOW, 0);
}


void Gandharva::bangHide(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WINDOWCLASS_DLL, NULL);
  if(hwnd) PostMessage(hwnd, WM_USER, USERBM_HIDE, 0);
}


//ssssssssssssssssssssssssssssssssssssswinamp �̃����[�g�R���g���[��!BAMG
//preview
void Gandharva::bangAmpPrev(HWND hwnd, char *args)
{
  CWinampFunction cAmpFunc;
  cAmpFunc.SendWinampCommand(AMPAPI_CMD_PREV);
}

//execute&play
void Gandharva::bangAmpPlay(HWND hwnd, char *args)
{
  CWinampFunction cAmpFunc;

  if(FALSE == cAmpFunc.SendWinampCommand(AMPAPI_CMD_PLAY))
    cAmpFunc.ExecuteWinamp(hwnd);
}

//pause
void Gandharva::bangAmpPause(HWND hwnd, char *args)
{
  CWinampFunction cAmpFunc;
  cAmpFunc.SendWinampCommand(AMPAPI_CMD_PAUSE);
}

//stop
void Gandharva::bangAmpStop(HWND hwnd, char *args)
{
  CWinampFunction cAmpFunc;
  cAmpFunc.SendWinampCommand(AMPAPI_CMD_STOP);
}

//next
void Gandharva::bangAmpNext(HWND hwnd, char *args)
{
  CWinampFunction cAmpFunc;
  cAmpFunc.SendWinampCommand(AMPAPI_CMD_NEXT);
}

//toggle pl editer
void Gandharva::bangAmpPLEdit(HWND hwnd, char *argv)
{
  //winamp ���S�ʂɂȂ��ƐV���������\������Ȃ�
  CWinampFunction cAmpFunc;
  HWND hWinamp = cAmpFunc.FindWinamp();
  if(hWinamp){
    SetWindowPos(hWinamp, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
    cAmpFunc.SendWinampCommand(AMPAPI_CMD_PLEDIT);
  }
}

//disp file open dialog
void Gandharva::bangAmpOpenFile(HWND hwnd, char *argv)
{
  //winamp ���S�ʂɂȂ��ƐV���������\������Ȃ�
  CWinampFunction cAmpFunc;
  HWND hWinamp = cAmpFunc.FindWinamp();
  if(hWinamp){
    SetWindowPos(hWinamp, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
    cAmpFunc.SendWinampCommand(AMPAPI_CMD_OPENFILE);
  }
}

//power on/off
void Gandharva::bangAmpPower(HWND hwnd, char *argv)
{
  CWinampFunction cAmpFunc;
  HWND hWinamp = cAmpFunc.FindWinamp();

  if(hWinamp){
    cAmpFunc.CloseWinamp();
  }else{
    cAmpFunc.ExecuteWinamp(hwnd);
  }
}

//command extensions
void Gandharva::bangAmpCommand(HWND hwnd, char *argv)
{
  CWinampFunction cAmpFunc;
  int argn = atoi(argv);

  if(40001 <= argn && 40298 >= argn)
    cAmpFunc.SendWinampCommand(argn);
}
