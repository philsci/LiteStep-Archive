//% $Id: exports.cpp,v 1.2.2.2 2001/04/22 09:38:24 Yoshi Exp $

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#include "lsapi.h"
#include "exports.h"
#include "Gandharva.h"

Gandharva* pGandharva;

/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���W���[���̃��[�h���A�����[�h
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
int initModuleEx( HWND lswnd, HINSTANCE lsinstance, LPCSTR lspath )
{
  pGandharva = new Gandharva(lswnd, lsinstance);

  if(pGandharva)
    return 1;

  return 0;
}


int quitModule( HINSTANCE lsinstance )
{
  if(pGandharva)
    delete pGandharva;

  return 0;
}