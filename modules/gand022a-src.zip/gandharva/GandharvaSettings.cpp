//% $Id: GandharvaSettings.cpp,v 1.12.2.1 2001/04/23 12:54:33 Yoshi Exp $

#include "GandharvaSettings.h"
#include "lsapi.h"
#include <stdlib.h>

#if defined _A2UNVLIB
#include <a2unvlib.h>
#endif

/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^�Őݒ��ǂݍ���
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
GandharvaSettings::GandharvaSettings(HWND owner)
{
  LPSTR lpszbuf = new char[1024];
  char token[4][4];
  char *tokens[]={token[0], token[1], token[2], token[3], 0};

  //sssssssssssssssssssssssssssssssss�V�X�e���p�����[�^������
  m_hWnd = owner;
  m_hbmBack = NULL;

  //sssssssssssssssssssssssssssssssss��{�ݒ�
  GetRCString("GandharvaFont", m_TextLogFont.lfFaceName, "MS UI Gothic", LF_FACESIZE);
  m_TextLogFont.lfHeight =GetRCInt("GandharvaFontSize", 16);
  m_FontColor            =GetRCColor("GandharvaFontColor", 0x00FFFFFF);
  m_BGColor              =GetRCColor("GandharvaBGColor", 0x000000);
  m_BorderColor          =GetRCColor("GandharvaBorderColor", 0x888888);

  m_bTitleScroll = GetRCBool("GandharvaAutoScroll", TRUE);

  m_TextLogFont.lfItalic = GetRCBool("GandharvaFontItalic", TRUE);
  if(TRUE == GetRCBool("GandharvaFontBold", TRUE))
    m_TextLogFont.lfWeight = 700;
  else
    m_TextLogFont.lfWeight = 400;
  
  m_PosX = GetRCInt("GandharvaX", 0);
  m_PosY = GetRCInt("GandharvaY", 0);
  m_Width= GetRCInt("GandharvaWidth", 180);
  m_Height=GetRCInt("GandharvaHeight", 20);

  //bitmap
  GetRCString("GandharvaBitmap", lpszbuf, "", MAX_PATH);

  m_bTranspBack = (m_BGColor == 0xFF00FF || m_BorderColor == 0xFF00FF) ? TRUE : FALSE;

  if(*lpszbuf){
    m_hbmBack = LoadLSImage(lpszbuf, NULL);

    //�r�b�g�}�b�v�ɂ��킹�ăT�C�Y�C�����w�i���ߖ���
    if(m_hbmBack){
      GetLSBitmapSize(m_hbmBack, &m_Width, &m_Height);
      m_bTranspBack = FALSE;
    }
  }

  //sssssssssssssssssssssssssssssssss�g���ݒ�
  GetRCString("GandharvaDefaultString", m_lpszTitleDefault, "", 128);

  //window style
  m_bAlwaysOnTop = GetRCBool("GandharvaAlwaysOnTop", TRUE);
  m_bVisible = GetRCBool("GandharvaHidden", FALSE);

  //border
  GetRCLine("GandharvaBorderSize", lpszbuf, MAX_RCCOMMAND, "0");

  if(4 == LCTokenize(lpszbuf, NULL, 0, NULL)){
    LCTokenize(lpszbuf, tokens, 4, NULL);

    m_nBorderTop   =atoi(token[0]);
    m_nBorderRight =atoi(token[1]);
    m_nBorderBottom=atoi(token[2]);
    m_nBorderLeft  =atoi(token[3]);
  }else
    m_nBorderTop = m_nBorderRight = m_nBorderBottom = m_nBorderLeft = GetRCInt("GandharvaBorderSize", 0);

  //for compatible with old ver.
  m_nBorderTop   =GetRCInt("GandharvaBorderTop"   , m_nBorderTop);
  m_nBorderRight =GetRCInt("GandharvaBorderRight" , m_nBorderRight);
  m_nBorderBottom=GetRCInt("GandharvaBorderBottom", m_nBorderBottom);
  m_nBorderLeft  =GetRCInt("GandharvaBorderLeft"  , m_nBorderLeft);

  //padding
  GetRCLine("GandharvaPadding", lpszbuf, MAX_RCCOMMAND, "0");

  if(4 == LCTokenize(lpszbuf, NULL, 0, NULL)){
    LCTokenize(lpszbuf, tokens, 4, NULL);

    m_nPaddingTop   =atoi(token[0]);
    m_nPaddingRight =atoi(token[1]);
    m_nPaddingBottom=atoi(token[2]);
    m_nPaddingLeft  =atoi(token[3]);
  }else
    m_nPaddingTop = m_nPaddingRight = m_nPaddingBottom = m_nPaddingLeft = GetRCInt("GandharvaBorderSize", 0);

  //scroll
  m_nScrollInterval = GetRCInt("GandharvaScrollInterval", 500);
  m_nScrollStep = GetRCInt("GandharvaScrollStep", 4);

  //prefix suffix
  m_bKeepPrefix = GetRCBool("GandharvaKeepPrefix", TRUE);
  m_bKeepSuffix = GetRCBool("GandharvaKeepSuffix", TRUE);

  //!command mode
  GetRCString("GandharvaCommandMode", lpszbuf, "basic", 64);

  if(!strcmpi(lpszbuf, "none"))	m_swCmdMode=CMDMODE_NONE;
  if(!strcmpi(lpszbuf, "basic"))	m_swCmdMode=CMDMODE_BASIC;
  if(!strcmpi(lpszbuf, "extension")) m_swCmdMode=CMDMODE_BASIC; //old version

  //text align
  GetRCString("GandharvaTextAlignH", lpszbuf, "left", 64);

  if(!strcmpi(lpszbuf, "left")) m_swTextAlignH=ALIGN_LEFT;
  if(!strcmpi(lpszbuf, "right")) m_swTextAlignH=ALIGN_RIGHT;
  if(!strcmpi(lpszbuf, "center")) m_swTextAlignH=ALIGN_CENTER;

  //ssssssssssssssssssssssssssssssssTextLogFont
//m_TextLogFont.lfHeight;
  m_TextLogFont.lfWidth = 0;
  m_TextLogFont.lfEscapement = 0;
  m_TextLogFont.lfOrientation = 0;
//m_TextLogFont.lfWeight;
//m_TextLogFont.lfItalic;
  m_TextLogFont.lfUnderline = FALSE;
  m_TextLogFont.lfStrikeOut = FALSE;
  m_TextLogFont.lfCharSet = DEFAULT_CHARSET;
  m_TextLogFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
  m_TextLogFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
  m_TextLogFont.lfQuality = PROOF_QUALITY;
  m_TextLogFont.lfPitchAndFamily = DEFAULT_PITCH|FF_DONTCARE;
//m_TextLogFont.lfFaceName[LF_FACESIZE];

  //sssssssssssssssssssssssssssssssss�ꎞ�o�b�t�@�̔j��
  delete lpszbuf;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
GandharvaSettings::~GandharvaSettings()
{
  if(m_hbmBack)
    DeleteObject(m_hbmBack);

}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̏o��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintBG(HDC hdcdst)
{
  HDC hdc;
  HBITMAP hbmold;
  
  //sssssssssssssssssssssssssssssssss�w�i�̍쐬�͂܂��H
  if( !m_hbmBack )
    CreateBG();

  //sssssssssssssssssssssssssssssssss�w�i���R�s�[
  hdc    = CreateCompatibleDC(hdcdst);
  hbmold = (HBITMAP)SelectObject(hdc, m_hbmBack);

  BitBlt(hdcdst, 0, 0, m_Width, m_Height, hdc, 0, 0, SRCCOPY);

  SelectObject(hdc, hbmold);
  DeleteDC(hdc);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̍쐬
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::CreateBG()
{
  HDC	hdcScreen,hdcBack;
  HBITMAP hbmBackOld;
  RECT rect;
  HBRUSH hbrush;

  //sssssssssssssssssssssssssssssssss�E�C���h�E�R���p�`��DC,BMP
  hdcScreen = GetDC(m_hWnd);
  hdcBack = CreateCompatibleDC(hdcScreen);
  m_hbmBack = CreateCompatibleBitmap(hdcScreen, m_Width, m_Height);

  hbmBackOld = (HBITMAP)SelectObject(hdcBack, m_hbmBack);

  //sssssssssssssssssssssssssssssssss�ǎ���؂����ăE�B���h�E�ɒ���t����
  if(m_BorderColor == 0xFF00FF || m_BGColor == 0xFF00FF){
    PaintDesktop(hdcScreen);
    BitBlt(hdcBack, 0, 0, m_Width, m_Height, hdcScreen, 0, 0, SRCCOPY);

    ReleaseDC(m_hWnd, hdcScreen);
  }

  //sssssssssssssssssssssssssssssssss�g
  if(m_BorderColor != 0xFF00FF){
    hbrush = CreateSolidBrush(m_BorderColor);

    rect.left = 0;
    rect.top = 0;
    rect.right = m_Width;
    rect.bottom = m_nBorderTop;

    if(m_nBorderTop)
      FillRect(hdcBack, &rect, hbrush);

    rect.top = m_Height - m_nBorderBottom;
    rect.bottom = m_Height;

    if(m_nBorderBottom)
      FillRect(hdcBack, &rect, hbrush);

    rect.top = 0;
    rect.right = m_nBorderLeft;

    if(m_nBorderLeft)
      FillRect(hdcBack, &rect, hbrush);

    rect.left = m_Width - m_nBorderRight;
    rect.right = m_Width;

    if(m_nBorderRight)
      FillRect(hdcBack, &rect, hbrush);

    DeleteObject(hbrush);
  }

  //sssssssssssssssssssssssssssssssss�o�b�N�O���E���h
  if(m_BGColor != 0xFF00FF){
    rect.left = m_nBorderLeft;
    rect.top = m_nBorderTop;
    rect.right = m_Width - m_nBorderRight;
    rect.bottom = m_Height - m_nBorderBottom;

    hbrush = CreateSolidBrush(m_BGColor);
    FillRect(hdcBack, &rect, hbrush);
    DeleteObject(hbrush);
  }

  //sssssssssssssssssssssssssssssssss�㏈��
  SelectObject(hdcBack, hbmBackOld);
  DeleteDC(hdcBack);
}


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�������\��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void GandharvaSettings::PaintText(HDC hdcDst, LPSTR lpszTextStr)
{
  HFONT font, oldfont;
  HDC textDC;
  HBITMAP textBMP,oldtextBMP;
  int dx,dy,dcx,dcy;
  RECT textRECT,clippedRECT;
  SIZE textSIZE,clippedSIZE;

  int textLength = strlen(lpszTextStr);
  int SeparateWidth,SecondOffset;

  //�e�L�X�g�pDC�Ƀt�H���g��ݒ�
  textDC = CreateCompatibleDC(hdcDst);
#if defined _A2UNVLIB
  font = CreateFontIndirectC(&m_TextLogFont);
#else
  font = CreateFontIndirect(&m_TextLogFont);
#endif
  oldfont = (HFONT)SelectObject(textDC, font);

  //�t�H���g���l�����ĕ����񕝁A�����̎Z�o => textSIZE
  GetTextExtentPoint32(textDC, lpszTextStr, textLength, &textSIZE);

  //�e�L�X�g�T�C�Y�ɂ��킹��BMP���쐬
  textBMP = CreateCompatibleBitmap(hdcDst, textSIZE.cx, textSIZE.cy );
  oldtextBMP = (HBITMAP)SelectObject(textDC, textBMP);

  SetTextColor(textDC, m_FontColor);
  SetBkColor(textDC, 0xFF00FF);

  SelectObject(textDC, font);

  //�e�L�X�g�`��
  textRECT.left = 0;
  textRECT.top = 0;
  textRECT.right = textSIZE.cx;
  textRECT.bottom = textSIZE.cy;

  DrawText(textDC, lpszTextStr, -1, &textRECT, DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX);

  //PaddingSize�����ɃN���b�s���O�̈��ݒ�
  clippedRECT.left = m_nPaddingLeft;
  clippedRECT.top = m_nPaddingTop;
  clippedRECT.right = m_Width - m_nPaddingRight;
  clippedRECT.bottom = m_Height - m_nPaddingBottom;

  clippedSIZE.cx = clippedRECT.right - clippedRECT.left;
  clippedSIZE.cy = clippedRECT.bottom - clippedRECT.top;

  //sssssssssssss�X�N���[������
  //�X�N���[�����s��Ȃ�or�s���K�v���Ȃ��Ȃ�A�I�t�Z�b�g��g�O�ցA�Z�J���h�� TextAlignH �Őݒ�A�\��
  if(!(m_bTitleScroll) || textRECT.right <= clippedSIZE.cx){
    if(m_stimer){
      KillTimer(m_hWnd, TIMERID_SCROLL_INTERVAL);
      m_stimer = NULL;
    }

    m_nScrollOffset=textSIZE.cx;

    switch(m_swTextAlignH){
    case ALIGN_RIGHT:
      SecondOffset = clippedSIZE.cx - textSIZE.cx;
      break;
    case ALIGN_CENTER:
      SecondOffset = (clippedSIZE.cx - textSIZE.cx)/2;
      break;
    default:
      SecondOffset = 0;
      break;
    }
    //�X�N���[�����s���Ȃ�A�Z�J���h�̃I�t�Z�b�g���v�Z
  }else{
    if(!m_stimer)
      m_stimer = SetTimer(m_hWnd, TIMERID_SCROLL_INTERVAL, m_nScrollInterval, NULL);

    SeparateWidth = clippedSIZE.cx/4;
    SecondOffset = textSIZE.cx - m_nScrollOffset + SeparateWidth;

    //�Z�J���h�����֐؂�n�߂���A���C���ƌ��
    if(SecondOffset <= 0){
      m_nScrollOffset = -SecondOffset;
      SecondOffset = textSIZE.cx - m_nScrollOffset + SeparateWidth;
    }
  }

  //  [TTTTTTTT]
  //  |---->��������������
  if(m_nScrollOffset < textSIZE.cx){
    dx = clippedRECT.left;
    dy = clippedRECT.top;
    dcx = min(textSIZE.cx-m_nScrollOffset, clippedSIZE.cx);
    dcy = min(clippedSIZE.cy, textSIZE.cy);

    TransparentBltLS(hdcDst, dx, dy, dcx, dcy, textDC, m_nScrollOffset, 0, 0xFF00FF);
  }
  //        |-------->[TTTTTTT]
  //        ��������������
  if(SecondOffset < clippedSIZE.cx){
    dx = clippedRECT.left+SecondOffset;
    dy = clippedRECT.top;
    dcx = min(clippedSIZE.cx-SecondOffset, textSIZE.cx);
    dcy = min(clippedSIZE.cy, textSIZE.cy);

    TransparentBltLS(hdcDst, dx, dy, dcx, dcy, textDC, 0, 0, 0xFF00FF);
  }

  //�t�H���g�ABMP��߂�
  SelectObject(textDC, oldtextBMP);
  SelectObject(textDC, oldfont);

  //�j��
  DeleteObject(textBMP);
  DeleteObject(font);

  DeleteDC(textDC);
}
