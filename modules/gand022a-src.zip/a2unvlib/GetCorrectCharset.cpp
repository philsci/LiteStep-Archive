#include <windows.h>
#include "a2unvlib.h"

int CALLBACK EnumFontFamExProc(
			ENUMLOGFONTEX *lpelfe,
 			NEWTEXTMETRICEX *lpntme,
 			int FontType,
 			LPARAM lParam)
{
  if(lpelfe->elfLogFont.lfCharSet != *(BYTE *)lParam)
    return 1;

  return 0;
}


DWORD GetCorrectCharset(HDC hTargetDC, LPCTSTR lpszFace)
{
  BYTE nCharSet;// = (BYTE)GetTextCharset(hTargetDC);
  CHARSETINFO csi;
  TranslateCharsetInfo((LPDWORD)GetACP(), &csi, TCI_SRCCODEPAGE);

  nCharSet = csi.ciCharset;
  
  if (lpszFace[0] == NULL || lpszFace == NULL || hTargetDC == NULL)
    return nCharSet;
  
  LOGFONT lf;
  memset(&lf, 0, sizeof lf);
  
  strcpy(lf.lfFaceName, lpszFace);
  lf.lfCharSet = DEFAULT_CHARSET;
  lf.lfPitchAndFamily=0;

  if(EnumFontFamiliesEx(hTargetDC, &lf, (FONTENUMPROC)EnumFontFamExProc, (LPARAM)&nCharSet, NULL))
    nCharSet = DEFAULT_CHARSET;

  return nCharSet;
}
