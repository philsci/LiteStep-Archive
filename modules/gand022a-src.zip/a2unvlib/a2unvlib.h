/*  CreateFontY */

int CALLBACK EnumFontFamExProc(
			ENUMLOGFONTEX *lpelfe,
 			NEWTEXTMETRICEX *lpntme,
 			int FontType,
 			LPARAM lParam);

DWORD GetCorrectCharset(HDC hTargetDC, LPCTSTR lpszFace);

HFONT CreateFontC(
  int nHeight, // logical height of font
  int nWidth, // logical average character width
  int nEscapement, // angle of escapement
  int nOrientation, // base-line orientation angle
  int fnWeight, // font weight
  DWORD fdwItalic, // italic attribute flag
  DWORD fdwUnderline, // underline attribute flag
  DWORD fdwStrikeOut, // strikeout attribute flag
  DWORD fdwCharSet, // character set identifier
  DWORD fdwOutputPrecision, // output precision
  DWORD fdwClipPrecision, // clipping precision
  DWORD fdwQuality, // output quality
  DWORD fdwPitchAndFamily, // pitch and family
  LPCTSTR lpszFace // pointer to typeface name string
);

HFONT CreateFontIndirectC(LOGFONT *lplf);

