#include "grdIconsWrapper.h"
#include "lsapi.h"

// blending raster
// the source image is inverted and the anded with the dest
#define INVERTSRCAND         0x00220326 // DSna

#define REGKEY_SAVEDDATA     TEXT("Software\\Litestep\\Systray\\SavedData")



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: grdIconsWrapper()                             * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hTray                                            * */
/* *   the system tray window                                * */
/* *                                                         * */
/* *   HWND hParent                                          * */
/* *   the litestep window                                   * */
/* *                                                         * */
/* *   grdSysTraySettings *cfg                               * */
/* *   reference to the settings sub-class                   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: initialize the iconsWrapper class              * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdIconsWrapper::grdIconsWrapper( HWND hTray, HWND hParent, grdSysTraySettings *cfg ) {

	// save the params
	this->hSysTray = hTray;
	this->hLiteStep = hParent;
	this->settings = cfg;

	// create a tooltip window
	this->hToolTip = CreateWindowEx( WS_EX_TOOLWINDOW | WS_EX_TOPMOST, TOOLTIPS_CLASS,
									 NULL,
									 TTS_ALWAYSTIP | WS_POPUP,
									 0,0,
									 0,0,
									 this->hSysTray,
									 NULL,
									 NULL,
									 NULL );

	this->uLastID = 1;

	this->pFirst = NULL;
	this->pLast = NULL;

	this->loadRCIcons();

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: ~grdIconsWrapper()                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: destroy the iconsWrapper class                 * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdIconsWrapper::~grdIconsWrapper() {

	// destroy the list of icons
	this->delList();

	// destroy the tooltip window
	if ( this->hToolTip )
		DestroyWindow( this->hToolTip );
	this->hToolTip = NULL;

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: BOOL delList()                                * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: empty the list of icons                        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

BOOL grdIconsWrapper::delList() {

	PGRDSYSTRAYICON pTemporarySysTrayIcon, pTemporarySysTrayIcon2;

	// 	delete the items in the wrapper
	if ( this->pFirst ) {

		// start iterating the history items
		pTemporarySysTrayIcon = this->pFirst;

		do {

			// save the one to be deleted and move to the next
			pTemporarySysTrayIcon2 = pTemporarySysTrayIcon->pNext;

			// delete this history item
			this->delInside( pTemporarySysTrayIcon );

			pTemporarySysTrayIcon  = pTemporarySysTrayIcon2;

		} while ( pTemporarySysTrayIcon != NULL );

	}
	return TRUE;

}

void grdIconsWrapper::getRgn( PGRDSYSTRAYICON pSysTrayIcon ) {

	// a nullbmp
	HBITMAP hBmp = NULL;

	if ( pSysTrayIcon->hRgn )
		DeleteObject( pSysTrayIcon->hRgn );

	pSysTrayIcon->hRgn = CreateRectRgn(0,0,0,0);
	
	if ( pSysTrayIcon->hIcon && this->settings->bTranspBack ) {

		HDC hdc = CreateCompatibleDC( NULL );
		HBITMAP hbmOld;
		HBITMAP hbmNew = CreateCompatibleBitmap( hdc, this->settings->uIconSize, this->settings->uIconSize );
			
		hbmOld = (HBITMAP) SelectObject( hdc, hbmNew );

		if ( DrawIconEx( hdc, 0, 0, pSysTrayIcon->hIcon, this->settings->uIconSize, this->settings->uIconSize, 0, NULL, DI_MASK ) ) {

			UINT y = 0;

			while ( y < this->settings->uIconSize ) {

				UINT x = 0;

				while ( x < this->settings->uIconSize ) {

					UINT firstNTX = 0;

					// loop through all transparent pixels...
					while ( x < this->settings->uIconSize ) {

						// if the pixel is white, then break
						if ( !GetPixel(hdc, x, y) )
							break;
						x++;

					}
					
					// set first non transparent pixel
					firstNTX = x;
					
					// loop through all non transparent pixels
					while ( x < this->settings->uIconSize ) {

						// if the pixel is white, then break
						if ( GetPixel(hdc, x, y) )
							break;
						x++;

					}

					// if found one or more non-transparent pixels in a row, add them to the rgn...
					if ( (x-firstNTX) > 0 ) {

						HRGN hTempRgn = CreateRectRgn(firstNTX, y, x, y + 1);
						CombineRgn(pSysTrayIcon->hRgn, pSysTrayIcon->hRgn, hTempRgn, RGN_OR);
						DeleteObject(hTempRgn);

					}
					x++;

				}
				y++;

			}

		}
		SelectObject( hdc, hbmOld );
		DeleteDC(hdc);
		DeleteObject( hbmNew );

	}

}

void grdIconsWrapper::autoSize() {

	RECT rcOrg;
	int x,y,cx,cy;

	// this is the new size...
	if ( this->pLast ) {

	    cx = this->settings->uIconSize + this->settings->nIconSpacingX + this->settings->uBorderRight + ( ( !(this->settings->uDirection & TD_VERTICAL) && ( this->pLast->rc.top > this->settings->nFirstY ) ) ? this->settings->nLastX : this->pLast->rc.left );
		cy = this->settings->uIconSize + this->settings->nIconSpacingY + this->settings->uBorderBottom + ( ( (this->settings->uDirection & TD_VERTICAL) && ( this->pLast->rc.left > this->settings->nFirstX ) ) ? this->settings->nLastY : this->pLast->rc.top );

	} else {

		cx = this->settings->uBorderLeft + this->settings->uBorderRight;
		cy = this->settings->uBorderTop + this->settings->uBorderBottom;

	}
			
	// position it according to the old position
	GetWindowRect( this->hSysTray, &rcOrg );

	x = ( ( this->settings->uDirection == TD_RIGHT ) || ( this->settings->uWrapDirection == TD_RIGHT ) ) ? rcOrg.left : rcOrg.right - cx;
	y = ( ( this->settings->uDirection == TD_DOWN ) || ( this->settings->uWrapDirection == TD_DOWN ) ) ? rcOrg.top : rcOrg.bottom - cy;

	
	this->settings->setPos( x, y, cx, cy, NULL, TRUE );

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON add()                         * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   PNOTIFYICONDATA pnid                                  * */
/* *   data structure with information about the icon        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: add icon to the list                           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

PGRDSYSTRAYICON grdIconsWrapper::add( PNOTIFYICONDATA pnid ) {

	PGRDSYSTRAYICON pSysTrayIcon;
	TOOLINFO ti;
	
	if( !IsWindow( pnid->hWnd ) )
		return NULL;

	// check if the icon already exists
	pSysTrayIcon = this->find( pnid->hWnd, pnid->uID );

	// if found, modify instead of add
	if ( pSysTrayIcon != NULL ) 
		return this->modify( pnid );

	// if not found (which is the way it should go)
	pSysTrayIcon = (PGRDSYSTRAYICON)new BYTE[ sizeof(GRDSYSTRAYICON) ];

	pSysTrayIcon->hWnd             = pnid->hWnd;
	pSysTrayIcon->uID              = pnid->uID;
	pSysTrayIcon->uFlags           = pnid->uFlags;

	pSysTrayIcon->uCallbackMessage = ( pSysTrayIcon->uFlags & NIF_MESSAGE ) ? pnid->uCallbackMessage : NULL;

	pSysTrayIcon->hRgn             = NULL;
	pSysTrayIcon->hIcon	           = ( pSysTrayIcon->uFlags & NIF_ICON ) ? CopyIcon( pnid->hIcon ) : NULL;

	this->getRgn( pSysTrayIcon );

	if ( pSysTrayIcon->uFlags & NIF_TIP ) {

			int length = strlen( pnid->szTip ) + 1;	

			pSysTrayIcon->szTip = new TCHAR[ length ];
			
			lstrcpyn( pSysTrayIcon->szTip, pnid->szTip, length );
	
	} else {

		pSysTrayIcon->szTip = NULL;

	}

	pSysTrayIcon->uToolTip = this->uLastID++;

	// add to last position in the list
	if ( !this->pFirst ) {

		this->pFirst = pSysTrayIcon;
		pSysTrayIcon->pPrev = NULL;

	} 
		
	if ( this->pLast ) {

		pSysTrayIcon->pPrev = this->pLast;
		pSysTrayIcon->pPrev->pNext = pSysTrayIcon;

	}

	this->pLast = pSysTrayIcon;

	pSysTrayIcon->pNext = NULL;
	
	/* **************************** */
	/* *   ADJUST THE RECTANGLE   * */
	/* **************************** */

	if ( pSysTrayIcon->pPrev ) {

		if ( !(this->settings->uDirection & TD_VERTICAL) ) {

			// if there is room for one more icon
			if ( pSysTrayIcon->pPrev->rc.left != this->settings->nLastX ) {

				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + this->settings->nDeltaX;
				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top;
			
			} else {

				pSysTrayIcon->rc.left = this->settings->nFirstX;
				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + this->settings->nDeltaY;

			}

		} else {

			// if there is room for one more icon
			if ( pSysTrayIcon->pPrev->rc.top != this->settings->nLastY ) {

				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + this->settings->nDeltaY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left;
			
			} else {

				pSysTrayIcon->rc.top = this->settings->nFirstY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + this->settings->nDeltaX;

			}

		}

	} else {

		pSysTrayIcon->rc.left = this->settings->nFirstX;
		pSysTrayIcon->rc.top = this->settings->nFirstY;

	}


	pSysTrayIcon->rc.right = pSysTrayIcon->rc.left + this->settings->uIconSize;
	pSysTrayIcon->rc.bottom = pSysTrayIcon->rc.top + this->settings->uIconSize;

	/* **************************** */
	/* *    END OF ADJUSTATION    * */
	/* **************************** */

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = this->hSysTray;
	ti.uId = pSysTrayIcon->uToolTip;
	ti.rect = pSysTrayIcon->rc;
	ti.hinst = NULL;
	// this member either has a string or is NULL
	ti.lpszText = ( pSysTrayIcon->uFlags & NIF_TIP ) ? pSysTrayIcon->szTip : NULL ;
	
	SendMessage( this->hToolTip, TTM_ADDTOOL, 0, (LPARAM) &ti );

	// if it's the first icon, send an SHOW message
	if ( this->pFirst == pSysTrayIcon )
		if ( this->settings->bHideIfEmpty ) ShowWindow( this->hSysTray, SW_SHOWNOACTIVATE );

	// remove "unwanted" icons
	else
		this->cleanup();

	if ( this->settings->bAutoSize )
		this->autoSize(); // which will repaint the window
	else
		InvalidateRect( this->hSysTray, &pSysTrayIcon->rc, TRUE );

	
	// return the newly created icon
	return pSysTrayIcon;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON del()                         * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   PNOTIFYICONDATA pnid                                  * */
/* *   data structure with information about the icon        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: remove icon from the list                      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

BOOL grdIconsWrapper::del( PNOTIFYICONDATA pnid ) {

	PGRDSYSTRAYICON pSysTrayIcon;
	BOOL retVal = FALSE;

	pSysTrayIcon = this->find( pnid->hWnd, pnid->uID );

	retVal = this->delInside( pSysTrayIcon );

	return retVal;

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: BOOL delInside()                              * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   PGRDSYSTRAYICON pSysTrayIcon                          * */
/* *   data structure with information about the icon        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: remove icon from the list                      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

BOOL grdIconsWrapper::delInside( PGRDSYSTRAYICON pSysTrayIcon ) {
	
	PGRDSYSTRAYICON pIteratorSysTrayIcon;
	TOOLINFO ti;

	if( !pSysTrayIcon )
		return FALSE;
	
	if( ( pSysTrayIcon->uFlags & NIF_ICON ) && pSysTrayIcon->hIcon )
		DestroyIcon( pSysTrayIcon->hIcon );

	if( pSysTrayIcon->hRgn )
		DeleteObject( pSysTrayIcon->hRgn );
	
	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = this->hSysTray;
	ti.uId = pSysTrayIcon->uToolTip;
	
	SendMessage( this->hToolTip, TTM_DELTOOL, 0, (LPARAM) &ti );

	// delete the tip, if there is any
	if ( pSysTrayIcon->szTip )
		delete[] pSysTrayIcon->szTip;

	// change all the rectangles and update the tooltips
	pIteratorSysTrayIcon = this->pLast;

	while ( pIteratorSysTrayIcon != pSysTrayIcon ) {

		pIteratorSysTrayIcon->rc = pIteratorSysTrayIcon->pPrev->rc;

		if( pIteratorSysTrayIcon->uFlags & NIF_TIP ) {

			ti.hwnd = this->hSysTray;
			ti.uId = pIteratorSysTrayIcon->uToolTip;
			ti.rect = pIteratorSysTrayIcon->rc;
			
			SendMessage( hToolTip, TTM_NEWTOOLRECT, 0, (LPARAM) &ti );

		}

		pIteratorSysTrayIcon = pIteratorSysTrayIcon->pPrev;

	}

	// if it's first or last, move those pointers
	if ( this->pFirst == pSysTrayIcon )
		this->pFirst = pSysTrayIcon->pNext;
	else
		pSysTrayIcon->pPrev->pNext = pSysTrayIcon->pNext;


	if ( this->pLast == pSysTrayIcon )
		this->pLast = pSysTrayIcon->pPrev;
	else
		pSysTrayIcon->pNext->pPrev = pSysTrayIcon->pPrev;

	delete[] pSysTrayIcon;

	// update the window
	if ( !this->pFirst && this->settings->bHideIfEmpty )
		ShowWindow( this->hSysTray, SW_HIDE );

	else if ( this->settings->bAutoSize )
		this->autoSize();

	else
		InvalidateRect( this->hSysTray, NULL, TRUE );


	return TRUE;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON modify()                      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   PNOTIFYICONDATA pnid                                  * */
/* *   data structure with information about the icon        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: modify icon in the list                        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

PGRDSYSTRAYICON grdIconsWrapper::modify( PNOTIFYICONDATA pnid ) {

	PGRDSYSTRAYICON pTemporarySysTrayIcon;
	TOOLINFO ti;
	
	// check if the icon already exists
	pTemporarySysTrayIcon = this->find( pnid->hWnd, pnid->uID );

	// if not found, add instead of modify
	if ( pTemporarySysTrayIcon == NULL ) 
		return this->add( pnid );


	if( pnid->uFlags & NIF_MESSAGE ) {

		pTemporarySysTrayIcon->uFlags |= NIF_MESSAGE;
		pTemporarySysTrayIcon->uCallbackMessage = pnid->uCallbackMessage;

	}
	
	if( pnid->uFlags & NIF_TIP ) {

		int length = strlen( pnid->szTip ) + 1;

		if ( pTemporarySysTrayIcon->uFlags & NIF_TIP )
			delete[] pTemporarySysTrayIcon->szTip;

		// new tip to add
		if ( length > 1 ) {

			pTemporarySysTrayIcon->szTip = new TCHAR[ length ];
			lstrcpyn( pTemporarySysTrayIcon->szTip, pnid->szTip, length );

			pTemporarySysTrayIcon->uFlags |= NIF_TIP;

		} else {

			pTemporarySysTrayIcon->szTip = NULL;

		}
		
		ti.cbSize = sizeof(TOOLINFO);
		ti.hwnd = this->hSysTray;
		ti.uId = pTemporarySysTrayIcon->uToolTip;
		ti.hinst = NULL;
		ti.lpszText = ( pTemporarySysTrayIcon->uFlags & NIF_TIP ) ? pTemporarySysTrayIcon->szTip : NULL;	
		
		SendMessage( this->hToolTip, TTM_UPDATETIPTEXT, 0, (LPARAM) &ti );

	}
	
	if( pnid->uFlags & NIF_ICON ) {

		// delete old icon (if there is one)
		if ( pTemporarySysTrayIcon->hIcon )
			DestroyIcon( pTemporarySysTrayIcon->hIcon );
		
		pTemporarySysTrayIcon->uFlags |= NIF_ICON;

		pTemporarySysTrayIcon->hIcon = CopyIcon( pnid->hIcon );

		this->getRgn( pTemporarySysTrayIcon );
		
		InvalidateRect( this->hSysTray, &pTemporarySysTrayIcon->rc, TRUE );

	}

	// remove "unwanted" icons
	this->cleanup();

	// return the "refreshed" icon
	return pTemporarySysTrayIcon;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON find()                        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   icon's owner window                                   * */
/* *                                                         * */
/* *   UINT uID                                              * */
/* *   an ID identifying the icon                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: find icon in the list based on owner and ID    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

PGRDSYSTRAYICON grdIconsWrapper::find( HWND hWnd, UINT uID ) {

	PGRDSYSTRAYICON pTemporarySysTrayIcon = this->pFirst;
	
	while( pTemporarySysTrayIcon ) {

		if( ( pTemporarySysTrayIcon->hWnd == hWnd ) && ( pTemporarySysTrayIcon->uID == uID ) )
			return pTemporarySysTrayIcon;
		
		pTemporarySysTrayIcon = pTemporarySysTrayIcon->pNext;

	}
	
    return NULL;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON find()                        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   icon's owner window                                   * */
/* *                                                         * */
/* *   UINT uID                                              * */
/* *   an ID identifying the icon                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: find icon in the list based on owner and ID    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void grdIconsWrapper::cleanup() {

	PGRDSYSTRAYICON pSysTrayIcon = this->pFirst;
	PGRDSYSTRAYICON pSysTrayIcon2 = NULL;
	
	while( pSysTrayIcon ) {

		pSysTrayIcon2 = pSysTrayIcon->pNext;

		if( !IsWindow( pSysTrayIcon->hWnd )  )
			this->delInside( pSysTrayIcon );
		
		pSysTrayIcon = pSysTrayIcon2;

	}
	
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: PGRDSYSTRAYICON findPt()                      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   POINT pt                                              * */
/* *   the point where there should be an icon beneath?      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: find icon in the list based on a point         * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

PGRDSYSTRAYICON grdIconsWrapper::findPt( POINT pt ) {

	PGRDSYSTRAYICON pTemporarySysTrayIcon = this->pFirst;
	
	while( pTemporarySysTrayIcon ) {

		if( PtInRect( &pTemporarySysTrayIcon->rc, pt ) )

			// return NULL if it's parent is dead
			return ( IsWindow( pTemporarySysTrayIcon->hWnd ) ) ? pTemporarySysTrayIcon : NULL;
		
		pTemporarySysTrayIcon = pTemporarySysTrayIcon->pNext;

	}
	
    return NULL;

}



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: void iconsOut()                               * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HDC hdcDest                                           * */
/* *   the destination dc                                    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: print out the icons on a specific dc           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void grdIconsWrapper::iconsOut( HDC hdcDst, HRGN hrgnDst ) {

	PGRDSYSTRAYICON pTemporarySysTrayIcon = this->pFirst;

	while( pTemporarySysTrayIcon ) {

        if( pTemporarySysTrayIcon->uFlags & NIF_ICON ) {

			if( this->settings->uEffectFlags & FX_ANY ) {

				HDC hdcMask, hdcMem;
				HBITMAP hbmMaskOld;

				ICONINFO iconInfo;
					
				// load the icons HBITMAPs (mask & color bitmap)
				GetIconInfo( pTemporarySysTrayIcon->hIcon, &iconInfo );

				// load the MASK into one dc
				hdcMask    = CreateCompatibleDC( hdcDst );
				hbmMaskOld = (HBITMAP) SelectObject( hdcMask, iconInfo.hbmMask );

				// create a dc consist of the new bitmap
				hdcMem = CreateCompatibleDC( hdcDst );

				if ( hdcMem ) {

					BITMAP bm;					// Get bitmap size
					HBITMAP hbm32;				// the new 32 bit bitmap
					BITMAPINFOHEADER bmInfo;	// bitmapinfoheader for above
					VOID *pbits32;

					// get bitmap size
					GetObject( iconInfo.hbmColor, sizeof(bm), &bm ); 

					// set everything to 0
					memset( &bmInfo, 0, sizeof(BITMAPINFOHEADER) );

					// Create a 32 bits depth bitmap
					bmInfo.biSize = sizeof(BITMAPINFOHEADER);
					bmInfo.biWidth = bm.bmWidth;
					bmInfo.biHeight = bm.bmHeight;
					bmInfo.biPlanes = 1;
					bmInfo.biBitCount = 32;
					bmInfo.biCompression = BI_RGB;

					hbm32 = CreateDIBSection( hdcMem,
											  (BITMAPINFO*) &bmInfo,
											  DIB_RGB_COLORS,
											  &pbits32,
											  NULL,
											  0);

					if ( hbm32 ) {

						// select the new bitmap into memory
						HBITMAP hbmOld32 = (HBITMAP) SelectObject( hdcMem, hbm32 );

						// create a new dc for copying
						HDC hdcSrc = CreateCompatibleDC( hdcDst );

						if ( hdcSrc ) {

							BITMAP bm32;
							HBITMAP hbmOldSrc;
							BYTE *p32;
							int y, x;

							// get the bits from hbm32
							GetObject( hbm32, sizeof(bm32), &bm32 );

							// Get how many bytes per row we have for the bitmap bits (rounded up to 32 bits)
							while ( bm32.bmWidthBytes % 4 )
								bm32.bmWidthBytes++;

							// copy the original bitmap into it's dc
							hbmOldSrc = (HBITMAP) SelectObject( hdcSrc, iconInfo.hbmColor );
							// copy the original bitmaps contents into the new one
							BitBlt(hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, hdcSrc, 0, 0, SRCCOPY);

							// scan each bitmap row from bottom to top (the bitmap is inverted vertically)
							p32 = (BYTE*) bm32.bmBits + (bm32.bmHeight - 1) * bm32.bmWidthBytes;

							for (y = 0; y < bm.bmHeight; y++) {

								// go through every pixel from left to right
								for (x = 0; x < bm.bmWidth; x++) {

									// *p gets the color value of the pixel,
									// which can be freely modified
									DWORD *p = (DWORD*) p32 + x;
									BYTE   r = GetRValue( *p );
									BYTE   g = GetGValue( *p );
									BYTE   b = GetBValue( *p );

									// saturnation effect
									if ( this->settings->uEffectFlags & FX_SATURNATION ) {

										//float fSaturnation = (float)this->settings->uSaturnation / (float)255;

										BYTE gray = (BYTE)(r * 0.3086 + g * 0.6094 + b * 0.0820);

										r = (BYTE)( ( r * this->settings->uSaturnation + gray * (255 - this->settings->uSaturnation) + 255 ) >> 8 );
										g = (BYTE)( ( g * this->settings->uSaturnation + gray * (255 - this->settings->uSaturnation) + 255 ) >> 8 );
										b = (BYTE)( ( b * this->settings->uSaturnation + gray * (255 - this->settings->uSaturnation) + 255 ) >> 8 );

									}

									// icon hue effect
									if ( this->settings->uEffectFlags & FX_ICONHUE ) {

										//float fHueIntensity = (float)this->settings->uHueIntensity / (float)255;

										// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
										r = (BYTE)( ( r * (255 - this->settings->uHueIntensity) + GetBValue(this->settings->clrHue) * this->settings->uHueIntensity + 255 ) >> 8 );
										g = (BYTE)( ( g * (255 - this->settings->uHueIntensity) + GetGValue(this->settings->clrHue) * this->settings->uHueIntensity + 255 ) >> 8 );
										b = (BYTE)( ( b * (255 - this->settings->uHueIntensity) + GetRValue(this->settings->clrHue) * this->settings->uHueIntensity + 255 ) >> 8 );

									}

									*p = RGB( r, g, b );

								}

								// Go to next row (remember, the bitmap is inverted vertically)
								p32 -= bm32.bmWidthBytes;
							}

							// Clean up
							SelectObject( hdcSrc, hbmOldSrc );
							DeleteDC( hdcSrc );

							// remove unwanted information from the modified			
							BitBlt( hdcMem,0,0,bm.bmWidth,bm.bmHeight,hdcMask,0,0,INVERTSRCAND );

							// do an "transparency blit onto the destionation buffer, using mask as mask and icon as source
							StretchBlt( hdcDst, pTemporarySysTrayIcon->rc.left, pTemporarySysTrayIcon->rc.top, this->settings->uIconSize, this->settings->uIconSize, hdcMask, 0, 0, bm.bmWidth, bm.bmHeight, SRCAND );
							// Combine the foreground with the background
							StretchBlt( hdcDst, pTemporarySysTrayIcon->rc.left, pTemporarySysTrayIcon->rc.top, this->settings->uIconSize, this->settings->uIconSize, hdcMem , 0, 0, bm.bmWidth, bm.bmHeight, SRCPAINT );

						}
						SelectObject( hdcMem, hbmOld32 );
						DeleteObject( hbm32 );

					}
					DeleteDC( hdcMem );

				}

				SelectObject( hdcMask, hbmMaskOld );
				DeleteDC( hdcMask );

				DeleteObject( iconInfo.hbmMask  );
				DeleteObject( iconInfo.hbmColor );


			} else {

				DrawIconEx( hdcDst, pTemporarySysTrayIcon->rc.left, pTemporarySysTrayIcon->rc.top, pTemporarySysTrayIcon->hIcon, this->settings->uIconSize, this->settings->uIconSize, 0, NULL, DI_NORMAL );

			}

			if ( pTemporarySysTrayIcon->hRgn && this->settings->bTranspBack ) { 

				OffsetRgn( pTemporarySysTrayIcon->hRgn, pTemporarySysTrayIcon->rc.left, pTemporarySysTrayIcon->rc.top );
				CombineRgn( hrgnDst, hrgnDst, pTemporarySysTrayIcon->hRgn, RGN_OR );
				OffsetRgn( pTemporarySysTrayIcon->hRgn, -pTemporarySysTrayIcon->rc.left, -pTemporarySysTrayIcon->rc.top );

			}

		}

		pTemporarySysTrayIcon = pTemporarySysTrayIcon->pNext;

	}

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: int save()                                    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   void *dst                                             * */
/* *   the destination buffer                                * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: save icon structures into the buffer           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

int grdIconsWrapper::save(void *dst) {

	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)dst;

	PGRDSYSTRAYICON pSysTrayIcon = NULL;
	
	int i = 0;

	this->cleanup();
	
	pSysTrayIcon = this->pFirst;

	while ( pSysTrayIcon ) {

		if ( pSysTrayIcon->hWnd != this->hSysTray ) {

			// set the saving data based on the list
			trayArray[i].cbSize				= sizeof(NOTIFYICONDATA);
			trayArray[i].hWnd				= pSysTrayIcon->hWnd;
			trayArray[i].uID				= pSysTrayIcon->uID;
			trayArray[i].uFlags				= pSysTrayIcon->uFlags;
			trayArray[i].uCallbackMessage	= pSysTrayIcon->uCallbackMessage;
			trayArray[i].hIcon				= CopyIcon( pSysTrayIcon->hIcon );
			lstrcpyn( trayArray[i].szTip, pSysTrayIcon->szTip, 64 );

			i++;

		}
		pSysTrayIcon = pSysTrayIcon->pNext;

	}

	trayArray[i].hWnd = 0;

	return i;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: int load()                                    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   void *src                                             * */
/* *   the source buffer                                     * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: load icon structures from the buffer           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

int grdIconsWrapper::load(void *src) {

	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)src;

	int i = 0;

	if ( src != NULL ) {

		while ( trayArray[i].hWnd != 0 ) {

			// add all icons from the buffer
			SendMessage( this->hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM)&trayArray[i] );

			DestroyIcon( trayArray[i].hIcon );
			i++;

		}

	}

	return i;

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: int loadMaudin()                              * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: loads icon the same way as systray does        * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

int grdIconsWrapper::loadMaduin() {

	// icon information			
	NOTIFYICONDATA *trayArray;
	DWORD dwIconCount = 0;

	unsigned int i = 0;

	// subkey
	HKEY hSubKey = NULL;
	// registry values needed
	DWORD dwDataType;
	DWORD dwDataSize = sizeof(DWORD);
	
	// open the regestry subkey
	if( RegOpenKeyEx( HKEY_CURRENT_USER, REGKEY_SAVEDDATA, 0, KEY_QUERY_VALUE, &hSubKey ) == ERROR_SUCCESS ) {

		// get the number of icons
		if( RegQueryValueEx( hSubKey, TEXT("IconCount"), NULL, &dwDataType, (LPBYTE) &dwIconCount, &dwDataSize ) == ERROR_SUCCESS ) {
			
			// if not everything worked perfectly return 0
			if( ( dwDataType == REG_DWORD ) && ( dwDataSize == sizeof(DWORD) ) ) {

				dwDataSize = dwIconCount * sizeof(NOTIFYICONDATA);

				trayArray = (PNOTIFYICONDATA) new BYTE[ dwDataSize ];
						
				if( trayArray ) {

					if( RegQueryValueEx( hSubKey, TEXT("Icons"), NULL, &dwDataType, (LPBYTE) trayArray, &dwDataSize ) == ERROR_SUCCESS ) {
					
						if( dwDataType == REG_BINARY ) {

							for( i = 0; i < dwIconCount; i++ ) {

								if( IsWindow( trayArray[i].hWnd ) )
									SendMessage( this->hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) &trayArray[i] );
								
								// as this module does not remove the icons array from memory
								// it's not very wise to remove the HICONs
								//if( trayArray[i].uFlags & NIF_ICON )
								//	DestroyIcon( trayArray[i].hIcon );

							}

						}

					}
					delete[] trayArray;

				}

			}

		}
		// close the registry subkey
		RegCloseKey( hSubKey );

	}

	return (int)(i + 1);

}

int grdIconsWrapper::loadRCIcons() {

	FILE * f;
	char buffer[4096];
	int iAdd = 0;

	f = LCOpen(NULL);

	if (f) {

		while ( LCReadNextConfig ( f, TEXT("*grdTrayAdd"), buffer, 4096 ) ) {

			// 12 is because we don't need the part "*grdTrayAdd "
			if ( this->addRC( (char *)(buffer+12) ) )
				iAdd++;

		}

		LCClose(f);

	}
	return iAdd;

}

PGRDSYSTRAYICON grdIconsWrapper::addRC( char *config ) {

	// temporary variables to store settings that
	// eventually will be used for this icon
	char   *szOnClick = NULL;
	HICON   hIcon = NULL;
    
	// gets the settings
	char    szBuffer[4096];
	// gets one valuename (inc value) at the time
    char	vName[4096];
	char   *vValue;
	// array with tokens
	char*	tokens[1];

	// prepare for launching LCTokenize
	tokens[0] = vName;
    VarExpansion( szBuffer, config );

    do {

        vName[0] = '\0';

        // split the string into tokens (one at a time)
        LCTokenize (szBuffer, tokens, 1, szBuffer);

		// find the delimiter
        vValue = strchr(vName,'=');

		if ( vValue ) {

			// and split into name/value pair
			*vValue = '\0';
			vValue++;

			if ( !strnicmp(vName, TEXT("icon"), 5) ) {

				if ( hIcon )
					DestroyIcon( hIcon );

				hIcon = LoadLSIcon( vValue, NULL );

			} else if ( !strnicmp(vName, TEXT("onclick"), 8) ) {

				if ( szOnClick )
					delete[] szOnClick;

				szOnClick = new char[ lstrlen( vValue ) + 1 ];
				strcpy( szOnClick, vValue );

			}
			//else if ( !strnicmp(vName, "tip", 4) )
			//	strcpy( szTip, vValue );

		}

    } while ( *szBuffer );

	// if enough info is provided, add an icon
	if ( hIcon || ( szOnClick && *szOnClick ) ) {

		// if not found (which is the way it should go)
		PGRDSYSTRAYICON pSysTrayIcon = (PGRDSYSTRAYICON)new BYTE[ sizeof(GRDSYSTRAYICON) ];

		pSysTrayIcon->hWnd             = this->hSysTray;
		pSysTrayIcon->uID              = NULL;
		pSysTrayIcon->uFlags           = ( ( hIcon ) ? NIF_ICON : NULL ) | ( ( szOnClick && *szOnClick ) ? NIF_TIP : NULL );

		pSysTrayIcon->uCallbackMessage = NULL;

		pSysTrayIcon->hRgn             = NULL;
		pSysTrayIcon->hIcon	           = hIcon;

		this->getRgn( pSysTrayIcon );

		pSysTrayIcon->szTip			   = szOnClick;
		pSysTrayIcon->uToolTip		   = NULL;

		// add to last position in the list
		if ( !this->pFirst ) {

			this->pFirst = pSysTrayIcon;
			pSysTrayIcon->pPrev = NULL;

		} 
			
		if ( this->pLast ) {

			pSysTrayIcon->pPrev = this->pLast;
			pSysTrayIcon->pPrev->pNext = pSysTrayIcon;

		}

		this->pLast = pSysTrayIcon;

		pSysTrayIcon->pNext = NULL;
		
		/* **************************** */
		/* *   ADJUST THE RECTANGLE   * */
		/* **************************** */

		if ( pSysTrayIcon->pPrev ) {

			if ( !(this->settings->uDirection & TD_VERTICAL) ) {

				// if there is room for one more icon
				if ( pSysTrayIcon->pPrev->rc.left != this->settings->nLastX ) {

					pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + this->settings->nDeltaX;
					pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top;
				
				} else {

					pSysTrayIcon->rc.left = this->settings->nFirstX;
					pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + this->settings->nDeltaY;

				}

			} else {

				// if there is room for one more icon
				if ( pSysTrayIcon->pPrev->rc.top != this->settings->nLastY ) {

					pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + this->settings->nDeltaY;
					pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left;
				
				} else {

					pSysTrayIcon->rc.top = this->settings->nFirstY;
					pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + this->settings->nDeltaX;

				}

			}

		} else {

			pSysTrayIcon->rc.left = this->settings->nFirstX;
			pSysTrayIcon->rc.top = this->settings->nFirstY;

		}


		pSysTrayIcon->rc.right = pSysTrayIcon->rc.left + this->settings->uIconSize;
		pSysTrayIcon->rc.bottom = pSysTrayIcon->rc.top + this->settings->uIconSize;

		/* **************************** */
		/* *    END OF ADJUSTATION    * */
		/* **************************** */

		// if it's the first icon, send an SHOW message
		if ( this->pFirst == pSysTrayIcon )
			if ( this->settings->bHideIfEmpty )
				ShowWindow( this->hSysTray, SW_SHOWNOACTIVATE );

		// remove "unwanted" icons
		else
			this->cleanup();

		if ( this->settings->bAutoSize )
			this->autoSize(); // which will repaint the window
		else
			InvalidateRect( this->hSysTray, &pSysTrayIcon->rc, TRUE );

		
		// return the newly created icon
		return pSysTrayIcon;

	} else {

		if ( hIcon )
			DestroyIcon( hIcon );

		if ( szOnClick )
			delete[] szOnClick;

	}

	return NULL;
}
