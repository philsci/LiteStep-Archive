#ifndef EXPORTS_H
#define EXPORTS_H

#ifdef __cplusplus
extern "C" {
#endif
    
/* LOAD-MODULE Functions */
__declspec( dllexport ) int initModuleEx( HWND lswnd, HINSTANCE lsinstance, LPCTSTR lspath );
__declspec( dllexport ) int quitModule( HINSTANCE lsinstance );

/* WHARF-MODULE Functions */
__declspec( dllexport ) int initWharfModule( HWND parent, HINSTANCE lsinstance, void *wharfData );
__declspec( dllexport ) int quitWharfModule( HINSTANCE lsinstance );

#ifdef __cplusplus
}
#endif

#endif