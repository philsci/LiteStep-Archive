
#include "grdSysTraySettings.h"

int grdBitBlt ( HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, BOOL bTransparent );
int grdStretchTileBlt ( HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, BOOL bTiled, BOOL bTransparent );


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: grdSysTraySettings()                          * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: initialize the sysTraySettings class           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdSysTraySettings::grdSysTraySettings( BOOL inWharf, HWND hParentWnd ) {

    char *tmpString = new char[256];
	int tmpInteger = 0;

	this->hParent = hParentWnd;

	// style booleans
    this->bAlwaysOnTop = GetRCBool(TEXT("grdTrayAlwaysOnTop"),TRUE);
	this->bVisible = GetRCBool(TEXT("grdTrayHidden"),FALSE);
	this->bHideIfEmpty = GetRCBool(TEXT("grdTrayHideIfEmpty"),TRUE);
	this->bInWharf = inWharf;

	// tray, SPECIAL FOR WHARF
	if ( this->bInWharf ) {

		RECT rc;
		tmpInteger = GetRCInt(TEXT("WharfBevelWidth"),0);

		GetClientRect( this->hParent, &rc );

		this->nTrayX      = tmpInteger;
		this->nTrayY      = tmpInteger;
		this->nTrayWidth  = rc.right - 2 * tmpInteger;
		this->nTrayHeight = rc.bottom - 2 * tmpInteger;

	} else {

		this->nTrayX = GetRCInt(TEXT("grdTrayX"),0);
		if(this->nTrayX < 0)
			this->nTrayX += GetSystemMetrics(SM_CXSCREEN);

		this->nTrayY = GetRCInt(TEXT("grdTrayY"),0);
		if(this->nTrayY < 0)
			this->nTrayY += GetSystemMetrics(SM_CYSCREEN);

		this->nTrayWidth = GetRCInt(TEXT("grdTrayWidth"),100);
		this->nTrayHeight = GetRCInt(TEXT("grdTrayHeight"),20);

	}

	// autosize
	// NOT FOR WHARF
	this->bAutoSize = ( !this->bInWharf && GetRCBool(TEXT("grdTrayAutoSize"),TRUE) );

	// border
	tmpInteger = GetRCInt(TEXT("grdTrayBorderSize"),0);

	this->uBorderTop = GetRCInt(TEXT("grdTrayBorderTop"),tmpInteger);
	this->uBorderLeft = GetRCInt(TEXT("grdTrayBorderLeft"),tmpInteger);
	this->uBorderRight = GetRCInt(TEXT("grdTrayBorderRight"),tmpInteger);
	this->uBorderBottom = GetRCInt(TEXT("grdTrayBorderBottom"),tmpInteger);
	// NOT FOR WHARF
	this->bBorderDrag = ( !this->bInWharf && GetRCBool(TEXT("grdTrayBorderDrag"),TRUE) );
	
	// icon effects
	this->uEffectFlags = 0;

	this->uHueIntensity = (UCHAR)min( GetRCInt(TEXT("grdTrayIconHueIntensity"),0), 255 );
	this->clrHue = GetRCColor(TEXT("grdTrayIconHueColor"),RGB(128,128,128));
	if ( this->uHueIntensity )
		this->uEffectFlags |= FX_ICONHUE;

	this->uSaturnation = (UCHAR)min( GetRCInt(TEXT("grdTrayIconSaturnation"),255), 255 );
	if ( this->uSaturnation != 255 )
		this->uEffectFlags |= FX_SATURNATION;

	// colors
	this->clrBack = GetRCColor(TEXT("grdTrayBGColor"),RGB(255,0,255));
	this->clrBorder = GetRCColor(TEXT("grdTrayBorderColor"),RGB(255,255,255));
	
	// skinning
    GetRCString(TEXT("grdTrayBitmap"),tmpString,TEXT(""),256);

    if ( tmpString[0] == '\0' ) {

        this->hbmSkin = NULL;
		this->bTranspSkin = ( ( this->clrBack == RGB(255,0,255) ) || ( this->clrBorder == RGB(255,0,255) ) ) ? TRUE : FALSE;

    } else {

		BITMAP bm;
		HRGN hBitmapRgn, hOpaqueRgn;

        this->hbmSkin = LoadLSImage(tmpString, NULL);

		// get info from the bitmap
        GetObject( this->hbmSkin, sizeof(BITMAP), &bm );

		hBitmapRgn = BitmapToRegion( this->hbmSkin, RGB(255,0,255), 0x101010, 0, 0);
		hOpaqueRgn = CreateRectRgn( 0, 0, bm.bmWidth, bm.bmHeight );

		// to see if any pixels are transparent
		this->bTranspSkin = !EqualRgn( hBitmapRgn, hOpaqueRgn );

		DeleteObject( hBitmapRgn );
		DeleteObject( hOpaqueRgn );

	}
	this->hbmBack = NULL;
	this->bTranspBack = FALSE;

    this->bSkinTiled = GetRCBool(TEXT("grdTrayBitmapTiled"),TRUE);

	//tray wrapping
    this->uWrapCount = GetRCInt(TEXT("grdTrayWrapCount"),0);

    // get direction
    GetRCString(TEXT("grdTrayDirection"),tmpString,TEXT("right"),256);
    if ( !strnicmp(tmpString, "left", 5) )
        this->uDirection = TD_LEFT;
    else if ( !strnicmp(tmpString, "up", 3) )
        this->uDirection = TD_UP;
    else if ( !strnicmp(tmpString, "down", 5) )
        this->uDirection = TD_DOWN;
	else
		this->uDirection = TD_RIGHT;

    // get wrap-direction
    GetRCString(TEXT("grdTrayWrapDirection"),tmpString,TEXT("up"),256);
    if (this->uDirection & TD_VERTICAL) {
        if ( !strnicmp( tmpString, "left", 5 ) )
            this->uWrapDirection = TD_LEFT;
        else 
            this->uWrapDirection = TD_RIGHT;
    } else {
        if ( !strnicmp( tmpString, "down", 5) )
            this->uWrapDirection = TD_DOWN;
        else
            this->uWrapDirection = TD_UP;
    }

	// icon
	this->uIconSize = GetRCInt(TEXT("grdTrayIconSize"),16);
    this->nIconSpacingX = GetRCInt(TEXT("grdTrayIconSpacingX"),1);
	this->nIconSpacingY = GetRCInt(TEXT("grdTrayIconSpacingY"),1);

    // this section evaluates how the placing of new icons should be calculated
    this->nDeltaX = ((( this->uDirection & TD_VERTICAL )?this->uWrapDirection:this->uDirection ) == TD_LEFT) ? -1 : 1;
    this->nDeltaY = ((( this->uDirection & TD_VERTICAL )?this->uDirection:this->uWrapDirection ) == TD_DOWN) ? 1 : -1;

	this->nDeltaX *= this->uIconSize + this->nIconSpacingX;
	this->nDeltaY *= this->uIconSize + this->nIconSpacingY;

	this->setFirstLast();
	this->createBG();

	delete[] tmpString;

}

void grdSysTraySettings::setFirstLast() {

	// the following settings are used with the icon rectangles
	// to ensure they match the desired pattern
	this->nFirstX = ( (this->uDirection == TD_LEFT) || (this->uWrapDirection == TD_LEFT) ) ?
						( this->nTrayWidth -  this->uBorderRight  - this->nIconSpacingX - this->uIconSize ) :
						( this->uBorderLeft + this->nIconSpacingX );
	this->nLastX  = this->nFirstX + ( this->uWrapCount - 1 ) * this->nDeltaX;

	this->nFirstY = ( (this->uDirection == TD_DOWN) || (this->uWrapDirection == TD_DOWN) ) ?
						( this->uBorderTop + this->nIconSpacingY ) :
						( this->nTrayHeight - this->uBorderBottom - this->nIconSpacingY - this->uIconSize );

	this->nLastY  = this->nFirstY + ( this->uWrapCount - 1 ) * this->nDeltaY;

	return;

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: ~grdSysTraySettings()                         * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: destroy the sysTraySettings class              * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdSysTraySettings::~grdSysTraySettings() {

	if ( this->hbmSkin )
		DeleteObject( this->hbmSkin );
	this->hbmSkin = NULL;

	if ( this->hbmBack )
		DeleteObject( this->hbmBack );
	this->hbmBack = NULL;

	if ( this->hrgnBack )
		DeleteObject( this->hrgnBack );
	this->hrgnBack = NULL;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: void createBG()                               * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: create the BG for blitting onto a DC           * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void grdSysTraySettings::createBG() {

	HDC hdcScreen, hdcDst;
	HBITMAP hbmDstOld;

	// delete old objects if necessary...
	if ( this->hbmBack ) {

		DeleteObject( this->hbmBack );
		this->hbmBack = NULL;

	} 

	if ( this->hrgnBack ) {

		DeleteObject( this->hrgnBack );
		this->hrgnBack = NULL;

	}

	// initiate a new destination dc
	hdcScreen = GetDC( this->hSysTray );

	hdcDst = CreateCompatibleDC( hdcScreen );
	this->hbmBack = CreateCompatibleBitmap( hdcScreen, this->nTrayWidth, this->nTrayHeight );
	hbmDstOld = (HBITMAP) SelectObject( hdcDst, this->hbmBack );

	ReleaseDC( this->hSysTray, hdcScreen );


	// if the background colors are needed put them on...
	if ( ( !this->hbmSkin ) || ( this->hbmSkin && this->bTranspSkin ) ) {

		RECT r;
		HBRUSH brush;

		// fill the border with the border colors
		if ( this->uBorderTop || this->uBorderLeft || this->uBorderBottom || this->uBorderTop ) {

			brush = CreateSolidBrush( this->clrBorder );

			if ( this->uBorderTop ) {

				r.left = 0;
				r.top = 0;
				r.right = this->nTrayWidth;
				r.bottom = this->uBorderTop;
				FillRect(hdcDst, &r, brush );

			}
		
			if ( this->uBorderLeft ) {

				r.left = 0;
				r.top = this->uBorderTop;
				r.right = this->uBorderLeft;
				r.bottom = this->nTrayHeight - this->uBorderBottom;
				FillRect(hdcDst, &r, brush );

			}

			if ( this->uBorderRight ) {

				r.left = this->nTrayWidth - this->uBorderRight;
				r.top = this->uBorderTop;
				r.right = this->nTrayWidth;
				r.bottom = this->nTrayHeight - this->uBorderBottom;
				FillRect(hdcDst, &r, brush );

			}

			if ( this->uBorderBottom ) {

				r.left = 0;
				r.top = this->nTrayHeight - this->uBorderBottom;
				r.right = this->nTrayWidth;
				r.bottom = this->nTrayHeight;
				FillRect(hdcDst, &r, brush );

			}

			DeleteObject( brush );

		}

		r.left   = this->uBorderLeft;
		r.top    = this->uBorderTop;
		r.right  = this->nTrayWidth  - this->uBorderRight;
		r.bottom = this->nTrayHeight - this->uBorderBottom;
    
		brush = CreateSolidBrush( this->clrBack );

		// now fill the inner rectangle (excluding the borders) with the background color
		FillRect(hdcDst, &r, brush );

		DeleteObject( brush );

	}

	// if a background image is provided, put it on...
    if ( this->hbmSkin ) {

        HDC     hdcSrc;
        HBITMAP hbmSrcOld;
        BITMAP  bm;

		// get info from the bitmap
        GetObject( this->hbmSkin, sizeof(BITMAP), &bm );

        hdcSrc = CreateCompatibleDC( hdcDst );
        hbmSrcOld = (HBITMAP) SelectObject( hdcSrc, this->hbmSkin );

        // take the four corners to start with
        // topleft
	    grdBitBlt( hdcDst, 0, 0, this->uBorderLeft, this->uBorderTop,
                   hdcSrc, 0, 0, this->bTranspSkin );

        // topright
        grdBitBlt( hdcDst, this->nTrayWidth-this->uBorderRight, 0, this->uBorderRight, this->uBorderTop,
                   hdcSrc, bm.bmWidth-this->uBorderRight, 0, this->bTranspSkin );

        //bottomright
        grdBitBlt( hdcDst, this->nTrayWidth-this->uBorderRight, this->nTrayHeight-this->uBorderBottom, this->uBorderRight, this->uBorderBottom,
                   hdcSrc, bm.bmWidth-this->uBorderRight, bm.bmHeight-this->uBorderBottom, this->bTranspSkin );

        //bottomleft
        grdBitBlt( hdcDst, 0, this->nTrayHeight-this->uBorderBottom, this->uBorderLeft, this->uBorderBottom,
                   hdcSrc, 0, bm.bmHeight-this->uBorderBottom, this->bTranspSkin );

        // top
        grdStretchTileBlt( hdcDst, this->uBorderLeft, 0, this->nTrayWidth-(this->uBorderRight+this->uBorderLeft), this->uBorderTop,
						   hdcSrc, this->uBorderLeft, 0, bm.bmWidth-(this->uBorderRight+this->uBorderLeft), this->uBorderTop,
						   this->bSkinTiled, this->bTranspSkin );

        // right
        grdStretchTileBlt( hdcDst, this->nTrayWidth-this->uBorderRight, this->uBorderTop, this->uBorderRight, this->nTrayHeight-(this->uBorderBottom+this->uBorderTop),
						   hdcSrc, bm.bmWidth-this->uBorderRight, this->uBorderTop, this->uBorderRight, bm.bmHeight-(this->uBorderBottom+this->uBorderTop),
						   this->bSkinTiled, this->bTranspSkin );

        // bottom
        grdStretchTileBlt( hdcDst, this->uBorderLeft, this->nTrayHeight-this->uBorderBottom, this->nTrayWidth-(this->uBorderRight+this->uBorderLeft), this->uBorderBottom, 
						   hdcSrc, this->uBorderLeft, bm.bmHeight-this->uBorderBottom, bm.bmWidth-(this->uBorderRight+this->uBorderLeft), this->uBorderBottom,
						   this->bSkinTiled, this->bTranspSkin );

        // left
        grdStretchTileBlt( hdcDst, 0, this->uBorderTop, this->uBorderLeft, this->nTrayHeight-(this->uBorderBottom+this->uBorderTop),
						   hdcSrc, 0, this->uBorderTop, this->uBorderLeft, bm.bmHeight-(this->uBorderBottom+this->uBorderTop),
						   this->bSkinTiled, this->bTranspSkin );

        // middle area
        grdStretchTileBlt( hdcDst, this->uBorderLeft, this->uBorderTop, this->nTrayWidth-(this->uBorderRight+this->uBorderLeft), this->nTrayHeight-(this->uBorderBottom+this->uBorderTop),
						   hdcSrc, this->uBorderLeft, this->uBorderTop, bm.bmWidth-(this->uBorderRight+this->uBorderLeft), bm.bmHeight-(this->uBorderBottom+this->uBorderTop),
						   this->bSkinTiled, this->bTranspSkin );

        SelectObject( hdcSrc, hbmSrcOld );
        DeleteDC( hdcSrc );

    }

	SelectObject( hdcDst, hbmDstOld );
	DeleteDC( hdcDst );

	if ( !this->bTranspSkin ) {

		this->bTranspBack = FALSE;

	} else {

		HRGN hOpaqueRgn = CreateRectRgn( 0, 0, this->nTrayWidth, this->nTrayHeight );
		this->hrgnBack = BitmapToRegion( this->hbmBack, RGB(255,0,255), 0x101010, 0, 0);

		// to see if any pixels are transparent
		this->bTranspBack = !EqualRgn( this->hrgnBack, hOpaqueRgn );

		DeleteObject( hOpaqueRgn );

		if ( !this->bTranspBack ) {

			DeleteObject( this->hrgnBack );
			this->hrgnBack = NULL;

		}

	}
	return;

}

BOOL grdSysTraySettings::setPos( int x, int y, int cx, int cy, UINT uFlags, BOOL bUpdate ) {

	if ( !( uFlags & SWP_NOMOVE ) ) {
		
		this->nTrayX = x;
		this->nTrayY = y;

	}

	if ( ( ( cx != this->nTrayWidth ) || ( cy != this->nTrayHeight ) ) && !( uFlags & SWP_NOSIZE ) )  {

		this->nTrayWidth = cx;
		this->nTrayHeight = cy;

		this->setFirstLast();
		this->createBG();

	}

	if ( bUpdate )
		return SetWindowPos( this->hSysTray, NULL, this->nTrayX, this->nTrayY, this->nTrayWidth, this->nTrayHeight, SWP_NOSENDCHANGING | SWP_NOCOPYBITS | SWP_NOZORDER | SWP_NOACTIVATE );

	return FALSE;

}

void grdSysTraySettings::skinOut( HDC hdcDst, HRGN hrgnDst ) {

	HDC hdcSrc;
	HBITMAP hbmOld;

	// if the background isn't there, make one...
	if ( !this->hbmBack ) {

		this->createBG();
		// if still not there... then it's nothing to do...
		if ( !this->hbmBack )
			return;

	}

	hdcSrc = CreateCompatibleDC( hdcDst );
	hbmOld = (HBITMAP) SelectObject( hdcSrc, this->hbmBack );

	BitBlt( hdcDst, 0, 0, this->nTrayWidth, this->nTrayHeight, hdcSrc, 0, 0, SRCCOPY );

	SelectObject( hdcSrc, hbmOld );
	DeleteDC( hdcSrc );

	if ( this->hrgnBack && this->bTranspBack )
		CombineRgn( hrgnDst, this->hrgnBack, NULL, RGN_COPY );

}


// grd Blitting functions...
// to enable transp / not transp painting
// and to enable tile / stretch resizing

int grdBitBlt ( HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, BOOL bTransparent ) {

	if ( bTransparent ) {

		TransparentBltLS( hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, RGB(255,0,255) );

	} else {

		return BitBlt( hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, SRCCOPY );

	}
	return 0;

}

int grdStretchTileBlt ( HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, BOOL bTiled, BOOL bTransparent ) {

	if ( bTiled ) {

		int nWidth = cxDst;
		int nHeight = cyDst;

		int x, y;
		
		for( y = 0; y < nHeight; y += cySrc ) {

			cxDst = nWidth;
			
			for( x = 0; x < nWidth; x += cxSrc ) {

				if ( bTransparent )
					TransparentBltLS( hdcDst, xDst + x, yDst + y, min( cxDst, cxSrc ), min( cyDst, cySrc ), hdcSrc, xSrc, ySrc, RGB(255,0,255) );
				else
					BitBlt( hdcDst, xDst + x, yDst + y, min( cxDst, cxSrc ), min( cyDst, cySrc ), hdcSrc, xSrc, ySrc, SRCCOPY );

				cxDst -= cxSrc;

			}
			
			cyDst -= cySrc;

		}
		return 0;

	} else {

		if ( bTransparent ) {

			HDC hdcTmp = CreateCompatibleDC( hdcDst );
			HBITMAP hbmTmp = CreateCompatibleBitmap( hdcDst, cxDst, cyDst );
			HBITMAP hbmOld = (HBITMAP) SelectObject( hdcTmp, hbmTmp );

			// change the size
			StretchBlt( hdcTmp, 0, 0, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY );

			// transblit the resized image on the result
			TransparentBltLS( hdcDst, xDst, yDst , cxDst, cyDst, hdcTmp, 0, 0, RGB(255,0,255) );

			SelectObject( hdcTmp, hbmOld );
			DeleteObject( hbmTmp );
			DeleteDC( hdcTmp );

			return 0;

		} else {

			return StretchBlt( hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY );

		}

	}

}



