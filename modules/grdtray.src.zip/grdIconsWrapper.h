#ifndef  __GRDICONSWRAPPER
#define  __GRDICONSWRAPPER

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <commctrl.h>
#include <shellapi.h>
#include <stdio.h>
#include "grdSysTraySettings.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * STRUCTURE: GRDSYSTRAYICON                               * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the structure that is stored for every icon    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

typedef struct GRDSYSTRAYICON {

	// owner window
	HWND hWnd;
	// id
	UINT uID;
	// flags
	UINT uFlags;
	// callback message ( to send to the owner window )
	UINT uCallbackMessage;
	// icon
	HICON hIcon;
	// icon region
	HRGN hRgn;
	// trayicon rectangle
	RECT rc;

	// tooltip text
	TCHAR *szTip;
	// tooltip id
	UINT uToolTip;

	struct GRDSYSTRAYICON *pNext, *pPrev;

} GRDSYSTRAYICON, *PGRDSYSTRAYICON, FAR *LPGRDSYSTRAYICON;


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdIconsWrapper                                  * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this class stores the icon information in a really     * */
/* *  smart way and prints the layout to a dc desiring it.   * */
/* *                                                         * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class grdIconsWrapper {

	public:

		// this one loads the wrapper from an ini-file
		grdIconsWrapper( HWND hTray, HWND hParent, grdSysTraySettings *cfg );
		// this one saves the wrapper to an ini-file
		~grdIconsWrapper();

		PGRDSYSTRAYICON add( PNOTIFYICONDATA pnid );
		PGRDSYSTRAYICON addRC( char *config );
		BOOL            del( PNOTIFYICONDATA pnid );
		PGRDSYSTRAYICON modify( PNOTIFYICONDATA pnid );
		
		PGRDSYSTRAYICON find( HWND hWnd, UINT uID );
		PGRDSYSTRAYICON findPt( POINT pt );

		void            cleanup();

		// to delete the complete list
		BOOL            delList();

		// to paint the icons to a dc
		void            iconsOut( HDC hdcDest, HRGN hrgnDest );

		// these are stolen from the LS source code (more or less)		
		int             save(void *dst);
		int             load(void *src);
		int             loadMaduin();
		int             loadRCIcons();

		HWND			hToolTip;

	private:

		void            getRgn( PGRDSYSTRAYICON pSysTrayIcon );
		void            autoSize();
		BOOL            delInside( PGRDSYSTRAYICON pSysTrayIcon );

		// the pointers that this class uses
		PGRDSYSTRAYICON pFirst, pLast;

		// window handles needed
		HWND hSysTray, hLiteStep;

		UINT uLastID;

		// this is interesting
		grdSysTraySettings *settings;

};


#endif// __GRDICONSWRAPPER
