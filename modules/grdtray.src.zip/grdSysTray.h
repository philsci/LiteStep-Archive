#ifndef  __GRDSYSTRAY
#define  __GRDSYSTRAY

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#include <windows.h>
#include <stdlib.h>
#include "grdSysTraySettings.h"
#include "grdIconsWrapper.h"
#include "grdShellTray.h"
#include "lsapi.h"

// name of shelldesktop class
#define WC_SHELLDESKTOP    TEXT("DesktopBackgroundClass")

// name of the grdSysTray class
#define WC_SYSTRAY         TEXT("grdSysTray")

typedef struct tag_GRDMSG {
  UINT msg;
  union {
    struct {
      WPARAM wParam;
      LPARAM lParam;
      LRESULT lResult;
    };
    struct {
      WORD wParamLo;
      WORD wParamHi;
      WORD lParamLo;
      WORD lParamHi;
      WORD lResultLo;
      WORD lResultHi;
    };
  };
} GRDMSG, *PGRDMSG, FAR *LPGRDMSG;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdSysTray                                       * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the main class, which does all the real work   * */
/* *  it initializes a couple of "sub-classes" that are      * */
/* *  that just to make it easier to understand and manage   * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class grdSysTray {

	public:

		// this starts the whole thing
		grdSysTray( HWND parent, HINSTANCE lsinstance, BOOL inWharf );
		// this terminates the whole thing
		~grdSysTray();

		// has to be public for the sake of bang-commands
		void onUser( PGRDMSG pmsg );

	private:

		static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

		void onGetRevID( PGRDMSG pmsg );
		void onRestoreSysTray( PGRDMSG pmsg );
		void onSaveSysTray( PGRDMSG pmsg );
		void onSysTray( PGRDMSG pmsg );
		void onCreate( PGRDMSG pmsg );
		void onMouse( PGRDMSG pmsg );
		void onSize( PGRDMSG pmsg );
		void onMove( PGRDMSG pmsg );
		void onPaint( PGRDMSG pmsg );

		grdSysTraySettings *settings;
		grdIconsWrapper    *icons;
		grdShellTray       *shellTray;

		HINSTANCE           hInstance;

		HWND                hLiteStep;
		HWND				hDesktop;
		HWND				hSysTray;
		HWND                hParent;

};


#endif// __GRDSYSTRAY