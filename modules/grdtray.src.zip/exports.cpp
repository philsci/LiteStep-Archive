#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#include <windows.h>
#include "exports.h"
#include "grdSysTray.h"

grdSysTray *theActualTray = NULL;

/********************************************
* int initModuleEx()                        *
*                *  *  *  *                 *
*    Arguments:                             *
*                                           *
*    - HWND lswnd                           *
*      The HWND of LiteStep                 *
*    - HINSTANCE dll                        *
*      The HINSTANCE of this DLL.           *
*    - LPCSTR szPath                        *
*      The path to LiteStep                 *
*                *  *  *  *                 *
* Handles all initialization of grdTray     *
********************************************/
	
int initModuleEx( HWND lswnd, HINSTANCE lsinstance, LPCSTR lspath ) {

	theActualTray = new grdSysTray( lswnd, lsinstance, FALSE );

	if ( theActualTray )
		return 0;
	else
		return 1;

}

/********************************************
* int quitModule()                          *
*                 *  *  *  *                *
*    Arguments:                             *
*                                           *
*    - HINSTANCE lsinstance                 *
*      The HINSTANCE of this DLL.           *
*                 *  *  *  *                *
* Handles all of the unloading of this DLL. *
********************************************/

int quitModule( HINSTANCE lsinstance ) {

	if ( theActualTray )
		delete theActualTray;

    return 0;

}

/********************************************
* int initWharfModule()                     *
*                *  *  *  *                 *
*    Arguments:                             *
*                                           *
*    - HWND parent                          *
*      The HWND of LiteStep                 *
*    - HINSTANCE dll                        *
*      The HINSTANCE of this DLL.           *
*    - void *wharfData                      *
*      Structure with LiteStep info         *
*                *  *  *  *                 *
* Handles all initialization of grdTray     *
********************************************/

int initWharfModule(HWND parent, HINSTANCE lsinstance, void *wharfData) {

	theActualTray = new grdSysTray( parent, lsinstance, TRUE );

	if ( theActualTray )
		return 0;
	else
		return 1;

}

/********************************************
* int quitModule()                          *
*                 *  *  *  *                *
*    Arguments:                             *
*                                           *
*    - HINSTANCE lsinstance                 *
*      The HINSTANCE of this DLL.           *
*                 *  *  *  *                *
* Handles all of the unloading of this DLL. *
********************************************/

int quitWharfModule( HINSTANCE lsinstance ) {

	return quitModule( lsinstance );

}