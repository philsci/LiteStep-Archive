#ifndef  __GRDSHELLTRAY
#define  __GRDSHELLTRAY

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#include <windows.h>
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include "lsapi.h"

// the name of the shelltray windowclass
#define WC_SHELLTRAY       "Shell_TrayWnd"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdShellTray                                     * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is a sub-class that handles the real message-     * */
/* *  passing routine.                                       * */
/* *                                                         * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class grdShellTray {

	public:

		// this starts the whole thing
		grdShellTray( HWND lswnd, HINSTANCE lsinstance );
		// this terminates the whole thing
		~grdShellTray();

	private:

		// functions
		static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
		LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

		// properties
		HINSTANCE hInstance;
		HWND      hShellTray;
		HWND	  hLiteStep;

};


#endif// __GRDSHELLTRAY