#ifndef  __GRDSYSTRAYSETTINGS
#define  __GRDSYSTRAYSETTINGS

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include "lsapi.h"

// defined directions
#define TD_VERTICAL    0x1
#define TD_TOTOPLEFT   0x2

#define TD_RIGHT       0x0
#define TD_LEFT        (TD_TOTOPLEFT)
#define TD_UP          (TD_TOTOPLEFT|TD_VERTICAL)
#define TD_DOWN        (TD_VERTICAL)

// defined effects
#define FX_ICONHUE     0x1
#define FX_SATURNATION 0x2

#define FX_ANY         (FX_ICONHUE|FX_SATURNATION)


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdSysTraySettings                               * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this sub-class handles everything that has anythin     * */
/* *  in common with loading settings and checking them      * */
/* *  for proper format and so on...                         * */
/* *                                                         * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class grdSysTraySettings {

	public:

		grdSysTraySettings( BOOL inWharf, HWND hParentWnd );
		~grdSysTraySettings();

		void skinOut( HDC hdcDst, HRGN hrgnDst );
		
		BOOL setPos( int x, int y,int cx, int cy, UINT uFlags, BOOL bUpdate );
		
		// booleans
		BOOL bAlwaysOnTop;
		BOOL bHideIfEmpty;
		BOOL bVisible;
		BOOL bInWharf;

		// tray
		int  nTrayX;
		int  nTrayY;
		int  nTrayWidth;
		int  nTrayHeight;

		// autosize
		BOOL bAutoSize;

		// borders
		UINT uBorderTop; 
		UINT uBorderLeft;
		UINT uBorderRight;
		UINT uBorderBottom;
		BOOL bBorderDrag;

		// tray wrapping
		UINT uDirection;
		UINT uWrapCount;
		UINT uWrapDirection;

		// icon
		UINT uIconSize;
		int  nIconSpacingX;
		int  nIconSpacingY;
		int  nDeltaX;
		int  nDeltaY;

		int  nFirstX;
		int  nLastX;
		int  nFirstY;
		int  nLastY;

		// icon effects
		COLORREF clrHue;
		UCHAR uHueIntensity;

		UCHAR uSaturnation;

		UCHAR uEffectFlags;

		BOOL bTranspBack;
		HWND hSysTray;


	private:

		void setFirstLast();
		void createBG();

		// skinning
		HBITMAP hbmSkin;
		HBITMAP hbmBack;
		HRGN    hrgnBack;
		BOOL bSkinTiled;
		BOOL bTranspSkin;

		COLORREF clrBack;
		COLORREF clrBorder;

		HWND hParent;

};


#endif// __GRDSYSTRAYSETTINGS