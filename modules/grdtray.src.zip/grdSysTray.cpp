#include "grdSysTray.h"

// don't know the purpose of this one...
#define MAGICDWORD         0x49474541

// defined BangMessages
#define BM_SHOW            142
#define BM_HIDE            143
#define BM_TOGGLE          144
#define BM_ONTOP           150
#define BM_MOVE            169
#define BM_SIZE            170

// register messages from litestep
UINT nMessages[] = {
    LM_GETREVID,
	LM_RESTORESYSTRAY,
	LM_SAVESYSTRAY,
//	LM_SENDSYSTRAY,    // removed
	LM_SYSTRAY,
	0
};

void grdTrayBangHide( HWND caller, char *args );
void grdTrayBangShow( HWND caller, char *args );
void grdTrayBangToggle( HWND caller, char *args );
void grdTrayBangOnTop( HWND caller, char *args );
void grdTrayBangMove( HWND caller, char *args );
void grdTrayBangSize( HWND caller, char *args );

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: grdSysTray()                                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   LPCTSTR szPath                                        * */
/* *   path to the litestep directory                        * */
/* *                                                         * */
/* *   HINSTANCE dll                                         * */
/* *   the current instance                                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: initialize the sysTray class                   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdSysTray::grdSysTray( HWND parent, HINSTANCE lsinstance, BOOL inWharf ) {

	// temporary variables
	WNDCLASSEX wc;
	
	/* *************************************** */
	/* *     STORE THE INFORMATION PASSED    * */
	/* *************************************** */

	this->hParent   = parent;
	this->hLiteStep = GetLitestepWnd();
    this->hInstance = lsinstance;


	/* *************************************** */
	/* *            LOAD SETTINGS            * */
	/* *************************************** */

	this->settings = new grdSysTraySettings( inWharf, this->hParent );


	/* *************************************** */
	/* *       GET SOME WINDOW HANDLES       * */
	/* *************************************** */

	this->hDesktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if ( !this->hDesktop )
		this->hDesktop = GetDesktopWindow();


	/* *************************************** */
	/* *       INITIATE SOME VARIABLES       * */
	/* *************************************** */
	
	this->hSysTray  = NULL;
	this->icons     = NULL; 
	this->shellTray = NULL;


	/* *************************************** */
	/* *      REGISTER THE SYSTRAY CLASS     * */
	/* *************************************** */

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
	wc.lpfnWndProc = (WNDPROC) grdSysTray::WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = this->hInstance;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.hIcon = NULL;
	wc.hIconSm = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_SYSTRAY;
	
	if (!RegisterClassEx( &wc ) ) {

        MessageBox(0,TEXT("couldn't register the window class"),WC_SYSTRAY,MB_OK);
		return;

	}
	

	/* *************************************** */
	/* *      CREATE THE SYSTRAY WINDOW      * */
	/* *************************************** */

	this->hSysTray = CreateWindowEx( WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT | ( this->settings->bAlwaysOnTop ) ? WS_EX_TOPMOST : NULL,
						             WC_SYSTRAY,
									 NULL,
									 ( ( this->settings->bInWharf ) ? WS_CHILD : WS_POPUP ),
									 this->settings->nTrayX, this->settings->nTrayY,
									 this->settings->nTrayWidth, this->settings->nTrayHeight,
									 this->hParent,
									 NULL,
									 this->hInstance,
									 NULL );

	if ( this->hSysTray == NULL ) {

        MessageBox(0,TEXT("couldn't create the window"),WC_SYSTRAY,MB_OK);
		return;

	}


	/* *************************************** */
	/* *      ADJUST THE SYSTRAY WINDOW      * */
	/* *************************************** */
	
	// pass the window handle to the settings object...
	this->settings->hSysTray = this->hSysTray;

	// set the magicDWord
	SetWindowLong( this->hSysTray, GWL_USERDATA, (LONG)MAGICDWORD );

	// save the class handle as a window long
	SetWindowLong( this->hSysTray, 0, (LONG)this );

	// set always on top
	// REMOVED FOR WHARF USAGE
	if( this->settings->bAlwaysOnTop && !this->settings->bInWharf )
		SetWindowPos( this->hSysTray, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );

	// set the parent window to the desktop window
	//
	// when it's always on top this is avoided
	// don't know about this, but I think the topmost
	// doesn't work otherwise
	//
	// please correct me if I'm wrong
	// REMOVED FOR WHARF USAGE
	if( !this->settings->bAlwaysOnTop && !this->settings->bInWharf ) 
		SetParent( this->hSysTray, this->hDesktop );
	

	/* *************************************** */
	/* *     SHOW AND UPDATE THE SYSTRAY     * */
	/* *************************************** */	

	ShowWindow( this->hSysTray, ( !this->settings->bVisible || ( this->settings->bHideIfEmpty ) ) ? SW_HIDE : SW_SHOWNOACTIVATE );

	InvalidateRect( this->hSysTray, NULL, TRUE );

	
	/* *************************************** */
	/* *       LAUNCH THE ICON-WRAPPER       * */
	/* *************************************** */
	
	this->icons = new grdIconsWrapper( this->hSysTray, this->hLiteStep, this->settings );


	/* *************************************** */
	/* *  ACTIVATE IT AS A LITESTEP SYSTRAY  * */
	/* *************************************** */

	SendMessage( this->hLiteStep, LM_REGISTERMESSAGE, (WPARAM) this->hSysTray, (LPARAM) nMessages );


	/* *************************************** */
	/* *          LOAD BANG COMMANDS         * */
	/* *************************************** */

	// NOT FOR WHARF
	if ( !this->settings->bInWharf ) {

		AddBangCommand( TEXT("!grdTrayHide"),   grdTrayBangHide );
		AddBangCommand( TEXT("!grdTrayShow"),   grdTrayBangShow );
		AddBangCommand( TEXT("!grdTrayToggle"), grdTrayBangToggle );
		AddBangCommand( TEXT("!grdTrayOnTop"),  grdTrayBangOnTop );
		AddBangCommand( TEXT("!grdTrayMove"),   grdTrayBangMove );
		AddBangCommand( TEXT("!grdTraySize"),   grdTrayBangSize );

	}

    
	/* *************************************** */
	/* *   CREATE A SHELLTRAY IF NECESSARY   * */
	/* *************************************** */
	
	if( !FindWindow( WC_SHELLTRAY, NULL ) )
		this->shellTray = new grdShellTray( this->hLiteStep, this->hInstance );

	return;

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: ~grdSysTray()                                 * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: destroy the sysTray class                      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdSysTray::~grdSysTray( ) {

	/* *************************************** */
	/* *   REMOVE THE SHELLTRAY IF CREATED   * */
	/* *************************************** */
	
	if ( this->shellTray )
		delete this->shellTray;
	this->shellTray = NULL;

	
	/* *************************************** */
	/* *         UNLOAD BANG COMMANDS        * */
	/* *************************************** */
	
	// NOT FOR WHARF
	if ( !this->settings->bInWharf ) {

		RemoveBangCommand( TEXT("!grdTrayHide")   );
		RemoveBangCommand( TEXT("!grdTrayShow")   );
		RemoveBangCommand( TEXT("!grdTrayToggle") );
		RemoveBangCommand( TEXT("!grdTrayOnTop")   );
		RemoveBangCommand( TEXT("!grdTrayMove")   );
		RemoveBangCommand( TEXT("!grdTraySize")   );

	}


	/* *************************************** */
	/* * DEACTIVATE IT AS A LITESTEP SYSTRAY * */
	/* *************************************** */

	SendMessage( this->hLiteStep, LM_UNREGISTERMESSAGE, (WPARAM) this->hSysTray, (LPARAM) nMessages );


	/* *************************************** */
	/* *       DELETE THE ICON-WRAPPER       * */
	/* *************************************** */

	if ( this->icons )
		delete this->icons;
    this->icons = NULL;

	
	
	/* *************************************** */
	/* *     DESTROY THE SYSTRAY WINDOW      * */
	/* *************************************** */
	
	DestroyWindow( this->hSysTray );
	this->hSysTray = NULL;

	
	/* *************************************** */
	/* *     UNREGISTER THE SYSTRAY CLASS    * */
	/* *************************************** */
	
	UnregisterClass( WC_SYSTRAY, this->hInstance );


	/* *************************************** */
	/* *   DESTROY NECESSARY PROPS/CLASSES   * */
	/* *************************************** */
	
	if ( this->settings )
		delete this->settings;
    this->settings = NULL;


    return;

}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WndProc()                             * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: forward the window's messages                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

LRESULT CALLBACK grdSysTray::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {	

	grdSysTray *tray = (grdSysTray *)::GetWindowLong( hwnd, 0 );
	
	if ( tray ) {

		GRDMSG msg;

		msg.msg     = message;
		msg.wParam  = wParam;
		msg.lParam  = lParam;
		msg.lResult = 0;

		switch ( message ) {

			case LM_GETREVID:
				tray->onGetRevID( &msg );
				break;

			case LM_RESTORESYSTRAY:
				tray->onRestoreSysTray( &msg );
				break;

			case LM_SAVESYSTRAY:
				tray->onSaveSysTray( &msg );
				break;

			case LM_SYSTRAY:
				tray->onSysTray( &msg );
				break;

			case WM_CREATE:
				tray->onCreate( &msg );
				break;

			case WM_USER:
				tray->onUser( &msg );
				break;

			case WM_LBUTTONDBLCLK:
			case WM_LBUTTONDOWN:
			case WM_LBUTTONUP:
			case WM_MBUTTONDBLCLK:
			case WM_MBUTTONDOWN:
			case WM_MBUTTONUP:
			case WM_MOUSEMOVE:
			case WM_RBUTTONDBLCLK:
			case WM_RBUTTONDOWN:
			case WM_RBUTTONUP:
				tray->onMouse( &msg );
				break;

			case WM_SIZE:
				tray->onSize( &msg );
				break;

			case WM_MOVE:
				tray->onMove( &msg );
				break;

			case WM_PAINT:
				tray->onPaint( &msg );
				break;

			default:
				msg.lResult = DefWindowProc( hwnd, message, wParam, lParam );
				break;

		}
		return msg.lResult;

	} else {

		return DefWindowProc(hwnd, message, wParam, lParam);

	}

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WindowProc()                          * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: handle the window's messages                   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

void grdSysTray::onGetRevID( PGRDMSG pmsg ) {

	char *buf = (char *)(pmsg->lParam);

	switch (pmsg->wParam) {

		case 0:
			strcpy(buf, TEXT("grdTray.dll: 2.2 beta 1 ") );
			break;

		case 1:
			strcpy(buf, TEXT("Id: grdTray.cpp,v 2.2 beta 1 2000/05/01 grd Exp ") );
			break;

		default:
			strcpy(buf, TEXT("") );
			break;

	}
	pmsg->lResult = lstrlen(buf);

}

void grdSysTray::onRestoreSysTray( PGRDMSG pmsg ) {

	if ( !this->icons->load( (void *)(pmsg->lParam) ) )
		this->icons->loadMaduin();

}
		
void grdSysTray::onSaveSysTray( PGRDMSG pmsg ) {

	this->icons->save( (void *)(pmsg->lParam) );

}

void grdSysTray::onSysTray( PGRDMSG pmsg ) {

	switch( pmsg->wParam ) {

		case NIM_ADD:

			pmsg->lResult = (BOOL)( this->icons->add( (PNOTIFYICONDATA) pmsg->lParam ) != NULL );
			break;

		case NIM_MODIFY:

			pmsg->lResult = (BOOL)( this->icons->modify( (PNOTIFYICONDATA) pmsg->lParam ) != NULL );
			break;
		
		case NIM_DELETE:
			
			pmsg->lResult = (BOOL)this->icons->del( (PNOTIFYICONDATA) pmsg->lParam );
			break;

		default:

			pmsg->lResult = FALSE;
			break;

	}
	
}
		
void grdSysTray::onCreate( PGRDMSG pmsg ) {

	// Win98/IE4 stuff
	PostMessage( HWND_BROADCAST, RegisterWindowMessage( TEXT("TaskbarCreated") ), 0, 0 );

}

void grdSysTray::onUser( PGRDMSG pmsg ) {

	// these are not for wharf usage
	if ( !this->settings->bInWharf ) {

		switch ( pmsg->wParam ) {

			case BM_SHOW:

				ShowWindow( this->hSysTray, SW_SHOWNOACTIVATE );
				break;

			case BM_HIDE:

				ShowWindow( this->hSysTray, SW_HIDE );
				break;

			case BM_TOGGLE:

				ShowWindow( this->hSysTray, IsWindowVisible( this->hSysTray ) ? SW_HIDE : SW_SHOWNOACTIVATE );
				break;

			case BM_ONTOP:

				if ( GetParent( this->hSysTray ) == this->hDesktop ) { // on bottom

					SetParent( this->hSysTray, this->hLiteStep );
					SetWindowPos( this->hSysTray,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);

				} else {

					SetParent( this->hSysTray, this->hDesktop );
					SetWindowPos( this->hSysTray,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);

				}
				break;

			case BM_MOVE:
			case BM_SIZE:
			{

				// these are the numbers we'll get
				int v1 = 0, v2 = 0;

				char *args = strtok((LPSTR)pmsg->lParam, "\"\t ,");

				if (args) {

					v1 = atoi(args);

					args = strtok(NULL, "\"\t ,");

					if (args) {

						v2 = atoi(args);

						if ( pmsg->wParam == BM_MOVE )
							this->settings->setPos( ( v1 >= 0 ) ? v1 : v1 + GetSystemMetrics(SM_CXSCREEN), ( v2 >= 0 ) ? v2 : v2 + GetSystemMetrics(SM_CYSCREEN), 0, 0, SWP_NOSIZE, TRUE );

						else if ( pmsg->wParam == BM_SIZE )
							this->settings->setPos( 0, 0, min( (UINT)max(0,v1), (UINT)(GetSystemMetrics(SM_CXSCREEN) - this->settings->nTrayX) ), min( (UINT)max(0,v2), (UINT)(GetSystemMetrics(SM_CYSCREEN) - this->settings->nTrayY) ), SWP_NOMOVE, TRUE );

					}

				}

			}
			break;

			default:

				pmsg->lResult = DefWindowProc( this->hSysTray, pmsg->msg, pmsg->wParam, pmsg->lParam );
				break;

		}

	}

}
		
void grdSysTray::onMouse ( PGRDMSG pmsg ) {

	PGRDSYSTRAYICON pSysTrayIcon;
	POINT pt;
	MSG msg;

	// remove "unwanted" icons
	this->icons->cleanup();

	// get cursor point
	pt.x = pmsg->lParamLo;
	pt.y = pmsg->lParamHi;
	
	// send message to the tooltip
	msg.hwnd = this->hSysTray;
	msg.message = pmsg->msg;
	msg.wParam = pmsg->wParam;
	msg.lParam = pmsg->lParam;
	msg.time = GetTickCount();
	msg.pt = pt;
	SendMessage( this->icons->hToolTip, TTM_RELAYEVENT, 0, (LPARAM) &msg );

	// get icon at point
    pSysTrayIcon = this->icons->findPt(pt);

	// post message to that icon
    if( pSysTrayIcon ) {
		
		if (pSysTrayIcon->uFlags & NIF_MESSAGE) {

			if ( pSysTrayIcon->hWnd != this->hSysTray ) {

				PostMessage( pSysTrayIcon->hWnd, pSysTrayIcon->uCallbackMessage, (WPARAM) pSysTrayIcon->uID, (LPARAM) pmsg->msg );
				return;

			}

		}

    } 
	
	// if it's not for an icon, and it's a right click, send to ls
	if ( pmsg->msg == WM_RBUTTONUP )
		PostMessage( this->hLiteStep, LM_POPUP, (WPARAM) pt.x, (LPARAM) pt.y );


	if ( ( pmsg->msg == WM_LBUTTONDOWN ) && ( this->settings->bBorderDrag ) ) {

		// if the point is on the border...
		if ( ( pt.x <= (int)this->settings->uBorderLeft ) ||
			 ( pt.x >= (int)(this->settings->nTrayWidth - this->settings->uBorderRight) ) ||
			 ( pt.y <= (int)this->settings->uBorderTop ) ||
			 ( pt.y >= (int)(this->settings->nTrayHeight - this->settings->uBorderBottom) ) ) {
			 
			SendMessage( this->hSysTray, WM_SYSCOMMAND, SC_MOVE | 2, pmsg->lParam );

		}

	}

}

void grdSysTray::onSize ( PGRDMSG pmsg ) {

	if ( pmsg->wParam != SIZE_MINIMIZED )
		this->settings->setPos( 0,0,(int)pmsg->lParamLo, (int)pmsg->lParamHi, SWP_NOMOVE, FALSE );

}

void grdSysTray::onMove ( PGRDMSG pmsg ) {

	this->settings->setPos( (int)pmsg->lParamLo, (int)pmsg->lParamHi, 0, 0, SWP_NOSIZE, FALSE );

}

void grdSysTray::onPaint ( PGRDMSG pmsg ) {		

    HDC     hdcBuffer;
    HBITMAP hbmBuffer, hbmBufOld;
    HRGN    hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen;
	
	hdcScreen = BeginPaint( this->hSysTray, &ps );

    hdcBuffer = CreateCompatibleDC( hdcScreen );

    hbmBuffer = CreateCompatibleBitmap( hdcScreen, this->settings->nTrayWidth, this->settings->nTrayHeight );
    hbmBufOld = (HBITMAP) SelectObject( hdcBuffer, hbmBuffer );

	if ( this->settings->bTranspBack )
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	this->settings->skinOut( hdcBuffer, hrgn );

	// blit the icons
	this->icons->iconsOut( hdcBuffer, hrgn );

	// set the windowRgn
	if ( this->settings->bTranspBack )
		SetWindowRgn( this->hSysTray, hrgn, TRUE );

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, this->settings->nTrayWidth, this->settings->nTrayHeight, hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject( hdcBuffer, hbmBufOld );
	DeleteObject( hbmBuffer );

	// remove the two memory DCs
	DeleteDC( hdcBuffer );

	EndPaint( this->hSysTray, &ps );
	
}
		
grdSysTray *getTray() {

	grdSysTray *theSysTray;
	HWND hSysTray = FindWindow( WC_SYSTRAY, NULL );

	// if it's not found, it's a child of the desktop window...
	// check that window, for a child which would be my tray
	if ( !hSysTray ) {

		HWND hDeskTop = FindWindow(WC_SHELLDESKTOP, NULL);
		if ( !hDeskTop )
				hDeskTop = GetDesktopWindow();

		hSysTray = FindWindowEx( hDeskTop, NULL, WC_SYSTRAY, NULL );

	}

	if ( !hSysTray )
		return NULL;

	theSysTray = (grdSysTray *)::GetWindowLong( hSysTray, 0 );

	if ( !theSysTray )
		return NULL;

	return theSysTray;

}

// BANG COMMAND FUNCTIONS

void grdTrayBangShow( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_SHOW;
		msg.lParam  = 0;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

void grdTrayBangHide( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_HIDE;
		msg.lParam  = 0;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

void grdTrayBangToggle( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_TOGGLE;
		msg.lParam  = 0;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

void grdTrayBangOnTop( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_ONTOP;
		msg.lParam  = 0;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

void grdTrayBangMove( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_MOVE;
		msg.lParam  = (LPARAM)(LPCSTR)args;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

void grdTrayBangSize( HWND caller, char *args ) {

	grdSysTray *tray = getTray();

	if ( tray ) {

		GRDMSG msg;

		msg.msg     = WM_USER;
		msg.wParam  = BM_SHOW;
		msg.lParam  = (LPARAM)(LPCSTR)args;
		msg.lResult = 0;

		tray->onUser( &msg );

	}

}

