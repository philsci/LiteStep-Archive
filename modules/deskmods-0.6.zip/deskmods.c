/*

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

2/7/99 - version 0.6
			Fixed shortcut transparency and added optional size parameters.

2/3/99 - version 0.5
			Major tweak of the wharf.dll that allows you to put modules or shortcuts anywhere
			on the desktop. Does not have folders support or shortcut hints.

Jeb Crouson (aka TrOgI)
crouson@inreach.com
http://home.inreach.com/crouson

/****************************************************************************

 11/16/98 - Bug*Killer added by Fahim
			Added facility for popup menu to open when right clicked on wharf
			Divided the title bar in two parts : drag the left one to move the 
			bar, click on the right one to shade/unshade the bar. When the wharf
			bar is not shaded, a double click on the left part puts it in shaded
			mode & then moves it to a special position : 
			ScreenWidth - "WharfDblClickXPosition",0. When the wharf bar is 
			shaded, a double click on the left part unshades the bar, then docks
			it on the right, or on the left if the "WharfDblClickDockOnLeft" 
			step.rc entry is specified.
 11/15/98 - cael
			Added checks in SetWorkArea() to not change the work area if
			SetDesktopArea is true
 11/03/98 - W. Konkel
				Added the better wharf movement as well as sound to !WharfTasks
 11/02/98 - W. Konkel
				Added wharf open/close/min/max sounds (with the help/request 
					of snowchyld)
 11/01/98 - T. Engel
	 			Added back WharfTitleFont, WharfTitleFontSize, and a new
 				option WharfTitleFontWeight
 11/01/98 - W. Konkel
				Added better wharf movement (fixed a few small bugs)
				Made WharfCloseOnSwitch work much much better
 10/31/98 - Cyberian
				Fixed crashing on recycle when WharfCloseOnSwitch is enabled
 10/29/98 - Cyberian (Fahim Farook)
				Added WharfCloseOnSwitch to step.rc so that you can have the 
				subwharf folders auto-close when focus is lost if you desire
				Added support for wharf hints

 10/10/98 - W. Konkel
				Added snap-to-edge wharf and the ability to not include the
					default.bmp and 3dots.bmp in wharf layer.
 10/09/98 - C. Boyda
				Made the trans titlebar much more efficent in speed

 10/03/98 - J. Vaughn
				Added fully functional, working transparency to the wharf
				titlebar (why was it left out to begin with?? :P)

 09/03/98 - C. Boyda
                Added fully functional, working transparency to the wharf
            D. Hodgkiss
                Folders support is now in

 08/31/98 - D. Hodgkiss
                Added ability to move the wharf anywhere on the screen
                Added a titlebar to the wharf
                Added hide/unhide support

 08/25/98 - D. Hodgkiss
                This file contains the source for the wharf bar

****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>

#include "lsapi.h"
#include "deskmods.h"

// -------------------------------------------------------------------------------------------------------

const LPCTSTR   szMainWindowClass = _T("DeskClass");

// our window procedures
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// -------------------------------------------------------------------------------------------------------

BOOL CreateDeskType(int, LPCSTR);
void ReadConfig(void);
int GetDeskTypeByWnd(HWND hwnd);
void ExecuteDeskType(int i);

char szLitestepPath[256];
char lsPath[256];
char szImagePath[256];
char szDefPixmap[256];
HBITMAP defaultBackImage = NULL;
HINSTANCE dll;
HWND parent;
HWND desktop = NULL;
int ScreenWidth, ScreenHeight;
deskType *deskTypes = NULL;
int numDeskTypes = 0;
//BOOL onTop = FALSE;

// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	dll = dllInst;
	parent = ParentWnd;
	
	strcpy(szLitestepPath, szPath);
	ReadConfig();

	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
	{
		desktop = GetDesktopWindow();
	}

	{	// Register our window class
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = MainWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.lpszClassName = szMainWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;
		
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class", "Desk", MB_OK);
			return 1;
		}
	}

	{
		FILE *f;
		
		f = LCOpen (NULL);
		if (f)
		{
			char	buffer[4096];
			char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], token7[4096], token8[4096], extra_text[4096];
			char*	tokens[8];

			tokens[0] = token1;
			tokens[1] = token2;
			tokens[2] = token3;
			tokens[3] = token4;
			tokens[4] = token5;
			tokens[5] = token6;
			tokens[6] = token7;
			tokens[7] = token8;

			buffer[0] = 0;

			while (LCReadNextConfig (f, "*Desk", buffer, sizeof (buffer)))
			{
				int count;
				
				token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = token7[0] = token8[0] = extra_text[0] = '\0';
				
				count = LCTokenize (buffer, tokens, 8, extra_text);
				
				switch (count)
				{
				case 6:
				case 7:
					{
						// token 1 is "*Desk", token 2 is the name, token 3 is the x coordinate,
						// token 4 is the y coordinate, token 5 is the graphic, token 6 is the executable,
						// and the extra_text are the program arguments.
						char windowName[256];

						count = LCTokenize (buffer, tokens, 6, extra_text);

						windowName[0] = '\0';

						if ((token6[0] == '%') && (strrchr(token6, '%') == token6))
						{
							char szTempToken[4096];
							char*	tokens2[7];
							tokens2[0] = token1;
							tokens2[1] = token2;
							tokens2[2] = token3;
							tokens2[3] = token4;
							tokens2[4] = token5;
							tokens2[5] = szTempToken;
							tokens2[6] = token6;

							strcpy (windowName, token6 + 1);

							extra_text[0] = token6[0] = '\0';
							count = LCTokenize (buffer, tokens2, 7, extra_text);
						}

						{
							char szTT[1024];

							if (!deskTypes)
								deskTypes = (deskType *)malloc(sizeof(deskType));
							else
								deskTypes = (deskType *)realloc(deskTypes, (numDeskTypes+1)*sizeof(deskType));

							memset(&deskTypes[numDeskTypes], 0, sizeof(deskTypes[numDeskTypes]));
							
							strcpy(deskTypes[numDeskTypes].szName, token2);
							deskTypes[numDeskTypes].X = atoi(token3);
							deskTypes[numDeskTypes].Y = atoi(token4);
							if (deskTypes[numDeskTypes].X < 0) deskTypes[numDeskTypes].X += ScreenWidth;
							if (deskTypes[numDeskTypes].Y < 0) deskTypes[numDeskTypes].Y += ScreenHeight;
							strcpy(deskTypes[numDeskTypes].szCommand, token6);
							strcpy(deskTypes[numDeskTypes].szParameters, extra_text);
							deskTypes[numDeskTypes].width = 64;
							deskTypes[numDeskTypes].height = 64;
							
							strcpy(szTT, token6);
							if (strnicmp(".extract", token5, 8) && extra_text && strlen(extra_text))
							{
								strcat (szTT, " ");
								strcat (szTT, extra_text);
							}
							deskTypes[numDeskTypes].frontImage = LoadLSImage(token5, szTT);
							
							CreateDeskType(numDeskTypes, windowName);
							numDeskTypes++;
						}
					}
					break;
				case 8:
					{
						// token 1 is "*Desk", token 2 is the name, token 3 is the x coordinate,
						// token 4 is the y coordinate, token 5 is the graphic, token 6 is the width, token 7 is
						// the height, token 8 is the executable, and the extra_text are the program arguments.
						char windowName[256];

						windowName[0] = '\0';

						if ((token8[0] == '%') && (strrchr(token8, '%') == token8))
						{
							char szTempToken[4096];
							char*	tokens2[9];
							tokens2[0] = token1;
							tokens2[1] = token2;
							tokens2[2] = token3;
							tokens2[3] = token4;
							tokens2[4] = token5;
							tokens2[5] = token6;
							tokens2[6] = token7;
							tokens2[7] = szTempToken;
							tokens2[8] = token8;

							strcpy (windowName, token8 + 1);

							extra_text[0] = token8[0] = '\0';
							count = LCTokenize (buffer, tokens2, 9, extra_text);
						}

						{
							char szTT[1024];

							if (!deskTypes)
								deskTypes = (deskType *)malloc(sizeof(deskType));
							else
								deskTypes = (deskType *)realloc(deskTypes, (numDeskTypes+1)*sizeof(deskType));

							memset(&deskTypes[numDeskTypes], 0, sizeof(deskTypes[numDeskTypes]));
							
							strcpy(deskTypes[numDeskTypes].szName, token2);
							deskTypes[numDeskTypes].X = atoi(token3);
							deskTypes[numDeskTypes].Y = atoi(token4);
							if (deskTypes[numDeskTypes].X < 0) deskTypes[numDeskTypes].X += ScreenWidth;
							if (deskTypes[numDeskTypes].Y < 0) deskTypes[numDeskTypes].Y += ScreenHeight;
							deskTypes[numDeskTypes].width = atoi(token6);
							deskTypes[numDeskTypes].height = atoi(token7);
							strcpy(deskTypes[numDeskTypes].szCommand, token8);
							strcpy(deskTypes[numDeskTypes].szParameters, extra_text);
							
							strcpy(szTT, token8);
							if (strnicmp(".extract", token5, 8) && extra_text && strlen(extra_text))
							{
								strcat (szTT, " ");
								strcat (szTT, extra_text);
							}
							deskTypes[numDeskTypes].frontImage = LoadLSImage(token5, szTT);
							
							CreateDeskType(numDeskTypes, windowName);
							numDeskTypes++;
						}
					}
				}
			}
			LCClose(f);
		}
	}

	return 0;
}

// -------------------------------------------------------------------------------------------------------

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(parent,WM_KEYDOWN,8889,0);
				return 0;
			default:
				break;
			}
		}
		break;;
					
	case WM_CREATE: return 0;
	case WM_ERASEBKGND: return 0;
		
	case WM_PAINT:
		{
			int i = GetDeskTypeByWnd(hwnd);
			PAINTSTRUCT ps;
			HDC src = CreateCompatibleDC(NULL);
			HDC hdc = BeginPaint(hwnd,&ps);

			if (i != -1)
			{
				if (deskTypes[i].backImage)
				{
					SelectObject(src, deskTypes[i].backImage);
					BitBlt(hdc, 0, 0, deskTypes[i].width, deskTypes[i].height, src, 0, 0, SRCCOPY);
				}
			}
			EndPaint(hwnd,&ps);
			DeleteDC(src);
			
		}
		return 0;

	case WM_LBUTTONDOWN:
		return 0;
	case WM_LBUTTONUP:
		{
			int i = GetDeskTypeByWnd(hwnd);
			
			if (i != -1)
				ExecuteDeskType(i);
		}
		return 0;

	case WM_RBUTTONUP: // Open popup menu
            SendMessage(parent, LM_POPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
            return 0;
    case WM_RBUTTONDOWN: // Close popup menu
            SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
            return 0; 
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst) {
	int i;
	
	for (i = 0; i < numDeskTypes; i++) {
		if (deskTypes[i].hInst) {
			(*deskTypes[i].quitWharfModule)(deskTypes[i].hInst);
			FreeLibrary(deskTypes[i].hInst);
		}
		DestroyWindow(deskTypes[i].hWnd);
		if (deskTypes[i].backImage)
			DeleteObject(deskTypes[i].backImage);
		if (deskTypes[i].frontImage)
			DeleteObject(deskTypes[i].frontImage);

		if (defaultBackImage)
			DeleteObject(defaultBackImage);
	}
	free(deskTypes);

	UnregisterClass(szMainWindowClass,dllInst); // unregister window class
}

void ReadConfig (void)
{
	GetRCString("PixmapPath", szImagePath, "c:\\litestep\\images\\", 256);
	if (GetRCString("DeskBackPic", szDefPixmap, "", 256))
		defaultBackImage = LoadLSImage (szDefPixmap, NULL);
	//onTop = GetRCBool("DeskmodsOnTop", TRUE);
}

BOOL CreateDeskType(int i, LPCSTR szWindowName)
{
	HWND hWnd = NULL;
	RECT r;

	hWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,
		szMainWindowClass,
		szWindowName,
		WS_POPUP,
		0, 0,
		deskTypes[i].width, deskTypes[i].height,
		desktop,
		NULL,
		dll,
		NULL);
	
	if (!hWnd)
	{
		MessageBox(parent, "Error creating wharf tile", "Desk", MB_OK);
		return FALSE;
	}
	deskTypes[i].hWnd = hWnd;
	SetWindowLong(deskTypes[i].hWnd, GWL_USERDATA, magicDWord);
	
	//if (onTop)
	//	SetWindowPos(deskTypes[i].hWnd, HWND_TOPMOST, deskTypes[i].X, deskTypes[i].Y, 0, 0, SWP_NOSIZE);
	//else
		SetWindowPos(deskTypes[i].hWnd, NULL, deskTypes[i].X, deskTypes[i].Y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	
	if (deskTypes[i].szCommand[0] == '@')
	{
		int (FAR *FinitWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *FquitWharfModule)(HINSTANCE);

		char *module;
		HINSTANCE moduleInst;
		
		module = deskTypes[i].szCommand;
		if (*module == '@')
			module++;
		moduleInst = LoadLibrary(module);
		if ((UINT)moduleInst > HINSTANCE_ERROR)
		{
			FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "initWharfModule");
			FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "quitWharfModule");

			if (!FinitWharfModule || !FquitWharfModule)
			{
				MessageBox(NULL, module, "Invalid Wharf module", MB_OK);
				FreeLibrary(moduleInst);
				deskTypes[i].hInst = NULL;
			} else {
				deskTypes[i].hInst = moduleInst;
				deskTypes[i].initWharfModule = FinitWharfModule;
				deskTypes[i].quitWharfModule = FquitWharfModule;
				ExecuteDeskType(i);
			}
		} else {
			deskTypes[i].hInst = NULL;
			MessageBox(NULL, module, "Error loading module", MB_OK);
		}
	}
	
	/* Combine our images into one */
	{
		HDC src = CreateCompatibleDC(NULL);
		HDC dst = CreateCompatibleDC(NULL);
		HBRUSH hb = CreateSolidBrush(RGB(255,0,255));
		HDC tempDC = GetDC(deskTypes[i].hWnd);
		RECT r;
		
		deskTypes[i].backImage = CreateCompatibleBitmap(tempDC, deskTypes[i].width, deskTypes[i].height);
		SelectObject(dst, deskTypes[i].backImage);
		r.left = 0;
		r.top = 0;
		r.right = deskTypes[i].width;
		r.bottom = deskTypes[i].height;
		FillRect(dst, &r, hb);
		{
			HDC ddc = GetDC(GetDesktopWindow());
			POINT p;

			p.x = 0;
			p.y = 0;
			ClientToScreen(deskTypes[i].hWnd, &p);
			BitBlt(dst, 0, 0, deskTypes[i].width, deskTypes[i].height, ddc, p.x, p.y, SRCCOPY);

			ReleaseDC(GetDesktopWindow(), ddc);
		}
		if (defaultBackImage)
		{
			SelectObject(src, defaultBackImage);
			TransparentBltLS(dst, 0, 0, deskTypes[i].width, deskTypes[i].height, src, 0, 0, RGB(255, 0, 255));
		}
		if (deskTypes[i].frontImage)
		{
			BITMAP bmInfo;
			
			GetObject(deskTypes[i].frontImage, sizeof(bmInfo), &bmInfo);
			if (bmInfo.bmWidth > deskTypes[i].width) bmInfo.bmWidth = deskTypes[i].width;
			if (bmInfo.bmHeight > deskTypes[i].height) bmInfo.bmHeight = deskTypes[i].height;
			SelectObject(src, deskTypes[i].frontImage);
			TransparentBltLS(dst, (deskTypes[i].width/2)-(bmInfo.bmWidth/2), (deskTypes[i].height/2)-(bmInfo.bmHeight/2), bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255,0,255));
			DeleteObject(deskTypes[i].frontImage);
		}
		
		ReleaseDC(deskTypes[i].hWnd, tempDC);
		DeleteDC(src);
		DeleteDC(dst);
		DeleteObject(hb);
	}
	
	ShowWindow(deskTypes[i].hWnd, SW_SHOWNORMAL);
	GetClientRect(deskTypes[i].hWnd, &r);
	InvalidateRect(deskTypes[i].hWnd, &r, TRUE);
	
	return TRUE;
}

int GetDeskTypeByWnd(HWND hwnd)
{
	int i;
	
	for (i=0;i<numDeskTypes;i++)
		if (deskTypes[i].hWnd == hwnd)
			return i;
		return -1;
}

void GetWharfData(wharfDataType *wd)
{
		
	strcpy(lsPath, szLitestepPath);
	if (lsPath[strlen(lsPath)] != '\\')
		strcat(lsPath, "\\");

	wd->trayIconSize = GetRCInt("TrayIconSize", 16);
	wd->taskBarFore = GetRCColor("LSTaskBarFore", 0x000000);
	wd->taskBarBack = GetRCColor("LSTaskBarBack", 0x7f7f7f);
	wd->taskBarText = GetRCColor("LSTaskBarText", 0xffffff);
	wd->taskBarFore2 = GetRCColor("LSTaskBarFore2", 0x3f3f3f3f);
	wd->taskBar = GetRCBool("NoTaskBar", FALSE);
	wd->showBeta = GetRCBool("NoShowBeta", TRUE);;
	wd->usClock = GetRCBool("UsClock", TRUE);
	wd->vwmVelocity = GetRCInt("VWMVelocity", 300);
	wd->VWMDistance = GetRCInt("VWMSecurityDistance", 5);
	wd->VWMNoAuto = GetRCBool("VWMNoAuto", TRUE);
	wd->pixmapDir = szImagePath;
	wd->defaultBmp = "";
	wd->vwmBackColor = GetRCColor("VWMBackColor", 0x000000);
	wd->vwmSelBackColor = GetRCColor("VWMSelBackColor", 0x3f3f3f);
	wd->vwmForeColor = GetRCColor("VWMForeColor", 0x906090);
	wd->vwmBorderColor = GetRCColor("VWMBorderColor", 0xffffff);
	wd->lsPath = lsPath;
	wd->borderSize = 0;
}

void ExecuteDeskType(int i)
{
	if (deskTypes[i].szCommand[0] == '@')
	{
		wharfDataType wharfData;
		memset (&wharfData, 0, sizeof (wharfData));
		GetWharfData(&wharfData);
		
		(*deskTypes[i].initWharfModule)(deskTypes[i].hWnd, deskTypes[i].hInst, &wharfData);
		return;
	}
	
	if (deskTypes[i].szCommand[0] == '!')
	{
		ParseBangCommand(deskTypes[i].hWnd, deskTypes[i].szCommand, deskTypes[i].szParameters);
		return;
	}
	
	{
		SHELLEXECUTEINFO si;
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];
		
		_splitpath(deskTypes[i].szCommand, drive, dir, NULL, NULL);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);
		
		memset(&si, 0, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);
		si.lpDirectory = workDirectory;
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = deskTypes[i].szCommand;
		si.lpParameters = deskTypes[i].szParameters;
		ShellExecuteEx(&si);
		return;
	}
}
