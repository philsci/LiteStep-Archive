#ifndef __DESKMODS_H
#define __DESKMODS_H

#include "../litestep/wharfdata.h"

typedef struct {
        HINSTANCE hInst;
        HWND hWnd;
		HBITMAP frontImage;
		HBITMAP backImage;
		char szName[256];
        char szCommand[MAX_PATH];
		char szParameters[256];
        int X;
        int Y;
		int width;
		int height;
		int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *quitWharfModule)(HINSTANCE);
        } deskType;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif


#endif

