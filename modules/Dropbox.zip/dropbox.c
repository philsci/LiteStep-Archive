#include <windows.h>
#include "exports.h"
#include "lsapi.h"

#define NORMAL 0
#define CLICK 1
#define OVER 2

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
struct box* GetBoxByWindow(HWND hwnd);
void LoadSetup();

struct box
{
	HBITMAP normal;
	int normalw, normalh;
	HBITMAP click;
	int clickw, clickh;
	HBITMAP over;
	int overw, overh;
	int MOUSE_STATE;

	int x, y, w, h;
	char cmd[MAX_PATH];

	HWND hwnd;

	struct box* next;
} DropBox;

int ScreenX, ScreenY;
char* szAppName = "DropBox";
char lsdir[MAX_PATH] = "";
char imagedir[MAX_PATH] = "";
HINSTANCE hInstance;
BOOL TIMER=FALSE;

struct box* start;

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

    hInstance = dllInst;
	strcpy(lsdir, szPath);
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	LoadSetup();

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	UnregisterClass(szAppName, dll);

	while (start)
	{
		struct box* p = start;
		
		start=start->next;

		DeleteObject(p->click);
		DeleteObject(p->over);
		DeleteObject(p->normal);
		DestroyWindow(p->hwnd);
		p=NULL;
		free(p);
	}

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP backupbmp;
			struct box* p = GetBoxByWindow(hwnd);
			RECT r;
			
			GetClientRect(hwnd, &r);	

			if (p)
			{
				switch (p->MOUSE_STATE)
				{
					case NORMAL:	SelectObject(buf, p->normal); break;
					case CLICK:		SelectObject(buf, p->click); break;
					case OVER:		SelectObject(buf, p->over); break;
				}
			}
			else
			{
				backupbmp = CreateCompatibleBitmap(hdc, r.right, r.bottom);
				SelectObject(buf, backupbmp);
				FillRect(buf, &r, GetStockObject(GRAY_BRUSH));
			}

			BitBlt(hdc, 0, 0, r.right, r.bottom, buf, 0, 0, SRCCOPY);
			
			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
			DeleteDC(buf);
			if (backupbmp) DeleteObject(backupbmp);
			if (p) { p=NULL; free(p); }
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* wp = (WINDOWPOS*)lParam;			
			wp->flags |= SWP_NOZORDER;
		}
		break;

		case WM_DROPFILES:
		{
			struct box* p = GetBoxByWindow(hwnd);
			HDROP hdrop = (HDROP)wParam;
			int count = DragQueryFile(hdrop, 0xFFFFFFFF, NULL, 0);
			char filename[MAX_PATH] = "";
			int x=0;

			for (x=0; x < count; x++)
			{
				char buffer[256] = "";
				
				strcpy(buffer, p->cmd);
				memset(&filename, 0, sizeof(filename));
				DragQueryFile(hdrop, x, filename, MAX_PATH);
				
				if (!_strnicmp(buffer, "copy", 4))
				{
					char* name = strrchr(filename, '\\');
					char* m = strstr(buffer, "$1");
					char dest[256] = "";

					name++;
					sprintf(dest, "%s", m+3);
					if (dest[strlen(dest)] != '\\') dest[strlen(dest)] = '\\';
					strcat(dest, name);

					CopyFile(filename, dest, TRUE);
				}
				else if (!_strnicmp(buffer, "move", 4))
				{
					char* name = strrchr(filename, '\\');
					char* m = strstr(buffer, "$1");
					char dest[256] = "";

					name++;
					sprintf(dest, "%s", m+3);
					if (dest[strlen(dest)] != '\\') dest[strlen(dest)] = '\\';
					strcat(dest, name);

					MoveFile(filename, dest);
				}
				else
				{
					char* m = strstr(buffer, "$1");
					char exec[256] = "";
					strncpy(exec, buffer, m - buffer);
					strcat(exec, filename);
					WinExec(exec, SW_SHOWNORMAL);
				}
			}
		}
		return 0;

		case WM_LBUTTONDOWN:
		{
			struct box* p = GetBoxByWindow(hwnd);
			p->MOUSE_STATE = CLICK;
			InvalidateRect(hwnd, NULL, TRUE);
			if (p) { p=NULL; free(p); }
		}
		break;

		case WM_LBUTTONUP:
		{
			struct box* p = GetBoxByWindow(hwnd);
			if (p) p->MOUSE_STATE = OVER;
			InvalidateRect(hwnd, NULL, TRUE);
			MessageBox(hwnd, p->cmd, szAppName, MB_SYSTEMMODAL);
			if (p) { p=NULL; free(p); }
		}
		break;

		case WM_MOUSEMOVE:
		{
			struct box* p = GetBoxByWindow(hwnd);
			if (!(wParam & MK_LBUTTON)) { if (p) { p->MOUSE_STATE = OVER; } }
			if (!TIMER) { TIMER=TRUE; SetTimer(hwnd, 0, 10, NULL); }
			InvalidateRect(hwnd, NULL, TRUE);
			if (p) { p=NULL; free(p); }
		}
		break;

		case WM_TIMER:
		{
			struct box* b = GetBoxByWindow(hwnd);
			RECT cr, wr;
			POINT p;

			GetCursorPos(&p);
			GetWindowRect(hwnd, &wr);
			GetClientRect(hwnd, &cr);

			if (p.x > wr.right || p.x < wr.left || p.y < wr.top || p.y > wr.bottom) 
			{
				if (b) b->MOUSE_STATE = NORMAL;
				KillTimer(hwnd, 0);
				TIMER=FALSE;
				InvalidateRect(hwnd, NULL, TRUE);
			}
			if (b) { b=NULL; free(b); }
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

struct box* GetBoxByWindow(HWND hwnd)
{
	struct box* p = (struct box*)malloc(sizeof(struct box));

	for (p=start; p; p=p->next)
	{
		if (p->hwnd == hwnd) return p;
	}

	p=NULL;
	free(p);
	return NULL;
}

void LoadSetup()
{
	FILE* step;
	char temp[256] = "";
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], token6[4096], token7[4096], extra_text[4096];
	char*	tokens[7];
			
	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	tokens[6] = token7;

	sprintf(temp, "%s\\images", lsdir);
	GetRCString("DropBoxImageDir", imagedir, temp, MAX_PATH);
	if (imagedir[strlen(imagedir)] != '\\') 
	{
		imagedir[strlen(imagedir)] = '\\';
		imagedir[strlen(imagedir)+1] = '\0';
	}

	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);

	while (LCReadNextConfig(step, "*DropBox", temp, 256))
	{
		int count;
				
		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = token6[0] = token7[0] = extra_text[0] = '\0';
				
		count = LCTokenize (temp, tokens, 7, extra_text);

		if (count == 7)
		{
			struct box* p = (struct box*)malloc(sizeof(struct box));
			char path[MAX_PATH] = "";

			p->x = atoi(token2);
			p->y = atoi(token3);

			memset(&path, 0, sizeof(path));
			sprintf(path, "%s%s", imagedir, token4);
			p->normal = LoadImage(NULL, path, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if (p->normal) GetLSBitmapSize(p->normal, &p->normalw, &p->normalh);
			else continue;

			memset(&path, 0, sizeof(path));
			sprintf(path, "%s%s", imagedir, token5);
			p->over = LoadImage(NULL, path, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if (p->over) GetLSBitmapSize(p->over, &p->overw, &p->overh);
			else continue;

			memset(&path, 0, sizeof(path));
			sprintf(path, "%s%s", imagedir, token6);
			p->click = LoadImage(NULL, path, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
			if (p->click) GetLSBitmapSize(p->click, &p->clickw, &p->clickh);
			else continue;

			strcpy(p->cmd, token7);
			if (!p->cmd) continue;

			p->next = 0;
			p->MOUSE_STATE = 0;

			p->hwnd = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_ACCEPTFILES, szAppName, szAppName, WS_POPUP | WS_VISIBLE, p->x, p->y, p->normalw, p->normalh, NULL, NULL, hInstance, NULL);
			if (!p->hwnd) continue;

			if (start) p->next = start;
			start = p;

			p=NULL;
			free(p);
		}
	}
	LCClose(step);
}