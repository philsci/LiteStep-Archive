===================================================
===================================================
== bangvwm.dll - Who needs a GUI? Not I. ==========
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://jugg.logicpd.com/ =======
================== jugg@dylern.com ================
===================================================
===================================================
= Version: 0.30 = Release Date: 01.07.03 ==========
===================================================
===================================================

-=ToC=-
I. Introduction
II. Installation
III. Information
 A} Commands
 B} Changes
 C} Notes
IV. Tips & Tricks
V. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================

bangvwm.dll is a Virtual Window Manager for Win32
Shells that support the LiteStep module standard.
bangvwm.dll is based off of the idea of LiteStep's
VWM modules, but is purely controlled via !bang
commands and has no built in visual interface. This
gives an extremely fast and simple VWM without the
overhead of other similiar modules.


======================
== II. Installation ==
======================
===================================================

Extract "bangvwm.dll" to your Shell module
directory (c:\purels\modules\). Open up your Shell
configuration file and find the section where all
of your "LoadModule" lines are located. Remove any
"LoadModule" lines that are loading "sysvwm.dll" or
other VWM module. Now, add a new line that looks
like this:

LoadModule c:\purels\modules\jkey.dll

Of course, adjust the path as necessary. Refer to
the "Commands" section and configure your new VWM.
Then save your shell configuration file(s) and
issue the Shell's Recycle command (!Recycle).


======================
== III. Information ==
======================
===================================================
= A} Commands =
===============

bVWMDesks 4

  =!Bang Commands=
  ================
   !vVWMDesk <value>
     - parameters:
       ".home" - Goes to initial VW.
       ".end" - Goes to last VW.
       ".next" - Goes to next VW.
       ".prev" - Goes to previous VW.
       <integer> - Goes to specified VW.

     - Issuing this command will set the current VW
       to the specified <value>. If specifing an
       <integer>, the VW list is zero base, meaning
       the first VW is "0".

   !bVWMNext
     - parameters: none
     - Issuing this command will switch to the next
       Virtual Window.

   !bVWMPrev
     - parameters: none
     - Issuing this command will switch to the
       previous Virtual Window.

   !bVWMGather
     - parameters:
       ".home" - Gathers windows to the initial VW.
       ".end" - Gathers windows to the last VW.
       ".next" - Gathers windows to the next VW.
       ".prev" - Gathers windows to the previous
                 VW.
       <integer> - Gathers windows to the
                   specified VW.
       <noparams> - Gathers windows to the current
                     VW.
     - Issuing this command will gather all windows
       to the specified Virtual Window. If called
       without any parameters, it will gather the
       windows to the current Virtual Window.

===================================================
= B} Changes =
==============
(+)Added
(-)Removed
(*)Changed
(!)Fixed
(^)MiscNote


- 0.30 -
--------
  + Initial release.
  + Supports navigating the VWM by !bang commands


===================================================
= C} Notes =
============
Currently there is no way to make the VW auto
switch when focus is set to a window outside of the
current VW. This will be in the next release.

Enjoy


=====================
= IV. Tips & Tricks =
=====================
===================================================
Set your configuration to switch VW's via the
supplied !bang commands with hotkey's or with
desktop shortcuts for mouse click VW switching.

=================
= V. Disclaimer =
=================
===================================================

Copyright (C) 2001, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
