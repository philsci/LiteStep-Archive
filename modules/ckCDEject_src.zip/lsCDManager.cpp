//Porgram Name: lsCDEject.dll
//Filename	: 	lsCDManager.cpp
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "stdafx.h"
#include <cassert>
#include "lsCDManager.h"

// Static Variables
lsCDPool * lsCDManager::_pool = NULL;

// Static Functions
void lsCDManager::CDTrayOpen(HWND caller,char *args)
{	
	lsCD *cd = GetDrive(args);
	if(cd != NULL) cd->Open();
}

void lsCDManager::CDTrayClose(HWND caller,char *args)
{
	lsCD *cd = GetDrive(args);
	if(cd != NULL) cd->Close();
}

void lsCDManager::CDTrayToggle(HWND caller,char *args)
{
	lsCD *cd = GetDrive(args);
	if(cd != NULL) cd->Toggle();
}

// NULL if error
lsCD * lsCDManager::GetDrive(char *args)
{
	char drive;
	assert(_pool != NULL);
	drive = GetDriveLetter(args);
	//right now i dont want to implement any error warning crap yet
	if(drive == -1) return NULL; // this is when incoorect argument is detected
	return _pool->GetDrive(drive); // return NULL when pool is full
}

// return -1 if the argument is incorrect
char lsCDManager::GetDriveLetter(char *args)
{
	if(args == NULL) return -1;
	while(*args == ' ' || *args == '\r') ++args;
	
	if(!IsCharAlpha(*args)) return -1;
	else return *args;
}
