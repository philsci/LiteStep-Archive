//Porgram Name: lsCDEject.dll
//Filename	: 	lsStaticCDPool.cpp
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "stdafx.h"
#include "lsStaticCDPool.h"

//static vars
lsCD lsStaticCDPool::_pool[POOLSIZE];

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

lsStaticCDPool::lsStaticCDPool()
{	_curpos = 0;  }


// lsStaticCDPool::~lsStaticCDPool() {}

// return NULL if the drive doens't exist
lsCD * lsStaticCDPool::GetDrive(char ch)
{
	int pos;
	for(pos = 0; pos < _curpos; pos++)
		if(_pool[pos].GetLetter() == ch) return &(_pool[pos]);
		
	if(AddDrive(ch)) return &(_pool[_curpos-1]);
	return NULL;
}

bool lsStaticCDPool::AddDrive(char ch)
{
	if(_curpos < POOLSIZE)
	{
		_pool[_curpos++].SetDriveLetter(ch);
		return true;
	}
	return false;
}
