//Porgram Name: lsCDEject.dll
//Filename	: 	lsCDManager.h
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

// lsCDManager.h: interface for the lsCDManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LSCDMANAGER_H__CE6F95E9_8B9E_11D4_B89D_00400567D3A4__INCLUDED_)
#define AFX_LSCDMANAGER_H__CE6F95E9_8B9E_11D4_B89D_00400567D3A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "lsCDPool.h"

// This class manages the interaction between the Litestep's 
// bang commands and it's internal lsCD pool
class lsCDManager  
{
public:
	// Get the pointer to lsCD according to the argument from bang
	static lsCD * GetDrive(char *args);
	// call back functions
	static void CDTrayOpen(HWND caller,char *args);
	static void CDTrayClose(HWND caller,char *args);
	static void CDTrayToggle(HWND caller,char *args);
	
	// get the drive letter from argument
	static char GetDriveLetter(char *args);

	// set the currectn pool that's associated with this manager
	static void CDSetPool(lsCDPool *pool)
	{	_pool = pool;  }

protected:	
	// pointer to pool
	static lsCDPool * _pool;
};

#endif // !defined(AFX_LSCDMANAGER_H__CE6F95E9_8B9E_11D4_B89D_00400567D3A4__INCLUDED_)
