//Porgram Name: lsCDEject.dll
//Filename	: 	lsCD.cpp
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "stdafx.h"
#include <cassert>

#include <mmsystem.h>

#include "lsCD.h"

//static vars
//change the letter at pos: 12
char lsCD::_opencmd[] = "set cdaudio! : door open";
char lsCD::_closecmd[] = "set cdaudio! : door closed";

//letter at pos: 15
char lsCD::_togglecmd[] = "status cdaudio! : mode";

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
lsCD::lsCD(char ch/* =0 */)
{
	_letter = ch;
	_curStats = UNKOWN;
}

//lsCD::~lsCD() {}

bool lsCD::Open()
{	
	_curStats = OPEN;
	return SendCommand(_opencmd); 
}

bool lsCD::Close()
{	
	_curStats = CLOSE;
	return SendCommand(_closecmd); 
}

bool lsCD::Toggle()
{
	if(_curStats == UNKOWN)
	{
		char stats[11]; // for storing the restul status
		if(_letter == 0) return false;
		char *cmd = _togglecmd;
		*(cmd+15) = _letter; // change the drive letter
		if(mciSendString(cmd,stats,10,NULL) != 0) return false;
		if(lstrcmpi(stats, "open") == 0) return Close();
		else return Open();
	}
	else if(_curStats == OPEN)
		return Close();
	else
		return	Open();
}

void lsCD::SetDriveLetter(char ch)
{
	assert(IsCharAlpha(ch));
	_letter = ch;
}

bool lsCD::SendCommand(char *cmd)
{
	if(_letter == 0) return false;
	
	*(cmd+12) = _letter; // change the drive letter
	if(mciSendString(cmd,NULL,0,NULL) != 0) return false;

	return true;
}
