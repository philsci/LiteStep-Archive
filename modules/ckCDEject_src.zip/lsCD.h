//Porgram Name: lsCDEject.dll
//Filename	: 	lsCD.h
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
// lsCD.h: interface for the lsCD class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LSCD_H__CE6F95E8_8B9E_11D4_B89D_00400567D3A4__INCLUDED_)
#define AFX_LSCD_H__CE6F95E8_8B9E_11D4_B89D_00400567D3A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// This is core working class 
// The main thing it does maintain the open/close status
// for the drive letter it's assigned to

class lsCD  
{
	// the type for storing status
	enum CDSTATS { OPEN, CLOSE, UNKOWN};
public:
	bool SendCommand(char *cmd);
	lsCD(char ch = 0);
//	virtual ~lsCD();

	// open the cd tray
	bool Open();
	// close the cd tray
	bool Close();
	// toggle the cd tray depends on its status
	bool Toggle();	

	// get the drive letter associated with this object
	char GetLetter() { return _letter;}
	// set the drive letter that for this object
	void SetDriveLetter(char ch);

protected:
	char _letter;
	CDSTATS _curStats;

	//command strings for mci
	static char _opencmd[];
	static char _closecmd[];
	static char _togglecmd[];
};

#endif // !defined(AFX_LSCD_H__CE6F95E8_8B9E_11D4_B89D_00400567D3A4__INCLUDED_)
