//Porgram Name: lsCDEject.dll
//Filename	: 	lsCDEject.cpp
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Date		:	9/16/2000				
//Purpose:
//	This Litstep Module provides 3 bang commands for open, 
//	eject, and toggle the cd tray
/*
    Copyright (C) 2000  

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/


//entry point of the dll 

#include "stdafx.h"
#include <ls/lsapi.h>
#include <ls/exports.h>
#include "lsCDEject.h"
#include "lsCDManager.h"
#include "lsStaticCDPool.h"

//global crap
lsStaticCDPool g_Pool;

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

// LOAD MODULE Functions
LSCDEJECT_API int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

LSCDEJECT_API int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	// Register 3 bang commands
	lsCDManager::CDSetPool(&g_Pool);
	AddBangCommand("!CDOpenTray", lsCDManager::CDTrayOpen);
	AddBangCommand("!CDCloseTray",lsCDManager::CDTrayClose);
	AddBangCommand("!CDToggleTray",lsCDManager::CDTrayToggle);

	return 0;
}

LSCDEJECT_API int quitModule(HINSTANCE dll)
{
	return 0;
}
