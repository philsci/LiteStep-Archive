Autorecycle.dll

A simple module to recylce litestep everytime you save your step.rc or your theme file.

Steps

1)	Unzip to a location of your choice
2)	Loadmodule "path to autorecycle\autorecycle.dll"
3)	Make sure you have refernced your themefile

Version History:

0.1	1st release
0.2	Added Theme File as well

Pending

(0.3)	Ability to add up to 30 files to watch for changes


Galois
Galois@Techie.net