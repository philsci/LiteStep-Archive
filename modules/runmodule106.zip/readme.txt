////////////////////////////////
// Readme for RunModule v1.06 //
////////////////////////////////

//////////////////////////////
// Updated 1/9/2001 (D/M/Y) //
//////////////////////////////

LICENSE:
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ��AS IS'� AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html

HOWTO:
This program acts like the "Run..." option on the start menu, but has more power since it allows the user to specify the action that they want to perform on the file/folder.  The drop-down box allows for drag and drop, and remembers what you have already run.  The "Action Verb"  drop-down box will contain the action that you want to perform on the file.  The "Action Verb" can be one of the following without the quotes:
"open"
"explore"
"print"
"edit"
or any other command associated with the file/folder.

USE "rename" verb:
enter "rename" as your verb, and for the file name "OldFilePath"="NewFilePath"
USE "delete" verb:
Use this as you would any normal verb.  WARNING! You will not be prompted to confirm the deletion, also the file will be deleted and NOT sent to the recycle bin.

CUSTOMIZE RUNMODULE:
	All of the following options are just that, optional.  You do not have to set any of these to use the program.
	HOW TO SET THE FOLLOWING OPTIONS:
		The following options are to be set in the shortcut to the program.  Create a shortcut to "RunModule", and right-click the new shortcut.  Then Choose "Properties" from the menu.  This will bring up a window that has 2 tabs.  Choose the "Shortcut" tab.  There should be a text field called "Target:".  This is where you will be placing the options.  You need to place the options at the end of the line AFTER the quotes.  Make sure to leave a space between the quotes, and leave a space between each of the options. ie: "C:\Program Files\RunModule\RunModule.exe" /f "list.ini" /b /i /d 3000

	SETTING THE "LIST FILE":
		The "list file" is the file that will be used to save and retrieve the commands and files that are run with RunModule.  It also is the file that the batch run switch will run.  If you do not set this option the "list file" will default to "list.ini", which will be in the directory that RunModule was run from.  You will need to place quotes around paths that contain spaces.
		- The switch for this option is /f FILEPATH
		- The FILEPATH = the path to the file that will maintain the program list
		- ie. /f "c:\mylist.ini" would set the "list file" to mylist.txt in the c:\ directory
	SETTING THE "LAUNCH DELAY":
		The "launch delay" is the time in Milliseconds that RunModule will wait between program launched from a batch run of a "list file".  If you do not set this option the "launch delay" will default to 0 so there will be no pause between launches.
		- The switch for this option is /d DELAY
		- The DELAY = the time in Milliseconds
		- ie. /d 2000 would cause RunModule to wait 2 seconds before launching the next program in the "list file"
	SETTING THE "BATCH RUN":
		The "batch run" is the option to cause RunModule to execute all of the programs in the specified "list file".  If you do not set this option the "batch run" RunModule will just normally start up as normal.
		- The switch for this option is /b
		- No options
		- ie. /b /f "batch_list.ini" would cause RunModule to execute the specified "list file"
	SETTING THE "OBJECT":
		The "object" is the option to cause RunModule to execute the specified "object" without starting the GUI.  If you do not set this option the "object" RunModule will just normally start up as normal.
		- The switch for this option is /o FILEPATH
		- FILEPATH = the path to the object to execute
		- ie. /o C:\MyApp.exe would execute the specified object, and not start the GUI
	SETTING THE "COMMAND":
		The "command" aka. "action verb" is the option to cause RunModule to execute the specified "object" using the "command" without starting the GUI.  If you do not set this option the "command" will default to "open".
		- The switch for this option is /c FILEPATH
		- FILEPATH = the path to the object to execute
		- ie. /o C:\MyFile.bat /c edit would edit the specified object, and not start the GUI

RUNMODULE.INI SETTINGS:
   To create the runmodule.ini file, just run RunModule once, and then close it.  This will automatically create a RunModule.ini file.  All of the available settings can be seen in the "runmodule-all-settings.ini" file.  Changes made the this file will not be recognized, make/add all changes to the runmodule.ini file.  All of the options in the [layout] section define the places that you would want a particular control placed (button, drop-down, checkbox).  The "-x" and "-y" options define the upper left hand corner position of the control.  The "-cx" and "-cy" options define the width and height of the control respectively.  All of the controls x and y positions are relative to the upper left corner of the "client area", which is the area that starts below the window�s title.  By effectively using these settings you can create a pretty compact, yet fully functional variation of RunModule.
   The [settings] section defines various options for the program.  These can have their values set at either 1 or 0.  1 will enable this feature, and 0 will disable it.
hide-descriptions	; This hides the drop down box descriptions, and the button names.
stay-open		; This is the state of the "Close on OK" check box.  1 = checked, 0 = unchecked
topmost			; This allows the window to stay above other windows, which is good if you are using it as a shell
toolwindow		; This will make the window like a tool box window ie. smaller caption, doesn�t  appear in the taskbar, etc.
no-caption		; This removes the window title from the window, which is useful if you want to get the smallest screen footprint.  This also enables the system menu to appear if you right mouse click an open part of the "client area" of the window.  This enables moving the window by left mouse clicking and dragging the window from the "client area".

    Try copying and pasting the entire "runmodule-all-settings.ini" file over the "runmodule.ini" too see the drastic changes this makes to the appearance of RunModule.  You can use the open area on the right of the window the move it around.  Have fun with this options, I think that it is very useful.

CREATING LISTS USING "RNMDLLSTBLDR":
	First off this program can be slow when removing entries from a file.  Any modification that you make while a file is loaded will directly change the file, and there is no undo option.
[OPTIONS]
-Pressing the "Delete" key in the Section list will remove the entry from the file
-Pressing the "Insert" key in the Section list will add a "undef" entry to the file
-If you want to edit the contents of an entry you must choose Edit - Update Current Item from the file menu.
-Pressing the "Enter" key will open the Load file window
-DRAG AND DROP SUPPORT - Drop file(s) anywhere into the window and they will be added to the end of current list with "open" action verb.

USING RUNMODULE AS A SHELL:
	Though designed as only part of a shell, RunModule can be used as a stand alone shell.  WARNING! Modifying the registry can cause data loss or not cause your computer to start, modify at your own risk.  What I do is create a "startup_list.ini" with all of my startup programs, and start up programs in the registry.  I then spawn RunModule with the following settings:
c:\program files\runmodule\RunModule.exe /b /f "startup_list.ini" /d 2000
And all of your programs will start up.
Check out TrayModule on the AM Productions website for a system tray replacement.

CHANGES:
[v1.06]
-Added an "autocomplete" feature to both of the dropdown boxes.
-Fixed the "Close on OK" checkbox so that the last state is saved.
-Fixed the image positioning problems with the buttons.
-Added custom button positions.
-Added snapping to the edge of the screen.
-Added URL support.  Now by typing in any http:// website will be able to be launched ie. http://am-productions.yi.org/
[v1.04]
-When a program is run the current directory is set to the program�s directory NOT RunModule�s directory.
-There is a "Help" button in the About box which opens this readme file
-Added the "delete", and "rename" verb, so these don't have to be associated with the file to work.
-Added a manually set list file (/f FileName)
-Added a batch run switch (/b)
-Added a delay launching switch (only works when executing a file list /d TimeInMilliseconds)
-Added a ignore error switch (only works when executing a file list /i)
-Added a launch a object from the command line (/o filename)
-Added a specify verb for command line launch (/c verb)
-Changed the file list types to .ini files with a numbered list
-Added "RnMdlLstBldr.exe" to expedite the creating of execution lists (I just threw this together so don�t email any problems)
-Added support for apps that don�t "properly" register their shell extensions
-Fixed some minor bugs when executing some programs
-Added "Task Manager" to the system menu for easy task access 


Thank you for using RunModule,

Anish Mistry
email: amistry@am-productions.yi.org
website: am-productions.yi.org