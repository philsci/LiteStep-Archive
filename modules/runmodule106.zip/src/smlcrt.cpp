/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/

#include "stdafx.h"
#include "smlcrt.h"

void* __cdecl operator new(unsigned int cb)
{
  return HeapAlloc(GetProcessHeap(),0,cb);
}

void __cdecl operator delete(void* pv)
{
  if(pv)
    HeapFree(GetProcessHeap(),0,pv);
}

extern "C" int _cdecl _purecall(void)
{
  return 0;
}

inline unsigned int Pow(int num,int power)
{
	if(power == 0)
		return 1;
	int tempNum = num;
//	int tempPower = power;
	while(power != 1)
	{
		tempNum *= num;
		power--;
	}
	return tempNum;
}
/*
// function definitions
int __CxxFrameHandler(void )
{
	return 1;
}

int atexit( void ( __cdecl *func )( void ) )
{
	return true;

}*/

void __cdecl WinMainCRTStartup( void )
{

    int mainret;
    char *lpszCommandLine;
    STARTUPINFO StartupInfo;

    lpszCommandLine = GetCommandLine();

    // Skip past program name (first token in command line).

    if ( *lpszCommandLine == '"' )  //Check for and handle quoted program name
    {
        // Scan, and skip over, subsequent characters until  another
        // double-quote or a null is encountered

        while( *lpszCommandLine && (*lpszCommandLine != '"') )
            lpszCommandLine++;

        // If we stopped on a double-quote (usual case), skip over it.

        if ( *lpszCommandLine == '"' )
            lpszCommandLine++;
    }
    else    // First token wasn't a quote
    {
        while ( *lpszCommandLine > ' ' )
            lpszCommandLine++;
    }

    // Skip past any white space preceeding the second token.

    while ( *lpszCommandLine && (*lpszCommandLine <= ' ') )
        lpszCommandLine++;

    StartupInfo.dwFlags = 0;
    GetStartupInfo( &StartupInfo );

    mainret = WinMain( GetModuleHandle(NULL),
                       NULL,
                       lpszCommandLine,
                       StartupInfo.dwFlags & STARTF_USESHOWWINDOW
                            ? StartupInfo.wShowWindow : SW_SHOWDEFAULT );

    ExitProcess(mainret);
}


char GetAlphaNum(const int &num)
{
	if(num > 9)
		return NULL;
	return char(48+num);
}

inline int GetStringLength(const char *str)
{
	for(unsigned int i = 0;str[i] != NULL;i++);
	return i;
}

int Atoi(const char *pString)
{
	int nNum = 0;
	int nMagnitude = 1;
	bool bNeg = false;
	int i = 0;
	int nStrLength = GetStringLength(pString)-1;
	if(pString[0] == '-')
	{
		bNeg = true;
		pString++;
		nStrLength--;
	}
	while(i <= nStrLength)
	{
		nNum += nMagnitude*(pString[nStrLength-i++]-48);
		//i++;
		nMagnitude*=10;
	}
	if(bNeg)
	{
		nNum *= -1;
		//return nNum|4294967296;
	}
	return nNum;
}

inline int GetNumDigits(int n)
{
	for(int i = 0;n != 0;i++,n/=10);
	return i;
}


const char *Itoa(int num, char *buffer)
{
	int nNumDigits = GetNumDigits(num);
	bool bNeg = false;
	if(num & 0x80000000)
	{
		bNeg = true;
		num *= -1;
		buffer[0] = '-';
		buffer++;
	}
	for(int i = nNumDigits-1;i >= 0;i--,num/=10)
	{
		buffer[i] = char(48+(int(num%10)));
	}
	if(bNeg)
		buffer--;
	return buffer;
}

char * GetFileDirectory(const char *pProgramPath,char *pCurrentDirectory)
{// begin GetFileDirectory
	for(int i = lstrlen(pProgramPath)-1;i >= 0;i--)
		if(pProgramPath[i] == '\\')
		{// begin copy directory name into buffer
			lstrcpyn(pCurrentDirectory,pProgramPath,i+1);
			break;
		}// end copy directory name into buffer
	return pCurrentDirectory;
}// end GetFileDirectory

void SetAppDirectoryAsCurrent(void)
{// begin SetAppDirectoryAsCurrent
	// get the directory of the program
	char pCurrentDirectory[MAX_PATH] = {NULL};
	char pProgramPath[MAX_PATH] = {NULL};
	GetModuleFileName(GetModuleHandle(NULL),pProgramPath,MAX_PATH-1);
	// turn into a directory
	GetFileDirectory(pProgramPath,pCurrentDirectory);
	// set the current directory to the one the program is running from
	SetCurrentDirectory(pCurrentDirectory);
}// end SetAppDirectoryAsCurrent
