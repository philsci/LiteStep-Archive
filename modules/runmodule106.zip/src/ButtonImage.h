// ButtonImage.h: interface for the CButtonImage class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ButtonImage_H__0317E4E1_0333_11D4_93B2_00A0CC3702BF__INCLUDED_)
#define AFX_ButtonImage_H__0317E4E1_0333_11D4_93B2_00A0CC3702BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Thunk.h"

// button image attribs
#define BI_CENTERIMAGE 1		// 00000001
// other image attribs
#define BI_SIZE 8		// 00001000

class CButtonImage  
{
protected:
	virtual LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	ThunkData m_Thunk;
public:
	void SetTransparentColor(COLORREF cColor);
	void SetTextStyles(unsigned int styles);
	COLORREF SetFontColor(COLORREF color);
	COLORREF SetColor(COLORREF color);
	CButtonImage();
	virtual ~CButtonImage();
	void Create(UINT ID,HWND ownerWnd,HINSTANCE parentInstance,BYTE imageFlags,SIZE imgSz);
	SIZE SetImageSize(SIZE newImageSize);
	bool LoadCtrlImage(UINT iconID);
	HWND GetSafeHwnd(void);
protected:
	bool OnDestroy();
	virtual void Setup();
	virtual void Cleanup();
	COLORREF cTransparentColor;
	void Draw3dRect(HDC destDC,RECT *rect,COLORREF topLeftColor,COLORREF bottomRightColor);
	COLORREF GetHiliteColor(COLORREF color);
	COLORREF GetShadowColor(COLORREF color);
	SIZE GetButtonEdgeSize(unsigned long int extendedStyles);
	void DrawControlText(HDC buttonDC,char *buttonText,RECT &buttonTextRect);
	LRESULT OnPaint();
	int LevelColorBottom(int color);
	int LevelColorTop(int color);
	POINT buttonTopLeft;
	int OnSetStyle(unsigned long int styles,bool redraw);
	unsigned int OnGetState();
	void ToggleButtonState();
	int OnSetState(WPARAM state);
	HANDLE GetButtonImage();
	void OnClick(HWND hWnd,LPARAM lParam);
	void SetButtonImage(unsigned int type, HANDLE image);
	void OnMouseMove(LPARAM lParam);
	void DrawButtonFrame(const HDC buttonDC,RECT *buttonRect);
	void DrawButtonImage(const HDC buttonDC,const POINT imagePos);
	void DrawImage(const HDC hDC,const POINT *pLeftTop,HANDLE hImage = NULL);
	virtual RECT DrawButtonText(const HDC buttonDC,POINT &textPos, const RECT buttonRect);
	void ExpandRectangle(unsigned int num, RECT *rect);
	void ContractRectangle(unsigned int num,RECT *rect);
	void ExpandRectangle(SIZE size,RECT *rect);
	void ContractRectangle(SIZE size,RECT *rect);
	bool CleanUpImage();
	void DrawTransparentBitmap(HDC hDC, HBITMAP hBitmap, int x, int y, COLORREF crColour);
//	LRESULT OnSetText(WPARAM wParam,LPARAM lParam);

	virtual bool Draw(HDC originalButtonDC);

	void SetOffset(void);

	WNDPROC oldWndProc;
	HWND parentWnd;
	unsigned int ctrlID;
	bool firstDraw;
	COLORREF fontColor;
	bool hasFocus;
	unsigned int imageType;
	bool IsDown;
	POINT imageTopLeft;	
	int buttonState;
	HGDIOBJ buttonImage;
	SIZE imageSize;
	HWND ctrlWnd;
	HINSTANCE appInstance;
	BYTE flags;
	POINT lastPoint;
	bool cursorIsOut;
	unsigned int m_nTextStyles;
	unsigned int buttonColor;
	SIZE borderSize;
	UINT lastState;
	unsigned long int m_nStyles;
};

#endif // !defined(AFX_ButtonImage_H__0317E4E1_0333_11D4_93B2_00A0CC3702BF__INCLUDED_)
