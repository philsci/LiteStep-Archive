// GroupBoxImage.cpp: implementation of the CGroupBoxImage class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GroupBoxImage.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGroupBoxImage::CGroupBoxImage()
{
	CButtonImage::CButtonImage();
}

CGroupBoxImage::~CGroupBoxImage()
{
	CButtonImage::~CButtonImage();
}

void CGroupBoxImage::Create(UINT ID,HWND parent,HINSTANCE parentInstance,BYTE imageFlags,SIZE imgSz)
{
	// calculate image position
/*	RECT buttonRect;
	GetWindowRect(ctrlWnd,&buttonRect);
	*/
	CButtonImage::Create(ID,parent,parentInstance,imageFlags,imgSz);
	HDC buttonDC = GetWindowDC(ctrlWnd);
	HFONT font = (HFONT)SendMessage(ctrlWnd,WM_GETFONT,0,0);
	HFONT oldFont = (HFONT)SelectObject(buttonDC,font);
	char windowText[MAX_PATH] = {NULL};
	GetWindowText(ctrlWnd,windowText,MAX_PATH-1);
	int textLength = lstrlen(windowText);
	GetTextExtentPoint32(buttonDC,windowText,textLength,&textSize);
	SIZE oneCharSize = {NULL};
	GetTextExtentPoint32(buttonDC,"O",1,&oneCharSize);
	averageCharWidth = oneCharSize.cx;
	SelectObject(buttonDC,oldFont);
 	ReleaseDC(ctrlWnd,buttonDC);
//	imageTopLeft.x = textSize.cy/2;
}

RECT CGroupBoxImage::DrawGroupBox(HDC buttonDC)
{
	RECT buttonRect = {NULL};
	GetClientRect(ctrlWnd,&buttonRect);
	SIZE titleSize = {NULL};
	titleSize.cx = averageCharWidth+borderSize.cx+textSize.cx+imageSize.cx;
	if(textSize.cy > imageSize.cy)
		titleSize.cy = textSize.cy;
	else
		titleSize.cy = imageSize.cy;

	RECT textRect = {averageCharWidth,0,titleSize.cx,titleSize.cy};
	RECT hiliteGroupBoxRect = {1,textSize.cy/2+1,buttonRect.right,buttonRect.bottom};
	RECT sunkenGroupBoxRect = {0,textSize.cy/2,buttonRect.right-1,buttonRect.bottom-1};
	
	if(firstDraw)
	{
		RECT groupBoxInterior = sunkenGroupBoxRect;
		groupBoxInterior.right += 1;
		groupBoxInterior.bottom += 1;
		HRGN groupBoxRgn = CreateRectRgnIndirect(&groupBoxInterior);
		HRGN textRgn = CreateRectRgnIndirect(&textRect);
		ContractRectangle(2,&groupBoxInterior);
		HRGN interiorGroupBoxRgn = CreateRectRgnIndirect(&groupBoxInterior);
		CombineRgn(groupBoxRgn,groupBoxRgn,interiorGroupBoxRgn,RGN_DIFF);
		CombineRgn(groupBoxRgn,groupBoxRgn,textRgn,RGN_OR);
		SetWindowRgn(ctrlWnd,groupBoxRgn,true);	// don't delete groupBoxRgn, because a copy is not made
		DeleteObject(textRgn);
		DeleteObject(interiorGroupBoxRgn);
		firstDraw = false;
	}

//	COLORREF sunkenColor = RGB(LevelColorBottom(GetRValue(fontColor)+128),LevelColorBottom(GetGValue(fontColor)+128),LevelColorBottom(GetBValue(fontColor)+128));
//	COLORREF hiliteColor = RGB(LevelColorTop(GetRValue(fontColor)+216),LevelColorTop(GetGValue(fontColor)+216),LevelColorTop(GetBValue(fontColor)+216));
	COLORREF sunkenColor = GetShadowColor(buttonColor);
	COLORREF hiliteColor = GetHiliteColor(buttonColor);
	HBRUSH hiliteColorBrush = CreateSolidBrush(hiliteColor);
	HBRUSH sunkenColorBrush = CreateSolidBrush(sunkenColor);
	FrameRect(buttonDC,&hiliteGroupBoxRect,hiliteColorBrush);
	FrameRect(buttonDC,&sunkenGroupBoxRect,sunkenColorBrush);
	// fill in the 4 pixels that were missed
	SetPixel(buttonDC,sunkenGroupBoxRect.left,sunkenGroupBoxRect.bottom,hiliteColor);
	SetPixel(buttonDC,sunkenGroupBoxRect.right,sunkenGroupBoxRect.top,hiliteColor);
	SetPixel(buttonDC,textRect.right,textRect.bottom,buttonColor);
	SetPixel(buttonDC,textRect.right,textRect.top,buttonColor);

	DeleteObject(sunkenColorBrush);
	DeleteObject(hiliteColorBrush);
	return textRect;
}

bool CGroupBoxImage::Draw(HDC originalButtonDC)
{// begin Draw

	// get button info
	RECT buttonRect = {NULL};
	GetClientRect(ctrlWnd,&buttonRect);

	if(imageTopLeft.x < 0)
		imageTopLeft.x = 0;

	SIZE buttonSize = {buttonRect.right,buttonRect.bottom};

	HDC buttonDC = CreateCompatibleDC(originalButtonDC);
	HBITMAP buttonBitmap = CreateCompatibleBitmap(originalButtonDC,buttonRect.right,buttonRect.bottom);
	HGDIOBJ oldButtonBitmap = SelectObject(buttonDC,buttonBitmap);
	if(buttonDC != NULL)
	{// begin draw image

/*		// select the default button color brush to draw area with
		HGDIOBJ oldBrush = SelectObject(buttonDC,brush);
		// select the default button color pen to draw area with
		HPEN pen = CreatePen(PS_SOLID,1,buttonColor);
		HGDIOBJ oldPen = SelectObject(buttonDC,pen);*/

		RECT buttonTextRect = DrawGroupBox(buttonDC);
		POINT tempPoint = {buttonTextRect.left,buttonTextRect.top};
		// clear area for image and text
		// draw face
		HBRUSH brush = CreateSolidBrush(buttonColor);
		buttonTextRect.right -= 1;
		FillRect(buttonDC,&buttonTextRect,brush);
		buttonTextRect.right += 1;
		DeleteObject(brush);
//		Rectangle(buttonDC,buttonTextRect.left,buttonTextRect.top,buttonTextRect.right+1,buttonTextRect.bottom+1);
		// draw image
		DrawButtonImage(buttonDC,tempPoint);
		// draw the text
		DrawButtonText(buttonDC,tempPoint,buttonTextRect);
		
		// copy to originalButtonDC
		BitBlt(originalButtonDC,buttonTopLeft.x,buttonTopLeft.y,buttonSize.cx,buttonSize.cy,buttonDC,buttonTopLeft.x,buttonTopLeft.y,SRCCOPY);

		// clean up
		SelectObject(buttonDC,oldButtonBitmap);
/*		SelectObject(buttonDC,oldBrush);
		SelectObject(buttonDC,oldPen);
		DeleteObject(pen);
		*/
		DeleteObject(buttonBitmap);
		DeleteObject(oldButtonBitmap);
		DeleteDC(buttonDC);

		return true;
	}// end draw image
	return false;
}// end Draw