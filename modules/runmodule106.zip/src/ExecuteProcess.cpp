// ExecuteProcess.cpp: implementation of the CExecuteProcess class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ExecuteProcess.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExecuteProcess::CExecuteProcess()
{

}

CExecuteProcess::~CExecuteProcess()
{

}

int CExecuteProcess::RunProgram(char *pObject,char *pCommand)
{// begin RunProgram
	if(lstrcmp(pObject,"") == 0)
		return ERROR_FILE_NOT_FOUND;
	if(lstrcmp(pCommand,"") == 0)
	{
		lstrcpy(pCommand,"open");
	}

	// declarations
	int nRtnVal = 33;
	// deterimine object  type
	unsigned long int nObjectAttribs = GetFileAttributes(pObject);
	if(nObjectAttribs == 0xFFFFFFFF)
	{// begin fail
		// could be a file in the windows folder
		nRtnVal = WinExec(pObject,SW_SHOWNORMAL);
		if(nRtnVal > 31)
			nRtnVal = 33;
		// could be a URL check for a http://
		if(strstr(pObject,"http://"))
		{// begin launch URL
			nRtnVal = (int)ShellExecute(NULL,pCommand,pObject,NULL,NULL,SW_SHOWNORMAL);
		}// end launch URL
	}// end fail
	else if(nObjectAttribs & FILE_ATTRIBUTE_DIRECTORY)
	{// begin directory
		char pDir[MAX_PATH] = {NULL};
		if(lstrcmpi(pCommand,"explore") == 0)
			wsprintf(pDir,"explorer /e, \"%hs\"",pObject);
		else if(lstrcmpi(pCommand,"delete") == 0)
		{// begin delete
			if(!CStdFile::Delete(pObject))
				 nRtnVal = 0;
			else
				 nRtnVal = 33;
			return nRtnVal;
		}// end delete
		else if(lstrcmpi(pCommand,"rename") == 0)
		{// begin rename
			// find and replace the '=' to NULL
			char *pRenameString = pObject;
			for(int j = 0;pRenameString[j] != NULL;j++)
				if(pRenameString[j] == '=')
				{
					pRenameString[j] = '\0';
					pRenameString += j+1;
					break;
				}
			if(CStdFile::Rename(pObject,pRenameString+1))
				return 33;	// sucessful
			return 0;	// failed
		}// end rename
		else if(lstrcmpi(pCommand,"open") == 0)
			wsprintf(pDir,"explorer /n, \"%hs\"",pObject);
		else
			return (int)ShellExecute(NULL,pCommand,pObject,NULL,NULL,SW_SHOWNORMAL);
		nRtnVal = (int)WinExec(pDir,SW_SHOWNORMAL);
		if(nRtnVal > 31)
			nRtnVal = 33;
	}// end directory
	else
	{// begin file
		// set the object's current directory to the one that it is being run from
		char pCurrentDirectory[MAX_PATH] = {NULL};
		GetFileDirectory(pObject,pCurrentDirectory);
		if(lstrcmp("",pCurrentDirectory) != 0)
			SetCurrentDirectory(pCurrentDirectory);
		if(lstrcmpi(pCommand,"delete") == 0)
		{// begin delete
			SetAppDirectoryAsCurrent();	// since this isn't needed for deleting
			if(!CStdFile::Delete(pObject))
				 nRtnVal = 0;
			else
				 nRtnVal = 33;
			return nRtnVal;
		}// end delete
		else if(lstrcmpi(pCommand,"rename") == 0)
		{
			SetAppDirectoryAsCurrent();	// since this isn't needed for renaming
			// find and replace the '=' to NULL
			char *pRenameString = pObject;
			for(int j = 0;pRenameString[j] != NULL;j++)
				if(pRenameString[j] == '=')
				{
					pRenameString[j] = '\0';
					pRenameString += j+1;
					break;
				}
			if(CStdFile::Rename(pObject,pRenameString+1))
				return 33;	// sucessful
			return 0;	// failed
		}
		else if(lstrcmpi(pCommand,"open") == 0)
		{// begin open
			if(WinExec(pObject,SW_SHOWNORMAL) < 32)
			{// begin fail
				nRtnVal = (int)ShellExecute(NULL,pCommand,pObject,NULL,NULL,SW_SHOWNORMAL);
				if(nRtnVal == 31)
				{// begin find program
					char pFormattedString[MAX_PATH] = {NULL};
					char pNewObject[MAX_PATH] = {NULL};
					char pExtension[MAX_PATH] = {NULL};
					GetExtension(pObject,pExtension);
					GetDefaultApp(pExtension,pFormattedString);
					// insert pObject into program path
					FormatMessage( FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ARGUMENT_ARRAY,
						pFormattedString,
						NULL,
						MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
						pNewObject,
						MAX_PATH-1,
						&pObject);
					// run it
					nRtnVal = WinExec(pNewObject,SW_SHOWNORMAL);
					if(nRtnVal > 31)
						nRtnVal = 33;
					LocalFree(pNewObject);
				}// end find program
			}// end fail
		}// end open
		else
		{// begin default
			nRtnVal = (int)ShellExecute(NULL,pCommand,pObject,NULL,NULL,SW_SHOWNORMAL);
		}// end default
		SetAppDirectoryAsCurrent();
	}// end file
	return nRtnVal;
}// end RunProgram

const char * CExecuteProcess::GetExtension(const char *pFile,char *pBuffer)
// returns the extension of a file including the '.'
{// begin GetExtension
	for(int i = lstrlen(pFile)-1;i >= 0;i--)
	{// begin search
		if(pFile[i] == '.')
		{
			const char *pStart = &pFile[i];
			for(int j = 1;1;j++)
			{
				if(!IsCharAlphaNumeric(pStart[j]))
					return lstrcpyn(pBuffer,pStart,j+1);
			}
		}
	}// end search
	return NULL;
}// end GetExtension

const char * CExecuteProcess::GetDefaultApp(const char *pExtension, char *pBuffer)
// returns a formatting string 'MyApp.exe "%1"'
{// begin GetDefaultApp

	// open the CLASSES_ROOT section of registry
	HKEY hKey = NULL;
	char pSubKey[MAX_PATH] = {NULL};
	unsigned long int nBufferSize = MAX_PATH-1;
	unsigned long int nRegString = REG_SZ;
	RegOpenKeyEx(HKEY_CLASSES_ROOT,pExtension,0,KEY_READ,&hKey);
	// get the location of the program data
	RegQueryValueEx(hKey,NULL/*Get the default value*/,0,&nRegString,(unsigned char *)pSubKey,&nBufferSize);
	// close the key
	RegCloseKey(hKey);
	if(lstrcmp(pSubKey,"") == 0)
	{// begin no program
		// exit
		return NULL;
	}// end no program
	// open the other location
	HKEY hSubKey = NULL;
	char pFirstSubKey[MAX_PATH] = {NULL};
	wsprintf(pFirstSubKey,"%hs\\shell",pSubKey);
	RegOpenKeyEx(HKEY_CLASSES_ROOT,pFirstSubKey,0,KEY_READ,&hSubKey);
	// get the location of the first app
	char pFirstApp[MAX_PATH] = {NULL};
	unsigned long int nFirstSize = MAX_PATH-1;
	RegEnumKey(hSubKey,0,pFirstApp,nFirstSize);
	RegCloseKey(hSubKey);
	if(lstrcmp(pFirstApp,"") == 0)
	{// begin no program
		// exit
		return NULL;
	}// end no program
	// now get the actual app
	HKEY hProgramKey = NULL;
	char pApp[MAX_PATH] = {NULL};
	wsprintf(pApp,"%hs\\%hs\\command",pFirstSubKey,pFirstApp);
	RegOpenKeyEx(HKEY_CLASSES_ROOT,pApp,0,KEY_READ,&hProgramKey);
	// get the first app
	unsigned long int nAppSize = MAX_PATH-1;
	RegQueryValueEx(hProgramKey,NULL/*Get the default value*/,0,&nRegString,(unsigned char *)pApp,&nAppSize);
	RegCloseKey(hProgramKey);
	if(lstrcmp(pApp,"") == 0)
	{// begin no program
		// exit
		return NULL;
	}// end no program
	// copy into the buffer
	lstrcpy(pBuffer,pApp);
	return pBuffer;
}// end GetDefaultApp

