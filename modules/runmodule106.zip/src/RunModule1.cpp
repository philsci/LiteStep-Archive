// RunModule1.cpp: implementation of the CRunModule class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RunModule1.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DWORD WINAPI DoRunProgram( LPVOID pData );

DWORD WINAPI DoRunProgram( LPVOID pData )
{// begin DoRunProgram
	CRunModule *pThisClass = (CRunModule *)pData;
	pThisClass->OnButtonOk();
	return 0;
}// end DoRunProgram

CRunModule::CRunModule()
{
	m_bNoCaption = false;
	m_bHideDescriptions = false;
}

CRunModule::CRunModule(const char *pCommandLine)
{// begin CRunModule(const char *pCommandLine)
	// initilize class variables
	// snap pixels
	m_nSnapPixels = 3;
	// get the desktop rectangle for snappyness
	GetWindowRect(GetDesktopWindow(),&m_rDesktopRect);
	m_nThreadID	= 1;
	m_nErrorCode = 0;
	m_pListFile[0] = NULL;
	// parse command line
	CCommandLine clCmdLine(pCommandLine);
	bool bIgnoreErrors = false;
	bool bBatchRun = false;
	int nDelayExec = 0;
	char pBuffer[MAX_PATH] = {NULL};
	char pCommand[MAX_PATH] = {NULL};
	char pObject[MAX_PATH] = {NULL};
	char cSwitch = NULL;
	while((cSwitch = clCmdLine.GetNextSwitch()))
	{// begin parse command line
			switch(cSwitch)
			{// begin cSwitch switch
				case 'o':	// object/file/folder
					clCmdLine.GetNextString(pObject);
					//MessageBox(NULL,pObject,"/o switch data",MB_OK);
					break;
				case 'c':	// action to perform on object
					clCmdLine.GetNextString(pCommand);
					//MessageBox(NULL,pCommand,"/c switch data",MB_OK);
					break;
				case 'f':	// set the data file
					clCmdLine.GetNextString(m_pListFile);
					//MessageBox(NULL,m_pListFile,"/f switch data",MB_OK);
					break;
				case 'b':	// batch run data file
					bBatchRun = true;
					break;
				case 'i':	// ignore batch run errors 
					bIgnoreErrors = true;
					break;
				case 'd':	// delay executing objects (ms)
					clCmdLine.GetNextString(pBuffer);
					nDelayExec = Atoi(pBuffer);
					break;
				default:	// invalid switch
					break;
			}// end cSwitch switch
	}// end parse command line
	if(pObject[0])
	{// begin execute object
		m_nErrorCode = RunProgram(pObject,pCommand);
	}// end execute object
	if(!m_pListFile[0])
	{// begin use default file list
		lstrcpy(m_pListFile,"list.ini");
	}// end use default file list
	if(bBatchRun)
	{// begin BatchRun
		m_nErrorCode = BatchRun(nDelayExec,bIgnoreErrors);
	}// end BatchRun
}// end CRunModule(const char *pCommandLine)


CRunModule::~CRunModule()
{

}

bool CRunModule::Init(HINSTANCE hInstance, HWND hParent, unsigned long nTemplateID, bool bDoModal)
{// begin Init
	if(m_nErrorCode)	// check for command line run
		return false;
	return CMyDialog::Init(hInstance,hParent,nTemplateID,bDoModal);
}// end Init

bool CRunModule::OnInitDialog(HWND hDlg)
{// begin OnInitDialog
	CMyDialog::OnInitDialog(hDlg);

	// add "Task Manager" to the system menu
	HMENU hSysMenu = GetSystemMenu(hDlg,false);
	char pTask[] = "Task Manager";
	AppendMenu(hSysMenu,MF_SEPARATOR,0,pTask);
	AppendMenu(hSysMenu,MF_STRING,IDM_TASKMANAGER,pTask);
	// add "Control Panel" to the system menu
	char pControl[] = "Control Panel";
	AppendMenu(hSysMenu,MF_STRING,IDM_CONTROLPANEL,pControl);
	// add "About..." to the system menu
	char pAbout[] = "About...";
	AppendMenu(hSysMenu,MF_SEPARATOR,0,pTask);
	AppendMenu(hSysMenu,MF_STRING,IDM_ABOUT,pAbout);

	// set the window Icon
	SendMessage(m_hDlg,WM_SETICON,ICON_SMALL,(LPARAM)(HICON)LoadImage(m_hInstance,MAKEINTRESOURCE(IDI_RUNMODULE),IMAGE_ICON,16,16,LR_DEFAULTCOLOR));   
	SendMessage(m_hDlg,WM_SETICON,ICON_BIG,(LPARAM)(HICON)LoadImage(m_hInstance,MAKEINTRESOURCE(IDI_RUNMODULE),IMAGE_ICON,32,32,LR_DEFAULTCOLOR));   
	SIZE imageSize = {16,16};
	// subclass the combobox
	m_ccObject.Init(GetDlgItem(m_hDlg,IDC_COMBO_RUN));
	m_cacCommand.Init(GetDlgItem(m_hDlg,IDC_COMBO_OPTION));
	// initilize the buttons with the required variables
	m_biOkButton.Create(IDOK,m_hDlg,m_hInstance,BI_SIZE|BI_CENTERIMAGE,imageSize);
	m_biCancelButton.Create(IDCANCEL,m_hDlg,m_hInstance,BI_SIZE|BI_CENTERIMAGE,imageSize);
	m_biBrowseButton.Create(IDC_BROWSE,m_hDlg,m_hInstance,BI_SIZE|BI_CENTERIMAGE,imageSize);
	m_biAboutButton.Create(IDC_ABOUT,m_hDlg,m_hInstance,BI_SIZE|BI_CENTERIMAGE,imageSize);
	m_cbiCloseCheck.Create(IDC_CHECK_CLOSE,m_hDlg,m_hInstance,BI_SIZE,imageSize);

	// manually set the styles of the text (do this automatically later)
	m_biOkButton.SetTextStyles(DT_CENTER|DT_VCENTER|DT_NOCLIP|DT_SINGLELINE);
	m_biCancelButton.SetTextStyles(DT_CENTER|DT_VCENTER|DT_NOCLIP|DT_SINGLELINE);
	m_biBrowseButton.SetTextStyles(DT_CENTER|DT_VCENTER|DT_NOCLIP|DT_SINGLELINE);
	m_biAboutButton.SetTextStyles(DT_CENTER|DT_VCENTER|DT_NOCLIP|DT_SINGLELINE);
	m_cbiCloseCheck.SetTextStyles(DT_VCENTER|DT_NOCLIP|DT_SINGLELINE);


	m_biOkButton.SetColor(RGB(0,200,0));
	m_biCancelButton.SetColor(RGB(200,0,0));
	m_biBrowseButton.SetColor(RGB(223,223,0));
	m_biAboutButton.SetColor(RGB(0,174,174));

	// load the desired icon into the button
	m_biOkButton.LoadCtrlImage(IDB_BITMAP_OK);
	m_biCancelButton.LoadCtrlImage(IDB_BITMAP_CANCEL);
	m_biBrowseButton.LoadCtrlImage(IDB_BITMAP_BROWSE);
	m_biAboutButton.LoadCtrlImage(IDB_BITMAP_ABOUT);
	m_cbiCloseCheck.LoadCtrlImage(IDI_RUNMODULE);

	// move all the windows to the desired positions
	// NOTE: do this in the reverse tab order to preserve order
	LoadWindowPlacement(m_hDlg,"wnd");
	LoadWindowPlacement(GetDlgItem(m_hDlg,IDC_STATIC_MESSAGE),"status-edit");
	LoadWindowPlacement(m_cbiCloseCheck.GetSafeHwnd(),"close-check");
	LoadWindowPlacement(m_biAboutButton.GetSafeHwnd(),"about-button");
	LoadWindowPlacement(m_biBrowseButton.GetSafeHwnd(),"browse-button");
	LoadWindowPlacement(m_biCancelButton.GetSafeHwnd(),"exit-button");
	LoadWindowPlacement(m_biOkButton.GetSafeHwnd(),"ok-button");
	LoadWindowPlacement(GetDlgItem(m_hDlg,IDC_COMBO_OPTION),"command-combo");
	LoadWindowPlacement(m_ccObject.GetSafeHwnd(),"object-combo");

	// load settings
	CRunModuleData rmdSettings;
	m_bHideDescriptions = rmdSettings.HideDescriptions();
	if(m_bHideDescriptions)
	{// begin hide
		ShowWindow(GetDlgItem(m_hDlg,IDC_STATIC_OBJECT),SW_HIDE);
		ShowWindow(GetDlgItem(m_hDlg,IDC_STATIC_COMMAND),SW_HIDE);
		SetWindowText(m_biOkButton.GetSafeHwnd(),"");
		SetWindowText(m_biCancelButton.GetSafeHwnd(),"");
		SetWindowText(m_biBrowseButton.GetSafeHwnd(),"");
		SetWindowText(m_biAboutButton.GetSafeHwnd(),"");
		SetWindowText(m_cbiCloseCheck.GetSafeHwnd(),"");
	}// end hide
	WPARAM wState = 0;
	if(rmdSettings.GetStayOpen())
		wState = BST_CHECKED;
	else
		wState = BST_UNCHECKED;
	m_cbiCloseCheck.SetCheckState(wState);
	// change the dialog style
	unsigned long int nStyles = GetWindowLong(m_hDlg,GWL_STYLE);
	m_bNoCaption = rmdSettings.NoCaption();
	if(m_bNoCaption)
	{// begin remove the caption area
		nStyles ^= WS_CAPTION;
	}// end remove the caption area
	unsigned long int nExStyles = GetWindowLong(m_hDlg,GWL_EXSTYLE);
	HWND hZOrder = NULL;
	if(rmdSettings.MakeToolWindow())
		nExStyles |= WS_EX_TOOLWINDOW;
	if(rmdSettings.MakeTopMost())
		hZOrder = HWND_TOPMOST;
	// apply the settings
	SetWindowLong(m_hDlg,GWL_STYLE,nStyles);
	SetWindowLong(m_hDlg,GWL_EXSTYLE,nExStyles);
	// flush the window cache
	SetWindowPos(m_hDlg,hZOrder,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_FRAMECHANGED);
	// set the focus to the edit control of the combobox
	SetFocus(GetDlgItem(m_ccObject.GetSafeHwnd(),1001));

	// load the previous runs in the combo box
	LoadRunComboBox();
	// return true so that the focus is left on the edit control
	return false;
}// end OnInitDialog

bool CRunModule::LoadRunComboBox()
{// begin LoadRunComboBox
	// load the files combo box
//	HWND hObject = GetDlgItem(m_hDlg,IDC_COMBO_RUN);
//	HWND hCommand = GetDlgItem(m_hDlg,IDC_COMBO_OPTION);
	char pObject[1024] = {NULL};
	char pCommand[1024] = {NULL};
	CRunModuleListFile rmlfFile;
	rmlfFile.SetFile(m_pListFile);
	// empty the combo boxes
	m_ccObject.ResetContent();
	m_cacCommand.ResetContent();
//	::SendMessage(hObject,CB_RESETCONTENT,0,0);
//	::SendMessage(hCommand,CB_RESETCONTENT,0,0);
	for(int i = 1;rmlfFile.GetItem(i,pObject,pCommand);i++)
	{// begin load string into combo box
//		if(SendMessage(hObject,CB_SELECTSTRING,(WPARAM)0,(LPARAM)pObject) == CB_ERR)
		if(m_ccObject.SelectString(0,pObject) == CB_ERR)
			m_ccObject.AddString(pObject);
//		if(SendMessage(hCommand,CB_SELECTSTRING,(WPARAM)0,(LPARAM)pCommand) == CB_ERR)
		if(m_cacCommand.SelectString(0,pCommand) == CB_ERR)
			m_cacCommand.AddString(pCommand);
	}// end load string into combo box
	return true;
}// begin LoadRunComboBox

LRESULT CRunModule::DlgProc(HWND hDlg,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin DlgProc
	switch (nMessage) 
	{
	case WM_SYSCOMMAND:
		return OnSysCommand(wParam,lParam);
	case WM_DESTROY:
		return OnDestroy();
	case WM_MOVING:
		OnMoving(wParam,lParam);
		break;
	case WM_LBUTTONDOWN:
		if(m_bNoCaption)
			return OnLButtonDown(wParam,lParam);
		break;
	case WM_CONTEXTMENU:
		if(m_bNoCaption)
			return OnContextMenu(wParam,lParam);
		break;
	}
	return CMyDialog::DlgProc(hDlg,nMessage,wParam,lParam);
}// end DlgProc

bool CRunModule::OnDestroy()
{// begin OnDestroy
	// cleanup the icons
	DestroyIcon((HICON)SendMessage(m_hDlg,WM_SETICON,ICON_SMALL,(LPARAM)NULL));
	// save the main window's position
	RECT rWndRect = {NULL};
	GetWindowRect(m_hDlg,&rWndRect);
	POINT pt = {rWndRect.left,rWndRect.top};
	CRunModuleData rmdSettings;
	rmdSettings.SetWndPos(pt);
	if(m_cbiCloseCheck.GetCheckState() == BST_CHECKED)
		rmdSettings.SetStayOpen(true);
	else
		rmdSettings.SetStayOpen(false);
	return false;
}// end OnDestroy

bool CRunModule::OnCommand(WPARAM wParam, LPARAM lParam)
{// begin OnCommand
	int nID = LOWORD(wParam); 
	int nEvent = HIWORD(wParam); 
	// Parse the menu selections:
	switch (nID)
	{// begin parse controls
		case IDOK:
			unsigned long int nThreadID;
			nThreadID = GetNextThreadID();
			CreateThread(NULL,0,DoRunProgram,this,0,&nThreadID);
		   break;
		case IDCANCEL:
		   EndDialog(0);
		   break;
		case IDC_BROWSE:
		   OnButtonBrowse();
		   break;
		case IDC_ABOUT:
			OnAbout();
			break;
		case IDC_COMBO_RUN:
			switch(nEvent)
			{// begin wmEvent
				case CBN_SELENDOK:
					LoadItemCommand();
					break;
			}// end wmEvent
			break;
		default:
		   return true;
	}// end parse controls
	return false;
}// end OnCommand

unsigned long int CRunModule::GetNextThreadID()
{// begin GetNextThreadID
	return m_nThreadID++;
}// end GetNextThreadID

void CRunModule::OnButtonBrowse()
{// begin OnButtonBrowse
	char pFilePath[1024] = {NULL};
	char pOldCurrentDirectory[1024] = {NULL};
	GetCurrentDirectory(1023,pOldCurrentDirectory);
		OPENFILENAME ofnAttribs = {sizeof(OPENFILENAME),
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		pFilePath,
		1023,
		NULL,//titleBuffer,
		NULL,//1023,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL
		};
	GetOpenFileName(&ofnAttribs);
    // select the string in to the IDC_COMBO_RUN ComboBox
	SetDlgItemText(m_hDlg,IDC_COMBO_RUN,pFilePath);
	// choose open from the IDC_COMBO_OPTION ComboBox
	m_cacCommand.SelectString(-1,"open");
//	SendMessage(GetDlgItem(m_hDlg,IDC_COMBO_OPTION),CB_SELECTSTRING,(WPARAM)-1,(LPARAM)"open");
	// set old directory back
	SetCurrentDirectory(pOldCurrentDirectory);
}// end OnButtonBrowse

bool CRunModule::LoadItemCommand()
{// begin LoadItemCommand
	int nItemIndex = 0;
	bool bFound = false;
//	HWND hComboRun = GetDlgItem(m_hDlg,IDC_COMBO_RUN);
//	nItemIndex = SendMessage(hComboRun,CB_GETCURSEL,0,0);
	nItemIndex = m_ccObject.GetCurSel();
	if(nItemIndex != CB_ERR)
	{// begin item selected
		char *pObject = NULL;
		char pCommand[MAX_PATH] = {NULL};
		char *pTmpObject = NULL;
		char pCurrentSection[16] = {NULL};
		int nObjectLen = m_ccObject.GetLBTextLen(nItemIndex);
		pObject = new char [nObjectLen+1];
		pTmpObject = new char [nObjectLen+1];
		m_ccObject.GetLBText(nItemIndex,pObject);	
//		SendMessage(hComboRun,CB_GETLBTEXT,(WPARAM) nItemIndex,(LPARAM) pObject);
		CRunModuleListFile ifFile;
		ifFile.SetFile(m_pListFile);
		for(int i = 1;!bFound && ifFile.ReadKey(Itoa(i,pCurrentSection),"object","",pTmpObject,nObjectLen);i++)
		{// begin search file
			if(lstrcmpi(pTmpObject,pObject) == 0)
			{// begin object found
				bFound = true;
				ifFile.ReadKey(Itoa(i,pCurrentSection),"command","open",pCommand,MAX_PATH-1);
			}// end object found
		}// end search file
		if(bFound)
		{// begin select command
//			unsigned long int nErrorMessage = SendMessage(GetDlgItem(m_hDlg,IDC_COMBO_OPTION),CB_SELECTSTRING,0,(LPARAM)pCommand);
			unsigned long int nErrorMessage = m_cacCommand.SelectString(0,pCommand);
			if(nErrorMessage == CB_ERR)
			{// begin error
				delete []pObject;
				delete []pTmpObject;
				return false;
			}// end error
		}// end select command
		delete []pObject;
		delete []pTmpObject;
	}// end item selected
	return bFound;
}// end LoadItemCommand

void CRunModule::OnButtonOk()
{// begin OnButtonOk
	char *pObject = NULL;
	char *pCommand = NULL;
	int nObjectLen = GetWindowTextLength(m_ccObject.GetSafeHwnd());
	int nCommandLen = GetWindowTextLength(m_cacCommand.GetSafeHwnd());
	pObject = new char[nObjectLen+1];
	pCommand = new char[nCommandLen+1];
	GetWindowText(m_ccObject.GetSafeHwnd(),pObject,nObjectLen+1);
	GetWindowText(m_cacCommand.GetSafeHwnd(),pCommand,nCommandLen+1);
//	GetDlgItemText(m_hDlg,IDC_COMBO_RUN,pObject,MAX_PATH-1);
//	GetDlgItemText(m_hDlg,IDC_COMBO_OPTION,pCommand,MAX_PATH-1);
	if(lstrcmp(pCommand,"") == 0)
	{
		SetDlgItemText(m_hDlg,IDC_COMBO_OPTION,"open");
	}
	// disable run button
//	HWND hOkButton = GetDlgItem(m_hDlg,IDOK);
	EnableWindow(m_biOkButton.GetSafeHwnd(),false);
	int nErrorCode = RunProgram(pObject,pCommand);
	if(nErrorCode > 32)
	{// begin successful
		DisplayMessage("Saving...");
		CRunModuleListFile rmlfFile;
		rmlfFile.SetFile(m_pListFile);
		rmlfFile.AddItem(pObject,pCommand);
		LoadRunComboBox();
		DisplayMessage("OK");
	}// end successful
	else
	{// begin error
		char *pBuffer = NULL;
		DisplayMessage(GetErrorMessage(pBuffer));
		LocalFree(pBuffer);
	}// end error

	// enable run button
	EnableWindow(m_biOkButton.GetSafeHwnd(),true);
//	bool bDontClose = (bool)::SendMessage(GetDlgItem(m_hDlg,IDC_CHECK_CLOSE),BM_GETCHECK,0,0);
	bool bDontClose = m_cbiCloseCheck.GetCheckState();
	if(!bDontClose)
		EndDialog(0);
	delete []pObject;
	delete []pCommand;
}// end OnButtonOk

void CRunModule::DisplayMessage(const char *pMessage)
{// begin DisplayMessage
	if(m_bHideDescriptions)
	{// begin display in title
		char pTitle[] = "Run command . . . - ";
		char *pTitleMessage = new char[lstrlen(pTitle)+lstrlen(pMessage)+1];
		lstrcpy(pTitleMessage,pTitle);
		lstrcat(pTitleMessage,pMessage);
		SetWindowText(m_hDlg,pTitleMessage);
	}// end display in title
	SetDlgItemText(m_hDlg,IDC_STATIC_MESSAGE,pMessage);
	UpdateWindow(GetDlgItem(m_hDlg,IDC_STATIC_MESSAGE));
}// end DisplayMessage

bool CRunModule::HasChar(char *pString,char cChar)
{// begin HasChar
	for(;*pString != cChar;pString++);
	if(*pString == cChar)
		return true;
	return false;
}// end HasChar

int CRunModule::RunProgram(char *pObject,char *pCommand)
{// begin RunProgram
	return CExecuteProcess::RunProgram(pObject,pCommand);
}// end RunProgram

int CRunModule::BatchRun(int nDelayExec, bool bIgnoreErr)
{// begin BatchRun
	// execute all of the objects in the data file
	CRunModuleListFile ifFile;
	ifFile.SetFile(m_pListFile);
	char pObject[MAX_OBJECT_LENGTH] = {NULL};
	char pCommand[MAX_PATH] = {NULL};
	int nLastItem = 0;
	CRunModuleListFile rmlfFile;
	rmlfFile.SetFile(m_pListFile);
	rmlfFile.FindItem("?","?",nLastItem);
	nLastItem--;	// adjust so that is the last section
	int nErrorCode = 0;
	for(int i = 1;ifFile.GetItem(i,pObject,pCommand);i++)
	{// begin execute command
		if(((nErrorCode = RunProgram(pObject,pCommand)) < 33) && !bIgnoreErr)
		{
			char pErrorMessage[MAX_PATH] = {NULL};
			char *pErrorCode = NULL;
			wsprintf(pErrorMessage,"Error: Section [%i].\r\nFile: %hs\r\n------------\r\nobject = %hs\r\ncommand = %hs\r\n------------\r\nDetails: %hs\r\nWould you like to open this file for editing?\r\n[Enter]=No\r\n[Esc]=\"Cancel\"\r\n\"Cancel\"=Stop Executing",i,ifFile.GetFilePath(),pObject,pCommand,GetErrorMessage(pErrorCode));
			// free the error message buffer
			LocalFree(pErrorCode);
			int nBtnVal = MessageBox(NULL,pErrorMessage,"RunModule - Error",MB_YESNOCANCEL|MB_ICONWARNING|MB_DEFBUTTON2|MB_SETFOREGROUND);
			if(nBtnVal == IDYES)
			{
				char pDir[MAX_OBJECT_LENGTH] = {NULL};
				lstrcpy(pDir,ifFile.GetFilePath());
				RunProgram(pDir,NULL);
			}
			else if(nBtnVal == IDCANCEL)
			{
				return true;
			}

		}
		if(i >= nLastItem)
		{
			return true;	// no more objects to execute no need to delay
		}
		Sleep(nDelayExec);
	}// end execute command
	return i;	// return the section that the error occured in
}// end BatchRun

const char *CRunModule::GetErrorMessage(char *pBuffer)
{// begin GetErrorMessage
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS|
		FORMAT_MESSAGE_MAX_WIDTH_MASK,	// remove this flag if you want line breaks
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &pBuffer,
		0,
		NULL 
	);
	return pBuffer;
}// end GetErrorMessage

bool CRunModule::OnSysCommand(WPARAM wParam, LPARAM lParam)
{// begin OnSysCommand
	unsigned long int nCmdType = wParam;
//	POINT pCoord = {LOWORD(lParam),HIWORD(lParam)};   
	switch(nCmdType)
	{// begin parse command
		case IDM_TASKMANAGER:
			RunProgram("taskmgr",NULL);
			break;
		case IDM_CONTROLPANEL:
			RunProgram("control",NULL);
			break;
		case IDM_ABOUT:
			OnAbout();
			break;
	}// end command
	return false;	// return false since we are processing the message
}// end OnSysCommand

void CRunModule::OnAbout()
{// begin OnAbout
	CAbout aDlg;
	aDlg.Init(m_hInstance,m_hDlg,IDD_DIALOG_ABOUT,true);
}// end OnAbout

void CRunModule::OnMoving(WPARAM &wParam,LPARAM &lParam)
{// begin OnMoving
	RECT *pRect = (RECT *)lParam;
	// calculate window size
	SIZE szSize = {pRect->right-pRect->left,pRect->bottom-pRect->top};
	// snap window to screen edges
	if(pRect->top < m_nSnapPixels && pRect->top > -m_nSnapPixels)
	{// begin snap to top
		pRect->top = 0;
		pRect->bottom = szSize.cy;
	}// end snap to top
	if(pRect->left < m_nSnapPixels && pRect->left > -m_nSnapPixels)
	{// begin snap to left
		pRect->left = 0;
		pRect->right = szSize.cx;
	}// end snap to left
	if(pRect->right < m_rDesktopRect.right+m_nSnapPixels && pRect->right > m_rDesktopRect.right-m_nSnapPixels)
	{// begin snap to right
		pRect->right = m_rDesktopRect.right;
		pRect->left = m_rDesktopRect.right-szSize.cx;
	}// end snap to right
	if(pRect->bottom < m_rDesktopRect.bottom+m_nSnapPixels && pRect->bottom > m_rDesktopRect.bottom-m_nSnapPixels)
	{// begin snap to bottom
		pRect->bottom = m_rDesktopRect.bottom;
		pRect->top = m_rDesktopRect.bottom-szSize.cy;
	}// end snap to bottom
}// end OnMoving

void CRunModule::LoadWindowPlacement(HWND hWnd,const char *pName)
{// begin LoadWindowPlacement
	// command combo
	unsigned long int nFlags = SWP_NOOWNERZORDER;
	CRunModuleData rmdSettings;
	POINT ptPos = rmdSettings.GetPos(pName);
	SIZE szSize = rmdSettings.GetSize(pName);
	// ignore the size if it is less than 1
	if(szSize.cx < 1 || szSize.cy < 1)
		nFlags |= SWP_NOSIZE;
	// ignore the position if it is less than 0
	if(ptPos.x < 0 || ptPos.y < 0)
		nFlags |= SWP_NOMOVE;
	SetWindowPos(hWnd,NULL,ptPos.x,ptPos.y,szSize.cx,szSize.cy,nFlags);
}// end LoadWindowPlacement

LRESULT CRunModule::OnLButtonDown(WPARAM wParam, LPARAM lParam)
{// begin OnLButtonDown
	return PostMessage(m_hDlg,WM_NCLBUTTONDOWN,HTCAPTION,MAKELPARAM(LOWORD(lParam),HIWORD(lParam)));
}// end OnLButtonDown

LRESULT CRunModule::OnContextMenu(WPARAM wParam, LPARAM lParam)
{// begin OnRButtonDown
	HMENU hSysMenu = GetSystemMenu(m_hDlg,false);
	int nSelItem = TrackPopupMenuEx(hSysMenu,TPM_LEFTALIGN|TPM_TOPALIGN|TPM_RETURNCMD|TPM_NONOTIFY|TPM_RIGHTBUTTON,LOWORD(lParam),HIWORD(lParam),m_hDlg,NULL);
	return PostMessage(m_hDlg,WM_SYSCOMMAND,(WPARAM)nSelItem,lParam);
}// end OnRButtonDown