// HLS.h: interface for the CHLS class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HLS_H__73AE3C41_8029_11D4_93B2_00A0CC3702BF__INCLUDED_)
#define AFX_HLS_H__73AE3C41_8029_11D4_93B2_00A0CC3702BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define  HLSMAX   252	// H,L, and S vary over 0-HLSMAX 
#define  RGBMAX   252   // R,G, and B vary over 0-RGBMAX 
                        // HLSMAX BEST IF DIVISIBLE BY 6 
                        // RGBMAX, HLSMAX must each fit in a byte. 

// Hue is undefined if Saturation is 0 (grey-scale) 
// This value determines where the Hue scrollbar is 
// initially set for achromatic colors 
#define UNDEFINED (HLSMAX*2/3)

class CHLS
{// begin CHLS

public:
	CHLS::CHLS();
	CHLS::CHLS(unsigned short int h,unsigned short int l,unsigned short int s);	//constructor #2
	CHLS::CHLS(unsigned long int RGBColor);
	~CHLS();
	unsigned short int CHLS::HueToRGB(unsigned short int n1,unsigned short int n2,unsigned short int hue);
	unsigned long int CHLS::ToRGB();

protected:
	unsigned short int H;
	unsigned short int L;
	unsigned short int S;
};// end CHLS
#endif // !defined(AFX_HLS_H__73AE3C41_8029_11D4_93B2_00A0CC3702BF__INCLUDED_)
