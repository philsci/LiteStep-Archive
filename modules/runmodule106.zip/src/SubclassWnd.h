// SubclassWnd.h: interface for the CSubclassWnd class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SUBCLASSWND_H__96328E9D_0021_43F3_94B6_288FE146D747__INCLUDED_)
#define AFX_SUBCLASSWND_H__96328E9D_0021_43F3_94B6_288FE146D747__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Thunk.h"

class CSubclassWnd  
{
protected:
	virtual LRESULT WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam);	// this must be the first declared virtual function
	ThunkData m_Thunk;
public:
	HWND GetSafeHwnd();
	virtual bool Init(HWND hSubclassWnd);
	CSubclassWnd();
	virtual ~CSubclassWnd();
protected:
	virtual void OnDestroy();

	// member variables
	HWND m_hWnd;
	HINSTANCE m_hInstance;
	WNDPROC m_wpOldWndProc;

};

#endif // !defined(AFX_SUBCLASSWND_H__96328E9D_0021_43F3_94B6_288FE146D747__INCLUDED_)
