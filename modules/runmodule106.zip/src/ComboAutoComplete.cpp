// ComboAutoComplete.cpp: implementation of the CComboAutoComplete class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ComboAutoComplete.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComboAutoComplete::CComboAutoComplete()
{
	m_nLastTextLength = 0;
}

CComboAutoComplete::~CComboAutoComplete()
{

}

LRESULT CComboAutoComplete::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_COMMAND:
		if(HIWORD(wParam) == EN_CHANGE && LOWORD(wParam) == 1001)
			OnChange(wParam,lParam);
		break;
	}// end nMessage swtich
	return CMyComboBox::WndProc(hWnd, nMessage, wParam, lParam);
}// end WndProc

void CComboAutoComplete::OnChange(WPARAM wParam,LPARAM lParam)
{// begin OnChange
	char *pString = NULL;
	char *pFoundString = NULL;
	int nLength = GetWindowTextLength(m_hWnd);
	pString = new char[nLength+1];
 	GetWindowText(m_hWnd,pString,nLength+1);
	int nIndexFound = 0;
	if(nLength > 0 && nLength > m_nLastTextLength)
	{// begin autocomplete
		nIndexFound = FindString(-1, pString);
		if(nIndexFound != -1)
		{// begin partail match found
			int nFoundLength = GetLBTextLen(nIndexFound);
			if(nFoundLength != CB_ERR)
			{// begin no error
				pFoundString = new char[nFoundLength+1];
				GetLBText(nIndexFound, pFoundString);
				SelectString(nIndexFound, pFoundString);
				SetEditSel(nLength, -1);
				if(GetDroppedState())
					ShowDropDown(false);
			}// end no error
		}// end partial match found
		else
			ShowDropDown(true);
	}// end autocomplete
	else
	{// begin close dropdown
		if(GetDroppedState())
			ShowDropDown(false);
		SetEditSel(nLength, nLength);
	}// end close dropdown
	m_nLastTextLength = nLength;
	if(pString)
		delete []pString;
	if(pFoundString)
		delete []pFoundString;
}// end OnChange