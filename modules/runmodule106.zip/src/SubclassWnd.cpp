// SubclassWnd.cpp: implementation of the CSubclassWnd class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SubclassWnd.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSubclassWnd::CSubclassWnd()
{
	m_hInstance = GetModuleHandle(NULL);
	m_hWnd = NULL;
	m_wpOldWndProc = NULL;
	// init the ThunkData with the this pointer so that this can be subclassed
	ThunkInit(m_Thunk, this);
}

CSubclassWnd::~CSubclassWnd()
{
	if(m_wpOldWndProc || m_hWnd)
		OnDestroy();
}

bool CSubclassWnd::Init(HWND hSubclassWnd)
{// begin Init
	// save HWND
	if(!hSubclassWnd)
		return false;
	m_hWnd = hSubclassWnd;
	// subclass the window
	m_wpOldWndProc = (WNDPROC)SetWindowLong(m_hWnd,GWL_WNDPROC,(LONG)(void *)m_Thunk);
	if(!m_wpOldWndProc)
		return false;
	return true;
}// end Init

LRESULT CSubclassWnd::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_DESTROY:
		OnDestroy();
		break;
	}// end nMessage swtich
	return CallWindowProc(m_wpOldWndProc,hWnd, nMessage, wParam, lParam);
}// end WndProc

void CSubclassWnd::OnDestroy()
{// begin OnDestroy
	// remove subclassing
	if(m_wpOldWndProc)
	{
		SetWindowLong(m_hWnd,GWL_WNDPROC,(LONG)m_wpOldWndProc);
		m_wpOldWndProc = NULL;
	}
	m_hWnd = NULL;
}// end OnDestroy

HWND CSubclassWnd::GetSafeHwnd()
{// begin GetSafeHwnd
	return m_hWnd;
}// end GetSafeHwnd
