// RadioButtonImage.cpp: implementation of the CRadioButtonImage class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RadioButtonImage.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRadioButtonImage::CRadioButtonImage()
{
	CCheckBoxImage::CCheckBoxImage();
}

CRadioButtonImage::~CRadioButtonImage()
{
	CCheckBoxImage::~CCheckBoxImage();
}
/*RECT CRadioButtonImage::DrawButtonText(const HDC buttonDC, POINT &textPos, const RECT buttonRect)
{
	return CCheckBoxImage::DrawButtonText(buttonDC,textPos,buttonRect);
}*/
bool CRadioButtonImage::Draw(HDC originalButtonDC)
{// begin Draw

	// get button info
	RECT buttonRect = {NULL};
	GetClientRect(ctrlWnd,&buttonRect);

	if(imageTopLeft.x < 0)
		imageTopLeft.x = 0;

	SIZE buttonSize = {buttonRect.right,buttonRect.bottom};

	HDC buttonDC = CreateCompatibleDC(originalButtonDC);
	HBITMAP buttonBitmap = CreateCompatibleBitmap(originalButtonDC,buttonRect.right,buttonRect.bottom);
	HGDIOBJ oldButtonBitmap = SelectObject(buttonDC,buttonBitmap);
	if(buttonDC != NULL)
	{// begin draw image
		POINT tempPoint = imageTopLeft;

		unsigned long int tempStyles = 0;//buttonStyles;
		tempStyles |= DFCS_BUTTONRADIO;	// set so it shows a check instead of a button


		if((m_nStyles & BS_PUSHLIKE) == BS_PUSHLIKE)
			tempStyles |= DFCS_BUTTONPUSH;
		if(IsDown)
			tempStyles |= DFCS_PUSHED;

		// select the default button color brush to draw area with
		HBRUSH brush = CreateSolidBrush(buttonColor);
		HGDIOBJ oldBrush = SelectObject(buttonDC,brush);
		// select the default button color pen to draw area with
		HPEN pen = CreatePen(PS_SOLID,1,buttonColor);
		HGDIOBJ oldPen = SelectObject(buttonDC,pen);
		// draw face
		Rectangle(buttonDC,buttonRect.left,buttonRect.top,buttonRect.right+1,buttonRect.bottom+1);

		if(buttonState == BST_CHECKED)
			tempStyles |= DFCS_CHECKED;

		DrawCheckBox(buttonDC,tempStyles,&tempPoint);
		tempPoint.x += borderSize.cx;

		// draw image
		tempPoint.x += borderSize.cx*2;
		DrawButtonImage(buttonDC,tempPoint);
		tempPoint.x += borderSize.cx*2;
		buttonRect.left = tempPoint.x;
		// draw the text
		RECT buttonTextRect = DrawButtonText(buttonDC,tempPoint,buttonRect);
		// draw focus rect if the button is active
		if(GetFocus() == ctrlWnd)
		{
			RECT temp = buttonTextRect;
			ExpandRectangle(1,&temp);
			DrawFocusRect(buttonDC,&temp);
		}
		
		// copy to originalButtonDC
		BitBlt(originalButtonDC,buttonTopLeft.x,buttonTopLeft.y,buttonSize.cx,buttonSize.cy,buttonDC,buttonTopLeft.x,buttonTopLeft.y,SRCCOPY);

		// clean up
		SelectObject(buttonDC,oldButtonBitmap);
		SelectObject(buttonDC,oldBrush);
		SelectObject(buttonDC,oldPen);
		DeleteObject(pen);
		DeleteObject(brush);
		DeleteObject(buttonBitmap);
		DeleteObject(oldButtonBitmap);
		DeleteDC(buttonDC);

		return true;
	}// end draw image
	return false;
}// end Draw