// ButtonImage.cpp: implementation of the CButtonImage class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ButtonImage.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CButtonImage::CButtonImage()
{
	ThunkInit(m_Thunk,this);
}

CButtonImage::~CButtonImage()
{
	Cleanup();
}
bool CButtonImage::LoadCtrlImage(UINT iconID)
{
	// determine what type of resource the user wants to load
	if((m_nStyles & BS_BITMAP) == BS_BITMAP)
		imageType = IMAGE_BITMAP;
	else if((m_nStyles & BS_ICON) == BS_ICON)
		imageType = IMAGE_ICON;
	else
		return false;

	// Load image from resource
	HGDIOBJ hIcon = LoadImage(appInstance, MAKEINTRESOURCE(iconID),imageType, imageSize.cx, imageSize.cy, LR_DEFAULTCOLOR);
	SetButtonImage(imageType,hIcon);
/*	HGDIOBJ oldObject = buttonImage;
	
	// destroy the image
	if(imageType == IMAGE_BITMAP)
		DeleteObject(oldObject);
	else if(imageType == IMAGE_ICON)
		DestroyIcon((HICON)oldObject);
	else if(imageType == IMAGE_CURSOR)
		DestroyCursor((HCURSOR)oldObject);
	else
		return false;*/
	return true;
}
void CButtonImage::Create(UINT ID,HWND parent,HINSTANCE parentInstance,BYTE imageFlags,SIZE imgSz)
{
	Setup();
	// assign values
	appInstance = parentInstance;
	flags = imageFlags;
	ctrlID = ID;
	parentWnd = parent;
	if((flags & BI_SIZE) == BI_SIZE)
	{// begin user want custon size
		imageSize = imgSz;
	}// end user want custom size
	else
	{// begin use default
		imageSize.cx = 32;
		imageSize.cy = 32;
	}// end use default
	ctrlWnd = GetDlgItem(parent,ID);
	// subclass owner's window message function
	oldWndProc = (WNDPROC)::SetWindowLong(ctrlWnd,GWL_WNDPROC,(LONG)(void *)m_Thunk);

	// set the button colors to the default ones
	buttonColor = GetSysColor(COLOR_BTNFACE);
	fontColor = GetSysColor(COLOR_BTNTEXT);

	// get button styles
	m_nStyles = GetWindowLong(ctrlWnd,GWL_STYLE);

//	SetOffset();
}

LRESULT CButtonImage::WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{ // begin switch
	case BM_SETIMAGE:
		SetButtonImage((unsigned int)wParam,(HANDLE)lParam);
		break;
	case BM_GETIMAGE:
		return (LRESULT)GetButtonImage();
	case BM_SETSTATE:
		return OnSetState(wParam);
	case BM_GETSTATE:
	case BM_GETCHECK:
		return (LRESULT)OnGetState();
	case BM_SETCHECK:
	case BM_SETSTYLE:
		return (bool)OnSetStyle((unsigned long int)wParam,(LPARAM)(bool)lParam);
	case WM_SETFOCUS:
		hasFocus = true;
		SendMessage(hwnd,WM_PAINT,0,0);
		break;
	case WM_KILLFOCUS:
		hasFocus = false;
		SendMessage(hwnd,WM_PAINT,0,0);
		break;
	case WM_LBUTTONDBLCLK:
	case WM_LBUTTONDOWN:
		if((m_nStyles & BS_GROUPBOX) == BS_GROUPBOX)
			return 0;
		SetCapture(hwnd);
		SetFocus(hwnd);
		IsDown = true;
		SendMessage(hwnd,WM_PAINT,0,0);
		return 0;//break;
	case WM_MOUSEMOVE:
		OnMouseMove(lParam);
		break;
	case WM_LBUTTONUP:
		if(IsDown)
		{
			OnClick(hwnd,lParam);
		}
		break;
	case WM_ENABLE:
		SendMessage(hwnd,WM_PAINT,0,0);
		return 0;
	case WM_PAINT:
		return OnPaint();
	case WM_DESTROY:
		OnDestroy();
		break;
//	case WM_SETTEXT:
//		return OnSetText(wParam,lParam);
	} // end switch

	// pass the message to the owner window's WndProc function
	return CallWindowProc(oldWndProc,hwnd,message,wParam,lParam);
}

SIZE CButtonImage::SetImageSize(SIZE newImageSize)
// precondition: newImageSize is a valid new image size
// postcondition: the previous image size is returned
{// begin SetImageSize
	SIZE oldSize = imageSize;
	imageSize = newImageSize;
	return oldSize;
}// end SetImageSize

bool CButtonImage::Draw(HDC originalButtonDC)
{// begin Draw

	// get button info
	RECT buttonRect = {NULL};
	GetClientRect(ctrlWnd,&buttonRect);
	unsigned long int nExStyles = (unsigned long int)GetWindowLong(ctrlWnd,GWL_EXSTYLE);
//	m_nStyles = (unsigned long int)GetWindowLong(ctrlWnd,GWL_STYLE);
	SetOffset();

	SIZE buttonEdge = GetButtonEdgeSize(nExStyles);

	buttonRect.left += buttonEdge.cx;
	buttonRect.top += buttonEdge.cy;
	buttonRect.right += buttonEdge.cx;
	buttonRect.bottom += buttonEdge.cy;
	buttonTopLeft.x = buttonEdge.cx;
	buttonTopLeft.y = buttonEdge.cy;

	SIZE buttonSize = {buttonRect.right-buttonRect.left,buttonRect.bottom-buttonRect.top};

	if(imageTopLeft.x < buttonEdge.cx)
		imageTopLeft.x = buttonEdge.cx;


	HDC buttonDC = CreateCompatibleDC(originalButtonDC);
	HBITMAP buttonBitmap = CreateCompatibleBitmap(originalButtonDC,buttonRect.right,buttonRect.bottom);
	HGDIOBJ oldButtonBitmap = SelectObject(buttonDC,buttonBitmap);
	if(buttonDC != NULL)
	{// begin draw image
		POINT tempPoint = imageTopLeft;
		if(IsDown)
		{// begin draw in down pos
			tempPoint.x += 1;
			tempPoint.y += 1;
		}// end draw in down pos

		unsigned long int tempStyles = 0;//m_nStyles;

		tempStyles |= DFCS_BUTTONPUSH;
		if(IsDown)
			tempStyles |= DFCS_PUSHED;

		// select the default button color brush to draw area with
		HBRUSH brush = CreateSolidBrush(buttonColor);
		HGDIOBJ oldBrush = SelectObject(buttonDC,brush);
		// select the default button color pen to draw area with
		HPEN pen = CreatePen(PS_SOLID,1,buttonColor);
		HGDIOBJ oldPen = SelectObject(buttonDC,pen);
		// draw face
		RECT tempRectangle = buttonRect;
		tempRectangle.left -= 1;
		tempRectangle.top -= 1;
		FillRect(buttonDC,&tempRectangle,brush);
		// draw frame
		DrawButtonFrame(buttonDC,&buttonRect);
//		ContractRectangle(borderSize,&tempRectangle);
//		Rectangle(buttonDC,buttonTopLeft.x,buttonTopLeft.y,tempRectangle.right,tempRectangle.bottom);

		if(GetFocus() == ctrlWnd)
		{
			ExpandRectangle(1,&buttonRect);
		}
		// draw image
		tempPoint.x += borderSize.cx;//*2;
		DrawButtonImage(buttonDC,tempPoint);
		// draw the text
		DrawButtonText(buttonDC,tempPoint,buttonRect);
		
		// draw focus rect if the button is active
		if(GetFocus() == ctrlWnd)
		{// begin draw focus
			RECT temp = buttonRect;
			ContractRectangle(4,&temp);
			DrawFocusRect(buttonDC,&temp);
		}// end draw focus

		// copy to originalButtonDC
		BitBlt(originalButtonDC,buttonTopLeft.x,buttonTopLeft.y,buttonSize.cx,buttonSize.cy,buttonDC,buttonTopLeft.x,buttonTopLeft.y,SRCCOPY);

		// clean up
		SelectObject(buttonDC,oldButtonBitmap);
		SelectObject(buttonDC,oldBrush);
		SelectObject(buttonDC,oldPen);
		DeleteObject(pen);
		DeleteObject(brush);
		DeleteObject(buttonBitmap);
		DeleteObject(oldButtonBitmap);
		DeleteDC(buttonDC);

		return true;
	}// end draw image
	return false;
}// end Draw

bool CButtonImage::CleanUpImage()
{// begin CleanUpImage
	// determine image type
	if((m_nStyles & BS_BITMAP) == BS_BITMAP)
		imageType = IMAGE_BITMAP;
	else if((m_nStyles & BS_ICON) == BS_ICON)
		imageType = IMAGE_ICON;
	else
		return false;
	// destroy the image
	if((m_nStyles & BS_BITMAP) == BS_BITMAP)
		DeleteObject(buttonImage);
	else if((m_nStyles & BS_ICON) == BS_ICON)
		DestroyIcon((HICON)buttonImage);
	else
		return false;
	return true;
}// end CleanUpImage

void CButtonImage::SetOffset()
{// begin SetOffset
	// calculate image position
	if((m_nStyles & BS_GROUPBOX) != BS_GROUPBOX && m_nStyles & BS_VCENTER)
	{
		RECT rButton = {NULL};
		GetWindowRect(ctrlWnd,&rButton);
		imageTopLeft.y = ((rButton.bottom-rButton.top)/2)-(imageSize.cy/2);
	}
	else
		imageTopLeft.y = 0;
	if((flags & BI_CENTERIMAGE) == BI_CENTERIMAGE)
	{// begin center image
		char string[1024] = {NULL};
		SIZE fontSize = {NULL};
		// get info for GetTextExtentPoint32
		GetWindowText(ctrlWnd,string,1023);
		HDC buttonDC = GetWindowDC(ctrlWnd);
		int stringLength = lstrlen(string);

		// get the font dimentions
		GetTextExtentPoint32(buttonDC,string,stringLength,&fontSize);
		// get the control dimentions
		RECT buttonRect = {NULL};
		GetClientRect(ctrlWnd,&buttonRect);
		imageTopLeft.x = ((buttonRect.right-buttonRect.left)/2)-(fontSize.cx+imageSize.cx+borderSize.cx)/2;
		if(imageTopLeft.x < borderSize.cx)
		{
			imageTopLeft.x = borderSize.cx;
		}

		// clean up
		ReleaseDC(ctrlWnd,buttonDC);
	}// end center image
	else
	{// left justify image
		imageTopLeft.x = 0;
	}// left justify image
}// end SetOffset

void CButtonImage::ContractRectangle(unsigned int num, RECT *rect)
{
	rect->top += num;
	rect->left += num;
	rect->right -= num;
	rect->bottom -= num;
}

void CButtonImage::ContractRectangle(SIZE size,RECT *rect)
{
	rect->top += size.cy;
	rect->left += size.cx;
	rect->right -= size.cx;
	rect->bottom -= size.cy;
}

void CButtonImage::ExpandRectangle(unsigned int num, RECT *rect)
{
	rect->top -= num;
	rect->left -= num;
	rect->right += num;
	rect->bottom += num;
}

void CButtonImage::ExpandRectangle(SIZE size,RECT *rect)
{
	rect->top -= size.cy;
	rect->left -= size.cx;
	rect->right += size.cx;
	rect->bottom += size.cy;
}

RECT CButtonImage::DrawButtonText(const	HDC buttonDC, POINT &textPos, const RECT buttonRect)
{
	char buttonText[MAX_PATH] = {NULL};
	GetWindowText(ctrlWnd,buttonText,MAX_PATH-1);
	RECT buttonTextRect = buttonRect;
	if(IsDown)
	{// begin set pushed offset
		buttonTextRect.top += 1;
		buttonTextRect.bottom += 1;
		buttonTextRect.left += 1;
		buttonTextRect.right += 1;
	}// end set pushed offset

	ContractRectangle(borderSize,&buttonTextRect);

	buttonTextRect.left = textPos.x+imageSize.cx+borderSize.cx;
	buttonTextRect.top -= borderSize.cy;

	DrawControlText(buttonDC,buttonText,buttonTextRect);

	return buttonTextRect;
}

void CButtonImage::DrawButtonImage(const HDC buttonDC,const POINT imagePos)
{
	// draw image
	if(!IsWindowEnabled(ctrlWnd))
	{
		// the button is disabled monochrome the image
		HICON icon = (HICON)::CopyImage( buttonImage, IMAGE_ICON, imageSize.cx, imageSize.cy, LR_MONOCHROME );
		DrawImage(buttonDC,&imagePos,icon);
//		DrawIconEx(buttonDC,imagePos.x,imagePos.y,(HICON)icon,imageSize.cx,imageSize.cy,NULL,NULL,DI_NORMAL);
		DestroyIcon(icon);
	}
	else
		DrawImage(buttonDC,&imagePos);
		//DrawIconEx(buttonDC,imagePos.x,imagePos.y,(HICON)buttonImage,imageSize.cx,imageSize.cy,NULL,NULL,DI_NORMAL);
}

void CButtonImage::DrawButtonFrame(const HDC buttonDC,RECT *buttonRect)
{
	// adjust for focused button
	if(GetFocus() == ctrlWnd)
	{
		// draw border
		HBRUSH borderBrush = CreateSolidBrush(fontColor);
		FrameRect(buttonDC,buttonRect,borderBrush);
		DeleteObject(borderBrush);

		// shrink 3D rect to not cover border
		ContractRectangle(1,buttonRect);
	}

//	DrawFrameControl(buttonDC,buttonRect,DFC_BUTTON,drawStyles );

	RECT tempRect = *buttonRect;
	tempRect.right -= 1;
	tempRect.bottom -= 1;
	COLORREF topLeftColor = NULL;
	COLORREF bottomRightColor = NULL;
	if(IsDown)
	{
		topLeftColor = GetShadowColor(buttonColor);
		bottomRightColor = GetHiliteColor(buttonColor);
	}
	else
	{
		topLeftColor = GetHiliteColor(buttonColor);
		bottomRightColor = GetShadowColor(buttonColor);
	}

	Draw3dRect(buttonDC,&tempRect,topLeftColor,RGB(0,0,0));
	ContractRectangle(1,&tempRect);
	Draw3dRect(buttonDC,&tempRect,buttonColor,bottomRightColor);

}

void CButtonImage::OnMouseMove(LPARAM lParam)
{
	if(IsDown)
	{
		POINT cursorPos = {LOWORD(lParam),HIWORD(lParam)};
		ClientToScreen(ctrlWnd,&cursorPos);
		RECT buttonRect = {NULL};
		GetWindowRect(ctrlWnd,&buttonRect);
		if(!PtInRect(&buttonRect,lastPoint) && PtInRect(&buttonRect,cursorPos))
		{// begin mouse now over button
			// draw the button
				IsDown = true;
				SendMessage(ctrlWnd,WM_PAINT,0,0);
		}// end mouse now over button
		else if(PtInRect(&buttonRect,lastPoint) && !PtInRect(&buttonRect,cursorPos))
		{// begin mouse now out of button
			// draw the button
				IsDown = false;
				SendMessage(ctrlWnd,WM_PAINT,0,0);
		}// end mouse now out of button
		IsDown = true;
		lastPoint = cursorPos;
	}

}

void CButtonImage::SetButtonImage(unsigned int type, HANDLE image)
{
	if(buttonImage != NULL)
		CleanUpImage();
	buttonImage = image;  // handle to the image 
	imageType = type;
}



void CButtonImage::OnClick(HWND hWnd, LPARAM lParam)
{
	if(GetCapture() == hWnd)
		ReleaseCapture();
	IsDown = false;
	POINT pt = {LOWORD(lParam),HIWORD(lParam)};
	RECT buttonRect = {NULL};
	GetClientRect(hWnd,&buttonRect);
	if(PtInRect(&buttonRect,pt))
	{
		ToggleButtonState();
		// notify parent of button click
		WORD loword = (WORD)ctrlID;
		WORD hiword = 0;
		SendMessage(parentWnd,WM_COMMAND,MAKEWPARAM(loword,hiword),(LPARAM)hWnd);
	}
	// paint in new state
	SendMessage(hWnd,WM_PAINT,0,0);
}

HANDLE CButtonImage::GetButtonImage()
{
	return (HANDLE)buttonImage;
}

unsigned int CButtonImage::OnGetState()
{
	unsigned int states = 0;
	states = states|buttonState;
	if(GetFocus() == ctrlWnd)
		states = states|BST_FOCUS;
	if(IsDown)
		states = states|BST_PUSHED;
	return states;
}

int CButtonImage::OnSetStyle(unsigned long int styles, bool redraw)
{
	SetWindowLong(ctrlWnd,GWL_STYLE,(LONG)styles);
	m_nStyles = styles;
	SetOffset();
	if(redraw)
		SendMessage(ctrlWnd,WM_PAINT,0,0);
	return 0;
}

COLORREF CButtonImage::SetColor(COLORREF color)
{
	COLORREF oldButtonColor = buttonColor;
	buttonColor = color;
	return oldButtonColor;
}

COLORREF CButtonImage::SetFontColor(COLORREF color)
{
	COLORREF oldFontColor = fontColor;
	fontColor = color;
	return oldFontColor;
}




int CButtonImage::LevelColorTop(int color)
{
	if(color > 255)
		color = 255;
	return color;
}

int CButtonImage::LevelColorBottom(int color)
{
	if(color < 0)
		color = 0;
	return color;
}

LRESULT CButtonImage::OnPaint()
{
	// initilize paintStruct
	PAINTSTRUCT paintStruct = {NULL};
	BeginPaint(ctrlWnd,&paintStruct);
	HDC drawDC = GetWindowDC(ctrlWnd);
	if(drawDC)
	{
		Draw(drawDC);
		ReleaseDC(ctrlWnd,drawDC);
	}
	EndPaint(ctrlWnd,&paintStruct);
	return 0;
}

void CButtonImage::SetTextStyles(unsigned int styles)
{
	m_nTextStyles = styles;
	SetOffset();
}

void CButtonImage::DrawControlText(HDC buttonDC,char *buttonText,RECT &buttonTextRect)
{// begin DrawControlText
	// set and save text background color
	COLORREF oldBkColor = SetBkColor(buttonDC,buttonColor);
	COLORREF oldFontColor = SetTextColor(buttonDC,fontColor);
	HFONT font = (HFONT)SendMessage(ctrlWnd,WM_GETFONT,0,0);
	HFONT oldFont = (HFONT)SelectObject(buttonDC,font);
	if(!IsWindowEnabled(ctrlWnd))
	{// begin draw disabled text
		//COLORREF hiliteColor = RGB(LevelColorTop(GetRValue(fontColor)+216),LevelColorTop(GetGValue(fontColor)+216),LevelColorTop(GetBValue(fontColor)+216));
		SetTextColor(buttonDC,GetHiliteColor(buttonColor));
		RECT tempRect = buttonTextRect;
		tempRect.bottom += 1;
		tempRect.left += 1;
		tempRect.right += 1;
		tempRect.top += 1;
		DrawTextEx(buttonDC,buttonText,-1,&tempRect,m_nTextStyles,NULL);
		SetTextColor(buttonDC,GetShadowColor(buttonColor));
//		SetTextColor(buttonDC,RGB(LevelColorTop(GetRValue(fontColor)+128),LevelColorTop(GetGValue(fontColor)+128),LevelColorTop(GetBValue(fontColor)+128)));
	}// end draw disabled text
	SetBkMode(buttonDC,TRANSPARENT); 
	DrawTextEx(buttonDC,buttonText,-1,&buttonTextRect,m_nTextStyles,NULL);
	SetBkMode(buttonDC,OPAQUE); 
	SelectObject(buttonDC,oldFont);
	// set the old text background color back in case it is needed else where
	SetTextColor(buttonDC,oldFontColor);
	SetBkColor(buttonDC,oldBkColor);
}// end DrawControlText
 /*
void CButtonImage::DrawControlText(HDC buttonDC,char *buttonText,RECT &buttonTextRect)
{// begin DrawControlText
	// set and save text background color
	COLORREF oldBkColor = SetBkColor(buttonDC,buttonColor);
	COLORREF oldFontColor = SetTextColor(buttonDC,fontColor);
	HFONT font = (HFONT)SendMessage(ctrlWnd,WM_GETFONT,0,0);
	HFONT oldFont = (HFONT)SelectObject(buttonDC,font);
	if(!IsWindowEnabled(ctrlWnd))
	{// begin draw disabled text
		COLORREF hiliteColor = RGB(LevelColorTop(GetRValue(fontColor)+216),LevelColorTop(GetGValue(fontColor)+216),LevelColorTop(GetBValue(fontColor)+216));
		SetTextColor(buttonDC,hiliteColor);
		RECT tempRect = buttonTextRect;
		tempRect.bottom += 1;
		tempRect.left += 1;
		tempRect.right += 1;
		tempRect.top += 1;
		DrawTextEx(buttonDC,buttonText,-1,&tempRect,m_nTextStyles,NULL);
		SetTextColor(buttonDC,RGB(LevelColorTop(GetRValue(fontColor)+128),LevelColorTop(GetGValue(fontColor)+128),LevelColorTop(GetBValue(fontColor)+128)));
	}// end draw disabled text
	SetBkMode(buttonDC,TRANSPARENT); 
	DrawTextEx(buttonDC,buttonText,-1,&buttonTextRect,m_nTextStyles,NULL);
	SetBkMode(buttonDC,OPAQUE); 
	SelectObject(buttonDC,oldFont);
	// set the old text background color back in case it is needed else where
	SetTextColor(buttonDC,oldFontColor);
	SetBkColor(buttonDC,oldBkColor);
}// end DrawControlText
*/

void CButtonImage::ToggleButtonState()
{
	switch(buttonState)
	{
	case BST_UNCHECKED:
		OnSetState(BST_CHECKED);
		break;
	case BST_CHECKED:
		OnSetState(BST_UNCHECKED);
		break;
	default:
		OnSetState(BST_UNCHECKED);
	}
}

SIZE CButtonImage::GetButtonEdgeSize(unsigned long int extendedStyles)
{
		SIZE buttonEdge = {0,0};
		if((extendedStyles & WS_EX_STATICEDGE) == WS_EX_STATICEDGE)
		{
			buttonEdge.cx += GetSystemMetrics(SM_CXBORDER);
			buttonEdge.cy += GetSystemMetrics(SM_CYBORDER);
		}
		else
		{
			if((extendedStyles & WS_EX_CLIENTEDGE) == WS_EX_CLIENTEDGE)
			{
				buttonEdge.cx += GetSystemMetrics(SM_CXEDGE);
				buttonEdge.cy += GetSystemMetrics(SM_CYEDGE);
			}
			if((extendedStyles & WS_EX_DLGMODALFRAME) == WS_EX_DLGMODALFRAME)
			{
				buttonEdge.cx += GetSystemMetrics(SM_CXDLGFRAME);
				buttonEdge.cy += GetSystemMetrics(SM_CYDLGFRAME);
			}
		}
		return buttonEdge;
}

int CButtonImage::OnSetState(WPARAM state)
{
	buttonState = state;
	return 0;
}



COLORREF CButtonImage::GetHiliteColor(COLORREF color)
{
	double alpha = 0;
	return RGB((1-alpha)*LevelColorTop(GetRValue(color)+128) + (alpha*GetRValue(color)),
		(1-alpha)*LevelColorTop(GetGValue(color)+128) + (alpha*GetGValue(color)),
		(1-alpha)*LevelColorTop(GetBValue(color)+128) + (alpha*GetBValue(color)));
/*	return RGB((1-alpha)*LevelColorTop(GetRValue(color)+196) + (alpha*GetRValue(color)),
		(1-alpha)*LevelColorTop(GetGValue(color)+196) + (alpha*GetGValue(color)),
		(1-alpha)*LevelColorTop(GetBValue(color)+196) + (alpha*GetBValue(color)));*/
}

COLORREF CButtonImage::GetShadowColor(COLORREF color)
{
	// avoid using floating point numbers so that _ftol() is not needed
	int whole = 1000000000; // 1,000,000,000
	int alpha = 333333333;	// 333,333,333
	return RGB((whole-alpha)*LevelColorBottom(GetRValue(color)-128) + (alpha*GetRValue(color)/100),
		(whole-alpha)*LevelColorBottom(GetGValue(color)-128) + (alpha*GetGValue(color)/100),
		(whole-alpha)*LevelColorBottom(GetBValue(color)-128) + (alpha*GetBValue(color)/100));

}

void CButtonImage::Draw3dRect(HDC destDC,RECT *rect, COLORREF topLeftColor, COLORREF bottomRightColor)
{
	POINT leftTopArray[3] = {NULL};
	leftTopArray[0].x = rect->left;
	leftTopArray[0].y = rect->bottom;
	leftTopArray[1].x = rect->left;
	leftTopArray[1].y = rect->top;
	leftTopArray[2].x = rect->right;
	leftTopArray[2].y = rect->top;

	HPEN topLeftPen = CreatePen(PS_SOLID,1,topLeftColor);
	HGDIOBJ oldTopLeftPen = SelectObject(destDC,topLeftPen);
	Polyline(destDC,leftTopArray,3); 
	SelectObject(destDC,oldTopLeftPen);
	DeleteObject(topLeftPen);

	POINT bottomRightArray[3] = {NULL};
	bottomRightArray[0].x = rect->right;
	bottomRightArray[0].y = rect->top;
	bottomRightArray[1].x = rect->right;
	bottomRightArray[1].y = rect->bottom;
	bottomRightArray[2].x = rect->left-1;
	bottomRightArray[2].y = rect->bottom;

	HPEN bottomRightPen = CreatePen(PS_SOLID,1,bottomRightColor);
	HGDIOBJ oldBottomRightPen = SelectObject(destDC,bottomRightPen);
	Polyline(destDC,bottomRightArray,3); 
	SelectObject(destDC,oldBottomRightPen);
	DeleteObject(bottomRightPen);
}

void CButtonImage::DrawImage(const HDC hDC,const POINT *pLeftTop,HANDLE hImage)
{// begin DrawImage
	if(hImage == NULL)
		hImage = buttonImage;
	switch(imageType)
	{// begin imageType switch
	case IMAGE_ICON:
		DrawIconEx(hDC,pLeftTop->x,pLeftTop->y,(HICON)hImage,imageSize.cx,imageSize.cy,NULL,NULL,DI_NORMAL);
		break;
	case IMAGE_BITMAP:
		DrawTransparentBitmap(hDC,(HBITMAP)hImage,pLeftTop->x,pLeftTop->y,cTransparentColor);
		break;
	}// end imageType switch
}// end DrawImage

void CButtonImage::DrawTransparentBitmap(HDC hDC, HBITMAP hBitmap, int x, int y, COLORREF crColour)
// written by Paul Reynolds: Paul.Reynolds@cmgroup.co.uk
// CodeGuru article: "Transparent Bitmap - True Mask Method"
// http://codeguru.earthweb.com/bitmap/CISBitmap.shtml
{
	COLORREF crOldBack = SetBkColor(hDC,RGB(255,255,255));
	COLORREF crOldText = SetTextColor(hDC,RGB(0,0,0));
	HDC dcImage, dcTrans;

	// Create two memory dcs for the image and the mask
	dcImage = CreateCompatibleDC(hDC);
	dcTrans = CreateCompatibleDC(hDC);

	// Select the image into the appropriate dc
	HGDIOBJ hOldBitmapImage = SelectObject(dcImage,hBitmap);

	// Create the mask bitmap
	HBITMAP bitmapTrans = NULL;
	// get the image dimensions
	BITMAP bm = {NULL};
    GetObject(hBitmap, sizeof(BITMAP), (LPSTR)&bm);
	int nWidth = bm.bmWidth;
	int nHeight = bm.bmHeight;
	bitmapTrans = CreateBitmap(nWidth, nHeight, 1, 1, NULL);

	// Select the mask bitmap into the appropriate dc
	HGDIOBJ hOldBitmapTrans = SelectObject(dcTrans,bitmapTrans);

	// Build mask based on transparent colour
	SetBkColor(dcImage,crColour);
	BitBlt(dcTrans, 0, 0, nWidth, nHeight, dcImage, 0, 0, SRCCOPY);

	// Do the work - True Mask method - cool if not actual display
	BitBlt(hDC,x, y, nWidth, nHeight, dcImage, 0, 0, SRCINVERT);
	BitBlt(hDC,x, y, nWidth, nHeight, dcTrans, 0, 0, SRCAND);
	BitBlt(hDC,x, y, nWidth, nHeight, dcImage, 0, 0, SRCINVERT);

	// Restore settings
	// don't delete this, since it is the bitmap
	SelectObject(dcImage,hOldBitmapImage);
	// delete bitmapTrans
	DeleteObject(SelectObject(dcTrans,hOldBitmapTrans));
	SetBkColor(hDC,crOldBack);
	SetTextColor(hDC,crOldText);
	// clean up
	DeleteDC(dcImage);
	DeleteDC(dcTrans);
}

void CButtonImage::SetTransparentColor(COLORREF cColor)
{// begin SetTransparentColor
	cTransparentColor = cColor;
}// end SetTransparentColor

void CButtonImage::Cleanup()
{// begin Cleanup
	CleanUpImage();
}// end Cleanup

void CButtonImage::Setup()
{// begin Setup
	// initilize variables
	appInstance = NULL;
	ctrlWnd = NULL;
	oldWndProc = NULL;
	flags = NULL;
	imageSize.cx = 0;
	imageSize.cy = 0;
	imageTopLeft.x = 0;
	imageTopLeft.y = 0;
	IsDown = false;
	borderSize.cx = GetSystemMetrics(SM_CXEDGE);
	borderSize.cy = GetSystemMetrics(SM_CYEDGE);
	m_nTextStyles = DT_LEFT|DT_WORDBREAK|DT_NOCLIP;
	m_nStyles = 0;
	lastPoint.x = 0;
	buttonState = BST_CHECKED;
	lastPoint.y = 0;
	buttonImage = NULL;
	hasFocus = false;
	firstDraw = true;
	ctrlID = 0;
	parentWnd = NULL;
	buttonTopLeft.x = 0;
	buttonTopLeft.y = 0;
	cTransparentColor = RGB(255,0,255);
}// end Setup

bool CButtonImage::OnDestroy()
{// begin OnDestroy
	// remove subclass of owner's window message function
	::SetWindowLong(ctrlWnd,GWL_WNDPROC,(DWORD)oldWndProc);
	Cleanup();
	return true;
}// end OnDestroy

HWND CButtonImage::GetSafeHwnd(void)
{// begin GetSafeHwnd
	return ctrlWnd;
}// end GetSafeHwnd
/*
LRESULT CButtonImage::OnSetText(WPARAM wParam,LPARAM lParam)
{// begin OnSetText
	LRESULT lResult = CallWindowProc(oldWndProc,ctrlWnd,WM_SETTEXT,wParam,lParam);
	SetOffset();
	return lResult;
}// end OnSetText
*/