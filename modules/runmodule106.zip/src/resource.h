//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RunModule.rc
//
#define IDC_MYICON                      2
#define IDD_RUNMODULE_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_RUNMODULE                   107
#define IDI_SMALL                       108
#define IDC_RUNMODULE                   109
#define IDI_ICON_OK                     109
#define IDI_ICON_CANCEL                 110
#define IDI_ICON_BROWSE                 111
#define IDI_ICON_ABOUT                  112
#define IDR_MAINFRAME                   128
#define IDD_RUNDLG                      129
#define IDD_DIALOG_ABOUT                130
#define IDB_BITMAP_ABOUT                132
#define IDB_BITMAP_BROWSE               133
#define IDB_BITMAP_CANCEL               134
#define IDB_BITMAP_OK                   135
#define IDC_BROWSE                      1000
#define IDC_COMBO_RUN                   1002
#define IDC_COMBO_OPTION                1003
#define IDC_CHECK_CLOSE                 1004
#define IDC_ABOUT                       1005
#define IDC_BUTTON_WEBSITE              1006
#define IDC_BUTTON_EMAIL                1007
#define IDC_BUTTON_REGISTER             1008
#define IDC_RADIO                       1010
#define IDC_STATIC_MESSAGE              1015
#define IDC_BUTTON_HELP                 1016
#define IDC_STATIC_OBJECT               1018
#define IDC_STATIC_COMMAND              1019
#define IDM_TASKMANAGER					1020
#define IDM_CONTROLPANEL				1021
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
