// CommandLine.cpp: implementation of the CCommandLine class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CommandLine.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCommandLine::CCommandLine()
{
	m_nCurrentIndex = 0;
}

CCommandLine::~CCommandLine()
{

}

void CCommandLine::SetCommandLine(const char *pCmdLine)
{// begin SetCommandLine
	// set command line string
	m_pCmdLine = pCmdLine;
	// set default params
	CCommandLine();

}// end SetCommandLine

char CCommandLine::GetNextSwitch()
{// begin GetNextSwitch
	for(int i = m_nCurrentIndex;m_pCmdLine[i] != '\0';i++)
	{// begin move to the first switch
		for(;m_pCmdLine[i] != '/';i++)
			if(m_pCmdLine[i] == '\0')	// invalid command line
				return NULL;
		if(m_pCmdLine[i] == '/')
		{// begin parse command line
			// move to the switch option
			i++;
			// create temporay character
			char option = m_pCmdLine[i];
			// make lowercase
			CharLower(&option);
			// advance index
			i++;
			m_nCurrentIndex = i;
			return option;
		}// end parse command line
	}// end move to the first switch
	return NULL;
}// end GetNextSwitch

const char * CCommandLine::GetNextString(char *pBuffer)
{// begin GetNextString
	bool bIsQuoted = false;
	char *pSourceString = (char *)(void *)&m_pCmdLine[m_nCurrentIndex];
	// advance to the beginning of the string
	for(;*pSourceString != '\0' && *pSourceString == ' ';pSourceString++);
	// advance to the next character
//	pSourceString++;
	// get the length of the string
	if(pSourceString[0] == '"')
	{
		// flag quoted string
		bIsQuoted = true;
		// advance to the next character
		pSourceString++;
	}
	for(int i = 0;pSourceString[i] != '\0' && !(bIsQuoted && pSourceString[i] == '"') && !(!bIsQuoted && pSourceString[i] == ' ');i++);
	// advance to next character
	i++;
	// copy the string into the buffer
	lstrcpyn(pBuffer,pSourceString,i);
	// adjust the current string index
	m_nCurrentIndex += i;
	return pBuffer;
}// end GetNextString
