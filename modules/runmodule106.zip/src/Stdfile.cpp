// StdFile.cpp: implementation of the CStdFile class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "StdFile.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStdFile::CStdFile()
{// begin CStdFile constructor
	// initilize variables
	fileHandle = NULL;
	currentFilePos = 0;
}// end CStdFile constructor

CStdFile::~CStdFile()
{// begin CStdFile destructor
	if(fileHandle != NULL)
		Close();
}// end CStdFile destructor

bool CStdFile::Open(const char *fileName, DWORD accessFlags, DWORD shareAccess, DWORD creationAttributes)
{// begin Open
// CreateFile("wndMainPos.dat",GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	fileHandle = CreateFile(fileName,accessFlags,shareAccess,NULL,creationAttributes,FILE_ATTRIBUTE_NORMAL,NULL);
	if(fileHandle == INVALID_HANDLE_VALUE)
		return false;
	char tempFileName[MAX_PATH] = {NULL};
	GetName(fileName,tempFileName);
	char filePath[MAX_PATH] = {NULL};
	GetCurrentDirectory(MAX_PATH-1,filePath);
	lstrcat(filePath,"\\");
	lstrcat(filePath,tempFileName);
	lstrcpy(path,filePath);
	return true;
}// end Open

DWORD CStdFile::WriteLine(const char *buffer)
{// begin WriteLine
	DWORD bytesWritten = Write(buffer,lstrlen(buffer));
	if(bytesWritten)
	{// begin write endline
		DWORD temp = Write("\r\n",2);
		if(!temp)
		{
			return bytesWritten;
		}
		return bytesWritten+temp;
	}// end write endline
//	currentFilePos += bytesWritten;
	return bytesWritten;
}// end WriteLine

DWORD CStdFile::ReadLine(char *bufferOut)
{// begin ReadLine
//	DWORD bytesRead = 0;
	for(int i = 0;Read(&bufferOut[i], 1);i++)
	{// begin read file
		if(bufferOut[i] == '\r')// || bufferOut[i] == '\n')
		{// begin end of line found
			bufferOut[i] = NULL;
			Seek(currentFilePos+1,FILE_BEGIN);
			return i;
		}// end end of line found		
	}// end read file
	return i;
}// end ReadLine

bool CStdFile::Close()
{// begin Close
	if(CloseHandle(fileHandle))
	{// begin file was closed
		fileHandle = NULL;
		return true;
	}// end file was closed
	return false;
}// end Close

bool CStdFile::Delete(const char *fileName)
{// begin Delete
	if(!DeleteFile(fileName))
	{// begin could be a folder
		if(!RemoveDirectory(fileName))
			return false;
	}// end could be a folder
	return true;
}// end Delete

void CStdFile::GetName(const char *fileString, char *fileBufferOut)
{// begin GetName
	for(int i = lstrlen(fileString)-1;fileString[i] != '\\' && i > -1;i--);
	lstrcpyn(fileBufferOut,&fileString[i+1],(lstrlen(fileString))-i);
}// end GetName
/*
bool CStdFile::Rename(const char *source, const char *dest)
{// begin Rename
	SHFILEOPSTRUCT file = {NULL,FO_RENAME ,source,dest,FOF_NOERRORUI ,FALSE,NULL,NULL};
	if(::SHFileOperation(&file) == 0)
	{// begin rename successful
		return true;
	}// end rename successful
	return false;
}// end Rename
*/
const char * CStdFile::GetFileName()
{// begin GetFileName
	return name;
}// end GetFileName

const char * CStdFile::GetFilePath()
{// begin GetFilePath
	return path;
}// end GetFilePath

DWORD CStdFile::Read(char *buffer, DWORD bytesToRead)
{// begin Read
	DWORD bytesRead = 0;
	ReadFile(fileHandle,buffer,bytesToRead,&bytesRead,NULL);
	currentFilePos += bytesRead;
	return bytesRead;
}// end Read

DWORD CStdFile::Write(const char *buffer, DWORD bytesToWrite)
{// begin Write
	DWORD bytesWritten = 0;
	WriteFile(fileHandle,buffer,bytesToWrite,&bytesWritten,NULL);
	currentFilePos += bytesWritten;
	return bytesWritten;
}// end Write

DWORD CStdFile::GetLength()
{// begin GetLength
	return GetFileSize(fileHandle,NULL);
}// end GetLength

DWORD CStdFile::Seek(DWORD pos,DWORD start)
{// begin Seek
	currentFilePos = SetFilePointer(fileHandle,pos,NULL,start);
	return currentFilePos;
}// end Seek

bool CStdFile::Rename(const char *source, const char *dest)
{// begin Rename
	return (bool)MoveFile(source,dest);
}// end Rename

unsigned long int CStdFile::GetPos()
{// begin GetPos
	return currentFilePos;
}// end GetPos
