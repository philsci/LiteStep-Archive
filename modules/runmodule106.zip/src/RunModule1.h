// RunModule1.h: interface for the CRunModule class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RUNMODULE1_H__68BD483C_25CE_4E0F_8C7C_743F3DA794D2__INCLUDED_)
#define AFX_RUNMODULE1_H__68BD483C_25CE_4E0F_8C7C_743F3DA794D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ButtonImage.h"
#include "CheckBoxImage.h"
#include "RadioButtonImage.h"
#include "GroupBoxImage.h"
#include "CommandLine.h"
#include "MyDialog.h"
#include "StdFile.h"
#include "RunModuleListFile.h"
#include "About.h"
#include "ExecuteProcess.h"
#include "RunModuleData.h"
#include "ComboCommand.h"

class CRunModule : public CMyDialog  
{
public:
	bool Init(HINSTANCE hInstance,HWND hParent,unsigned long nTemplateID,bool bDoModal = true);
	int GetErrorCode(){return m_nErrorCode;}
	void OnButtonOk();	// needs to be public for threading
	static int RunProgram(char *pObject,char *pCommand);
	CRunModule();
	CRunModule(const char *pCommandLine);
	virtual ~CRunModule();
protected:
//	bool GetItem(int nItem, char *pObject, char *pCommand);
//	int FindItem(const char *pObject,const char *pCommand, int &nLastItem);
//	static const char * GetDefaultApp(const char *pExtension, char *pBuffer);
//	static const char * GetExtension(const char *pFile, char *pBuffer);
	void LoadWindowPlacement(HWND hWnd,const char *pName);
	void OnAbout();
	virtual bool OnSysCommand(WPARAM wParam,LPARAM lParam);
	const char *GetErrorMessage(char *pBuffer);
	int BatchRun(int nDelayExec, bool bIgnoreErr);
	bool OnCommand(WPARAM wParam, LPARAM lParam);
	LRESULT DlgProc(HWND hDlg,UINT nMessage,WPARAM wParam,LPARAM lParam);
	bool LoadRunComboBox();
	bool HasChar(char *pString,char cChar);
//	bool AddItem();
	void DisplayMessage(const char *pMessage);
//	void DisplayMessage(int nErrorCode);
	bool LoadItemCommand();
	void OnButtonBrowse();
	unsigned long int GetNextThreadID();
	virtual bool OnDestroy();
	bool OnInitDialog(HWND hDlg);
	void OnMoving(WPARAM &wParam,LPARAM &lParam);
	LRESULT OnLButtonDown(WPARAM wParam,LPARAM lParam);
	LRESULT OnContextMenu(WPARAM wParam,LPARAM lParam);

	CButtonImage m_biOkButton;
	CButtonImage m_biCancelButton;
	CButtonImage m_biBrowseButton;
	CButtonImage m_biAboutButton;
	CCheckBoxImage m_cbiCloseCheck;
	unsigned long int m_nThreadID;
	int m_nErrorCode;
	char m_pListFile[MAX_PATH];
	int m_nSnapPixels;
	RECT m_rDesktopRect;
	bool m_bNoCaption;
	bool m_bHideDescriptions;
	CComboCommand m_ccObject;
	CComboAutoComplete m_cacCommand;
};

#endif // !defined(AFX_RUNMODULE1_H__68BD483C_25CE_4E0F_8C7C_743F3DA794D2__INCLUDED_)
