// ComboCommand.cpp: implementation of the CComboCommand class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ComboCommand.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComboCommand::CComboCommand()
{

}

CComboCommand::~CComboCommand()
{

}

LRESULT CComboCommand::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_DROPFILES:
		OnDropFiles(wParam,lParam);
		break;
	}// end nMessage swtich
	return CComboAutoComplete::WndProc(hWnd, nMessage, wParam, lParam);
}// end WndProc

void CComboCommand::OnDropFiles(WPARAM wParam,LPARAM lParam)
{// begin OnDropFiles
	HWND hWnd = GetParent(m_hWnd);
	HDROP hDropInfo = (HDROP) wParam;
	// Get the number of bytes required by the file's full pathname
	int nFiles = DragQueryFile(hDropInfo,0xFFFFFFFF,NULL,NULL);
	// get the string in the edit field
	char pBuffer[MAX_PATH] = {NULL};
	GetDlgItemText(hWnd,IDC_COMBO_RUN,pBuffer,MAX_PATH-1);

	for(;nFiles > 0;nFiles--)
	{// begin add the file to the edit field
		UINT wPathnameSize = DragQueryFile(hDropInfo, nFiles-1, NULL, 0);
		// Allocate memory to contain full pathname & zero byte
		char * npszFile = (char *) HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY, wPathnameSize += 1);
		// Copy the pathname into the buffer
		DragQueryFile(hDropInfo, nFiles-1, npszFile, wPathnameSize);
		lstrcat(pBuffer,npszFile);
		// clean up
		HeapFree(GetProcessHeap(),NULL,npszFile);
	}// end add the file to the edit field

	// set the text back to the edit field
	SetDlgItemText(hWnd,IDC_COMBO_RUN,pBuffer);
}// end OnDropFiles
