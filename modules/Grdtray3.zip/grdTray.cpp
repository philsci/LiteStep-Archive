#include "grdTray.h"
#include <commctrl.h>
#include <shellapi.h>
#include <stdio.h>

// defined directions
#define TD_VERTICAL    0x1
#define TD_TOTOPLEFT   0x2

#define TD_RIGHT       0x0
#define TD_LEFT        (TD_TOTOPLEFT)
#define TD_UP          (TD_TOTOPLEFT|TD_VERTICAL)
#define TD_DOWN        (TD_VERTICAL)

// defined effects
#define FX_ICONHUE     0x1
#define FX_SATURNATION 0x2

#define FX_ANY         (FX_ICONHUE|FX_SATURNATION)

#define MAX_LINE_LENGTH 4096

#define INVERTSRCAND         0x00220326 // DSna

//#define REGKEY_SAVEDDATA     TEXT("Software\\Litestep\\Systray\\SavedData")

// this one is only necessary b/c I've broken the usual .h files...
#define magicDWord 0x49474541
// name of shelldesktop class
#define WC_SHELLDESKTOP    TEXT("DesktopBackgroundClass")

const char szAppName[] = "grdTray"; // Our window class, etc

const char rcsRevision[] = "$Revision: 3.0 beta 2 $"; // Our Version
const char rcsId[] = "$Id: grdtray.cpp,v 3.0 beta 2 2001/11/26 00:00:00 grd Exp $"; // The Full RCS ID.

grdTray *tray; // The module

//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  Window::init(dllInst);
  tray = new grdTray(parentWnd, code);
  return code;
}
int initWharfModule(HWND parentWnd, HINSTANCE dllInst, void *wharfData)
{
  int code;
  Window::init(dllInst);
  tray = new grdTray(parentWnd, code);
  return code;
}
void quitModule(HINSTANCE dllInst)
{
  delete tray;
}
void quitWharfModule(HINSTANCE dllInst)
{
  delete tray;
}

// BANG COMMAND FUNCTIONS

void bangShow( HWND sender, LPCSTR args )
{
	tray->show();
}
void bangHide( HWND sender, LPCSTR args )
{
  tray->hide();
}
void bangToggle( HWND sender, LPCSTR args )
{
	tray->toggle();
}
void bangOnTop( HWND sender, LPCSTR args )
{
	tray->toggleOnTop();
}
void bangMove( HWND sender, LPCSTR args )
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX,szY};
	LCTokenize( args, tokens, 2, NULL );
	tray->move(atoi(szX),atoi(szY));
}
void bangSize( HWND sender, LPCSTR args )
{
	char szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	char *tokens[2] = {szCX,szCY};
	LCTokenize( args, tokens, 2, NULL );
	tray->size(atoi(szCX),atoi(szCY));
}
void bangAdd( HWND sender, LPCSTR args )
{
	char buffer[MAX_LINE_LENGTH];
	strcpy( buffer, args );
	tray->iconAddBang(buffer);
}
void bangDel( HWND sender, LPCSTR args )
{
	char buffer[MAX_LINE_LENGTH];
	strcpy( buffer, args );
	tray->iconDelBang( atoi(buffer) );
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
grdTray::grdTray(HWND parentWnd, int& code):
Window(szAppName)
{
	// reading settings for window creation
  // ======================================

  // get ls window handle
  liteStep = GetLitestepWnd();
	desktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if (!desktop)
		desktop = GetDesktopWindow();

  // if the parent window is not litestep, it must be the wharf
  inWharf = (parentWnd!=liteStep);

	// get the position and size of the main window
	// using different method if it's docked in the wharf
  if ( inWharf )
  {
		RECT rc;
	  int  wharfBorder;
	  
	  // get the wharf window size
	  GetClientRect( parentWnd, &rc );
	  wharfBorder = GetRCInt( "WharfBevelWidth", 0 );

	  trayX = wharfBorder;
	  trayY = wharfBorder;
	  trayWidth = rc.right - 2 * wharfBorder;
	  trayHeight = rc.bottom - 2 * wharfBorder;
  }
  else
  {
		trayX = GetRCInt( "grdTrayX", 0 );
		if ( trayX < 0 )
			trayX += GetSystemMetrics(SM_CXSCREEN);
	  trayY = GetRCInt( "grdTrayY", 0 );
		if ( trayY < 0 )
			trayY += GetSystemMetrics(SM_CYSCREEN);
	  trayWidth = GetRCInt( "grdTrayWidth", 64 );
	  trayHeight = GetRCInt( "grdTrayHeight", 64 );
  }
	onTop = !inWharf && GetRCBool("grdTrayAlwaysOnTop", TRUE);
  
//  OutputDebugString("just before window creation\n");

  if (!createWindow(WS_EX_TOOLWINDOW,szAppName,(inWharf||!onTop)?WS_CHILD:WS_POPUP,
		trayX,trayY,trayWidth,trayHeight,(inWharf?parentWnd:((!onTop)?desktop:NULL))))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  if (!onTop)
   SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) & ~WS_CHILD)|WS_POPUP);

  code = 0;
}

grdTray::~grdTray()
{
  destroyWindow();
}										

void grdTray::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate,            WM_CREATE)
    MESSAGE(onDestroy,           WM_DESTROY)
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
		//MESSAGE(onRestoreTray,       LM_RESTORESYSTRAY)
		//MESSAGE(onSaveTray,          LM_SAVESYSTRAY)
		MESSAGE(onSysTray,           LM_SYSTRAY)
		MESSAGE(onWindowPosChanged,  WM_WINDOWPOSCHANGED)
		MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
    MESSAGE(onKeyMessage,        WM_KEYDOWN)
    MESSAGE(onKeyMessage,        WM_KEYUP)
    MESSAGE(onKeyMessage,        WM_HOTKEY)
    MESSAGE(onMouse,             WM_LBUTTONDOWN)
    MESSAGE(onMouse,             WM_MBUTTONDOWN)
    MESSAGE(onMouse,             WM_RBUTTONDOWN)
    MESSAGE(onMouse,             WM_LBUTTONUP)
    MESSAGE(onMouse,             WM_MBUTTONUP)
    MESSAGE(onMouse,             WM_RBUTTONUP)
    MESSAGE(onMouse,             WM_LBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_MBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_RBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_MOUSEMOVE)
    MESSAGE(onPaint,             WM_PAINT)
    MESSAGE(onPaint,             LM_REPAINT)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
  END_MESSAGEPROC
}

void grdTray::onEndSession(Message& message)
{
  message.lResult = SendMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void grdTray::onKeyMessage(Message& message)
{
  // Forward these messages
  PostMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void grdTray::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(liteStep, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void grdTray::onCreate(Message& message)
{
  char szTemp[256];
  int tmpInteger = 0;
  int msgs[] = {LM_GETREVID,/*LM_RESTORESYSTRAY,LM_SAVESYSTRAY,*/LM_SYSTRAY,0};

	// register messages
  SendMessage(liteStep, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// has to be done
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  // make sure it handle dblclicks... =)
  SetClassLong(hWnd,GCL_STYLE,CS_DBLCLKS|GetClassLong(hWnd,GCL_STYLE));

	// load settings here
	// ===========================================
	visible         = inWharf || GetRCBool("grdTrayHidden", FALSE);
	hideIfEmpty     = !inWharf && GetRCBool("grdTrayHideIfEmpty", TRUE);
	autoSize        = !inWharf && GetRCBool("grdTrayAutoSize", TRUE);
	tmpInteger      = GetRCInt("grdTrayBorderSize",0);
	borderTop       = max(GetRCInt("grdTrayBorderTop",tmpInteger),0);
	borderLeft      = max(GetRCInt("grdTrayBorderLeft",tmpInteger),0);
	borderRight     = max(GetRCInt("grdTrayBorderRight",tmpInteger),0);
	borderBottom    = max(GetRCInt("grdTrayBorderBottom",tmpInteger),0);
	borderDrag      = !inWharf && GetRCBool("grdTrayBorderDrag",TRUE);
	snapDistance    = max(GetRCInt("grdTraySnapDistance", (GetRCBool("grdTraySnap",TRUE) ? 10 : 0)),0);
	
	// icon effects
	effectFlags = 0;

	hueIntensity    = (UCHAR)min( max( GetRCInt("grdTrayIconHueIntensity",0), 0), 255 );
	clrHue          = GetRCColor("grdTrayIconHueColor",RGB(128,128,128));
	if ( hueIntensity )
		effectFlags |= FX_ICONHUE;

	saturnation     = (UCHAR)min( max( GetRCInt("grdTrayIconSaturnation",255), 0), 255 );
	if ( saturnation != 255 )
		effectFlags |= FX_SATURNATION;

	// colors
	clrBack         = GetRCColor("grdTrayBGColor",RGB(255,0,255));
	clrBorder       = GetRCColor("grdTrayBorderColor",RGB(255,255,255));
	
	// skinning
  GetRCString("grdTrayBitmap",szTemp,"",256);

  if ( szTemp[0] == '\0' )
	{
    hbmSkin = NULL;
		transpSkin = (clrBack==RGB(255,0,255));
		if (!transpSkin)
			transpSkin = (borderTop+borderLeft+borderRight+borderBottom>0) && (clrBorder==RGB(255,0,255));
  }
	else
	{
		BITMAP bm;
		HRGN hBitmapRgn, hOpaqueRgn;

    hbmSkin = LoadLSImage(szTemp, NULL);

		// get info from the bitmap
    GetObject( hbmSkin, sizeof(BITMAP), &bm );

		hBitmapRgn = BitmapToRegion( hbmSkin, RGB(255,0,255), 0x101010, 0, 0);
		hOpaqueRgn = CreateRectRgn( 0, 0, bm.bmWidth, bm.bmHeight );

		// to see if any pixels are transparent
		transpSkin = !EqualRgn( hBitmapRgn, hOpaqueRgn );

		DeleteObject( hBitmapRgn );
		DeleteObject( hOpaqueRgn );
	}
  skinTiled = GetRCBool("grdTrayBitmapTiled",TRUE);

	// initiate vars for the background creation
	hbmBack     = NULL;
	transpBack = FALSE;

	//tray wrapping
  wrapCount = max(GetRCInt("grdTrayWrapCount",0),0);

  // get direction
  GetRCString("grdTrayDirection",szTemp,"",256);
  if ( !::strnicmp(szTemp, "left", 5) )
    direction = TD_LEFT;
  else if ( !::strnicmp(szTemp, "up", 3) )
    direction = TD_UP;
  else if ( !::strnicmp(szTemp, "down", 5) )
    direction = TD_DOWN;
	else
		direction = TD_RIGHT;

  // get wrap-direction
  GetRCString("grdTrayWrapDirection",szTemp,"",256);
  if (direction & TD_VERTICAL) {
      if ( !::strnicmp( szTemp, TEXT("left"), 5 ) )
          wrapDirection = TD_LEFT;
      else 
          wrapDirection = TD_RIGHT;
  } else {
      if ( !::strnicmp( szTemp, TEXT("down"), 5) )
          wrapDirection = TD_DOWN;
      else
          wrapDirection = TD_UP;
  }

	// icon
	iconSize     = max(GetRCInt( TEXT("grdTrayIconSize"), 16 ),0);
  iconSpacingX = max(GetRCInt( TEXT("grdTrayIconSpacingX"), 1 ),0);
	iconSpacingY = max(GetRCInt( TEXT("grdTrayIconSpacingY"), 1 ),0);

  // this section evaluates how the placing of new icons should be calculated
  deltaX = ((( direction & TD_VERTICAL ) ? wrapDirection : direction ) == TD_LEFT) ? -1 : 1;
  deltaY = ((( direction & TD_VERTICAL ) ? direction : wrapDirection ) == TD_DOWN) ? 1 : -1;

	deltaX *= iconSize + iconSpacingX;
	deltaY *= iconSize + iconSpacingY;

	setFirstLast();
	createBackground();

  //OutputDebugString("done reading step.rc\n");

	// NOT FOR WHARF
	if ( !inWharf ) {

		AddBangCommand( "!grdTrayHide", bangHide );
		AddBangCommand( "!grdTrayShow", bangShow );
		AddBangCommand( "!grdTrayToggle", bangToggle );
		AddBangCommand( "!grdTrayOnTop", bangOnTop );
		AddBangCommand( "!grdTrayMove", bangMove );
		AddBangCommand( "!grdTraySize", bangSize );

	}
	AddBangCommand( "!grdTrayAdd", bangAdd );
	AddBangCommand( "!grdTrayDel", bangDel );

	// set always on top
	if (onTop)
		SetWindowPos( hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );

	// show window	
	ShowWindow( hWnd, (!visible||hideIfEmpty)?SW_HIDE:SW_SHOWNOACTIVATE );
	InvalidateRect( hWnd, NULL, TRUE );

	// create a tooltip window
	tooltip = CreateWindowEx(WS_EX_TOOLWINDOW|WS_EX_TOPMOST,TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP|WS_POPUP,0,0,0,0,hWnd,NULL,NULL,NULL);

	uLastID = 1;
	pFirst = NULL;
	pLast = NULL;

  //OutputDebugString("right before loading rc-icons\n");
	iconListLoadRC();

  //OutputDebugString("right after loading rc-icons\n");

	// Win98/IE4 stuff
	//PostMessage( HWND_BROADCAST, RegisterWindowMessage("TaskbarCreated"), 0, 0 );

  //OutputDebugString("done initiating, except shellTray\n");

	//if( !FindWindow(WC_SHELLTRAY, NULL) )
	//	shellTray = new grdShellTray(liteStep);

  //OutputDebugString("done initiating\n");

	PostMessage(liteStep, LM_SYSTRAYREADY, NULL, NULL);

}

void grdTray::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID,/*LM_RESTORESYSTRAY,LM_SAVESYSTRAY,*/LM_SYSTRAY,0};
	
	/*if ( shellTray )
		delete shellTray;
	shellTray = NULL;*/

	// NOT FOR WHARF
	if ( !inWharf )
	{
		RemoveBangCommand("!grdTrayHide");
		RemoveBangCommand("!grdTrayShow");
		RemoveBangCommand("!grdTrayToggle");
		RemoveBangCommand("!grdTrayOnTop");
		RemoveBangCommand("!grdTrayMove");
		RemoveBangCommand("!grdTraySize");
	}
	RemoveBangCommand( "!grdTrayAdd" );
	RemoveBangCommand( "!grdTrayDel" );

	SendMessage(liteStep, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// destroy the list of icons
	iconListDelAll();

	// destroy the tooltip window
	if (tooltip)
		DestroyWindow( tooltip );
    // delete gdi objects...
	if (hbmSkin)
		DeleteObject( hbmSkin );
	if (hbmBack)
		DeleteObject( hbmBack );
	if (hrgnBack)
		DeleteObject( hrgnBack );
}

void grdTray::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "grdTray.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}

/*void grdTray::onRestoreTray(Message& message)
{
	if ( !iconListLoad( (void *)(message.lParam) ) )
		iconListLoadMaduin();
}
		
void grdTray::onSaveTray(Message& message)
{
	iconListSave( (void *)(message.lParam) );
}*/

void grdTray::onSysTray(Message& message)
{
	switch( message.wParam )
	{
		case NIM_ADD:
		{
			message.lResult = (BOOL)( iconAdd( (PLSNOTIFYICONDATA)message.lParam ) != NULL );
			break;
		}
		case NIM_MODIFY:
		{
			message.lResult = (BOOL)( iconMod( (PLSNOTIFYICONDATA)message.lParam ) != NULL );
			break;
		}
		case NIM_DELETE:
		{
			message.lResult = (BOOL)iconDel( (PLSNOTIFYICONDATA)message.lParam );
			break;
		}
		default:
		{
			message.lResult = FALSE;
			break;
		}
	}
}

void grdTray::onMouse(Message& message)
{
  if (!onMouseIcon(message))
	{
		int x = message.lParamLo, y = message.lParamHi;
		if (message.uMsg==WM_LBUTTONDOWN)
		{
			if ( borderDrag && ( (x<=borderLeft) || (x>=trayWidth-borderRight) ||
													 (y<=borderTop) || (y>=trayHeight-borderBottom) ) )
				SendMessage( hWnd, WM_SYSCOMMAND, SC_MOVE|2, message.lParam );
		}
		else if (message.uMsg==WM_RBUTTONUP)
		{
			PostMessage( liteStep, LM_POPUP, (WPARAM)x, (LPARAM)y );
		}
	}
	message.lResult = DefWindowProc(hWnd,message.uMsg,message.wParam,message.lParam);
}

BOOL grdTray::onMouseIcon(Message& message)
{
	PGRDSTICON pSysTrayIcon;
	MSG msg;
  POINT pt;
  pt.x = message.lParamLo;
  pt.y = message.lParamHi;

	// send message to the tooltip
	msg.hwnd = hWnd;
	msg.message = message.uMsg;
	msg.wParam = message.wParam;
	msg.lParam = message.lParam;
	msg.time = GetTickCount();
	msg.pt = pt;
	SendMessage( tooltip, TTM_RELAYEVENT, 0, (LPARAM) &msg );

	// remove "unwanted" icons
	iconListCleanup();

	// get icon at point
  pSysTrayIcon = iconListFindPt(pt);

	// post message to that icon
  if (pSysTrayIcon)
	{
		HWND hOwnerWnd = (HWND)pSysTrayIcon->getProp(GSTI_PT_HWND);

		if (hOwnerWnd==hWnd)
		{
			char *szCommand = (char *)pSysTrayIcon->getProp( WM_TO_GSTI_PT(message.uMsg) );
			if (szCommand && *szCommand)
			{
				LSExecute(hWnd, szCommand, SW_SHOWNORMAL);
				return TRUE;
			}
		}
		else
		{
			UINT uPostMsg = (UINT)pSysTrayIcon->getProp(GSTI_PT_MSG);
			if (uPostMsg)
			{
				SendMessage( hOwnerWnd, uPostMsg, (WPARAM)pSysTrayIcon->getProp(GSTI_PT_ID), (LPARAM)message.uMsg );
				return TRUE;
			}
		}
  }
	return FALSE;
}

void grdTray::onWindowPosChanging(Message& message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)message.lParam;

	if ( !( lpwp->flags & SWP_NOSIZE ) )
	{
		if ( (trayWidth!=lpwp->cx) || (trayHeight!=lpwp->cy) )
		{
      trayWidth = lpwp->cx;
			trayHeight = lpwp->cy;
		}
	}
	
	if ( !( lpwp->flags & SWP_NOMOVE ) )
	{
		if (snapDistance)
		{
			if ( abs(lpwp->x) <= snapDistance )
				lpwp->x = 0;
			if ( abs(lpwp->y) <= snapDistance )
				lpwp->y = 0;
			if ( abs(lpwp->x+trayWidth-GetSystemMetrics(SM_CXSCREEN)) <= snapDistance )
				lpwp->x = GetSystemMetrics(SM_CXSCREEN) - trayWidth;
			if ( abs(lpwp->y+trayHeight-GetSystemMetrics(SM_CYSCREEN)) <= snapDistance ) 
				lpwp->y = GetSystemMetrics(SM_CYSCREEN) - trayHeight;
		}
		trayX = lpwp->x;
		trayY = lpwp->y;
	}

	if ( !( lpwp->flags & SWP_NOSIZE) )
	{
		setFirstLast();
		createBackground();

		InvalidateRect(hWnd,NULL,TRUE);
	}
	message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam); 
}

void grdTray::onWindowPosChanged(Message& message)
{
  LPWINDOWPOS lpwp = (LPWINDOWPOS)message.lParam;

  if (!(lpwp->flags&SWP_NOMOVE))
  {
  	trayX = (int)lpwp->x;
	  trayY = (int)lpwp->y;
    lpwp->flags |= SWP_NOMOVE;
  }
  if (!(lpwp->flags&SWP_NOSIZE))
  {
		if ( (trayWidth!=lpwp->cx) || (trayHeight!=lpwp->cy) )
		{
      //char buffer2[MAX_LINE_LENGTH];
      //sprintf( buffer2, "before trayWidth=%d\ntrayHeight=%d\n",trayWidth,trayHeight);
      //OutputDebugString( buffer2 );

      trayWidth = lpwp->cx;
			trayHeight = lpwp->cy;

      //sprintf( buffer2, "before trayWidth=%d\ntrayHeight=%d\n",trayWidth,trayHeight);
      //OutputDebugString( buffer2 );

			setFirstLast();
			createBackground();

			InvalidateRect(hWnd,NULL,TRUE);
		}
    lpwp->flags |= SWP_NOSIZE;
	}
  message.lResult = DefWindowProc(hWnd,message.uMsg, message.wParam,(LPARAM)lpwp);
}

void grdTray::onPaint (Message& message)
{
	HDC     hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN    hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	if (transpBack)
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	paintBackground(hdcBuffer, hrgn);

	// blit the icons
	iconListPaint(hdcBuffer, hrgn);

	// set the windowRgn
	if (transpBack)
		SetWindowRgn(hWnd, hrgn, TRUE);

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, trayWidth, trayHeight, hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// remove the memory DC
	DeleteDC(hdcBuffer);

	EndPaint(hWnd, &ps);
}


// bang commands!!		
void grdTray::show(void)
{
	visible = TRUE;
	ShowWindow( hWnd, SW_SHOWNOACTIVATE );
}
void grdTray::hide(void)
{
	visible = FALSE;
	ShowWindow( hWnd, SW_HIDE );
}
void grdTray::toggle(void)
{
	visible = !IsWindowVisible( hWnd );
	ShowWindow( hWnd, visible?SW_SHOWNOACTIVATE:SW_HIDE );
}
void grdTray::toggleOnTop(void)
{
	onTop = !(GetWindowLong(hWnd, GWL_EXSTYLE) & WS_EX_TOPMOST);
	SetWindowPos( hWnd, onTop?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	SetWindowLong( hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ ((onTop)?WS_CHILD:WS_POPUP))|((onTop)?WS_POPUP:WS_CHILD));
}	
void grdTray::move(int x, int y)
{
	SetWindowPos( hWnd, NULL, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE );
}
void grdTray::size(int cx, int cy)
{
	SetWindowPos( hWnd, NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE );
}
void grdTray::iconAddBang(char *args)
{
	iconAddRC(args);
}
void grdTray::iconDelBang(int n)
{
	PGRDSTICON pSysTrayIcon = NULL;
	if (n>0)
	{
		pSysTrayIcon = pFirst;
		n--;
		while (n && pSysTrayIcon)
		{
			pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
			n--;
		}
	}
	else
	{
		pSysTrayIcon = pLast;
		if (n<0)
		{
			n++;
			while (n && pSysTrayIcon)
			{
				pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_PREV);
				n++;
			}
		}
	}
	iconDelGRD( pSysTrayIcon );
}

void grdTray::setFirstLast()
{
	// the following settings are used with the icon rectangles
	// to ensure they match the desired pattern
	firstX = ( ( direction == TD_LEFT ) || ( wrapDirection == TD_LEFT ) ) ?
				( trayWidth -  borderRight  - iconSpacingX - iconSize ) :
				( borderLeft + iconSpacingX );
	lastX  = firstX + ( wrapCount - 1 ) * deltaX;

	firstY = ( ( direction == TD_DOWN ) || ( wrapDirection == TD_DOWN ) ) ?
				( borderTop + iconSpacingY ) :
				( trayHeight - borderBottom - iconSpacingY - iconSize );

	lastY  = firstY + ( wrapCount - 1 ) * deltaY;
}


void grdTray::createBackground()
{
  HDC hdcScreen, hdcDst;
  HBITMAP hbmDstOld;

  // delete old objects if necessary...
  if ( hbmBack )
	  DeleteObject( hbmBack );
  hbmBack = NULL;

  if ( hrgnBack )
	  DeleteObject( hrgnBack );
  hrgnBack = NULL;

  // initiate a new destination dc
  hdcScreen = GetDC(hWnd);

  hdcDst    = CreateCompatibleDC(hdcScreen);
  hbmBack   = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
  hbmDstOld = (HBITMAP)SelectObject(hdcDst, hbmBack);

  ReleaseDC(hWnd, hdcScreen);

  // if the background colors are needed put them on...
  if ((!hbmSkin)||transpSkin)
  {
	  RECT r;
	  HBRUSH brush;

	  // fill the border with the border colors
	  if (borderTop||borderLeft||borderBottom||borderTop)
	  {
		  brush = CreateSolidBrush(clrBorder);

		  if (borderTop)
		  {
			  SetRect(&r, 0, 0, trayWidth, borderTop);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderLeft)
		  {
			  SetRect(&r, 0, borderTop, borderLeft, trayHeight - borderBottom);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderRight)
		  {
			  SetRect(&r, trayWidth - borderRight, borderTop, trayWidth, trayHeight - borderBottom);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderBottom)
		  {
			  SetRect(&r, 0, trayHeight - borderBottom, trayWidth, trayHeight);
			  FillRect(hdcDst, &r, brush);
		  }
		  DeleteObject(brush);
	  }

	  // now fill the inner rectangle (excluding the borders) with the background color
	  brush = CreateSolidBrush(clrBack);

	  SetRect(&r, borderLeft, borderTop, trayWidth-borderRight, trayHeight-borderBottom);
	  FillRect(hdcDst, &r, brush);

	  DeleteObject(brush);
  }

  // if a background image is provided, put it on...
  if (hbmSkin)
  {

    HDC     hdcSrc;
    HBITMAP hbmSrcOld;
    BITMAP  bm;
    int innerWidth, innerHeight, bmInnerWidth, bmInnerHeight;

	  // get info from the bitmap
    GetObject(hbmSkin, sizeof(BITMAP), &bm);

    // this is to prevent negative values on the width
    innerWidth  = max(trayWidth -(borderLeft+borderRight), 0);
    innerHeight = max(trayHeight-(borderTop+borderBottom), 0);
    bmInnerWidth  = max(bm.bmWidth -(borderLeft+borderRight), 1);
    bmInnerHeight = max(bm.bmHeight-(borderTop+borderBottom), 1);

    hdcSrc    = CreateCompatibleDC(hdcDst);
    hbmSrcOld = (HBITMAP)SelectObject(hdcSrc, hbmSkin);

	  if (borderTop||borderLeft||borderBottom||borderTop)
	  {

		  // paint the four corners first, and then the borders
		  // topleft, topright, bottomright, bottomleft
		  copyBlt(hdcDst, 0, 0, borderLeft, borderTop, hdcSrc, 0, 0);
		  copyBlt(hdcDst, trayWidth-borderRight, 0, borderRight, borderTop, hdcSrc, bm.bmWidth-borderRight, 0);
		  copyBlt(hdcDst, trayWidth-borderRight, trayHeight-borderBottom, borderRight, borderBottom, hdcSrc, bm.bmWidth-borderRight, bm.bmHeight-borderBottom);
		  copyBlt(hdcDst, 0, trayHeight-borderBottom, borderLeft, borderBottom, hdcSrc, 0, bm.bmHeight-borderBottom);

		  if (borderTop&&innerWidth)
		    sizeBlt(hdcDst, borderLeft, 0, innerWidth, borderTop, hdcSrc, borderLeft, 0, bmInnerWidth, borderTop);
		  if (borderLeft&&innerHeight)
		    sizeBlt(hdcDst, 0, borderTop, borderLeft, innerHeight, hdcSrc, 0, borderTop, borderLeft, bmInnerHeight);
		  if (borderRight&&innerHeight)
		    sizeBlt(hdcDst, trayWidth-borderRight, borderTop, borderRight, innerHeight, hdcSrc, bm.bmWidth-borderRight, borderTop, borderRight, bmInnerHeight);
		  if (borderBottom&&innerWidth)
		    sizeBlt(hdcDst, borderLeft, trayHeight-borderBottom, innerWidth, borderBottom, hdcSrc, borderLeft, bm.bmHeight-borderBottom, bmInnerWidth, borderBottom);
	  }

    // draw area in the middle
    if(innerWidth&&innerHeight)
      sizeBlt(hdcDst, borderLeft, borderTop, innerWidth, innerHeight, hdcSrc, borderLeft, borderTop, bmInnerWidth, bmInnerHeight);

    SelectObject( hdcSrc, hbmSrcOld );
    DeleteDC( hdcSrc );
  }

  SelectObject( hdcDst, hbmDstOld );
  DeleteDC( hdcDst );

  if (!transpSkin)
  {
	  transpBack = FALSE;
  }
  else
  {
	  HRGN hOpaqueRgn = CreateRectRgn(0, 0, trayWidth, trayHeight);
	  hrgnBack        = BitmapToRegion(hbmBack, RGB(255,0,255), 0x101010, 0, 0);

	  // to see if any pixels are transparent
	  transpBack      = !EqualRgn(hrgnBack, hOpaqueRgn);

	  DeleteObject(hOpaqueRgn);

	  if (!transpBack)
	  {
		  DeleteObject(hrgnBack);
		  hrgnBack = NULL;
	  }
  }
}

void grdTray::paintBackground( HDC hdcDst, HRGN hrgnDst ) {

	HDC hdcSrc;
	HBITMAP hbmOld;

	// if the background isn't there, make one...
	if (!hbmBack)
	{
		createBackground();
  }
  else
  {
    BITMAP bm;
    GetObject(hbmBack,sizeof(BITMAP),&bm);
    if(bm.bmWidth!=trayWidth||bm.bmHeight!=trayHeight)
    {
      createBackground();
    }
  }

	// if there is no background now... do nothing
	if (!hbmBack)
		return;


	hdcSrc = CreateCompatibleDC(hdcDst);
	hbmOld = (HBITMAP)SelectObject(hdcSrc, hbmBack);

	BitBlt(hdcDst, 0, 0, trayWidth, trayHeight, hdcSrc, 0, 0, SRCCOPY);

	SelectObject(hdcSrc, hbmOld);
	DeleteDC(hdcSrc);

	if ( hrgnBack && transpBack )
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_COPY);

}

// grd Blitting functions...
// to enable transp / not transp painting
// and to enable tile / stretch resizing
int grdTray::copyBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc)
{
	if (transpSkin)
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, RGB(255,0,255));
	else
		return BitBlt(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, SRCCOPY);

	return 0;
}

int grdTray::sizeBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc)
{
	HDC		  hdcTmp;
	HBITMAP hbmTmp, hbmOld;
  int     tmpX, tmpY;
	
	if (transpSkin)
	{
		hdcTmp = CreateCompatibleDC( hdcDst );
		hbmTmp = CreateCompatibleBitmap( hdcDst, cxDst, cyDst );
		hbmOld = (HBITMAP)SelectObject( hdcTmp, hbmTmp );
    tmpX = 0, tmpY = 0;
	}
	else
  {
		hdcTmp = hdcDst;
    tmpX = xDst, tmpY = yDst;
  }
	
	if (skinTiled)
	{
		int x, y;
		// fill the first row of images
		for (x = 0; x < cxDst; x += cxSrc)
			BitBlt(hdcTmp, tmpX+x, tmpY, min(cxSrc, cxDst-x), min(cySrc,cyDst), hdcSrc, xSrc, ySrc, SRCCOPY);
		// copy this row down the y axis...
		for (y = cySrc; y < cyDst; y += cySrc)
			BitBlt(hdcTmp, tmpX, tmpY+y, cxDst, min(cySrc, cyDst-y), hdcTmp, tmpX, tmpY, SRCCOPY);

	}
	else
  {
	  // stretch it
		StretchBlt(hdcTmp, tmpX, tmpY, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY);
  }

	// blit the resulting image onto the destination dc
	if (transpSkin)
	{
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcTmp, tmpX, tmpY, RGB(255,0,255));

		// cleanup
		SelectObject( hdcTmp, hbmOld );
		DeleteObject( hbmTmp );
		DeleteDC( hdcTmp );
	}
	return 0;
}

PGRDSTICON grdTray::iconListFind(HWND hWnd, UINT uID)
{
	PGRDSTICON pSysTrayIcon = pFirst;
	
	while(pSysTrayIcon)
	{
		if( ((HWND)pSysTrayIcon->getProp(GSTI_PT_HWND)==hWnd) && ((UINT)pSysTrayIcon->getProp(GSTI_PT_ID)==uID) )
			return pSysTrayIcon;
		pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
	}
  return NULL;
}
PGRDSTICON grdTray::iconListFindPt(POINT pt)
{
	PGRDSTICON pSysTrayIcon = pFirst;
	
	while(pSysTrayIcon)
	{
		if( PtInRect(((RECT*)pSysTrayIcon->getProp(GSTI_PT_RECT)),pt) )
		{
			if ( IsWindow((HWND)pSysTrayIcon->getProp(GSTI_PT_HWND)) )
			{
				return pSysTrayIcon;
			}
			else
			{
				iconDelGRD(pSysTrayIcon);
				return NULL;
			}
		}
		pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
	}
  return NULL;
}

/*int grdTray::iconListSave(void *dst)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)dst;
	PGRDSTICON pSysTrayIcon = NULL;
	int i = 0;

	iconListCleanup();
	pSysTrayIcon = pFirst;

	while (pSysTrayIcon)
	{
		// don't save the RC-icons
		if ( (HWND)pSysTrayIcon->getProp(GSTI_PT_HWND)!=hWnd )
		{
			void *value = NULL;

			// set the saving data based on the list
			trayArray[i].cbSize	= sizeof(NOTIFYICONDATA);
			trayArray[i].hWnd	= (HWND)pSysTrayIcon->getProp(GSTI_PT_HWND);
			trayArray[i].uID = (UINT)pSysTrayIcon->getProp(GSTI_PT_ID);
			trayArray[i].uFlags	= NULL;
			trayArray[i].uCallbackMessage = (UINT)pSysTrayIcon->getProp(GSTI_PT_MSG);
			if (trayArray[i].uCallbackMessage)
				trayArray[i].uFlags |= NIF_MESSAGE;

			value = pSysTrayIcon->getProp(GSTI_PT_ICON);
			if (value)
			{
				trayArray[i].uFlags |= NIF_ICON;
				trayArray[i].hIcon = CopyIcon((HICON)value);
			}

			value = pSysTrayIcon->getProp(GSTI_PT_TIP);
			if (value)
			{
				trayArray[i].uFlags |= NIF_TIP;
				lstrcpyn(trayArray[i].szTip, (char *)value, 64);
			}
			i++;

		}
		pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
	}
	trayArray[i].hWnd = 0;

	return i;
}

int grdTray::iconListLoad(void *src)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)src;
	int i = 0;

	if (src)
	{
		while (trayArray[i].hWnd)
		{
			// add all icons from the buffer
			SendMessage( liteStep, LM_SYSTRAY, NIM_ADD, (LPARAM)&trayArray[i] );
			DestroyIcon( trayArray[i].hIcon );
			i++;
		}
	}
	return i;
}

int grdTray::iconListLoadMaduin()
{
	// icon information			
	NOTIFYICONDATA *trayArray;
	DWORD dwIconCount = 0;
	unsigned int i = 0;

	// subkey
	HKEY hSubKey = NULL;
	// registry values needed
	DWORD dwDataType;
	DWORD dwDataSize = sizeof(DWORD);
	
	// open the regestry subkey
	if( RegOpenKeyEx( HKEY_CURRENT_USER, REGKEY_SAVEDDATA, 0, KEY_QUERY_VALUE, &hSubKey ) == ERROR_SUCCESS )
	{
		// get the number of icons
		if( RegQueryValueEx( hSubKey, TEXT("IconCount"), NULL, &dwDataType, (LPBYTE) &dwIconCount, &dwDataSize ) == ERROR_SUCCESS )
		{
			// if not everything worked perfectly return 0
			if( ( dwDataType == REG_DWORD ) && ( dwDataSize == sizeof(DWORD) ) )
			{
				dwDataSize = dwIconCount * sizeof(NOTIFYICONDATA);
				trayArray = (PNOTIFYICONDATA) new BYTE[ dwDataSize ];
						
				if(trayArray)
				{
					if( RegQueryValueEx( hSubKey, TEXT("Icons"), NULL, &dwDataType, (LPBYTE) trayArray, &dwDataSize ) == ERROR_SUCCESS )
					{
						if( dwDataType == REG_BINARY )
						{
							for( i = 0; i < dwIconCount; i++ )
							{
								if( IsWindow( trayArray[i].hWnd ) )
								SendMessage( liteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) &trayArray[i] );
								// as this module does not remove the icons array from memory
								// it's not very wise to remove the HICONs
							}
						}
					}
					delete[] trayArray;
				}
			}
		}
		// close the registry subkey
		RegCloseKey( hSubKey );
	}
	return (int)(i + 1);
}*/

int grdTray::iconListLoadRC()
{
	FILE * f;
	char buffer[MAX_LINE_LENGTH];
	int iAdd = 0;

	f = LCOpen(NULL);

	if (f)
	{
		while ( LCReadNextConfig(f, TEXT("*grdTrayAdd"), buffer, 4096) )
		{
			// 12 is because we don't need the part "*grdTrayAdd "
      //char buffer2[MAX_LINE_LENGTH];
      //sprintf( buffer2, "loading icon from \"%s\"", (char *)(buffer+12) );
      //OutputDebugString(buffer2);
			if ( iconAddRC( (char *)(buffer+12) ) )
				iAdd++;
		}
		LCClose(f);
	}
	return iAdd;
}

void grdTray::iconListCleanup()
{
	PGRDSTICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;
	
	while(pSysTrayIcon)
	{
		pSysTrayIcon2 = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
		//char buffer2[MAX_LINE_LENGTH];
		//sprintf(buffer2,"checking window: %d", (int)pSysTrayIcon->getProp(GSTI_PT_HWND));
		//OutputDebugString(buffer2);

		if( !IsWindow((HWND)pSysTrayIcon->getProp(GSTI_PT_HWND)) )
			iconDelGRD(pSysTrayIcon);
		
		pSysTrayIcon = pSysTrayIcon2;
	}
}

BOOL grdTray::iconListDelAll() {

	PGRDSTICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;

	while (pSysTrayIcon)
	{
		// save the one to be deleted and move to the next
		pSysTrayIcon2 = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
		// delete this history item
		iconDelGRD(pSysTrayIcon);
		pSysTrayIcon = pSysTrayIcon2;
	}
	return TRUE;
}

void grdTray::iconListPaint( HDC hdcDst, HRGN hrgnDst )
{
	PGRDSTICON pSysTrayIcon = pFirst;

	while(pSysTrayIcon)
	{
		HICON hIcon = (HICON)pSysTrayIcon->getProp(GSTI_PT_ICON);
		RECT *rc    = (RECT*)pSysTrayIcon->getProp(GSTI_PT_RECT);
		HRGN  hRgn  = (HRGN)pSysTrayIcon->getProp(GSTI_PT_RGN);

		//char buffer[MAX_LINE_LENGTH];
		//char buffer2[MAX_LINE_LENGTH];
		//GetWindowText((HWND)pSysTrayIcon->getProp(GSTI_PT_HWND),buffer,MAX_LINE_LENGTH-1);
		//sprintf(buffer2, "painting icon...\nowner window title=\"%s\"", buffer);
		//OutputDebugString( buffer2 );

		if(hIcon)
		{
			if (effectFlags & FX_ANY)
			{
				UINT y = 0;
				HDC hdc        = ::CreateCompatibleDC(hdcDst);
				HBITMAP hbmNew = ::CreateCompatibleBitmap(hdcDst, 2*iconSize, iconSize);
				HBITMAP hbmOld = (HBITMAP) ::SelectObject(hdc, hbmNew);

				DrawIconEx(hdc, 0, 0, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
				DrawIconEx(hdc, iconSize, 0, hIcon, iconSize, iconSize, 0, NULL, DI_MASK);

				while (y < iconSize)
				{
					UINT x = 0;
					while (x < iconSize)
					{
						// loop through all transparent pixels...
						while (x < iconSize)
						{
							// if the mask-pixel is white, then break
							if ( !GetPixel(hdc, x+iconSize, y) )
							{
								COLORREF cl = ::GetPixel(hdc, x, y);
								BYTE r = GetRValue(cl);
								BYTE g = GetGValue(cl);
								BYTE b = GetBValue(cl);

								// saturnation effect
								if (effectFlags & FX_SATURNATION)
								{
									BYTE gray = (BYTE)(r*0.3086+g*0.6094+b*0.0820);

									r = (BYTE)((r*saturnation+gray*(255-saturnation)+255)>>8);
									g = (BYTE)((g*saturnation+gray*(255-saturnation)+255)>>8);
									b = (BYTE)((b*saturnation+gray*(255-saturnation)+255)>>8);
								}
								// icon hue effect
								if (effectFlags & FX_ICONHUE)
								{
									// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
									r = (BYTE)((r*(255-hueIntensity)+GetBValue(clrHue)*hueIntensity+255)>>8);
									g = (BYTE)((g*(255-hueIntensity)+GetGValue(clrHue)*hueIntensity+255)>>8);
									b = (BYTE)((b*(255-hueIntensity)+GetRValue(clrHue)*hueIntensity+255)>>8);
								}
								SetPixel(hdcDst, rc->left+x, rc->top+y, RGB(r, g, b));
							}
							x++;
						}
					}
					y++;
				}
				SelectObject(hdc, hbmOld);
				DeleteObject(hbmNew);
				DeleteDC(hdc);

			}
			else
				DrawIconEx(hdcDst, rc->left, rc->top, hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);

			// combine the region
			if (hRgn && transpBack)
			{ 
				OffsetRgn(hRgn, rc->left, rc->top);
				CombineRgn(hrgnDst, hrgnDst, hRgn, RGN_OR);
				OffsetRgn(hRgn, -rc->left, -rc->top);
			}
		}
		pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
	}
}

/**** PROPERTY CHANGERS ****/

void grdTray::setIcon(PGRDSTICON pSysTrayIcon, HICON icon)
{
	HRGN  hRgn  = NULL;

	if (icon && transpBack)
	{
		hRgn = ::CreateRectRgn(0,0,0,0);
		
		HDC hdc        = ::CreateCompatibleDC( NULL );
		HBITMAP hbmNew = ::CreateCompatibleBitmap( hdc, iconSize, iconSize );
		HBITMAP hbmOld = (HBITMAP) ::SelectObject( hdc, hbmNew );

		if ( DrawIconEx(hdc, 0, 0, icon, iconSize, iconSize, 0, NULL, DI_MASK) )
		{
			int y = 0;
			while ( y < iconSize )
			{
				int x = 0;
				while ( x < iconSize )
				{
					UINT firstNTX = 0;
					// loop through all transparent pixels...
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( !::GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// set first non transparent pixel
					firstNTX = x;
					// loop through all non transparent pixels
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// if found one or more non-transparent pixels in a row, add them to the rgn...
					if ((x-firstNTX)>0)
					{
						HRGN hTempRgn = CreateRectRgn(firstNTX, y, x, y+1);
						CombineRgn(hRgn, hRgn, hTempRgn, RGN_OR);
						DeleteObject(hTempRgn);
					}
					x++;

				}
				y++;

			}

		}
		pSysTrayIcon->setProp(GSTI_PT_RGN, (void *)hRgn);
		DeleteObject( hRgn );
		SelectObject( hdc, hbmOld );
		DeleteObject( hbmNew );
		DeleteDC(hdc);

	}
	pSysTrayIcon->setProp(GSTI_PT_ICON, (void *)icon);
}

void grdTray::setToolTip(PGRDSTICON pSysTrayIcon, char *szNewToolTip)
{
	BOOL     existed = TRUE;
	UINT     uStrLen = 0;
	TOOLINFO ti;
	char    *szToolTip = (char *)pSysTrayIcon->getProp(GSTI_PT_TIP);

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd	  = hWnd;
	ti.hinst  = NULL;

  //OutputDebugString("1");

  if (!szToolTip)
	{
		existed = FALSE;
		pSysTrayIcon->setProp(GSTI_PT_TIPID, (void *)uLastID++);
	}

	ti.uId = (UINT)pSysTrayIcon->getProp(GSTI_PT_TIPID);

  //OutputDebugString("2");

  // set the new tip
	pSysTrayIcon->setProp(GSTI_PT_TIP, (void *)szNewToolTip);

	// load the new tip into szToolTip
	szToolTip = (char *)pSysTrayIcon->getProp(GSTI_PT_TIP);
	ti.lpszText = szToolTip;

  //OutputDebugString("3");

	if ( existed )
  {
    //OutputDebugString("4a");
		SendMessage(tooltip, (szToolTip)?TTM_UPDATETIPTEXT:TTM_DELTOOL, 0, (LPARAM)&ti);
  }
	else if ( szToolTip )
	{
    //OutputDebugString("4b");
		RECT *rc = (RECT *)pSysTrayIcon->getProp(GSTI_PT_RECT);
		ti.uFlags = 0;
    ti.rect = *rc;
		ti.lpszText = szToolTip;

		SendMessage(tooltip, TTM_ADDTOOL, 0, (LPARAM)&ti);
	}
  //OutputDebugString("5");
}
void grdTray::adjustRect(PGRDSTICON pSysTrayIcon)
{
	BOOL existed = TRUE;
	PGRDSTICON pPrevTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_PREV);
	RECT *rc = (RECT *)pSysTrayIcon->getProp(GSTI_PT_RECT);

	if (!rc)
  {
		rc = new RECT;
		existed = FALSE;
	}

	if (pPrevTrayIcon)
	{
		RECT *rcPrev = (RECT *)pPrevTrayIcon->getProp(GSTI_PT_RECT);
		if (direction & TD_VERTICAL)
		{
			// if there is room for one more icon
			if (rcPrev->top!=lastY)
			{
				rc->top  = rcPrev->top  + deltaY;
				rc->left = rcPrev->left;
			}
			else
			{
				rc->top  = firstY;
				rc->left = rcPrev->left + deltaX;
			}
		}
		else
		{
			// if there is room for one more icon
			if (rcPrev->left!=lastX)
			{
				rc->left = rcPrev->left + deltaX;
				rc->top  = rcPrev->top;
			}
			else
			{
				rc->left = firstX;
				rc->top  = rcPrev->top  + deltaY;
			}
		}
	}
	else
	{
		rc->left = firstX;
		rc->top  = firstY;
	}

	rc->right  = rc->left + iconSize;
	rc->bottom = rc->top  + iconSize;

		if(pSysTrayIcon->getProp(GSTI_PT_TIP))
		{
			TOOLINFO ti;
			ti.hwnd = hWnd;
			ti.uId  = (UINT)pSysTrayIcon->getProp(GSTI_PT_TIPID);
			ti.rect = *rc;
			SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
		}


	// as it is a pointer, it has only to be set when the
	// pointer changes, which it doesn't if it existed before
	if (!existed)
		pSysTrayIcon->setProp(GSTI_PT_RECT, (void *)rc);
}

void grdTray::adjustSize()
{
	RECT rcOrg;
	int x,y,cx,cy;

	// this is the new size...
	if (pLast) {

		RECT *rcLast = (RECT*)pLast->getProp(GSTI_PT_RECT);

		cx = iconSize+2*iconSpacingX+borderRight+borderLeft;
		cy = iconSize+2*iconSpacingY+borderBottom+borderTop;

		if (direction & TD_VERTICAL)
		{
			if (rcLast->left!=firstX)
				cy += (direction==TD_DOWN)?(lastY-firstY):(firstY-lastY);
			else
				cy += (direction==TD_DOWN)?(rcLast->top-firstY):(firstY - rcLast->top);
			cx += (wrapDirection==TD_RIGHT)?(rcLast->left-firstX):(firstX-rcLast->left);
		}
		else
		{
			if (rcLast->top!=firstY)
				cx += (direction==TD_RIGHT)?(lastX-firstX):(firstX-lastX);
			else
        cx += (direction==TD_RIGHT)?(rcLast->left-firstX):(firstX-rcLast->left);
			cy += (wrapDirection==TD_DOWN)?(rcLast->top-firstY):(firstY - rcLast->top);
		}
	}
	else
	{
		cx = borderLeft + borderRight;
		cy = borderTop + borderBottom;
	}
			
	// position it according to the old position
	GetWindowRect(hWnd, &rcOrg);

	x = ((direction==TD_RIGHT)||(wrapDirection==TD_RIGHT))?rcOrg.left:rcOrg.right-cx;
	y = ((direction==TD_DOWN)||(wrapDirection==TD_DOWN))?rcOrg.top:rcOrg.bottom-cy;

	SetWindowPos(hWnd, NULL, x, y, cx, cy, SWP_NOACTIVATE|SWP_NOZORDER);

  /*trayX = x;
  trayY = y;
  trayWidth = cx;
  trayHeight = cy;

  setFirstLast();
  createBackground();*/

	if (pLast)
	{
		PGRDSTICON pSysTrayIcon = pFirst;

		while (pSysTrayIcon)
		{
			adjustRect(pSysTrayIcon);
			pSysTrayIcon = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
		}
	}
}

PGRDSTICON grdTray::iconAdd(PLSNOTIFYICONDATA pnid)
{
	PGRDSTICON pSysTrayIcon;
	
	if( !IsWindow(pnid->hWnd) )
		return NULL;

	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if found, modify instead of add
	if ( pSysTrayIcon ) 
		return iconMod( pnid );

	// if not found (which is the way it should go)
	pSysTrayIcon = new GRDSTICON;

	// transfer properties
	pSysTrayIcon->setProp(GSTI_PT_HWND, (void *)pnid->hWnd);
	pSysTrayIcon->setProp(GSTI_PT_ID, (void *)pnid->uID);
	pSysTrayIcon->setProp(GSTI_PT_MSG, (void *)((pnid->uFlags & NIF_MESSAGE)?pnid->uCallbackMessage:NULL));

	// set icon and region properties
	setIcon( pSysTrayIcon, (pnid->uFlags & NIF_ICON)?pnid->hIcon:NULL );

	// add to last position in the list
	if (!pFirst)
	{
		pFirst = pSysTrayIcon;
		pSysTrayIcon->setProp(GSTI_PT_PREV, (void *)NULL);
	} 
	if (pLast)
	{
		pSysTrayIcon->setProp(GSTI_PT_PREV, (void *)pLast);
		pLast->setProp(GSTI_PT_NEXT, (void *)pSysTrayIcon);
	}
	pLast = pSysTrayIcon;
	pSysTrayIcon->setProp(GSTI_PT_NEXT, (void *)NULL);

	// adjust the rectangle to the correct position ( uses list position )
	adjustRect(pSysTrayIcon);

	// add tooltip (uses rect)
	setToolTip(pSysTrayIcon, (pnid->uFlags & NIF_TIP)?pnid->szTip:NULL);

	// remove "unwanted" icons
	iconListCleanup();

	if (autoSize)
		adjustSize(); // which will repaint the window
	else
		InvalidateRect(hWnd, (RECT*)(pSysTrayIcon->getProp(GSTI_PT_RECT)), TRUE);

	// if it's the first icon, send an SHOW message
	if ( (pFirst==pSysTrayIcon) && (hideIfEmpty) )
		ShowWindow(hWnd, SW_SHOWNOACTIVATE);
	
	// return the newly created icon
	return pSysTrayIcon;
}

PGRDSTICON grdTray::iconAddRC(char *config)
{
	// gets the settings
	char szBuffer[MAX_LINE_LENGTH];
	// gets one valuename (inc value) at the time
	char szPropertyName[MAX_LINE_LENGTH];
	char *szPropertyValue;
	// array with tokens
	char*	tokens[1] = {szPropertyName};

	// init vars
	PGRDSTICON pSysTrayIcon = new GRDSTICON;

	pSysTrayIcon->setProp(GSTI_PT_HWND, (void *)hWnd);

	// add to last position in the list
	if (!pFirst)
	{
		pFirst = pSysTrayIcon;
		pSysTrayIcon->setProp(GSTI_PT_PREV, (void *)NULL);
	} 
	if (pLast)
	{
		pSysTrayIcon->setProp(GSTI_PT_PREV, (void *)pLast);
		pLast->setProp(GSTI_PT_NEXT, (void *)pSysTrayIcon);
	}
	pLast = pSysTrayIcon;
	pSysTrayIcon->setProp(GSTI_PT_NEXT, (void *)NULL);

  //OutputDebugString("icon placed in list\n");

	// adjust the rectangle
	adjustRect(pSysTrayIcon);

  //OutputDebugString("time to start reading config\n");

	// prepare for launching LCTokenize
  VarExpansion(szBuffer, config);

  do
	{
    szPropertyName[0] = '\0';
    // split the string into tokens (one at a time)
    LCTokenize (szBuffer, tokens, 1, szBuffer);

		// find the delimiter
    szPropertyValue = strchr(szPropertyName,'=');

		if (szPropertyValue)
		{
			// and split into name/value pair
			*szPropertyValue = '\0';
			szPropertyValue++;

			if (!strnicmp(szPropertyName, "icon", 5))
			{
        //char buffer2[MAX_LINE_LENGTH];
        //sprintf( buffer2, "loading HICON from %s\n", szPropertyValue );
        //OutputDebugString(buffer2);
				HICON hIcon = LoadLSIcon(szPropertyValue, NULL);
				setIcon(pSysTrayIcon, hIcon);
				DestroyIcon(hIcon);
        //OutputDebugString("icon is loaded\n");
			}
      else if (!strnicmp(szPropertyName, "tip", 4))
      {
        //char buffer2[MAX_LINE_LENGTH];
        //sprintf( buffer2, "loading tooltip from \"%s\"\n", szPropertyValue );
        //OutputDebugString(buffer2);
				setToolTip(pSysTrayIcon, szPropertyValue);
        //OutputDebugString("tooltip is loaded\n");
      }
			else if (!strnicmp(szPropertyName, "onldown", 8))
			{
				pSysTrayIcon->setProp(GSTI_PT_LBUTTONDOWN, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onlup", 6))
			{
				pSysTrayIcon->setProp(GSTI_PT_LBUTTONUP, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onldblclk", 10))
			{
				pSysTrayIcon->setProp(GSTI_PT_LBUTTONDBLCLK, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onrdown", 8))
			{
				pSysTrayIcon->setProp(GSTI_PT_RBUTTONDOWN, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onrup", 6))
			{
				pSysTrayIcon->setProp(GSTI_PT_RBUTTONUP, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onrdblclk", 10))
			{
				pSysTrayIcon->setProp(GSTI_PT_RBUTTONDBLCLK, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onmdown", 8))
			{
				pSysTrayIcon->setProp(GSTI_PT_MBUTTONDOWN, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onmup", 6))
			{
				pSysTrayIcon->setProp(GSTI_PT_MBUTTONUP, (void *)szPropertyValue);
			}
			else if (!strnicmp(szPropertyName, "onmdblclk", 10))
			{
				pSysTrayIcon->setProp(GSTI_PT_MBUTTONDBLCLK, (void *)szPropertyValue);
			}
			// should be other possible vars to add and change props for...
			// have yet to decide which...
		}
  } while (*szBuffer);

  //OutputDebugString("done settings properties\ncleanup\n");

	// remove "unwanted" icons
	iconListCleanup();

	if (autoSize)
		adjustSize(); // which will repaint the window
	else
		InvalidateRect( hWnd, (RECT*)(pSysTrayIcon->getProp(GSTI_PT_RECT)), TRUE );

  //OutputDebugString("icon is loaded, more or less\n");

	// if it's the first icon, send an SHOW message
	if ( (pFirst==pSysTrayIcon) && hideIfEmpty )
		ShowWindow( hWnd, SW_SHOWNOACTIVATE );

	return pSysTrayIcon;
}

PGRDSTICON grdTray::iconMod(PLSNOTIFYICONDATA pnid)
{
	PGRDSTICON pSysTrayIcon;
	
	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if not found, add instead of modify
	if (!pSysTrayIcon) 
		return iconAdd(pnid);

	if(pnid->uFlags & NIF_MESSAGE)
		pSysTrayIcon->setProp(GSTI_PT_MSG, (void *)pnid->uCallbackMessage);
	
	if(pnid->uFlags & NIF_TIP)
		setToolTip(pSysTrayIcon, pnid->szTip);

	if(pnid->uFlags & NIF_ICON)
		setIcon(pSysTrayIcon, pnid->hIcon);

	// remove "unwanted" icons
	iconListCleanup();

	InvalidateRect(hWnd, NULL, TRUE);

	// return the "refreshed" icon
	return pSysTrayIcon;
}
	
BOOL grdTray::iconDel(PLSNOTIFYICONDATA pnid)
{
	PGRDSTICON pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	if (pSysTrayIcon)
	{
		return iconDelGRD(pSysTrayIcon);
	}
	return FALSE;
}

BOOL grdTray::iconDelGRD(PGRDSTICON pSysTrayIcon)
{
	RECT *rc;
	PGRDSTICON pIteratorSysTrayIcon;
	TOOLINFO ti;

	if( !pSysTrayIcon )
		return FALSE;

	// remove the tooltip
	setToolTip(pSysTrayIcon, NULL);
	
	// change all the rectangles and update the tooltips
	pIteratorSysTrayIcon = pLast;
	// swap rectangles... this is smooth
	while (pIteratorSysTrayIcon!=pSysTrayIcon)
	{
		// looks funny, but should work (get the rect from the previous grdSTIcon)
		rc = new RECT;
		*rc = *(RECT *)(((PGRDSTICON)pIteratorSysTrayIcon->getProp(GSTI_PT_PREV))->getProp(GSTI_PT_RECT));
		pIteratorSysTrayIcon->setProp(GSTI_PT_RECT, (void *)rc);
		
		if(pIteratorSysTrayIcon->getProp(GSTI_PT_TIP))
		{
			ti.hwnd = hWnd;
			ti.uId  = (UINT)pIteratorSysTrayIcon->getProp(GSTI_PT_TIPID);
			ti.rect = *rc;
			SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
		}
		pIteratorSysTrayIcon = (PGRDSTICON)pIteratorSysTrayIcon->getProp(GSTI_PT_PREV);
	}

	// if it's first or last, move those pointers
	if (pFirst==pSysTrayIcon)
		pFirst = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT);
	else
		((PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_PREV))->setProp(GSTI_PT_NEXT, pSysTrayIcon->getProp(GSTI_PT_NEXT));

	if (pLast==pSysTrayIcon)
		pLast = (PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_PREV);
	else
		((PGRDSTICON)pSysTrayIcon->getProp(GSTI_PT_NEXT))->setProp(GSTI_PT_PREV, pSysTrayIcon->getProp(GSTI_PT_PREV));

	// remove the icon class
	delete pSysTrayIcon;

	if (!pFirst&&hideIfEmpty)
	{
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		if (autoSize)
			adjustSize();
		else
			InvalidateRect( hWnd, NULL, TRUE );
	}
	return TRUE;
}

grdSTIcon::grdSTIcon() {
	// nothing to do...
	//OutputDebugString("grdSTIcon created\n");
}

grdSTIcon::~grdSTIcon()
{
	propMap::iterator it = properties.begin();
	//OutputDebugString("grdSTIcon deleting\n");

	while ( it!=properties.end() )
  {
		delPropValue(it);
		it++;
	}
	properties.clear();
}
void grdSTIcon::addPropValue(propMap::iterator it, void *newValue)
{
	//OutputDebugString("grdSTIcon propertyValue adding\n");
	if (it->second)
		delPropValue(it);

	switch (it->first)
	{
		case GSTI_PT_ICON:
			it->second = (void *)CopyIcon( (HICON)newValue );
			break;

		case GSTI_PT_RGN:
			it->second = (void *)CreateRectRgn(0,0,0,0);
			CombineRgn( (HRGN)it->second, (HRGN)newValue, NULL, RGN_COPY );
			break;

		case GSTI_PT_TIP:
		case GSTI_PT_LBUTTONDOWN:
		case GSTI_PT_LBUTTONUP:
		case GSTI_PT_LBUTTONDBLCLK:
		case GSTI_PT_RBUTTONDOWN:
		case GSTI_PT_RBUTTONUP:
		case GSTI_PT_RBUTTONDBLCLK:
		case GSTI_PT_MBUTTONDOWN:
		case GSTI_PT_MBUTTONUP:
		case GSTI_PT_MBUTTONDBLCLK:
			it->second = (void *)new char[ strlen((char *)newValue) + 1 ];
			strcpy( (char *)it->second, (const char *)newValue );
			break;

		case GSTI_PT_RECT:
			it->second = (void *)new RECT;
			(*((RECT *)it->second)) = (*((RECT *)newValue));
			break;

		default:
			it->second = newValue;
			break;
	}
}

void grdSTIcon::delPropValue(propMap::iterator it)
{
	//OutputDebugString("grdSTIcon propertyValue deleting\n");
	if (it->second)
	{
		switch (it->first)
		{
			case GSTI_PT_ICON:
				DestroyIcon( (HICON)(it->second) );
				break;

			case GSTI_PT_RGN:
				DeleteObject( (HGDIOBJ)(it->second) );
				break;

			case GSTI_PT_TIP:
			case GSTI_PT_LBUTTONDOWN:
			case GSTI_PT_LBUTTONUP:
			case GSTI_PT_LBUTTONDBLCLK:
			case GSTI_PT_RBUTTONDOWN:
			case GSTI_PT_RBUTTONUP:
			case GSTI_PT_RBUTTONDBLCLK:
			case GSTI_PT_MBUTTONDOWN:
			case GSTI_PT_MBUTTONUP:
			case GSTI_PT_MBUTTONDBLCLK:
				delete[] (char *)(it->second);
				break;

			case GSTI_PT_RECT:
				delete (RECT *)(it->second);
				break;
		}
	}
	it->second = NULL;
}

void grdSTIcon::setProp(BYTE type, void *value)
{
	// search for an existant attribute
	propMap::iterator it = properties.find(type);

	//OutputDebugString("grdSTIcon property setting\n");

	// if it exists deallocate the current member
	if ( it==properties.end() )
	{
		if (value)
		{
			properties.insert(propMap::value_type(type, NULL));
			setProp(type,value);
		}
	}
	else
	{
		delPropValue(it);
		if (value)
			addPropValue(it, value);
		else
			properties.erase(it);
	}
}

void* grdSTIcon::getProp(BYTE type)
{
	// return value if it exists...
	propMap::iterator it = properties.find(type);

	//OutputDebugString("grdSTIcon property getting\n");
	
	if ( it!=properties.end() )
		return it->second;

	return NULL;
}