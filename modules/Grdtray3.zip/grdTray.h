#ifndef  __GRDSYSTRAY
#define  __GRDSYSTRAY

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#pragma warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include <stdlib.h>
#include <map>

//#include "grdShellTray.h"
#include "../ls-b24/lsapi/lsapi.h"
#include "../ls-b24/lsapi/lswinbase.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdSTIcon                                        * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the structure that is stored for every icon    * */
/* *  it's not a structure anymore, but a dynamic class      * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using namespace std;
typedef map<BYTE, void*> propMap;

// PROPERTY-TYPES SUPPORTED
#define GSTI_PT_HWND    0x01
#define GSTI_PT_ID      0x02
#define GSTI_PT_MSG     0x04
#define GSTI_PT_ICON    0x06
#define GSTI_PT_RGN     0x07
#define GSTI_PT_RECT    0x09
#define GSTI_PT_TIP     0x0b
#define GSTI_PT_TIPID   0x0c
#define GSTI_PT_PREV    0x0e
#define GSTI_PT_NEXT    0x0f

/* define the GSTI_PT_MOUSE? thingies using: */
/* (WM_MOUSE? & 0xff) | 0x10                 */
#define WM_TO_GSTI_PT(msg)    (msg & 0xff) | 0x10
#define GSTI_PT_LBUTTONDOWN   WM_TO_GSTI_PT(WM_LBUTTONDOWN)
#define GSTI_PT_LBUTTONUP     WM_TO_GSTI_PT(WM_LBUTTONUP)
#define GSTI_PT_LBUTTONDBLCLK WM_TO_GSTI_PT(WM_LBUTTONDBLCLK)
#define GSTI_PT_RBUTTONDOWN   WM_TO_GSTI_PT(WM_RBUTTONDOWN)
#define GSTI_PT_RBUTTONUP     WM_TO_GSTI_PT(WM_RBUTTONUP)
#define GSTI_PT_RBUTTONDBLCLK WM_TO_GSTI_PT(WM_RBUTTONDBLCLK)
#define GSTI_PT_MBUTTONDOWN   WM_TO_GSTI_PT(WM_MBUTTONDOWN)
#define GSTI_PT_MBUTTONUP     WM_TO_GSTI_PT(WM_MBUTTONUP)
#define GSTI_PT_MBUTTONDBLCLK WM_TO_GSTI_PT(WM_MBUTTONDBLCLK)

typedef class grdSTIcon {

	public:
		// create & destroy
		grdSTIcon();
		~grdSTIcon();

		// all properties have been removed and
		// replaced with these two functions
		void  setProp(BYTE type, void *value);
		void *getProp(BYTE type);

	private:
		// private property-management-routines
		void  addProp(BYTE type);
		void  addPropValue(propMap::iterator it, void *value);
		void  delPropValue(propMap::iterator it);

		// an stl::map that contains all the properties
		propMap properties;

} GRDSTICON, *PGRDSTICON;

// The LS NOTIFYICONDATA structure
typedef struct LSNOTIFYICONDATA
{
	DWORD cbSize;
	HWND hWnd;
	UINT uID;
	UINT uFlags;
	UINT uCallbackMessage;
	HICON hIcon;
	CHAR szTip[256];
	DWORD dwState;
}
LSNOTIFYICONDATA, *PLSNOTIFYICONDATA;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdTray                                          * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the main class, which does all the real work   * */
/* *  it initializes a couple of "sub-classes" that are      * */
/* *  that just to make it easier to understand and manage   * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class grdTray : public Window
{
private:
	// booleans
	BOOL onTop;
	BOOL hideIfEmpty;
	BOOL visible;
	BOOL inWharf;

	// tray
	int trayX;
	int trayY;
	int trayWidth;
	int trayHeight;

	// autosize
	BOOL autoSize;

	// borders
	int borderTop; 
	int borderLeft;
	int borderRight;
	int borderBottom;
	BOOL borderDrag;

	int snapDistance;

	// tray wrapping
	int direction;
	int wrapCount;
	int wrapDirection;

	// icon
	int iconSize;
	int iconSpacingX;
	int iconSpacingY;
	int deltaX;
	int deltaY;

	int firstX;
	int lastX;
	int firstY;
	int lastY;

	// icon effects
	COLORREF clrHue;
	UCHAR hueIntensity;
	UCHAR saturnation;
	UCHAR effectFlags;

	BOOL transpBack;
	HBITMAP hbmSkin;
	HBITMAP hbmBack;
	HRGN hrgnBack;
	BOOL skinTiled;
	BOOL transpSkin;

	COLORREF clrBack;
	COLORREF clrBorder;

	HWND liteStep;
	HWND desktop;
	HWND tooltip;

	UINT uLastID;

	PGRDSTICON pFirst;
	PGRDSTICON pLast;

	//grdShellTray *shellTray;

public:
  grdTray(HWND parentWnd, int& code);
  ~grdTray();

	// bang handlers
	void hide();
	void show();
	void toggle();
	void toggleOnTop();
	void move(int x, int y);
	void size(int cx, int cy);

	void iconAddBang(char *args);
	void iconDelBang(int n);

private:
	void paintBackground( HDC hdcDst, HRGN hrgnDst );
	void createBackground();
	void setFirstLast();
	void adjustSize();

	int copyBlt(HDC hdcDst, int xDst, int yDt, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc);
	int sizeBlt(HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc);

	/* *** * LIST MANAGEMENT FUNCTIONS * *** */
	PGRDSTICON iconListFind(HWND hWnd, UINT uID);
	PGRDSTICON iconListFindPt(POINT pt);
	//int iconListSave(void *dst);
	//int iconListLoad(void *src);
	//int iconListLoadMaduin();
	int iconListLoadRC();
	void iconListCleanup();
	BOOL iconListDelAll();
	void iconListPaint(HDC hdcDest, HRGN hrgnDest);

	/* *** * ICON MANAGEMENT FUNCTIONS * *** */
	PGRDSTICON iconAdd(PLSNOTIFYICONDATA pnid);
	PGRDSTICON iconAddRC(char *config);
	BOOL       iconDel(PLSNOTIFYICONDATA pnid);
	BOOL       iconDelGRD(PGRDSTICON pSysTrayIcon);
	PGRDSTICON iconMod(PLSNOTIFYICONDATA pnid);

	void       setIcon(PGRDSTICON pSysTrayIcon, HICON hIcon);
	void       setToolTip(PGRDSTICON pSysTrayIcon, char *tooltip);
	void       adjustRect(PGRDSTICON pSysTrayIcon);

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onDisplayChange(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onKeyMessage(Message& message);
  void onMouse(Message& message);
	BOOL onMouseIcon(Message& message);
  void onPaint(Message& message);
  void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	//void onRestoreTray(Message& message);
	//void onSaveTray(Message& message);
	void onSysTray(Message& message);
	void onWindowPosChanged(Message& message);
	void onWindowPosChanging(Message& message);
};

void bangHide( HWND sender, LPCSTR args );
void bangShow( HWND sender, LPCSTR args );
void bangToggle( HWND sender, LPCSTR args );
void bangOnTop( HWND sender, LPCSTR args );
void bangMove( HWND sender, LPCSTR args );
void bangSize( HWND sender, LPCSTR args );
void bangAdd( HWND sender, LPCSTR args );
void bangDel( HWND sender, LPCSTR args );

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif// __GRDSYSTRAY