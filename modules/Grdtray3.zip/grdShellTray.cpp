#include "grdShellTray.h"

// don't know the purpose of this one...
#define MAGICDWORD         0x49474541

// pass message structure
typedef struct SHELLTRAYDATA {
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
} SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;


// this is the version of NOTIFYICONDATA that shell32.dll v5 uses
typedef struct _NOTIFYICONDATAV5 { 
    DWORD cbSize; 
    HWND hWnd; 
    UINT uID; 
    UINT uFlags; 
    UINT uCallbackMessage; 
    HICON hIcon; 
    WCHAR szTip[128];
    DWORD dwState; 
    DWORD dwStateMask;
    WCHAR szInfo[256];
    union {
        UINT  uTimeout;
        UINT  uVersion;
    } DUMMYUNIONNAME;
    WCHAR szInfoTitle[64];
    DWORD dwInfoFlags;
} NOTIFYICONDATAV5, *PNOTIFYICONDATAV5; 


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: grdShellTray()                                * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:
/* *                                                         * */
/* *   HWND hTray                                            * */
/* *   the "parent" tray window                              * */
/* *                                                         * */
/* *   HINSTANCE dll                                         * */
/* *   the current instance                                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: initialize the shellTray class                 * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdShellTray::grdShellTray (HWND lswnd) {

	// temporary variables
	WNDCLASSEX wc;

	/* *************************************** */
	/* *     STORE THE INFORMATION PASSED    * */
	/* *************************************** */

	hLiteStep = lswnd;

	
	/* *************************************** */
	/* *     REGISTER THE SHELLTRAY CLASS    * */
	/* *************************************** */
	
   	memset(&wc,0,sizeof(wc));

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS ;
	wc.lpfnWndProc = (WNDPROC) grdShellTray::WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 4;
	wc.hInstance = 0;
	wc.lpszClassName = WC_SHELLTRAY;
		
   	if (!::RegisterClassEx(&wc))
 		::MessageBox( hLiteStep, "Error registering window class", WC_SHELLTRAY, MB_OK );
		

	/* *************************************** */
	/* *     CREATE THE SHELLTRAY WINDOW     * */
	/* *************************************** */
	
	hShellTray = ::CreateWindowEx( WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
								   WC_SHELLTRAY,
								   TEXT("grdSysTrayManager"),
								   WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
								   0,0,
								   10,10,
								   hLiteStep,
								   NULL,
								   (HINSTANCE)0,
								   NULL );

	if ( !hShellTray )
		::MessageBox( hLiteStep,"Error creating window", WC_SHELLTRAY, MB_OK);


	/* *************************************** */
	/* *      ADJUST THE SYSTRAY WINDOW      * */
	/* *************************************** */
	
	// set the magicDWord
	::SetWindowLong( hShellTray, GWL_USERDATA, (LONG)MAGICDWORD );

	// save the class handle as a window long
	::SetWindowLong( hShellTray, 0, (LONG)this );
	
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: ~grdShellTray()                               * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: destroy the shellTray class                    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

grdShellTray::~grdShellTray ( ) {

	// the window could be deleted
	::DestroyWindow( hShellTray );

	// the class could be unregistered
	::UnregisterClass( WC_SHELLTRAY, 0 );

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WndProc()                             * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: forward the window's messages                  * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

LRESULT CALLBACK grdShellTray::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {	

	grdShellTray *theShellTray = (grdShellTray*)::GetWindowLong(hwnd, 0);
	
	if (theShellTray)
		return theShellTray->WindowProc(hwnd, message, wParam, lParam);

	else 
        return DefWindowProc(hwnd, message, wParam, lParam);

}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * FUNCTION: LRESULT WindowProc()                          * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PARAMETERS:                                             * */
/* *                                                         * */
/* *   HWND hWnd                                             * */
/* *   a handle to a window which this function handles      * */
/* *                                                         * */
/* *   UINT nMessage                                         * */
/* *   the message sent to the window                        * */
/* *                                                         * */
/* *   WPARAM wParam                                         * */
/* *   the WPARAM of this message                            * */
/* *                                                         * */
/* *   LPARAM lParam                                         * */
/* *   the LPARAM of this message                            * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* * PURPOSE: handle the window's messages                   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

LRESULT grdShellTray::WindowProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam ) {

	switch( nMessage )
	{

		case WM_COPYDATA:
		{

			// odd conversion... don't know about this...
			PNOTIFYICONDATA pnid = NULL;
			PNOTIFYICONDATAV5 pnid5 = NULL;

			PCOPYDATASTRUCT pcds;
			PSHELLTRAYDATA pstd;

			BOOL result = FALSE;
			
			pcds = (PCOPYDATASTRUCT) lParam;
			
			if( pcds->dwData != 1 )
				return FALSE;
			
			pstd = (PSHELLTRAYDATA) pcds->lpData;

			if ( pstd->nid.cbSize == sizeof( NOTIFYICONDATAV5 ) ) {

				pnid5 = (PNOTIFYICONDATAV5)&pstd->nid;
				pnid = (PNOTIFYICONDATA)new BYTE[sizeof(NOTIFYICONDATA)];

				pnid->cbSize		   = sizeof(NOTIFYICONDATA);
				pnid->hWnd			   = pnid5->hWnd;
				pnid->uID			   = pnid5->uID;
				pnid->uFlags		   = pnid5->uFlags;
				pnid->uCallbackMessage = pnid5->uCallbackMessage;
				pnid->hIcon			   = pnid5->hIcon;
				pnid->szTip[0]		   = '\0';

				if ( pnid5->szTip == NULL )
					pnid->szTip[0] = '\0';
				else {

					UINT nChars = min( ( wcslen( pnid5->szTip ) + 1 ), 64 );

					::WideCharToMultiByte(CP_ACP, 0, pnid5->szTip, nChars, (char *)&pnid->szTip, nChars, NULL, NULL);

					// just to ensure last character is a NULL... :P
					pnid->szTip[63] = '\0';

				}

				result = (BOOL)::SendMessage( hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM)pnid );

				delete[] pnid;

			} else {

				result = (BOOL)::SendMessage( hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM)&pstd->nid );

			}

			return result;

		}
		
	}
	
	return ::DefWindowProc( hWnd, nMessage, wParam, lParam );
}

