DeskFolders 2.0 beta 3
---

Author: Maduin <maduin@dasoft.org>
Date: 04 May 1999
URL: http://maduin.dasoft.org/deskfolders

This archive contains the binary distribution of DeskFolders 2,
a desktop module for the Litestep shell. Documentation and
other distributions (if available) can be found at the DeskFolders
homepage: http://maduin.dasoft.org/deskfolders.

Note that this is beta software, there are bugs. Some I'm aware
of, some I'm not. If you find a bug please send me an email at
maduin@dasoft.org. Describe the bug and list your versions of
Windows, Litestep, and Internet Explorer (if installed).

A note about transparency problems. Some people experience
transparency problems with DeskFolders 2 in which the background
is corrupted. As of beta 3 there is now an option to enable
a hack to workaround this. Adding a "DeskFolderPaintHack" item
to your step.rc will cause DeskFolders to use an alternate method
for transparency. This will (should) fix transparency but adds a
problem of it's own: if a window is on top of a desk folder when
DeskFolders is loaded or recycled that window become a part of
the desk folder's background. I'm working to try and find a more
effective workaround, until then I hope this is sufficient.
