#define WIN32_LEAN_AND_MEAN
#define WM_NET  WM_USER+0x100+5
#define WM_NET2 WM_USER+0x200+5
#include<windows.h>
#include<windowsx.h>
#include<winsock.h>
#include<ras.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include"resource.h"
#define ID_CONNECTBTN 434
#define ID_DISCONBTN 435
#define ID_SERVERADDY 444
#define ID_SERVERPORT 445
#define ID_RECVEDIT 446
#define ID_SENDEDIT 447
void WriteStr(HWND hwnd, char* Str);
void WSAError(HWND hwnd, const char* pError);
void StartConServer();
char* SocketErrorDesc(const int Error);
int IsStr(const char* Str1, const char* Str2);
int InStr(const char* Str1, const char* Str2, const int Start);
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow);
LRESULT CALLBACK WndProc(HWND hwnd,UINT Message,WPARAM wParam,LPARAM lParam);
LRESULT CALLBACK SendEditWndProc(HWND Se_hwnd, UINT Se_Message, WPARAM Se_wParam, LPARAM Se_lParam);
LRESULT CALLBACK RecvEditWndProc(HWND Re_hwnd, UINT Re_Message, WPARAM Re_wParam, LPARAM Re_lParam);
LRESULT CALLBACK AddyEditWndProc(HWND Ae_hwnd, UINT Ae_Message, WPARAM Ae_wParam, LPARAM Ae_lParam);
LRESULT CALLBACK PortEditWndProc(HWND Pe_hwnd, UINT Pe_Message, WPARAM Pe_wParam, LPARAM Pe_lParam);
LRESULT CALLBACK ConnectBtnWndProc(HWND Ce_hwnd, UINT Ce_Message, WPARAM Ce_wParam, LPARAM Ce_lParam);
LRESULT CALLBACK DisConBtnWndProc(HWND De_hwnd, UINT De_Message, WPARAM De_wParam, LPARAM De_lParam);
long OldRecvEditWndProc,OldSendEditWndProc,OldAddyEditWndProc,OldPortEditWndProc,OldConnectBtnWndProc,OldDisConBtnWndProc;
HWND MainHwnd,ServerAddyEdit,ServerPortAddy,RecvEdit,SendEdit,StatusEdit,SetupBtn,ConnectBtn,DisconnectBtn,ExitBtn;
LPCTSTR NasComClassName,NasComAppName;
HINSTANCE G_Hinst;
int S_AppWidth,S_AppHeight,G_AppWidth,G_AppHeight;
int CanWrite;
RECT WorkAreaR;
HICON MainIcon;
WINDOWPOS* wp;
WSADATA wsaData;
SOCKET sClient=INVALID_SOCKET,sListen=INVALID_SOCKET;
const int MaxBufLen=2048;
int nRet=0;
long lMsgs;
SOCKADDR_IN LocalAddr,RemoteAddr;
SOCKADDR_IN ConLocalAddr,ConRemoteAddr;
SOCKET ConRxSock,ConTxSock;
char UserID[256] = "Nasiry",SystemID[256] = "Unix";
int ConPort = 12000;
char serverS[512],portS[7];
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
	{
	MainIcon = LoadIcon(NULL,(char*)IDI_ICON1);
	NasComClassName = "Nasiry's Communication 1.0";
	NasComAppName = "NasCom 1.0 (Beta)";
	WNDCLASSEX WndClass;
	MSG Msg;
	WndClass.cbSize 	   = sizeof(WNDCLASSEX);
	WndClass.style		   = CS_HREDRAW | CS_VREDRAW ;;
	WndClass.lpfnWndProc   = WndProc;
	WndClass.cbClsExtra    = NULL;
	WndClass.cbWndExtra    = NULL;
	WndClass.hInstance	   = G_Hinst;
	WndClass.hIcon		   = LoadIcon(G_Hinst,"IDI_ICON1");
	WndClass.hCursor	   = NULL;
	WndClass.hbrBackground = CreateSolidBrush(RGB(25,20,50));;
	WndClass.lpszMenuName  = NULL;
	WndClass.lpszClassName = NasComClassName;
	WndClass.hIconSm	   = LoadIcon(G_Hinst,"IDI_ICON1");	
	if(!RegisterClassEx(&WndClass))
		{
		MessageBox(0,"Window Registration Failed!","Error!",
			MB_ICONEXCLAMATION|MB_OK|MB_SYSTEMMODAL);
		return 0;
		}
	SystemParametersInfo(SPI_GETWORKAREA,NULL,&WorkAreaR,NULL);
	S_AppWidth = WorkAreaR.right - WorkAreaR.left;
	S_AppHeight = WorkAreaR.bottom - WorkAreaR.top;
	G_AppWidth = 400;
	G_AppHeight = 350;
	MainHwnd = CreateWindowEx(WS_EX_ACCEPTFILES|WS_EX_WINDOWEDGE ,NasComClassName,NasComAppName,WS_OVERLAPPEDWINDOW,(S_AppWidth-500)/2,(S_AppHeight-350)/2,600,260,NULL,NULL,G_Hinst,NULL);
	// use lensmoor.org for MUD
	ServerAddyEdit = CreateWindowEx(NULL,"EDIT","irc.mcs.net",WS_CHILD|WS_VISIBLE,1,0,300,15,MainHwnd,(HMENU)ID_SERVERADDY,G_Hinst,NULL);
	// use 3500 for lensmoor.org
	ServerPortAddy = CreateWindowEx(NULL,"EDIT","6667",WS_CHILD|WS_VISIBLE,302,0,50,15,MainHwnd,(HMENU)ID_SERVERPORT,G_Hinst,NULL);
	RecvEdit = CreateWindowEx(WS_EX_LEFTSCROLLBAR,"EDIT","Welcome to Nasiry's Communication",WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_WANTRETURN|ES_LEFT | ES_MULTILINE | ES_AUTOVSCROLL, 1,16,551,200,MainHwnd,(HMENU)ID_RECVEDIT,G_Hinst,NULL);
	SendEdit = CreateWindowEx(WS_EX_ACCEPTFILES,"EDIT","",WS_CHILD|WS_VISIBLE, 1,217,551,15,MainHwnd,(HMENU)ID_SENDEDIT,G_Hinst,NULL);
	OldSendEditWndProc = SetWindowLong(SendEdit, GWL_WNDPROC, (long)SendEditWndProc);
	OldRecvEditWndProc = SetWindowLong(RecvEdit,GWL_WNDPROC, (long)RecvEditWndProc);
	OldAddyEditWndProc = SetWindowLong(ServerAddyEdit,GWL_WNDPROC,(long)AddyEditWndProc);
	OldPortEditWndProc = SetWindowLong(ServerPortAddy,GWL_WNDPROC,(long)PortEditWndProc);
	ConnectBtn = CreateWindowEx(NULL,"Button","Connect",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT ,354, 1,78,16,MainHwnd,(HMENU)ID_CONNECTBTN,(HINSTANCE) GetWindowLong(MainHwnd, GWL_HINSTANCE),NULL);
	DisconnectBtn = CreateWindowEx(NULL,"Button","DisCon",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_FLAT ,440,1,78,16,MainHwnd,(HMENU)ID_DISCONBTN,G_Hinst,NULL);
	OldConnectBtnWndProc = SetWindowLong(ConnectBtn,GWL_WNDPROC,(long)ConnectBtnWndProc);
	OldDisConBtnWndProc = SetWindowLong(DisconnectBtn,GWL_WNDPROC,(long)DisConBtnWndProc);
	CreateEvent(NULL,FALSE,1,"RecvPoll");
	if(MainHwnd == NULL)
		{
		MessageBox(0,"Window Creation Failed!","Error!",
			MB_ICONEXCLAMATION|MB_OK|MB_SYSTEMMODAL);
		return 0;
		}
	ShowWindow(MainHwnd,SW_SHOWNA);
	UpdateWindow(MainHwnd);
	while(GetMessage(&Msg,NULL,0,0))
		{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
		}
	return Msg.wParam;
	}
void StartConServer()
	{
	int AddrLen=sizeof(SOCKADDR);
	ConTxSock=socket(AF_INET, SOCK_STREAM, 0);
	if(ConTxSock == INVALID_SOCKET)
		{
        WSAError(0, SocketErrorDesc(WSAGetLastError()));
        DestroyWindow(MainHwnd); //exit program
		}
	ConLocalAddr.sin_family=PF_INET;
	//server listens on port 5555
	ConLocalAddr.sin_port=htons(ConPort);
	
	//bind socket to address
	nRet=bind(ConRxSock, (PSOCKADDR)&ConLocalAddr, AddrLen);
	if(nRet == SOCKET_ERROR)
		{
        WSAError(0, SocketErrorDesc(WSAGetLastError()));
        DestroyWindow(MainHwnd);
		}
	
	//server starts up - max 5 clients at the same time
	nRet=listen(ConTxSock, 5);
	if(nRet == SOCKET_ERROR)
		{
        WSAError(0, SocketErrorDesc(WSAGetLastError()));
        DestroyWindow(MainHwnd);
		}
	
	//sensitize socket to network events
	//(accept, close, receive and send events)
	nRet=WSAAsyncSelect(ConTxSock, MainHwnd, WM_NET2,
		FD_ACCEPT | FD_CLOSE | FD_READ | FD_WRITE);
	
	if(nRet == SOCKET_ERROR)
        WSAError(0, SocketErrorDesc(WSAGetLastError()));
	}
void WriteStr(HWND hwnd, char* Str)
	{
	SendMessage(hwnd, EM_REPLACESEL, 0, (LPARAM)(LPSTR)Str);
	SendMessage(hwnd,EM_SETSEL,-1,0);
	SendMessage(hwnd,EM_SCROLLCARET,0,0);
	}
int InStr(const char* Str1, const char* Str2, const int Start)
	{
	int nLen=strlen(Str2);
	int index =0;
	for(int i=0; i <= 0; i++)
		{
		index =i + Start;
		if(Str2[i] != Str1[i])
			return 0;
		}
	return 1;
	}
int IsStr(const char* Str1, const char* Str2)
	{
	int nLen=strlen(Str2);
	for(int i=0; i < nLen; i++)
		{
		if(*(Str1+i) != *(Str2+i))
			return 0;
		}
	return 1;
	}

void WSAError(HWND hwnd, const char* pError)
	{
	MessageBox(hwnd, pError, "Winsock Error", MB_ICONEXCLAMATION | MB_OK);
	}

char* SocketErrorDesc(const int Error)
	{
	switch(Error)
		{
		case WSAEINTR:
			return "Interrupted system call";
		case WSAEBADF:
			return "Bad file number";
		case WSAEACCES:
			return "Permission denied";
		case WSAEFAULT:
			return "Bad address";
		case WSAEINVAL:
			return "Invalid argument";
		case WSAEMFILE:
			return "Too many open files";
		case WSAEWOULDBLOCK:
			return "Operation would block";
		case WSAEINPROGRESS:
			return "Operation now in progress";
		case WSAEALREADY:
			return "Operation already in progress";
		case WSAENOTSOCK:
			return "Socket operation on non-socket";
		case WSAEDESTADDRREQ:
			return "Destination address required";
		case WSAEMSGSIZE:
			return "Message too long";
		case WSAEPROTOTYPE:
			return "Protocol wrong type for socket";
		case WSAENOPROTOOPT:
			return "Protocol not available";
		case WSAEPROTONOSUPPORT:
			return "Protocol not supported";
		case WSAESOCKTNOSUPPORT:
			return "Socket type not supported";
		case WSAEOPNOTSUPP:
			return "Operation not supported on socket";
		case WSAEPFNOSUPPORT:
			return "Protocol family not supported";
		case WSAEAFNOSUPPORT:
			return "Address family not supported by protocol family";
		case WSAEADDRINUSE:
			return "Address already in use";
		case WSAEADDRNOTAVAIL:
			return "Can""t assign requested address";
		case WSAENETDOWN:
			return "Network is down";
		case WSAENETUNREACH:
			return "Network is unreachable";
		case WSAENETRESET:
			return "Network dropped connection on reset";
		case WSAECONNABORTED:
			return "Software caused connection abort";
		case WSAECONNRESET:
			return "Connection reset by peer";
		case WSAENOBUFS:
			return "No buffer space available";
		case WSAEISCONN:
			return "Socket is already connected";
		case WSAENOTCONN:
			return "Socket is not connected";
		case WSAESHUTDOWN:
			return "Can""t send after socket shutdown";
		case WSAETOOMANYREFS:
			return "Too many references: can""t splice";
		case WSAETIMEDOUT:
			return "Connection timed out";
		case WSAECONNREFUSED:
			return "Connection refused";
		case WSAELOOP:
			return "Too many levels of symbolic links";
		case WSAENAMETOOLONG:
			return "File name too long";
		case WSAEHOSTDOWN:
			return "Host is down";
		case WSAEHOSTUNREACH:
			return "No route to host";
		case WSAENOTEMPTY:
			return "Directory not empty";
		case WSAEPROCLIM:
			return "Too many processes";
		case WSAEUSERS:
			return "Too many users";
		case WSAEDQUOT:
			return "Disc quota exceeded";
		case WSAESTALE:
			return "Stale NFS file handle";
		case WSAEREMOTE:
			return "Too many levels of remote in path";
		case WSASYSNOTREADY:
			return "Network sub-system is unusable";
		case WSAVERNOTSUPPORTED:
			return "WinSock DLL cannot support this application";
		case WSANOTINITIALISED:
			return "WinSock not initialized";
		case WSAHOST_NOT_FOUND:
			return "Host not found";
		case WSATRY_AGAIN:
			return "Non-authoritative host not found";
		case WSANO_RECOVERY:
			return "Non-recoverable error";
		case WSANO_DATA:
			return "No Data";
		default:
			return "Not a WinSock error";
  }
  return 0;
}
LRESULT CALLBACK WndProc(HWND MainHwnd,UINT Message,WPARAM wParam,LPARAM lParam)
	{
	int AddrLen=sizeof(SOCKADDR);
	HBRUSH hBrush;
	//int temp=2;
	//char *temp2="";
	switch(Message)
		{
		case WM_CREATE:
			{
			//temp = InStr("irc",":irc.mcs.net 343",1);
			//itoa(nRet,temp,10);
			//itoa(temp,temp2,10);
			//MessageBox(0,temp2,"Result is...",0);
			//SwitchToThisWindow();
			nRet=WSAStartup(MAKEWORD(1,1),&wsaData);
			if(nRet)
				{
				WSAError(MainHwnd, SocketErrorDesc(WSAGetLastError()));
				DestroyWindow(MainHwnd);
				}
			if((LOBYTE(wsaData.wVersion) != 1) || (HIBYTE(wsaData.wVersion) != 1))
				{
				MessageBox(MainHwnd,"Winsock version not suitable","Winsock Error",MB_OK|MB_ICONEXCLAMATION);
				DestroyWindow(MainHwnd);
				}
			sClient=socket(PF_INET,SOCK_STREAM,0);
			if(sClient == INVALID_SOCKET)
				{
				WSAError(MainHwnd, SocketErrorDesc(WSAGetLastError()));
				DestroyWindow(MainHwnd);
				}
			lMsgs=FD_READ|FD_WRITE|FD_CONNECT|FD_CLOSE|FD_ACCEPT|FD_OOB;
			nRet=WSAAsyncSelect(sClient,MainHwnd,WM_NET,lMsgs);
			//nRet=WSAEventSelect(sClient,,lMsgs
			if(nRet == SOCKET_ERROR)
				WSAError(MainHwnd,SocketErrorDesc(WSAGetLastError()));
			}
			break;
		case WM_CTLCOLORBTN:
			{
			if((HWND)lParam == ConnectBtn)
				{
				SetBkMode((HDC) wParam, TRANSPARENT) ;//sets background color for push and check box buttons
				hBrush =CreateSolidBrush( RGB(0,200,200) ); 
				SelectObject( (HDC)wParam, hBrush );
				return((LONG)hBrush);
				}
			}
			break;
		case WM_CTLCOLOREDIT:
			{
			if((HWND) lParam == RecvEdit)
				{
				hBrush=CreateSolidBrush( RGB(20,0,90) );
				SetBkColor( (HDC)wParam, RGB(20,0,90) );
				SetTextColor((HDC)wParam,RGB(0,255,255));
				SelectObject( (HDC)wParam, hBrush );
				return((LONG)hBrush);
				}
			if((HWND)lParam == SendEdit)
				{
				hBrush=CreateSolidBrush(RGB(0,0,0));
				SetBkColor((HDC)wParam,RGB(0,0,0));
				SetTextColor((HDC)wParam,RGB(0,255,0));
				SelectObject((HDC)wParam,hBrush);
				return((LONG)hBrush);
				}
			if((HWND)lParam == ServerAddyEdit)
				{
				hBrush=CreateSolidBrush(RGB(50,50,50));
				SetBkColor((HDC)wParam,RGB(50,50,50));
				SetTextColor((HDC)wParam,RGB(100,200,150));
				SelectObject((HDC)wParam,hBrush);
				return((LONG)hBrush);
				}
			if((HWND)lParam == ServerPortAddy)
				{
				hBrush=CreateSolidBrush(RGB(0,0,0));
				SetBkColor((HDC)wParam,RGB(0,0,0));
				SetTextColor((HDC)wParam,RGB(150,0,250));
				SelectObject((HDC)wParam,hBrush);
				return((LONG)hBrush);
				}
			}
			break;
		case WM_COMMAND:
			{
			switch (LOWORD(wParam))
				{
				case ID_DISCONBTN:
					{
					shutdown(sClient,1);
					closesocket(sClient);
					sClient=INVALID_SOCKET;
					SetWindowText(RecvEdit,"");
					SetFocus(ConnectBtn);
					}
					break;
				case ID_CONNECTBTN:
					{
					sClient=socket(PF_INET,SOCK_STREAM,0);
					nRet=WSAAsyncSelect(sClient,MainHwnd,WM_NET,lMsgs);
					IN_ADDR		iaHost;
					LPHOSTENT	lpHostEntry;
					int port;
					GetWindowText(ServerPortAddy,portS,7);
					port = atoi( portS );
					GetWindowText(ServerAddyEdit,serverS,512);
					iaHost.s_addr = inet_addr(serverS);
					if (iaHost.s_addr == INADDR_NONE)
						{
						// Wasn't an IP address string, assume it is a name
						lpHostEntry = gethostbyname(serverS);
						}
					else
						{
						// It was a valid IP address string
						lpHostEntry = gethostbyaddr((const char *)&iaHost, 
							sizeof(struct in_addr), AF_INET);
						}
					if (lpHostEntry == NULL)
						{
						MessageBox(MainHwnd,"gethostbyname()","Error",0);
						break;
						}
					RemoteAddr.sin_family=AF_INET;
					//RemoteAddr.sin_addr.s_addr=inet_addr("204.57.55.39");
					RemoteAddr.sin_addr = *((LPIN_ADDR)*lpHostEntry->h_addr_list);
					RemoteAddr.sin_port=htons(port);          
					nRet=connect(sClient, (PSOCKADDR)&RemoteAddr, AddrLen);
					if(nRet == SOCKET_ERROR)
						{
						int WSAErr=WSAGetLastError();
						if(WSAErr != WSAEWOULDBLOCK)
							WSAError(MainHwnd, SocketErrorDesc(WSAGetLastError()));
						}
					SetFocus(SendEdit);
					}
					break;
				}
			}
			break;
		case WM_NET:
			{
			char SendBuffSecMain[MaxBufLen]="";
			//unsigned WSAEvent=WSAGETSELECTEVENT(lParam);
			switch(LOWORD(lParam))
				{
				case FD_CONNECT:
					{
					//User information
					char UserEmail[100] = "adamfoster@mail.com";
					char UserRealName[25] = "Adam Foster";
					char UserNickName[9] = "Nasiry";
					//Resetcontrols and display connection text
					SetWindowText(RecvEdit,"");
					SetWindowText(SendEdit,"");
					WriteStr(RecvEdit,"Connected...\r\n");
					//Start Login Process
					//Send desired NICK for IRC
					strcpy(SendBuffSecMain,"NICK ");
					strcat(SendBuffSecMain,UserNickName);
					strcat(SendBuffSecMain,"\r\n");
					nRet=send(sClient, SendBuffSecMain, strlen(SendBuffSecMain), 0);
					//Send USER information (aka Registration)
					SendBuffSecMain[MaxBufLen] = 0;
					strcpy(SendBuffSecMain,"USER");
					strcat(SendBuffSecMain," ");
					strcat(SendBuffSecMain,UserEmail);
					strcat(SendBuffSecMain," ");
					strcat(SendBuffSecMain,UserNickName);
					strcat(SendBuffSecMain," ");
					strcat(SendBuffSecMain,serverS);
					strcat(SendBuffSecMain," :");
					strcat(SendBuffSecMain,UserNickName);
					strcat(SendBuffSecMain,"\r\n");
					nRet=send(sClient, SendBuffSecMain,strlen(SendBuffSecMain),0);
					}
					break;					
				case FD_READ:
					{
					char pBuf[MaxBufLen]="";
					char *PingPongString= "PONG :";
					nRet=recv(sClient,pBuf,MaxBufLen,0);
					//begin process of fixing reversed "\r\n" from servers.
					int pBufLenC=0,Cindex=0,writepong=0;;
					pBufLenC = strlen(pBuf);
					while(Cindex <= pBufLenC)
						{
						if(pBuf[Cindex] == 0x0A && pBuf[Cindex+1] == 0x0D)
							{
							pBuf[Cindex] = 0x0D;
							pBuf[Cindex+1] = 0x0A;
							}
						if( pBuf[Cindex] == 'P' && pBuf[Cindex+1] == 'I' &&
							pBuf[Cindex+2] == 'N' && pBuf[Cindex+3] == 'G' &&
							pBuf[Cindex+4] == ' ' && pBuf[Cindex+5] == ':')
							{
							writepong = 1;
							
							}
						Cindex++;
						}
					//end this process
					WriteStr(RecvEdit, ">> ");
					WriteStr(RecvEdit, pBuf);
					if(writepong == 1)
						{
						SendBuffSecMain[MaxBufLen] = 0;
						strcat(PingPongString,serverS);
						nRet=send(sClient,PingPongString,strlen(PingPongString),0);
						WriteStr(RecvEdit,"PING? PONG!\r\n");
						writepong = 0;
						}
					}
					break;
				case FD_WRITE:
					{
					}
					break;
				case FD_CLOSE:
					{
					shutdown(sClient,1);
					closesocket(sClient);
					sClient=INVALID_SOCKET;
					}
					break;
				default:
					break;
				}
			return TRUE;
			}
			/*case WM_MOUSEMOVE:
			{
			int fwKeys = wParam;        // key flags 
			int xPos = LOWORD(lParam);  // horizontal position of cursor 
			int yPos = HIWORD(lParam);  // vertical position of cursor
			}
			break;*/
				case WM_SIZE: 
					{ 
					int nWidth = LOWORD(lParam);  // width of client area 
					int nHeight = HIWORD(lParam); // height of client area 
					MoveWindow(RecvEdit,0,17,nWidth,nHeight - 17 - 16,TRUE);
					MoveWindow(SendEdit,0,nHeight - 16,nWidth,15,TRUE);
					}
					break;
				case WM_WINDOWPOSCHANGING:
					{
					wp = (WINDOWPOS*)lParam;
					SystemParametersInfo(SPI_GETWORKAREA,NULL,&WorkAreaR,NULL);
					int ScreenX,ScreenY,SnapEdge;
					SnapEdge = 20;
					ScreenX = WorkAreaR.right - WorkAreaR.left;
					ScreenY = WorkAreaR.bottom - WorkAreaR.top;
					if(wp->x < SnapEdge && wp->x > - SnapEdge)
						wp->x = 0;
					if(wp->x + G_AppWidth > (ScreenX - SnapEdge) && wp->x + G_AppWidth < ScreenX + SnapEdge)
						wp->x = ScreenX - G_AppWidth;
					if(wp->y < SnapEdge && wp->y > - SnapEdge)
						wp->y = 0;
					if(wp->y + G_AppHeight > (ScreenY - SnapEdge) && wp->y + G_AppHeight < ScreenY + SnapEdge)
						wp->y = ScreenY - G_AppHeight;
					}
					break;
				case WM_CLOSE:
					{
					DestroyWindow(MainHwnd);
					}
					break;
				case WM_DESTROY:
					{
					if(sClient != INVALID_SOCKET)
						{
						shutdown(sClient,1);
						closesocket(sClient);
						}  
					WSACleanup();
					PostQuitMessage(0);
					}
					break; 
				default:
					return DefWindowProc(MainHwnd, Message, wParam, lParam);
	}
	return 0;
}
LRESULT CALLBACK SendEditWndProc(HWND Se_hwnd, UINT Se_Message, WPARAM Se_wParam, LPARAM Se_lParam)
	{
	char SendBuffMain[MaxBufLen]="";
	char *temp=0,*temp2=0;
	switch(Se_Message)
		{
		case WM_CHAR:
			{
			switch (Se_wParam) 
				{ 
				case 0x08:// Process a backspace. 
					break; 
				case 0x0A:// Process a linefeed. 
					break; 
				case 0x1B:// Process an escape. 
					break; 
				case 0x09:// Process a tab.
					SetFocus(ServerAddyEdit);
					break; 
				case 0x0D:// Process a carriage return.
					GetWindowText(SendEdit,SendBuffMain,2048);
					strcat(SendBuffMain,"\r\n");
					nRet=send(sClient, SendBuffMain, strlen(SendBuffMain), 0);
					SetWindowText(SendEdit,"");
					WriteStr(RecvEdit,SendBuffMain);
					SetFocus(SendEdit);
					break; 
				default:// Process displayable characters. 
					break;
				}
			}
			break;
		}
	return CallWindowProc((WNDPROC)OldSendEditWndProc, Se_hwnd, Se_Message, Se_wParam, Se_lParam);
	}
LRESULT CALLBACK RecvEditWndProc(HWND Re_hwnd, UINT Re_Message, WPARAM Re_wParam, LPARAM Re_lParam)
	{
	switch(Re_Message)
		{
		case WM_CHAR:
			return CallWindowProc((WNDPROC)OldRecvEditWndProc,Re_hwnd,Re_Message,Re_wParam,Re_lParam);
		default:
			return CallWindowProc((WNDPROC)OldRecvEditWndProc,Re_hwnd,Re_Message,Re_wParam,Re_lParam);
		}
	}
LRESULT CALLBACK AddyEditWndProc(HWND Ae_hwnd, UINT Ae_Message, WPARAM Ae_wParam, LPARAM Ae_lParam)
	{
	switch(Ae_Message)
		{
		case WM_CHAR:
			{
			switch(Ae_wParam)
				{
				case 0x09:
					SetFocus(ServerPortAddy);
					break;
				default:
					break;
				}
			}
			break;
		}
	return CallWindowProc((WNDPROC)OldAddyEditWndProc,Ae_hwnd,Ae_Message,Ae_wParam,Ae_lParam);
	}
LRESULT CALLBACK PortEditWndProc(HWND Pe_hwnd, UINT Pe_Message, WPARAM Pe_wParam, LPARAM Pe_lParam)
	{
	switch(Pe_Message)
		{
		case WM_CHAR:
			{
			switch(Pe_wParam)
				{
				case 0x09:
					SetFocus(ConnectBtn);
					break;
				default:
					break;
				}
			}
			break;
		}
	return CallWindowProc((WNDPROC)OldPortEditWndProc,Pe_hwnd,Pe_Message,Pe_wParam,Pe_lParam);
	}
LRESULT CALLBACK ConnectBtnWndProc(HWND Ce_hwnd, UINT Ce_Message, WPARAM Ce_wParam, LPARAM Ce_lParam)
	{
	switch(Ce_Message)
		{
		case WM_CHAR:
			{
			switch(Ce_wParam)
				{
				case 0x09:
					SetFocus(DisconnectBtn);
					break;
				default:
					break;
				}
			}
			break;
		}
	return CallWindowProc((WNDPROC)OldConnectBtnWndProc,Ce_hwnd,Ce_Message,Ce_wParam,Ce_lParam);
	}
LRESULT CALLBACK DisConBtnWndProc(HWND De_hwnd, UINT De_Message, WPARAM De_wParam, LPARAM De_lParam)
	{
	switch(De_Message)
		{
		case WM_CHAR:
			{
			switch(De_wParam)
				{
				case 0x09:
					SetFocus(SendEdit);
					break;
				default:
					break;
				}
			}
			break;
		}
	return CallWindowProc((WNDPROC)OldDisConBtnWndProc,De_hwnd,De_Message,De_wParam,De_lParam);
	}