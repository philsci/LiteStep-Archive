#ifndef NasLibH
#define NasLibH
//writes string Str to window hwnd
//(assumes that hwnd is a text box handle)
void WriteStr(HWND hwnd, char *Str);

//checks if Str1 and Str2 are identical
//(Str1 is checked against Str2)
int IsStr(const char* Str1, const char* Str2);

//displays an winsock error message
void WSAError(HWND hwnd, const char* pError);

//returns a string containing winsock error message
//corresponding to winsock error code
char* SocketErrorDesc(const int Error);

#endif