OK, this is a small addition to GeekAmp, that I made because it irritated me
(and others) that the geekamp commands !amp_power and !amp_play starts winamp
minimized (and unmaximizable). So I added two band-commands:
!amp_power2 and !amp_play2. These two starts winamp in the same state as it was 
in when you last closed it !!

To install this loadmodule first close winamp (if running),

then open x:\winamp_path\winamp.ini, and set "minimized=0".

Then start winamp by doubleclicking its icon, or an mp3-file or whatever.
(just don't use !amp_power or !amp_play)

Then change all!! uses of !amp_power to !amp_power2 and !amp_play to
!amp_play2.

Add the line loadmodule c:\litestep\zagamp.dll

Recycle

That should be it..


Many thanks to the GeekMaster for the source-code for geekAmp.
He should get most of the credit for this module, I just added a little.


Peter Zag

c971672@student.dtu.dk