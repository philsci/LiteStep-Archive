#include <windows.h>

LRESULT CALLBACK WndProc(HWND hwnd, int msg, WPARAM wParam, LPARAM lParam);

__declspec( dllexport ) HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam);
__declspec( dllexport ) void Quit();

static HBITMAP TopBmp;
static HBITMAP BufferBmp;
#pragma data_seg ("STATIC")
HBITMAP TopBmp=NULL;
HBITMAP BufferBmp=NULL;
#pragma data_seg ()

static HWND list[1000];
static WNDPROC listproc[1000];
static BOOL FIRST=TRUE;

HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	if (code < 0) 
	{
		//return (HOOKPROC)CallNextHookEx(0, code, wParam, lParam);
	}

	switch (code)
	{
		case HSHELL_WINDOWCREATED:
		{
			int x;

			if (FIRST)
			{
				FIRST=FALSE;
				for (x=0; x<1000; x++) { list[x] = NULL; listproc[x] = NULL; }
			}

			for (x=0; (list[x] != NULL) && (x<1000); x++)
			{
				if (list[x] == (HWND)wParam) return 0;
			}

			if (x==1000) return 0;
			else 
			{
				DWORD style = GetWindowLong((HWND)wParam, GWL_STYLE);
				int y = style & WS_CAPTION;
				int z = style & WS_CHILD;
				if (y && !z)
				{
					list[x] = (HWND)wParam;
					listproc[x] = (WNDPROC)SetWindowLong(list[x], GWL_WNDPROC, (LONG)WndProc);
				}
			}
		}
		return 0;
	}

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, int msg, WPARAM wParam, LPARAM lParam)
{
	int x;
	
	for (x=0; (list[x] != NULL) && (x<1000); x++)
	{
		if (list[x] == hwnd) break;
	}
	if (list[x] == NULL || x==1000) return 0;

	switch (msg)
	{
		case WM_NCHITTEST:
		{
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			RECT wr;
			GetWindowRect(hwnd, &wr);

			x -= wr.left;
			y -= wr.top;
			if (y <= GetSystemMetrics(SM_CYFRAME)) return HTTOP;
			else if (y <= (GetSystemMetrics(SM_CYFRAME) + GetSystemMetrics(SM_CYSIZE))) 
			{
				if (x >= 6 && x <= 19 && y >= 6 && y <= 19)
				{
					return HTCLOSE;
				}
				else
				{
					return HTCAPTION;
				}
			}
			else if (x <= GetSystemMetrics(SM_CXFRAME)) return HTLEFT;
			else if (x >= (wr.right - wr.left - GetSystemMetrics(SM_CXFRAME))) return HTRIGHT;
			else if (y >= (wr.bottom - wr.top - GetSystemMetrics(SM_CYFRAME))) return HTBOTTOM;
		}
		break;

		case WM_ACTIVATE: PostMessage(hwnd, WM_NCPAINT, 0, 0);  break;

		case WM_NCLBUTTONDOWN:
		{
			if (wParam == HTCLOSE) SendMessage(hwnd, WM_SYSCOMMAND, SC_CLOSE, 0);
		}
		break;

		//case WM_NCMOUSEMOVE:
		//case WM_WINDOWPOSCHANGED:
		case WM_NCACTIVATE:
		case WM_NCPAINT:
		{
			HDC hDC;
			HDC buffer = CreateCompatibleDC(NULL);
			HDC buf = CreateCompatibleDC(NULL);
			HDC tbuf = CreateCompatibleDC(NULL);
			RECT rc1, rc2;
			int xframe, yframe, ysize, width, height;
			char window_text[256] = "";
			RECT rgnbox;
			HBITMAP TempBmp=NULL;
			GetWindowText(hwnd, window_text, 256);
			
			if (!TopBmp) TopBmp = LoadImage(NULL, "h:\\dev\\garbonzo\\bepc.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

			hDC = GetWindowDC( hwnd );
			GetWindowRect( hwnd, (LPRECT)&rc2 );
			width = rc2.right - rc2.left;
			height = rc2.bottom - rc2.top;
			
			xframe = GetSystemMetrics(SM_CXFRAME);
			yframe = GetSystemMetrics(SM_CYFRAME);
			ysize = GetSystemMetrics(SM_CYSIZE);

			if (!BufferBmp)
			{
				BufferBmp = CreateCompatibleBitmap(hDC, width, yframe + ysize + 1);
				SelectObject(buffer, BufferBmp);

				GetRgnBox((HRGN)wParam, &rgnbox);
				SetRectRgn((HRGN)wParam, rgnbox.left, ysize + yframe*1, rgnbox.right, rgnbox.bottom);
				DefWindowProc(hwnd, msg, wParam, lParam);

				SetRect(&rc1, 0, 0, width, ysize + yframe + 1);
				
				SelectObject(buf, TopBmp);
				TempBmp = CreateCompatibleBitmap(hDC, 56, 23);
				SelectObject(tbuf, TempBmp);

				BitBlt(tbuf, 0, 0, 56, 23, buf, 25, 0, SRCCOPY);
				BitBlt(buffer, rc1.left, rc1.top, 25, rc1.bottom, buf, 0, 0, SRCCOPY);
				StretchBlt(buffer, 25, rc1.top, rc1.right-25, rc1.bottom, tbuf, 0, 0, 56, 23, SRCCOPY);
				BitBlt(buffer, rc1.right-25, rc1.top, 25, rc1.bottom, buf, 81, 0, SRCCOPY);

				SetBkColor( buffer, GetSysColor(COLOR_ACTIVECAPTION) );
				SetBkMode(buffer, TRANSPARENT);
				SetRect(&rc1, 0, ((ysize + yframe) / 2) - 8, width, ysize + yframe);
				DrawText( buffer, (LPSTR)window_text, -1, (LPRECT)&rc1, DT_CENTER);

				BitBlt(hDC, 0, 0, width, yframe + ysize + 1, buffer, 0, 0, SRCCOPY);
			}
			else
			{
				SelectObject(buffer, BufferBmp);
				BitBlt(hDC, 0, 0, width, yframe + ysize + 1, buffer, 0, 0, SRCCOPY);
			}

			SetRect(&rc1, 0, yframe + ysize, xframe, height - yframe);
			FillRect(hDC, &rc1, GetStockObject(BLACK_BRUSH));
			SetRect(&rc1, 0, height - yframe, width, height);
			FillRect(hDC, &rc1, GetStockObject(BLACK_BRUSH));
			SetRect(&rc1, width - xframe, yframe + ysize, width, height - yframe);
			FillRect(hDC, &rc1, GetStockObject(BLACK_BRUSH));

			ReleaseDC( hwnd, hDC );
			DeleteDC(buffer);
			DeleteDC(tbuf);
			DeleteDC(buf);
			DeleteObject(TempBmp);
		}
		return 0;
	}

	return CallWindowProc(listproc[x], hwnd, msg, wParam, lParam);
}

void Quit()
{
	DeleteObject(TopBmp);
	DeleteObject(BufferBmp);
  //int x;
  //for (x=0; list[x] && x<1000; x++)
  //{
  //  if (IsWindow(list[x])) SetWindowLong(list[x], GWL_WNDPROC, (LONG)listproc[x]);
  //}
}