//#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <commdlg.h>
#include "resource.h"


HINSTANCE hinst = NULL; 
HWND hwndMain = NULL; 
char* AppName = "Garbonzo";
HBITMAP TopBmp=NULL;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg;
	WNDCLASS wc;
	HINSTANCE hHookDll;
	HOOKPROC (FAR* hHookProc)(int, WPARAM, LPARAM);
	void (FAR* hQuit)();
	HHOOK hSystemHook;
    UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;  // save instance handle 

	memset(&wc,0,sizeof(wc));
	wc.hInstance = hInstance;
	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = AppName;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	RegisterClass(&wc);

	hHookDll = LoadLibrary("h:\\dev\\garbonzo\\map\\debug\\map.dll");
    hHookProc = (HOOKPROC (FAR*)(int, WPARAM, LPARAM))GetProcAddress(hHookDll, "HookFunction");
	hQuit = (void (FAR*)())GetProcAddress(hHookDll, "Quit");
    hSystemHook =  SetWindowsHookEx(WH_SHELL,(HOOKPROC)hHookProc,hHookDll,0);

	hwndMain = CreateWindow(AppName, AppName, WS_VISIBLE | WS_SIZEBOX | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_POPUPWINDOW | WS_CAPTION, 100, 100, 300, 300, NULL, NULL, hInstance, 0);
	if (!hwndMain) return FALSE;

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	if (hQuit) hQuit();
	UnhookWindowsHookEx(hSystemHook);
    FreeLibrary(hHookDll);

	if (hwndMain) DestroyWindow(hwndMain);
	UnregisterClass(AppName, hInstance);

	return msg.wParam; 
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hwndMain);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			RECT r;
			GetClientRect(hWnd, &r);
			FillRect(hdc, &r, GetStockObject(WHITE_BRUSH));
			EndPaint(hWnd, &ps);
		}
		break;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}
