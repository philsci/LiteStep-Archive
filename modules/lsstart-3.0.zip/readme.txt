There is now a crash trap implemented. If litestep.exe should happen to crash,
DO NOT reboot or logoff until your restart litestep. The way LSstart handles
watching for crashes, it needs to be properly exited to allow your applications
to start the next time it starts.

Make sure you read LSstart3.txt for usage instructions.

cbjcyber
cyber@cbj.net


