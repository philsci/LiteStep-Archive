/*
	This is a startup manager for LS.
	Use a line like:
	*Start X:\path\to\program.exe
	to have LS start a program for you

	author: cbjcyber
	version: 1.0
*/

#include <windows.h>
#include <stdio.h>
#include "start.h"
#include "../lsapi/lsapi.h"

// Startup stuff
// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

// Actual main function
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	FILE *f;
	
	f = LCOpen (NULL);
	if (f)
	{
		char	buffer[4096];
		char	token1[4096], token2[4096], extra_text[4096];
		char*	tokens[2];
		
		tokens[0] = token1;
		tokens[1] = token2;
		
		buffer[0] = 0;

		while (LCReadNextConfig (f, "*Start", buffer, sizeof (buffer)))
		{
			int count;
			
			token1[0] = token2[0] = extra_text[0];
			
			count = LCTokenize (buffer, tokens, 2, extra_text);
			
			// token 1 is "*Start", token 2 is the VWM window, token 3 is the
			// executable, and the extra_text are the program arguments.
			ShellExecute(NULL, NULL, token2, extra_text, NULL, SW_SHOWNORMAL);
		}
		LCClose(f);
	}
	return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)

{
	
}
