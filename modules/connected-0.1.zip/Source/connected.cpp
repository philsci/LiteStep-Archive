/*
This is a part of the Connected LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

Based upon structure of hotkey.dll by LiteStep Development Team
Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "connected.h"

const char rcsRevision[] = "$Revision: 0.1 (Sci)$"; // Our Version
const char rcsId[] = "$Id: connected.cpp,v 0.1 2001/08/11 14:41:00 Sci Exp $"; // The Full RCS ID.
const char szAppName[] = "ConnectedWindow";

Connected *connected; // The module

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	AddBangCommand("!Connected", bangConnected);

	Window::init(dllInst);
	connected = new Connected(parentWnd, code);

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!Connected");
	delete connected;
}

void bangConnected(HWND caller, LPCSTR args)
{
	char szConnected[MAX_LINE_LENGTH], szDisconnected[MAX_LINE_LENGTH];

	GetToken(args, szConnected, &args, true);
	GetToken(args, szDisconnected, &args, true);

	connected->bangConnected(szConnected, szDisconnected);
}

BOOL Connected::isConnected()
{
	DWORD flags;
	int conn=InternetGetConnectedState(&flags,0);
	if(conn && flags&INTERNET_CONNECTION_LAN && !(flags&INTERNET_CONNECTION_MODEM)) conn=0;
	return (conn!=0);
}

Connected::Connected(HWND parentWnd, int& code):
Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "Connected", WS_CHILD, 0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);

		code = 1;
		return;
	}
	code = 0;
}

Connected::~Connected()
{
	destroyWindow();
}

void Connected::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onCreate, WM_CREATE)
		MESSAGE(onDestroy, WM_DESTROY)
		MESSAGE(onEndSession, WM_ENDSESSION)
		MESSAGE(onEndSession, WM_QUERYENDSESSION)
		REJECT_MESSAGE(WM_ERASEBKGND)
		REJECT_MESSAGE(WM_PAINT)
		MESSAGE(onGetRevId, LM_GETREVID)
		MESSAGE(onSysCommand, WM_SYSCOMMAND)
		MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}

void Connected::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	long interval = 0;
	char szBuffer[MAX_LINE_LENGTH];

	bConnected = isConnected();

	GetRCLine("ConnectedOnConnect", szOnConnect, MAX_LINE_LENGTH, "");
	GetRCLine("ConnectedOnDisconnect", szOnDisconnect, MAX_LINE_LENGTH, "");

	GetRCString("ConnectedInterval", szBuffer, "10000", MAX_LINE_LENGTH);
	if(szBuffer[strlen(szBuffer)-1]=='s')
		interval = 1000;
	else if(szBuffer[strlen(szBuffer)-1]=='m')
		interval = 60000;
	else if(szBuffer[strlen(szBuffer)-1]=='h')
		interval = 3600000;

	if(interval == 0)
		interval = 1;
	else
		szBuffer[strlen(szBuffer)-1]=0;
	
	interval *= atol(szBuffer);

	SetTimer(hWnd, 1, interval, NULL);
}

void Connected::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	KillTimer(hWnd, 1);
}

void Connected::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Connected::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "connected.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void Connected::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Connected::onTimer(Message& message)
{
	if((long)message.wParam == 1)
		if(bConnected != isConnected())
		{
			bConnected = !bConnected;
			if(bConnected)
				LSExecute(NULL, szOnConnect, NULL);
			else
				LSExecute(NULL, szOnDisconnect, NULL);
		}
}

void Connected::bangConnected(LPCSTR szConnected, LPCSTR szDisconnected)
{
	if(isConnected())
		LSExecute(NULL, szConnected, NULL);
	else
		LSExecute(NULL, szDisconnected, NULL);
}
