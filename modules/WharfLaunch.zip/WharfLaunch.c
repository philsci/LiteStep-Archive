#include <windows.h>
#include <stdio.h>
#include "WharfLaunch.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "WharfLaunch"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void SetupRects();
void LoadSetup();

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

int width;
HMENU Popup;
HBITMAP backImage = NULL;
PAINTSTRUCT ps;
HINSTANCE TheInstance;

char ini[25] = "";
char programs[10][MAX_PATH] = {""};
char bitmaps[10][MAX_PATH] = {""};
HBITMAP bmp[10] = {NULL};

int HighLight=1, Grid=1, Timer=0;
RECT phil;
RECT empty;
RECT rects[10];
COLORREF chbr = 0x00000000;
COLORREF chgrid = 0x00000000;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    if (wharfData.borderSize < 0)
        wharfData.borderSize = 0;
	wndSize = 64-wharfData.borderSize*2;

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }

	TheInstance = dllInst;

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data
	
	width = (wndSize - 10) / 3;
	Timer = SetTimer(hMainWnd, 0, 100, NULL);
	SetupRects();
	sprintf(ini, "%smodules.ini", wharfData.lsPath);
	LoadSetup();

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Reload Settings");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 101, "&Edit Settings");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "&About WharfLaunch");


    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	DestroyMenu(Popup);
    DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{  
				HBRUSH hbr = CreateSolidBrush(chbr);
				HPEN hgrid = CreatePen(PS_SOLID, 0, chgrid);
				int count=1;
				int x=0, y=0;
				if (!backImage)
                {
					HDC hdc = GetDC(parent);
					HDC buf = CreateCompatibleDC(NULL);

					backImage = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, backImage);
					BitBlt(buf, 0, 0, 64, 64, hdc, 0, 0, SRCCOPY);

					ReleaseDC(hwnd,hdc);
					DeleteDC(buf);
				}
				
				{
					HDC hdc = BeginPaint(hwnd,&ps);
					HDC buf = CreateCompatibleDC(NULL);
					HDC src = CreateCompatibleDC(NULL);
					HBITMAP bufBMP = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, bufBMP);
					
					if (backImage)
					{	
						SelectObject(src, backImage);
						BitBlt(buf, 0, 0, 64, 64, src, 0, 0, SRCCOPY);
					}
					
					while (count != 10)
					{
						if (bitmaps[count][0] != '\0')
						{
							SelectObject(src, bmp[count]);
							if (count == 1 || count == 4 || count == 7) x = rects[1].left+1;
							else if (count == 2 || count == 5 || count == 8) x = rects[2].left;
							else if (count == 3 || count == 6 || count == 9) x = rects[3].left-1;
							if (count == 1 || count == 2 || count == 3) y = rects[1].top+1;
							else if (count == 4 || count == 5 || count == 6) y = rects[4].top;
							else if (count == 7 || count == 8 || count == 9) y = rects[7].top-1;
							BitBlt(buf, x, y, width, width, src, 0, 0, SRCCOPY);
						}
						count++;
						x=y=0;
					}
					
					if (HighLight) FillRect(buf, &phil, hbr);

					if (Grid)
					{
						SelectObject(buf, hgrid);
						MoveToEx(buf, rects[1].left, rects[1].top, NULL);
						LineTo(buf, rects[1].left, rects[7].bottom);
						MoveToEx(buf, rects[2].left, rects[2].top, NULL);
						LineTo(buf, rects[2].left, rects[8].bottom);
						MoveToEx(buf, rects[3].left, rects[3].top, NULL);
						LineTo(buf, rects[3].left, rects[9].bottom);
						MoveToEx(buf, rects[3].right, rects[3].top, NULL);
						LineTo(buf, rects[3].right, rects[9].bottom+1);

						MoveToEx(buf, rects[1].left, rects[1].top, NULL);
						LineTo(buf, rects[3].right, rects[3].top);
						MoveToEx(buf, rects[4].left, rects[4].top, NULL);
						LineTo(buf, rects[6].right, rects[6].top);
						MoveToEx(buf, rects[7].left, rects[7].top, NULL);
						LineTo(buf, rects[9].right, rects[9].top);
						MoveToEx(buf, rects[7].left, rects[7].bottom, NULL);
						LineTo(buf, rects[9].right+1, rects[9].bottom);
					}
					
					BitBlt(hdc, 0, 0, 64, 64, buf, 0, 0, SRCCOPY);

					EndPaint(hwnd,&ps);
					DeleteDC(buf);
					DeleteDC(src);
					DeleteObject(bufBMP);
					DeleteObject(hbr);
					DeleteObject(hgrid);
				}
			}
            return 0;
		case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
			{
				DWORD dw = GetMessagePos();
				TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			}
			return 0;
        case WM_LBUTTONDOWN:
		case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_LBUTTONUP:
			{
				static int valid=0;
				int err=0;
				int clicked=-1;
				int x = (int)LOWORD(lParam);
				int y = (int)HIWORD(lParam);
				if (x > 5 && x < 22)  // Column 1
				{
					if (y > 5 && y < 22)
					{
						//err = WinExec(programs[1], SW_SHOWNORMAL);
						clicked=1;
						phil = rects[1];
					}
					else if (y > 22 && y < 40)
					{
						//err = WinExec(programs[4], SW_SHOWNORMAL);
						clicked=4;
						phil = rects[4];
					}
					else if (y > 40 && y < wndSize - 5)
					{
						//err = WinExec(programs[7], SW_SHOWNORMAL);
						clicked=7;
						phil = rects[7];
					}
				}
				else if (x > 22 && x < 40) // Column 2
				{
					if (y > 5 && y < 22)
					{
						//err = WinExec(programs[2], SW_SHOWNORMAL);
						clicked=2;
						phil = rects[2];
					}
					else if (y > 22 && y < 40)
					{
						//err = WinExec(programs[5], SW_SHOWNORMAL);
						clicked=5;
						phil = rects[5];
					}
					else if (y > 40 && y < wndSize - 5)
					{
						//err = WinExec(programs[8], SW_SHOWNORMAL);
						clicked=8;
						phil = rects[8];
					}
				}
				else if (x > 40 && x < wndSize - 5) // Column 3
				{
					if (y > 5 && y < 22)
					{
						//err = WinExec(programs[3], SW_SHOWNORMAL);
						clicked=3;
						phil = rects[3];
					}
					else if (y > 22 && y < 40)
					{
						//err = WinExec(programs[6], SW_SHOWNORMAL);
						clicked=6;
						phil = rects[6];
					}
					else if (y > 40 && y < wndSize - 5)
					{
						//err = WinExec(programs[9], SW_SHOWNORMAL);
						clicked=9;
						phil = rects[9];
					}
				}
				else phil = empty;
				
				if (programs[clicked][0] != '\0' && clicked != -1)
				{
					InvalidateRect(hwnd, NULL, TRUE);
					err = WinExec(programs[clicked], SW_SHOWNORMAL);
					if (err <= 31)
					{
						switch (err)
						{
							case ERROR_BAD_FORMAT:
								MessageBox(NULL, "Error: This is not a valid 32-Bit Application", "WharfLaunch - Alert", MB_OK | MB_SETFOREGROUND);
								break;
							case ERROR_FILE_NOT_FOUND:
								MessageBox(NULL, "Error: File Not Found", "WharfLaunch - Alert", MB_OK | MB_SETFOREGROUND);
								break;
							case ERROR_PATH_NOT_FOUND:
								MessageBox(NULL, "Error: Path Not Found", "WharfLaunch - Alert", MB_OK | MB_SETFOREGROUND);
								break;
						}
					}
				}
				else 
				{ 
					InvalidateRect(hwnd, NULL, TRUE); 
				}
			}
			return 0;
			case WM_COMMAND:
				{
					switch (wParam)
					{
					case 100:
						LoadSetup();
						return 0;
					case 101:
					{
						char temp[MAX_PATH + 12] = "";
						sprintf(temp, "notepad.exe %s", ini);
						WinExec(temp, SW_SHOWNORMAL);
					}
						return 0;
					case 102:
						MessageBox(NULL, "WharfLaunch V1.2\nBy: MrJukes\n\n - Thanks to sitonacid for all the suggestions.\n - E-mail me at mrjukes@purdue.edu", "WharfLaunch V1.2", MB_OK | MB_SETFOREGROUND | MB_ICONINFORMATION);
						return 0;
					}
				}
				return 0;
			case WM_TIMER:
				{
					phil = empty;
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

void SetupRects()
{
	int side = 5;
	
	rects[1].left = side;
	rects[1].right = rects[1].left + width;
	rects[1].top = side;
	rects[1].bottom = rects[1].top + width;

	rects[2] = rects[1];
	rects[2].left = rects[1].right;
	rects[2].right = rects[2].left + width;
	
	rects[3] = rects[2];
	rects[3].left = rects[2].right;
	rects[3].right = rects[3].left + width;
	
	rects[4] = rects[1];
	rects[4].top = rects[1].bottom;
	rects[4].bottom = rects[4].top + width;

	rects[5] = rects[2];
	rects[5].top = rects[4].top;
	rects[5].bottom = rects[4].bottom;

	rects[6] = rects[3];
	rects[6].top = rects[4].top;
	rects[6].bottom = rects[4].bottom;

	rects[7] = rects[1];
	rects[7].top = rects[4].bottom;
	rects[7].bottom = rects[7].top + width;

	rects[8] = rects[2];
	rects[8].top = rects[7].top;
	rects[8].bottom = rects[7].bottom;

	rects[9] = rects[3];
	rects[9].top = rects[7].top;
	rects[9].bottom = rects[7].bottom;
}

void LoadSetup()
{
	int HaveRun=0;
	char temp[MAX_PATH + 12] = "";
	int x=1;
	char version[13] = "WharfLaunch";

	HaveRun = GetPrivateProfileInt(version, "HaveRun", 0, ini);
	HighLight = GetPrivateProfileInt(version, "HighLight", 1, ini);
	chbr = GetPrivateProfileInt(version, "HighLightColor", 0x00000000, ini);
	Grid = GetPrivateProfileInt(version, "Grid", 1, ini);
	chgrid = GetPrivateProfileInt(version, "GridColor", 0x00000000, ini);

	if (HaveRun)
	{
		while (x != 10)
		{
			sprintf(temp, "Program%d", x);
			GetPrivateProfileString(version, temp, NULL, programs[x], MAX_PATH, ini);
			sprintf(temp, "Bitmap%d", x);
			GetPrivateProfileString(version, temp, NULL, bitmaps[x], MAX_PATH, ini);
			if (bitmaps[x][0] != '\0')
				bmp[x] = LoadImage(TheInstance, bitmaps[x], IMAGE_BITMAP, 17, 17, LR_LOADFROMFILE);
			x++;
		}
		x=1;
	}
	else
	{
		WritePrivateProfileString(version, "HaveRun", "1", ini);
		WritePrivateProfileString(version, "HighLight", "1", ini);
		WritePrivateProfileString(version, "HighLightColor", "0x00000000", ini);
		WritePrivateProfileString(version, "Grid", "1", ini);
		WritePrivateProfileString(version, "GridColor", "0x00000000", ini);
		while (x != 10)
		{
			sprintf(temp, "Program%d", x);
			WritePrivateProfileString(version, temp, "", ini);
			sprintf(temp, "Bitmap%d", x);
			WritePrivateProfileString(version, temp, "", ini);
			x++;
		}
		sprintf(temp, "notepad.exe %s", ini);
		WinExec(temp, SW_SHOWNORMAL);
		MessageBox(NULL, "Edit the WharfLaunch section of your modules.ini.", "WharfLaunch", MB_OK | MB_SETFOREGROUND);
	}
	InvalidateRect(hMainWnd, NULL, TRUE);
}