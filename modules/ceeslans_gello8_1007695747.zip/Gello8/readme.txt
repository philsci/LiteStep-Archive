-------------------------------------------------------------------------------
  ATTENTION: If this is the first time you are using a theme that follows the
    Open Theme Standard, go to http://ls-ots.cjb.net, read the req. in the
        installation section, & follow the instructions on setting up your
                               personal config. files.
-------------------------------------------------------------------------------


1. install the theme
   Unzip the theme archive to your LiteStep\themes directory with path
   information.


2. Go to the Gello8\misc folder and unzip the included 'silkscreen.zip' to 
    the "fonts" folder in Windows-directory.
   Install the Winamp and WindowBlinds skins (if you like)


3. step.rc
   If you are using LSTS, run LSTS and select the theme
   Otherwise, browse to the LiteStep directory in your file manager - and
   edit step.rc so that it contains the following line and nothing else:
         include "$LiteStepDir$themes\Gello8\step.rc"
   Recycle LiteStep.
