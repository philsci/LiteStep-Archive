;------------------------------------------------------------------------------
;	instructions on installing personal config file
;------------------------------------------------------------------------------


NOTE: This setup process only has to be done once. After you do this, all your
personal settings (application paths, hotkeys, popup, etc.) will be applied
in all themes that adhere to the LiteStep Open Theme Standard. For information
on LS-OTS, how to create themes, or how to install themes, please go to:

	http://ls-ots.cjb.net


1. Create a 'personal' folder in your LiteStep directory, so that you have
   something like: 'X:\LiteStep\personal.'

2. Extract personal_cfg.zip to 'X:\LiteStep\personal'

3. Open 'X:\LiteStep\personal\evars.rc' and edit the paths according to your
   system

4. Open 'X:\LiteStep\personal\hotkey.rc' and setup the hotkeys as you wish

5. Open 'X:\LiteStep\personal\popup.rc' and setup the popup menu as you wish

6. There is no need to edit 'X:\LiteStep\personal\personal.rc'.

7. You may delete this file ('X:\LiteStep\personal\readme.txt') when done
