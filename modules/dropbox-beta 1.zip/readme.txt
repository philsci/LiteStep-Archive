///////////////////////////
// DropBox B1
// Written By: MrJukes
// Released: 1/10/00
///////////////////////////

// What is DropBox?
DropBox is a load module that will put an icon on your desktop.  When you
drag a file onto the icon, DropBox will perform the specified action upon
that file.

LoadModule c:\litestep\dropbox.dll

//Step.rc entries
*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "C:\program files\accessories\wordpad.exe $1"

*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "copy $1 c:\temp"
*DropBox 300 100 db_normal.bmp db_over.bmp db_click.bmp "move $1 c:\temp\"

That is:
*DropBox X Y normal over click "action"

DropBoxImageDir c:\litestep\images\dropbox

*Note* The width and height of the dropbox icon are the width of height of
the bitmap specified as the normal bitmap.

Have fun,
	MrJukes