#ifndef LITESTROKER_H
#define LITESTROKER_H

/* LOAD MODULE Functions */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

#endif 