0irc v1.0�
~~~~~~~~~~
version:    v1.0.6
release:    2
date:       2000/01/09
programmer: Torsten Stelling <murphy@dev0.de>
state:      freeware :-)
support:    <murphy@dev0.de>

(c)opyright 2000 by Torsten Stelling

this program is based on Aurore Irc source code.

what is 0irc
~~~~~~~~~~~~
0irc is a small irc-client for the global chat network.
what? you say, no not another irc-client! ok, delete 0irc and forget it!
otherwise read on and use it.

0irc is complete commandline based, except the dialog for the configuration
of the defaults.

why the name 0irc?
~~~~~~~~~~~~~~~~~~
i thought the name 0irc (say zero-irc) was good for a small irc-client.
this irc-client is as small as zero bytes. *grin*

use of 0irc
~~~~~~~~~~~
start 0irc.exe. enter in the commandline '/CONFIG' and press enter/return.
configure it for your needs and press ok. enter in the commandline '/CONNECT'
and press enter/return. use it like any other irc-client.

what files are delievered?
~~~~~~~~~~~~~~~~~~~~~~~~~~
0irc.exe     - the main executable of 0irc
readme.txt   - you are reading this
bugs.txt     - the bugs that are existent and a todo-list
whatsnew.txt - the history of 0irc
commands.txt - an overview of availble commands

end of text
~~~~~~~~~~~
now, have fun with it.
you can get a small help with the /HELP command.
