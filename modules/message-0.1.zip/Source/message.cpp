/*
This is a part of the MessageBox LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "message.h"

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!MessageBox", bangMessageBox);

	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!MessageBox");
}

void bangMessageBox(HWND caller, LPCSTR args)
{
	char token[MAX_LINE_LENGTH], message[MAX_LINE_LENGTH], title[MAX_LINE_LENGTH];
	char command[3][MAX_LINE_LENGTH];
	LPCSTR nextToken = args;
	UINT flags;
	int result;

	GetToken(nextToken, token, &nextToken, true);
	if(strcmp(token, "ari") == 0) flags = MB_ABORTRETRYIGNORE;
	else if(strcmp(token, "o") == 0) flags = MB_OK;
	else if(strcmp(token, "oc") == 0) flags = MB_OKCANCEL;
	else if(strcmp(token, "rc") == 0) flags = MB_RETRYCANCEL;
	else if(strcmp(token, "yn") == 0) flags = MB_YESNO;
	else if(strcmp(token, "ync") == 0) flags = MB_YESNOCANCEL;
	else return;

	GetToken(nextToken, token, &nextToken, true);
	strcpy(message, token);
	GetToken(nextToken, token, &nextToken, true);
	strcpy(title, token);
	for(int i=0; i<3; i++)
	{
		GetToken(nextToken, token, &nextToken, true);
		strcpy(command[i], token);
	}
	i=0;

	result = MessageBox(caller, message, title, flags|MB_SETFOREGROUND);
	switch(flags)
	{
	case MB_ABORTRETRYIGNORE:
		if(result==IDRETRY)
			i = 1;
		else if(result==IDIGNORE)
			i = 2;
		break;
	case MB_OKCANCEL:
		if(result==IDCANCEL)
			i = 1;
		break;
	case MB_RETRYCANCEL:
		if(result==IDCANCEL)
			i = 1;
		break;
	case MB_YESNO:
		if(result==IDNO)
			i = 1;
		break;
	case MB_YESNOCANCEL:
		if(result==IDNO)
			i = 1;
		else if(result==IDCANCEL)
			i = 2;
		break;
	}

	LSExecute(caller, command[i], SW_SHOWDEFAULT);
}
