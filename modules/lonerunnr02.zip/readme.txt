LoneRunnr version 1.1 by cael

this is just a small update to fix an anoying bug in LoneRunnr.

just put it wherever and add a shortcut to startup

enjoy ;-)
cael

version history

version 1.1
fixed multiple litestep's bug

version 1.0
initial release!