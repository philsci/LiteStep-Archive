/*****************************************
*
*
*	  Litepaper.dll  v1.01
*	   by Azathoth (2000)
*
*	www.intricatechaos.com
*
*****************************************/


*About:
	Litepaper.dll is a simple wallpaper changer with a few added extras.

*Features:

*	Ability to browse for background picture you want rather than constantly typing.
*	Ability to specify written loction of file for bangs/scripts etc.
*	Ability to specify style of background display (tile/center/stretch)
*	Ability to change resolutions upon background switching.

*Revision History:

[10/05/00] : 1.0
- Initial release.

[11/05/00] : 1.01
- More coding. 
- Implemented LM_GETREVID so that litepaper.dll registers in the about box.
- Added a version page to the dll properties.
- Changed the bang commands from !setwallpaper and !setwallpapercmd to !litepaper and !litepapercmd respectively due to older wallpaper modules using !setwallpaper.
- Brand new feature :
Resolution support is now available. The resolution can be changed upon background switching.
This support is available in both the !litepaper and the !litepapercmd commands.
- Cleaned up tokenizing code. Works and looks nicer now.
- Comments on everything. Source will be released soon.
- Module gone from 4k to 7k (must try to refine my code).
- Linked against the newest build lib. Fixed the problems that didn't allow me to compile under the new builds.


*Usage:

Put this line in your step.rc :
Loadmodule c:\litestep\litepaper.dll (where c:\litestep is the directory of litepaper.dll)

The commands are then as follows:

!litepaper <style> <bpp> <width> <height>

	This causes an open dialog to display and you can select the wallpaper of your choice.
	The <style> section is there to provide the facility to change the way the bkg is 	displayed. 0 = center, 1 = tile, 2 = stretch.
	The <bpp> defines what BitsPerPixel you wish the screen to display. ie. 16, 24...
	The <width> defines how wide the screen will be (in pixels). ie. 1024, 800, 640...
	The <height> defines the height in pixels of the screen. ie. 600, 768, 1200...

eg. !litepaper 0 16 800 600

!litepapercmd <path> <style> <bpp> <width> <height>

	This allows you to select a picture for the bkg with a path specification.
	The <path> is the full path to the image.
	The <style> section is for changing the way the picture is displayed. 0 =center, 1=tile, 2 = stretch.
	The <bpp> defines what BitsPerPixel the screen will change to. ie. 8, 32...
	The <width> defines how many pixels wide the screen will become. ie. 1600, 1900...
	The <height> defines how high in pixels the screen will be. ie. 480, 768...

eg. !litepapercmd c:\graphics\backgrounds\bg.bmp 2 32 1024 768

note: using quotes for long spaced out filenames is accepted.
eg. !litepapercmd "c:\my documents\images\chaos.bmp" 1 32 1024 768

also, note that you can only use BitMaP (bmp) files for the background, this is a windows imposed limitation and i am working on a work-around.

*Notes:

I took the initial idea from bangs.dll by rDj. I was re-writing it, implementing new commands etc., when i realised that i could do lots of stuff to the desktop. I went about making my own module and this is the result. I hope you like it.

*Thanks:

Firstly to the fellow coders who helped me greatly:-

MrJukes for helping me with many problems :)
NeXTer for showing me that i have sooo much more to learn.
Visigoth for making LSXCommand without which i would be severly stumped.
Message for listening to my rantings from time to time.
The LSDev team in general for just making something that I can use, enjoy and play with. I am just glad i can finally give something back to the community no matter how small.

I would also like to thank mindjunction.com cos it is a damn good site and it's ideas section has helped many a bored coder :) (Cheerz Geek)

I guess there are many other people to thank but i just can't think of any... oh wait...

Demigod for being so damn cool.

alrighty then, anything i missed????

*Adlib:

Send any suggestions, bugs, errors, hints or anything vaguely cool to me at the address' listed at the bottom of this doc.

********************************=============***********************************

*Contact details:

e-mail: 	azathoth@intricatechaos.com
website:	www.intricatechaos.com
ICQ:		25810657
MSN:		mistersteerpike@hotmail.com
IRC:		EFNet, #litestep, #ls_help, #chunkymunky, #ds_help + others; nick = Azathoth

