step.rc commands
 
LoadModule c:\litestep\litespeak.dll
 
// What is says when it loads
LiteSpeakGreeting My God, its' full of stars.
 
// What it says while you are changing speed and pitch
LiteSpeakTesting Testing
 
// Valid integer from 1-100 (these don't really work either)
LiteSpeakPitch 50
LiteSpeakSpeed 50
 
// Says whatever follows !Speak
!Speak Hello world!
 
// You can correct LiteSpeak's pronunciation using this
!LiteSpeakCorrect
 
// These don't really work right now
!LiteSpeakPitchUp
!LiteSpeakPitchDown
!LiteSpeakSpeedUp
!LiteSpeakSpeedDown


