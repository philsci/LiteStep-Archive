//============================================================
//lsCDEject.dll v1.0 - bangs for CD tray actions
//------------------------------------------------------------
//Filename	: 	lsCDEject.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This Litstep Module provides 3 bang commands for opening, 
//	ejecting, and toggling the cd tray. (released under GPL)
//------------------------------------------------------------
/****************** v1.0		9/16/2000************/
//	First release
//
//	3 Bang commands:
//		!CDOpenTray DriveLetter
//		!CDCloseTray DriveLetter
//		!CDToggleTray DriveLetter
//	DriveLetter is the place where you specify the cd-rom
//	drive you wish to perform the action.  The bang command
//	will not work if DriveLetter is not specified
//
//	Note: This allows manipulating up to 10 drives
//
//------------------------------------------------------------
//Example Step.rc config:
//	LoadModule "C:\Litestep\lsCDEject.dll"
//
//Example Bang usage:
//	!CDOpenTray E
//	!CDCloseTray F
//	!CDToggleTray G
//------------------------------------------------------------
//Example Popup usage:
//	*Popup "CD Drive" Folder
//		*Popup "E: Drive" !CDToggleTray E
//		*Popup "F: Drive" !CDToggleTray F
//	*Popup ~Folder
//------------------------------------------------------------