Autorecycle.dll

A simple module to recylce litestep everytime you save your step.rc or your theme file.

Steps

1)	Unzip to a location of your choice
2)	Loadmodule "path to autorecycle\autorecycle.dll"
3)	Make sure you have refernced your themefile
4)	Add any files you wish to watch to your step using the structure:
	*Watchfile "$litestepDir$script.rc"
	Warning: be sure to include quotes round any files with spaces in their path

Version History:

0.1	1st release
0.2	Added Theme File support
0.3	Ability to add up to 30 files to watch for changes
	fixed Theme File support (wasn't supporting new LsThemeFile setting)
	Added Bang Command !AutorecycleToggle as requested

NOTE: This module requires a recent dev build to work (It uses a new function added to lsapi)

Galois
Galois@Techie.net