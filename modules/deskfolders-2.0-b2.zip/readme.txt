DeskFolders 2.0 beta 2
---

Author: Maduin <maduin@dasoft.org>
Date: 02 May 1999
URL: http://maduin.dasoft.org/deskfolders

This archive contains the binary distribution of DeskFolders 2,
a desktop module for the Litestep shell. Documentation and
other distributions (if available) can be found at the DeskFolders
homepage: http://maduin.dasoft.org/deskfolders.

Note that this is beta software, there are bugs. Some I'm aware
of, some I'm not. If you find a bug please send me an email at
maduin@dasoft.org. Describe the bug and list your versions of
Windows, Litestep, and Internet Explorer (if installed).
