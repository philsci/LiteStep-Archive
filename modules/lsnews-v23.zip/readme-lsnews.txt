////////////////////////
// LSNews 2.3
// By: MrJukes
// Released: 3/22/00
////////////////////////

// What's new in 2.3?
- Added Bang Commands:
	+ !LSNewsShow
	+ !LSNewsHide
	+ !LSNewsToggle
	+ !LSNewsUpdate
	+ !LSNewsNextSite
	+ !LSNewsPrevSite
	+ !LSNewsFocus
	+ !LSNewsStartScrolling
	+ !LSNewsStopScrolling

- New step.rc commands:
	+ LSNewsBackColor 000000
		: Sets a background color. No transparency if you use this.
	+ LSNewsLinkColor RRGGBB
		: Sets the color of the links
	+ LSNewsLinkSize 8
		: Sets the font size of the links
	+ LSNewsLinkUnderline
		: If this is set LSNews will underline links.
		: Otherwise they are not underlined.
	+ LSNewsAutoScroll
		: Makes LSNews automatically scroll the text
	+ LSNewsScrollSpeed 500
		: The number of milliseconds between scrolls
	+ LSNewsAutoSwitch
		: If this is set LSNews will switch to the next
		: news site when it is done scrolling.
		: Otherwise it will keep scrolling the same site

// What's new in 2.2?
- Added Magic Pink (TM) support
	+ Careful! This is real transparency we're dealing with people. It takes whatever area you specify to be transparent and takes it completely out of the window.  I'd recommend only using it around the borders and not behind the text.
- New step.rc commands:
	+ LSNewsHScrollbar
		: Adds a horizontal scrollbar when needed
	+ LSNewsVScrollbar
		: Adds a vertical scrollbar when needed
- Modified step.rc commands:
	+ Changed LSNewsURL to *LSNewsURL
		: *LSNewsURL "Site Name" http://site.com/news.txt
		: This now means you can have as many *LSNewsURL entries as you want.
		: Use the right-click menu to switch between sites.

// What's new in 2.1?
- Added background support
- Added dragging
- Added text wrapping
- New step.rc commands:
	+ LSNewsEditX 3
	+ LSNewsEditY 23
	+ LSNewsEditWidth 220
	+ LSNewsEditHeight 100 
	+ LSNewsWrapText
	+ LSNewsBackground c:\litestep\images\lsnews.bmp

// What's new in 2.0?
- Complete rewrite of the old code.
- It is now a loadmodule, not a wharf module.
- You can't specify a background image (yet?), it just uses transparency

// Operation
- Use the up and down arrows to scroll.  Page Up and Page Down scrolls faster.
- Double click on the window to redraw the background
- Right click to bring up the popup menu.

// Step.rc commands
LoadModule h:\Litestep\lsnews.dll

LSNewsX 75		// X Position for main window
LSNewsY 75		// Y Position for main window
LSNewsWidth 400		// Width of main window
LSNewsHeight 625	// Height of main window
LSNewsEditX 0		// X Position for edit box (relative to main window)
LSNewsEditY 0		// Y Position for edit box (relative to main window)
LSNewsEditWidth 400	// Width of edit box
LSNewsEditHeight 625	// Height of edit box
LSNewsFontFace Fixedsys	// Face of regular font
LSNewsFontSize 10	// Size of regular font
LSNewsFontColor FFFFFF	// Color of regular font
LSNewsBackColor 000000	// Color of background (Comment out for transparency)
LSNewsTimer 15		// Number of minutes between updating
LSNewsWrapText		// Wraps text on the horizontal
LSNewsLinkColor B4B400	// Color of links
LSNewsLinkSize 8	// Size of links
LSNewsLinkUnderline	// Underlines links
LSNewsAutoScroll	// Automatically scroll through news
LSNewsScrollSpeed 500	// Speed of scrolling in milliseconds
LSNewsAutoSwitch	// Automatically switches between sites while scrolling
LSNewsHScrollbar	// Adds a horizontal scrollbar
LSNewsVScrollbar	// Adds a vertical scrollbar
LSNewsBackground c:\litestep\images\lsnews.bmp 	// Full path to background image

// For a list of sites go to
// http://lsnews.mindjunction.com
*LSNewsURL "Litestep News" http://lsnews.mindjunction.com/lsnet-news.news
*LSNewsURL "Litestep Screenshots" http://lsnews.mindjunction.com/lsnet-ss.news
*LSNewsURL "Litestep Themes" http://lsnews.mindjunction.com/lsnet-themes.news
*LSNewsURL "Slashdot" http://lsnews.mindjunction.com/slashdot.news
*LSNewsURL "AppWatch" http://lsnews.mindjunction.com/appwatch.news
*LSNewsURL "Arstechnica" http://lsnews.mindjunction.com/arstechnica.news
*LSNewsURL "Betanews" http://lsnews.mindjunction.com/betanews.news
*LSNewsURL "ChunkMunky" http://lsnews.mindjunction.com/chunky.news
*LSNewsURL "Desktopian" http://lsnews.mindjunction.com/desktopian.news
*LSNewsURL "FPN" http://lsnews.mindjunction.com/fpn.news
*LSNewsURL "Freshmeat" http://lsnews.mindjunction.com/freshmeat.news
*LSNewsURL "GeekNews" http://lsnews.mindjunction.com/geeknews.news
*LSNewsURL "Litestep.net" http://lsnews.mindjunction.com/lsnet.news
*LSNewsURL "Mindjuction Ideas" http://lsnews.mindjunction.com/mind-ideas.news
*LSNewsURL "Mindjunction News" http://lsnews.mindjunction.com/mind-news.news
*LSNewsURL "Mindjunction.com" http://lsnews.mindjunction.com/mindjunction.news
*LSNewsURL "SegFault" http://lsnews.mindjunction.com/segfault.news
*LSNewsURL "ShellCity" http://lsnews.mindjunction.com/shellcity.news

E-mail at mrjukes@purdue.edu for bug reports and feature requests.

Have Fun,
	MrJukes