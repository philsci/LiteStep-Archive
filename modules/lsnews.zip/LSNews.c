#include <windows.h>
#include <stdio.h>
#include "LSNews.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LSNews"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
//void LoadSetup(void);
int UpdateNews();
int closeup(int);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HINSTANCE Instance;
HBITMAP backImage = NULL;

int socketinit=0;
int wsainit;
SOCKET mysocket;
HANDLE thread=NULL;
HMENU Popup;
int error=0;
char ini[_MAX_PATH];
DWORD MB = MB_OK | MB_SETFOREGROUND;

char News[10000] = "";
char WebServer[25] = "homepage.interaccess.com";
char NewsFile[25] = "/~mrjukes/litestep.news";
char ini[MAX_PATH];
int Port = 80;
BOOL MESSAGEBOX=TRUE;
RECT r;
int Timer=0;
int HEIGHT=0;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    if (wharfData.borderSize < 0)
		wharfData.borderSize = 0;
	wndSize = 64-wharfData.borderSize*2;
	Instance = dllInst;

	//LoadSetup();

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Check Mail Now");

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }

	sprintf(ini, "%smodules.ini", wharfData.lsPath);

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);
	
	GetClientRect(hMainWnd, &r);

	return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	if (thread)
	{
		closeup(2);	// Should cause the thread to exit 
		if (thread)
		{ // if it is still alive, try to kill it
			TerminateThread(thread, 0);
		}
	}
	DeleteObject(backImage);
	DestroyWindow(hMainWnd);                // delete our window
	UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
				if (!backImage)
				{
					HDC hdc = GetDC(parent);
					HDC buf = CreateCompatibleDC(NULL);

					backImage = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, backImage);
					BitBlt(buf, 0, 0, 64, 64, hdc, 0, 0, SRCCOPY);

					ReleaseDC(hdc,hwnd);
					DeleteDC(buf);
				}
				{
					PAINTSTRUCT ps;
					HDC hdc = BeginPaint(hwnd,&ps);
					HDC buf = CreateCompatibleDC(NULL);
					HDC src = CreateCompatibleDC(NULL);
					HDC bufBMP = CreateCompatibleBitmap(hdc, 64, 64);
					HFONT hf, oldFont;
					char temp[25] = "";
					SelectObject(buf, bufBMP);

					if (backImage)
					{
						SelectObject(src, backImage);
						BitBlt(buf, 0, 0, 64, 64, src, 0, 0, SRCCOPY);
					}

					hf = GetStockObject(ANSI_FIXED_FONT); 
					oldFont = SelectObject(buf, hf); 
					SetBkMode(buf, TRANSPARENT);
					HEIGHT = DrawTextEx(buf, 
									News, 
									strlen(News), 
									&r, 
									DT_EDITCONTROL | DT_WORDBREAK | DT_CALCRECT,
									NULL);

					DrawTextEx(buf, 
								News, 
								strlen(News), 
								&r, 
								DT_EDITCONTROL | DT_WORDBREAK, 
								NULL);
					BitBlt(hdc, 0, 0, 64, 64, buf, 0, 0, SRCCOPY);
					EndPaint(hwnd,&ps);
					DeleteDC(buf);
					DeleteDC(src);
					DeleteObject(bufBMP);
				}
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	    case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_LBUTTONDOWN:
			UpdateNews();
			return 0;
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
        case WM_RBUTTONDOWN:
			{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			return 0;
			}
		case WM_LBUTTONDBLCLK:
			
			return 0;
		case WM_COMMAND:
			switch(wParam)
				{
				case 100:
					if (!thread)
						//CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)do_pop, (LPVOID)hwnd, 0, &(int)thread);
					break;
				}
			return 0;
		case WM_TIMER:
		{
			char temp[25] = "";
			if (News && (r.bottom > 0))
			{
				r.top -= 10;
			}
			else
			{
				GetClientRect(hwnd, &r);
			}
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return 0;

    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int UpdateNews(void)
{
	WORD wVersionRequested; 
	WSADATA wsaData; 
	struct in_addr addr;
	struct sockaddr_in myaddr;
	int err; 
	struct hostent *host;
	char data[10000] = "";
	
	wVersionRequested = MAKEWORD(1, 1); 
	memset(&wsaData, 0, sizeof(wsaData));
	err = WSAStartup(wVersionRequested, &wsaData); 

	if (err != 0) 						 
		return closeup(1);

	wsainit=1;
 
	if ( LOBYTE( wsaData.wVersion ) != 1 || 
		    HIBYTE( wsaData.wVersion ) != 1 ) { 
		return closeup(1);
		}

	if (!*WebServer)
	{
		return closeup(0);
	}

	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	memset((void *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons((short)Port);

	socketinit=1;
      
	addr.s_addr = inet_addr (WebServer);
	if (addr.s_addr == INADDR_NONE)
		{
		host = gethostbyname (WebServer);
		if (host == NULL)
			return closeup(1);
		else
			memcpy((char *) &addr, host->h_addr, host->h_length);
		}
										
	myaddr.sin_addr = addr;
	memset(News, 0, sizeof(News));
	if (connect(mysocket, (struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR) 
		return closeup(1);
	sprintf(data, "GET %s HTTP/1.0\n\n", NewsFile);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR) 
		return closeup(1);
	if (recv(mysocket, News, 10000, 0) == SOCKET_ERROR) 
		return closeup(1);
	sprintf(News,"%s",strstr(News, "Litestep News"));
	InvalidateRect(hMainWnd, NULL, TRUE);
	if (Timer) KillTimer(hMainWnd, Timer);
	Timer=0;
	if (MESSAGEBOX) MessageBox(NULL, News, "LSNews", MB);
	GetClientRect(hMainWnd, &r);
	SetTimer(hMainWnd, 0, 500, NULL);
	closeup(0);

	return(0);
}

/*********************************************************************/
/* Close TCP connection                                              */
/*********************************************************************/
int closeup(int err)
{
if (socketinit)
	closesocket(mysocket);

WSACleanup();

if (err != 2) thread=NULL;
return 0;
}
