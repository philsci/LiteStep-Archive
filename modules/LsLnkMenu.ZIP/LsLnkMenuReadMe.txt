LsLnkMenu.DLL version 1.0

Introduction:

	LSLnkMenu is a Litestep module that will display a menu
	of .lnk files (Explorer shortcuts).

	It was created because I got tired of modifing all my shortcuts 
	everytime I switched themes. With LsLnkMenu, all you have to do is 
	change the location of the main button and all your shortcuts stay the same. 

	LsLnkMenu will only read .lnk files and thier associated icons. However, 
	you can change the icon that the .lnk file displays via explorer to
	any icon or bitmap.

Installation:
	
	To install, add an entry to your step.rc file to load the dll 
	(ex. LoadModule C:\LiteStep\LSLnkMenu.dll). 
	Then make whatever modifications needed in the LSLnkMenu.ini file 
	and place it in the LiteStep directory. NOTE: If you use the sample INI
	file provided, the top part contains an Example of the format don't use this,
	use the bottom part. 

	I have also included a screen shot of the module in action.


Troubleshooting:
	Almost all errors are related to paths. Make sure all paths are correct.
	At the very minimum, each menu needs A Mainbutton bitmap, a middle panel bitmap,
	and a directory to load the lnk files from. Also if there is a problem, the 
	DLL will create a file called LsLnkError.txt in the Litestep directory.
	This file might give you a clue as to what is going on.


Contact:
	You can contact me at the EMail address below
	I can't promise total support, but if there is something major
	I'll do my best. 

	Enjoy!


Carl Milano
carluchi@stratos.net

	