/*********************************************************************/
/*                                                                   */
/* I Killed LSCPU 1.5                                                */
/*                                                                   */
/* Bassed on LSCPU Copyright (c)1998 Francis Gastellu                */
/*                                    aka Lone Runner/Aegis          */
/*                                                                   */
/* Hacked by Dan Giralte (IKKenny on IRC, ikilledkenny@execpc.com)   */
/*                                                                   */
/*********************************************************************/
/*                                                                   */
/* This very simple module monitors CPU (Green) and Memory (red)     */
/*  activity...and more                                              */
/*                                                                   */
/* You may use it as a base for another module or to customize it    */
/* to your own needs.                                                */
/*                                                                   */
/* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF */
/* ANY KIND, EITHER EXPRESSED OR IMPLIED.                            */
/*                                                                   */
/*********************************************************************/
/* 10/30/1998 Added Goran's Custom Timer Code */ 

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include "ik_lscpu.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "IK_LsCPU"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

DWORD Reserved,dataType,dataLen=8192;
char data[8192];	// Buffer to communicate with registry. (way bigger than neeeded)

// Registry Keeys
HKEY cpuperfKey;
HKEY startcpuPerfKey;
HKEY memperfKey;
HKEY startmemPerfKey;

// History of info
char cpuhistory[64];
char memhistory[64];

BOOL init=FALSE;        // Monitor started ?
int width=0;            // Width of monitor (= size of history)

int cpupointer=0;       // pointer to cpu history
int mempointer=0;       // pointer to memory history

// 1.1 Transparent & Color Changes, COLORREF is BBGGRR
BOOL NoBg;
BOOL NoBorder;
BOOL NoGrid;
COLORREF BorderColor;
COLORREF BackColor;
COLORREF GridColor;
COLORREF CPUColor;
COLORREF MEMColor;

// 1.2 New FillMon, Choose Mon code
BOOL NoMEM;
BOOL NoCPU;
BOOL Fillin;
int MyDelay;

// Memory status
MEMORYSTATUS freeMem;

// To the settings
char inipath[80];

// DoubleBuffer Stuff
void DrawMonitor(HDC hdc, RECT r);

BOOL InitDraw=FALSE;  	//Did we draw once yet?

HDC DCBack = NULL;
HBITMAP BMBack = NULL, OldBack = NULL;

HDC DCDblBuff = NULL;
HBITMAP BMDblBuff = NULL, OldDblBuff = NULL;

/*************************************************************/
/* Load the modules.ini settings                             */
/* 1.1 Trans/Color Changes                                   */
/*                                                           */
/* Stolen mostly from lsvwm code                             */
/*************************************************************/

void LoadKilledSettings() {
	// These 3 lines setup the modules.ini path ala lsvwm 
	int x;
	strcpy((char *)&inipath,wharfData.lsPath);
	strcat((char *)&inipath,"modules.ini");
	  
	NoBg        = GetPrivateProfileInt("ik_lscpu", "nobg",       FALSE, inipath);
	NoBorder    = GetPrivateProfileInt("ik_lscpu", "noborder",   FALSE, inipath);
	NoGrid      = GetPrivateProfileInt("ik_lscpu", "nogrid",     FALSE, inipath);
	BorderColor = GetPrivateProfileInt("ik_lscpu", "bordercolor",0x00FFFFFF, inipath);
	BackColor   = GetPrivateProfileInt("ik_lscpu", "backcolor",  0x00005000, inipath);
	GridColor   = GetPrivateProfileInt("ik_lscpu", "gridcolor",  0x00007000, inipath);
	CPUColor    = GetPrivateProfileInt("ik_lscpu", "cpucolor" ,  0x0000FF00, inipath);
	MEMColor    = GetPrivateProfileInt("ik_lscpu", "memcolor" ,  0x000000FF, inipath);

	// 1.2 Code
	NoMEM       = GetPrivateProfileInt("ik_lscpu", "nomem",      FALSE, inipath);
	NoCPU       = GetPrivateProfileInt("ik_lscpu", "nocpu",      FALSE, inipath);
	Fillin      = GetPrivateProfileInt("ik_lscpu", "fillin",     FALSE, inipath);
        MyDelay     = GetPrivateProfileInt("ik_lscpu", "delay",      2,     inipath);
}

/************************************************************/
/* CreateDblBuff gets our Double Buffer started             */
/************************************************************/
void CreateDblBuff() {
	HDC DCBack = GetDC(parent);

	DCDblBuff = CreateCompatibleDC(DCBack);
	BMDblBuff = CreateCompatibleBitmap(DCBack, wndSize, wndSize);
	OldDblBuff = (HBITMAP)SelectObject(DCDblBuff, BMDblBuff);

	ReleaseDC(parent, DCBack);
}

/************************************************************/
/* FreeDblBuff releases our Double Buffer stuff             */
/************************************************************/
void FreeDblBuff() {
	
	if(DCDblBuff) {
		SelectObject(DCDblBuff, OldDblBuff);
		DeleteDC(DCDblBuff);
	}

	DCDblBuff = NULL;

	if(BMDblBuff) {
		DeleteObject(BMDblBuff);
	}

	BMDblBuff = NULL;
}

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	parent = ParentWnd; // Save parent window
	
	// Duplicate wharfData since the one we get will be destroyed
	memcpy(&wharfData, wd, sizeof(wharfDataType));
	wndSize = 64-wharfData.borderSize*2;
	
	memset(cpuhistory, 0, 64); // initialize history to 0
	memset(memhistory, 0, 64); // initialize history to 0
	
	{  // Register the Window class
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;       // our window procedure
		wc.hInstance = dllInst;         // hInstance of DLL
		wc.lpszClassName = szAppName;   // our window class name
		
		if (!RegisterClass(&wc)) {
			MessageBox(parent,"Error registering window class",szAppName, MB_OK);
			return 1; 
		}
	}

	hMainWnd = CreateWindowEx(
			WS_EX_TRANSPARENT,                          // exstyles 
			szAppName,                                  // our window class name
			szAppName,                                  // use description for a window title
			WS_CHILD,                                   // window style
			wharfData.borderSize, wharfData.borderSize, // position 
			wndSize,wndSize,                            // width & height of window
			parent,                                     // parent window (litestep wharf window)
			NULL,                                       // no menu
			dllInst,                                    // hInstance of DLL
			0);                                         // no window creation data
	
	if (!hMainWnd) {
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		return 1;
	}
	
	// Load Custom Settings
	LoadKilledSettings();

	//Create our Double Buffer
	CreateDblBuff();

	//Set a timer for our monitor (We could customize :)
	// SetTimer(hMainWnd, 0, 1000, NULL);
	SetTimer(hMainWnd, 0, (MyDelay*1000), NULL);

	// if... new 1.2 code
	if (!NoCPU) {
		// Open the cpu usage registry key
		RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StatData", &cpuperfKey);
		RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StatData", &memperfKey);

		// Start monitoring
		RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StartStat", &startcpuPerfKey);
		RegOpenKey(HKEY_DYN_DATA, "PerfStats\\StartStat", &startmemPerfKey);

		RegQueryValueEx(startcpuPerfKey, "KERNEL\\CPUUsage", &Reserved, &dataType, data, &dataLen);
		RegQueryValueEx(startmemPerfKey, "VMM\\cpgFree"    , &Reserved, &dataType, data, &dataLen);
	}

	// Set normal cursor
	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
    	
	// DO NOT REMOVE ! Set magicDWord - required!
	// Used by some modules & litestep internals
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord);

	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst) {
	KillTimer(hMainWnd, 0);
	
	if (!NoCPU) {
		RegCloseKey(startcpuPerfKey);
		RegCloseKey(startmemPerfKey);
		RegCloseKey(cpuperfKey);
		RegCloseKey(memperfKey);
	}

	//New DoubleBuffer Code
	SelectObject(DCBack, OldBack);

	if(DCBack)
		DeleteDC(DCBack);

	if(BMBack)
		DeleteObject(BMBack);

	//Free our DoubleBuffer Handles
	FreeDblBuff();

	DestroyWindow(hMainWnd);                // delete our window
	UnregisterClass(szAppName, dllInst);    // unregister window class
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
		case WM_CREATE:
			return 0;
		
		case WM_ERASEBKGND:
			return 1;

		case WM_PAINT: {
			
			HDC hdc = DCDblBuff, Orig;
				       
			PAINTSTRUCT ps;
			RECT r;

			// RECT r passed to DrawMonitor()
			GetClientRect(hwnd, &r);

			if (!InitDraw) {
				HDC DCParent = GetDC(parent);

				//Save Original Window Contents for Transparancy
				DCBack = CreateCompatibleDC(DCParent);
				BMBack = CreateCompatibleBitmap(DCParent, wndSize, wndSize);
				OldBack=(HBITMAP)SelectObject(DCBack, BMBack);
				BitBlt(DCBack, 0, 0, wndSize, wndSize, DCParent, 0, 0, SRCCOPY);
				
				ReleaseDC(parent, DCParent);
				InitDraw = TRUE;
			}

			// Draw our saved area of the parent Window
			BitBlt(hdc, 0, 0, wndSize, wndSize, DCBack, 0, 0, SRCCOPY);

			// Window Drawing
			GetClientRect(hwnd, &r);

			// Draw!
			DrawMonitor(hdc, r);
			
			// Copy the Double-Buffered Stuff into the Original DC
			Orig = BeginPaint(hwnd, &ps);
			BitBlt(Orig, 0, 0, wndSize, wndSize, DCDblBuff, 0, 0, SRCCOPY);
			EndPaint(hwnd, &ps);
		
			DeleteDC(Orig);
			       } return 0;
		
		case WM_KEYDOWN:    // forward keyboard messages to parent window
		
		case WM_KEYUP:
			PostMessage(parent,message,wParam,lParam);
			return 0;

		// Mouse messages are here to ensure we have a good popup 
		// menu behaviour. You may insert your own custom actions
		case WM_RBUTTONUP: {
			RECT r;
			GetWindowRect(hwnd, &r);
			PostMessage(GetParent(GetParent(parent)), 9182, 
			            r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
			
				   } return 0;

		case WM_RBUTTONDOWN:
		
		case WM_LBUTTONDOWN:

		case WM_MBUTTONDOWN:
			PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
			return 0;
		
		case WM_TIMER: { // Update cpu monitor
			RECT r;
			if (!init) return 0;

			// Get last cpu usage value
			// if.. code 1.2
			if (!NoCPU) { 
				RegQueryValueEx(cpuperfKey, "KERNEL\\CPUUsage", &Reserved, &dataType, data, &dataLen);
				
				// Insert it in the rotating buffer
				cpuhistory[cpupointer] = *data;
				cpupointer++;
				cpupointer %= width;
			}

			// Get last mem usage value
			// if.. code 1.2
			if (!NoMEM) {
				// Insert it in the rotating buffer
				GlobalMemoryStatus(&freeMem);
				memhistory[mempointer] = freeMem.dwMemoryLoad;
				mempointer++;
				mempointer %= width;
			}

			// Invalidate client. This causes a WM_PAINT message to be sent to our window
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			
			       } return 0;
	}
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void DrawMonitor(HDC hdc, RECT r) { 
	
	int i, j;
	HBRUSH brush;
	HPEN pen, oldpen;
	
	r.left++; // Adjustment for WharfBorder

	// Contract Rect by 4 pixels
	r.top += 4;
	r.bottom -= 4;
	r.left += 4;
	r.right -= 4;

	width = (r.right - r.left) - 3;  // Width of Monitor

	//Draw Border
	if (!NoBorder) { 
		pen = CreatePen(PS_SOLID, 1, 0);
		oldpen = SelectObject(hdc, pen);

		MoveToEx(hdc, r.left, r.bottom -1, NULL);
		LineTo(hdc, r.left, r.top);
		LineTo(hdc, r.right-1, r.top);

		SelectObject(hdc, oldpen);
		DeleteObject(pen);
		
		// Our Real border
		pen = CreatePen(PS_SOLID, 1, BorderColor);
		oldpen = SelectObject(hdc, pen);

		LineTo(hdc, r.right-1, r.bottom-1);
		LineTo(hdc, r.left, r.bottom-1);

		SelectObject(hdc, oldpen);
		DeleteObject(pen);
	};

	// Contract Rect by 1 more pixel
	r.top++;
	r.bottom--;
	r.left++;
	r.right--;

	// Draw Background
	if (!NoBg) {
		brush = CreateSolidBrush(BackColor);
		FillRect(hdc, &r, brush);		
		DeleteObject(brush);
	};

	// Draw Grid
	if (!NoGrid) {
		pen = CreatePen(PS_SOLID, 1, GridColor);
		oldpen = SelectObject(hdc, pen);

		for (i=1; i<4; i++) {
			MoveToEx(hdc, r.left, r.top + ((r.bottom - r.top) / 4) * i, NULL);
			LineTo(hdc, r.right-1, r.top + ((r.bottom - r.top) / 4) * i);
		}

		for (i=1; i<4; i++) {
			MoveToEx(hdc, r.left + ((r.right-r.left) / 4) * i, r.top, NULL);
			LineTo(hdc, r.left + ((r.right-r.left)/4)*i, r.bottom-1);
		}
		
		SelectObject(hdc, oldpen);
		DeleteObject(pen);
	}

	// 1.2 code
	if (!NoMEM) { 
		// Draw Mem Monitor
		pen = CreatePen(PS_SOLID, 1, MEMColor);
		oldpen = SelectObject(hdc, pen);
		
		j = (mempointer + width) % width;
		MoveToEx(hdc, r.left, r.bottom-(width * memhistory[j]/100), NULL);

		for (i=0; i<width; i++) {
			j++;
			j %= width;
			LineTo(hdc, r.left+i, r.bottom-(width * memhistory[j]/100));

			// 1.2 Fillin Code
			if (Fillin) {
				LineTo(hdc, r.left+i, r.bottom);
			}

		}

		SelectObject(hdc, oldpen);
		DeleteObject(pen);
	}

	// 1.2 Code
	if (!NoCPU) {
		// CPU Monitor
		pen = CreatePen(PS_SOLID, 1, CPUColor);
		oldpen = SelectObject(hdc, pen);

		j = (cpupointer + width) % width;
		MoveToEx(hdc, r.left, r.bottom-(width * cpuhistory[j]/100), NULL);

		for (i=0; i<width; i++) {
			j++;
			j %= width;
			LineTo(hdc, r.left+i, r.bottom-(width * cpuhistory[j]/100));

			// 1.2 Fillin Code
			if (Fillin) {
				LineTo(hdc, r.left+i, r.bottom);
			}

		}

		SelectObject(hdc, oldpen);
		DeleteObject(pen);
	}
	
	// Cleanup
	init=TRUE;
}
