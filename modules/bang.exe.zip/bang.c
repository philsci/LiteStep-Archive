
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdio.h>
#include "lsapi.h"

void main()
{
	LPSTR s = GetCommandLine();
	LPSTR d;
	UINT m;
	LMBANGCOMMAND lmbc;
	HWND hLS;
	COPYDATASTRUCT cds;
	
	// application path
	//
	
	while( *s && (*s == ' ' || *s == '\t') )
		s++;
	
	if( *s == '\"' || *s == '\'' )
	{
		char quoteChar = *s;
		s++;
		
		while( *s && *s != quoteChar )
			*s++;
		
		if( *s )
			s++;
	}
	else
	{
		while( *s && *s != ' ' && *s != '\t' )
			*s++;
	}
	
	// bang command name
	//
	
	d = lmbc.szCommand;
	m = LMBC_MAXCOMMAND;
	
	while( *s && (*s == ' ' || *s == '\t') )
		s++;
	
	if( *s != '!' && --m )
		*d++ = '!';
	
	while( *s && *s != ' ' && *s != '\t' && --m )
		*d++ = *s++;
	
	*d = 0;
	
	// arguments
	//
	
	d = lmbc.szArgs;
	m = LMBC_MAXARGS;
	
	while( *s && (*s == ' ' || *s == '\t') )
		s++;
	
	while( *s && --m )
		*d++ = *s++;
	
	*d = 0;
	
	// execute command
	//
	
	lmbc.cbSize = sizeof(LMBANGCOMMAND);
	lmbc.hWnd = NULL;
	
	hLS = FindWindow( TEXT("TApplication"), TEXT("Litestep") );
	
	if( !hLS )
	{
		LPTSTR pszMessage = TEXT("Cannot execute command, Litestep is not running.\r\n");
		DWORD nBytes;
		
		WriteFile( GetStdHandle( STD_OUTPUT_HANDLE ),
			pszMessage,
			lstrlen( pszMessage ),
			&nBytes,
			NULL );
		
		ExitProcess( TRUE );
	}
	
	cds.dwData = LM_BANGCOMMAND;
	cds.cbData = sizeof(LMBANGCOMMAND);
	cds.lpData = (LPVOID) &lmbc;
	
	SendMessage( hLS, WM_COPYDATA, 0, (LPARAM) &cds );
	ExitProcess( FALSE );
}
