
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include "lsapi.h"

void Pause( HWND hWnd, LPCTSTR pszArgs )
{
	LONG lInterval = atoi( pszArgs );
	LONG lTime = GetTickCount();
	MSG msg;
	
	if( lInterval > 0 )
	{
		while( (GetTickCount() - lTime) < lInterval )
		{
			if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
			{
				TranslateMessage( &msg );
				DispatchMessage( &msg );
			}
		}
	}
}

int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	AddBangCommand( TEXT("!pause"), Pause );
	return 1;
}

void quitModule( HINSTANCE hInstance )
{
	BOOL (*pRemoveBangCommand)( LPCSTR );
	pRemoveBangCommand = (BOOL (*)( LPCSTR )) GetProcAddress( GetModuleHandle( TEXT("LSAPI.DLL") ), TEXT("RemoveBangCommand") );
	
	if( pRemoveBangCommand )
		(*pRemoveBangCommand)( TEXT("!pause") );
}

int APIENTRY DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )
		DisableThreadLibraryCalls( hInstance );
	
	return 1;
}
