----------------------------------------------------------------
hotspots.dll   v0.2			09/07/99
----------------------------------------------------------------
Pavel Vitis



What are "hotspots.dll"?
================================================================

Hotspots is my experimental module, now in very early stage of
completion.
It allows you to define hot areas on the screen called "hotspots"
that will trigger event (run program or !bang command) when
the mouse pointer passes in the area and stays here awhile.

I programmed this to simulate "active borders", nice feature
included in famous Pointix (Pop-Mouse) utility by
Pointix Company (http://www.pointix.com/).



What's new
================================================================

v0.2		09/07/99
	* Fixed some ugly bugs
	* Fixed some minor bugs
	* Some internal optimizations
	+ Coordinates can be negative values
	+ Sizes can be zero - they are recalculated to maximum
	+ Option to start hotspots disabled
	+ Added params to hotspots
	+ Added !HotspotsEnable
	+ Added !HotspotsDisable
	+ Added !HotspotUpdate

v0.1		09/06/99
	+ First release



Installation
================================================================

Installation is simple. Load the module in your step.rc as:

LoadModule "c:\litestep\hotspots.dll"

Copy hotspots.dll directly into your Litestep directory.



Then edit your step.rc and define some hotspots. The syntax
is:

*Hotspot "Name" "Params" X-position Y-position Width Height Delay "Action"

-  "Name" is the unique identifier of the hotspot. Use some
descriptive name here. Multiple hotspots can share same name.
This name is used to identify the hotspots in bang commands.

-  Position is in pixels. You can use negative values.
-  Width, Height are in pixels. Zero value "0" means maximum
size (hotspot width/height reaches opposite screen border).

-  Delay is the time interval (in 1/10 sec) that defines how
long should mouse pointer stay in the hotspot area before
triggering associated action. It is here to avoid accidental
actions when working with mouse.
Delay is between 0..10.

- "Action" can be any executable, file, or !bang command. If the
non-executable file is specified, it will activate application
associated to file-type, if any.

- "Params" is string of additional parameters. Empty "" will
result in default behavior.

Params are:
  S - Silent mode - this hotspot doesn't beep
  D - Disabled mode - this hotspot is initially disabled
  X - Start application maximized
  M - Start application minimized


You can also define sound that will play when action is triggered:

HotspotBeep "path_to\beep.wav"


You can disable hotspots functionality at startup by specifying:

HotspotsDisabled


And there are some !Bangs:

!HotspotsEnable
!HotspotsDisable

; Update hotstpot's params - Current params will be replaced
!HotspotUpdate "Hotspot_name" "New_Params"

For example:
to disable hotspot:	!HotspotUpdate LeftBar "D"
to mute hotspot:	!HotspotUpdate LeftBar "S"



Example	step.rc entries:
================================================================

There I provide example settings for 1024x768 resolution.
I define three active borders on the left, right and top of
the screen to run frequently used applications (substitute
yours). Next I define four hot corners, top-left to instantly
activate screen-saver, top-right to disable screen-saver,
bottom-left to shutdown windows and bottom-right to run step.rc
editor.
First two hotspots provide simple functionality of hiding
taskbar like in explorer. "HideTaskbar" is defined over whole
desktop area and will hide taskbar after the mouse leaves
taskbar	strip. Taskbar will be shown when touching bottom
edge of screen ("ShowTaskbar").	Use geekfunk.dll for taskbar
bangs. This cool tip was first introduced by Jorje from Modulo -
http://chunkymunky.com/modulo/.


;=====================================================
; SAMPLE STEP.RC SECTION
;=====================================================

;HotspotsDisabled
HotspotBeep "c:\sounds\tick.wav"

*Hotspot HideTaskbar "S" 2 2 1022 748 10 !Hide_Taskbar
*Hotspot ShowTaskbar "S" 0 -1 0 0 0 !Show_Taskbar

*Hotspot Left "MS" 0 2 2 764 4 "notepad.exe"
*Hotspot Right "" 1022 2 2 764 4 "calc.exe"
*Hotspot Top "" 2 0 1020 2 10 "explorer.exe"
*Hotspot TopLeft "S" 0 0 2 2 10 !ActivateScreenSaver
*Hotspot TopRight "S" 1022 0 2 2 10 !DisableScreenSaver
*Hotspot BottomLeft "" 0 766 2 2 10 !Shutdown
*Hotspot BottomRight "" 1022 766 2 2 10 "notepad c:\litestep\step.rc"



Features, limitations
================================================================

If any of your hotspots will overlap, the control over overlapped
region takes hotspot that is defined later. They are defined
"from bottom to topmost".

In this version you cannot attach action to mouse leaving the
hotspot. So the setting for !DisableScreenSaver in example above
is slightly uselles now, because it will stay in disabled state
even when the mouse cursor leaves top-right corner. It will be
fixed in next versions.

You can define up to maximum of 50 hotspots.
"This should be enough for everyone..." ;)


Plans for future versions
================================================================

1. Add support for Shift/Ctrl/Alt key modifiers - almost done.

2. Specify flags for starting of applications - start minimized,
hidden, only one instance, etc. - partially done.

3. Allow the "ScreenWidth" and "ScreenHeight" constants in
the hotspot definition to easy snap the hotspots at screen
borders when changing screen resolution.
(I'm not sure about this)

4. ...... fill in the blanks yourself :)



Contact & info
================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www   : http://come.to/pavel.vitis/

Programmed in Delphi 3, usind LSDevKit (modified TR3) by Murphy:
http://www.dev0.de/
