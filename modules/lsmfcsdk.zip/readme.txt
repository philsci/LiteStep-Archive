*****************************************************************************
*   LiteStep Wharf Module MFC SDK 0.2 by zathan                             *       
*                                                                           *
*   Location : http://members.tripod.com/zathan/LiteStep/                   *
*                                                                           *
*   Contact  : zathan@phearable.com                                         *
*                                                                           *
*   Based on LiteSTEP Wharf Module SDK 1.4 by Lone Runner/Aegis             *
*                                                                           *
*   Please don't modify and release this code... help me make it better.    *
*****************************************************************************

* 980925: 
 Released the new bugfixed version as 0.2 and with a shorter filename... :)
 Should be about complete for it's purpose now... So I won't spend much more
 time on this unless I get some bugreports... I would like spend more time
 on making USEFUL wharf modules from now on... :)
 
 Got a nice mail today from Thomas Stivers, explaining why I got that bug...
 A bit embarasing, but I forgot to add the AFX_MANAGE_STATE in the beginning
 of initWharfModule(...) and quitWharfModule(...)   ;)

 Removed the OpenGL sample dll, this will be released as a seperate app/source...
 Cleaned up some comments/added others...

--- small FAQ:

Q: What is this?
A: It is a LiteStep Wharf Module SDK using MFC, based on LSSDK 1.4 that comes 
   with LiteStep 1.0 beta 23e.

Q: What is LiteStep?
A: If you don't know, I won't tell you... :) got to www.litestep.net or 
   floach.pimpin.net to find out... 

Q: Why did you make this?
A: Because I'm used to MFC and find Object Oriented coding (C++) much easier 
   than standard coding (C), but could not find any module SDK for c++ and/or 
   using MFC...

Q: Hmm, LiteStep crashed on me when I recycled it, how do I get into litestep 
   w/o restarting?
A: I warned you... :) 
   1) Click OK on the error message
   2) Press CTRL+ALT+DEL ONCE
   3) Select LiteStep and terminate it
   4) Now, if you don't run LoneRunner (you should), press CTRL+ESC to pop up 
      task manager (if it doesn't, you're pretty fucked unless you can ALT+TAB 
      to a dos shell and start litestep again from there...)
   5) Select run and c:\litestep\litestep.exe
   6) And if you don't want this to happen in the future... 
      Help me find the bug... :)

Q: If it's not complete/still has bugs, then why release it?
A: To get some help finding the bugs and suggestions to how to fix them...

Q: How do I contact you for suggestions?
A: First, check my homepage at http://members.tripod.com/zathan/
   and make sure I haven't already fixed the bug, then you can email me at
   zathan@phearable.com   <- not always working since it's a free account... :)
   (if you can provide me with a free email that is more stable and doesn't have
   any commercial crap/spamming, then feel free to give me one... :))