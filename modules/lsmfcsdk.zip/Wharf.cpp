// Wharf.cpp : Defines the initialization routines for the DLL.
//
// This file is part of the LS MFC SDK 0.2 by zathan.

#include "stdafx.h"
#include "Wharf.h"
#include "WharfWnd.h"		// the main wharf wnd...
#include "wharfdata.h"		// wharfdata struc...

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CWharfApp

BEGIN_MESSAGE_MAP(CWharfApp, CWinApp)
	//{{AFX_MSG_MAP(CWharfApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWharfApp construction

CWharfApp::CWharfApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWharfApp object

CWharfApp theWharfApp;		// the one and only WharfApp Object

/* ----Included from lssdk.c---------------------------------------- */

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND hParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{	
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
    return theWharfApp.StartUp(hParentWnd, dllInst, wd);
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
    theWharfApp.ShutDown();	
}

/* ----end of lssdk.c---- */

int CWharfApp::StartUp(HWND hParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&m_WharfData, wd, sizeof(wharfDataType));
    int nWndSize = 64-m_WharfData.borderSize*2;

	// Register our new Window class...
	m_sClassName = AfxRegisterWndClass(CS_OWNDC);
    if ( m_sClassName.IsEmpty() ) 
    {
       MessageBox( hParentWnd, "Error registering window class", m_pszAppName, MB_OK );
       return 1;
    }

	// Create WharfWnd and set WharfApp to remember its main window 
	// (the app will automatically quit when the window closes...)
 	m_pMainWnd=new CWharfWnd();

	// Now create/set up window specs...
	if ( !m_pMainWnd->CreateEx(
		0,                                          // exstyles 
        m_sClassName,                               // our window class name
        m_pszAppName,                               // use description for a window title													
        WS_CHILD,									// window style
        m_WharfData.borderSize, m_WharfData.borderSize, // position 
        nWndSize,nWndSize,                          // width & height of window
        hParentWnd,                                 // parent window (litestep wharf window)
        NULL                                        // no menu
        ))
	{
		MessageBox( hParentWnd, "Unable to create WharfWnd", m_pszAppName, MB_OK );
		return 1;
	}
 
	// Set normal cursor
	// Not really neccessary, but if you would like to use some special cursor,
	// this would be a good spot to set it...
	// SetCursor(LoadCursor(MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong( m_pMainWnd->m_hWnd, GWL_USERDATA, magicDWord ); 

	// according to MFC docs, the first time you show a CWnd 
	// you should pass the CWinApp.m_nCmdShow.
	m_pMainWnd->ShowWindow( m_nCmdShow );  
	// show the window
	m_pMainWnd->ShowWindow( SW_SHOWNORMAL );

	return 0;
}

void CWharfApp::ShutDown()
{	
	// destroy/remove the window...
	m_pMainWnd->DestroyWindow();
	// clean up registered class...
	UnregisterClass(m_sClassName, m_hInstance);
	// delete the WharfWnd object... the app should then quit...
	delete m_pMainWnd;
}
