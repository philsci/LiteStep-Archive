// WharfWnd.cpp : implementation file
//
// This file is part of the LS MFC SDK 0.2 by zathan.

#include "stdafx.h"
#include "Wharf.h"
#include "WharfWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWharfWnd

CWharfWnd::CWharfWnd()
{
}

CWharfWnd::~CWharfWnd()
{
}

BEGIN_MESSAGE_MAP(CWharfWnd, CWnd)
	//{{AFX_MSG_MAP(CWharfWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_RBUTTONUP()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWharfWnd diagnostics

#ifdef _DEBUG
void CWharfWnd::AssertValid() const
{
	CWnd::AssertValid();
}

void CWharfWnd::Dump(CDumpContext& dc) const
{
	CWnd::Dump(dc);
}
#endif //_DEBUG

void CWharfWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	// close any open litestep popup menus...
    ::PostMessage(::GetParent(::GetParent(::GetParent(m_hWnd))), 9183, 0, 0 );
	CWnd::OnLButtonDown(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
// CWharfWnd drawing

void CWharfWnd::OnPaint() 
{
	RECT r;
    GetClientRect(&r); 

	CPaintDC dc(this); // device context for painting

	// TODO: Add your message handler code here
	// TODO: add draw code here

	dc.SetTextAlign( TA_BASELINE | TA_CENTER );
	// set the text color to the default system color (usually black)
	dc.SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	// make background show through text whitespace...
	dc.SetBkMode(TRANSPARENT);

	// create and a new brush with the system background color...
	CBrush *pMyBrush, *pOldBrush;
	pMyBrush=new CBrush(::GetSysColor(COLOR_WINDOW));

	// select our brush and save a pointer to the old brush..,
	pOldBrush = dc.SelectObject(pMyBrush);

	// fill our wharf with a rectangle colored with MyBrush...
    dc.Rectangle(r.left, r.top, r.right, r.bottom);

	// write something... :)
	dc.TextOut((r.right / 2), (r.bottom / 2), "Hello!");

	// restore the old brush to prevent system resources leak...
	dc.SelectObject(pOldBrush);
	
	// delete the brushes...
	delete pMyBrush;
	delete pOldBrush;

	// Do not call CWnd::OnPaint() for painting messages
}

void CWharfWnd::OnRButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	// This is converted from the lssdk.c source to allow litesteps popup menus to work:
	
	// Mouse messages are here to ensure we have a good popup menu behaviour. 
	// You may insert your own custom actions
	//  9182 => Open popup menu at global coordinates specified by wParam (x) and lParam (y)
	//  9183 => Close any open popup menu
	//  See the lssdk.c for an example.

	//	replace this source if you make your own popup menu...

    RECT r;
    GetWindowRect(&r);
	
	// open litestep popup...
    ::PostMessage(::GetParent(::GetParent(::GetParent(m_hWnd))), 9182, r.top+(int)point.y, r.left+(int)point.x);
  	
	CWnd::OnRButtonUp(nFlags, point);
}

void CWharfWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	// close any open litestep popup menus...
    ::PostMessage(::GetParent(::GetParent(::GetParent(m_hWnd))), 9183, 0, 0 );
	
	CWnd::OnRButtonDown(nFlags, point);
}