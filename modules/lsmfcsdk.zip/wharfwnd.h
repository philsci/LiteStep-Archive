#if !defined(AFX_WharfWnd_H__9989A5E1_4F3D_11D2_8C1B_444553540000__INCLUDED_)
#define AFX_WharfWnd_H__9989A5E1_4F3D_11D2_8C1B_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// WharfWnd.h : header file
//
// This file is part of the LS MFC SDK 0.2 by zathan.

/////////////////////////////////////////////////////////////////////////////
// CWharfWnd view

class CWharfWnd : public CWnd
{
public:
	CWharfWnd();
	virtual ~CWharfWnd();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWharfWnd)
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CWharfWnd)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WharfWnd_H__9989A5E1_4F3D_11D2_8C1B_444553540000__INCLUDED_)
