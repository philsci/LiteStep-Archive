// Wharf.h : main header file for the WHARF DLL
//
// This file is part of the LS MFC SDK 0.2 by zathan.

#if !defined(AFX_WHARF_H__0B560932_4EE9_11D2_9A5B_00A024195318__INCLUDED_)
#define AFX_WHARF_H__0B560932_4EE9_11D2_9A5B_00A024195318__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "WharfWnd.h"

// cut'n paste from lssdk.h
#include "wharfdata.h"
#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif
// end of cut'n paste

/////////////////////////////////////////////////////////////////////////////
// CWharfApp
// See Wharf.cpp for the implementation of this class
//

class CWharfApp : public CWinApp
{
public:
	CWharfApp();
	int StartUp(HWND hParentWnd, HINSTANCE dllInst, wharfDataType *wd);
	void ShutDown();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWharfApp)
	public:
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CWharfApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CString m_sClassName;
	wharfDataType m_WharfData;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WHARF_H__0B560932_4EE9_11D2_9A5B_00A024195318__INCLUDED_)
