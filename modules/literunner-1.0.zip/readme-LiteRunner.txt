/////////////////////////////
// Module: LiteRunner 1.0
// Written By: MrJukes
// Released: 9/20/00
/////////////////////////////

description
=============
This module will execute a bang command or an executable every time
it sees that one of the specified applications has been launched.

installation
=============
LoadModule c:\litestep\literunner.dll

step.rc
==========
*OnRun "Class" "Caption" !BangOnRun !BangOnClose
  Class = Window Class
  Caption = Window Caption
  !BangOnRun = Command to be executed when program is executed
  !BangOnClose = Command to be executed when program is closed

Example:
  *OnRun "Notepad" .none !About .none
  *OnRun "ExploreWClass" "Exploring - H:\dev" notepad.exe !About

Note:
  It is important to put .none for variables you do not want to use.
  If you just skip over an unused variable without 
  putting .none LITERUNNER WILL NOT FUNCTION PROPERLY.
  There must ALWAYS be 5 entries per *OnRun command.

bangs
=======
!LiteRunnerOn		; Turns it on
!LiteRunnerOff		; Turns it off
!LiteRunnerToggle	; Toggles it on or off
!LiteRunnerIdentify	; Pops up a message box containing the window class
			; and caption of the window under the cursor

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes