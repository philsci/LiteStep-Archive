////////////////////////////////////////////////
// Instructions on how to use TrayModule 1.00 //
////////////////////////////////////////////////

///////////////////////
// Updated 8/29/2001 //
///////////////////////

LICENSE:
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, by Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html

NEW FOR VERSION 1.00
- stays on the desktop
- does not flicker like the explorer tray icons sometimes do with ATI gfx cards
- automatically expands to fit the number of icons
- vertical caption area

HOW TO INSTALL:
- No install needed, just run the .exe.
HOW TO UNINSTALL:
- Delete the program files.

INSTRUCTIONS:
-This will NOT work if explorer or another system tray program is running as the shell.  What I do is use the batch run feature of RunModule, and have it start as the first program to run.  See the "example" directory for using this as part of your shell.
CUSTOMIZE TRAYMODULE:
	All of the options are set in the "TrayModule.ini".  The items are pretty self explainatory, but the two that are probably the items that you would like to change would be:
	- "icons-per-row" in the "[layout]" section - This is the number of icons that are displayed before starting a new row
	- "caption-width" in the "[appearance]" section - This is the width in pixels that the blue caption area occupies.

PLEASE REGISTER (IT'S FREE)!
If you register you will:
- Receive notification of updates/other software that AM Productions creates
- Free tech support
- TO REGISTER visit http://am-productions.yi.org/reg.php
	- I WILL NOT KNOWINGLY DISRIBUTE YOUR E-MAIL to others.  This is only for customer support reasons.

Issues:
-Does not snap back to the edge of the screen after it has automatically expanded.

Bugs:
-Some program's popup menu's sometimes do not disappear if the window looses focus, not sure how to fix this so if you have any idea send them this way.

Bugs/Questions/Comments:
If you find a bug in the program (GASP!) you can e-mail me a clear description of the bug and how to reproduce it.  Include version number, OS version, and any other help information.
If you have a comment, suggestion, or improvement please feel free to e-mail me a description of it.

WANT TO HELP? (No programming experience required!)
	The easiest way to help it to visit the AM Productions website http://am-productions.yi.org/ and go to the "Free Stuff" page.  There you will find various services and applications.  By signing up for these services you help support the development of quality freeware.
	Still would like to help?  Well you can volunteer to beta test various AM Productions software.  To volunteer send me an email telling us what program you would like to beta test.  If you do have programming experience then just drop me a line so I can get you up to speed with everyone else.

Thank you for using TrayModule 1.00,

Anish Mistry
email: amistry@am-productions.yi.org
AM Productions: http://am-productions.yi.org/	