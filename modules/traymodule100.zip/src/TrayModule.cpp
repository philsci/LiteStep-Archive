// TrayModule.cpp: implementation of the CTrayModule class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/

#include "stdafx.h"
#include "TrayModule.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTrayModule::CTrayModule()
{

}

CTrayModule::~CTrayModule()
{
	// unregister the classes
	HINSTANCE hInstance = GetModuleHandle(NULL);
	UnregisterClass("Shell_TrayWnd",hInstance);
	UnregisterClass("TrayNotifyWnd",hInstance);
}

bool CTrayModule::Init()
{// begin Init
	// load the data from the file
	CTrayData tdData;
	tdData.SetFile("TrayModule.ini");
	int nIconSize = tdData.GetIconSize();
	int nIconDim = tdData.GetIconDim();
	int nMoveSpace = tdData.GetCaptionWidth();
	int nRowWidth = tdData.GetWidth();
	POINT ptTopLeft = tdData.GetWindowPos();

	// register the classes
	m_stwWnd.RegisterClass("Shell_TrayWnd",IDI_ICON_MAIN,NULL);
	m_tnwWnd.RegisterClass("TrayNotifyWnd",NULL,NULL);
	// create the windows
	RECT rShellTrayRect = {0,0,nIconSize*nRowWidth,0};
	// check for valid min width
	if(rShellTrayRect.right-rShellTrayRect.left < nIconSize)
		// set min width (one icon)
		rShellTrayRect.right = rShellTrayRect.left+nIconSize;
	if(m_stwWnd.Init(NULL,"",WS_EX_DLGMODALFRAME|WS_EX_TOPMOST,WS_POPUP,ptTopLeft.x,ptTopLeft.y,
		((rShellTrayRect.right-rShellTrayRect.left)/nIconSize)*nIconSize+GetSystemMetrics(SM_CXDLGFRAME)*2+GetSystemMetrics(SM_CXEDGE)+nMoveSpace,
		((rShellTrayRect.bottom-rShellTrayRect.top)/nIconSize)*nIconSize+GetSystemMetrics(SM_CYDLGFRAME)*2+GetSystemMetrics(SM_CYEDGE),
		NULL,SW_SHOWNORMAL))
	{// begin setup child
		// load the constants
		m_stwWnd.SetConstants(nMoveSpace);
		RECT rShellRect = {NULL};
		RECT rTrayRect = {NULL};
		GetClientRect(m_stwWnd.GetSafeHwnd(),&rShellRect);
		rTrayRect = rShellRect;
		rTrayRect.left += nMoveSpace;
		rTrayRect.top += 0;
		rTrayRect.right = rTrayRect.left+1;
		rTrayRect.bottom = rTrayRect.top+1;
		if(m_tnwWnd.Init(m_stwWnd.GetSafeHwnd(),"",WS_EX_STATICEDGE,WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,rTrayRect.left,rTrayRect.top,rTrayRect.right,rTrayRect.bottom,NULL,SW_SHOWNORMAL))
		{// begin setup tray
			m_tnwWnd.SetConstants(nMoveSpace,nIconSize,nIconDim);
			m_stwWnd.SetTrayWnd(&m_tnwWnd);
			return true;
		}// end setup tray
	}// end setup child
	return false;
}// end Init
