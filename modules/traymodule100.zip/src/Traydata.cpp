// TrayData.cpp: implementation of the CTrayData class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrayData.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTrayData::CTrayData()
{

}

CTrayData::~CTrayData()
{

}

void CTrayData::SetWindowPos(POINT pt)
{// begin SetWindowPos
	WriteKey("layout","x",pt.x);
	WriteKey("layout","y",pt.y);
}// end SetWindowPos

POINT CTrayData::GetWindowPos()
{// begin GetWindowPos
	POINT pt = {NULL};
	pt.x = ReadKey("layout","x",0);
	pt.y = ReadKey("layout","y",0);
	return pt;
}// end GetWindowPos

void CTrayData::SetWidth(int nIcons)
{// begin SetWidth
	WriteKey("layout","icons-per-row",nIcons);
}// end SetWidth

int CTrayData::GetWidth()
{// begin GetWidth
	return ReadKey("layout","icons-per-row",1);
}// end GetWidth

void CTrayData::SetIconSize(int nSize)
{// begin SetIconSize
	WriteKey("layout","icon-size",nSize);
}// end SetIconSize

int CTrayData::GetIconSize()
{// begin GetIconSize
	return ReadKey("layout","icon-size",17);
}// end GetIconSize

void CTrayData::SetCaptionWidth(int nWidth)
{// begin SetCaptionWidth
	WriteKey("appearance","caption-width",nWidth);
}// end SetCaptionWidth

int CTrayData::GetCaptionWidth()
{// begin GetCaptionWidth
	return ReadKey("appearance","caption-width",8);
}// end GetCaptionWidth

void CTrayData::SetIconDim(int nSize)
{// begin SetIconDim
	WriteKey("appearance","icon-dim",nSize);
}// end SetIconDim

int CTrayData::GetIconDim()
{// begin GetIconDim
	return ReadKey("appearance","icon-dim",16);
}// end GetIconDim

void CTrayData::SetSnapPixels(int nSize)
{// begin SetIconDim
	WriteKey("general","snap-pixels",nSize);
}// end SetIconDim

int CTrayData::GetSnapPixels()
{// begin GetSnapPixels
	return ReadKey("general","snap-pixels",3);
}// end GetSnapPixels

