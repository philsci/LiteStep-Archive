// ShellTrayWnd.cpp: implementation of the CShellTrayWnd class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/

#include "stdafx.h"
#include "ShellTrayWnd.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShellTrayWnd::CShellTrayWnd()
{
	m_pmwTrayNotifyWnd = NULL;
	CTrayData tdData;
	tdData.SetFile("TrayModule.ini");
	m_nSnapPixels = tdData.GetSnapPixels();
	// get the desktop rectangle for snappyness
	GetWindowRect(GetDesktopWindow(),&m_rDesktopRect);
	m_bActive = false;
	m_nMoveSpace = 0;
}

CShellTrayWnd::~CShellTrayWnd()
{

}

LRESULT CShellTrayWnd::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_SETFOCUS:
		m_bActive = true;
		OnFocus();
		break;
	case WM_KILLFOCUS:
		m_bActive = false;
		OnFocus();
		break;
	case WM_COPYDATA:
		return OnCopyData(wParam,lParam);
	case WM_DISPLAYCHANGE:
		OnDisplayChange(lParam);
		break;
	case WM_WINDOWPOSCHANGING:
		OnWindowPosChanging(lParam);
		break;
	case WM_LBUTTONDOWN:
		OnLButtonDown(wParam,lParam);
		break;
	case WM_CONTEXTMENU:
		OnContextMenu(wParam,lParam);
		break;
	case WM_PAINT:
		OnPaint();
		break;
	case WM_DESTROY:
		OnDestroy();
		break;
	}// end nMessage swtich
	return CMyWindow::WndProc(hWnd, nMessage, wParam, lParam);
}// end WndProc

bool CShellTrayWnd::OnCopyData(WPARAM wParam,LPARAM lParam)
{// begin OnCopyData
	HWND hWnd = (HWND)wParam;            // handle of sending window 
	COPYDATASTRUCT *pcdsCopyData = (COPYDATASTRUCT *)lParam;
	if(pcdsCopyData->dwData)
	{// begin data
		SHELLTRAYDATA *pstd = (SHELLTRAYDATA *)pcdsCopyData->lpData;
		NOTIFYICONDATA *pnid = (NOTIFYICONDATA *)&pstd->nid;
		// send the appropriate message
		switch(pstd->dwMessage)
		{// begin direct message
		case NIM_ADD:
			SendMessage(m_pmwTrayNotifyWnd->GetSafeHwnd(),WM_TRAYICONADD,(WPARAM)NULL,(LPARAM)pnid);
			break;
		case NIM_MODIFY:
			SendMessage(m_pmwTrayNotifyWnd->GetSafeHwnd(),WM_TRAYICONMODIFY,(WPARAM)NULL,(LPARAM)pnid);
			break;
		case NIM_DELETE:
			SendMessage(m_pmwTrayNotifyWnd->GetSafeHwnd(),WM_TRAYICONDELETE,(WPARAM)NULL,(LPARAM)pnid);
			break;
		}// end direct message
		// we processed it so return true
		return true;
	}// end data
	return false;
}// end OnCopyData

void CShellTrayWnd::SetTrayWnd(CTrayNotifyWnd *pcmWnd)
{// begin SetTrayWnd
	m_pmwTrayNotifyWnd = pcmWnd;
}// end SetTrayWnd

void CShellTrayWnd::OnWindowPosChanging(LPARAM lParam)
{// begin OnWindowPosChanging
	WINDOWPOS *pwpInfo = (WINDOWPOS *)lParam;
	POINT pt = {pwpInfo->x,pwpInfo->y};
	POINT ptNewPos = pt;
	// check to see if the window is off the desktop
	if(pt.x + pwpInfo->cx > m_rDesktopRect.right)
	{// begin move left
		ptNewPos.x = m_rDesktopRect.right-pwpInfo->cx;
	}// end move left
	if(pt.x < m_rDesktopRect.left)
	{// begin move right
		ptNewPos.x = m_rDesktopRect.left;
	}// end move right
	if(pt.y + pwpInfo->cy > m_rDesktopRect.bottom)
	{// begin move left
		ptNewPos.y = m_rDesktopRect.bottom-pwpInfo->cy;
	}// end move left
	if(pt.y < m_rDesktopRect.top)
	{// begin move right
		ptNewPos.y = m_rDesktopRect.top;
	}// end move right
	if(pt.y != ptNewPos.y || ptNewPos.x != pt.x)
	{// begin move window
		pwpInfo->x = ptNewPos.x;
		pwpInfo->y = ptNewPos.y;
	}// end move window
}// end OnWindowPosChanging

LRESULT CShellTrayWnd::OnLButtonDown(WPARAM wParam, LPARAM lParam)
{// begin OnLButtonDown
	return PostMessage(m_hWnd,WM_NCLBUTTONDOWN,HTCAPTION,MAKELPARAM(LOWORD(lParam),HIWORD(lParam)));
}// end OnLButtonDown

bool CShellTrayWnd::OnPaint()
{// begin OnPaint
	OnFocus();
	return true;
}// end OnPaint

bool CShellTrayWnd::DrawCaption(HDC hDC)
{// begin DrawCaption
	int nCaptionColor = 0;
	if(m_bActive)
		nCaptionColor = COLOR_ACTIVECAPTION;
	else
		nCaptionColor = COLOR_INACTIVECAPTION;
	SIZE sDlgFrame = {GetSystemMetrics(SM_CXDLGFRAME),GetSystemMetrics(SM_CYDLGFRAME)};
	RECT rWndRect = {NULL};
	GetClientRect(m_hWnd,&rWndRect);
	rWndRect.left += sDlgFrame.cx;
	rWndRect.top += sDlgFrame.cy;
	rWndRect.right = rWndRect.left+m_nMoveSpace-1;
	rWndRect.bottom += sDlgFrame.cy;
	HGDIOBJ hOldBrush = SelectObject(hDC,GetSysColorBrush(nCaptionColor));
	HPEN hPen = CreatePen(PS_SOLID,1,GetSysColor(nCaptionColor));
	HGDIOBJ hOldPen = SelectObject(hDC,hPen);
	Rectangle(hDC,rWndRect.left,rWndRect.top,rWndRect.right,rWndRect.bottom);
	// clean up
	DeleteObject(SelectObject(hDC,hOldBrush));
	DeleteObject(SelectObject(hDC,hOldPen));
	return true;
}// end DrawCaption

void CShellTrayWnd::OnFocus()
{// begin OnFocus
	HDC hDC = GetWindowDC(m_hWnd);
	// begin drawing
	DrawCaption(hDC);
	ReleaseDC(m_hWnd,hDC);
}// end OnFocus

bool CShellTrayWnd::OnContextMenu(WPARAM wParam, LPARAM lParam)
{// begin OnContextMenu
	if((HWND)wParam != m_hWnd)
		return false;
	POINT pt = {LOWORD(lParam),HIWORD(lParam)};
	// load the menu
	HMENU hMenu = LoadMenu(m_hInstance,MAKEINTRESOURCE(IDR_MENU_CONTEXT));
	// get the shortcut menu
	hMenu = GetSubMenu(hMenu,0);
	// display it
	TrackPopupMenu(hMenu,TPM_LEFTALIGN|TPM_TOPALIGN|TPM_LEFTBUTTON,pt.x,pt.y,0,m_hWnd,NULL);
	DestroyMenu(hMenu);
	return true;
}// end OnContextMenu

unsigned long int CShellTrayWnd::OnCommand(WPARAM wParam, LPARAM lParam)
{// begin OnCommand
	switch(wParam)
	{// begin ID switch
	case IDM_ABOUT:
		OnAbout();
		break;
	case IDM_EXIT:
		DestroyWindow(m_hWnd);
		break;
	}// end ID switch
	return 0;
}// end OnCommand

void CShellTrayWnd::OnAbout()
{// begin OnAbout
	CAbout aDlg;
	aDlg.Init(m_hWnd,IDD_DIALOG_ABOUT,true);
}// end OnAbout

void CShellTrayWnd::SetConstants(int nMoveSpace)
{// begin SetConstants
	m_nMoveSpace = nMoveSpace;
}// end SetConstants

void CShellTrayWnd::OnDestroy()
{// begin OnDestroy
	// save the window pos
	CTrayData tdData;
	tdData.SetFile("TrayModule.ini");
	RECT rWindowRect = {NULL};
	GetWindowRect(m_hWnd,&rWindowRect);
	POINT pt = {rWindowRect.left,rWindowRect.top};
	tdData.SetWindowPos(pt);
	PostQuitMessage(0);
}// end OnDestroy

void CShellTrayWnd::OnDisplayChange(LPARAM lParam)
{// begin OnDisplayChange
	m_rDesktopRect.right = LOWORD(lParam);
	m_rDesktopRect.bottom = HIWORD(lParam);
}// end OnDisplayChange