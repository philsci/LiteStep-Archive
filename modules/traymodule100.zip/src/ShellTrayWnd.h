// ShellTrayWnd.h: interface for the CShellTrayWnd class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/

#if !defined(AFX_SHELLTRAYWND_H__C1E5F744_80D4_4C06_838C_8EC288A2DB8B__INCLUDED_)
#define AFX_SHELLTRAYWND_H__C1E5F744_80D4_4C06_838C_8EC288A2DB8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GlobalWnd.h"
#include "TrayNotifyWnd.h"
#include "About.h"

#define WM_TRAYICONADD WM_USER+1
#define WM_TRAYICONMODIFY WM_USER+100
#define WM_TRAYICONDELETE WM_USER+5


class CShellTrayWnd : public CGlobalWnd  
{
struct SHELLTRAYDATA
{
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
};
public:
	void SetConstants(int nMoveSpace);
	bool DrawCaption(HDC hDC);
	void SetTrayWnd(CTrayNotifyWnd *pcmWnd);
	CShellTrayWnd();
	virtual ~CShellTrayWnd();
protected:
	void OnDestroy();
	void OnAbout();
	bool OnContextMenu(WPARAM wParam, LPARAM lParam);
	bool m_bActive;
	LRESULT WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam);
	bool OnCopyData(WPARAM wParam,LPARAM lParam);
	LRESULT OnLButtonDown(WPARAM wParam, LPARAM lParam);
	unsigned long int OnCommand(WPARAM wParam, LPARAM lParam);
	bool OnPaint();
	void OnFocus();
	void OnSize(LPARAM lParam);
	void OnDisplayChange(LPARAM lParam);
	void OnWindowPosChanging(LPARAM lParam);

	// member variables
	CTrayNotifyWnd *m_pmwTrayNotifyWnd;
	int m_nSnapPixels;
	RECT m_rDesktopRect;
	int m_nMoveSpace;

};

#endif // !defined(AFX_SHELLTRAYWND_H__C1E5F744_80D4_4C06_838C_8EC288A2DB8B__INCLUDED_)
