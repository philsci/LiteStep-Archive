// IniFile.cpp: implementation of the CIniFile class.
//
// Created: 04/01/2001 {mm/dm/yyyyy}
// Written by: Anish Mistry http://am-productions.yi.org/
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "IniFile.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIniFile::CIniFile()
{
	m_pFilePath = NULL;
	m_pFileName = NULL;
}

CIniFile::~CIniFile()
{// begin ~CIniFile
	if(m_pFilePath)
	{// begin free previous file path
		delete []m_pFilePath;
	}// end free previous file path
	if(m_pFileName)
	{// begin free previous file name
		delete []m_pFileName;
	}// end free previous file name
}// end ~CIniFile

BOOL CIniFile::WriteKey(const char *pSection, const char *pKey, const char *pData)
{// begin WriteKey
	if(!m_pFilePath)
		return false;
	return (BOOL)WritePrivateProfileString(pSection,pKey,pData,m_pFilePath); 
}// end WriteKey

int CIniFile::WriteKey(const char *pSection, const char *pKey, int nData)
{// begin WriteKey
	if(!m_pFilePath)
		return false;
	char pData[12] = {NULL};
	wsprintf(pData,"%i",nData);
	return (BOOL)WritePrivateProfileString(pSection,pKey,pData,m_pFilePath); 
}// end WriteKey

void CIniFile::SetFile(const char *pFileName)
{// begin SetFile
	if(m_pFilePath)
	{// begin free previous file path
		delete []m_pFilePath;
	}// end free previous file path
	if(m_pFileName)
	{// begin free previous file name
		delete []m_pFileName;
	}// end free previous file name
	// get the current directory to store
	int nAllocAmount = 2;	// initilize to 2 so that the NULL terminatior 
	// and '\' at the end of the CurrentDirectory are included
	char pDirectory[MAX_PATH_LENGTH] = {NULL};
	GetCurrentDirectory(MAX_PATH_LENGTH-1,pDirectory);
	// calcluate the amount of memory to allocate
	nAllocAmount += lstrlen(pDirectory)+lstrlen(pFileName)+1;
	// allocate the required amount of memory and assign it to m_pFilePath & m_pFileName
	m_pFilePath = new char[nAllocAmount];
	m_pFileName = new char[lstrlen(pFileName)+1];
	// copy the path into the new buffer
	lstrcpy(m_pFilePath,pDirectory);
	lstrcat(m_pFilePath,"\\");
	lstrcat(m_pFilePath,pFileName);
	// copy name
	lstrcpy(m_pFileName,pFileName);
}// end SetFile

unsigned long int CIniFile::ReadKey(const char *pSection, const char *pKey, const char *pDefault,char *pOutputBuffer, unsigned long nOutputBufferLength)
{// begin ReadKey
	if(!m_pFilePath)
		return false;
	return GetPrivateProfileString(pSection,pKey,pDefault,pOutputBuffer,nOutputBufferLength,m_pFilePath);
}// end ReadKey

int CIniFile::ReadKey(const char *pSection, const char *pKey, int nDefault)
{// begin ReadKey
	if(!m_pFilePath)
		return false;
	return (long int)GetPrivateProfileInt(pSection,pKey,nDefault,m_pFilePath);
}// end ReadKey

const char *CIniFile::GetFilePath()
{// begin GetFilePath
	return m_pFilePath;
}// end GetFilePath

const char *CIniFile::GetFileName()
{// begin GetFileName
	return m_pFileName;
}// end GetFileName
