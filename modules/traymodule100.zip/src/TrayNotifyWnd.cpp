// TrayNotifyWnd.cpp: implementation of the CTrayNotifyWnd class.
//
//////////////////////////////////////////////////////////////////////
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of the Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/

#include "stdafx.h"
#include "TrayNotifyWnd.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTrayNotifyWnd::CTrayNotifyWnd()
{
	m_vIcons.resize(0);
	m_mwWnd.RegisterClass("TrayIconWnd",NULL,NULL);
	m_nMoveSpace = 0;
	m_nIconSize = 0;
	m_nIconDim = 0;
}

CTrayNotifyWnd::~CTrayNotifyWnd()
{
	for(int i = m_vIcons.size()-1;i > -1;i--)
	{
		delete m_vIcons[i];
	}
	// empty the vector
	m_vIcons.clear();
	m_vIcons.resize(0);
	// unregister the tray icon class
	UnregisterClass("TrayIconWnd",m_hInstance); 
}

ATOM CTrayNotifyWnd::RegisterClass(char *pWindowClass,unsigned long int nIconID, unsigned long int nMenuID)
{// begin RegisterClass
	lstrcpy(m_pWindowClass,pWindowClass);
	WNDCLASSEX wcex = {NULL};

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)(void *)m_Thunk;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= m_hInstance;
	wcex.hIcon			= (HICON)LoadImage(m_hInstance, (LPCTSTR)nIconID,IMAGE_ICON,32,32,LR_DEFAULTCOLOR);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_3DFACE+1);
	wcex.lpszMenuName	= (LPCSTR)nMenuID;
	wcex.lpszClassName	= m_pWindowClass;
	wcex.hIconSm		= (HICON)LoadImage(m_hInstance, (LPCTSTR)nIconID,IMAGE_ICON,16,16,LR_DEFAULTCOLOR);
	wcex.cbSize = sizeof(wcex); 

	return RegisterClassEx(&wcex);
}// end RegisterClass

LRESULT CTrayNotifyWnd::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_TRAYICONMODIFY:
	case WM_TRAYICONADD:
		OnTrayIconAdd(lParam);
		break;
//		OnTrayIconModify(lParam);
//		break;
	case WM_TRAYICONDELETE:
		OnTrayIconDelete(lParam);
		break;
//	case WM_ERASEBKGND:	// prevent flickering
//		return 0;
	case WM_PAINT:
		// redraw the border
		CMyWindow::WndProc(hWnd, nMessage, wParam, lParam);
		OnPaint();
		return 0;
	}// end nMessage swtich
	return CMyWindow::WndProc(hWnd, nMessage, wParam, lParam);
}// end WndProc

bool CTrayNotifyWnd::OnTrayIconAdd(LPARAM lParam)
{// begin OnTrayIconAdd
	NOTIFYICONDATA *pnidData = (NOTIFYICONDATA *)lParam;
	// add it to the list
	// first check to see if it is already in the list
	for(int i = 0;i < m_vIcons.size();i++)
	{// begin search
		if(m_vIcons[i]->GetOwnerWnd() == pnidData->hWnd && m_vIcons[i]->IsID(pnidData->uID))
		{// begin already there
			m_vIcons[i]->SetData(pnidData);
			return true;
		}// end already there
	}// end search
	// create a new icon window
	POINT pt = GetIconPos(m_vIcons.size());
	m_vIcons.resize(m_vIcons.size()+1);

	// allocate memory
	m_vIcons[m_vIcons.size()-1] = new CTrayIconWnd;
	if(!m_vIcons[m_vIcons.size()-1]->Init(m_hWnd,pt.x,pt.y,m_nIconSize,m_nIconSize))
		return false;
	m_vIcons[m_vIcons.size()-1]->SetConstants(m_nIconSize,m_nIconDim);
	// calculate new window size
	RECT rClientRect = {NULL};
	HWND hShellTrayWnd = GetParent(m_hWnd);
	GetClientRect(hShellTrayWnd,&rClientRect);
	SIZE sSize = {NULL};
	if(m_vIcons.size()*m_nIconSize > rClientRect.right-m_nMoveSpace)
		sSize.cx = ((rClientRect.right-m_nMoveSpace)/m_nIconSize)*m_nIconSize;
	else
		sSize.cx = pt.x+m_nIconSize;
	sSize.cy = pt.y+m_nIconSize;

	SIZE sBorderSize = {NULL};
	sBorderSize.cx = GetSystemMetrics(SM_CXEDGE);
	sBorderSize.cy = GetSystemMetrics(SM_CYEDGE);
	// change the window size to fit
	SetWindowPos(m_hWnd,HWND_TOP,0,0,sSize.cx+sBorderSize.cx,sSize.cy+sBorderSize.cy,SWP_NOMOVE|SWP_NOOWNERZORDER);
	// check to see if the shell window is big enough
	if(rClientRect.bottom < sSize.cy)
	{// begin enlagre window
		SIZE sDlgFrame = {GetSystemMetrics(SM_CXDLGFRAME),GetSystemMetrics(SM_CYDLGFRAME)};
		RECT rWindowRect = {NULL};
		GetWindowRect(hShellTrayWnd,&rWindowRect);
		MoveWindow(hShellTrayWnd,rWindowRect.left,rWindowRect.top,
			((rClientRect.right-rClientRect.left)/m_nIconSize)*m_nIconSize+sBorderSize.cx+sDlgFrame.cx*2+m_nMoveSpace,
			sSize.cy+sBorderSize.cy+sDlgFrame.cy*2,
			true);
	}// end enlarge window
	// set the icon info
	m_vIcons[m_vIcons.size()-1]->SetData(pnidData);
	return true;
}// end OnTrayIconAdd

bool CTrayNotifyWnd::OnTrayIconModify(LPARAM lParam)
{// begin OnTrayIconModify
	NOTIFYICONDATA *pnidData = (NOTIFYICONDATA *)lParam;
	for(int i = 0;i < m_vIcons.size();i++)
	{// begin search
		if(IsWindow(m_vIcons[i]->GetOwnerWnd()) && m_vIcons[i]->GetOwnerWnd() == pnidData->hWnd && m_vIcons[i]->IsID(pnidData->uID))
		{// begin already there
			m_vIcons[i]->SetData(pnidData);
			return true;
		}// end already there
	}// end search
	return false;
}// end OnTrayIconModify

bool CTrayNotifyWnd::OnTrayIconDelete(LPARAM lParam)
{// begin OnTrayIconDelete
	NOTIFYICONDATA *pnidData = (NOTIFYICONDATA *)lParam;
	for(int i = 0;i < m_vIcons.size();i++)
	{// begin search
		if(m_vIcons[i]->GetOwnerWnd() == pnidData->hWnd && m_vIcons[i]->IsID(pnidData->uID))
		{// begin already there
			HWND hDeleteWnd = m_vIcons[i]->GetSafeHwnd();
			ShowWindow(m_vIcons[i]->GetSafeHwnd(),SW_HIDE);
			// destroy the window
			DestroyWindow(hDeleteWnd);
			delete m_vIcons[i];
			m_vIcons.erase(&m_vIcons[i]);
			RepositionIcons(i);
			return true;
		}// end already there
	}// end search
	return false;
}// end OnTrayIconDelete

POINT CTrayNotifyWnd::GetIconPos(int nPos)
{// begin GetIconPos
	POINT pt = {NULL};
	RECT rClientRect = {NULL};
	GetClientRect(GetParent(m_hWnd),&rClientRect);
	// calculate icon position
	pt.x = nPos%((rClientRect.right-m_nMoveSpace)/m_nIconSize)*m_nIconSize;
	pt.y = nPos/((rClientRect.right-m_nMoveSpace)/m_nIconSize)*m_nIconSize;
	return pt;
}// end GetIconPos

bool CTrayNotifyWnd::OnPaint()
{// begin OnPaint
	// redraw all of the tray icons
	for(int i = 0;i < m_vIcons.size();i++)
		SendMessage(m_vIcons[i]->GetSafeHwnd(),WM_PAINT,0,0);
	return true;
}// end OnPaint

void CTrayNotifyWnd::RepositionIcons(int nStartIndex)
{// begin RepositionIcons
	// calculate new window size
	SIZE sBorderSize = {GetSystemMetrics(SM_CXEDGE),GetSystemMetrics(SM_CYEDGE)};
	SIZE sDlgFrame = {GetSystemMetrics(SM_CXDLGFRAME),GetSystemMetrics(SM_CYDLGFRAME)};
	RECT rClientRect = {NULL};
	SIZE sSize = {NULL};
	HWND hShellTrayWnd = GetParent(m_hWnd);
	GetClientRect(hShellTrayWnd,&rClientRect);
	POINT pt = {NULL};
	for(int i = nStartIndex;i < m_vIcons.size();i++)
	{// begin set new position
		pt = GetIconPos(i);
		// move the icon window
		MoveWindow(m_vIcons[i]->GetSafeHwnd(),pt.x,pt.y,m_nIconSize,m_nIconSize,true);
	}// end set new position

	pt = GetIconPos(i-1);
	if(m_vIcons.size()*m_nIconSize > rClientRect.right-m_nMoveSpace)
		sSize.cx = ((rClientRect.right-m_nMoveSpace)/m_nIconSize)*m_nIconSize;
	else
		sSize.cx = pt.x+m_nIconSize;
	sSize.cy = pt.y+m_nIconSize;
	// change the window size to fit
	SetWindowPos(m_hWnd,HWND_TOP,0,0,sSize.cx+sBorderSize.cx,sSize.cy+sBorderSize.cy,SWP_NOMOVE|SWP_NOOWNERZORDER);
	// change shell window to fit
	RECT rWindowRect = {NULL};
	GetWindowRect(hShellTrayWnd,&rWindowRect);
	MoveWindow(hShellTrayWnd,rWindowRect.left,rWindowRect.top,
		((rClientRect.right-rClientRect.left)/m_nIconSize)*m_nIconSize+sBorderSize.cx+sDlgFrame.cx*2+m_nMoveSpace,
		sSize.cy+sBorderSize.cy+sDlgFrame.cy*2,
		true);
}// end RepositionIcons

void CTrayNotifyWnd::SetConstants(int nMoveSpace, int nIconSize, int nIconDim)
{// begin SetConstants
	m_nMoveSpace = nMoveSpace;
	m_nIconSize = nIconSize;
	m_nIconDim = nIconDim;
}// end SetConstants
