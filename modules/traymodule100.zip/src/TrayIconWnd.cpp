// TrayIconWnd.cpp: implementation of the CTrayIconWnd class.
//
/*
Copyright 2001 Anish Mistry. All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

   1. Redistributions of source code must retain the above copyright notice, 
   this list of conditions and the following disclaimer.
   2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation 
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY ANISH MISTRY ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS 
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies,
either expressed or implied, of Anish Mistry or AM Productions.

* Variation of the FreeBSD License. http://www.freebsd.org/copyright/freebsd-license.html
*/
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TrayIconWnd.h"
#include <commctrl.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTrayIconWnd::CTrayIconWnd()
{
	m_hInstance = GetModuleHandle(NULL);
	m_hWnd = NULL;
	// init the ThunkData with the this pointer so that this can be subclassed
	ThunkInit(m_Thunk, this);
	m_hToolTipWnd = NULL;
	m_wpOldWndProc = NULL;
	m_nidData.cbSize = sizeof(NOTIFYICONDATA);
	m_nidData.hIcon = NULL;
	m_nidData.hWnd = NULL;
	lstrcpy(m_nidData.szTip,"");
	m_nidData.uCallbackMessage = NULL;
	m_nidData.uFlags = 0;
	m_nidData.uID = 1;
	m_nIconSize = 0;
	m_nIconDim = 0;
}

CTrayIconWnd::~CTrayIconWnd()
{
	if(m_hWnd)
	{
		OnDestroy();// remove subclassing
	}

}

void CTrayIconWnd::SetData(NOTIFYICONDATA *pnidData)
{// begin SetData
	if(pnidData)
	{// begin set new data
		m_nidData.uFlags = pnidData->uFlags;
		m_nidData.hWnd = pnidData->hWnd;
		m_nidData.cbSize = pnidData->cbSize;
		m_nidData.uID = pnidData->uID;
		if(m_nidData.uFlags & NIF_MESSAGE)
			m_nidData.uCallbackMessage = pnidData->uCallbackMessage;
		if(m_nidData.uFlags & NIF_ICON)
		{// begin new icon
			DestroyIcon(m_nidData.hIcon);
			m_nidData.hIcon = DuplicateIcon(m_hInstance,pnidData->hIcon);//CopyIcon(pnidData->hIcon);
		}// end new icon
		// convert the unicode string to char *
		if(m_nidData.uFlags & NIF_TIP)
		{// begin tip
			char pTip[64] = {NULL};
			for(int i = 0;i < 64;i+=2)
			{// begin convert
				pTip[i/2] = pnidData->szTip[i];
			}// end convert
			// set new tooltip parameters
			TOOLINFO tiTip = {NULL};
			tiTip.cbSize = sizeof(TOOLINFO); 
			tiTip.hwnd = m_hWnd; 
			tiTip.uId = 1;
			tiTip.hinst = m_hInstance; 
			tiTip.lpszText = pTip;
			// save tip
			lstrcpy(m_nidData.szTip,pTip);
			SendMessage(m_hToolTipWnd,TTM_UPDATETIPTEXT,(WPARAM)0,(LPARAM)&tiTip);
		}// end tip
		// paint the icon
		HDC hIconWndDC = GetWindowDC(m_hWnd);
		OnPaint((WPARAM)hIconWndDC,0);
		ReleaseDC(m_hWnd,hIconWndDC);
	}// end set new data
}// end SetData

LRESULT CTrayIconWnd::WndProc(HWND hWnd,UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin WndProc
	switch(nMessage)
	{// begin nMessage switch
	case WM_LBUTTONDBLCLK:
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MBUTTONDBLCLK:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_MOUSEMOVE:
	case WM_RBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
		// relay message to the tooltip window
		RelayTooltipEvent(nMessage,wParam,lParam);
		// redirect this message to the owner
		if(!RedirectMessage(nMessage))
			return 0;
		break;
	case WM_ERASEBKGND:	// prevent flickering
		return 0;
	case WM_PAINT:
		OnPaint(wParam,lParam);
		break;
	case WM_DESTROY:
		OnDestroy();
		break;
	}// end nMessage swtich
	return CallWindowProc(m_wpOldWndProc,hWnd, nMessage, wParam, lParam);
}// end WndProc

LRESULT CTrayIconWnd::RedirectMessage(UINT nMessage)
{// begin RedirectMessage
	if(!IsWindow(m_nidData.hWnd))
	{// begin owner no long exists
		// remove this window
		return PostMessage(GetParent(m_hWnd),WM_TRAYICONDELETE,0,(LPARAM)&m_nidData);
	}// end owner no longer exists
	if(m_nidData.uFlags & NIF_MESSAGE || m_nidData.uCallbackMessage)
	{// begin redirect
		return PostMessage(m_nidData.hWnd,m_nidData.uCallbackMessage,m_nidData.uID,nMessage);
	}// end redirect
	return 0;
}// end RedirectMessage

void CTrayIconWnd::RelayTooltipEvent(UINT nMessage,WPARAM wParam,LPARAM lParam)
{// begin RelayTooltipEvent
	POINT pt = {LOWORD(lParam),HIWORD(lParam)};
	MSG msg = {NULL};
	msg.hwnd = m_hWnd;
	msg.message = nMessage;
	msg.wParam = wParam;
	msg.lParam = lParam;
	msg.time = GetTickCount();
	msg.pt = pt;
	PostMessage(m_hToolTipWnd,TTM_RELAYEVENT,(WPARAM)0,(LPARAM)&msg);
}// end RelayTooltipEvent

unsigned long int CTrayIconWnd::Init(HWND hParent, int x, int y,int nWidth, int nHeight)
{// begin Init
	m_hWnd = CreateWindowEx(NULL,"TrayIconWnd","",WS_CHILD,x,y,nWidth,nHeight,hParent,NULL,m_hInstance,NULL);
	if(!m_hWnd)
		return 0;
	if(!m_hToolTipWnd)
	{// begin init tooltips
		// Ensure that the common control DLL is loaded  
		InitCommonControls();
		// create a m_hToolTipWnd control. 
		m_hToolTipWnd = CreateWindow( TOOLTIPS_CLASS, NULL,
								WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP,
								CW_USEDEFAULT, CW_USEDEFAULT,
								CW_USEDEFAULT, CW_USEDEFAULT,
								m_hWnd, NULL, NULL,	NULL);

		SetWindowPos(m_hToolTipWnd, HWND_TOPMOST,0, 0, 0, 0,
					 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		// create a tooltip area
		TOOLINFO tiTip = {NULL};
		// set new tooltip parameters
		tiTip.cbSize = sizeof(TOOLINFO); 
		tiTip.hwnd = m_hWnd; 
		tiTip.uId = 1;
		tiTip.hinst = m_hInstance; 
		tiTip.uFlags = TTF_SUBCLASS;
		GetClientRect(m_hWnd,&tiTip.rect);
		tiTip.lpszText = (LPSTR)"";
		SendMessage(m_hToolTipWnd, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &tiTip);
	}// end init tooltips
	m_wpOldWndProc = (WNDPROC)SetWindowLong(m_hWnd,GWL_WNDPROC,(LONG)(void *)m_Thunk);
	// display the window
	ShowWindow(m_hWnd, SW_SHOWNORMAL);
	UpdateWindow(m_hWnd);
	return 1;
}// end Init

bool CTrayIconWnd::OnDestroy()
{// begin OnDestroy
	// destroy the icon
	DestroyIcon(m_nidData.hIcon);
	// destroy the tooltip
	TOOLINFO ti = {NULL};
	ti.cbSize = sizeof(TOOLINFO); 
	ti.hwnd = m_hWnd; 
	ti.uId = 1;
	// close the tooltip (if it is open)
	SendMessage(m_hToolTipWnd, TTM_POP , 0, 0);
	// delete the tooltip
	SendMessage(m_hToolTipWnd, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	// destroy the tooltip window
	DestroyWindow(m_hToolTipWnd);
	// remove subclassing
	SetWindowLong(m_hWnd,GWL_WNDPROC,(LONG)m_wpOldWndProc);
	m_hWnd = NULL;
	return true;
}// end OnDestroy

bool CTrayIconWnd::OnPaint(WPARAM wParam,LPARAM lParam)
{// begin OnPaint
	// draw icon
	if(!m_nidData.hIcon)
		return false;
	// draw the icon
	HDC hDC = GetWindowDC(m_hWnd);
	if(!hDC)
		return false;
	HDC hMemDC = CreateCompatibleDC(hDC);
	HBITMAP hBitmap = CreateCompatibleBitmap(hDC,m_nIconSize,m_nIconSize);
	HGDIOBJ hOldBitmap = SelectObject(hMemDC,hBitmap);
	HGDIOBJ hOldBrush = SelectObject(hMemDC,GetSysColorBrush(COLOR_3DFACE));
	// draw to the memory DC
	BitBlt(hMemDC,0,0,m_nIconSize,m_nIconSize,NULL,0,0,WHITENESS);
	Rectangle(hMemDC,-1,-1,m_nIconSize+1,m_nIconSize+1);
	DrawIconEx(hMemDC,0,0,m_nidData.hIcon,m_nIconDim,m_nIconDim,0,NULL,DI_NORMAL);
	// copy to the screen DC
	BitBlt(hDC,0,0,m_nIconSize,m_nIconSize,hMemDC,0,0,SRCCOPY);
	// cleanup
	DeleteObject(SelectObject(hMemDC,hOldBitmap));
	DeleteObject(SelectObject(hMemDC,hOldBrush));
	DeleteDC(hMemDC);
	ReleaseDC(m_hWnd,hDC);
	return true;
}// end OnPaint

bool CTrayIconWnd::IsID(UINT nID)
{// begin IsID
	if(m_nidData.uID == nID)
		return true;
	return false;
}// end IsID

HWND CTrayIconWnd::GetSafeHwnd()
{// begin GetSafeHwnd
	return m_hWnd;
}// end GetSafeHwnd

HWND CTrayIconWnd::GetOwnerWnd()
{// begin GetOwnerWnd
	return m_nidData.hWnd;
}// end GetOwnerWnd

void CTrayIconWnd::SetConstants(int nIconSize, int nIconDim)
{// begin SetConstants
	m_nIconSize = nIconSize;
	m_nIconDim = nIconDim;
}// end SetConstants
