//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CTrayModule Test.rc
//
#define IDI_ICON_MAIN                   101
#define IDR_MENU_CONTEXT                102
#define IDD_DIALOG_ABOUT                103
#define IDC_BUTTON_WEBSITE              1006
#define IDC_BUTTON_EMAIL                1007
#define IDC_BUTTON_REGISTER             1008
#define IDM_EXIT                        40001
#define IDM_ABOUT                       40002
#define ID__TRAYMODULE                  40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
