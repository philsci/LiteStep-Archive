#include <windows.h>
#include <lsapi.h>
#include "exports.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();
void SetWindowBitmapRgn(HWND hwnd, HDC hdc);
void LoadFromFile(const char*);
void SaveToFile(const char*);

int ScreenX, ScreenY;
char* szAppName = "LSClipboard";
char* szVersion = "LSClipboard 2.1 (MrJukes)\0";
char myini[MAX_PATH] = "";
HWND hwndMain, hwndParent, hwndList, hwndNextCB;
int X, Y, W, H;
int TB, RB, BB, LB;
HBITMAP hbmpBG;
BOOL UPDATE=TRUE;
BOOL ONTOP=FALSE;
COLORREF list_bg, list_fg, list_fg_sel;

void BangOnTop(HWND caller, const char* args)
{
	SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	ONTOP=TRUE;
}

void BangNotOnTop(HWND caller, const char* args)
{
	SetWindowPos(hwndMain, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	ONTOP=FALSE;
}

void BangToggleOnTop(HWND caller, const char* args)
{
	if (ONTOP) BangNotOnTop(caller, args);
	else BangOnTop(caller, args);
}

void BangShow(HWND caller, const char* args) 
{
	ShowWindow(hwndMain, SW_SHOW);
	SetFocus(hwndList);
}

void BangHide(HWND caller, const char* args) 
{ 
	ShowWindow(hwndMain, SW_HIDE);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangClear(HWND caller, const char* args)
{
	SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
}

void LoadSetup()
{
	char temp[256] = "";

	GetWindowsDirectory(myini, MAX_PATH);
	strcat(myini, "\\lsclipboard.ini");
	
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!CBShow", BangShow);
	AddBangCommand("!CBHide", BangHide);
	AddBangCommand("!CBToggle", BangToggle);
	AddBangCommand("!CBClear", BangClear);
	AddBangCommand("!CBOnTop", BangOnTop);
	AddBangCommand("!CBNotOnTop", BangNotOnTop);
	AddBangCommand("!CBToggleOnTop", BangToggleOnTop);

	X = GetRCInt("CBX", 100);
	if (X < 0) X = ScreenX+X;
	Y = GetRCInt("CBY", 100);
	if (Y < 0) Y = ScreenY+Y;
	W = GetRCInt("CBWidth", 150);
	H = GetRCInt("CBHeight", 150);

	TB = GetRCInt("CBBorderTop", 5);
	RB = GetRCInt("CBBorderRight", 5);
	BB = GetRCInt("CBBorderBottom", 5);
	LB = GetRCInt("CBBorderLeft", 5);

	GetRCString("CBBgBmp", temp, "", 256);
	if (strlen(temp))
	{
		hbmpBG = LoadLSImage(temp, temp);
	}

	list_bg = GetRCColor("CBColorListBg", 0x00FFFFFF);
	list_fg = GetRCColor("CBColorListFg", 0x00000000);
	list_fg_sel = GetRCColor("CBColorListFgSel", 0x00FFFFFF);

}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	int msgs[] = {LM_GETREVID, 0};

	hwndParent = parent;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  szAppName, szAppName, 
							  WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
							  X, Y, 
							  W, H, 
							  NULL, NULL, dllInst, NULL);
		
	if (!hwndMain) return 1;

	SetWindowLong(hwndMain, GWL_USERDATA, 0x49474541);

	hwndList = CreateWindow("LISTBOX", "", 
							WS_CHILD | WS_VISIBLE | LBS_HASSTRINGS | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | LBS_WANTKEYBOARDINPUT | LBS_OWNERDRAWVARIABLE,
							RB, TB,
							W-RB-LB, H-BB-TB,
							hwndMain, NULL, dllInst, NULL); 

	LoadFromFile(myini);

	hwndNextCB = SetClipboardViewer(hwndMain);

	if (GetRCBool("CBAlwaysOnTop", TRUE))
	{
		SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		ONTOP=TRUE;
	}

	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

	if (GetRCBool("CBStartHidden", FALSE))
	{
		ShowWindow(hwndMain, SW_SHOWNORMAL);
	}
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	int msgs[] = {LM_GETREVID, 0};

	SaveToFile(myini);

	RemoveBangCommand("!CBShow");
	RemoveBangCommand("!CBHide");
	RemoveBangCommand("!CBToggle");
	RemoveBangCommand("!CBClear");
	RemoveBangCommand("!CBOnTop");
	RemoveBangCommand("!CBNotOnTop");
	RemoveBangCommand("!CBToggleOnTop");

	ChangeClipboardChain(hwndMain, hwndNextCB);
	
	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	DestroyWindow(hwndMain);

	UnregisterClass(szAppName, dll);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == LM_GETREVID)
	{
		LPSTR buf = (LPSTR)(lParam);

		switch (wParam)
		{
			case 0:
				sprintf(buf, "%s", szVersion);
			break;
			case 1:
				sprintf(buf, "%s", szVersion);
			break;
			default:
				sprintf(buf, "%s", szVersion);
		}
		return strlen(buf);
	}

	switch (msg)
	{
		case WM_ERASEBKGND: return 0;
		case WM_NCHITTEST: 
		{
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			RECT r;
			long htx=0;
			long hty=0;
			long ht=0;

			GetWindowRect(hwnd, &r);

			if ((y - r.top) < TB) hty=HTCAPTION;
			else if ((y-r.top) > r.bottom-r.top-BB) hty=HTBOTTOM;
			else hty=0;
			
			if ((x-r.left) < LB) htx=HTLEFT;
			else if ((x-r.left) > r.right-r.left-RB) htx=HTRIGHT;
			else htx=0;

			if (htx && hty)
			{
				if (hty == HTBOTTOM)
				{
					if (htx == HTLEFT) ht=HTBOTTOMLEFT;
					else if (htx == HTRIGHT) ht = HTBOTTOMRIGHT;
				}
			}
			else if (htx) ht = htx;
			else if (hty) ht = hty;
			else ht=HTCLIENT;

			return ht;
		}
		return 0;

		case WM_NCPAINT:
		case WM_PAINT:
		{
			RECT r;
			static RECT or;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp;
			HBITMAP oldsrc, oldbuf;

			GetClientRect(hwnd, &r);
			bufbmp = CreateCompatibleBitmap(hdc, r.right, r.bottom);
			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			if (hbmpBG)
			{
				BITMAP bmp;
					
				GetObject(hbmpBG, sizeof(bmp), &bmp);
				oldsrc = (HBITMAP)SelectObject(src, hbmpBG);

				// Top Left Corner
				StretchBlt(buf, 0, 0, RB, TB, src, 0, 0, RB, TB, SRCCOPY);

				// Top Right Corner
				StretchBlt(buf, r.right-RB, 0, RB, TB, src, bmp.bmWidth-RB, 0, RB, TB, SRCCOPY);

				// Top
				StretchBlt(buf, LB, 0, r.right-RB-LB, TB, src, LB, 0, bmp.bmWidth-RB-LB, TB, SRCCOPY);

				// Bottom Left Corner
				StretchBlt(buf, 0, r.bottom-BB, RB, TB, src, 0, bmp.bmHeight-BB, RB, TB, SRCCOPY);

				// Bottom Right Corner
				StretchBlt(buf, r.right-RB, r.bottom-BB, RB, TB, src, bmp.bmWidth-RB, bmp.bmHeight-BB, RB, TB, SRCCOPY);

				// Bottom
				StretchBlt(buf, LB, r.bottom-BB, r.right-LB-RB, BB, src, LB, bmp.bmHeight-BB, bmp.bmWidth-LB-RB, BB, SRCCOPY);
						
				// Left
				StretchBlt(buf, 0, TB, LB, r.bottom-TB-BB, src, 0, TB, LB, bmp.bmHeight-TB-BB, SRCCOPY);
						
				// Right
				StretchBlt(buf, r.right-RB, TB, RB, r.bottom-TB-BB, src, bmp.bmWidth-RB, TB, RB, bmp.bmHeight-TB-BB, SRCCOPY);
						
				// Client
				StretchBlt(buf, LB, TB, r.right-LB-RB, r.bottom-TB-BB, src, LB, TB, bmp.bmWidth-LB-RB, bmp.bmHeight-TB-BB, SRCCOPY);

				if (r.right != or.right || r.bottom != or.bottom)
				{
					SetRect(&or, r.left, r.top, r.right, r.bottom);
					SetWindowBitmapRgn(hwnd, buf);
				}
			}

			BitBlt(hdc, 0, 0, r.right, r.bottom, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			DeleteObject(oldbuf);
			SelectObject(src, oldsrc);
			DeleteDC(src);
			DeleteObject(oldsrc);
			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
		}
		break;

		case WM_MEASUREITEM:
		{
			LPMEASUREITEMSTRUCT mis = (LPMEASUREITEMSTRUCT)lParam;
			RECT r;
			int len = SendMessage(hwndList, LB_GETTEXTLEN, mis->itemID, 0);
			char* temp = new char[len];
			SendMessage(hwndList, LB_GETTEXT, (WPARAM)mis->itemID, (LPARAM)temp);
			SetRect(&r, 0, 0, W-RB-LB, 0);
			DrawText(GetDC(hwndList), temp, -1, &r, DT_CALCRECT | DT_EDITCONTROL | DT_WORDBREAK | DT_EXPANDTABS);

			mis->itemWidth = W-RB-LB;
			mis->itemHeight = r.bottom;
		}
		return TRUE;

		case WM_DRAWITEM:
		{
			LPDRAWITEMSTRUCT dis = (LPDRAWITEMSTRUCT)lParam;
					
			HBRUSH hbr = CreateSolidBrush(list_bg);
			RECT r;
			GetClientRect(hwndList, &r);
			FillRect(dis->hDC, &r, hbr);
			DeleteObject(hbr);

			int count = SendMessage(hwndList, LB_GETCOUNT, 0, 0);
			int cursel = SendMessage(hwndList, LB_GETCURSEL, 0, 0);

			for (int x=0; x<count; x++)
			{
				RECT ir;
				SendMessage(hwndList, LB_GETITEMRECT, x, (LPARAM)&ir);

				int len = SendMessage(hwndList, LB_GETTEXTLEN, x, 0);
				char* temp = new char[len];
				SendMessage(hwndList, LB_GETTEXT, (WPARAM)x, (LPARAM)temp);

				SetBkMode(dis->hDC, TRANSPARENT);

				if (x == cursel)
				{
					SetTextColor(dis->hDC, list_fg_sel);
				}
				else
				{
					SetTextColor(dis->hDC, list_fg);
				}
					
				DrawText(dis->hDC, temp, -1, &ir, DT_LEFT | DT_EDITCONTROL | DT_WORDBREAK | DT_EXPANDTABS);
			}
		}
		return TRUE;

		case WM_VKEYTOITEM:
		{
			if (LOWORD(wParam) == VK_DELETE)
			{
				int cursel = SendMessage(hwndList, LB_GETCURSEL, 0, 0);
				SendMessage(hwndList, LB_DELETESTRING, (WPARAM)cursel, 0);
				SendMessage(hwndList, LB_SETCURSEL, cursel, 0);
			}
		}
		break;

		case WM_CHANGECBCHAIN:
		{
			if ((HWND)wParam == hwndNextCB)
			{
				hwndNextCB = (HWND)lParam;
			}
			else
			{
				SendMessage(hwndNextCB, msg, wParam, lParam);
			}
		}
		return 0;

		case WM_DRAWCLIPBOARD:
		{
			if (UPDATE)
			{
				if (OpenClipboard(hwndMain))
				{
					if (IsClipboardFormatAvailable(CF_TEXT))
					{
						HANDLE cbdata = GetClipboardData(CF_TEXT);
						if (cbdata)
						{
							if (strlen((char*)cbdata))
							{
								int index = SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)(char*)cbdata);
								SendMessage(hwndList, LB_SETTOPINDEX, (WPARAM)index, 0);
								SendMessage(hwndList, LB_SETCURSEL, index, 0);
							}
						}
					}
					CloseClipboard();
				}
			}
			else UPDATE=TRUE;
		}
		return SendMessage(hwndNextCB, msg, wParam, lParam);

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case LBN_DBLCLK:
				{
					int cursel = SendMessage(hwndList, LB_GETCURSEL, 0, 0);
					if (cursel > -1)
					{
						int len = SendMessage(hwndList, LB_GETTEXTLEN, (WPARAM)cursel, 0);
						char* temp = new char[len];
						SendMessage(hwndList, LB_GETTEXT, (WPARAM)cursel, (LPARAM)temp);
						if (OpenClipboard(hwndMain))
						{
							EmptyClipboard();
							HGLOBAL hglbCopy = GlobalAlloc(GMEM_MOVEABLE, 
													(len + 1) * sizeof(TCHAR)); 
							if (hglbCopy)
							{
								LPTSTR lptstrCopy;
								lptstrCopy = (LPTSTR)GlobalLock(hglbCopy); 
								memcpy(lptstrCopy, temp, 
								len * sizeof(TCHAR)); 
								lptstrCopy[len] = (TCHAR)0;
								GlobalUnlock(hglbCopy);
								UPDATE=FALSE;
								SetClipboardData(CF_TEXT, hglbCopy);
							}
							CloseClipboard();
						}
					}
				}
				break;
			}
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
					
			if (!(pos->flags & SWP_NOMOVE))
			{		
				if (pos->x+W >= ScreenX-5) pos->x = ScreenX - W;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+H >= ScreenY-5) pos->y = ScreenY - H;
				else if (pos->y <= 5) pos->y = 0;

				X=pos->x;
				Y=pos->y;
			}

			if ((W != pos->cx || H != pos->cy) && (pos->cx && pos->cy))
			{
				W = pos->cx;
				H = pos->cy; 

				SetWindowPos(hwndList, NULL, RB, TB, W-RB-LB, H-TB-BB, SWP_NOZORDER);
				InvalidateRect(hwnd, NULL, TRUE);
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void SetWindowBitmapRgn(HWND hwnd, HDC hdc)
{
	if (hwnd && hdc)
	{
		int x=0, y=0;
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		RECT r;
		GetClientRect(hwnd, &r);
		hMainRgn = CreateRectRgn(0, 0, r.right, r.bottom);

		// Top Border
		for (y=0; y <= TB; y++)
		{
			for (x=0; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}

		// Left and Right Borders
		for (y=TB; y <= r.bottom-BB; y++)
		{
			for (x=0; x < LB; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}

			for (x=r.right-RB; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		// Bottom Border
		for (y=r.bottom-BB; y < r.bottom; y++)
		{
			for (x=0; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, TRUE);

		DeleteObject(hTransRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}

void SaveToFile(const char* ini)
{
	FILE* file = fopen(ini, "w");
	char temp[256] = "";
	int x, count;
	
	if (file)
	{
		// Save new stuff
		fprintf(file, "(%d)(%d)(%d)(%d)\n\n", X, Y, W, H);
	
		count = SendMessage(hwndList, LB_GETCOUNT, 0, 0);
		for (x=0; x<count-1; x++)
		{
			int len = SendMessage(hwndList, LB_GETTEXTLEN, x, 0);
			char* text = new char[len];
			SendMessage(hwndList, LB_GETTEXT, (WPARAM)x, (LPARAM)text);

			fprintf(file, "****====****====****====\n");
			fprintf(file, "%s\n", text);
			fprintf(file, "****====****====****====\n");
		}
		fclose(file);
	}
}

void LoadFromFile(const char* ini)
{
	FILE* file = fopen(ini, "r");
	char temp[256] = "";

	if (file)
	{
		fscanf(file, "(%d)(%d)(%d)(%d)\n", &X, &Y, &W, &H);
		SetWindowPos(hwndMain, NULL, X, Y, W, H, SWP_NOZORDER);
		SetWindowPos(hwndList, NULL, 0, 0, W-LB-RB, H-TB-BB, SWP_NOMOVE | SWP_NOZORDER);

		while (!feof(file))
		{
			fgets(temp, 256, file);
			
			if (!strcmp(temp, "****====****====****====\n"))
			{
				char text[2048] = "";
				fgets(temp, 256, file);
				while (strcmp(temp, "****====****====****====\n") && !feof(file))
				{
					if (strlen(text) + strlen(temp) < 2048)
					{
						strcat(text, temp);
					}
					fgets(temp, 256, file);
				}
				
				if (strlen(text))
				{
					if (text[strlen(text)-1] == '\n') text[strlen(text)-1] = '\0';
					int index = SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)text);
					SendMessage(hwndList, LB_SETTOPINDEX, (WPARAM)index, 0);
					SendMessage(hwndList, LB_SETCURSEL, index, 0);
				}
			}
		}
		fclose(file);
	}
}