Ported from my gnome panel icqmod quickly..

Requires ICQ 99a to be able to use the menu functions, this is a limitation
of the ICQ API itself and i can't do a thing about it.  Yes, Mirabillis
suck.. the whole point of an API is to send messages, oh well.. get ICQ
99a if you want all the functions.

Also only shows online users, not offline ones.. once again, blame the API.
Who wants to talk to offline users anyway?

ICQ must be running before the mod ofcourse.

Box will appear blank when you are in offline mode because there will be
no users listed in it, this isn't a bug.

ICQMAPI.DLL goes in your ls dir too.

mian (no@you.cannot.bug.me.com)

