//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinPanelProg.rc
//
#define IDD_CONFIG                      101
#define IDD_ADDPANEL                    102
#define IDC_EDIT1                       1000
#define IDC_NAME                        1000
#define IDC_SECTIONSTARTBMP             1000
#define IDC_EDIT2                       1001
#define IDC_PATH                        1001
#define IDC_SECTIONENDBMP               1001
#define IDC_EDIT3                       1002
#define IDC_BITMAP                      1002
#define IDC_BACKGROUNDBMP               1002
#define IDC_CANCEL                      1003
#define IDC_BIGBUTTONBMP                1003
#define IDC_OK                          1004
#define IDC_MODULEDIR                   1004
#define IDC_MODULEIMAGESDIR             1005
#define IDC_VWM_ON                      1006
#define IDC_VWM_OFF                     1007
#define IDC_BROWSEPATH                  1010
#define IDC_BROWSEBITMAP                1011
#define IDC_CONFIG_OK                   1011
#define IDC_CONFIG_CANCEL               1012
#define IDC_CONFIG_BROWSE_SECTIONSTARTBMP 1013
#define IDC_CONFIG_BROWSE_SECTIONENDBMP 1014
#define IDC_CONFIG_BROWSE_BACKGROUNDBMP 1015
#define IDC_CONFIG_BROWSE_BIGBUTTONBMP  1016
#define IDC_CONFIG_BROWSE_MODULEIMAGESDIR 1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
