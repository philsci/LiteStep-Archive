const long magicDWord = 0x49474541;

typedef struct {
    HWND Handle;
    BOOL Visible;
    RECT Position;
    } windowType;

typedef struct {
    int borderSize;
    int pos;
    int winListSize;
    windowType *winList;
    int trayIconSize;
    int lm78Unit;
    int lm78MaxCpu;
    int lm78MaxMb;
    int lm78Cpu;
    int taskBar;
    int msTaskBar;
    int taskBarFore;
    int taskBarBack;
    int taskBarText;
    int vwmVelocity;
    int autoHideWharf;
    int autoHideTaskbar;
    int VWMDistance;
    int autoHideDelay;
    int showBeta;
    int usClock;
    int VWMNoGathering;
    int VWMNoAuto;
    int xmouseDelay;
    int xmouseBringToTop;
    char *pixmapDir;
    char *defaultBmp;
    int vwmBackColor;
    int vwmSelBackColor;
    int vwmForeColor;
    int vwmBorderColor;
    char *backsaver;
    int taskBarFore2;
    int stripBar;
    char *lsPath;
} wharfDataType;

struct Panel {
	HWND PanelWnd;
	HBITMAP PanelBmp;
	char execstr[MAX_PATH];
	char bmpstr[MAX_PATH];
	char progstr[256];

	BOOL module;
	int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
	int (FAR *quitWharfModule)(HINSTANCE);
	HINSTANCE moduleInst;

	struct Panel* next;
};
typedef struct Panel Panel;

typedef struct {
	Panel* start;
} PanelList;

struct Window {
	HWND BigWnd;
	int z;
	int Desktop;

	struct Window* next;
};
typedef struct Window Window;

typedef struct {
	Window* start;
} WindowList;