#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <commdlg.h>
#include "WinPanel.h"
#include "resource.h"

HINSTANCE hinst; 

HWND hwndMain; 
HWND AddPanelWnd;
HWND ConfigDialogWnd;
HWND AddToSection;
HWND VWMwnd;

PanelList* Panels;
WindowList* Windows;
wharfDataType* WDT;

HBITMAP sectionstartbmp;
HBITMAP sectionendbmp;
HBITMAP bgbmp;

HPEN VWMLinePen;
HBRUSH VWMBackgroundBrush;
HBRUSH VWMWindowBrush;
HBRUSH VWMCurrentDesktopBrush;

int bgx=64, bgy=64;
int ScreenX, ScreenY;
int startx, starty;
int WPHeight=75;
int PanelSize=64, SectionWidth=10, HSpacing=5, VSpacing=3;
int SectionCount=0;
int CurrentDesktop=0;
int VWMTimer=0;
int count=1;
int MaxWin=0;

HMENU popup;
HMENU sectionpopup;

char* AppName = "WinPanel";
char* PanelName = "ChildPanel";
char* SectionName = "WinPanelSection";
char* VWMName = "WinPanelVWM";
char* VWMSmallName = "WinPanelVWMWindow";
char sectionstartbmppath[MAX_PATH] = "";
char sectionendbmppath[MAX_PATH] = "";
char bgbmppath[MAX_PATH] = "";
char bbbpath[MAX_PATH] = "";
char ModuleDir[MAX_PATH] = "";
char ModuleImagesDir[MAX_PATH] = "";

BOOL DRAWEDGES=FALSE;
BOOL HIDETASKBAR=FALSE;
BOOL LOADED=FALSE;
BOOL SHRUNK=FALSE;
BOOL VWM=FALSE;

BOOL CALLBACK AddPanelDialogProc( HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam ); 
BOOL CALLBACK ConfigDialogProc( HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam ); 
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
LRESULT CALLBACK PanelProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam ); 
LRESULT CALLBACK SectionProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam ); 
LRESULT CALLBACK VWMProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam ); 
LRESULT CALLBACK WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam ); 

int AddPanel(HWND parent, char* prog, char* exec, char* bmp, int x, int y, int w, int h, int nCmdShow);
HWND AddSection(char*);
int BrowseForFile(HWND parent, char* filename, int which);
int Cleanup();
int EditPanel(HWND panel);
int EndSection(HWND);
int FirstOpen(HWND current);
int FitMainWindow();
int FitSections();
int HideTaskbar();
int LoadSections();
int LoadSetup();
int LoadVWM();
int RemovePanel(HWND panel);
int SavePosition();
int SetupModules();
int ShowTaskbar();
int SwitchVW(int);
int WPTransparentBlt(HDC, HWND, int);

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg; 
    WNDCLASS wc; 
    UNREFERENCED_PARAMETER(lpszCmdLine);

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, 100, "&WinPanel Settings");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 101, "&Add Section");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 102, "&Quit WinPanel");

	sectionpopup = CreatePopupMenu();
    AppendMenu(sectionpopup, MF_ENABLED | MF_STRING, 100, "&Add Panel");

    if (!hPrevInstance) 
    { 
        wc.style = 0; 
        wc.lpfnWndProc = (WNDPROC) WndProc; 
        wc.cbClsExtra = 0; 
        wc.cbWndExtra = 0; 
        wc.hInstance = hInstance; 
        wc.hIcon = LoadIcon(hInstance, 
            IDI_APPLICATION);
        wc.hCursor = LoadCursor((HINSTANCE) NULL, 
            IDC_ARROW); 

		wc.hbrBackground = NULL;
        wc.lpszClassName = AppName;  
        if (!RegisterClass(&wc)) 
            return FALSE; 

		wc.lpfnWndProc = (WNDPROC) PanelProc; 
        wc.lpszClassName = PanelName; 
        if (!RegisterClass(&wc)) 
            return FALSE; 

		wc.lpfnWndProc = (WNDPROC) SectionProc; 
        wc.lpszClassName = SectionName; 
        if (!RegisterClass(&wc)) 
            return FALSE; 

		wc.lpfnWndProc = (WNDPROC) VWMProc; 
        wc.lpszClassName = VWMName; 
        if (!RegisterClass(&wc)) 
            return FALSE; 
    } 
 
    hinst = hInstance;  // save instance handle 

	SetupModules();
	LoadSetup();

    hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, AppName, "WinPanel", 
        WS_POPUP | WS_DLGFRAME, startx, starty, 0, WPHeight, (HWND) NULL, 
        (HMENU) NULL, hinst, (LPVOID) NULL); 
	
	if (!hwndMain) 
        return FALSE; 
 
	ShowWindow(hwndMain, nCmdShow); 
	SetWindowLong (hwndMain, GWL_USERDATA, magicDWord);
	AddPanel(hwndMain, "BigButton", "", bbbpath, HSpacing, VSpacing, PanelSize, PanelSize, SW_SHOWNORMAL);
	if (VWM) LoadVWM();
	LoadSections();
	FitMainWindow();
	LOADED=TRUE;

    while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	Cleanup();
	if (HIDETASKBAR) ShowTaskbar();

    return msg.wParam; 
}

int  Cleanup()
{
	Panel* p = malloc(sizeof(Panel));
	Window* w = malloc(sizeof(Window));

	if (VWMTimer) KillTimer(VWMwnd, VWMTimer);

	DestroyWindow(hwndMain); 
	DestroyWindow(AddPanelWnd);
	DestroyWindow(ConfigDialogWnd);
	DestroyWindow(AddToSection);
	DestroyWindow(VWMwnd);
	
	if (Windows)
	{
		while (Windows->start)
		{
			w = Windows->start;
			
			if (w->next)
			{
				Windows->start = w->next;
			}
			else
			{
				Windows->start = NULL;
			}
			free(w);
		}
	}
	Windows = NULL;

	if (Panels)
	{
		while (Panels->start)
		{
			p = Panels->start;
			
			if (p->next)
			{
				Panels->start = p->next;	
			}
			else
			{
				Panels->start = NULL;
			}

			DestroyWindow(p->PanelWnd);
			DeleteObject(p->PanelBmp);
			if (p->module)
			{
				p->quitWharfModule(p->moduleInst);
			}
			free(p);
		}
	}
	
	free(Panels);
	free(Windows);
	free(WDT);

	DeleteObject(sectionstartbmp);
	DeleteObject(sectionendbmp);
	DeleteObject(bgbmp);
	DeleteObject(VWMLinePen);
	DeleteObject(VWMBackgroundBrush);
	DeleteObject(VWMWindowBrush);
	DeleteObject(VWMCurrentDesktopBrush);
	
	DestroyMenu(popup);
	DestroyMenu(sectionpopup);

	return 1;
}

////////////////////////////////
// WINDOWS PROCEDURES
////////////////////////////////

BOOL CALLBACK AddPanelDialogProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		return TRUE;
		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDC_OK:
						{
							HWND end = FindWindowEx(AddToSection, NULL, "Button", "End");
							RECT r;
							int x = FirstOpen(AddToSection);
							char prog[256] = "";
							char exec[256] = "";
							char bmp[256] = "";
							GetClientRect(AddToSection, &r);

							GetWindowText(GetDlgItem(hwnd, IDC_NAME), prog, 256);
							GetWindowText(GetDlgItem(hwnd, IDC_PATH), exec, 256);
							GetWindowText(GetDlgItem(hwnd, IDC_BITMAP), bmp, 256);
							
							if (r.right - r.left == SectionWidth*2) 
							{ 
								AddPanel(AddToSection, prog, exec, bmp, x, 0, PanelSize, PanelSize, SW_HIDE);
							}
							else
							{
								if (AddPanel(AddToSection, prog, exec, bmp, x, 0, PanelSize, PanelSize, SW_SHOWNORMAL))
								{
									SetWindowPos(AddToSection, 0, 0, 0, r.right+PanelSize+HSpacing, PanelSize, SWP_NOMOVE | SWP_NOZORDER);
									SetWindowPos(end, 0, x+PanelSize+HSpacing, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
									FitMainWindow();
									FitSections();
								}
							}
						}
						case IDC_CANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
						case IDC_BROWSEPATH:
						{
							char filename[MAX_PATH] = "";
							if (BrowseForFile(hwnd, filename, 1))
							{
								SetWindowText(GetDlgItem(hwnd, IDC_PATH), filename);
							}
						}
						break;
						case IDC_BROWSEBITMAP:
						{
							char filename[MAX_PATH] = "";
							if (BrowseForFile(hwnd, filename, 2))
							{
								SetWindowText(GetDlgItem(hwnd, IDC_BITMAP), filename);
							}
						}
						break;
					}
				}
			}
		}
		return TRUE;
	}

	return FALSE;
}

BOOL CALLBACK ConfigDialogProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			SetWindowText(GetDlgItem(hwnd, IDC_SECTIONSTARTBMP),	sectionstartbmppath);
			SetWindowText(GetDlgItem(hwnd, IDC_SECTIONENDBMP),	sectionendbmppath);
			SetWindowText(GetDlgItem(hwnd, IDC_BACKGROUNDBMP),	bgbmppath);
			SetWindowText(GetDlgItem(hwnd, IDC_BIGBUTTONBMP),	bbbpath);
			SetWindowText(GetDlgItem(hwnd, IDC_MODULEDIR),		ModuleDir);
			SetWindowText(GetDlgItem(hwnd, IDC_MODULEIMAGESDIR),	ModuleImagesDir);
			
			if (VWM) SendMessage(GetDlgItem(hwnd, IDC_VWM_ON), BM_SETCHECK, (WPARAM)BST_CHECKED, (LPARAM)0);
			else SendMessage(GetDlgItem(hwnd, IDC_VWM_OFF), BM_SETCHECK, (WPARAM)BST_CHECKED, (LPARAM)0);
		}
		return TRUE;
		case WM_SYSCOMMAND:
		{
			switch(wParam)
			{
				case SC_CLOSE:
					EndDialog(hwnd, 0);
			}
		}
		return TRUE;
		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					char filename[MAX_PATH] = "";

					switch (LOWORD(wParam))
					{
						case IDC_CONFIG_BROWSE_SECTIONSTARTBMP:
						{
							if (BrowseForFile(ConfigDialogWnd, filename, 2))
								SetWindowText(GetDlgItem(ConfigDialogWnd, IDC_SECTIONSTARTBMP), filename);
						}
						return TRUE;
						case IDC_CONFIG_BROWSE_SECTIONENDBMP:
						{
							if (BrowseForFile(ConfigDialogWnd, filename, 2))
								SetWindowText(GetDlgItem(ConfigDialogWnd, IDC_SECTIONENDBMP), filename);
						}
						return TRUE;
						case IDC_CONFIG_BROWSE_BACKGROUNDBMP:
						{
							if (BrowseForFile(ConfigDialogWnd, filename, 2))
								SetWindowText(GetDlgItem(ConfigDialogWnd, IDC_BACKGROUNDBMP), filename);
						}
						return TRUE;
						case IDC_CONFIG_BROWSE_BIGBUTTONBMP:
						{
							if (BrowseForFile(ConfigDialogWnd, filename, 2))
								SetWindowText(GetDlgItem(ConfigDialogWnd, IDC_BIGBUTTONBMP), filename);
						}
						return TRUE;
						case IDC_CONFIG_OK:
						{
							
						}
						case IDC_CONFIG_CANCEL:
						{
							EndDialog(hwnd, 0);
						}
						return TRUE;
					}
				}
				break;
			}
		}
		break;
	}
	return FALSE;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	RECT r;
	HWND top = GetForegroundWindow();
	Window* w = malloc(sizeof(Window));
	Window* p = malloc(sizeof(Window));
	BOOL FOUND = FALSE;

	if (IsWindowVisible(hwnd))
	{		
		if (Windows)
		{
			w = Windows->start;
	
			while (w)
			{
				if (w->BigWnd == hwnd) 
				{
					GetWindowRect(w->BigWnd, &r);
					if (r.left >= 0 && r.left <= ScreenX) 
					{
						w->Desktop = CurrentDesktop;
					}

					//if (w->BigWnd == top && w->Desktop != CurrentDesktop)
					//{ 
					//	int old = CurrentDesktop; 
					//	CurrentDesktop = w->Desktop; 
					//	SwitchVW(old); 
					//	InvalidateRect(VWMwnd , NULL, TRUE);
					//}

					w->z = count;
					count++;
					FOUND = TRUE;
					break;
				}
				w = w->next;
			}
		}

		if (!FOUND)
		{
			DWORD style = GetWindowLong(hwnd, GWL_STYLE), 
				exstyle = GetWindowLong(hwnd, GWL_EXSTYLE);
	
			if ((style & WS_VISIBLE)&&(style & WS_SYSMENU)&&(!(exstyle & WS_EX_TOOLWINDOW)))
			{
		
				Window* NewWindow = malloc(sizeof(Window));
				NewWindow->BigWnd = hwnd;
				NewWindow->Desktop = CurrentDesktop;
			
				if (Windows)
				{
					NewWindow->next = Windows->start;
					Windows->start = NewWindow;
				}
				else
				{
					Windows = (WindowList*)malloc(sizeof(WindowList));
					NewWindow->next = NULL;
					Windows->start = NewWindow;
				}
				MaxWin++;
			}
		}
	}

	if (Windows)
	{
		w = p = Windows->start;
		while (w)
		{
			if (!IsWindow(w->BigWnd))
			{
				if (w == Windows->start)
				{
					Windows->start->next = NULL;
					Windows->start = NULL;
				}
				else
				{
					p->next = w->next;
					w = NULL;
				}
				MaxWin--;
				break;
			}
			p = w;
			w = w->next;
		}
	}

	InvalidateRect(VWMwnd, NULL, TRUE);
	return TRUE;
}

LRESULT CALLBACK PanelProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			WPTransparentBlt(hdc, hwnd, EDGE_RAISED);
			EndPaint(hwnd, &ps);
		}
		break;
	}
	return (DefWindowProc(hwnd, msg, wParam, lParam));
}

LRESULT CALLBACK SectionProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			EndPaint(hwnd, &ps);
		}
		break;
		case WM_DRAWITEM:
		{
			DRAWITEMSTRUCT* di = (DRAWITEMSTRUCT*)lParam;
			if (SendMessage(di->hwndItem, BM_GETSTATE, 0, 0) & BST_PUSHED)
				WPTransparentBlt(di->hDC, di->hwndItem, EDGE_SUNKEN);
			else
				WPTransparentBlt(di->hDC, di->hwndItem, EDGE_RAISED);
		}
		break;
		case WM_COMMAND:
		{
			switch (wParam)
			{
				case 100:
				{
					AddToSection = hwnd;
					DialogBox(hinst, MAKEINTRESOURCE(IDD_ADDPANEL), hwndMain, AddPanelDialogProc);
				}
				break;
				case 101:
				{
					PostQuitMessage(0);
				}
				break;
				case BN_CLICKED:
				{
					char temp[256] = "";
					
					GetWindowText((HWND)lParam, temp, 256);
					if (!strnicmp(temp, "Panel", 5))
					{
						Panel* p = Panels->start;
						while (p)
						{
							if (p->PanelWnd == (HWND)lParam) { WinExec(p->execstr, SW_SHOWNORMAL); break; }
							p=p->next;
						}
					}
					else if (!strnicmp(temp, "Start", 5))
					{
						DWORD dw = GetMessagePos();
						TrackPopupMenu(sectionpopup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
					}
					else if (!strnicmp(temp, "End", 3))
					{
						RECT r;
						GetClientRect(hwnd, &r);

						if ((r.right - r.left) == SectionWidth*2) // It is shrunk
						{
							int x=SectionWidth + HSpacing;
							HWND tempwnd=NULL;
							while ((tempwnd = FindWindowEx(hwnd, tempwnd, NULL, "Panel")))
							{
								ShowWindow(tempwnd, SW_SHOWNORMAL);
								x+=PanelSize+HSpacing;
							}

							SetWindowPos((HWND)lParam, 0, x, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
							SetWindowPos(hwnd, 0, 0, 0, x+SectionWidth, PanelSize, SWP_NOMOVE | SWP_NOZORDER);
							FitMainWindow();
							FitSections();
							InvalidateRect(hwndMain, NULL, TRUE);
						}
						else // It is not shrunk
						{
							HWND tempwnd=NULL;
							while ((tempwnd = FindWindowEx(hwnd, tempwnd, NULL, "Panel")))
							{
								ShowWindow(tempwnd, SW_HIDE);
							}
							SetWindowPos((HWND)lParam, 0, SectionWidth, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
							SetWindowPos(hwnd, 0, 0, 0, SectionWidth*2, PanelSize, SWP_NOMOVE | SWP_NOZORDER);
							FitMainWindow();
							FitSections();
						}
					}
				}
				break;
			}
		}
		break;
	}
	return (DefWindowProc(hwnd, msg, wParam, lParam));
}

LRESULT CALLBACK WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_DESTROY:
		{
			SavePosition();
		}
		break;
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					PostQuitMessage(0);
			}
		}		
		break;
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			RECT r;
			int x=0;

			SelectObject(buf, bgbmp);
			GetClientRect(hwnd, &r);

			while (x <= r.right)
			{
				BitBlt(hdc, x, 0, bgx, bgy, buf, 0, 0, SRCCOPY);
				x += bgx;
			}
			
			EndPaint(hwnd, &ps);
			DeleteObject(buf);
		}
		break;
		case WM_NCRBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		break;
		case WM_WINDOWPOSCHANGING:
		{
			LPWINDOWPOS lpwp = (LPWINDOWPOS) lParam;
			RECT r;
			GetWindowRect(hwnd, &r);

			if (lpwp->y <= 0)
			{
				lpwp->y = 0;
			}
			else if (lpwp->y >= ScreenY - WPHeight + 10)
			{
				lpwp->y = ScreenY - WPHeight;
			}
			
			if (lpwp->x <= 0)
			{
				lpwp->x = 0;
			}
			else if (lpwp->x >= ScreenX - (r.right-r.left))
			{
				lpwp->x = ScreenX - (r.right-r.left);
			}

			return 0;
		}
		break;
		case WM_DRAWITEM:
		{
			DRAWITEMSTRUCT* di = (DRAWITEMSTRUCT*)lParam;
			if (SendMessage(di->hwndItem, BM_GETSTATE, 0, 0) & BST_PUSHED)
				WPTransparentBlt(di->hDC, di->hwndItem, EDGE_SUNKEN);
			else
				WPTransparentBlt(di->hDC, di->hwndItem, EDGE_RAISED);
		}
		break;
		case WM_COMMAND:
		{
			switch (wParam)
			{
				case BN_CLICKED:
				{
					DWORD dw = GetMessagePos();
					TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
				}
				break;
				case 100:
				{
					ConfigDialogWnd = CreateDialog(hinst, MAKEINTRESOURCE(IDD_CONFIG), hwndMain, ConfigDialogProc);					
				}
				break;
				case 101:
				{
					char temp[256] = "";
					sprintf(temp, "New%d", SectionCount);
					EndSection(AddSection(temp));
				}
				break;
				case 102:
				{
					PostQuitMessage(0);
				}
				break;
			}
		}
		break;
		case WM_NCHITTEST: return HTCAPTION;
	}
	return (DefWindowProc(hwnd, msg, wParam, lParam));
}

/////////////////////////////////////////////////////////////////////////////

////////////////////////////////
// VWM FUNCTIONS
////////////////////////////////

LRESULT CALLBACK VWMProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, PanelSize + (PanelSize/2), PanelSize);
			Window* w = malloc(sizeof(Window));
			int temp=0;
			RECT r, screen, br, fillme, vwr[6];
			int i=0;

			GetClientRect(hwnd, &r);
			GetClientRect(GetDesktopWindow(), &screen);

			SelectObject(buf, bufbmp);
			FillRect(buf, &r, VWMBackgroundBrush);

			for (i=0; i < 6; i++)
			{
				switch (i)
				{
					case 0:
						vwr[i].left		= r.left;
						vwr[i].right	= (r.right-r.left)/3;
						vwr[i].top		= r.top;
						vwr[i].bottom	= (r.bottom-r.top)/2;
						break;
					case 1:
						vwr[i].left		= (r.right-r.left)/3;
						vwr[i].right	= r.right - (r.right-r.left)/3;;
						vwr[i].top		= r.top;
						vwr[i].bottom	= (r.bottom-r.top)/2;
						break;
					case 2:
						vwr[i].left		= r.right - (r.right-r.left)/3;
						vwr[i].right	= r.right;
						vwr[i].top		= r.top;
						vwr[i].bottom	= (r.bottom-r.top)/2;
						break;
					case 3:
						vwr[i].left		= r.left;
						vwr[i].right	= (r.right-r.left)/3;
						vwr[i].top		= (r.bottom-r.top)/2;
						vwr[i].bottom	= r.bottom;
						break;
					case 4:
						vwr[i].left		= (r.right-r.left)/3;
						vwr[i].right	= r.right - (r.right-r.left)/3;
						vwr[i].top		= (r.bottom-r.top)/2;
						vwr[i].bottom	= r.bottom;
						break;
					case 5:
						vwr[i].left		= r.right - (r.right-r.left)/3;
						vwr[i].right	= r.right;
						vwr[i].top		= (r.bottom-r.top)/2;
						vwr[i].bottom	= r.bottom;
						break;
				}
			}

			FillRect(buf, &vwr[CurrentDesktop], VWMCurrentDesktopBrush);

			SelectObject(buf, VWMLinePen);
			MoveToEx(buf, vwr[0].right, 0, NULL);
			LineTo(buf, vwr[0].right, vwr[3].bottom);
			MoveToEx(buf, vwr[2].left, 0, NULL);
			LineTo(buf, vwr[2].left, vwr[5].bottom);
			MoveToEx(buf, vwr[0].left, vwr[0].bottom, NULL);
			LineTo(buf, vwr[2].right, vwr[2].bottom);

			if (Windows)
			{
				for (temp = MaxWin; temp > 0 ; temp--)
				{
					w = Windows->start;
					while (w)
					{
						if (w->z == temp && !IsIconic(w->BigWnd))
						{
							int xscale, yscale;
							int width, height;
							int desk = w->Desktop;

							width = vwr[desk].right-vwr[desk].left;
							height = vwr[desk].bottom-vwr[desk].top;
							xscale = ScreenX/width;
							yscale = ScreenY/height;
							GetWindowRect(w->BigWnd, &br);
							fillme.left	  =	vwr[CurrentDesktop].left + (br.left/xscale);
							fillme.right  =	vwr[CurrentDesktop].left + (br.right/xscale);
							fillme.top    =	vwr[CurrentDesktop].top  + (br.top/yscale);
							fillme.bottom =	vwr[CurrentDesktop].top  + (br.bottom/yscale);
							FillRect(buf, &fillme, VWMWindowBrush);
							FrameRect(buf, &fillme, GetStockObject(BLACK_BRUSH));
							break;
						}
						w = w->next;
					}
				}
			}

			BitBlt(hdc, 0, 0, PanelSize + (PanelSize/2), PanelSize, buf, 0, 0, SRCCOPY);

			EndPaint(hwnd, &ps);
			DeleteDC(buf);
			DeleteObject(bufbmp);
		}
		break;
		case WM_RBUTTONUP:
		{
			RECT r;
			POINT p;
			int OldDesktop = CurrentDesktop;

			GetWindowRect(hwnd, &r);
			GetCursorPos(&p);
			p.x -= r.left;
			p.y -= r.top;
			
			GetClientRect(hwnd, &r);
			if (p.x < ((r.right-r.left)/3))
				CurrentDesktop = 0;
			else if (p.x > (r.right - ((r.right-r.left)/3)))
				CurrentDesktop = 2;
			else
				CurrentDesktop = 1;

			if (p.y > ((r.bottom-r.top)/2)) CurrentDesktop += 3;
	
			SwitchVW(OldDesktop);
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;
		case WM_TIMER:
		{
			EnumWindows(EnumWindowsProc, (LPARAM)NULL);
			count=1;
		}
		break;
	}
	return (DefWindowProc(hwnd, msg, wParam, lParam));
}

int LoadVWM()
{
	VWMwnd = CreateWindowEx(WS_EX_TRANSPARENT, VWMName, VWMName, WS_BORDER | WS_CHILD, PanelSize + 2*HSpacing, VSpacing, PanelSize + (PanelSize/2), PanelSize, hwndMain, (HMENU) NULL, hinst, (LPVOID) NULL);
	ShowWindow(VWMwnd, SW_SHOWNORMAL);
	SetTimer(VWMwnd, 0, 333, NULL);
	return 1;
}

int SwitchVW(int OldDesktop)
{
	RECT r;

	if (Windows)
	{
		Window* w = Windows->start;

		while (w)
		{
			if (GetWindowLong(w->BigWnd, GWL_USERDATA) != magicDWord)
			{
				int movex=0, movey=0;
				GetWindowRect(w->BigWnd, &r);
				
				if (CurrentDesktop <= 2 && OldDesktop >= 3) movey = -1;
				else if (CurrentDesktop >= 3 && OldDesktop <= 2) movey = 1;
				else movey = 0;

				movex = (CurrentDesktop % 3) - (OldDesktop % 3);

				SetWindowPos(w->BigWnd, 0, 
					r.left - (ScreenX * movex), 
					r.top - (ScreenY * movey),
					0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
			}
			w = w->next;
		}
	}

	return 1;
}

/////////////////////////////////////////////////////////////////////////

////////////////////////////////
// SETUP FUNCTIONS
////////////////////////////////

HWND AddSection(char* name)
{
	HWND hwnd;
	HWND parent = CreateWindowEx(WS_EX_TRANSPARENT, SectionName, name, WS_CHILD, VSpacing, HSpacing, SectionWidth, PanelSize, hwndMain,
					(HMENU) NULL, hinst, (LPVOID) NULL);
	if (!parent) return FALSE;
	ShowWindow(parent, SW_SHOWNORMAL);

	hwnd = CreateWindow("Button", "Start", WS_CHILD | BS_BITMAP, 0, 0, SectionWidth, PanelSize, parent,
					(HMENU) NULL, hinst, (LPVOID) NULL);
	if (!hwnd) return FALSE;
	SendMessage(hwnd, BM_SETIMAGE, (WPARAM)IMAGE_BITMAP, (LPARAM)sectionstartbmp);
	ShowWindow(hwnd, SW_SHOWNORMAL);
	FitSections();

	SectionCount++;

	if (LOADED)
	{
		FILE* config = fopen("WinPanel.rc", "a");

		fprintf(config, "\n*SectionStart \"%s\"\n", name);
		
		fclose(config);
	}

	return parent;
}

int EndSection(HWND parent)
{
	RECT r;
	HWND hwnd;
	GetClientRect(parent, &r);
	hwnd = CreateWindow("Button", "End", WS_CHILD | BS_BITMAP, r.right, 0, SectionWidth, PanelSize, parent,
					(HMENU) NULL, hinst, (LPVOID) NULL);
	if (!hwnd) return FALSE;
	ShowWindow(hwnd, SW_SHOWNORMAL);
	SendMessage(hwnd, BM_SETIMAGE, (WPARAM)IMAGE_BITMAP, (LPARAM)sectionendbmp);

	SetWindowPos(parent, 0, 0, 0, r.right+SectionWidth, PanelSize, SWP_NOMOVE | SWP_NOZORDER);
	FitMainWindow();

	if (LOADED)
	{
		FILE* config = fopen("WinPanel.rc", "a");

		fprintf(config, "*SectionEnd \"Open\"\n");
		
		fclose(config);
	}

	return 1;
}

int FirstOpen(HWND current)
{
	HWND panel = NULL;
	int x=SectionWidth+HSpacing;

	while ( (panel = FindWindowEx(current, panel, NULL, "Panel")) )
	{
		x += PanelSize;
	}

	return x;
}

int FitMainWindow()
{
	HWND pwnd = NULL, cwnd = NULL;
	int x = PanelSize + HSpacing * 2;
	int front=1;
	RECT r;
	GetWindowRect(hwndMain, &r);

	if (VWM) x += PanelSize + (PanelSize/2) + HSpacing;

	while ( (pwnd = FindWindowEx(hwndMain, pwnd, SectionName, NULL)) )
	{
		x += SectionWidth;
		while ( (cwnd = FindWindowEx(pwnd, cwnd, NULL, "Panel")) )
		{
			if (IsWindowVisible(cwnd)) 
			{
				if (front) { x+=HSpacing; front=0; }
				x += PanelSize + HSpacing;
			}
		}
		x += SectionWidth + HSpacing;
		front = 1;
		cwnd = NULL;
	}

	SetWindowPos(hwndMain, 0, 0, 0, x+7, WPHeight, SWP_NOMOVE | SWP_NOZORDER);
	SetWindowPos(hwndMain, 0, r.left, r.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	return 1;
}

int FitSections()
{
	HWND pwnd = NULL, cwnd = NULL;
	int front=1;
	int x=PanelSize + HSpacing * 2;

	if (VWM) x += PanelSize + (PanelSize/2) + HSpacing;

	while ( (pwnd = FindWindowEx(hwndMain, pwnd, SectionName, NULL)) )
	{
		SetWindowPos(pwnd, 0, x, VSpacing, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
		x += SectionWidth;
		while ( (cwnd = FindWindowEx(pwnd, cwnd, NULL, "Panel")) )
		{
			if (IsWindowVisible(cwnd)) 
			{
				if (front) { x+=HSpacing; front=0; }
				x += PanelSize + HSpacing;
			}
		}
		x += SectionWidth + HSpacing;
		front=1;
		cwnd = NULL;
	}

	return 1;
}

int LoadSetup()
{
	int r=0, g=0, b=0;
	char buffer[256] = "";
	
	FILE* config = fopen("WinPanel.rc", "r");

	while (fgets(buffer, 256, config)) 
	{
		if (!strnicmp(buffer, "StartPosition", 13))
		{
			strtok(buffer, "\"");
			startx = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			starty = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "Height", 6))
		{
			strtok(buffer, "\"");
			WPHeight = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "PanelSize", 9))
		{
			strtok(buffer, "\"");
			PanelSize = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "VerticalSpacing", 15))
		{
			strtok(buffer, "\"");
			VSpacing = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "HorizontalSpacing", 17))
		{
			strtok(buffer, "\"");
			HSpacing = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "SectionWidth", 12))
		{
			strtok(buffer, "\"");
			SectionWidth = atoi(strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "ModuleDir", 9))
		{
			strtok(buffer, "\"");
			strcpy(ModuleDir, strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "VWMStatus", 9))
		{
			strtok(buffer, "\"");
			if (!strnicmp(strtok(NULL, "\""), "ON", 2)) VWM=TRUE;
		}
		else if (!strnicmp(buffer, "HideTaskbar", 11))
		{
			strtok(buffer, "\"");
			if (!strnicmp(strtok(NULL, "\""), "ON", 2)) { HIDETASKBAR=TRUE; HideTaskbar(); }
		}
		else if (!strnicmp(buffer, "DrawEdges", 9))
		{
			strtok(buffer, "\"");
			if (!strnicmp(strtok(NULL, "\""), "ON", 2)) DRAWEDGES=TRUE;
		}
		else if (!strnicmp(buffer, "VWMBorderColor", 14))
		{
			strtok(buffer, "\"");
			r = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			g = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			b = atoi(strtok(NULL, "\""));
			VWMLinePen = CreatePen(PS_SOLID, 1, RGB(r,g,b));
		}
		else if (!strnicmp(buffer, "VWMBackgroundColor", 18))
		{
			strtok(buffer, "\"");
			r = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			g = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			b = atoi(strtok(NULL, "\""));
			VWMBackgroundBrush = CreateSolidBrush(RGB(r,g,b));
		}
		else if (!strnicmp(buffer, "VWMWindowColor", 14))
		{
			strtok(buffer, "\"");
			r = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			g = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			b = atoi(strtok(NULL, "\""));
			VWMWindowBrush = CreateSolidBrush(RGB(r,g,b));
		}
		else if (!strnicmp(buffer, "VWMActiveDesktopColor", 21))
		{
			strtok(buffer, "\"");
			r = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			g = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			b = atoi(strtok(NULL, "\""));
			VWMCurrentDesktopBrush = CreateSolidBrush(RGB(r,g,b));
		}
		else if (!strnicmp(buffer, "ModuleImagesDir", 15))
		{
			strtok(buffer, "\"");
			strcpy(ModuleImagesDir, strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "BigButtonBmp", 12))
		{
			strtok(buffer, "\"");
			strcpy(bbbpath, strtok(NULL, "\""));
		}
		else if (!strnicmp(buffer, "SectionStartBmp", 15)) 
		{ 
			strtok(buffer, "\"");
			strcpy(sectionstartbmppath, strtok(NULL, "\""));
			sectionstartbmp = LoadImage(NULL, sectionstartbmppath, IMAGE_BITMAP, SectionWidth, PanelSize, LR_LOADFROMFILE);
		}
		else if (!strnicmp(buffer, "SectionEndBmp", 13)) 
		{ 
			strtok(buffer, "\"");
			strcpy(sectionendbmppath, strtok(NULL, "\""));
			sectionendbmp = LoadImage(NULL, sectionendbmppath, IMAGE_BITMAP, SectionWidth, PanelSize, LR_LOADFROMFILE);
		}
		else if (!strnicmp(buffer, "BackgroundBmp", 13)) 
		{
			strtok(buffer, "\"");
			strcpy(bgbmppath, strtok(NULL, "\""));
			strtok(NULL, "\"");
			bgx = atoi(strtok(NULL, "\""));
			strtok(NULL, "\"");
			bgy = atoi(strtok(NULL, "\""));

			bgbmp = LoadImage(NULL, bgbmppath, IMAGE_BITMAP, bgx, bgy, LR_LOADFROMFILE);
		}
	}
	
	fclose(config);
	return 1;
}

int LoadSections()
{
	HWND parent;
	int x=0;
	char buffer[256] = "";
	
	FILE* config = fopen("WinPanel.rc", "r");

	while (fgets(buffer, 256, config)) 
	{
		if (!strnicmp(buffer, "*SectionStart", 13))
		{
			strtok(buffer, "\"");
			parent = AddSection(strtok(NULL, "\"")); x+=SectionWidth + HSpacing;
		}
		else if (!strnicmp(buffer, "*Panel", 6))
		{
			char prog[256] = "";
			char exec[256] = "";
			char bmp[256] = "";
			
			strtok(buffer, "\"");
			sprintf(prog, "%s", strtok(NULL, "\""));
			strtok(NULL, "\"");
			sprintf(bmp, "%s", strtok(NULL, "\""));
			strtok(NULL, "\"");
			sprintf(exec, "%s", strtok(NULL, "\""));

			if (AddPanel(parent, prog, exec, bmp, x, 0, PanelSize, PanelSize, SW_SHOWNORMAL)) x+=PanelSize + HSpacing;
		}
		else if (!strnicmp(buffer, "*SectionEnd", 11))
		{
			char open[15] = "";
			EndSection(parent); x=0;
			strtok(buffer, "\"");
			sprintf(open, "%s", strtok(NULL, "\""));
			if (!strnicmp(open, "Closed", 6))
			{
				PostMessage(FindWindowEx(parent, NULL, "Button", "End"), WM_LBUTTONUP, 0, 0);
			}
		}
	}
	
	fclose(config);
	return 1;
}

int SavePosition()
{
	RECT r;
	char temp[256] = "";
	FILE* config = fopen("WinPanel.rc", "r");
	FILE* tempconfig = tmpfile();

	GetWindowRect(hwndMain, &r);
	
	fprintf(tempconfig, "StartPosition \"%d\" \"%d\"\n", r.left, r.top);

	while (fgets(temp, 256, config))
	{
		if (!strstr(temp, "StartPosition"))
		{
			fprintf(tempconfig, "%s", temp);
		}
	}
	rewind(tempconfig);
	fclose(config);
	config = fopen("WinPanel.rc", "w");

	while (fgets(temp, 256, tempconfig))
	{
		fprintf(config, "%s", temp);
	}

	fclose(tempconfig);
	fclose(config);

	return 1;
}

int SetupModules()
{
	WDT = malloc(sizeof(wharfDataType*));

	WDT->borderSize = 0;
    WDT->pos = 0;
    WDT->winListSize = 0;
    WDT->trayIconSize = 0;
    WDT->lm78Unit = 0;
    WDT->lm78MaxCpu = 0;
    WDT->lm78MaxMb = 0;
    WDT->lm78Cpu = 0;
    WDT->taskBar = 0;
    WDT->msTaskBar = 0;
    WDT->taskBarFore = 0;
    WDT->taskBarBack = 0;
    WDT->taskBarText = 0;
    WDT->vwmVelocity = 0;
    WDT->autoHideWharf = 0;
    WDT->autoHideTaskbar = 0;
    WDT->VWMDistance = 5;
    WDT->autoHideDelay = 0;
    WDT->showBeta = 0;
    WDT->usClock = 1;
    WDT->VWMNoGathering = 1;
    WDT->VWMNoAuto = 0;
    WDT->xmouseDelay = 0;
    WDT->xmouseBringToTop = 0;
    WDT->pixmapDir = malloc(sizeof(char*) * MAX_PATH);
	sprintf(WDT->pixmapDir, "%s", ModuleImagesDir);
	WDT->defaultBmp = malloc(sizeof(char*) * MAX_PATH);
    sprintf(WDT->defaultBmp, "");
    WDT->vwmBackColor = 101010;
    WDT->vwmSelBackColor = 505050;
    WDT->vwmForeColor = 500000;
    WDT->vwmBorderColor = 005000;
	WDT->backsaver = malloc(sizeof(char*) * MAX_PATH);
    sprintf(WDT->backsaver, "");
    WDT->taskBarFore2 = 0;
    WDT->stripBar = 0;
	WDT->lsPath = malloc(sizeof(char*) * MAX_PATH);
    sprintf(WDT->lsPath, "%s", ModuleDir);

	return 1;
}

//////////////////////////////////////////////////////////////////////////

////////////////////////////////
// LINKED LIST FUNCTIONS
////////////////////////////////

int AddPanel(HWND parent, char* prog, char* exec, char* bmp, int x, int y, int w, int h, int nCmdShow)
{
	char temp[MAX_PATH] = "";
	Panel* NewPanel = malloc(sizeof(Panel));

	strcpy(NewPanel->progstr, prog);
	strcpy(NewPanel->execstr, exec);
	strcpy(NewPanel->bmpstr, bmp);
	NewPanel->PanelBmp = LoadImage(NULL, bmp, IMAGE_BITMAP, PanelSize, PanelSize, LR_LOADFROMFILE | LR_LOADTRANSPARENT);

	if (exec[0] == '@')
	{
		if (PanelSize == 64)
		{
			exec++;
			NewPanel->module = TRUE;
		
			NewPanel->PanelWnd = CreateWindowEx(WS_EX_TRANSPARENT, PanelName, "Panel", WS_CHILD, x, y, w, h, parent, 
								(HMENU) NULL, hinst, (LPVOID) NULL);
			if (!NewPanel->PanelWnd) return FALSE; 

			NewPanel->moduleInst = LoadLibrary(exec);
			if ((UINT)NewPanel->moduleInst > HINSTANCE_ERROR)
			{
				NewPanel->initWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(NewPanel->moduleInst, "initWharfModule");
				NewPanel->quitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(NewPanel->moduleInst, "quitWharfModule");
			}
			else
			{
				sprintf(temp, "Could not load module - %s", exec);
				MessageBox(hwndMain, temp, "WinPanel Error", MB_OK | MB_SETFOREGROUND);
				DestroyWindow(NewPanel->PanelWnd);
				NewPanel = NULL;
				return 0;
			}

			NewPanel->initWharfModule(NewPanel->PanelWnd, NewPanel->moduleInst, WDT);
		}
		else return FALSE;
	}
	else
	{
		NewPanel->PanelWnd = CreateWindowEx(WS_EX_TRANSPARENT, "Button", "Panel", WS_CHILD | BS_OWNERDRAW, x, y, w, h, parent, 
							(HMENU) NULL, hinst, (LPVOID) NULL);
		if (!NewPanel->PanelWnd) return FALSE; 
	}

	ShowWindow(NewPanel->PanelWnd, nCmdShow);
	SetWindowPos(parent, 0, 0, 0, x+PanelSize+HSpacing, PanelSize, SWP_NOMOVE | SWP_NOZORDER);

	if (Panels)
	{
		NewPanel->next = Panels->start;
		Panels->start = NewPanel;
	}
	else
	{
		Panels = (PanelList*)malloc(sizeof(PanelList));
		NewPanel->next = NULL;
		Panels->start = NewPanel;
	}

	if (LOADED)
	{
		FILE* config = fopen("WinPanel.rc", "r");
		FILE* tempconfig = tmpfile();
		char parentname[256] = "";
		char newentry[256] = "";

		GetWindowText(parent, temp, 256);
		sprintf(parentname, "*SectionStart \"%s\"", temp);
		sprintf(newentry, "*Panel \"%s\" \"%s\" \"%s\"", NewPanel->progstr, NewPanel->bmpstr, NewPanel->execstr);

		while (fgets(temp, 256, config))
		{
			if (!strnicmp(temp, parentname, strlen(parentname)))
			{
				fprintf(tempconfig, "%s", temp);
				while (fgets(temp, 256, config))
				{
					if (strstr(temp, "*SectionEnd"))
					{
						fprintf(tempconfig, "%s\n", newentry);
						fprintf(tempconfig, "%s", temp);
						break;
					}
					fprintf(tempconfig, "%s", temp);
				}
			}
			else
			{
				fprintf(tempconfig, "%s", temp);
			}
		}
		
		rewind(tempconfig);
		fclose(config);
		config = fopen("WinPanel.rc", "w");
		
		while (fgets(temp, 256, tempconfig))
		{
			fprintf(config, "%s", temp);
		}

		fclose(tempconfig);
		fclose(config);
	}

	return 1;
}

int EditPanel(HWND panel)
{
	Panel* p = Panels->start;
	while (p)
	{
		if (p->PanelWnd == panel)
		{

		}

		p = p->next;
	}
	return 1;
}

int RemovePanel(HWND panel)
{
	return 1;
}

///////////////////////////////////////////////////////////////////////////////

///////////////////////////////
// MISC FUNCTIONS
///////////////////////////////

int BrowseForFile(HWND parent, char* filename, int i)
{
	OPENFILENAME* of	= malloc(sizeof(OPENFILENAME));
	of->lStructSize	= sizeof(OPENFILENAME);
	of->hwndOwner	= parent;
	of->hInstance	= NULL;
	if (i == 1) { of->lpstrFilter	= "Executables (*.exe *.com)\0*.exe;*.com\0All Files (*.*)\0*.*\0\0"; }
	else if (i == 2) { of->lpstrFilter	= "Bitmaps (*.bmp)\0*.bmp\0All Files (*.*)\0*.*\0\0"; }
	of->lpstrCustomFilter = NULL;
	of->nMaxCustFilter	= 0;
	of->nFilterIndex	= 0;
	of->lpstrFile		= filename;
	of->nMaxFile		= MAX_PATH;
	of->lpstrFileTitle	= NULL;
	of->lpstrInitialDir	= NULL;
	of->lpstrTitle		= "WinPanel Browse";
	of->Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;

	if (GetOpenFileName(of))
	{
		free(of);
		return 1;
	}
	else return 0;
}

int HideTaskbar()
{
	HWND tray = FindWindow("Shell_TrayWnd", NULL);

	if (tray)
	{
		ShowWindow(tray, SW_HIDE);
	}

	return 0;
}

int ShowTaskbar()
{
	HWND tray = FindWindow("Shell_TrayWnd", NULL);

	if (tray)
	{
		ShowWindow(tray, SW_SHOW);
	}

	return 0;
}

int WPTransparentBlt(HDC hdc, HWND hwnd, int edge)
{
	HDC buf = CreateCompatibleDC(NULL);
	HDC trans = CreateCompatibleDC(GetDC(NULL));
	HBITMAP mask = CreateBitmap( PanelSize, PanelSize, 1, 1, NULL );
	RECT r;
	Panel* p = Panels->start;

	while (p)
	{
		if (p->PanelWnd == hwnd) { break; }
		p = p->next;
	}

	GetClientRect(hwnd, &r);
	SelectObject(buf, p->PanelBmp);

	SelectObject(trans, mask);
	SetBkColor(buf, RGB(255,0,255));
	BitBlt( trans, 0, 0, PanelSize, PanelSize, buf, 0, 0, SRCCOPY );
	SetBkColor( buf, RGB(0,0,0) );
	SetTextColor( buf, RGB(255,255,255) );
	BitBlt( buf, 0, 0, PanelSize, PanelSize, trans, 0, 0, SRCAND );
	SetBkColor( hdc, RGB(255,255,255) );
	SetTextColor( hdc, RGB(0,0,0) );
	BitBlt( hdc, 0, 0, PanelSize, PanelSize, trans, 0, 0, SRCAND );
	BitBlt( hdc, 0, 0, PanelSize, PanelSize, buf, 0, 0, SRCPAINT);

	if (!p->module && DRAWEDGES) DrawEdge(hdc, &r, edge, BF_RECT);

	DeleteDC(buf);
	DeleteDC(trans);
	DeleteObject(mask);

	return 1;
}