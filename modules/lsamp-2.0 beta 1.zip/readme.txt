< >  lsAmp - a winAmp frontend for LiteStep (v2 is even more)    < >
<!>==============================================================<!>
< >                                                              < >
<#>    lsAmp v1 was developed by Gustav Munkby aiming at         <#>
< >  becomming a functional winAmp front-end for LiteStep.       < >
< >  The program is built on the same feature as geekMaster's    < >
< >  geekAmp. The main difference is that this is a skinnable    < >
< >  frontend and not just a couple bang-commands                < >
< >    But I wasn't really satisfied with the module when I      < >
< >  was more or less ready. Therefore I started creating v2,    < >
< >  which will be more than a front-end for winAmp. when I'm    < >
< >  finished it will not only be a "remote control" for         < >
< >  winAmp, but a "remote control" for everything on your       < >
< >  computer, including, executing of programs, bang commands   < >
< >  and some "in-program" functions (like the ones from         < >
< >  winAmp). Does it sound promising, just wait and see!        < >
< >                                                              < >
< >                                    developer: Gustav Munkby  < >
< >                                              grd@swipnet.se  < >
< >                                                              < >
< >                                                              < >
< >  installation                                                < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>  1) unpack the lsAmp.dll into your LiteStep directory.       <#>
< >     (beta version only)                                      < >
< >                                                              < >
<#>  2) add the line to step.rc looking somewhat like this:      <#>
< >     *wharf "lsAmp" .none "@c:\litestep\lsAmp.dll"            < >
< >                                                              < >
<#>  3) start playin' around with the settings in your step.rc   <#>
< >     and images for the frontend. (final version will         < >
< >     contain a default "skin", anyone want to create one?)    < >
< >                                                              < >
< >                                                              < >
< >  configuring                                                 < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>    lsAmp supports three different controls in it's user      <#>
< >  interface. They are: images, buttons & sliders.             < >
< >                                                              < >
<#>  Images:  A control with just an image displaying on top of  <#>
< >           the background image.                              < >
< >                                                              < >
<#>  Buttons: A control which is like an image, but with one     <#>
< >           major difference, it has an clicking action.       < >
< >           (final version might contain ctrl+click actions)   < >
< >           (or rightclick action or something, comments   )   < >
< >                                                              < >
<#>  Sliders: A control which has a handle which you can move    <#>
< >           either from side to side or up and down.           < >
< >                                                              < >
< >    lsAmp at least is supposed to be intelligent when it      < >
< >  comes to configuration, and it's supposed to be really      < >
< >  simple. The syntax for an image is as follows:              < >
< >                                                              < >
<#>  *lsAmpControl pos(x,y) size(width,height) image(src)        <#>
< >                                                              < >
< >  For buttons the syntax is the following:                    < >
< >                                                              < >
<#>  *lsAmpControl pos(x,y) size(width,height) image(src) ...    <#>
<#>  ... action(command)                                         <#>
< >                                                              < >
< >  THE "..." MEANS THAT EVERYTHING SHOULD BE ON ONE LINE, AND  < >
< >  THE "..." SHOULD BE EXCLUDED.                               < >
< >                                                              < >
< >  The syntax for sliders is:                                  < >
< >                                                              < >
<#>  *lsAmpControl pos(x,y) size(width,height) image(src) ...    <#>
<#>  ... action(command) handlesize(width,height) ...            <#>
<#>  ... handleimage(src)                                        <#>
< >                                                              < >
< >  THE "..." MEANS THAT EVERYTHING SHOULD BE ON ONE LINE, AND  < >
< >  THE "..." SHOULD BE EXCLUDED.                               < >
< >                                                              < >
<#>    This means that all controls are created in an almost     <#>
< >  identical way, which makes it very easy. This means that    < >
< >  every line starting with *lsAmpControl is read in and then  < >
< >  lsAmp figures out whether the information supplied is an    < >
< >  image, button or slider. Which gives you the possability    < >
< >  to leave out some properties for the control.               < >
< >  for example, the size property isn't required to be set     < >
< >  if there is an image source supplied. On the other hand     < >
< >  imagesource isn't required if you specify the size.         < >
< >                                                              < >
<#>  if you don't understand this, it doesn't really matter,     < >
< >  just know that all these are valid lines:                   < >
< >                                                              < >
<#>  *lsAmpControl image(pic.bmp) pos(4,20) size(8,8) ...        <#>
<#>  ... action(play)                                            <#>
< >                                                              < >
<#>  *lsAmpControl image("pic two.bmp") pos(8,40) ...            <#>
<#>  ... size(48,8) action(vertvolume) ...                       <#>
<#>  ... handleimage(pic.bmp) handlesize(8,6)                    <#>
< >                                                              < >
<#>  *lsAmpControl pos(4,20) image(pic.bmp) ...                  <#>
<#>  ... action(horzpanning) handleimage(pic.bmp)                <#>
< >                                                              < >
<#>  *lsAmpControl pos(4,20) size(16,16) action(horvolume) ...   <#>
<#>  ... slidersize(8,10)                                        <#>
< >                                                              < >
<#>  *lsAmpControl size(16,16) action(next)                      <#>
< >                                                              < >
<#>  The only thing that shouldn't be easy to understand yet,    <#>
< >  is the things standing inside the action parantheses.       < >
< >  For sliders the valid actions are:                          < >
< >                                                              < >
<8>  horzvolume  = horizontal volume slider (winAmp)             <8>
<8>  vertvolume  = vertical volume slider (winAmp)               <8>
<8>  horzpanning = horizontal panning slider (winAmp)            <8>
<8>  vertpainnng = vertical panning slider (winAmp)              <8>
<8>  horztime    = horizontal time slider (winAmp)               <8>
<8>  verttime    = vertical time slider (winAmp)                 <8>
< >                                                              < >
<#>  For buttons the pre-defined actions are:                    <#>
< >                                                              < >
<8>  eq,equalizer   = toggle equalizer window (winAmp)           <8>
<8>  exit           = terminate (winAmp)                         <8>
<8>  ff,fastforward = fastforward (5 sec) (winAmp)               <8>
<8>  mb,browser,    = toggle minibrowser window (winAmp)         <8>
<8>  minibrowser                                                 <8>
<8>  menu           = show main-menu (winAmp) / lsAmp menu       <8>
<8>  mw,main        = toggle main window (winAmp)                <8>
<8>  next           = go to next track (winAmp)                  <8>
<8>  paus, pause    = pause the current track (winAmp)           <8>
<8>  pe,playlist    = toggle playlist window (winAmp)            <8>
<8>  play           = play current track (winAmp)                <8>
<8>  prev,previous  = go to previous track (winAmp)              <8>
<8>  rew,rewind     = rewind (5 sec) (winAmp)                    <8>
<8>  stop           = stop the current track (winAmp)            <8>
<8>  vdn,volumedown = decrease volume (winAmp)                   <8>
<8>  vup,volumeup   = increase volume (winAmp)                   <8>
< >                                                              < >
<#>  Buttons also have this exciting feature that they can       <#>
<#>  both ordinary commands & bang-commands (simlar to wharf)    <#>
<#>  For any of these just type in whatever the command is!      <#>
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  additional notes                                            < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    Nothing here yet, except the fact that I'd like to be     < >
< >  presented with a lot of ideas, help and stuff like that.    < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  the man                                                     < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >  Gustav Munkby, online known as grim reaper or grd           < >
< >  The man behind the concept "grd" which stands for;          < >
< >  grim reaper designs, which is my web-page and what I do on  < >
< >  the computer.                                               < >
< >  This is where you find me online:                           < >
< >                                                              < >
<?>  e-mail:      grd@swipnet.se                                 <?>
<?>  webpage:     http://home.swipnet.se/grd/                    <?>
<?>  lsAmp-web:   http://home.swipnet.se/grd/lsAmp/              <?>
<?>  icq:         1349988                                        <?>
<?>  irc:         #litestep/#lsdev/#winprog (nick: grd)          <?>
< >                                                              < >
<|>**************************************************************<|>
