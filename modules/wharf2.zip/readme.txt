Wharf2.dll

This is a simple hack of the normal wharf.dll

To use it, add to step.rc:

LoadModule C:\litestep\wharf2.dll

Then define you second wharf's items using *Wharf2 instead of *Wharf

It uses the same settings as your first wharf except for the following:

Wharf2CapHeight
Wharf2NoTitleBar
Wharf2TitleFore
Wharf2TitleBack
Wharf2TitlebarPix

I changed only the settings affecting the wharf cap/titlebar for now. If this appears
to be a well liked hack, I will make any requested changes to it.

Send bug reports, comments and requests to cyber@cbj.net

