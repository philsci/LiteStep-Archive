#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define SIZE 10
#define STEP 5
#define NUM_BOLTS 4
#define NUM_PENS 3
#define TIMER 100

HINSTANCE hinst = NULL; 
HWND hwndMain = NULL; 
char* szAppName = "bolt";

int X = 0, Y = 0;
int W = 400, H = 200;
HPEN pen[NUM_PENS];

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
	WNDCLASS wc;
    MSG msg;
	UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;  // save instance handle 

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = hInstance;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	srand(time(NULL));

	for (int cp=0; cp<NUM_PENS; cp++)
	{
		int r = 255-(cp*(255/NUM_PENS));
		int g = 255-(cp*(255/NUM_PENS));
		int b = 255;
		pen[cp] = CreatePen(PS_SOLID, cp+1, RGB(r, g, b));
	}


	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW,
							  szAppName, szAppName,
							  WS_POPUP | WS_VISIBLE,
							  X, Y,
							  W, H,
							  NULL, NULL, hInstance, NULL);

	if (!hwndMain) return FALSE;

	SetTimer(hwndMain, 0, TIMER, NULL);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

	KillTimer(hwndMain, 0);
	if (hwndMain) DestroyWindow(hwndMain);

	for (int pc=0; pc<NUM_PENS; pc++)
	{
		DeleteObject(pen[pc]);
	}

	return msg.wParam; 
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hwndMain);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;
	
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			RECT r;

			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));

			SelectObject(hdc, (HPEN)GetStockObject(WHITE_PEN));

			for (int count=0; count < NUM_BOLTS; count++)
			{
				//int y=rand()%H;
				int y=H/2;

				for (int x=0; x<W; x+=STEP)
				{
					int oldy = y;

					if (abs(W/2)-x)
					{
						if (rand()%2) y += rand()%abs(((W/2)-x))%SIZE;
						else y -= rand()%abs(((W/2)-x))%SIZE;
					}
					else
					{
						if (rand()%2) y += rand()%SIZE;
						else y -= rand()%SIZE;
					}

					for (int cp=NUM_PENS-1; cp>=0; cp--)
					{
						SelectObject(hdc, pen[cp]);
						MoveToEx(hdc, x, oldy, NULL);
						LineTo(hdc, x+STEP, y);
					}
				}
			}

			EndPaint(hwnd, &ps);
		}
		break;

		case WM_MOUSEMOVE: SetCursor(LoadCursor(NULL, IDC_ARROW)); break;

		case WM_TIMER:
		{
			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wParam, lParam);
}
