#if !defined(__UTILITY_H)
#define __UTILITY_H

BOOL IsAppWindow(HWND hWnd);
void SwitchToThisWindow(HWND hWnd, BOOL restore);

#endif
