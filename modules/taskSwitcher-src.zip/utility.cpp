#include "common.h"
#include "utility.h"

// is the given window a toplevel application window?
BOOL IsAppWindow(HWND hWnd)
{
	if(!IsWindowVisible(hWnd))
		return FALSE;

	if(GetWindow(hWnd, GW_OWNER) != 0)
		return FALSE;

	long exStyle = GetWindowLong(hWnd, GWL_EXSTYLE);

	if(exStyle & WS_EX_APPWINDOW)
		return TRUE;

	if(exStyle & WS_EX_TOOLWINDOW)
		return FALSE;

	if(GetWindowLong(hWnd, GWL_USERDATA) == 0x49474541)
		return FALSE;

	return true;
}

// undocumented API to switch window activation
void SwitchToThisWindow(HWND hWnd, BOOL restore)
{
	void (WINAPI *SwitchToThisWindowF)(HWND, BOOL) = (void (WINAPI *)(HWND, BOOL)) GetProcAddress(
		GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

	SwitchToThisWindowF(hWnd, restore);
}
