#include "common.h"
#include "bangCommands.h"
#include "TaskList.h"

void SwitchToPreviousTaskBangCommand(HWND hCaller, const char *args);
void SwitchToNextTaskBangCommand(HWND hCaller, const char *args);

// bang commands implemented by this module
struct { const char *name; BangCommand *function; } bangCommands[] = {
	{ "!SwitchToPreviousTask", SwitchToPreviousTaskBangCommand },
	{ "!SwitchToNextTask", SwitchToNextTaskBangCommand }
};

const int bangCommandCount = sizeof(bangCommands) / sizeof(bangCommands[0]);

void AddBangCommands()
{
	// register bang commands with LSAPI
	for(int i = 0; i < bangCommandCount; i++)
		AddBangCommand(bangCommands[i].name, bangCommands[i].function);
}

void RemoveBangCommands()
{
	// unregister bang commands that were registered in AddBangCommands
	for(int i = 0; i < bangCommandCount; i++)
		RemoveBangCommand(bangCommands[i].name);
}

void SwitchToPreviousTaskBangCommand(HWND hCaller, const char *args)
{
	taskList->switchToPrevious();
}

void SwitchToNextTaskBangCommand(HWND hCaller, const char *args)
{
	taskList->switchToNext();
}
