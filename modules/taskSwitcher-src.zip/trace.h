#if !defined(__TRACE_H)
#define __TRACE_H

#if !defined(DEBUG)
#define TRACE if(0) trace
#else
#define TRACE trace
#endif

void trace(const char *format, ...);

#endif
