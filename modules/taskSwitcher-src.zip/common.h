#if !defined(__COMMON_H)
#define __COMMON_H

#include <string>
#include <vector>

using namespace std;

typedef bool boolean;

#define WIN32_LEAN_AND_MEAN
#define STRICT
// #define DEBUG

#include <windows.h>
#include "lsapi.h"
#include "utility.h"
#include "trace.h"

#endif
