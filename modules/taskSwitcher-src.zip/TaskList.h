#if !defined(__TASKLIST_H)
#define __TASKLIST_H

class TaskList
{
public:

	TaskList(HINSTANCE hInstance);
	virtual ~TaskList();

	void switchToPrevious();
	void switchToNext();
	void switchTo(HWND hWnd);

protected:

	void updateList();

private:

	HWND hWnd;
	HINSTANCE hInstance;

	vector<HWND> tasks;
	int active;

protected:

	virtual int onGetRevID(int level, char *buffer);
	virtual void onTimer();
	virtual boolean onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult);

private:

	static BOOL WINAPI enumWindowsProcedure(HWND hWnd, LPARAM lParam);
	static LRESULT WINAPI windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

extern TaskList *taskList;

#endif
