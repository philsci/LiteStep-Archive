#include "common.h"
#include "TaskList.h"

#define TIMER_ID 1
#define TIMER_INTERVAL 1500

int lsMessages[] = {
	LM_GETREVID,
	0
};

TaskList::TaskList(HINSTANCE hInstance)
{
	hWnd = 0;
	this->hInstance = hInstance;

	WNDCLASSEX wc;

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS | CS_DBLCLKS;
	wc.lpfnWndProc = TaskList::windowProcedure;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = sizeof(TaskList *);
	wc.hInstance = hInstance;
	wc.hbrBackground = 0;
	wc.hCursor = LoadCursor(0, IDC_ARROW);
	wc.hIcon = 0;
	wc.lpszMenuName = 0;
	wc.lpszClassName = "TaskListLS";
	wc.hIconSm = 0;

	RegisterClassEx(&wc);

	hWnd = CreateWindowEx(WS_EX_TOOLWINDOW,
		"TaskListLS",
		0,
		WS_POPUP,
		0, 0, 0, 0, 0, 0,
		hInstance,
		this);

	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE,
		(WPARAM) hWnd, (LPARAM) lsMessages);

	updateList();
	SetTimer(hWnd, TIMER_ID, TIMER_INTERVAL, 0);
}

TaskList::~TaskList()
{
	KillTimer(hWnd, TIMER_ID);

	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE,
		(WPARAM) hWnd, (LPARAM) lsMessages);

	DestroyWindow(hWnd);
	UnregisterClass("TaskListLS", hInstance);
}

void TaskList::switchToPrevious()
{
	active = (active + tasks.size() - 1) % tasks.size();
	switchTo(tasks[active]);
}

void TaskList::switchToNext()
{
	active = (active + 1) % tasks.size();
	switchTo(tasks[active]);
}

void TaskList::switchTo(HWND hWnd)
{
	SendMessage(GetLitestepWnd(), LM_BRINGTOFRONT, 0, (LPARAM) hWnd);
	SwitchToThisWindow(hWnd, TRUE);
	SetTimer(this->hWnd, TIMER_ID, TIMER_INTERVAL, 0);
}

void TaskList::updateList()
{
	int i;

	vector<HWND> oldTasks = tasks;
	tasks.clear();

	for(i = 0; i < oldTasks.size(); i++)
	{
		if(IsWindow(oldTasks[i]) && IsAppWindow(oldTasks[i]) && !IsIconic(oldTasks[i]))
			tasks.push_back(oldTasks[i]);
	}

	EnumWindows(enumWindowsProcedure, (LPARAM) this);

	/*HWND nextTask = GetWindow(GetDesktopWindow(), GW_CHILD);

	while(nextTask)
	{
		if(IsAppWindow(nextTask))
			tasks.push_back(nextTask);

		nextTask = GetWindow(nextTask, GW_HWNDNEXT);
	}*/

	HWND activeTask = GetForegroundWindow();

	for(i = 0; i < tasks.size(); i++)
	{
		if(tasks[i] == activeTask)
		{
			active = i;
			break;
		}
	}
}

int TaskList::onGetRevID(int level, char *buffer)
{
	strcpy(buffer, "TaskSwitcher 1.0 (Maduin)");
	return strlen(buffer);
}

void TaskList::onTimer()
{
	updateList();
}

boolean TaskList::onWindowMessage(UINT message, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	switch(message)
	{
		case LM_GETREVID:
		{
			lResult = onGetRevID((int) wParam, (char *) lParam);
			return true;
		}

		case WM_TIMER:
		{
			onTimer();
			return true;
		}
	}

	return false;
}

BOOL TaskList::enumWindowsProcedure(HWND hWnd, LPARAM lParam)
{
	if(IsAppWindow(hWnd) && !IsIconic(hWnd))
	{
		TaskList *taskList = (TaskList *) lParam;
		boolean found = false;

		for(int i = 0; i < taskList->tasks.size(); i++)
		{
			if(taskList->tasks[i] == hWnd)
			{
				found = true;
				break;
			}
		}

		if(!found)
			taskList->tasks.push_back(hWnd);
	}

	return TRUE;
}

LRESULT TaskList::windowProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	TaskList *taskList = (TaskList *) GetWindowLong(hWnd, 0);

	if(message == WM_NCCREATE)
	{
		taskList = (TaskList *) ((CREATESTRUCT *) lParam)->lpCreateParams;
		taskList->hWnd = hWnd;
		SetWindowLong(hWnd, 0, (LONG) taskList);
	}

	if(taskList)
	{
		LRESULT lResult = 0;

		if(taskList->onWindowMessage(message, wParam, lParam, lResult))
			return lResult;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

TaskList *taskList;
