#include "common.h"
#include "bangCommands.h"
#include "TaskList.h"

// HANDLE hThread;
// DWORD threadID;

/* int WINAPI MainThread(HINSTANCE hInstance)
{
	taskList = new TaskList(hInstance);
	AddBangCommands();

	MSG msg;

	while(GetMessage(&msg, 0, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	RemoveBangCommands();
	delete taskList;

	return 0;
} */

int initModuleEx(HWND hParent, HINSTANCE hInstance, const char *lsPath)
{
	taskList = new TaskList(hInstance);
	AddBangCommands();

	/* hThread = CreateThread(0,
		0,
		(LPTHREAD_START_ROUTINE) MainThread,
		(void *) hInstance,
		0,
		&threadID); */

	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommands();
	delete taskList;

	/* PostThreadMessage(threadID, WM_QUIT, 0, 0);
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread); */
}
