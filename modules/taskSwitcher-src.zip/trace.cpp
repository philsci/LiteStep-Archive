#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdarg.h>
#include "trace.h"

void trace(const char *format, ...)
{
	va_list argList;
	char buffer[4096];

	va_start(argList, format);
	wvsprintf(buffer, format, argList);
	va_end(argList);
	strcat(buffer, "\r\n");

	HANDLE hOutput = CreateFile("\\TRACE.LOG",
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		0,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		0);

	SetFilePointer(hOutput, 0, 0, FILE_END);

	unsigned long byteCount;
	WriteFile(hOutput, buffer, strlen(buffer), &byteCount, 0);

	CloseHandle(hOutput);
}
