#include <windows.h>
#include "lsapi.h"
#include "exports.h"

//const long magicDWord = 0x49474541;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();

int ScreenX, ScreenY;
char* szAppName = "jamp";
HINSTANCE hInstance;
HWND hwndMain, hwndJamp, hwndParent;
int msgs[] = {LM_GETREVID, 0};
int x, y, w, h;
HBITMAP bgbmp;

char title[256] = "";
HWND winamp=NULL;
HFONT font;
COLORREF color, bgcolor;
HBRUSH bgbrush;
int speed=25;
BOOL SCROLL=TRUE, USEBGCOLOR=FALSE;

DWORD ALIGNMENT = DT_LEFT;
char FORMAT[256] = "";
char LEFTCLICK[256] = "";
char RIGHTCLICK[256] = "";
char MIDDLECLICK[256] = "";
char NOWINAMPTEXT[256] = "";

int BL=0, BR=0, BT=0, BB=0;

void BangToggleScroll(HWND caller, const char* args)
{
	if (!SCROLL)
	{
		SCROLL=TRUE;
		SetTimer(hwndMain, 1, speed, NULL);
	}
	else
	{
		SCROLL=FALSE;
		KillTimer(hwndMain, 1);
	}
}

void BangMove(HWND caller, const char* args)
{
	if (args)
	{
		char	token1[4096], token2[4096], extra_text[4096];
		char*	tokens[2];
		int count;

		tokens[0] = token1;
		tokens[1] = token2;
		token1[0] = token2[0] = extra_text[0] = '\0';

		count = LCTokenize (args, tokens, 2, extra_text);
		if (count == 2)
		{
			// Clear it out!
			KillTimer(hwndMain, 0);
			KillTimer(hwndMain, 1);
			SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
			DestroyWindow(hwndMain);
			DeleteObject(bgbmp);
			bgbmp=NULL;
			hwndMain=NULL;

			// Create it up!
			hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
									  szAppName, szAppName, 
									  WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
									  atoi(token1), atoi(token2), 
							          w, h, 
									  NULL, NULL, hInstance, NULL);
			
			if (hwndMain)
			{
				SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
				SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
				if (GetRCBool("jampAlwaysOnTop", TRUE)) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
				SetTimer(hwndMain, 0, 100, NULL);
				SetTimer(hwndMain, 1, speed, NULL);
			}
		}
	}
}

void BangHome(HWND caller, const char* args)
{
	BangMove(caller, "0 0");
}

void BangShow(HWND caller, const char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangHide(HWND caller, const char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void LoadSetup()
{
	char temp[256] = "";
	int size;

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!jampToggleScroll", BangToggleScroll);
	AddBangCommand("!jampShow", BangShow);
	AddBangCommand("!jampHide", BangHide);
	AddBangCommand("!jampToggle", BangToggle);
	AddBangCommand("!jampMove", BangMove);
	AddBangCommand("!jampHome", BangHome);
	
	x = GetRCInt("jampX", 0);
	if (x < 0) x = ScreenX+x;
	y = GetRCInt("jampY", 0);
	if (y < 0) y = ScreenY+y;
	w = GetRCInt("jampW", 400);
	h = GetRCInt("jampH", 25);

	size = GetRCInt("jampFontSize", 12);
	GetRCString("jampFont", temp, "Arial", 256);

	font = CreateFont(size, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	color = GetRCColor("jampFontColor", 0x00FFFFFF);

	speed = GetRCInt("jampSpeed", 25);

	USEBGCOLOR = GetRCBool("jampBackColor", TRUE);
	if (USEBGCOLOR) 
	{
		bgcolor = GetRCColor("jampBackColor", 000000);
		bgbrush = CreateSolidBrush(bgcolor);
	}

	GetRCString("jampBackBmp", temp, "", 256);
	bgbmp = LoadLSImage(temp, temp);

	GetRCString("jampFormat", FORMAT, "%title% - %status% - %length% - %rem%", 256);
	GetRCString("jampLeftClick", LEFTCLICK, "", 256);
	GetRCString("jampRightClick", RIGHTCLICK, "", 256);
	GetRCString("jampMiddleClick", MIDDLECLICK, "", 256);
	GetRCString("jampNoWinampText", NOWINAMPTEXT, "", 256);

	if (GetRCBool("jampAlignCenter", TRUE)) ALIGNMENT = DT_CENTER;
	else if (GetRCBool("jampAlignRight", TRUE)) ALIGNMENT = DT_RIGHT;

	BL=GetRCInt("jampBorderLeft", 0);
	BR=GetRCInt("jampBorderRight", 0);
	BT=GetRCInt("jampBorderTop", 0);
	BB=GetRCInt("jampBorderBottom", 0);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	hwndParent = parent;
	hInstance = dllInst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc2;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.lpszClassName = "jampParent";   // our window class name
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}

	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  "jampParent", "jampParent",
							  WS_POPUP, 
							  x, y, 
							  w, h, 
							  NULL, NULL, dllInst, NULL);

	if (!hwndMain) return 1;

	hwndJamp = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  szAppName, szAppName,
							  WS_CHILD | WS_VISIBLE, 
							  BL, BT, 
							  w-BL-BR, h-BT-BB, 
							  hwndMain, NULL, dllInst, NULL);
		
	if (GetRCBool("jampStartHidden", FALSE)) ShowWindow(hwndMain, SW_SHOW);
	if (GetRCBool("jampAlwaysOnTop", TRUE)) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
	if (GetRCBool("jampNoScroll", TRUE)) SCROLL=FALSE;

	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	SetTimer(hwndMain, 0, 100, NULL);
	SetTimer(hwndMain, 1, speed, NULL);

	return 0;
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!jampToggleScroll");
	RemoveBangCommand("!jampShow");
	RemoveBangCommand("!jampHide");
	RemoveBangCommand("!jampToggle");
	RemoveBangCommand("!jampMove");
	RemoveBangCommand("!jampHome");
	
	KillTimer(hwndMain, 0);
	KillTimer(hwndMain, 1);
	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);
	UnregisterClass("jampParent", dll);

	DeleteObject(bgbrush);
	DeleteObject(bgbmp);
	DeleteObject(font);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);
			sprintf(buf, "jamp 1.3 (MrJukes)\0");
			return strlen(buf);
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);

			if (!bgbmp && !USEBGCOLOR)
			{
				bgbmp = CreateCompatibleBitmap(hdc, w, h);
				oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!USEBGCOLOR)
			{
				oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
			}
			else
			{
				FillRect(buf, &r, (HBRUSH)bgbrush);
			}

			EndPaint(hwnd, &ps);
		}
		break;

		case WM_TIMER:
		{
			switch ((int)wParam)
			{
				case 0:
				{
					char temp[256] = "";

					if (!winamp) winamp = FindWindow("Winamp v1.x", NULL);
					else if (!IsWindow(winamp)) winamp = FindWindow("Winamp v1.x", NULL);

					if (winamp)
					{
						char buf[256] = "";
						char* tformat = _strdup(FORMAT);

						GetWindowText(winamp, temp, 256);
						memset(&title, 0, sizeof(title));

						char* p = strstr(temp, " - Winamp");
						strncpy(buf, temp, p-temp);
									
						int length = SendMessage(winamp, WM_USER, 1, 105);
						int position = SendMessage(winamp, WM_USER, 0, 105);

						char* t = strtok(tformat, "%");
						while (t)
						{
							if (!_stricmp(t, "title")) strcat(title, buf);
							else if (!_stricmp(t, "status")) 
							{
								int status = SendMessage(winamp, WM_USER, 0, 104);
								if (status == 1) strcat(title, "Playing");
								else if (status == 3) strcat(title, "Paused");
								else strcat(title, "Stopped");
							}
							else if (!_stricmp(t, "length"))
							{
								char len[100] = "";
								if (length != -1) sprintf(len, "%d:%02d", length/60, length%60);
								else sprintf(len, "0:00");
								strcat(title, len);
							}
							else if (!_stricmp(t, "pos"))
							{
								char pos[100] = "";
								if (position != -1) sprintf(pos, "%d:%02d", position/1000/60, position/1000%60);
								else sprintf(pos, "0:00");
								strcat(title, pos);
							}
							else if (!_stricmp(t, "rem"))
							{
								char rem[100] = "";
								int remaining = length - (position/1000);
								if (length != -1 && position != -1)
									sprintf(rem, "%d:%02d", remaining/60, remaining%60);
								else sprintf(rem, "0:00");
								strcat(title, rem);
							}
							else strcat(title, t);

							t=strtok(NULL, "%");
						}
					}
				}

				case 1:
				{
					InvalidateRect(hwndMain, NULL, TRUE);
				}
				break;
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

LRESULT CALLBACK WndProc2(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
			HBITMAP oldbuf, oldsrc;
			RECT r;
			static int scroll=0;
			static char* p = title;
			char temp[512] = "";

			GetClientRect(hwnd, &r);

			if (!bgbmp && !USEBGCOLOR)
			{
				bgbmp = CreateCompatibleBitmap(hdc, w, h);
				oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!USEBGCOLOR)
			{
				oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
			}
			else
			{
				FillRect(buf, &r, (HBRUSH)bgbrush);
			}

			SelectObject(buf, font);
			SetBkMode(buf, TRANSPARENT);
			SetTextColor(buf, color);

			strcpy(temp, title);
			strcat(temp, "  ");

			DrawText(buf, temp, strlen(temp), &r, DT_CALCRECT | ALIGNMENT);
			if (r.right > (w-BB-BL) && SCROLL)
			{
				if (r.right-scroll < BL) 
				{
					scroll=BL;
				}
				else if (r.right-scroll < (w-BB-BL))
				{
					strcat(temp, title);
				}

				SetRect(&r, r.left-scroll++, r.top, r.right, r.bottom);
			}
			else if (r.right < w)
			{
				SetRect(&r, r.left, r.top, w, r.bottom);
			}

			DrawText(buf, temp, strlen(temp), &r, ALIGNMENT | DT_EXPANDTABS);

			BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

			SelectObject(src, oldsrc);
			DeleteDC(src);
			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_LBUTTONUP:
		{
			if (LEFTCLICK[0] == '!') ParseBangCommand(hwndMain, LEFTCLICK, "");
			else ShellExecute(NULL, "open", LEFTCLICK, NULL, NULL, SW_SHOWNORMAL);
		}
		break;

		case WM_RBUTTONUP:
		{
			if (RIGHTCLICK[0] == '!') ParseBangCommand(hwndMain, RIGHTCLICK, "");
			else ShellExecute(NULL, "open", RIGHTCLICK, NULL, NULL, SW_SHOWNORMAL);
		}
		break;

		case WM_MBUTTONUP:
		{
			if (MIDDLECLICK[0] == '!') ParseBangCommand(hwndMain, MIDDLECLICK, "");
			else ShellExecute(NULL, "open", MIDDLECLICK, NULL, NULL, SW_SHOWNORMAL);
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}
