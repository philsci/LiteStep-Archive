 LSWeather B5 Readme                                                 4 October 2001
+----------------------------------+-----------------------------------------------+
|  Coded by:                       |  MrJukes (mrjukes@purdue.edu)                 |
|  Version B5 by:                  |  Seth (lrover@mindspring.com)                 |
+----------------------------------+-----------------------------------------------+

=================
Table of Contents
=================

- Instructions
  - Wharf Module
  - Load Module
- LSWeather Usage
- What's New
- Popups Menu
- Bang Commands
- String Formatting
- Current Issues
- Feedback, etc.


==========
* NOTICE *
==========
In order for LSWeather B5 to function properly you will have to use a Litestep build
from after approximately 10-9-99.  Anything before that build will probably result
in LSWeather crashing or improper functioning of the dialog boxes.


===========================
Instructions - Wharf Module
===========================

1) Unzip LSWeather to a directory off your Litestep dir.
	example: C:\Litestep\LSWeather\
2) Edit your step.rc file and add the following line:
	*Wharf LSWeather .none @C:\Litestep\LSWeather\lsweather.dll
3) Recycle Litestep
4) Enter the Settings dialog and load "C:\Litestep\LSWeather\lsw-wharfmodule.thm"
5) If you need help with the Settings dialog hit F1 or click on the "?" button and
   then click on an edit box or button.


==========================
Instructions - Load Module
==========================

1) Unzip LSWeather to a directory off your Litestep dir.
	example: C:\Litestep\LSWeather\
2) Edit your step.rc file and add the following line:
	LoadModule C:\Litestep\LSWeather\lsweather.dll
3) Recycle Litestep
4) Enter the Settings dialog and load "C:\Litestep\LSWeather\lsw-loadmodule.thm"
5) If you need help with the Settings dialog hit F1 or click on the "?" button and
   then click on an edit box or button.


===============
LSWeather Usage
===============

LSWeather can get weather conditions from almost anywhere on the globe, providing
that you supply it with a proper Zip Code for US residence, or a global station code for
international users.

To find out your Global Station Code goto www.wunderground.com and under the "International"
section choose the continent you live in, then on the map choose your city.  Now in
the URL box of your browser it should say a number followed by an .html extension.
This is your Global Station Code.

Some Global Station Codes:

	- London, England    = 03772
	- Paris, France      = 07150
	- Jerusalem, Israel  = 40184
        - Sydney, Australia  = 94767
	- Tokyo, Japan       = 47662
	- Hong Kong, China   = 45007
	- Toronto, Canada    = 71265
	- Vostok, Antarctica = 89606

Advanced Settings
-----------------
Apart from the configuration options in the in-program config dialog, there are three
advanced settings that can only set by editing the theme file directly.  These are:

 - Wind format string for when wind is calm.  This is in the section "Wind" and is called
   "Calm".  Treat it just like any other format string.  If there are leading or trailing
   spaces, surround it with quotes.

 - Wind style option.  This is called WindStyle, is in the Wind section, and can take four
   values: 0, 1, 2, or 3.  The following table illustrates their use:

     WindStyle value	Meaning		Examples
     -------------------------------------------
     	0		ALL CAPS	NNE, SOUTH
     	1		First Caps	NNE, South (default)
     	2		ABBR. caps	NNE, south
     	3		no caps		nne, south

 - Default string formats for report conditions dialog.  For information on this feature,
   see the section on string formatting.


=================
What's New in B5?
=================

  (in approximate order of importance)

 - Relative Feature Positioning
   I wanted a more natural-language weather readout,
   and found that varying field widths, esp. with
   wind and conditions, led to potentially large gaps
   between feature displays.  So, if you choose
   relative positioning, you specify the start (X,Y)
   coordinate, and enable one feature with the
   'follows' value left at "follows".  Then create a
   chain of features leading from that one.  Be warned
   that you should only enable one feature as the
   start feature, i.e. with the 'follows' field left
   to "follows".  Further features so configured will
   be ignored.

 - Min/max temperature
   LSWeather now records maximum and minimum
   observed temperatures.  Be warned, however,
   that it makes no distinction as to where a
   given temperature was observed, making it
   not beneficial for users who often switch
   locales.  If many people would like separate
   data for each locale, I may add the feature.

 - Heat index/windchill
   LSWeather calculates heat index and winchill.
   These values are determined from performing
   calculations upon other weather data, so the
   reporting station at wunderground.com does not
   need to provide them.

 - Format strings options
   An option has been added to use the custom
   format string in the Report Conditions dialog.
   If this is selected (the only choice in previous
   versions), the strings in the report conditions
   dialog will display information in the same format
   as the permanent display.  Otherwise, the program
   uses the format string as specified by the
   "Default" profile string in the theme file.

 - Extended ASCII character display
   To display any ASCII character, use the format
   '#xxx' where xxx is replaced by the one, two, or
   three digit ASCII code of that character.

 - Transparency
   Window transparency is now available, if no
   background bitmap is specified.

 - Config dialog changes
   I removed the 'Load' and 'Save' theme buttons from
   the config dialog, as they were somewhat redundant.
   Browsing for a new theme loads it, and themes are
   automatically saved.

 - Time & date
   Time and date are provided on the Report
   Conditions dialog.  This is the current system
   time and is not calibrated for distant stations.

 - Wind speed
   A numeric wind speed value is not recorded when
   wind is calm.  This means that all format
   specifiers after %Wk or %Wm are discarded when
   there is no wind.

 - Bugfixes
   ...reading wind speed from international stations
   ...error-checking when getting weather from the
      server

=================
What's New in B4?
=================

- Changed weather source, now www.wunderground.com
- LSWeather now is able to display:
	- Temperature, Humidity, Dewpoint
	- Pressure, Visibility, Wind
	- Sunrise, Sunset, Moonrise, Moonset
	- Weather Conditions in text or bitmap
- New configuration dialog controls:
	- All theme options
	- Saving and loading of new themes
- New bang commands:
	- !LSWHide, !LSWShow, !LSWToggle
	- !LSWUpdate, !LSWChangeSettings
	- !LSWLaunchWebpage, !LSWReport
	- !LSWAlwaysOntop (Toggle)
- Customizable double-click action
- Text display formatting added for all fields.
- All loadmodule display bugs fixed (for now)
- New incredible wharf and loadmodule themes created by Tritian! :P

=================
What's New in B3?
=================

- Added a favorites menu
- Fixed some bugs
- Moved weather conditions into the modules.ini instead of being hardcoded

=================
What's New in B2?
=================

- Can be loaded as a LoadModule
- Got rid of messagebox warning that it could not connect to weather.com
- Images can be in any directory


==========
Popup Menu
==========

Update                    - Update weather conditions for selected area.
Active                    - Toggles automatic update of the weather
Report Current Conditions - Brings up a dialog with all your weather conditions
Change Settings           - Changes your settings
Launch Webpage            - Launches www.wunderground.com to your current location
About LSWeather           - The About box
Reset Max/Min Temps       - Resets max and min temps to current temp
  -----
Favorites                 - Stores your favorites, add up to 10 favorites through settings.
  -----
Use Zip Code              - Uses the specified zip code
Use City                  - Uses the specified city file
Use Global Station        - Uses the global station code for your area.


=============
Bang Commands
=============

Load/Wharf Bang Commands:
  !LSWUpdate         - Updates weather conditions
  !LSWChangeSettings - Enters the settings dialog
  !LSWLaunchWebpage  - Launches www.wunderground.com
  !LSWReport         - Brings up a dialog with the current conditions.

LoadModule Specific Bang Commands:
  !LSWHide           - Hides LSWeather
  !LSWShow           - Shows LSWeather
  !LSWToggle         - Toggles Hide/Show of LSWeather
  !LSWAlwaysOntop    - Toggles LSWeather's always ontop status


=================
String Formatting
=================

 PLEASE NOTE:

 In addition to the format strings in the theme file,
 there is a field called "Default" which contains the formatting for the
 report conditions dialog should you choose NOT to mirror the custom
 string format for that dialog.  These values can only be changed by
 editing the file directly.


Temperature:
 + Valid Variables: %T[fck] %d
 - Example) Temp: %Tf %dF		==> Temp: 80 �F
 - Example) T: %Tc%dC			==> T: 27�C
 - Example) %Tk%dK			==> 278�K

Heat Index:
 + Valid Variables: %I[fck] %d
 - Example) Heat Index: %If %dF		==> Heat Index: 80 �F
 - Example) HI: %Ic%dC			==> HI: 27�C
 - Example) %Ik%dK			==> 278�K

Pressure:
 + Valid Variables: %P[ih]
 - Example) Pres: %Pi inches		==> Pres: 8 inches
 - Example) P: %Ph hPa			==> P: 270 hPa

Humidity:
 + Valid Variables: %H
 - Example) Hum: %H%			==> Hum: 38%

Dew Point:
 + Valid Variabes: %D[fck] %d
 - Example) Dew: %Df %dF		==> Dew: 80 �F
 - Example) D: %Dc%dC			==> D: 27�C
 - Example) %Dk%dK			==> 278�K

Visibility:
 + Valid Variables: %V[mk]
 - Example) Vis: %Vm miles		==> Vis: 10 miles
 - Example) Vis: %Vk km			==> Vis: 17 km

Wind:
 + Valid Variables: %W[dmk]
 - Example) Wind: %Wd at %Wm mph	==> Wind: NNW at 8mph
 - Example) Wind: %Wk kph		==> Wind: 12 kph

Windchill:
 + Valid Variables: %L[fck] %d
 - Example) Windchill: %Lf %dF		==> Windchill: 80 �F
 - Example) WC: %Lc%dC			==> WC: 27�C
 - Example) %Lk%dK			==> 278�K

Minimum Temp:
 + Valid Variables: %XL[fckhmw] %d
 - Example) Minimum: %XLf%dF at %XLh:%XLm %XLw     ==>Minimum: 45�F at 6:32 AM
 - Example) Mintemp: %XLc%dC @ %XLh:%XLh           ==>Mintemp: 12�C @ 5:49
 - Example) min: %XL%dF                            ==>min: 56�F

Maximum Temp:
 + Valid Variables: %XH[fckhmw] %d
 - Example) Maximum: %XHf%dF at %XHh:%XHm %XHw     ==>Maximum: 92�F at 3:42 PM
 - Example) Maxtemp: %XHc%dC @ %XHh:%XHh           ==>Maxtemp: 28�C @ 2:43
 - Example) max: %XH%dF                            ==>max: 62�F

Sunrise:
 + Valid Variables: %SR[hmwz]
 - Example) Sunrise: %SRh:%SRm%SRw %SRz	==> Sunrise: 6:15AM EDT
 - Example) SR: %SRh:%SRm %SRw		==> SR: 7:25 AM

Sunset:
 + Valid Variables: %SS[hmwz]
 - Example) Sunset: %SSh:%SSm%SSw %SSz	==> Sunset: 6:15PM EDT
 - Example) SS: %SSh:%SSm %SSw		==> SS: 7:25 PM

Moonrise:
 + Valid Variables: %MR[hmwz]
 - Example) Moonrise: %MRh:%MRm%MRw %MRz	==> Moonrise: 6:15AM EDT
 - Example) MR: %MRh:%MRm %MRw			==> MR: 7:25 AM

Moonset:
 + Valid Variables: %MS[hmwz]
 - Example) Moonset: %MSh:%MSm%MSw %MSz	==> Moonset: 6:15AM EDT
 - Example) MS: %MSh:%MSm %MSw		==> MS: 7:25 AM

Weather Conditions:
 + Valid Variables: %C
 - Example) %C				==> Partly Cloudy
 - Example) Cond: %C			==> Cond: Sunny


===============
Current Issues:
===============

 - Max and min temps are meaningless when locale changes
   (You can reset them to be valid for the current locale)
 - Reports local time for distant locations in report dialog
 - Does not support multiple leading relative-placed features.
   Of course, if it did, they would overlap and be illegible, so...
   LSWeather only pays attention to the first such feature.



===============
Feedback, etc.:
===============


   If anyone would like the same module in an .exe, perhaps for a non-Litestep user,
   or for whatever reason, I've got one, and would be happy to e-mail it to you.

   Also, if you wish a copy of the source, let me know.

   If you enjoy LSWeather B5, or have further feature requests, please tell me.
   Thanks to MrJukes, who created LSWeather and let me release this updated version,
   Visigoth for his online Litestep tutorials, and the entire Litestep community for
   the source code and online resources they have made available.  Lastly, I
   apologize if my readme is excessive in its verbiage... but there ya go, it's over.


                                                        - Seth McCarus
                                                          lrover@mindspring.com