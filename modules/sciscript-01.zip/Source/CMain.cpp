/*
This is a part of the Timer LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "CMain.h"

const char* szAppName = "SciScript";
const char* szVersion = "SciScript 0.1 (Sci)";
const char* szDetailed = "SciScript.dll version 0.1 date 2001-09-29 (Sci)";

CMain* pMain;

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	AddBangCommand("!ScriptStatus",		BangStatus);

	Window::init(dllInst);
	pMain = new CMain(parentWnd, code);

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!ScriptStatus");

	delete pMain;
}

void BangScript(HWND hCaller, LPCSTR szCommand, LPCSTR szArgs) {pMain->bangScript(szCommand, szArgs);}
void BangStatus(HWND hCaller, LPCSTR szArgs)		{pMain->bangStatus();		}

CMain::CMain(HWND parentWnd, int& code):
Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "SciScript", WS_CHILD, 0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);
		code = 1;
		return;
	}
	code = 0;
}

CMain::~CMain()
{
	destroyWindow();
}

void CMain::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onCreate, WM_CREATE)
		MESSAGE(onDestroy, WM_DESTROY)
		MESSAGE(onEndSession, WM_ENDSESSION)
		MESSAGE(onEndSession, WM_QUERYENDSESSION)
		REJECT_MESSAGE(WM_ERASEBKGND)
		REJECT_MESSAGE(WM_PAINT)
		MESSAGE(onGetRevId, LM_GETREVID)
		MESSAGE(onSysCommand, WM_SYSCOMMAND)
	END_MESSAGEPROC
}

void CMain::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	bDebug = GetRCBoolDef("ScriptDebug", FALSE);
	pFuncs = NULL;
	pBangs = NULL;

	FILE* fpStep;
	fpStep = LCOpen(NULL);
	if(fpStep)
	{
		char szBuffer[4096];
		char szScript[4096], szFile[4096];
		char* tl[1];

		tl[0] = szScript;
		szBuffer[0] = 0;
		while(LCReadNextConfig(fpStep, "*ScriptFile", szBuffer, sizeof(szBuffer)))
		{
			szFile[0] = 0;
			LCTokenize(szBuffer, tl, 1, szFile);
			LoadScriptFile(szFile);
		}
		LCClose(fpStep);
	}
}

void CMain::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	CScript* pTemp = pBangs;
	while(pTemp)
	{
		char szTemp[4096];
		strcpy(szTemp, "!");
		strcat(szTemp, pTemp->szName);
		RemoveBangCommand(szTemp);

		pTemp = pTemp->pNext;
	}

	FreeScripts(pFuncs);
	FreeScripts(pBangs);
}

void CMain::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void CMain::onGetRevId(Message& message)
{
	char* szBuffer = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		strcpy(szBuffer, szVersion);
		break;
	case 1:
		strcpy(szBuffer, szDetailed);
		break;
	default:
		strcpy(szBuffer, "");
	}
	message.lResult = strlen(szBuffer);
}

void CMain::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void CMain::FreeScripts(CScript* pList)
{
	CScript* pTemp = pList;
	CScript* pDel;
	while(pTemp)
	{
		pDel = pTemp;
		pTemp = pTemp->pNext;
		delete pDel;
	}
	pList = NULL;
}

void CMain::LoadScriptFile(char* szFile)
{
	FILE* pFile;
	char szBuffer[4096];
	int bInScript = FALSE;
	int nBlock = 0;
	CScript* pCurrent = NULL;

	pFile = fopen(szFile, "r");
	if(!pFile)
	{
		if(bDebug) MessageBox(hWnd, "Could not open file.", szVersion, MB_OK | MB_SETFOREGROUND);
		return;
	}

	while(!feof(pFile))
	{
		if(fgets(szBuffer, 256, pFile) == NULL) break;

		StrTrim(szBuffer, " \t");
		if(szBuffer[strlen(szBuffer)-1] = '\n') szBuffer[strlen(szBuffer)-1] = '\0';
		if(strlen(szBuffer) == 0) continue;
		if(strncmp(szBuffer, "//", 2) == 0) continue;

		if(!bInScript)
		{
			if(strncmp(szBuffer, "bang", 4) == 0)
			{
				CScript* pNew = new CScript();
				pNew->pNext = pBangs;
				pBangs = pNew;
				bInScript = TRUE;
				nBlock = 0;
				strcpy(pNew->szName, szBuffer + 5);
				pCurrent = pNew;
				
				char szBang[4096];
				strcpy(szBang, "!");
				strcat(szBang, szBuffer + 5);
				AddBangCommandEx(szBang, BangScript);
			}
			else if(strncmp(szBuffer, "func", 4) == 0)
			{
				CScript* pNew = new CScript();
				pNew->pNext = pFuncs;
				pFuncs = pNew;
				bInScript = TRUE;
				nBlock = 0;
				strcpy(pNew->szName, szBuffer + 5);
				pCurrent = pNew;
			}
		}
		else
		{
			if(pCurrent)
			{
				if(szBuffer[0] == '}')
				{
					nBlock--;
					if(nBlock == 0)
						bInScript = FALSE;
					else
						pCurrent->AddLine(szBuffer);
				}
				else if(szBuffer[0] == '{')
				{
					if(nBlock) pCurrent->AddLine(szBuffer);
					nBlock++;
				}
				else
					pCurrent->AddLine(szBuffer);
			}
		}
	}

	fclose(pFile);
}

void CMain::ExecScript(CScript* pScript)
{
	CLine* pLine = pScript->pLines;
	while(pLine)
	{
		CScript* pScript = pFuncs;
		while(pScript)
		{
			if(strcmpi(pScript->szName, pLine->szLine) == 0)
				break;
			pScript = pScript->pNext;
		}
		if(pScript)
			ExecScript(pScript);
		else
			LSExecute(NULL, pLine->szLine, SW_NORMAL);
		pLine = pLine->pNext;
	}
}

void CMain::bangScript(LPCSTR szCommand, LPCSTR szArgs)
{
	CScript* pScript = pBangs;
	while(pScript)
	{
		if(strcmpi(pScript->szName, szCommand + 1) == 0)
		{
			ExecScript(pScript);
			break;
		}
		pScript = pScript->pNext;
	}
}

void CMain::bangStatus()
{
	char szMsg[4096];

	strcpy(szMsg, "Scripts:\n");
	CScript* pScript = pFuncs;
	while(pScript)
	{
		strcat(szMsg, pScript->szName);
		strcat(szMsg, "\n");
		pScript = pScript->pNext;
	}

	strcat(szMsg, "\nBangs:\n");
	pScript = pBangs;
	while(pScript)
	{
		strcat(szMsg, pScript->szName);
		strcat(szMsg, "\n");
		pScript = pScript->pNext;
	}

	MessageBox(NULL, szMsg, szVersion, MB_OK | MB_SETFOREGROUND);
}
