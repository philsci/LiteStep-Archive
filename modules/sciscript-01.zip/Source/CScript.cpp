#include "CScript.h"

CScript::CScript()
{
	pLines = NULL;
	pNext = NULL;
}

CScript::~CScript()
{
	CLine* pTemp = pLines;
	CLine* pDel;
	while(pTemp)
	{
		pDel = pTemp;
		pTemp = pTemp->pNext;
		delete pDel;
	}
}

void CScript::AddLine(char* szLine)
{
	CLine* pTemp = new CLine();
	strcpy(pTemp->szLine, szLine);
	pTemp->pNext = NULL;
	if(pLines)
	{
		CLine* pList = pLines;
		while(pList->pNext)
			pList = pList->pNext;
		pList->pNext = pTemp;
	}
	else
		pLines = pTemp;
}
