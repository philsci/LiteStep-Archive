*Wordwrap makes reading easier . . .

A few bang commands written from ideas at MindStorm.

!SetWallPaper <bitmap>
!ChangeScreenRes <bitsperpixel> <width> <height>
!ToggleScreenSaver

Ps. these are ideas 11, 48 and 54.
Source is included.

Remco de Jong - [rDJ]


Updated 6-4-99 by WhiteShadow

New to step.rc:
WallpaperList <plain text file>

New bang command:
!SetWallPaper Random

This will set a random wallpaper from a list file.  An easy way to make a file list it to put all your wallpapers in one directory and typing "dir *.bmp /b/s > list.txt" at the command prompt.

