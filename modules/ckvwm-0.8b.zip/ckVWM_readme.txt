//============================================================
//ckVWM.dll v0.8b - a vwm based on sysvwm
//------------------------------------------------------------
//Filename	: 	ckVWM.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This module adds some new function to the sysvwm
//------------------------------------------------------------
/****************** v0.8b		9/24/2000************/
//
//
//About:
//	First, thanks for all the people who contributed to sysvwm.  This module is almost
//	90% from sysvwm, so I dont know if i should name it sysvwm with a newer version
//	or not.  Since this is not in the core module, so......If you have any suggestion on the
//	naming or anything, please e-mail @ chaokuo@iname.com
//	
//	Anyway, i included the sysvwm's readme's with this package just in case you need them.
//	The configs and bangs are same with sysvwm with the following additions.
//
//Changes:
//	Added Step.rc Config:
//		VWMHideTaskOnSwitch
//			-This will cause the sysvwm hide the tasks from task bar if
//			 its window is not on the current screen.  It will not hide the minimized window
//			from task bar, and it'll carry it to differnt desktop.  So when restored, the window
//			will be in the current desktop, and not in the old
//			
//		VWMWrapScreen
//			-This will alow your desktops to be kind of circular.  Let's say the you are in the 
//			first desktop. When you use !VWMLeft, this config will allow you to move to the last
//			desktop.
//		VWMReturnToFirstScreen
//			-For those whose sysvwm will behave weird when not recycling in the first desktop,
//			this config will force the sysvwm to go back to the first desktop.
//			(I don't know about most of the people, but i guess you won't experience this kind of problem)
//
//	Added Bang Commands:
//		!VWMTOGGLEHIDETASKONSWITCH
//			-This is for toggling the VWMHideTaskOnSwitch config
//		!VWMTOGGLEWRAPSCREEN
//			-This is for toggling the VWMWrapScreen config
//	
//	*Note: 
//		-In this version of !VWMDesk #, the # will start from 1 and not 0
//		-This is just a beta version.  I welcome any suggestions, and if you found a bug
//		please please report to me @ chaokuo@iname.com  Thanks.
//------------------------------------------------------------
//Example Step.rc config:
//	LoadModule "C:\Litestep\ckVWM.dll"
//	VWMHideTaskOnSwitch
//	VWMReturnToFirstScreen
//	VWMWrapScreen
//	
