/*********************************************************************/
/*                                                                   */
/* LiteSTEP Wharf Module SDK 1.3                                     */
/*                                                                   */
/* Copyright (c)1998 Francis Gastellu aka Lone Runner/Aegis          */
/*                                                                   */
/*********************************************************************/
/*                                                                   */
/* This is a sample Wharf module. It is not supposed to provide any  */
/* functionality but to show how to implement your own Wharf module  */
/*                                                                   */
/* ----------------------------------------------------------------- */

#include <windows.h>
#include <stdio.h>
#include <initguid.h>
#include <spchwrap.h>
#include <dsound.h>
#include "WharfSpeak.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LiteSpeak"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void SpeakClipboard();
int LoadSettings();
void Say(const char *format, ...);
int InitializeSpeech();
void DestroySpeech(void);
char* DictionaryString(const char*);

HWND hMainWnd;                    // main window handle
char ini[_MAX_PATH];
char dictini[MAX_PATH];

// Voice Globals
char Greeting[256] = "";
char Ident[256] = "";
CVoiceText *SpeakObject;
HWND NextClipView;
BOOL QUIET=FALSE;
int CHANGED=1;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	sprintf(ini, "%s\\modules.ini", szPath);
	sprintf(dictini, "%s\\dictini.ini", szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name

	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL,"Error registering window class",szAppName, MB_OK);
		return 1;
	}

    hMainWnd = CreateWindowEx(
        0,                                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_POPUP,                                   // window style
        0, 0,										// position 
        0, 0,										// width & height of window
        0,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	LoadSettings();

    if (!InitializeSpeech()) { MessageBox(NULL, "Error Initializng Speech", szAppName, MB_OK); return 0; }

	Say("%s", Greeting);

	OpenClipboard(hMainWnd);
	EmptyClipboard();
	CloseClipboard();
	NextClipView = SetClipboardViewer(hMainWnd);

	SetTimer(hMainWnd, 1, 100, NULL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitModule(HINSTANCE dllInst)
{
	DestroySpeech();

	ChangeClipboardChain(hMainWnd, NextClipView);
    DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
		case WM_DRAWCLIPBOARD:		
			{
				CHANGED=1;
				SendMessage(NextClipView,WM_DRAWCLIPBOARD,NULL,NULL);
			}
			return 0;
		case WM_CHANGECBCHAIN:
			if (NextClipView != &wParam)
			{
				SendMessage(NextClipView,WM_CHANGECBCHAIN,NULL,NULL);
			}
			else
			{
				NextClipView = &lParam;
			}
			return 0;
		case WM_TIMER:
			{
				if (CHANGED)
				{
					CHANGED=0;
					SpeakClipboard();
				}
				return 0;
			}
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int LoadSettings()
{
	GetPrivateProfileString("LiteSpeak","Identifier","EMPTY", Ident, 256, ini);
	GetPrivateProfileString("LiteSpeak","Greeting","My God, it's full of stars",Greeting,256,ini);
	
	if (!strcmp(Ident, "EMPTY"))
	{
		strcpy(Ident, "LiteSpeak");
		WritePrivateProfileString("LiteSpeak", "Identifier", Ident, ini);
		WritePrivateProfileString("LiteSpeak", "Greeting", Greeting, ini);
	}

	return 0;
}

void SpeakClipboard()
{
	HANDLE CBData = NULL;
	OpenClipboard(hMainWnd);
	CBData = GetClipboardData(CF_TEXT);
	CloseClipboard();
	
	if (CBData)
	{
		if (!strncmp((CHAR*)CBData, Ident, strlen(Ident)))
		{
			if (!strncmp((CHAR*)CBData+strlen(Ident)+1, "Clear", 5))
			{
				SpeakObject->StopSpeaking();
			}
			else if (!strncmp((CHAR*)CBData+strlen(Ident)+1, "Quiet", 5))
			{
				QUIET=TRUE;
			}
			else if (!strncmp((CHAR*)CBData+strlen(Ident)+1, "Talk", 5))
			{
				QUIET=FALSE;
			}
			else
			{
				if (!QUIET)
				{
					char* temp = DictionaryString((CHAR*)CBData+strlen(Ident));
					Say("%s", temp);
				}
			}
		}
	}
}

int InitializeSpeech(void)
{
	CoInitialize(NULL);
	SpeakObject = new CVoiceText;
	if (!SpeakObject) return 0;
	if (SpeakObject->Init(L"LiteSpeak")) return 0;
	return 1;
}

void Say(const char *format, ...)
{
	va_list args;
	char buf[8192];
	WCHAR wbuf[8192] = L"";

	va_start(args, format);
	_vsnprintf(buf, sizeof(buf), format, args);
	va_end(args);
	MultiByteToWideChar(CP_ACP, 0, buf, -1, wbuf, lstrlen(buf));
	SpeakObject->Speak(wbuf, VTXTST_READING);
}

void DestroySpeech(void)
{
	SpeakObject->StopSpeaking();
	if (SpeakObject) delete SpeakObject;
	CoUninitialize();
}

char* DictionaryString(const char* input)
{
	char *temp;
	char* str = (char*)input;
	char* retstr = (char*)malloc(strlen(input)*2);
	int first=1;
	
	while (1)
	{
		if (first) { temp = strtok(str, " "); first=0; }
		else temp = strtok(NULL, " ");

		if (temp == NULL) break;
		else
		{
			char *blah = (char*)malloc(strlen(temp));
			GetPrivateProfileString("Dictionary", temp, temp, blah, 256, dictini);
			strcat(retstr, blah);
			strcat(retstr, " ");
			free(blah);
		}
		temp = NULL;
	}

	free(str);
	free(retstr);
	return retstr;
}