#include <windows.h>
#include <stdio.h>
#include <wininet.h>
#include <commctrl.h>
#include "lsapi.h"
#include "LSTVG.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LSTVG"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void GetShows();
void LoadSetup();

// Litestep Stuff
HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HINSTANCE Instance;
HMENU Popup;

// Handles
HANDLE thread=NULL;
HBITMAP bgbmp=NULL;
HBRUSH CHANNEL_BRUSH=NULL, SHOW_BRUSH=NULL, HEADER_BRUSH=NULL, BORDER_BRUSH=NULL;
HFONT CHANNEL_FONT=NULL, SHOW_FONT=NULL, HEADER_FONT=NULL;

// ColorRefs
COLORREF CHANNEL_FONT_COLOR, SHOW_FONT_COLOR, HEADER_FONT_COLOR;

// Dwords
DWORD MB = MB_OK | MB_SETFOREGROUND;
DWORD threadID=0;

// Character Strings
char ini[MAX_PATH] = "";
char thm[MAX_PATH] = "h:\\litestep\\lstvg.thm";
char BASE_TIME[256] = "";

// Ints
int XPos=50, YPos=50;
int WndWidth=600; WndHeight=100;
int HIGHEST_CHANNEL=0;
int TOTAL_COLUMNS=4;
int TOTAL_ROWS=4;
int INDENT=3;

// BOOLs
BOOL BORDER=TRUE;
BOOL CHECKING=FALSE;
BOOL CHANNEL_TRANS=FALSE, SHOW_TRANS=FALSE, HEADER_TRANS=FALSE;

////////////////////////////////////////////////////////////////////////


// It has begun
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	DWORD ex = WS_EX_TOOLWINDOW;
	parent = ParentWnd; // Save parent window
	Instance = dllInst;
	sprintf(ini, "%s\\modules.ini", szPath);

	{    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }
	
	LoadSetup();

	hMainWnd = CreateWindowEx(
        ex,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_POPUP,                                   // window style
        XPos, YPos,									// position 
        WndWidth, WndHeight,                        // width & height of window
        GetDesktopWindow(),                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	//(TIMER>0)? SetTimer(hMainWnd, 0, TIMER, NULL) : 0;

	return 0;
}

void quitModule(HINSTANCE dllInst)
{
	quitWharfModule(dllInst);
}

void quitWharfModule(HINSTANCE dllInst)
{
	TerminateThread(thread, 0);
	KillTimer(hMainWnd, 0);
	DestroyMenu(Popup);
	DeleteObject(bgbmp);
	DeleteObject(CHANNEL_BRUSH);
	DeleteObject(SHOW_BRUSH);
	DeleteObject(HEADER_BRUSH);
	DeleteObject(BORDER_BRUSH);
	DeleteObject(CHANNEL_FONT);
	DeleteObject(SHOW_FONT);
	DeleteObject(HEADER_FONT);
	DestroyWindow(hMainWnd);                // delete our window
	UnregisterClass(szAppName, dllInst);    // unregister window class
}

void LoadSetup()
{
	int r,g,b;
	char temp[256] = "";

	GetPrivateProfileString(szAppName, "ThemeFile", "", thm, MAX_PATH, ini);
	XPos = GetPrivateProfileInt(szAppName, "DesktopX", 0, ini);
	YPos = GetPrivateProfileInt(szAppName, "DesktopY", 0, ini);

	WndWidth = GetPrivateProfileInt("Main", "WindowWidth", 600, thm);
	WndHeight = GetPrivateProfileInt("Main", "WindowHeight", 100, thm);

	INDENT = GetPrivateProfileInt("Main", "Indent", 3, thm);
	TOTAL_COLUMNS = GetPrivateProfileInt("Main", "Columns", 4, thm);
	TOTAL_ROWS = GetPrivateProfileInt("Main", "Rows", 4, thm);

	r = GetPrivateProfileInt("Channels", "BackR", 0, thm);
	g = GetPrivateProfileInt("Channels", "BackG", 0, thm);
	b = GetPrivateProfileInt("Channels", "BackB", 0, thm);
	if (r == -1 && g == -1 && b == -1) CHANNEL_TRANS=TRUE;
	else CHANNEL_BRUSH = CreateSolidBrush(RGB(r,g,b));

	r = GetPrivateProfileInt("Channels", "FontR", 0, thm);
	g = GetPrivateProfileInt("Channels", "FontG", 0, thm);
	b = GetPrivateProfileInt("Channels", "FontB", 0, thm);
	CHANNEL_FONT_COLOR = RGB(r,g,b);
	GetPrivateProfileString("Channels", "FontName", "Arial", temp, 256, thm);
	CHANNEL_FONT = CreateFont(WndHeight/TOTAL_ROWS, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);

	r = GetPrivateProfileInt("Shows", "BackR", 0, thm);
	g = GetPrivateProfileInt("Shows", "BackG", 0, thm);
	b = GetPrivateProfileInt("Shows", "BackB", 0, thm);
	if (r == -1 && g == -1 && b == -1) SHOW_TRANS=TRUE;
	else SHOW_BRUSH = CreateSolidBrush(RGB(r,g,b));

	r = GetPrivateProfileInt("Shows", "FontR", 0, thm);
	g = GetPrivateProfileInt("Shows", "FontG", 0, thm);
	b = GetPrivateProfileInt("Shows", "FontB", 0, thm);
	SHOW_FONT_COLOR = RGB(r,g,b);
	GetPrivateProfileString("Shows", "FontName", "Arial", temp, 256, thm);
	CHANNEL_FONT = CreateFont(WndHeight/TOTAL_ROWS, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);

	r = GetPrivateProfileInt("Header", "BackR", 0, thm);
	g = GetPrivateProfileInt("Header", "BackG", 0, thm);
	b = GetPrivateProfileInt("Header", "BackB", 0, thm);
	if (r == -1 && g == -1 && b == -1) HEADER_TRANS=TRUE;
	else HEADER_BRUSH = CreateSolidBrush(RGB(r,g,b));

	r = GetPrivateProfileInt("Header", "FontR", 0, thm);
	g = GetPrivateProfileInt("Header", "FontG", 0, thm);
	b = GetPrivateProfileInt("Header", "FontB", 0, thm);
	HEADER_FONT_COLOR = RGB(r,g,b);
	GetPrivateProfileString("Header", "FontName", "Arial", temp, 256, thm);
	HEADER_FONT = CreateFont(WndHeight/TOTAL_ROWS, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);

	r = GetPrivateProfileInt("Main", "BorderColorR", 0, thm);
	g = GetPrivateProfileInt("Main", "BorderColorG", 0, thm);
	b = GetPrivateProfileInt("Main", "BorderColorB", 0, thm);
	if (r == -1 && g == -1 && b == -1) BORDER=FALSE;
	else BORDER_BRUSH = CreateSolidBrush(RGB(r,g,b));

	GetPrivateProfileString("Main", "BaseTime", "", BASE_TIME, 256, thm);

	GetPrivateProfileString("Main", "BGBMP", "", temp, 256, thm);
	if (strlen(temp))
	{
		bgbmp = LoadImage(Instance, temp, IMAGE_BITMAP, WndWidth, WndHeight, LR_LOADFROMFILE);
	}

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, M_UPDATE, "&Update");
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;

        case WM_PAINT:
		{
			if (!bgbmp)
			{
				HDC hdc = GetDC(hwnd);
				HDC buf = CreateCompatibleDC(NULL);
				bgbmp = CreateCompatibleBitmap(hdc, WndWidth, WndHeight);
				SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, WndWidth, WndHeight, hdc, 0, 0, SRCCOPY);
				DeleteObject(buf);
				ReleaseDC(hwnd, hdc);
				InvalidateRect(hwnd, NULL, TRUE);
			}
			else
			{
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hwnd, &ps);
				HDC buf = CreateCompatibleDC(NULL);
				HDC back = CreateCompatibleDC(NULL);
				HBITMAP bufbmp = CreateCompatibleBitmap(hdc, WndWidth, WndHeight);
				char temp[256] = "";
				char SECTION[256] = "";
				RECT r, m;
				int x=1;
				int WIDTH = (WndWidth/TOTAL_COLUMNS);
				int HEIGHT = (WndHeight/TOTAL_ROWS);
				
				SelectObject(buf, bufbmp);

				SelectObject(back, bgbmp);
				BitBlt(buf, 0, 0, WndWidth, WndHeight, back, 0, 0, SRCCOPY);
				
				GetClientRect(hwnd, &r);
				SetRect(&m, r.left, 0, r.right, HEIGHT);
				(!HEADER_TRANS)? FillRect(buf, &m, HEADER_BRUSH) : 0;

				SetBkMode(buf, TRANSPARENT);
				SetTextColor(buf, HEADER_FONT_COLOR);
				SelectObject(buf, HEADER_FONT);
				
				if (CHECKING)
				{
					DrawText(buf, "Updating Listings from TVGuide.com...", 37, &r, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
				}
				else
				{
					SetRect(&m, INDENT, INDENT, WIDTH-INDENT, HEIGHT-INDENT);
					DrawText(buf, "Channel", strlen("Channel"), &m, DT_CENTER | DT_SINGLELINE | DT_VCENTER);

					for (x=1; x < TOTAL_COLUMNS; x++)
					{
						int left = WIDTH*x;
						int H=0, M=0;
						char TIME[30] = "";
						char temptime[256] = "";
						char* p;

						strcpy(temptime, BASE_TIME);
						p = strtok(temptime, ":");
						if (p) H = atoi(p);
						p = strtok(NULL, " ");
						if (p) M = atoi(p);
						
						if (x>1)
						{
							M += 30*(x-1);
							if (M>=60) { H+=M/60; M%=60; }
							if (H>12) H-=12;
						}
						
						if (!M) sprintf(TIME, "%d:0%d", H, M);
						else sprintf(TIME, "%d:%d", H, M);

						SetRect(&m, left+INDENT, INDENT, left+WIDTH-INDENT, HEIGHT-INDENT); 
						DrawText(buf, TIME, strlen(TIME), &m, DT_CENTER | DT_SINGLELINE | DT_VCENTER);
					}
					
					SetRect(&m, 0, HEIGHT, WIDTH, r.bottom);
					(!CHANNEL_TRANS)? FillRect(buf, &m, CHANNEL_BRUSH) : 0;
					SetRect(&m, WIDTH, HEIGHT, r.right, r.bottom);
					(!SHOW_TRANS)? FillRect(buf, &m, SHOW_BRUSH) : 0;
						
					sprintf(temp, "%d", x=1);
					while (GetPrivateProfileString("Visible", temp, "", SECTION, 256, thm))
					{	
						char buffer[256] = "";
						char current[15] = "";
						int y=0;
						int top = HEIGHT*x;
						char* n=SECTION+7;
						
						GetPrivateProfileString(SECTION, "Name", "", temp, 256, thm);
						sprintf(buffer, "%s %s", n, temp);

						SelectObject(buf, CHANNEL_FONT);
						SetTextColor(buf, CHANNEL_FONT_COLOR);
						SetRect(&m, 0, top, WIDTH, top+HEIGHT);
						(BORDER)? FrameRect(buf, &m, BORDER_BRUSH) : 0;
						SetRect(&m, INDENT, top+INDENT, WIDTH-INDENT, top+HEIGHT-INDENT);
						DrawText(buf, buffer, strlen(buffer), &m, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

						SelectObject(buf, SHOW_FONT);
						SetTextColor(buf, SHOW_FONT_COLOR);
						for (y=1; y < TOTAL_COLUMNS; y++)
						{
							int left = WIDTH*y;
							sprintf(current, "Current%d", y-1);
							GetPrivateProfileString(SECTION, current, "NA", temp, 256, thm);
							
							SetRect(&m, left, top, left+WIDTH, top+HEIGHT);
							(BORDER)? FrameRect(buf, &m, BORDER_BRUSH) : 0;
							SetRect(&m, left+INDENT, top+INDENT, left+WIDTH-INDENT, top+HEIGHT-INDENT);
							DrawText(buf, temp, strlen(temp), &m, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
						}

						sprintf(temp, "%d", ++x);
					}
				}

				BitBlt(hdc, 0, 0, WndWidth, WndHeight, buf, 0, 0, SRCCOPY);

				EndPaint(hwnd, &ps);
				DeleteDC(buf);
				DeleteDC(back);
				DeleteObject(bufbmp);
			}
		}
		return 0;

		case WM_TIMER:
		{
			switch ((int)wParam)
			{
				case 0: break;
			}
		}
		return 0;

        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        
		case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;

		case WM_LBUTTONDBLCLK:
		{
			int X = LOWORD(lParam);
			int Y = HIWORD(lParam);
			int W = WndWidth/TOTAL_COLUMNS;
			int H = WndHeight/TOTAL_ROWS;
			char SECTION[50] = "";
			char ON[256] = "";
			char temp[50] = "";

			sprintf(temp, "%d", Y/H);
			GetPrivateProfileString("Visible", temp, "", SECTION, 50, thm);
			sprintf(temp, "Current%d", (X/W)-1);
			GetPrivateProfileString(SECTION, temp, "", ON, 256, thm);
			
			MessageBox(hMainWnd, ON, szAppName, MB);
		}
		return 0;

		case WM_RBUTTONUP:
        {
			RECT r;
            GetWindowRect(hwnd, &r);
            PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
		}
        return 0;

        case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
		}
		return 0;

		case WM_MOUSEMOVE:
		{
			SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
		}
		return 0;

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case M_UPDATE:
				{
					thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)GetShows, (LPVOID)NULL, 0, &threadID);
				}
				break;
			}
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

void GetShows()
{
	HINTERNET hint = NULL;
	HINTERNET http = NULL;
	
	CHECKING = TRUE;
	InvalidateRect(hMainWnd, NULL, TRUE);

	hint = InternetOpen(szAppName, INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
	if (hint)
	{
		char FULL_URL[256] = "";
		char FIND_URL[256] = "";
		double TVGUIDE_TIME = 0.0000000000;
		int ID = GetPrivateProfileInt(szAppName, "ID", 0, ini);
		int count=0;

		sprintf(FIND_URL, "http://www.tvguide.com/Listings/TimeBar1.asp?I=%d&Style=1&GB=2", ID);

		http = InternetOpenUrl(hint, FIND_URL, NULL, 0, INTERNET_FLAG_TRANSFER_ASCII | INTERNET_FLAG_RELOAD | INTERNET_FLAG_DONT_CACHE, 0);
		if (http)
		{
			DWORD dwRead;
			TCHAR szTemp[30000];
			char temp[256] = "";

			while (InternetReadFile(http, (LPVOID)szTemp, 30000, &dwRead))
			{
				char* pointer = strtok(szTemp, "\n\r");
				BOOL ONCE=FALSE, STOP=FALSE;

				if (!dwRead) break;

				while ((pointer = strtok(NULL, "\n\r")))
				{
					if (strstr(pointer, ";ST="))
					{
						char *p2 = strstr(pointer, ";ST=") + 4;
						char *p3 = strstr(p2, "&");
						strncpy(temp, p2, p3-p2);
						TVGUIDE_TIME = atof(temp);
					}
					else if (strstr(pointer, "<OPTION VALUE=\"\" SELECTED>"))
					{
						if (!ONCE) ONCE=TRUE; // Skip the selected date
						else
						{
							char* p2 = strstr(pointer, ">")+1;
							strcpy(BASE_TIME, p2);
							WritePrivateProfileString("Main", "BaseTime", BASE_TIME, thm);
							STOP=TRUE;
							break;
						}
					}
				}
				if (STOP) break;
			}
		}

		for (count=0; count < TOTAL_COLUMNS; count++)
		{
			if (count) TVGUIDE_TIME += (float)1/48;
			sprintf(FULL_URL, "http://www.tvguide.com/listings/PrintView.asp?I=%d&Style=1&Dyn=&GB=1&ST=%f&P=98&MV=4&FC=0&FG=&FS=&Na=0", ID, TVGUIDE_TIME);
			http = NULL;
			http = InternetOpenUrl(hint, FULL_URL, NULL, 0, INTERNET_FLAG_TRANSFER_ASCII | INTERNET_FLAG_RELOAD | INTERNET_FLAG_DONT_CACHE, 0);

			if (http)
			{
				DWORD dwRead;
				TCHAR szTemp[30000];
				char temp[256] = "";

				while (InternetReadFile(http, (LPVOID)szTemp, 30000, &dwRead))
				{
					char* pointer = strtok(szTemp, "\n");

					if (!dwRead) break;

					while ((pointer = strtok(NULL, "\n")))
					{
						if (strstr(pointer, "<TH WIDTH=\"8%\" BGCOLOR=\"#FFFFFF\" bordercolor=\"Black\">"))
						{
							char *p2;
							char temp[256] = "";
							char chan[256] = "";
							char SECTION[256] = "";
							int channel=0;

							pointer = strtok(NULL, "\n");
							p2 = strstr(pointer, "&nbsp;");
							strncpy(temp, pointer, p2-pointer);
							
							if (strlen(temp)) HIGHEST_CHANNEL = channel = atoi(temp);
							sprintf(SECTION, "Channel%d", channel);

							pointer += strlen(temp) + strlen("&nbsp;");

							strcpy(temp, pointer);
							temp[strlen(temp)-1] = '\0';
							WritePrivateProfileString(SECTION, "Name", temp, thm);

							while ((pointer = strtok(NULL, "\n\0")))
							{
								if (strstr(pointer, "</TR>")) break;

								while ((pointer = strtok(NULL, "\n\r")))
								{
									int x, y=0;
									BOOL OPEN=TRUE;
									BOOL AMP=FALSE;
									memset(&temp, '\0', sizeof(temp));

									if (strstr(pointer, "</TD>")) break;
									
									for (x=0; pointer[x] != '\0' && pointer[x] != '\r' && pointer[x] != '\n'; x++)
									{
										if (pointer[x] == '<') OPEN=TRUE;
										else if (pointer[x] == '>') { OPEN=FALSE; x++; }
										else if (pointer[x] == '&' && pointer[x+1] == 'g' && pointer[x+2] == 't' && pointer[x+3] == ';') { x += 3; continue; }

										if (!OPEN)
										{
											temp[y] = pointer[x];
											y++;
										}
									}
									
									sprintf(chan, "Current%d", count);
									WritePrivateProfileString(SECTION, chan, temp, thm);
								}
							}
						}
					}

					memset(&szTemp, '\0', sizeof(szTemp));
				}
			}
		}
	}
	
	CHECKING=FALSE;

	InternetCloseHandle(hint);
	InvalidateRect(hMainWnd, NULL, TRUE);
}
