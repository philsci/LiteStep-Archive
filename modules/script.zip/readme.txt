This is a version of script.exe by schmoo that I have modified to
work with Killarny's script.dll(included) to run LiteStep bang
commands. The lsapi included with Killarny's lscript package is also
here, if needed.

Here is the added command:

	lsbang

	description:
	
		lsbang is used to run a LiteStep bang command.  DO NOT use the starting !, the engine
		automatically prepends it. Since script.exe uses Killarny's script.dll for bang calls,
		you can specify multiple bangs on one line. For the subsequent bangs, you must prepend
		the ! along with an escape character \ . See the examples.
		
	syntax:

		lsbang,bang[|\!bang2[|\n!bang3|...]]

	example:

		lsbang,recycle
		lsbang,toggleshortcutgroup 1|\!toggleshortcutgroup 2|\!toggleshortcutgroup 3|\!toggleshortcutgroup 4|\!vwmup
		
		
How to use:

LoadModule script.dll

Edit script.ini to point to your modules.ini file.



I have included a smaple script I use to edit my step.rc, copy it to the theme dir
and then recycle LS.

This software is provided as is, with no claims or warantees.
If it breaks your system, it's YOUR fault.

Enjoy it!

