#ifndef __VWM_H
#define __VWM_H

/*
    ckVWM, a Virtual Windows Manager for LiteStep
    Copyright (C) 2000 Chao-Kuo Lin

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../lsapi/lsapi.h"

typedef struct {
	HWND hwnd;
	HICON hicon;
	RECT r;
	// 1 = valid, 0 = invalid, 3 = valid in hide list, but will be remove from hide list soon
	// 4 = child tool window
	char valid; 
	} winDataType;

typedef struct {
	HWND hwnd;
	RECT r;
}	winToolType;

typedef struct {
	HWND hwnd;
	char screen;
	} winFixType;

typedef struct {
	char match[80];
} ConfigInfoT;


typedef struct
{
	char match[80];
	int desktop;
} StartWindowT;

//proc for callback's callback purpose.  Return False to stop enumerating
typedef BOOL(*lpEnumProc)(HWND);

typedef struct
{
	lpEnumProc proc;
	LPCSTR str;
} EnumProcDataT, *lpEnumProcDataT;

#define WIN_KEY 0
#define ALT_KEY 1
#define CTRL_KEY 2

//Chao-Kuo Lin
// hidden windows should always be more or equal to 
// the shown window, so WIN_HIDE_COUNT should be higher
#define WIN_RECT_COUNT 300
#define WIN_HIDE_COUNT 300
#define WIN_FIX_COUNT 300
#define WIN_TOOL_COUNT 300
#define WIN_SHOWN_LIST 0xFF

#define WIN_SHOW_METHOD SW_SHOWNA

#define CKVWMCLASSNAME "ckVWM"

#ifndef true
#define true 1
#endif
//end

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int quitWharfModule(HINSTANCE dll);

// desk specifies which desk the caller will enum the windows
// return TRUE if succeeded, FALSE if failed, probalby cause wrong desktop number
// the number starts with 1, and 0 will allow you to enumerate tasks on all
// desktops.  This is done by calling the pEnumFunc first then ckEnumFunc

// the first proc is for enumerating through the EnumWindows function, the second
// one is for the already hidden windows
__declspec( dllexport ) BOOL EnumTasks(int desk, WNDENUMPROC pEnumFunc, WNDENUMPROC ckEnumFunc, LPARAM lParam);

#ifdef __cplusplus
}
#endif

#endif
