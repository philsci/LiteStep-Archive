//Chao-Kuo Lin
//Define the following if want debug output
//#define VWM_DEBUG_OUTPUT
//TODO:
//		>Change all window title or class matching to use the match function
//		ex: *mirc*, for more info, refer to the match.c file
//		(done, tested)
//
//		>Add configs to disable the Autoswitchvertical and stuff
//			-VWMDisableVerticalAutoSwitch
//			-VWMDisableHorizontalAutoSwitch
//		(done, tested)
//
//		>!VWMRESTOREALLWINDOWS <keyword>, cascade, tilehorizontal, tilevertical, overlap
//		!VWMRESTOREALLWINDOWS "window name" "method"
//		(done overlap, cascade)(tested)
//
//		>fix MoveApp bang so that it will follow the new Wrapscreen feature
//		(done, tested)
//
//		>*VWMStartWindowsOnDesktop "Window Name" "Desktop Nunber"
//			use timer to check?
//				-add config *VWMStartWindowsOnDesktop "Window Name" "Desktop Number"
//		(done, tested, so far only works in litestep, and not PureLS)
//
//
//		>hmm..so like switch a window to another desktop? but it will retain the same relative coordinate to that desktop?
//			!VWMMoveApp
//			I've made bangs for !VWMMoveAppN where N is desktop to move... I've binded those to hotkeys.  
//			I want to trigger them with shortcuts or the like, but clicking them loses focus on windows... 
//			so is there a way to do !VWMMoveApp if there's lost focus.. I'm guessing there has to be a 
//			refocus by remembering the last active window or soemthing..
//		(done, tested)
//
//
//		>Fix the bug that when clicking on task, the wrong desktop will be shown
//		(done)
//
//		><Chaku> so dragging windows will just move to another desktop instead of moving the window?
//		<[steve]> Chaku: yep
//		<TNL> Chaku: ya.. kinda like having them snap into the place
//		<Chaku> i see...
//			-config VWMSnapWindowOnDrag
//		(done)
//
//		>make ckVWM moveable through bangs, e.g. "!VWMMove x y"
//		(done, tested)
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//		><Chaku> steve: like !tasks for all differnt desktops?
//		<TNL> ya.. like *Popup "Workspace 1" !PopupTasks1
//		<TNL> but you can also see !PopupTasks2,...,!PopupTasksN
//		(done, but going to add the popuptasks1.... support for those even without hide on switch)
//
//		><Milk-Boy> Chaku: how about adding a vwm "lockup" feature so that when a 
//		bang is sent or something, the vwm locks up untill a password is entered 
//		in a little box that replaces the vwm or something like that?
//
//		><Chaku> steve: so like when "mouse button down" it'll change to that dekstop,
//		then when the miniwindow is drag to other desktop, vwm will change to that 
//		desktop too?
//		><[steve]> yeah
//
//		>what about having a feature in the vwm where you can double click on a windows representation to either maximise 
//		  or restore that window on that screen?
//			-VWMMouseDoubleLeft
//		(half done, got some bug to fix)
//
//
//		>will be under other window, and will activate and be above other window when activate wharf or
//		dwarf
//
//		>Add bang commands for controlling group of windows?
//
//		>The ability to make dekstops content switch...so that all the windows in the source desktop
//		will move to the destine desktop, and the windows in destine desktop will move to source desktop
//
//		>i thought of another *task thing
//		<[steve]> for the vwm
//		<[steve]> ./popup thingie
//		<[steve]> *MiscTasks - minimized tasks
//		<[steve]> !MiscTasks
//		<[steve]> or !TasksThatAreMinimized (cause i like typing long words)
//		>Add a config VWMNOMINIWINDOWS so that miniwindows won't be rendered, also should add bang to change it
//
//		>Add the ability for VWM to remember the old active windows in eeach vwm
//
////////////////////////////////////////////////////////////////////////////////////
//		Bugs:
//			>Moveapp will move the always on top shit(fixed)
//			>VWM<direction> bangs will not really work with threaded feature
//			>bottom 2 pixels will be scrambled shit(fixed)
//			>fix so that it can be load inside wharf, right now the size if dead fixed(fixed)
//			>I want to move an app to desktop #4 from whatever # I'm on. From #1, #2 ...(added)
//			There is no way to do this without scripting, is there?
//			>photoshop weirdness(fixed)

////////////////////////////////////////////////////
// new bugs
//			>WM_CLOSE and return 0; for it, because currently alt+F4 closes ckVWM. (fixed)
//			>mouse move window will show the photoshop tool windows

/*
    ckVWM, a Virtual Windows Manager for LiteStep
    Copyright (C) 2000 Chao-Kuo Lin

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#define STRICT

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <commctrl.h>
#include <tchar.h>
#include <assert.h>

#include "vwm.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/macros.h"
#define VWM_DESKNO 0x11110000;

/*
//this is for test
typedef int(*InitModuleT)(HWND, HINSTANCE ,LPCSTR);
//HINSTANCE ckHook = NULL;
*/

HWND hMainWnd=NULL;		//hwnd for vwm panel
HWND parent = NULL;		//hwnd for vwm's parent
HWND refToplevel;
HWND newW=(HWND)-1;
HWND lastActive=NULL;
HWND photoshop;
HWND eudora;
HWND tapp, desk, winswitch;
HINSTANCE inst;

HDC memDC, bgDC;
HBITMAP	memBM, oldBM, oldBG;
HBITMAP bBGBitmap, sBGBitmap, wBGBitmap, tBGBitmap;
HIMAGELIST hBGList;

RECT *deskRect = NULL;
RECT oldWinPos;
POINT lastPoint;
POINT diff;

UINT Timer=0;
UINT TimerAct=1;
UINT nOffsetX, nOffsetY;
UINT mTimer=2;
UINT mcTimer=3;
UINT autoTimer=4;

BOOL NoGather=FALSE;
BOOL NoBorder=FALSE;
BOOL NoWindows=FALSE;
BOOL backInit=FALSE;
BOOL moveCursor=FALSE;
BOOL background=FALSE;
BOOL snapshot=FALSE;
BOOL bevel=FALSE;
BOOL rolled=FALSE;
BOOL onTop=FALSE;
BOOL currentOnTop = FALSE;
BOOL noShow=FALSE;
BOOL noMove=FALSE;
BOOL titlebars=FALSE;
BOOL NeverSwitch=FALSE;
BOOL FocusCenter=FALSE;
BOOL VWMautohide=FALSE;
BOOL autoHidden=FALSE;
BOOL autoswitch=FALSE;
BOOL useIcons=FALSE;
BOOL useInitialDesk=FALSE;

//Wharf related variables
BOOL dockedOnWharf=FALSE;
RECT wharfRect;
POINT wharfSize;

//Chao-Kuo Lin
//should i use MAX_PATH_LENGTH defined by lsapi.h?
static const char szAppName[] = CKVWMCLASSNAME;
static char szLitestepPath [MAX_PATH+1];
static char szImagePath [MAX_PATH+1];
//end

int backX, backY, selX, selY, winX, winY, titleX, titleY;
int backColor;
int winColor;
int foreColor;
int selBackColor;
int borderColor;
int snapWidth = 3;
int autoHideDistance = 3;
int autoSwitchDistance = 1;
int autoHideFix = 1;
int inchk=0;
int mpos=0;
int mTimeout=50;
int searched=0;
int wndSizeX, wndSizeY;
int ratioX, ratioY;
int currentScreen=0;
int ScreenWidth = 800;
int ScreenHeight = 600;
int TitlebarHeight;
int titleHeightMod = 16;
int getDesktop(HWND h);
//int First = 1;
int ScreensX = 2;
int ScreensY = 2;
int mainX = 0;
int mainY = 0;
//chao-kuo lin 
//used to memorize the position of mainX and mainY
int oldMainX = 0;
int oldMainY = 0;
//end
int mainWidth = 64;
int mainHeight = 64;
int MaxScreens = 0;
int nWinRect=0;
//Chao-Kuo Lin
int nHideRect=0;
//used with windowcreated message
HWND lastMoved = NULL;
//end

int movingWin=-1;

//Chao-Kuo Lin
// our instance 
//HINSTANCE g_hInstance;

// this represents whether we are moving the regular window or the hidden window
// 0 == normal, 1 == hidden
int movingType = 0; 
HWND movingHWND = NULL;

//this var is for Window start on desktop to notify that
//the showHWND is about to show from hidden list and not actually
//just created
HWND showHWND[WIN_SHOWN_LIST];
int currentShow = 0;

//this var is for storing the last window that has focus
//so we will show the last on focus instead of the lame solution
HWND *LastFocus = NULL;
BOOL FocusLast = TRUE;

// actual Desktop area
RECT workingArea;
//end

//BOOL bUseWin32Hide = TRUE;

int movingMain=0;
int ticksNewW=0;
int iconSize=16;
int initialDesk=0;
int stickyTotal=0;
int fixTotal=0;

//Chao-Kuo Lin
int windowStartTotal=0;
//end

int mouseLeft=2;
int mouseRight=1;
int mouseMiddle=0;
int borderSize=0;

//Chao-Kuo Lin
BOOL mouseDoubleLeft = FALSE;
//BOOL mouseDoubleRight = FALSE;

volatile int lock=0;

static const char rcsRevision[] = _T("$Revision: 1.32$");
static const char rcsId[] = _T("$Id: ckVWM v1.32 PM 01:55 2001/8/1 Chao-Kuo Lin $");

static ConfigInfoT StickyConfig[256];
static ConfigInfoT FixConfig[256];
static StartWindowT StartWindow[256];
//Chao-Kuo Lin
static winDataType winRect[WIN_RECT_COUNT]; // 
static winDataType winHideRect[WIN_HIDE_COUNT]; // 
static winFixType winFix[WIN_FIX_COUNT]; // 
//end

static PTSTR pszWallpapers[256];
PTSTR *pszOnSwitch;
int nOnSwitch;


//Chao-Kuo Lin
// Debug output file
#ifdef VWM_DEBUG_OUTPUT
	FILE *debug_output;
#endif
//end

//Chao-Kuo Lin
// Step.rc var
//	TRUE will cause sysvwm to use my new implementation
BOOL bHideTaskOnSwitch = FALSE; 
//	TRUE will cause sysvwm to switch to the first screen, 0,
//	during quitModule
BOOL bReturntoFirstScreenOnRecycle = FALSE;
//	TRUE will cause the vwm to act like circular instead of linear
BOOL bWrapScreen = FALSE;
//	TREU will cause when dargging windows in mini-snapshot, window
//	will retain its relative position
BOOL bSnapWindowOnDrag = FALSE;

//  For PureLS users, you can specify this so that you will be able
//  to use the cool startwindownondesktop config
// BOOL bPureLS = FALSE;

// TRUE to disable them in step.rc
BOOL bVWMDisableVerticalAutoSwitch = FALSE;
BOOL bVWMDisableHorizontalAutoSwitch = FALSE;

//  The settings for BangRestore, window's dimention
int RestoreX = 10;
int RestoreY = 10;
int RestoreWidth = -400; //negative so that the original window's dimension
int RestoreHeight = -300; // will be retained

//  Setting for changing the determinating factor
//  10 = 10%, 100 = 100%
int MaximizeThreshold = 10;


//HHOOK g_Hook = NULL;

void (__stdcall *SwitchToThisWindow)(HWND, int);

void ReadConfig (void);
void prefixWinFix(int s);
int inFix(HWND hwnd);
void postfixWinFix(int s);
void removeWinFix(HWND hwnd);
void addWinFix(HWND hwnd, int s);
void CreateImageMasks(HWND hwnd);
void createView(void);
void createRecordedView(void);
void switchToDesktop(int desk, BOOL fixFocus);
void gatherAll(void);
void DoEvents(int n);
void MakeBuffer(HWND hWnd);
void RegisterBangCommands(void);
void UnRegisterBangCommands(void);
void getShifts(int old, int desk, int *addH, int *addV);
void SetDeskWallpaper(void);
int outsideAnyScreen(RECT r);
int getDesktopByRect(RECT r);
void NormalizeCoordinate(RECT *r, int *deskx, int *desky);

//Chao-Kuo Lin
BOOL IsInHideList(HWND hwnd);
BOOL IsRectOnScreen(LPRECT rect, HWND hwnd);
void RemoveWinFromList(void); // removes those that are now in the current desk
void RegenerateHideList(void);
winDataType *FindInList(HWND hwnd); //find the hwnd from hide list
winDataType *FindInRectList(HWND hwnd); //find the hwnd from the WinRect
BOOL ProcessWinData(winDataType *ptr);

BOOL StartWindowCheck(HWND hwnd);

void AddShownWindow(HWND hwnd);
BOOL IsShownWindow(HWND hwnd);

//our double click function no up and down for dblclik
MouseProc3(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

//show and hide window inline
//void ckShowWindow(HWND hwnd);
//void ckHideWindow(HWND hwnd);

void BangGather(HWND caller, LPCSTR args);

//bang commands for toggling
void BangHideTask(HWND caller, LPCSTR args); 
void BangWrap(HWND caller, LPCSTR args);
//bang command for restoring window if it disappeared
void BangRestore(HWND caller, LPCSTR args);
void BangRestoreAll(HWND caller, LPCSTR args);
//bang command for moving the main window
void BangMove(HWND caller, LPCSTR args);

void BangToggleOnTop(HWND caller, LPCSTR args);
//helper function
void SetAlwaysOnTop();
void SetNeverOnTop();


BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lParam);
BOOL RestoreWindowsProc(HWND hwnd);
BOOL RestoreAllWindowsProc(HWND hwnd);
BOOL RestoreAllWindowsCascadeProc(HWND hwnd);
//setup the mouse hook	
/*
void SetShellHook(void);
void RemoveShellHook(void);
LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam);
//end
*/

HICON getIconFromWindow(HWND hWnd, BOOL bBigIcon);
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK searchLSVWMproc(HWND hWnd, LPARAM lParam );

BOOL WinCheck1(HWND targetWin, char* matchval)
{
	char tmpbuf[0xFF+1];
	GetClassName(targetWin, tmpbuf, 0xFF);
	if (match(matchval, tmpbuf)) {return TRUE;}
	return FALSE;
}

BOOL WinCheck0(HWND targetWin, char* matchval)
{
	char tmpbuf[0xFF+1];
	GetWindowText(targetWin, tmpbuf, 0xFF);
	if (match(matchval, tmpbuf)) {return TRUE;}
	return FALSE;
}

BOOL Sticky(HWND hwnd)
{
	int num = 0;
	BOOL t = FALSE;
	
	for(num = 0; num < stickyTotal; ++num)
	{
		t = WinCheck1(hwnd,StickyConfig[num].match);
		if(t) break;
		t = WinCheck0(hwnd,StickyConfig[num].match);
		if(t) break;
	}
/*	
	while (1) {
		num++;
		t = StickyCheck1(hwnd,StickyConfig[num].match);
		if ((t == 0) && (num < stickyTotal)) continue;
		else break;
	}
	if (t == 0) {
		num = 0;
		while (1) {
			num++;
			t = StickyCheck0(hwnd,StickyConfig[num].match);
			if ((t == 0) && (num < stickyTotal)) continue;
			else break;
		}
	}
	if (t == 1) return TRUE;
	else return FALSE;
*/
	return t;

}

//check to see if hwnd's parent is in our fix list
//if it is, then we need to fix the window's relative
//position to its parent
BOOL Fix(HWND hwnd)
{
	int num = 0;
	BOOL t = FALSE;
	
	for(num = 0; num < fixTotal; ++num)
	{
		t = WinCheck1(hwnd,FixConfig[num].match);
		if(t) break;
		t = WinCheck0(hwnd,FixConfig[num].match);
		if(t) break;
	}

	return t;
}

void GetBMPSize(HBITMAP hBitmap, int *x, int *y)
{
	BITMAP bm;
	if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
    {
		*x=0;
		*y=0;
    }
	else
    {
		*x = bm.bmWidth;
		*y = bm.bmHeight;
    }
}

void BangToggleOnTop(HWND caller, LPCSTR args)
{
    BOOL setonTop = currentOnTop;

    //return if it's in wharf
    if(dockedOnWharf) return;

    if(args != NULL && strlen(args) > 0)
    {
       setonTop = (stricmp(args, "on") == 0 || stricmp(args, "true") == 0 || stricmp(args, "yes") == 0);
    }
    else
    {
        setonTop = !setonTop;
    }

    if(setonTop != currentOnTop)
    {
        currentOnTop = setonTop;
        // Set the parent correctly
        //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_POPUP) | WS_CHILD);
        SetParent(hMainWnd, currentOnTop ? NULL : desk);
        //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_CHILD) | WS_POPUP);
        SetWindowPos(hMainWnd, currentOnTop ? HWND_TOPMOST : HWND_BOTTOM, 0, 0, 0, 0,
                       SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }
}

void SetAlwaysOnTop()
{
    if(dockedOnWharf) return;

    currentOnTop = TRUE;
    // Set the parent correctly
    //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_POPUP) | WS_CHILD);
    SetParent(hMainWnd, NULL);
    //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_CHILD) | WS_POPUP);
    SetWindowPos(hMainWnd, HWND_TOPMOST, 0, 0, 0, 0,
                   SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

void SetNeverOnTop()
{
    if(dockedOnWharf) return;

    currentOnTop = FALSE;
    // Set the parent correctly
    //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_POPUP) | WS_CHILD);
    SetParent(hMainWnd, desk);
    //SetWindowLong(GWL_STYLE, (GetStyle() & ~WS_CHILD) | WS_POPUP);
    SetWindowPos(hMainWnd, HWND_BOTTOM, 0, 0, 0, 0,
                   SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}


void BangUp(HWND caller, LPCSTR args)
{
	RECT r;
	
	////////////////////////////
	// Chao-Kuo Lin
	int destScreen = currentScreen - ScreensX;
	// fix if the user decides for the wrapping scheme
	if(destScreen < 0 && bWrapScreen)
	{
		destScreen += MaxScreens; 
		if( (destScreen % ScreensX) == 0) // the screen is at left bottom
			destScreen = MaxScreens - 1; // change it to the right bottom
		else
			--destScreen; //move to left 1 instead just up and down
	}
		
	////////////////////////////

	if (destScreen >= 0 && !lock)
	{
		switchToDesktop(destScreen, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDown(HWND caller, LPCSTR args)
{
	RECT r;
	////////////////////////////
	// Chao-Kuo Lin
	int destScreen = currentScreen + ScreensX;
	// fix if the user decides for the wrapping scheme
	if(destScreen >= MaxScreens && bWrapScreen)
	{
		destScreen -= MaxScreens; 
		if(destScreen == (ScreensX - 1)) //screen is at right top
			destScreen = 0; // change it to the left top screen
		else
			++destScreen; // move one right instead of just up and down
	}
	////////////////////////////

	if (destScreen < MaxScreens  && !lock)
	{
		switchToDesktop(destScreen, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangLeft(HWND caller, LPCSTR args)
{
	RECT r;
	////////////////////////////
	// Chao-Kuo Lin
	int destScreen = currentScreen - 1;
	// fix if the user decides for the wrapping scheme
	if(destScreen < 0 && bWrapScreen)
		destScreen = MaxScreens - 1; 
	////////////////////////////
	

	if (destScreen >= 0 && !lock)
	{
		switchToDesktop(destScreen, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRight(HWND caller, LPCSTR args)
{
	RECT r;
	////////////////////////////
	// Chao-Kuo Lin
	int destScreen = currentScreen + 1;
	// fix if the user decides for the wrapping scheme
	if(destScreen >= MaxScreens && bWrapScreen)
		destScreen = 0; 
	////////////////////////////

	if ( destScreen < MaxScreens && !lock)
	{
		switchToDesktop(destScreen, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDesk(HWND caller, LPCSTR args)
{
	RECT r;
	int i = atoi(args);

	//bug cannot go to the previous one cause i forgot to -1
	if ((currentScreen != (i - 1)) && (i > 0) && (i <= MaxScreens) && !lock)
	{
		///////////////////////////////////////////////////
		// Chao-Kuo Lin
		// this should probably be i+1
		switchToDesktop(i-1, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRollUp(HWND caller, LPCSTR args)
{
	if (dockedOnWharf) return;
	if (!rolled)
	{
		rolled = TRUE;
		ShowWindow(hMainWnd,SW_HIDE);
	} else {
		rolled = FALSE;
		ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
}

//statler 990722 begin (snowchyld)
void BangShow(HWND caller, LPCSTR args)
{
	if (dockedOnWharf) return;
	rolled = FALSE;
	ShowWindow(hMainWnd,SW_SHOWNORMAL);
}

void BangHide(HWND caller, LPCSTR args)
{
	if (dockedOnWharf) return;
	rolled = TRUE;
	ShowWindow(hMainWnd,SW_HIDE);
}
//statler 990722 end (snowchyld)

void BangOpen(HWND caller, LPCSTR args)
{
	int s=0;
	char parm2[MAX_PATH]; /*parm3[MAX_PATH];*/
	//char *destptr, *topptr;
	//SHELLEXECUTEINFO si;
	RECT r;

	//topptr = args;

	if (args != NULL) {
		{
			char string[2000], seps[2000];
			char *token;

			//destptr = args;

			if (strlen(args) != 0) {

				strcpy(string, args);

				strcpy(seps, " ");
				token = strtok( string, seps );
				s = atoi(token);

				strcpy(seps, "");
				token = strtok( NULL, seps );
				strcpy(parm2, token);
			}
		}

    /*
		destptr = parm2;

		if (destptr != NULL)
		{
			char string[2000], seps[2000];
			char *token;

			if (strlen(parm2) != 0) {

				strcpy(string, parm2);

				if (string[0] == '\"') {
					strcpy(seps, "\"");
					token = strtok( string, seps );
				}
				else {
					strcpy(seps, " ");
					token = strtok( string, seps );
				}
				strcpy(parm2, token);

				strcpy(seps, "");
				token = strtok( NULL, seps );
				if (token != NULL) strcpy(parm3, token);
			}
		}
    */
	}

	if ((currentScreen != (s-1)) && (s > 0) && (s <= MaxScreens) && !lock)
	{
		switchToDesktop(s-1, FALSE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}

	if (parm2)
	{
		LSExecute(NULL, parm2, 0);
    /*
    memset(&si, 0, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);
		si.lpDirectory = NULL;
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = parm2;
		si.lpParameters = parm3;
		ShellExecuteEx(&si);
    */
	}

	GetClientRect(hMainWnd,&r);
	createView();
	InvalidateRect(hMainWnd, &r, FALSE);
}

void BangReset(HWND caller, LPCSTR args)
{
	int i;

	if (dockedOnWharf) return;
    if (mpos)
	{
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
	}
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);
	DestroyWindow(hMainWnd);

	//Chao-Kuo Lin
	// show all the hidden stuff
	for(i=0; i<nHideRect; i++)
	{
		//showHWND = winHideRect[i].hwnd;
		AddShownWindow(winHideRect[i].hwnd);
		ShowWindow(winHideRect[i].hwnd, WIN_SHOW_METHOD);
	}
	//end

	ReadConfig();
	/* //taken care in readconfig
	while (mainX < 0) mainX += ScreenWidth;
	//if (mainX < 0) mainX = ScreenWidth + mainX;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;

	while (mainY < 0) mainY += ScreenWidth;
	//if (mainY < 0) mainY = ScreenHeight + mainY;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;
	*/

	hMainWnd = CreateWindowEx(
		WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
		szAppName,
		szAppName,
		WS_POPUP,
		mainX, mainY,
		mainWidth, mainHeight,
		parent,
		NULL,
		inst,
		NULL);

	if (!hMainWnd)
	{
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		PostQuitMessage(0);
	}

	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord);
	DragAcceptFiles(hMainWnd, TRUE);
	
    (onTop) ? SetAlwaysOnTop() : SetNeverOnTop();

	if (!noShow) {
		if (VWMautohide) {
			POINT pts;
			GetCursorPos(&pts);
			if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
			{
				if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) {
					rolled = TRUE;
					ShowWindow(hMainWnd,SW_HIDE);
				}
			}
		}
		else ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
	else rolled = TRUE;

	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
	SetTimer(hMainWnd, autoTimer, 50, NULL);
	if (autoswitch) SetTimer(hMainWnd, mcTimer, 50, NULL);
}

void BangMoveApp(HWND caller, LPCSTR args)
{
	HWND MoveHwnd = GetForegroundWindow();
	RECT newRect, r;
	int addH = 0, addV = 0;
	int destScreen, srcScreen;

	//char text[0xFF+1];
	
	if(MoveHwnd == NULL) 
	{
	//	MessageBox(NULL, "No Foreground shit", "Error", MB_OK);
		return;
	}
	
	//GetWindowText(MoveHwnd, text, 0xFF);
	//MessageBox(NULL, text, "Starting Title", MB_OK);
	MoveHwnd = GetWindow(MoveHwnd, GW_HWNDFIRST);

	while
	( 		MoveHwnd != NULL && 
			(GetWindowLong(MoveHwnd , GWL_USERDATA) == magicDWord) || 
			!IsWindowVisible(MoveHwnd) || 
			//((GetWindowLong(MoveHwnd, GWL_EXSTYLE) & WS_EX_TOPMOST) && MoveHwnd != GetFocus())
			((GetWindowLong(MoveHwnd, GWL_EXSTYLE) & WS_EX_TOPMOST) && GetParent(MoveHwnd) != GetDesktopWindow())

	)
	{
		MoveHwnd =  GetNextWindow(MoveHwnd, GW_HWNDNEXT);
		if(MoveHwnd == NULL) break;
	//	GetWindowText(MoveHwnd, text, 0xFF);
	//	MessageBox(NULL, text, "Title", MB_OK);
	}

	if(MoveHwnd == NULL) 
	{
		//MessageBox(NULL, "Nothing is visible", "Error", MB_OK);
		return;
	}
	
	//GetWindowText(MoveHwnd, text, 0xFF);
	//MessageBox(NULL, text, "Title", MB_OK);

	GetWindowRect(MoveHwnd, &newRect);
	srcScreen = getDesktop(MoveHwnd);

	if (!stricmp (args, "up")) 
	{
		destScreen = srcScreen - ScreensX;
		// fix if the user decides for the wrapping scheme
		if(destScreen < 0 && bWrapScreen && !bVWMDisableVerticalAutoSwitch)
		{
			destScreen += MaxScreens; 
			if( (destScreen % ScreensX) == 0) // the screen is at left bottom
				destScreen = MaxScreens - 1; // change it to the right bottom
			else
				--destScreen; //move to left 1 instead just up and down
		}

		if (destScreen >= 0)
			getShifts(srcScreen, destScreen, &addH, &addV);
	}
	else if (!stricmp (args, "down")) 
	{
		destScreen = srcScreen + ScreensX;
		// fix if the user decides for the wrapping scheme
		if(destScreen >= MaxScreens && bWrapScreen && !bVWMDisableVerticalAutoSwitch)
		{
			destScreen -= MaxScreens; 
			if(destScreen == (ScreensX - 1)) //screen is at right top
				destScreen = 0; // change it to the left top screen
			else
				++destScreen; // move one right instead of just up and down
		}
		////////////////////////////

		if (destScreen < MaxScreens)
			getShifts(srcScreen, destScreen, &addH, &addV);

	}
	else if (!stricmp (args, "left")) 
	{
		destScreen = srcScreen - 1;
		// fix if the user decides for the wrapping scheme
		if(destScreen < 0 && bWrapScreen && !bVWMDisableHorizontalAutoSwitch)
			destScreen = MaxScreens - 1; 
		////////////////////////////
		if (destScreen >= 0)
			getShifts(srcScreen, destScreen, &addH, &addV);
	}
	else if (!stricmp (args, "right")) 
	{
		////////////////////////////
		// Chao-Kuo Lin
		destScreen = srcScreen + 1;
		// fix if the user decides for the wrapping scheme
		if(destScreen >= MaxScreens && bWrapScreen && !bVWMDisableHorizontalAutoSwitch)
			destScreen = 0; 
		////////////////////////////

		if ( destScreen < MaxScreens)
			getShifts(srcScreen, destScreen, &addH, &addV);
	}
	else
	{	//check to see if it's a desk  number
		LPCSTR temp;
		temp = args;	
		while(*temp)
		{
			if(!isspace(*temp) && !isdigit(*temp)) return;
			++temp;
		}
		
		getShifts(srcScreen, atoi(args)-1, &addH, &addV);
	}

	//we didn't get shifts because the user doesn't wrap screen, let's return
	if(addH == 0 && addV == 0)
		return;
	
	MoveWindow(MoveHwnd, newRect.left + addH, newRect.top + addV, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);

	GetClientRect(hMainWnd,&r);
	createView();
	InvalidateRect(hMainWnd, &r, FALSE);
}

void RegisterBangCommands(void)
{
	AddBangCommand("!VWMGATHER", BangGather);
	AddBangCommand("!VWMUP", BangUp);
	AddBangCommand("!VWMDOWN", BangDown);
	AddBangCommand("!VWMLEFT", BangLeft);
	AddBangCommand("!VWMRIGHT", BangRight);
	AddBangCommand("!VWMDESK", BangDesk);
	AddBangCommand("!VWMROLLUP", BangRollUp);
	AddBangCommand("!VWMOPEN", BangOpen);
//statler 990722 start	(snowchyld)
	AddBangCommand("!VWMSHOW", BangShow);
	AddBangCommand("!VWMHIDE", BangHide);
//statler 990722 end    (snowchyld)
	AddBangCommand("!VWMRESET", BangReset);
	AddBangCommand("!VWMMOVEAPP", BangMoveApp);
	
//Chao-Kuo Lin
	AddBangCommand("!VWMTOGGLEHIDETASKONSWITCH", BangHideTask);
	AddBangCommand("!VWMTOGGLEWRAPSCREEN", BangWrap);
	AddBangCommand("!VWMRESTOREWINDOW", BangRestore);
	AddBangCommand("!VWMRESTOREALLWINDOWS", BangRestoreAll);
	AddBangCommand("!VWMMove", BangMove);
    AddBangCommand("!VWMToggleOnTop", BangToggleOnTop);
//end

}

void UnRegisterBangCommands(void)
{
	RemoveBangCommand("!VWMGATHER");
	RemoveBangCommand("!VWMUP");
	RemoveBangCommand("!VWMDOWN");
	RemoveBangCommand("!VWMLEFT");
	RemoveBangCommand("!VWMRIGHT");
	RemoveBangCommand("!VWMDESK");
	RemoveBangCommand("!VWMROLLUP");
	RemoveBangCommand("!VWMOPEN");

	RemoveBangCommand("!VWMSHOW");
	RemoveBangCommand("!VWMHIDE");

	RemoveBangCommand("!VWMRESET");
	RemoveBangCommand("!VWMMOVEAPP");

	RemoveBangCommand("!VWMTOGGLEHIDETASKONSWITCH");
	RemoveBangCommand("!VWMTOGGLEWRAPSCREEN");
	RemoveBangCommand("!VWMRESTOREWINDOW");
	RemoveBangCommand("!VWMRESTOREALLWINDOWS");
	RemoveBangCommand("!VWMMove");
    RemoveBangCommand("!VWMToggleOnTop");
}

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, (wd) ? wd->lsPath : NULL);
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	dockedOnWharf = TRUE;
	GetWindowRect(ParentWnd, &wharfRect);
	wharfSize.x = wharfRect.right - wharfRect.left;
	wharfSize.y = wharfRect.bottom - wharfRect.top;

	return initModuleEx (ParentWnd, dllInst, (wd) ? wd->lsPath : NULL);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	#ifdef VWM_DEBUG_OUTPUT
		char buffer[0xFF+1];
	#endif

	RECT r;
	HDC pDC;
	UINT Msgs[10];
	int XPos, YPos;
	int sze;

	memset(winRect, 0, sizeof(winRect));
	memset(winHideRect, 0, sizeof(winHideRect));

	#ifdef VWM_DEBUG_OUTPUT
		debug_output = fopen("C:\\WINDOWS\\Application Data\\Microsoft\\Internet Explorer\\Quick Launch\\debug.txt", "w");
	#endif
	// end

	memset(winFix, 0, sizeof(winFix));
	
	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	SystemParametersInfo(SPI_GETWORKAREA,0,&workingArea,0);

	#ifdef VWM_DEBUG_OUTPUT
		wsprintf(buffer, "Screen Dimention: %d X %d\n version1.1", ScreenWidth, ScreenHeight);
		fputs(buffer, debug_output);
	#endif
	
	strcpy (szLitestepPath, szPath);
	
	pszOnSwitch = NULL;
	nOnSwitch = 0;

	ReadConfig();
	
	if (dockedOnWharf) 
	{
		mainX = borderSize;
		mainY = borderSize;
		mainWidth = wharfSize.x-borderSize*2;
		mainHeight = wharfSize.y-borderSize*2;
	}

	oldMainX = mainX;
	oldMainY = mainY;

	MaxScreens = ScreensX * ScreensY;
	deskRect = malloc(MaxScreens * sizeof(RECT));
	LastFocus = malloc(MaxScreens * sizeof(HWND));
	memset(LastFocus, 0, MaxScreens * sizeof(HWND));

	for (YPos = 0; YPos < ScreensY; YPos++) 
		for (XPos = 0; XPos < ScreensX; XPos++)
		{
			int desk = (YPos * ScreensX) + XPos;
			int top = YPos * (ScreenHeight);
			int left = XPos * (ScreenWidth);
			
			deskRect[desk].top = top;
			deskRect[desk].left = left;
			deskRect[desk].right = left + ScreenWidth + 10;
			deskRect[desk].bottom = top + ScreenHeight + 10;
		}
	
	if (dockedOnWharf) 
	{
		wndSizeX = (wharfSize.x - borderSize*2) / ScreensX;
		wndSizeY = (wharfSize.y - borderSize*2) / ScreensY;
		nOffsetX = ((wndSizeX*ScreensX) - wharfSize.x)+borderSize;
		nOffsetY = ((wndSizeY*ScreensY) - wharfSize.y)+borderSize;
	} 
	else 
	{	
		wndSizeX = mainWidth / ScreensX;
		wndSizeY = mainHeight / ScreensY;
		nOffsetX = (wndSizeX*ScreensX) - mainWidth;
		nOffsetY = (wndSizeY*ScreensY) - mainHeight;
	}
	
	ratioX = (ScreenWidth)/wndSizeX;
	ratioY = (ScreenHeight)/wndSizeY;
	
	TitlebarHeight = wndSizeY / titleHeightMod;
	
	//inst = dllInst;
	
	tapp = GetLitestepWnd();
	
	sze = sizeof(int) | VWM_DESKNO;
	
	SendMessage(tapp, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &currentScreen);

	desk = FindWindow("DesktopBackgroundClass", NULL);
	winswitch = FindWindow("#32771", NULL);
	(long)SwitchToThisWindow = (long)GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	
	{
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppName;
		wc.style = CS_DBLCLKS;
		
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class",szAppName,MB_OK);
			PostQuitMessage(0);
			return 1;
		}
	}
	
	if (dockedOnWharf) parent = ParentWnd;
	else 
	{
		parent = FindWindow("DesktopBackgroundClass", NULL);
		if (!parent) parent = GetDesktopWindow();
	}

/* //taken care in readconfig
	if (mainX < 0) mainX = ScreenWidth + mainX;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
	
	if (mainY < 0) mainY = ScreenHeight + mainY;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;
*/

	hMainWnd = CreateWindowEx(
		dockedOnWharf?WS_EX_TRANSPARENT:WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
		szAppName,
		NULL,
		dockedOnWharf?WS_CHILD:WS_POPUP,
		mainX, mainY,
		mainWidth, mainHeight,
		parent,
		NULL,
		dllInst,
		NULL);
	
	if (!hMainWnd) 
	{						   
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);
		PostQuitMessage(0);
		return 1;
	}

    (onTop) ? SetAlwaysOnTop() : SetNeverOnTop();
	
	Msgs[0] = LM_BRINGTOFRONT;
	Msgs[1] = LM_SWITCHTON;
	// Chao-Kuo Lin
	Msgs[2] = LM_GETREVID;
	Msgs[3] = LM_WINDOWCREATED;
	//Msgs[3] = LM_ADDWINDOW;
	// Chao-Kuo Lin
	Msgs[4] = 0;
	
	SendMessage(tapp, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	RegisterBangCommands();
	
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord);
	DragAcceptFiles(hMainWnd, TRUE);
	
    pDC = GetDC(parent);
	memDC = CreateCompatibleDC(pDC);
	memBM = CreateCompatibleBitmap(pDC, wndSizeX*ScreensX+ScreensX,wndSizeY*ScreensY+ScreensY);
	ReleaseDC(parent, pDC);
	oldBM = SelectObject(memDC,memBM);
	
	if (!dockedOnWharf) 
	{
		if (!noShow)
		{
			if (VWMautohide) 
			{
				POINT pts;
				GetCursorPos(&pts);
				if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
				{
					if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) 
					{
						rolled = TRUE;
						ShowWindow(hMainWnd,SW_HIDE);
					}
				}
			}
			else ShowWindow(hMainWnd,SW_SHOWNORMAL);
		}
		else rolled = TRUE;
	} 
	else 
		ShowWindow(hMainWnd,SW_SHOWNORMAL);


	if (useInitialDesk)
	{
	    if (initialDesk > MaxScreens) initialDesk = MaxScreens;
	    else if(initialDesk <= 0) initialDesk = 1;
	    
	    switchToDesktop(initialDesk-1, FALSE);
	}
	
	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
	if (!dockedOnWharf) SetTimer(hMainWnd, autoTimer, 50, NULL);
	if (autoswitch) SetTimer(hMainWnd, mcTimer, 50, NULL);

	SetDeskWallpaper();

	return 0;
}

int quitWharfModule(HINSTANCE dllInst)
{
	return quitModule(dllInst);
}

int quitModule(HINSTANCE dllInst)
{
	int nDesks;
	int i;
	UINT Msgs[10];

	
	//Chao-Kuo Lin
	// Clean up and stuff
	
	
	#ifdef VWM_DEBUG_OUTPUT
	if(debug_output) fclose(debug_output);
	#endif
	//end

	/*
	if(bPureLS)
		RemoveShellHook();
	*/

	gatherAll();
	
    if (mpos)
	{
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
	}
	
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);
	KillTimer(hMainWnd, autoTimer);
	
	
	SelectObject(memDC,oldBM);
	SelectObject(bgDC, oldBG);
	DeleteDC(memDC);
	DeleteDC(bgDC);
	DeleteObject(bBGBitmap);
	DeleteObject(sBGBitmap);
	DeleteObject(tBGBitmap);
	DeleteObject(wBGBitmap);
	DeleteObject(memBM);
	ImageList_Remove(hBGList, -1);
	ImageList_Destroy(hBGList);
	
	Msgs[0] = LM_BRINGTOFRONT;
	Msgs[1] = LM_SWITCHTON;
	//Chao-Kuo LIn
	Msgs[2] = LM_GETREVID;
	Msgs[3] = LM_WINDOWCREATED;
	//Msgs[3] = LM_ADDWINDOW;
	Msgs[4] = 0;
	//Chao-Kuo Lin
	
	SendMessage(tapp, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	DestroyWindow(hMainWnd);
	UnRegisterBangCommands();
	UnregisterClass(szAppName,dllInst);
	
	free(deskRect);
	deskRect = NULL;
	free(LastFocus);
	LastFocus = NULL;

	nDesks = ScreensX * ScreensY;

	for( i = 0; i < nDesks; i++ )
	{
		if( pszWallpapers[i] )
			free( (void *)pszWallpapers[i] );
	}

	for( i = 0; i < nOnSwitch; i++ )
	{
		if( pszOnSwitch[i] )
			free( (void *)pszOnSwitch[i] );
	}

	free( (void *)pszOnSwitch );

	return 0;
}

int MouseProc1down(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	if (lock) 
	{
		PostMessage(hwnd, message, wParam, lParam);
		return 0;
	}
	lock = 1;
	{
		POINT pt;
		int deskx;
		int desky;
		int s;
		
		if (dockedOnWharf) 
		{
			POINTS pts;
			pts = MAKEPOINTS(lParam);
			pt.x = pts.x;
			pt.y = pts.y;
		} 
		else 
		{
			GetCursorPos(&pt);
		}

		deskx = (pt.x-mainX) / wndSizeX;
		desky = (pt.y-mainY) / wndSizeY;

		s = (desky * ScreensX) + deskx;
		
		{
			RECT r;
			switchToDesktop(s, TRUE);
			GetClientRect(hwnd,&r);
			createView();
			InvalidateRect(hwnd, &r, FALSE);
		}
	}

	lock=0;
  return 1;
}

int MouseProc1up(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

void MouseProc2down(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pts;
	int i;
	int deskX = currentScreen % ScreensX;
	int deskY = currentScreen / ScreensX;
	
	if (dockedOnWharf) 
	{
		POINTS pt;
		pt = MAKEPOINTS(lParam);
		pts.x = pt.x;
		pts.y = pt.y;
	} 
	else 
	{
		GetCursorPos(&pts);
	}

	pts.x = pts.x-mainX;
	pts.y = pts.y-mainY;
	
	movingHWND = NULL;
	movingWin = -1;

	for (i=0;winRect[i].valid;i++);

	for (i--; i>=0;i--)
	{
		if ((pts.x-wndSizeX*deskX >= winRect[i].r.left/ratioX) &&
			(pts.x-wndSizeX*deskX <= winRect[i].r.right/ratioX) &&
			(pts.y-wndSizeY*deskY >= winRect[i].r.top/ratioY) &&
			(pts.y-wndSizeY*deskY <= winRect[i].r.bottom/ratioY))
		{
			GetWindowRect(winRect[i].hwnd, &oldWinPos);
			movingType = 0;
			movingHWND = winRect[i].hwnd;
			movingWin = i;
			pts.x = pts.x+mainX;
			pts.y = pts.y+mainY;
			lastPoint = pts;
			SetCapture(hMainWnd);
			//break;
			return;
		}
	}
	
//	if(!movingHWND)
//	{
		for (i=0;winHideRect[i].valid && i < nHideRect;i++);

		for (i--; i>=0;i--)
		{
			if ((pts.x-wndSizeX*deskX >= winHideRect[i].r.left/ratioX) &&
				(pts.x-wndSizeX*deskX <= winHideRect[i].r.right/ratioX) &&
				(pts.y-wndSizeY*deskY >= winHideRect[i].r.top/ratioY) &&
				(pts.y-wndSizeY*deskY <= winHideRect[i].r.bottom/ratioY))
			{
				GetWindowRect(winHideRect[i].hwnd, &oldWinPos);
				movingType = 1;
				movingHWND = winRect[i].hwnd;
				movingWin = i;
				pts.x = pts.x+mainX;
				pts.y = pts.y+mainY;
				lastPoint = pts;
				SetCapture(hMainWnd);
				//break;
				return;
			}
		}
//	}
	
	if ((!noMove) && (movingWin == -1)) {
		movingMain = 1;
		if (dockedOnWharf) 
		{
			POINTS pt;
			pt = MAKEPOINTS(lParam);
			pts.x = pt.x;
			pts.y = pt.y;
		} 
		else 
		{
			GetCursorPos(&pts);
		}

		diff.x = pts.x - mainX;
		diff.y = pts.y - mainY;
		SetCapture(hMainWnd);
	}
}

void MouseProc2up(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	RECT r;
	int s, deskx, desky;
	
	if (dockedOnWharf) 
	{
		POINTS pts;
		pts = MAKEPOINTS(lParam);
		pt.x = pts.x;
		pt.y = pts.y;
	} 
	else 
	{
		GetCursorPos(&pt);
	}

	if (!movingMain) 
	{
		pt.x = pt.x-mainX;
		pt.y = pt.y-mainY;
	}
	
	deskx = pt.x-mainX / wndSizeX;
	desky = pt.y-mainY / wndSizeY;
	s = (desky * ScreensX) + deskx;
	ReleaseCapture();
	
	if (movingMain == 1) {
		if (pt.x-diff.x < snapWidth) mainX = 0;
		else mainX = pt.x-diff.x;
		
		if (pt.y-diff.y < snapWidth) mainY = 0;
		else mainY = pt.y-diff.y;
		
		if (mainX+mainWidth+snapWidth > ScreenWidth) mainX = ScreenWidth-mainWidth;
		if (mainY+mainHeight+snapWidth > ScreenHeight) mainY = ScreenHeight-mainHeight;
		
		MoveWindow(hwnd, mainX, mainY, mainWidth, mainHeight, TRUE);
		movingMain = 0;
	} else {
		//winDataType *ptr = FindInList(movingHWND);
		//if(!ptr) ptr = FindInRectList(movingHWND);
		//if(!ptr) return;
		winDataType *ptr = (movingType == 1) ? 
						&(winHideRect[movingWin]):&(winRect[movingWin]);
		
		if (pt.x < 0 || pt.y < 0 || pt.x > mainWidth || pt.y > mainHeight)
			MoveWindow(ptr->hwnd, oldWinPos.left, oldWinPos.top, oldWinPos.right-oldWinPos.left, oldWinPos.bottom-oldWinPos.top, TRUE);
/*
		else if (GetWindowLong(ptr->hwnd, GWL_STYLE) & WS_MAXIMIZE)
		{
			RECT newRect;
			int oldDesk = getDesktopByRect(oldWinPos);
			int newDesk = s;
			newRect.top = oldWinPos.top + deskRect[newDesk].top - deskRect[oldDesk].top;
			newRect.left = oldWinPos.left + deskRect[newDesk].left - deskRect[oldDesk].left;
			newRect.bottom = oldWinPos.bottom + deskRect[newDesk].top - deskRect[oldDesk].top;
			newRect.right = oldWinPos.right + deskRect[newDesk].left - deskRect[oldDesk].left;
			MoveWindow(ptr->hwnd, newRect.left, newRect.top, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);
			GetWindowRect(ptr->hwnd, &(ptr->r));
		}
*/
		GetClientRect(hwnd,&r);
		createRecordedView();
		InvalidateRect(hwnd, &r, FALSE);
		movingWin=-1;
	}
}


MouseProc3(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int i;
	POINTS pt;
	int deskX = currentScreen % ScreensX;
	int deskY = currentScreen / ScreensX;
	HWND target = NULL;

	pt = MAKEPOINTS(lParam);
	
	for (i=0;winRect[i].valid;i++);

	for (i--; i>=0;i--)
	{
		if ((pt.x-wndSizeX*deskX >= winRect[i].r.left/ratioX) &&
			(pt.x-wndSizeX*deskX <= winRect[i].r.right/ratioX) &&
			(pt.y-wndSizeY*deskY >= winRect[i].r.top/ratioY) &&
			(pt.y-wndSizeY*deskY <= winRect[i].r.bottom/ratioY))
		{
			
			target = winRect[i].hwnd;
			break;
		}
	}

	if(!target)
	{
		for (i=0;winHideRect[i].valid && i < nHideRect;i++);

		for (i--; i>=0;i--)
		{
			if ((pt.x-wndSizeX*deskX >= winHideRect[i].r.left/ratioX) &&
				(pt.x-wndSizeX*deskX <= winHideRect[i].r.right/ratioX) &&
				(pt.y-wndSizeY*deskY >= winHideRect[i].r.top/ratioY) &&
				(pt.y-wndSizeY*deskY <= winHideRect[i].r.bottom/ratioY))
			{
				target = winRect[i].hwnd;
				break;
			}
		}
	}
	
	if(target)
	{
		if(GetWindowLong(hwnd, GWL_STYLE) & WS_MAXIMIZE)
			ShowWindow(target, SW_RESTORE);
		else
			ShowWindow(target, SW_SHOWMAXIMIZED);
	}
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	#ifdef VWM_DEBUG_OUTPUT
	{
		char buf[10];
		wsprintf(buf, "%ul", message);
		fputs("Message Number ", debug_output);
		fputs(buf, debug_output);
		fputs(" was recieved.\n", debug_output);
	}
	#endif

	switch (message)
	{
	case WM_CREATE:	
		MakeBuffer(parent);
		CreateImageMasks(parent);
		return 0;

	//we don't let user destroy us that easily
	case WM_CLOSE: 
		return 0;

	case WM_ERASEBKGND:
		return 0;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT r;
			HDC hdc = BeginPaint(hwnd,&ps);
/*			
			if (First) 
			{
				MakeBuffer(parent);
				CreateImageMasks(parent);
				First = 0;
			}
*/			
			GetClientRect(hwnd,&r);
			if (!backInit)
			{
				createView();
				backInit = TRUE;
			}
			BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		PostMessage(parent,message,wParam,lParam);
		return 0;
	case WM_RBUTTONDOWN:
		if (mouseRight == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseRight == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_RBUTTONUP:
		if (mouseRight == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseRight == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;
	case WM_LBUTTONDOWN:
		if (mouseLeft == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseLeft == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_LBUTTONUP:
		if (mouseLeft == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseLeft == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;
	case WM_MBUTTONDOWN:
		if (mouseMiddle == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseMiddle == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_MBUTTONUP:
		if (mouseMiddle == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseMiddle == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;

	//add double click functions
	case WM_LBUTTONDBLCLK:
		if(mouseDoubleLeft)
			MouseProc3(hwnd, message, wParam, lParam);
		return 0;
		
	case WM_MOUSEMOVE:
		{
			POINT pts, thisPt;
			RECT r;
			
			if (dockedOnWharf) 
			{
				POINTS pt;
				pt = MAKEPOINTS(lParam);
				pts.x = pt.x;
				pts.y = pt.y;
			} 
			else 
			{
				GetCursorPos(&pts);
			}

			if (movingMain == 1) 
			{
				if (moveCursor == FALSE) SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_SIZEALL)));
				
				if (pts.x-diff.x < snapWidth) mainX = 0;
				else mainX = pts.x-diff.x;
				
				if (pts.y-diff.y < snapWidth) mainY = 0;
				else mainY = pts.y-diff.y;
				
				if (mainX+mainWidth+snapWidth > ScreenWidth) mainX = ScreenWidth-mainWidth;
				if (mainY+mainHeight+snapWidth > ScreenHeight) mainY = ScreenHeight-mainHeight;
				
				MoveWindow(hwnd, mainX, mainY, mainWidth, mainHeight, TRUE);
				moveCursor = TRUE;
			} 
			else if (movingWin != -1) 
			{
				//winDataType *ptr = FindInList(movingHWND);
				//if(!ptr) ptr = FindInRectList(movingHWND);
				//if(!ptr) return 0;
				winDataType *ptr = (movingType == 1) ? 
						&(winHideRect[movingWin]):&(winRect[movingWin]);


				if (moveCursor == TRUE) 
				{
					SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
					moveCursor = FALSE;
				}
				
				if(bSnapWindowOnDrag)
				{//the last point is relative to the whole screen
					int OldDesk, CurDesk;
					int AddH, AddV;
					
					#ifdef VWM_DEBUG_OUTPUT
					char buffer[0xFF+1];
					fputs("Window dragging snap method is enabled\n", debug_output);
					#endif
					
					CurDesk = (((pts.y-mainY)/ wndSizeY)*ScreensX) + ((pts.x - mainX) / wndSizeX);
						
					OldDesk = (((lastPoint.y-mainY)/ wndSizeY)*ScreensX) + ((lastPoint.x - mainX) / wndSizeX);
					
					#ifdef VWM_DEBUG_OUTPUT
					wsprintf(buffer, "The old desktop was number %d, the new desktop is number %d\n", OldDesk, CurDesk);
					fputs(buffer, debug_output);
					#endif

					if(CurDesk != OldDesk)
					{
						//int shiftY;
						getShifts(OldDesk, CurDesk, &AddH, &AddV);
						//shiftY = ((CurDesk / ScreensX) - (OldDesk / ScreensX));
						//AddV -= shiftY * 10;
						GetWindowRect(ptr->hwnd, &(ptr->r));
						MoveWindow(ptr->hwnd, ptr->r.left + AddH, ptr->r.top + AddV, ptr->r.right - ptr->r.left, ptr->r.bottom - ptr->r.top, TRUE);
						GetWindowRect(ptr->hwnd, &(ptr->r));
					}

					lastPoint = pts;
				}
				else
				{
					thisPt = pts;

					pts.x -= lastPoint.x;
					pts.y -= lastPoint.y;
				
					

					GetWindowRect(ptr->hwnd, &(ptr->r));
					MoveWindow(ptr->hwnd, 
						ptr->r.left + pts.x*ratioX, ptr->r.top + pts.y * ratioY, 
						ptr->r.right - ptr->r.left, ptr->r.bottom - ptr->r.top,
						TRUE);
						//ptr->r.right + pts.x * ratioX - (ptr->r.left + pts.x*ratioX), 
						//ptr->r.bottom + pts.y * ratioY-(ptr->r.top + pts.y*ratioY), TRUE);

					GetWindowRect(ptr->hwnd, &(ptr->r));
					lastPoint = thisPt;
				}
				////////////////////////////
				// Chao-Kuo Lin
				// this block of code doesn't call any of my helper functions
				// to speed up?
/*
				//if( !(GetWindowLong(ptr->hwnd, GWL_STYLE) & WS_VISIBLE))
				if(!IsWindowVisible(ptr->hwnd))
				{
					if(IsRectOnScreen(&(ptr->r), ptr->hwnd))
					{
						if(IsInHideList(ptr->hwnd))
						{
							//winDataType *p = FindInList(ptr->hwnd);
							//memcpy(p, &(ptr[movingWin]), sizeof(winDataType));
							//ptr->valid = 3;
							FindInList(ptr->hwnd)->valid = 3;
						}
						else
							ptr->valid = 1;

						//showHWND = ptr->hwnd;
						AddShownWindow(ptr->hwnd);
						ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
					}
					else
					{
						if(!IsInHideList(ptr->hwnd))
						{//add it
							ptr->valid = 1;
							memcpy(&(winHideRect[nHideRect++]), ptr, sizeof(winDataType));
							memset(&(winHideRect[nHideRect]), 0, sizeof(winDataType));
						}
					}

				}
				else //it's visible, check if we need to hide
				{
					//hmm......check ptr == winHidRect?
					if(!IsRectOnScreen(&(ptr->r), ptr->hwnd))
					{
						if(IsInHideList(ptr->hwnd) )
						{//it was dragged here, then back to invisible
							ShowWindow(ptr->hwnd, SW_HIDE);
							//ptr->valid = 1;
							FindInList(ptr->hwnd)->valid = 1;
						}
						else //not in hide list, let's add
						{
							ptr->valid = 1;
							//memcpy(&(winHideRect[nHideRect++]), &(ptr[movingWin]), sizeof(winDataType));
							memcpy(&(winHideRect[nHideRect++]), ptr, sizeof(winDataType));
							memset(&(winHideRect[nHideRect]), 0, sizeof(winDataType));
							ShowWindow(ptr->hwnd, SW_HIDE);
						}
					}
				}
				//end
*/
				ProcessWinData(ptr);
				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
			
			} 
			else if (moveCursor == TRUE) 
			{
				SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
				moveCursor = FALSE;
				return 0;
			}
		}
		return 0;
		
	case LM_SWITCHTON:
		{
			RECT r;
			int i = wParam;
			
			if ((currentScreen != i) && !lock)
			{
				switchToDesktop(i, FALSE);
				GetClientRect(hMainWnd, &r);
				createView();
				InvalidateRect(hMainWnd, &r, TRUE);
			}
			return TRUE;
		}
		
	case LM_BRINGTOFRONT: // Change window focus via message (change desktop if needed)
		if (lock)
		{ // Try later
			PostMessage(hwnd, message, wParam, lParam);
			return TRUE;
		}
		lock = 1;
		{
			int n = getDesktop((HWND)lParam);
			if (n != currentScreen) switchToDesktop(n, TRUE);
			SwitchToThisWindow((HWND)lParam, 1);
		}
		lock=0;
		return TRUE;

	///////////////////////
	//Chao-Kuo Lin
	case LM_GETREVID: 
		{
			PTSTR buffer = (PTSTR)lParam;
			
			if (wParam == 0)
			{
				_tcscpy(buffer, _T("ckVWM: "));
				_tcscat(buffer, &rcsRevision[11]);
				buffer[_tcslen(buffer)-1] = 0;
			}
			else if (wParam == 1)
			{
				_tcscpy(buffer, &rcsId[5]);
				buffer[_tcslen(buffer)-1] = 0;
			} else
			{
				_tcscpy(buffer, _T(""));
			}
			return _tcslen(buffer);
		}

	//a new window is just created
	//use this place to reposition the windows
	//case LM_ADDWINDOW:
	case LM_WINDOWCREATED:
		{
			
			RECT r;
			int AddH, AddV;
			int index;
			//we use this cause strange windowcreated is sent twice
			
			HWND windowCreated = (HWND)wParam;
			HWND foregroundWindow = NULL;
			
			#ifdef VWM_DEBUG_OUTPUT
				char text[0xff+1];
				char buffer[0xff+1];
				GetWindowText(windowCreated, text, 0xFF);
				wsprintf(buffer, "Window \"%s\" is created.\n", text);
				fputs(buffer, debug_output);
			#endif
			
			if(windowCreated == lastMoved) return 0;

			if( GetWindowLong(windowCreated, GWL_USERDATA) == magicDWord || 
				IsShownWindow(windowCreated) || windowCreated == NULL)
				return 0;


			#ifdef VWM_DEBUG_OUTPUT
				fputs("The window is just launched", debug_output);
			#endif

			if(IsWindowVisible(windowCreated) || IsIconic(windowCreated))
			{
				#ifdef VWM_DEBUG_OUTPUT
					fputs("looking for the Window in StartWindow Database...\n",debug_output);
				#endif

				index = StartWindowCheck(windowCreated);

				if(index >= 0)
				{
					if(StartWindow[index].desktop != currentScreen)
					{
						foregroundWindow = GetForegroundWindow();
						if(foregroundWindow == windowCreated)
						{
							do
								foregroundWindow = GetNextWindow(foregroundWindow, GW_HWNDNEXT);
							while(	((GetWindowLong(foregroundWindow , GWL_USERDATA) == magicDWord) ||
									!IsWindowVisible(foregroundWindow)) && foregroundWindow != NULL);

							if(foregroundWindow != NULL)
							{
								SetForegroundWindow(foregroundWindow);
								SwitchToThisWindow(foregroundWindow, 1);
							}
						}
					
						#ifdef VWM_DEBUG_OUTPUT
							wsprintf(buffer, "about to move Window \"%s\" from desktop %d to %d.\n", text, currentScreen, StartWindow[index].desktop);
							fputs(buffer, debug_output);
						#endif

						getShifts(currentScreen, StartWindow[index].desktop, &AddH, &AddV);
						
						if(GetWindowRect(windowCreated, &r))
						{
							MoveWindow(windowCreated, r.left+AddH, r.top+AddV, r.right-r.left, r.bottom-r.top, TRUE);

							#ifdef VWM_DEBUG_OUTPUT
							fputs("window moved.\n", debug_output);
							#endif
							
							if(foregroundWindow != NULL)
							{// to make sure that movewindow doesnt' change focus
								SetForegroundWindow(foregroundWindow);
								SwitchToThisWindow(foregroundWindow, 1);
							}
						}
						
					}

					lastMoved = windowCreated;
				}
			}
			//PostMessage(GetLitestepWnd(), LM_WINDOWCREATED, wParam, 0);
		}
		return 0;
	
	//End Chao-Kuo Lin
	///////////////////////
	case WM_WINDOWPOSCHANGING:
		if (!onTop) {
			WINDOWPOS *lpwp = (WINDOWPOS*)lParam;
			lpwp->flags |= SWP_NOZORDER;
		}
		return 0;
		
	case WM_DROPFILES:
		{
			if (lock) 
			{
				PostMessage(hwnd, message, wParam, lParam);
				return 0;
			}
			lock = 1;
			{
				int numDropped, i;
				int deskx;
				int desky;
				int s;
				char szFname[256];
				//SHELLEXECUTEINFO si;
				RECT r;
				POINT pt;
				
				GetCursorPos(&pt);
				deskx = (pt.x-mainX) / wndSizeX;
				desky = (pt.y-mainY) / wndSizeY;
				s = (desky * ScreensX) + deskx;
				
				switchToDesktop(s, FALSE);
				
				numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
				for (i = 0; i < numDropped; i++)
				{
					DragQueryFile((HDROP) wParam, i, (char *)&szFname, sizeof(szFname));
					if (szFname && szFname[0])
					{
            LSExecuteEx(NULL, NULL, szFname, NULL, NULL, SW_SHOWNORMAL);
            /*
						memset(&si, 0, sizeof(si));
						si.cbSize = sizeof(SHELLEXECUTEINFO);
						si.lpDirectory = NULL;
						si.lpVerb = NULL;
						si.nShow = 1;
						si.fMask = SEE_MASK_DOENVSUBST;
						si.lpFile = szFname;
						si.lpParameters = NULL;
						ShellExecuteEx(&si);
            */
					}
				}
				DragFinish((HDROP) wParam);
				
				GetClientRect(hwnd,&r);
				createView();
				InvalidateRect(hwnd, &r, FALSE);
				
				lock=0;
			}
		}
		return 0;
		
	case WM_TIMER:
		{ 
			if (lock)
				return 0;
			if (wParam == autoTimer)
			{
				POINT pts;
				GetCursorPos(&pts);
				if (VWMautohide) 
				{
					if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
					{
						if (movingWin == -1)
						{
						  if (FALSE != autoHideFix)
						  {
							RECT rcWin;
							GetWindowRect(hMainWnd, &rcWin);

							if (FALSE != autoHidden && FALSE != rolled)
							{
							  if (0 == mainX)
								rcWin.right = rcWin.left + autoHideDistance;
							  else if (0 == mainY)
								rcWin.bottom = rcWin.top + autoHideDistance;
							  else if (mainX+mainWidth == ScreenWidth)
								rcWin.left = rcWin.right - autoHideDistance;
							  else if (mainY+mainHeight == ScreenHeight)
								rcWin.top = rcWin.bottom - autoHideDistance;
							}

							if (FALSE == PtInRect(&rcWin, pts))
							{
							  if (autoHidden != TRUE)
							  {
								autoHidden = TRUE;
								rolled = TRUE;
								ShowWindow(hMainWnd,SW_HIDE);
							  }
							}
							else
							{
							  if (autoHidden != FALSE)
							  {
								autoHidden = FALSE;
								rolled = FALSE;
								ShowWindow(hMainWnd,SW_SHOWNORMAL);
							  }
							}
						  }
						  else
						  {
							  if ((mainX == 0) && (pts.x <= autoHideDistance) && ((mainY != 0 && mainY + mainHeight != ScreenHeight) || mainWidth < mainHeight)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainY == 0) && (pts.y <= autoHideDistance) && ((mainX != 0 && mainX + mainWidth != ScreenWidth) || mainHeight < mainWidth)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainX+mainWidth == ScreenWidth) && (pts.x >= ScreenWidth-autoHideDistance) && ((mainY != 0 && mainY + mainHeight != ScreenHeight) || mainWidth < mainHeight)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainY+mainHeight == ScreenHeight) && (pts.y >= ScreenHeight-autoHideDistance) && ((mainX != 0 && mainX + mainWidth != ScreenWidth) || mainHeight < mainWidth)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if (((mainX==0 && mainY==0 && (pts.x <= autoHideDistance || pts.y <= autoHideDistance))
										|| (mainX==0 && mainY+mainHeight==ScreenHeight && (pts.x <= autoHideDistance || pts.y >= ScreenHeight-autoHideDistance))
										|| (mainY==0 && mainX+mainWidth==ScreenWidth && (pts.y <= autoHideDistance || pts.x >= ScreenWidth-autoHideDistance))
										|| (mainY+mainHeight==ScreenHeight && mainX+mainWidth==ScreenWidth && (pts.x >= ScreenWidth-autoHideDistance || pts.y >= ScreenHeight-autoHideDistance)))
										&& mainHeight==mainWidth) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) {
								  if (autoHidden != TRUE) {
									  autoHidden = TRUE;
									  rolled = TRUE;
									  ShowWindow(hMainWnd,SW_HIDE);
								  }
							  }
						  }
						}
					}
				}
				return 0;
			}
            if (wParam == mTimer)
            {
				POINTS pts;
				DWORD a = GetMessagePos();
				int nmpos = 0;
				pts = MAKEPOINTS(a);
				
				// horizontal
				if(!bVWMDisableHorizontalAutoSwitch)
                {	
					if ((pts.x) <= autoSwitchDistance) nmpos |= 1;
					if ((pts.x) >= ScreenWidth-autoSwitchDistance) nmpos |= 4;
				}
                
				// vertical
				if(!bVWMDisableVerticalAutoSwitch)
				{
					if ((pts.y) <= autoSwitchDistance) nmpos |= 2;
					if ((pts.y) >= ScreenHeight-autoSwitchDistance) nmpos |= 8;
				}

				if (!nmpos) return 0;
                else
                {
					if (nmpos == 1)
					{
						RECT r;
							//if (((currentScreen % ScreensX) > 0 ) && !lock)
							//{
							//switchToDesktop(currentScreen-1, TRUE);
							// Chao-Kuo Lin
							BangLeft(NULL, "");
							//end

							SetCursorPos(ScreenWidth-(autoSwitchDistance+1), pts.y);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
							//}
					}
					if (nmpos == 2)
					{
						RECT r;
						//if ((currentScreen > (ScreensX - 1)) && !lock)
						//{
							//switchToDesktop(currentScreen - ScreensX, TRUE);
							//Chao-Kuo Lin	
							BangUp(NULL, "");
							//end
							SetCursorPos(pts.x, ScreenHeight-(autoSwitchDistance+1));
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						//}
					}
					if (nmpos == 4)
					{
						RECT r;
						//if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
						//{
							//switchToDesktop(currentScreen+1, TRUE);
							//Chao-Kuo Lin
							BangRight(NULL, ""); 
							//end
							SetCursorPos(autoSwitchDistance+1, pts.y);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						//}
					}
					if (nmpos == 8)
					{
						RECT r;
						//if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
						//{
						//	switchToDesktop(currentScreen+ ScreensX, TRUE);
							//Chao-Kuo Lin
							BangDown(NULL, "");
							//end
							SetCursorPos(pts.x, autoSwitchDistance+1);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						//}
					}
                }
                KillTimer(hMainWnd, mTimer);
                return 0;
            }
            else if (wParam == mcTimer)
            {
                POINTS pts;
                DWORD a = GetMessagePos();
                int nmpos = 0;
                pts = MAKEPOINTS(a);
				
				// horizontal
				if(!bVWMDisableHorizontalAutoSwitch)
                {	
					if ((pts.x) <= autoSwitchDistance) nmpos |= 1;
					if ((pts.x) >= ScreenWidth-autoSwitchDistance) nmpos |= 4;
				}
                
				// vertical
				if(!bVWMDisableVerticalAutoSwitch)
				{
					if ((pts.y) <= autoSwitchDistance) nmpos |= 2;
					if ((pts.y) >= ScreenHeight-autoSwitchDistance) nmpos |= 8;
				}

                if (!nmpos)
                {
                    if (mpos)
                    {
                        KillTimer(hMainWnd, mTimer);
                        mpos = 0;
                    }
                }
                else
                {
                    if (!mpos)
                    {
                        mpos = nmpos;
                        SetTimer(hMainWnd, mTimer, mTimeout, NULL);
                    }
                }
                return 0;
            }
				
			lock = 1;
				
			if (!wParam)
			{
				RECT r;
				GetClientRect(hwnd,&r);
				createView();
				InvalidateRect(hwnd, &r, FALSE);
			}
			else
			{
				int style=0;
				int a=0;
				RECT r;
				HWND newFGWin = GetForegroundWindow();
				
				if (newFGWin)
				{
					style = GetWindowLong(newFGWin, GWL_STYLE);
					a = GetWindowLong(newFGWin, GWL_USERDATA);
				}
				
				if (newFGWin != lastActive)
				{
					if (newFGWin)
					{
						GetWindowRect(newFGWin, &r);
						if (!outsideAnyScreen(r) && 
							!(a == magicDWord || !newFGWin || (newFGWin && IsIconic(newFGWin)) || 
							!((style & WS_VISIBLE)) || (style & WS_DISABLED) || 
							(lastActive && IsWindow(lastActive) && IsIconic(lastActive)) ||
							(lastActive && !IsWindow(lastActive))
							|| (lastActive && GetWindowLong(lastActive, GWL_USERDATA) == magicDWord))
							)
						{
							int newScr = getDesktop(newFGWin);
							if ((newScr != currentScreen) && !NeverSwitch) switchToDesktop(newScr, FALSE);
						}
					}
					lastActive = newFGWin;
				}
			}
		}
			lock = 0;
			return 0;
			
	}
	
	

	return DefWindowProc(hwnd,message,wParam,lParam);
}

void MakeBuffer(HWND hWnd)
// commented out parts are for drawing a duplicate of the entire desktop into the 
// background of the vwm, but since it is not possible to get the bitmaps for the
// non-current desktops (since they don't actually exist) then there is no way to
// have an updated image of each virtual desktop
{
	char szTemp[4096];
	char token1[4096], *token[1];



	RECT r;
	//POINT p;
	HBITMAP fileBitmap = NULL;
	HDC hdc = GetDC(GetDesktopWindow());

	GetClientRect(hWnd,&r);
	//p.x = r.left-mainX;
	//p.y = r.top-mainY;
	token[0] = token1;
	
	GetRCString("VWMBackBmp", szTemp, ".none", 4096);
	LCTokenize(szTemp, token, 1, NULL);

	if (!stricmp(token1, ".snapshot")) 
	{
		snapshot = TRUE;
	}
	else 
	{
		snapshot = FALSE;
		fileBitmap = LoadLSImage(token1, NULL);
		if (fileBitmap) GetBMPSize(fileBitmap, &backX, &backY);
	}


	bgDC = CreateCompatibleDC(memDC);
	bBGBitmap = CreateCompatibleBitmap(hdc, mainWidth, mainHeight);
	//bBGBitmap = CreateCompatibleBitmap(hdc, ScreenWidth*3, ScreenHeight);
	GetBMPSize(bBGBitmap, &backX, &backY);
	oldBG = (HBITMAP)SelectObject(bgDC, bBGBitmap);
	
	if (!fileBitmap)
	{
		HBRUSH oldBrush, hBlueBrush = CreateSolidBrush(backColor);
		HPEN oldpen, pen = CreatePen(PS_SOLID, 1, borderColor);
		
		background = TRUE;
		
		oldBrush = SelectObject(bgDC, hBlueBrush);
		oldpen = SelectObject(bgDC, pen);
		Rectangle(bgDC, 0, 0, mainWidth, mainHeight);
		
		SelectObject(bgDC, oldpen);
		SelectObject(bgDC, oldBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(pen);
		
		if (snapshot) 
		{
			//int x, y;
			/*for (y = 0; y < ScreensY; y ++) for (x = 0; x < ScreensX; x ++)
			{
				int desk = (y * ScreensX) + x;
				int top = y * (ScreenHeight);
				int left = x * (ScreenWidth);
		
				StretchBlt(bgDC, deskRect[desk].left / ratioX, deskRect[desk].top / ratioY, deskRect[desk].right / ratioX, deskRect[desk].bottom / ratioY, hdc, 0, 0, ScreenWidth*3, ScreenHeight, SRCCOPY);*/
			if(!dockedOnWharf)
				BitBlt(bgDC, 0, 0, mainWidth, mainHeight, hdc, mainX, mainY, SRCCOPY);
			else
				BitBlt(bgDC, 0, 0, mainWidth, mainHeight, hdc, wharfRect.left+mainX, wharfRect.top+mainY, SRCCOPY);

			//}
		}
	} 
	else 
	{
		int cx, cy;
		HDC tempDC = CreateCompatibleDC(bgDC);
		HBITMAP oldBitmap;
		
		oldBitmap = (HBITMAP)SelectObject(tempDC, fileBitmap);
			
		GetBMPSize(fileBitmap, &cx, &cy);

		StretchBlt(bgDC, 0, 0, backX, backY, tempDC, 0, 0, cx, cy, SRCCOPY);
		
		SelectObject(tempDC, oldBitmap);
		DeleteDC(tempDC);
		DeleteObject(fileBitmap);
	}
	
	ReleaseDC(hWnd, hdc);


}

void getShifts(int old, int desk, int *addH, int *addV)
{
	int oldDeskX, oldDeskY;
	int deskX, deskY;
	int shiftX, shiftY;
	
	if(old == desk)
	{
		*addH = *addV = 0;
		return;
	}

	oldDeskX = old % ScreensX;
	oldDeskY = old / ScreensX;
	
	deskX = desk % ScreensX;
	deskY = desk / ScreensX;
	
	shiftX = deskX - oldDeskX;
	shiftY = deskY - oldDeskY;
	
	*addH = shiftX * (ScreenWidth + 10);
	*addV = shiftY * (ScreenHeight + 10);
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (!refToplevel && 
		!(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST) &&
		!( (GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) && (GetDesktopWindow() != GetParent(hwnd)) )
		)
	{
		refToplevel = hwnd;
		return FALSE;
	}
	return TRUE;
}

BOOL CALLBACK EudoraEnumChildProc(HWND hwnd, LPARAM lParam)
{
	HWND owner = GetWindow(hwnd, GW_OWNER);
	
	if (owner != eudora) return TRUE;
	{
		int style = GetWindowLong(hwnd, GWL_STYLE);
		
		if (style & WS_VISIBLE && style & WS_POPUP)
		{
			char txt[25];
			GetWindowText(hwnd, txt, 23);
			if (!strcmp(txt, "Progress") || !strcmp(txt, "No New Mail") || !strcmp(txt, "New Mail!") || !strcmp(txt, "Eudora Network Timeout"))
			{
				RECT r;
				RECT r2;
				RECT r3;
				GetWindowRect(eudora, &r);
				GetWindowRect(hwnd, &r2);
				r3.left = ((r.right-r.left-(r2.right-r2.left)) / 2) + r.left;
				r3.top = ((r.bottom-r.top-(r2.bottom-r2.top)) / 2) + r.top;
				r3.right = r3.left + (r2.right-r2.left);
				r3.bottom = r3.top + (r2.bottom-r2.top);
				MoveWindow(hwnd, r3.left, r3.top, r3.right-r3.left, r3.bottom-r3.top, TRUE);
			}
		}
	}
	
	return TRUE;
}

void createView(void)
{
	int xoff, yoff;
	HWND prev;
	RECT r;
	int H=0, V=0;
	static int oldnRects=0;
	int nRects=0;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		hWinBrush,
		oldBrush,
		hTitlebar;
	HPEN pen,oldpen;
	HPEN hiPen, shadPen, winPen;
	winDataType *ptr;
	static HWND winHandle[WIN_HIDE_COUNT+WIN_RECT_COUNT];
	int nwinHandle = 0, i;
	BOOL skipWin = FALSE;
	int WindowHeight;
	int WindowWidth;
	int WndDesk;
	
	//Get it constantly in case it changes
	SystemParametersInfo(SPI_GETWORKAREA,0,&workingArea,0);

	if (movingWin > -1) return;

	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	hWinBrush = CreateSolidBrush(winColor);
	hTitlebar = CreateSolidBrush(borderColor);
	hiPen = CreatePen(PS_SOLID, 1, foreColor);
	shadPen = CreatePen(PS_SOLID, 1, borderColor);
	winPen = CreatePen(PS_SOLID, 1, winColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);
	
    /*
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
	*/
    
    SelectObject(bgDC, bBGBitmap);
    StretchBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, backX, backY, SRCCOPY);

	if (background && !NoBorder) 
	{
		for (xoff=1; xoff < ScreensX; xoff++)
		{
			MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
			LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
		}
		for (yoff=1; yoff < ScreensY; yoff++)
		{
			MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
			LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
		}
	}
		
	r.left = nOffsetX+wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+wndSizeY*(currentScreen / ScreensX);
	
	if (!sBGBitmap) 
	{
		SelectObject(memDC, hGreyBrush);
		ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
	} 
	else 
	{
		SelectObject(bgDC, sBGBitmap);
		StretchBlt(memDC, r.left, r.top, wndSizeX, wndSizeY, bgDC, 0, 0, selX, selY, SRCCOPY);
	}
		
    if(!NoWindows)
    {
	    getShifts(0, currentScreen, &H, &V);
	    
	    refToplevel = NULL;
	    nWinRect=0;
	    EnumWindows(EnumWindowsProc, 0);
	    
	    prev = GetWindow(refToplevel, GW_HWNDLAST);

	    while(true)
	    {
		    if (prev == NULL) break;
		    
		    //////////////////////////////////
		    // Chao-Kuo Lin
		    // add something here
		    
		    // does not proccess if (not visible && not in hide list) || it's magic
		    //if ( !(GetWindowLong(winData.hwnd, GWL_STYLE) & WS_VISIBLE) && !IsInHideList(winData.hwnd))
		    if(	(IsWindowVisible(prev) || IsInHideList(prev)) && 
			    (GetWindowLong(prev, GWL_USERDATA) != magicDWord) )
			    /*
			    !((!IsWindowVisible(prev) && !IsInHideList(prev)) || 
			    (GetWindowLong(prev, GWL_USERDATA) == magicDWord))
			    )			
			    */
		    {
			    if (	/*!((GetWindowLong(prev, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) && 
					    GetParent(prev) != NULL && 
					    GetParent(prev) != GetDesktopWindow())*/
					    !(GetWindowLong(prev, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) ||
					    GetParent(prev) == NULL ||
					    GetParent(prev) == GetDesktopWindow()
				    )
			    {			
				    if(nwinHandle < (WIN_HIDE_COUNT+WIN_RECT_COUNT))
					    winHandle[nwinHandle++] = prev;
			    }
		    }

		    prev = GetNextWindow(prev, GW_HWNDPREV);
	    }
	    
	    for(i = 0; i < nwinHandle; i++)
	    {
		    skipWin = FALSE;

		    ptr = FindInList(winHandle[i]);
		    if(!ptr) ptr = &(winRect[nWinRect]);
		    if(!ptr) continue;

		    /////////////////////////////
		    // Chao-Kuo Lin
		    // probably fix something here?
		    ptr->hwnd = winHandle[i];
		    ptr->valid = 1;
		    nRects+=(int)ptr->hwnd;

		    //if the desktop this window is in is not 0
		    //then we need to adjust it's position
		    //so it'll render in minipanel right
		    WndDesk = getDesktop(ptr->hwnd);
		    GetWindowRect(ptr->hwnd, &(ptr->r));
		    /*
		    if(WndDesk != 0)
		    {//let's adjust
			    int adjustX, adjustY;
			    //make it seems it's multiple of 10 xtra pixels high
			    adjustX = (WndDesk % ScreensX) * 10; 
			    adjustY = (WndDesk / ScreensX) * 10;

			    ptr->r.left -= adjustX;
			    ptr->r.right -= adjustX;
			    ptr->r.top -= adjustY;
			    ptr->r.bottom -= adjustY;
		    }
		    */
		    
		    WindowHeight = ((ptr->r.bottom - ptr->r.top) / ratioY);
		    WindowWidth = ((ptr->r.right - ptr->r.left) / ratioX);
		    
		    {
			    char txt[25];
			    GetWindowText(ptr->hwnd, txt, 23);
			    if (!strcmp(txt, "Explorer")) skipWin = TRUE;
		    }
		    
		    if (!skipWin) 
		    {
			    //set drawing rectangle
			    int normx, normy;
						    
			    r = ptr->r;
			    NormalizeCoordinate(&r, &normx, &normy);
			    r.left = nOffsetX + (normx*wndSizeX) + r.left / ratioX;
			    r.top = nOffsetY + (normy*wndSizeY) + r.top / ratioY;
			    r.right = r.left + WindowWidth;
			    r.bottom = r.top + WindowHeight;
			    
			    if ((!titlebars) || (WindowHeight <= TitlebarHeight))
			    {
				    if (wBGBitmap) 
				    {
					    SelectObject(bgDC, wBGBitmap);
					    StretchBlt(memDC, r.left, r.top, WindowWidth, WindowHeight, bgDC, 0, 0, winX, winY, SRCCOPY);
				    } 
				    else 
				    {
					    if (bevel) 
					    {
						    //move to bottom left corner of outer
						    MoveToEx(memDC, r.left, r.bottom, NULL);
						    
						    //draw outer shadow
						    SelectObject(memDC, shadPen);
						    LineTo(memDC, r.left, r.top);
						    LineTo(memDC, r.right, r.top);
						    
						    //draw outer highlight
						    SelectObject(memDC, hiPen);						
						    LineTo(memDC, r.right, r.bottom);
						    LineTo(memDC, r.left-1, r.bottom);
						    
						    //move to top right corner of inner
						    MoveToEx(memDC, r.right-1, r.top+1, NULL);
						    
						    //draw inner shadow
						    SelectObject(memDC, shadPen);
						    LineTo(memDC, r.right-1, r.bottom-1);
						    LineTo(memDC, r.left+1, r.bottom-1);
						    
						    //draw inner highlight
						    SelectObject(memDC, hiPen);
						    LineTo(memDC, r.left+1, r.top+1);
						    LineTo(memDC, r.right-1, r.top+1);
						    
						    //draw inside rectangle
						    SelectObject(memDC, hWinBrush);
						    SelectObject(memDC, winPen);
						    Rectangle(memDC, r.left+2, r.top+2, r.right-1, r.bottom-1);
					    } 
					    else 
					    {
						    SelectObject(memDC, hWhiteBrush);
						    Rectangle(memDC, r.left, r.top, r.right, r.bottom);
					    }
				    }
			    } 
			    else 
			    {
				    if (tBGBitmap) 
				    {
					    SelectObject(bgDC, tBGBitmap);
					    StretchBlt(memDC, r.left, r.top, r.right-r.left, TitlebarHeight, bgDC, 0, 0, titleX, titleY, SRCCOPY);
				    } 
				    else 
				    {
					    if (bevel) 
					    {
						    //move to bottom left corner of outer
						    MoveToEx(memDC, r.left, r.top+TitlebarHeight, NULL);
						    
						    //draw outer shadow
						    SelectObject(memDC, shadPen);
						    LineTo(memDC, r.left, r.top);
						    LineTo(memDC, r.right, r.top);
						    
						    //draw outer highlight
						    SelectObject(memDC, hiPen);						
						    LineTo(memDC, r.right, r.top+TitlebarHeight);
						    
						    //skip outer bottom highlight and move to top right of inner to continue drawing
						    MoveToEx(memDC, r.right-1, r.top+1, NULL);
						    
						    //draw inner shadow
						    SelectObject(memDC, shadPen);
						    LineTo(memDC, r.right-1, r.top+TitlebarHeight-1);
						    LineTo(memDC, r.left+1, r.top+TitlebarHeight-1);
						    
						    //draw inner highlight
						    SelectObject(memDC, hiPen);
						    LineTo(memDC, r.left+1, r.top+1);
						    LineTo(memDC, r.right-1, r.top+1);
						    
						    //draw inside rectangle
						    SelectObject(memDC, hWinBrush);
						    SelectObject(memDC, winPen);
						    Rectangle(memDC, r.left+2, r.top+2, r.right-1, (r.top+TitlebarHeight)-1);
					    } 
					    else 
					    {
						    SelectObject(memDC, hTitlebar);
						    Rectangle(memDC, r.left, r.top, r.right, r.top+TitlebarHeight);
					    }
				    }
				    if (wBGBitmap) 
				    {
					    SelectObject(bgDC, wBGBitmap);
					    StretchBlt(memDC, r.left, r.top, r.right-r.left, (r.bottom-r.top)+TitlebarHeight, bgDC, 0, 0, winX, winY, SRCCOPY);
				    } 
				    else 
				    {
					    if (bevel) 
					    {
						    //move to bottom left corner of outer
						    MoveToEx(memDC, r.left, r.bottom, NULL);
						    
						    //draw outer shadow
						    SelectObject(memDC, shadPen);
						    LineTo(memDC, r.left, r.top+TitlebarHeight);
						    
						    //skip top shadow and move to top right to continue drawing
						    MoveToEx(memDC, r.right, r.top+TitlebarHeight, NULL);
						    
						    //draw outer highlight
						    SelectObject(memDC, hiPen);						
						    LineTo(memDC, r.right, r.bottom);
						    LineTo(memDC, r.left-1, r.bottom);
						    
						    //draw inside rectangle
						    SelectObject(memDC, hWinBrush);
						    SelectObject(memDC, winPen);
						    Rectangle(memDC, r.left+1, r.top+TitlebarHeight, r.right, r.bottom);
					    }
					    else 
					    {
						    SelectObject(memDC, hWhiteBrush);
						    Rectangle(memDC, r.left, r.top+TitlebarHeight, r.right, r.bottom);
					    }
				    }
			    }
			    if (useIcons) 
			    {
				    if (!titlebars)
				    {
					    if ((WindowWidth-4 > iconSize) || (WindowHeight-4 > iconSize))
					    {
						    if (iconSize <= 16) ptr->hicon = getIconFromWindow(ptr->hwnd, FALSE);
						    if (iconSize > 16) ptr->hicon = getIconFromWindow(ptr->hwnd, TRUE);
						    DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), r.top+((WindowHeight/2)-(iconSize/2)), ptr->hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
					    }
				    }
				    else 
				    {
					    if ((WindowWidth-4 > iconSize) || ((WindowHeight-TitlebarHeight)-4 > iconSize))
					    {
						    if (iconSize <= 16) ptr->hicon = getIconFromWindow(ptr->hwnd, FALSE);
						    if (iconSize > 16) ptr->hicon = getIconFromWindow(ptr->hwnd, TRUE);
						    DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), (r.top+TitlebarHeight)+((WindowHeight/2)-(iconSize/2)), ptr->hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
					    }
				    }
			    }

		    
			    if(!ProcessWinData(ptr))
			    {
				    if(nWinRect < WIN_RECT_COUNT)
					    memcpy(&(winRect[nWinRect++]), ptr, sizeof(winDataType));
			    }

			    // this is redundant code, but ..hmm
			    //ptr->hwnd = prev;
			    //ptr->valid = 1;

			    //((GetWindowLong(ptr->hwnd, GWL_STYLE) & WS_VISIBLE) && IsRectOnScreen(&(ptr->r))
    /*
			    if(IsRectOnScreen(&(ptr->r)) || IsIconic(ptr->hwnd)) // we dont want iconic in our list
			    {
				    if(IsInHideList(ptr->hwnd))
				    {
					    #ifdef VWM_DEBUG_OUTPUT
						    //debug
						    char winname[0xFF+1];
						    GetWindowText(ptr->hwnd, winname, 0xFF);
						    fputs("Remove Window: ", debug_output);
						    fputs(winname, debug_output);
						    fputs(" from list(createView)\n", debug_output);
					    #endif

					    ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
					    memcpy(&(winRect[nWinRect]), ptr, sizeof(winDataType));
					    ptr->valid = 3;
					    
				    }
				    nWinRect++;
			    }
			    else if( !IsInHideList(ptr->hwnd) )
			    {//it's not in the current list, add it
			     //make sure it won't appearn
				    #ifdef VWM_DEBUG_OUTPUT
					    //debug
					    char winname[0xFF+1];
					    GetWindowText(ptr->hwnd, winname, 0xFF);
					    fputs("Added Window: ", debug_output);
					    fputs(winname, debug_output);
					    fputs(" to list(createView)\n", debug_output);
				    #endif	

				    ShowWindow(ptr->hwnd, SW_HIDE);
				    memcpy(&(winHideRect[nHideRect]), ptr, sizeof(winDataType));
				    ++nHideRect;
			    }
    */
		    }
	    }
    }//!NoWindows	
		
	memset(&(winHideRect[nHideRect]), 0, sizeof(winDataType));
	memset(&(winRect[nWinRect]), 0, sizeof(winDataType));
		
	RemoveWinFromList();
	RegenerateHideList();

	if (nRects != oldnRects) 
	{
		// dont know if the modification is ok
		//if (! (GetWindowLong(winswitch, GWL_STYLE) & WS_VISIBLE)) 
		if(!IsWindowVisible(winswitch))
		{
			HWND last = GetWindow(desk, GW_HWNDLAST);
			while(last && last != desk) 
			{
				//if ( (GetWindowLong(last, GWL_STYLE) & WS_VISIBLE) || IsInHideList(last)) 
				if ( IsWindowVisible(last) || IsInHideList(last)) 
				{
					SetWindowPos(last, GetWindow(desk, GW_HWNDPREV), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
					last = GetWindow(desk, GW_HWNDLAST);
					continue;
				}
				last = GetWindow(last, GW_HWNDPREV);
			}
		}
		oldnRects = nRects;
		eudora = FindWindow("EudoraMainWindow", NULL);
		if (eudora)
			EnumWindows(EudoraEnumChildProc, 0);
	}
	
	////////////////////////////////////////
	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(hWinBrush);
	DeleteObject(hTitlebar);
	DeleteObject(pen);
	DeleteObject(hiPen);
	DeleteObject(shadPen);
	DeleteObject(winPen);


}

void createRecordedView(void)
{
	RECT r;
	int H=0, V=0;
	int i, j, xoff, yoff;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		hWinBrush,
		hTitlebar,
		oldBrush;
	HPEN pen,oldpen;
	HPEN hiPen, shadPen, winPen;
	BOOL skipWin = FALSE;
	winDataType *ptr;
	int WindowHeight;
	int WindowWidth;
	int WndDesk;
	
	hBlueBrush = CreateSolidBrush(backColor);
	hWinBrush = CreateSolidBrush(winColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	hTitlebar = CreateSolidBrush(borderColor);
	
	hiPen = CreatePen(PS_SOLID, 1, foreColor);
	shadPen = CreatePen(PS_SOLID, 1, borderColor);
	winPen = CreatePen(PS_SOLID, 1, winColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);

    SelectObject(bgDC, bBGBitmap);
    StretchBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, backX, backY, SRCCOPY);

    /*
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
	*/
    
	if (background && !NoBorder) 
	{
		for (xoff=1; xoff < ScreensX; xoff++)
		{
			MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
			LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
		}
		for (yoff=1; yoff < ScreensY; yoff++)
		{
			MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
			LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
		}
	}
	
	r.left = nOffsetX+ wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+ wndSizeY*(currentScreen / ScreensX);
	
	if (!sBGBitmap) 
	{
		SelectObject(memDC, hGreyBrush);
		ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
	} 
	else 
	{
		SelectObject(bgDC, sBGBitmap);
		StretchBlt(memDC, r.left, r.top, wndSizeX, wndSizeY, bgDC, 0, 0, selX, selY, SRCCOPY);
	}
	
	SelectObject(memDC, hWhiteBrush);
	
    if(!NoWindows)
    {
	    getShifts(0, currentScreen, &H, &V);
	    
	    for(j =0, ptr=winRect; j<2 ;ptr=winHideRect, j++)
	    {

		    for (i=0;ptr[i].valid && ( (ptr == winHideRect) ? (bHideTaskOnSwitch && i<nHideRect) : i<nWinRect) ;i++)
		    {
			    
			    WndDesk = getDesktop(ptr[i].hwnd);			
			    GetWindowRect(ptr[i].hwnd, &(ptr[i].r));
			    
			    /*
			    if(WndDesk != 0)
			    {
				    //let's adjust
				    int adjustX, adjustY;
				    //make it seems it's multiple of 10 xtra pixels high
				    adjustX = (WndDesk % ScreensX) * 10; 
				    adjustY = (WndDesk / ScreensX) * 10;

				    ptr[i].r.left -= adjustX;
				    ptr[i].r.right -= adjustX;
				    ptr[i].r.top -= adjustY;
				    ptr[i].r.bottom -= adjustY;
			    }
			    */


			    WindowHeight = ((ptr[i].r.bottom - ptr[i].r.top) / ratioY);
			    WindowWidth = ((ptr[i].r.right - ptr[i].r.left) / ratioX);
			    
			    {
				    char txt[25];
				    GetWindowText(ptr[i].hwnd, txt, 23);
				    if (!strcmp(txt, "Explorer"))
				    {
					    skipWin = TRUE;
				    }
			    }
			    
			    if (!skipWin) 
			    {
				    //set drawing rectangle
				    int normx, normy;
						    
				    r = ptr[i].r;
				    NormalizeCoordinate(&r, &normx, &normy);
				    r.left = nOffsetX + (normx*wndSizeX) + r.left / ratioX;
				    r.top = nOffsetY + (normy*wndSizeY) + r.top / ratioY;
				    r.right = r.left + WindowWidth;
				    r.bottom = r.top + WindowHeight;

    //				r.left = (ptr[i].r.left + H - (WndDesk % ScreensX) * 10) / ratioX;
    //				r.top = (ptr[i].r.top + V - (WndDesk / ScreensX) * 10) / ratioY;
    //				r.right = r.left+WindowWidth;//(ptr[i].r.right + H) / ratioX;
    //				r.bottom = r.top+WindowHeight;//(ptr[i].r.bottom + V) / ratioY;
				    
				    if ((!titlebars) || (WindowHeight <= TitlebarHeight))
				    {
					    if (wBGBitmap) 
					    {
						    SelectObject(bgDC, wBGBitmap);
						    StretchBlt(memDC, r.left, r.top, r.right-r.left, r.bottom-r.top, bgDC, 0, 0, winX, winY, SRCCOPY);
					    } 
					    else 
					    {
						    if (bevel) 
						    {
							    //move to bottom left corner of outer
							    MoveToEx(memDC, r.left, r.bottom, NULL);
							    
							    //draw outer shadow
							    SelectObject(memDC, shadPen);
							    LineTo(memDC, r.left, r.top);
							    LineTo(memDC, r.right, r.top);
							    
							    //draw outer highlight
							    SelectObject(memDC, hiPen);						
							    LineTo(memDC, r.right, r.bottom);
							    LineTo(memDC, r.left-1, r.bottom);
							    
							    //move to top right corner of inner
							    MoveToEx(memDC, r.right-1, r.top+1, NULL);
							    
							    //draw inner shadow
							    SelectObject(memDC, shadPen);
							    LineTo(memDC, r.right-1, r.bottom-1);
							    LineTo(memDC, r.left+1, r.bottom-1);
							    
							    //draw inner highlight
							    SelectObject(memDC, hiPen);
							    LineTo(memDC, r.left+1, r.top+1);
							    LineTo(memDC, r.right-1, r.top+1);
							    
							    //draw inside rectangle
							    SelectObject(memDC, hWinBrush);
							    SelectObject(memDC, winPen);
							    Rectangle(memDC, r.left+2, r.top+2, r.right-1, r.bottom-1);
						    } 
						    else 
						    {
							    SelectObject(memDC, hWhiteBrush);
							    Rectangle(memDC, r.left, r.top, r.right, r.bottom);
						    }
					    }
				    } 
				    else 
				    {
					    if (tBGBitmap) 
					    {
						    SelectObject(bgDC, tBGBitmap);
						    StretchBlt(memDC, r.left, r.top, r.right-r.left, TitlebarHeight, bgDC, 0, 0, titleX, titleY, SRCCOPY);
					    } 
					    else 
					    {
						    if (bevel) 
						    {
							    //move to bottom left corner of outer
							    MoveToEx(memDC, r.left, r.top+TitlebarHeight, NULL);
							    
							    //draw outer shadow
							    SelectObject(memDC, shadPen);
							    LineTo(memDC, r.left, r.top);
							    LineTo(memDC, r.right, r.top);
							    
							    //draw outer highlight
							    SelectObject(memDC, hiPen);						
							    LineTo(memDC, r.right, r.top+TitlebarHeight);
							    
							    //skip outer bottom highlight and move to top right of inner to continue drawing
							    MoveToEx(memDC, r.right-1, r.top+1, NULL);
							    
							    //draw inner shadow
							    SelectObject(memDC, shadPen);
							    LineTo(memDC, r.right-1, r.top+TitlebarHeight-1);
							    LineTo(memDC, r.left+1, r.top+TitlebarHeight-1);
							    
							    //draw inner highlight
							    SelectObject(memDC, hiPen);
							    LineTo(memDC, r.left+1, r.top+1);
							    LineTo(memDC, r.right-1, r.top+1);
							    
							    //draw inside rectangle
							    SelectObject(memDC, hWinBrush);
							    SelectObject(memDC, winPen);
							    Rectangle(memDC, r.left+2, r.top+2, r.right-1, (r.top+TitlebarHeight)-1);
						    } 
						    else 
						    {
							    SelectObject(memDC, hTitlebar);
							    Rectangle(memDC, r.left, r.top, r.right, r.top+TitlebarHeight);
						    }
					    }
					    if (wBGBitmap) 
					    {
						    SelectObject(bgDC, wBGBitmap);
						    StretchBlt(memDC, r.left, r.top, r.right-r.left, (r.bottom-r.top)+TitlebarHeight, bgDC, 0, 0, winX, winY, SRCCOPY);
					    } 
					    else 
					    {
						    if (bevel) 
						    {
							    //move to bottom left corner of outer
							    MoveToEx(memDC, r.left, r.bottom, NULL);
							    
							    //draw outer shadow
							    SelectObject(memDC, shadPen);
							    LineTo(memDC, r.left, r.top+TitlebarHeight);
							    
							    //skip top shadow and move to top right to continue drawing
							    MoveToEx(memDC, r.right, r.top+TitlebarHeight, NULL);
							    
							    //draw outer highlight
							    SelectObject(memDC, hiPen);						
							    LineTo(memDC, r.right, r.bottom);
							    LineTo(memDC, r.left-1, r.bottom);
							    
							    //draw inside rectangle
							    SelectObject(memDC, hWinBrush);
							    SelectObject(memDC, winPen);
							    Rectangle(memDC, r.left+1, r.top+TitlebarHeight, r.right, r.bottom);
						    }
						    else 
						    {
							    SelectObject(memDC, hWhiteBrush);
							    Rectangle(memDC, r.left, r.top+TitlebarHeight, r.right, r.bottom);
						    }
					    }
				    }
				    if (useIcons) 
				    {
					    if (!titlebars)
					    {
						    if ((WindowWidth-4 > iconSize) || (WindowHeight-4 > iconSize))
						    {
							    if (iconSize <= 16) ptr[i].hicon = getIconFromWindow(ptr[i].hwnd, FALSE);
							    if (iconSize > 16) ptr[i].hicon = getIconFromWindow(ptr[i].hwnd, TRUE);
							    DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), r.top+((WindowHeight/2)-(iconSize/2)), ptr[i].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						    }
					    } 
					    else 
					    {
						    if ((WindowWidth-4 > iconSize) || ((WindowHeight-TitlebarHeight)-4 > iconSize))
						    {
							    if (iconSize <= 16) ptr[i].hicon = getIconFromWindow(ptr[i].hwnd, FALSE);
							    if (iconSize > 16) ptr[i].hicon = getIconFromWindow(ptr[i].hwnd, TRUE);
							    DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), (r.top+TitlebarHeight)+((WindowHeight/2)-(iconSize/2)), ptr[i].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						    }
					    }
				    }
			    }
		    }
	    }
    }

	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(hTitlebar);
	DeleteObject(hWinBrush);
	DeleteObject(pen);
	DeleteObject(hiPen);
	DeleteObject(shadPen);
	DeleteObject(winPen);
}

/*
void DrawBackGround(HDC hdcbg)
{
	int xoff, yoff;
	HWND prev;
	RECT r;
	int H=0, V=0;
	static int oldnRects=0;
	int nRects=0;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		hWinBrush,
		oldBrush,
		hTitlebar;
	HPEN pen,oldpen;
	HPEN hiPen, shadPen, winPen;
	winDataType *ptr;
	static HWND winHandle[WIN_HIDE_COUNT+WIN_RECT_COUNT];
	int nwinHandle = 0, i;
	BOOL skipWin = FALSE;
	int WindowHeight;
	int WindowWidth;
	int WndDesk;
	
	//Get it constantly in case it changes
	SystemParametersInfo(SPI_GETWORKAREA,0,&workingArea,0);

	if (movingWin > -1) return;

	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	hWinBrush = CreateSolidBrush(winColor);
	hTitlebar = CreateSolidBrush(borderColor);
	hiPen = CreatePen(PS_SOLID, 1, foreColor);
	shadPen = CreatePen(PS_SOLID, 1, borderColor);
	winPen = CreatePen(PS_SOLID, 1, winColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(hdcbg, hBlueBrush);
	oldpen = SelectObject(hdcbg, pen);
	
    StretchBlt(hdcbg, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, backX, backY, SRCCOPY);

	if (background) 
	{
		for (xoff=1; xoff < ScreensX; xoff++)
		{
			MoveToEx(hdcbg, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
			LineTo(hdcbg, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
		}
		for (yoff=1; yoff < ScreensY; yoff++)
		{
			MoveToEx(hdcbg, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
			LineTo(hdcbg, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
		}
	}
		
	r.left = nOffsetX+wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+wndSizeY*(currentScreen / ScreensX);
	
	if (!sBGBitmap) 
	{
		SelectObject(hdcbg, hGreyBrush);
		ImageList_DrawEx(hBGList, currentScreen, hdcbg, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
	} 
	else 
	{
		SelectObject(bgDC, sBGBitmap);
		StretchBlt(hdcbg, r.left, r.top, wndSizeX, wndSizeY, bgDC, 0, 0, selX, selY, SRCCOPY);
	}

}
*/


/*
BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam)
{
	RECT r;
	winToolType **toolptr = (winToolType **)lParam;

	int style = GetWindowLong(hwnd, GWL_STYLE);
	

	if ((style & WS_VISIBLE) && ((style & WS_POPUP) || (style & WS_OVERLAPPED)) 
		)
	{
		(**toolptr).hwnd = hwnd;

		//getwindowrect is the screen relative position not parent relative
		GetWindowRect(GetParent(hwnd), &r);
		GetWindowRect(hwnd, &((**toolptr).r));

		(**toolptr).r.left -= r.left;
		(**toolptr).r.right -= r.left;
		(**toolptr).r.top -= r.top;
		(**toolptr).r.bottom -= r.top;
		(*toolptr)++;
	}

	return TRUE;
}
*/

BOOL CALLBACK FixEnumChildProc(HWND hwnd, LPARAM lParam)
{
	int style = GetWindowLong(hwnd, GWL_STYLE);
	
	if ((style & WS_VISIBLE) && ((style & WS_POPUP) || (style & WS_OVERLAPPED)) )
	{
		if (!inFix(hwnd))
		{
			addWinFix(hwnd, getDesktop(hwnd));
			if(Fix(hwnd))
				EnumChildWindows(hwnd, FixEnumChildProc, 0);
		}
	}
	return TRUE;
}

void switchToDesktop(int _desk, BOOL fixFocus)
{
	// the shown window, so WIN_HIDE_COUNT should be higher
	static HWND winHandle[WIN_HIDE_COUNT+WIN_RECT_COUNT];
	//static winToolType toolList[WIN_TOOL_COUNT];
	HWND LastFocusHWND = NULL;
	//winToolType *toolListptr;
	int nwinHandle = 0, /*nwinTool =0,*/ i;


	#ifdef VWM_DEBUG_OUTPUT
	//debug
		char buffer[0xFF+1];
	#endif

	winDataType winData;
	HDWP dwp;

	int addH=0, addV=0;

	winData.valid = 1;

	if (movingWin > -1) 
	{
		#ifdef VWM_DEBUG_OUTPUT
		//debug
		fputs("Cannot switch desktop cause movingWin > -1\n", debug_output);
		#endif
		return;
	}
	
	lock = 1;	

	#ifdef VWM_DEBUG_OUTPUT
	//debug
		wsprintf(buffer, "Switching from Desktop %d to %d", currentScreen, _desk);
		fputs(buffer, debug_output);
	#endif

	//we add the the last active window in this desktop
	//LastFocus[currentScreen] = GetForegroundWindow();
	if(FocusLast)
	{
		LastFocusHWND = GetForegroundWindow();
		LastFocusHWND = GetWindow(LastFocusHWND, GW_HWNDFIRST);

		while
		( 		LastFocusHWND != NULL && 
				(GetWindowLong(LastFocusHWND, GWL_USERDATA) == magicDWord) || 
				!IsWindowVisible(LastFocusHWND) || 
				((GetWindowLong(LastFocusHWND, GWL_EXSTYLE) & WS_EX_TOPMOST) && GetParent(LastFocusHWND) != GetDesktopWindow())
		)
		{
			LastFocusHWND =  GetNextWindow(LastFocusHWND, GW_HWNDNEXT);
			if(LastFocusHWND == NULL) break;
		}

		LastFocus[currentScreen] = LastFocusHWND;
	}

	getShifts(currentScreen, _desk, &addH, &addV);

	//photoshop = FindWindow("Photoshop", NULL);
	//if (photoshop) EnumChildWindows(photoshop, FixEnumChildProc, 0);

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);
	
	winData.hwnd = GetWindow(refToplevel, GW_HWNDLAST);
	
	DoEvents(2);
	
	dwp = BeginDeferWindowPos(nWinRect+nHideRect+16);
	
	//reset the shown list
	currentShow = 0;
	
	while(true)
	{
		#ifdef VWM_DEBUG_OUTPUT
		char buffer[0xFF+1];
		#endif
		
		if (winData.hwnd == NULL) break;
		
		//if (!(GetWindowLong(winData.hwnd, GWL_STYLE) & WS_VISIBLE) && !(IsInHideList(winData.hwnd)) )	continue;
		
		//we don't want invisible windows, but we want those that are in our list
		if(
			/*
			!((!IsWindowVisible(winData.hwnd) && !(IsInHideList(winData.hwnd))) ||
			//we don't mess with the magic!
			(GetWindowLong(winData.hwnd, GWL_USERDATA) == magicDWord)
			)
			*/
			(IsWindowVisible(winData.hwnd) || IsInHideList(winData.hwnd)) &&
			(GetWindowLong(winData.hwnd, GWL_USERDATA) != magicDWord)
		   )
		{
			#ifdef VWM_DEBUG_OUTPUT
			GetWindowText(winData.hwnd, buffer, 0xFF);
			fputs("Encountering window: ", debug_output);
			fputs(buffer, debug_output);
			fputs("\n", debug_output);
			#endif

			//Bug to Fix
			//has to fix the problem that when Sticky is already in other desktop
			//it'll move strangely
			if (Sticky(winData.hwnd) == TRUE) 
			{
				int stickyDesk = getDesktop(winData.hwnd);

				if( stickyDesk != currentScreen)
				{
					int H, V;
					RECT r;
					getShifts(stickyDesk, currentScreen, &H, &V);
					GetWindowRect(winData.hwnd, &r);
					SetWindowPos(winData.hwnd, NULL, 
								r.left+H, r.top+V, 0, 0, 
								SWP_NOACTIVATE|SWP_NOSIZE|SWP_NOZORDER);

				}

				if(inFix(winData.hwnd))
					removeWinFix(winData.hwnd);
			}
			else
			{
				if (	/*
						(GetWindowLong(winData.hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
						&& ( GetParent(winData.hwnd) != NULL && GetParent(winData.hwnd) != GetDesktopWindow())
						||
						*/
						Fix(GetParent(winData.hwnd)) )
				{	//let's save the handle, and it's relative position to its parent window
					//then after moving all the window, we move all these window to the position we saved
					//change it's valid type to 4 to signify it's a tool window
/*
					if(nwinTool > WIN_TOOL_COUNT)
					{//do some warning
						
					}
					else
					{
*/
						//EnumChildWindows(winData.hwnd, EnumChildProc, (LPARAM)&toolListptr);
						/*
						toolList[nwinTool].hwnd = winData.hwnd;
						//getwindowrect is the screen relative position not parent relative
						GetWindowRect(GetParent(winData.hwnd), &r);
						GetWindowRect(winData.hwnd, &(toolList[nwinTool].r));

						
						toolList[nwinTool].r.left -= r.left;
						toolList[nwinTool].r.right -= r.left;
						toolList[nwinTool].r.top -= r.top;
						toolList[nwinTool].r.bottom -= r.top;
						*/
						if(!inFix(winData.hwnd))
							addWinFix(winData.hwnd, getDesktop(winData.hwnd) );
/*
						wsprintf(buf, "Child relative position: (%d, %d) (%d, %d)",
									toolList[nwinTool].r.left, toolList[nwinTool].r.right,
									toolList[nwinTool].r.top, toolList[nwinTool].r.bottom);

						MessageBox(NULL, buf, "ckVWM", MB_OK);
*/
//					}
					
					//++nwinTool;
				}
				else
				{
					if(nwinHandle >= (WIN_HIDE_COUNT+WIN_RECT_COUNT))
					{
						//do a warning box
						break; // we can handle no more
					}
					
					winHandle[nwinHandle++] = winData.hwnd;
					
					if(Fix(winData.hwnd))
						EnumChildWindows(winData.hwnd, FixEnumChildProc, 0);
						//EnumWindows(FixEnumChildProc, (LPARAM)winData.hwnd);
					
				}
			}//non sticky				
		}
		//winData.hwnd = GetWindow(winData.hwnd, GW_HWNDPREV);
		winData.hwnd = GetNextWindow(winData.hwnd, GW_HWNDPREV); 
		// no dif from above actualy
	}

	//hide child
	prefixWinFix(currentScreen);

	for(i=0; i<nwinHandle; i++)
	{
		if(!inFix(winHandle[i]))
		{
			winData.hwnd = winHandle[i];
			GetWindowRect(winData.hwnd, &(winData.r));
			winData.r.left-= addH;
			winData.r.right-= addH;
			winData.r.top -= addV;
			winData.r.bottom-= addV;
		
			dwp = DeferWindowPos(dwp, winData.hwnd, NULL, 
				winData.r.left, winData.r.top, 
				/*winData.r.right-winData.r.left, winData.r.bottom-winData.r.top, */
				0, 0,
				SWP_NOZORDER | SWP_NOACTIVATE | SWP_NOSIZE);
			
			#ifdef VWM_DEBUG_OUTPUT
				if(!dwp) //failed
					fputs("DeferWindow Operation Failed\n", debug_output);
			#endif

	/*
			//Chao-Kuo Lin
			// old code
			// let's update
			if(IsInHideList(winData.hwnd))
			{
				winDataType *ptr = FindInList(winData.hwnd);
				//MessageBox(NULL, "It's in the hide list and it's now on screen", "Searching", MB_OK);
				if(ptr)
				{
					ptr->r = winData.r;
					ptr->valid = 1;
					if(IsRectOnScreen(&winData.r) || IsIconic(winData.hwnd))
					{
						#ifdef VWM_DEBUG_OUTPUT
							//debug
							char winname[0xFF+1];
							GetWindowText(prev, winname, 0xFF);
							fputs("Remove Window: ", debug_output);
							fputs(winname, debug_output);
							fputs(" from list(switchtoDesktop)\n", debug_output);
						#endif

						ptr->valid = 3;
						ShowWindow(winData.hwnd, WIN_SHOW_METHOD);
				
					}
				}
				
			}
			else if(!IsRectOnScreen(&winData.r) && !IsIconic(winData.hwnd))
			{
				#ifdef VWM_DEBUG_OUTPUT
					//debug
					char buffer[0xFF+1];
				#endif

				winHideRect[nHideRect].hwnd = winData.hwnd;
				winHideRect[nHideRect].r = winData.r;
				winHideRect[nHideRect].valid = 1;
				ShowWindow(winData.hwnd, SW_HIDE);
				++nHideRect;

				#ifdef VWM_DEBUG_OUTPUT
					//debug
					GetWindowText(winData.hwnd, buffer, 0xFF);
					fputs("Added Window: ", debug_output);
					fputs(buffer, debug_output);
					wsprintf(buffer, " to list with valid == %d (switchtoDesktop)\n", winHideRect[nHideRect-1].valid);
					fputs(buffer, debug_output);
				#endif
			}
	*/

			ProcessWinData(&winData);
		}
	}
	// defer those in the hidden list
	// then call function to do proper show and hide according to their window rect
	currentScreen = _desk;
	EndDeferWindowPos(dwp);
	
	postfixWinFix(currentScreen);
	
	//do some fixing about the tool window
	/*
	for(i=0; i< nwinTool ; ++i)
	{
		SetWindowPos(toolList[i].hwnd, NULL, toolList[i].r.left, toolList[i].r.right, 0, 0, 
				SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_NOACTIVATE);

	}
	*/

	if( currentScreen < nOnSwitch && pszOnSwitch[currentScreen] )
		LSExecute( NULL, pszOnSwitch[currentScreen], SW_SHOWNORMAL );

	SetDeskWallpaper();

	if(fixFocus)
	{
		if (LastFocus[currentScreen] && FocusLast)
		{
			if(getDesktop(LastFocus[currentScreen]) == currentScreen)
				SetForegroundWindow(LastFocus[currentScreen]);
			LastFocus[currentScreen] = NULL;
		}
		else if (FocusCenter || (!LastFocus[currentScreen] && FocusLast))
		{
			POINT p;
			p.x = ScreenWidth/2;
			p.y = ScreenHeight/2;
			SetForegroundWindow(WindowFromPoint(p));
		}
	}

	lock = 0;

	//So that the list will be ended here
	memset(&(winHideRect[nHideRect]), 0, sizeof(winDataType));

	RemoveWinFromList();
	RegenerateHideList();
}

void gatherAll(void)
{
	//RECT r;
	//HWND prev;
	int i;
		
	//Chao-Kuo Lin
	// show all the hidden stuff
	for(i=0; i<nHideRect; i++)
	{
		//showHWND = winHideRect[i].hwnd;
		AddShownWindow(winHideRect[i].hwnd);
		ShowWindow(winHideRect[i].hwnd, WIN_SHOW_METHOD);
	}

	//we have to show back all the fixes right here
	for(i=0; i<MaxScreens; ++i)
		postfixWinFix(i);


	if (NoGather)
	{
		if(!bReturntoFirstScreenOnRecycle)
		{
			int sze = sizeof(int) | VWM_DESKNO;
			SendMessage(tapp, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &currentScreen);
		}
		else
		{
			switchToDesktop(0, FALSE);
		}
	
		return;
	}
	
	if(bReturntoFirstScreenOnRecycle)
	{
		switchToDesktop(0, FALSE);
	}
	//end
	BangGather(hMainWnd, NULL);
/*
	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	while(true)
	{
		if (prev == NULL) break;
		
		if(
			  (IsWindowVisible(prev) && (GetWindowLong(prev, GWL_USERDATA) != magicDWord)) &&
			  ( !(GetWindowLong(prev, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) || (GetParent(prev) == GetDesktopWindow()) )
		   )
		{			
			
			GetWindowRect(prev, &r);
			if (r.left > ScreenWidth + 10)
			{
				r.left %= (ScreenWidth + 10);
				r.right %= (ScreenWidth + 10);
			}
			if (r.top > ScreenHeight + 10)
			{
				r.top %= (ScreenHeight + 10);
				r.bottom %= (ScreenHeight + 10);
			}
			if (r.left < 0)
			{
				r.right %= (ScreenWidth + 10);
				r.right += ScreenWidth + 10;
				r.left %= (ScreenWidth + 10);
				r.left += ScreenWidth + 10;
			}
			if (r.top < 0)
			{
				r.bottom %= (ScreenHeight + 10);
				r.bottom += ScreenHeight + 10;
				r.top %= (ScreenHeight + 10);
				r.top += ScreenHeight + 10;
			}
			MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
		}
		prev = GetWindow(prev, GW_HWNDPREV);
	}
*/
	currentScreen = 0;
	SetDeskWallpaper();
}

// Fix this to be compatible with maximized windows
// cause max windows often get out of bound
int getDesktop(HWND h)
{
	RECT rect;
	GetWindowRect(h, &rect);
	return (getDesktopByRect(rect));
}

//Chao-Kuo Lin
// Fixed that get desktop only considered the left
// top
// 
// !WARNING, no calling this function from besides getdesktop
// all functions that want to get hold of the rect should call
// getDesktop before calling GetWindowRect
int getDesktopByRect(RECT r)
{
	#ifdef VWM_DEBUG_OUTPUT
	char buffer[0xFF+1];
	#endif
	
	int offsetx1 = currentScreen % ScreensX;
	int offsety1 = currentScreen / ScreensX;
	int offsetx2, offsety2;

	int desk;

	r.left += offsetx1 * (ScreenWidth + 10);
	r.top += offsety1 * (ScreenHeight + 10);
	r.right += offsetx1 * (ScreenWidth + 10);
	r.bottom += offsety1 * (ScreenHeight + 10);

	#ifdef VWM_DEBUG_OUTPUT
	wsprintf(buffer, "The window has dimention: (%d, %d) (%d, %d)\n", r.left, r.top, r.right, r.bottom);
	fputs(buffer, debug_output);
	#endif

	if(r.right == 0)
		r.right = 1;
	if(r.bottom == 0)
		r.bottom = 1;

	offsetx1 = ((r.left) / (ScreenWidth + 10));
	offsety1 = ((r.top) / (ScreenHeight + 10));
	offsetx2 = ((r.right-1) / (ScreenWidth + 10)); //prevent when right == ScreenWidht
	offsety2 = ((r.bottom-1) / (ScreenHeight + 10));

	#ifdef VWM_DEBUG_OUTPUT
	wsprintf(buffer, "desktop offsets are : (%d, %d) (%d, %d)\n", offsetx1, offsety1, offsetx2, offsety2);
	fputs(buffer, debug_output);
	#endif

	//get the relative coordinate
	r.right -= (ScreenWidth + 10) * offsetx1;
	r.left  -= (ScreenWidth + 10) * offsetx1;
	r.bottom -= offsety1 * (ScreenHeight + 10);
	r.top -= offsety1 * (ScreenHeight + 10);
	
	#ifdef VWM_DEBUG_OUTPUT
	wsprintf(buffer, "The window has relative dimention: (%d, %d) (%d, %d)\n", r.left, r.top, r.right, r.bottom);
	fputs(buffer, debug_output);
	#endif
	

	//if some are invalid, use the other one
	if
	( 
		((offsetx1 >= 0 && offsetx1 <ScreensX) && (offsetx2 < 0 || offsetx2 >= ScreensX)) ||
		((offsety1 >= 0 && offsety1 <ScreensY) && (offsety2 < 0 || offsety2 >= ScreensY)) 
	)
	{//second one is not valid
		//MessageBox(NULL, "second one is valid while first one is invalid", "ckvwm", MB_OK);
	}
	else if(
			((offsetx1 <0 || offsetx1 >= ScreensX) && (offsetx2 >= 0 && offsetx2 <ScreensX)) ||
			((offsety1 <0 || offsety1 >= ScreensY) && (offsety2 >= 0 && offsety2 <ScreensY))
			)
	{//first one is not valid
		//this sucks, need to find a better way
		offsetx1 = ((offsetx1 <0 || offsetx1 >= ScreensX) && (offsetx2 >= 0 && offsetx2 <ScreensX)) ? offsetx2 : offsetx1;
		offsety1 = ((offsety1 <0 || offsety1 >= ScreensY) && (offsety2 >= 0 && offsety2 <ScreensY)) ? offsety2 : offsety1;
	}
	//what should we do if both are not valid?
	else 
	{
		if(offsetx1 != offsetx2)
		{
			assert(offsetx2 > offsetx1);
			if( (offsetx2-offsetx1) > 1)
			{
				offsetx1 += offsetx2;
				offsetx1 /= 2;
			}
			else
			{
				if( (ScreenWidth - r.left) < (r.right - ScreenWidth))
					offsetx1 = offsetx2;
			}
		}
		
		if(offsety1 != offsety2)
		{
			assert(offsety2 > offsety1);
			if( (offsety2-offsety1) > 1)
			{
				offsety1 += offsety2;
				offsety1 /= 2;
			}
			else
			{
				if( (ScreenHeight - r.top) < (r.bottom - ScreenHeight))
					offsety1 = offsety2;
			}
		}
	}
	

	desk = (offsety1 * ScreensX) + offsetx1;
	
	if (desk < 0) desk = 0;
	else if(desk >= MaxScreens) desk = MaxScreens -1 ;

	return desk;
}

int outsideAnyScreen(RECT r)
{
	return (r.left > ScreensX * (ScreenWidth + 10) || r.top > ScreensY*(ScreenHeight + 10));
}

void addWinFix(HWND hwnd, int s)
{
	int i;
	for (i=0;i<WIN_FIX_COUNT && winFix[i].hwnd;i++);
	
	if (i >= WIN_FIX_COUNT) return;
	winFix[i].hwnd = hwnd;
	winFix[i].screen = s;
}

void removeWinFix(HWND hwnd)
{
	int i;
	for (i=0;i<WIN_FIX_COUNT && winFix[i].hwnd && winFix[i].hwnd != hwnd;i++);
	
	if (i >= WIN_FIX_COUNT) return;
	winFix[i].hwnd = NULL;
	winFix[i].screen = 0;
}

void postfixWinFix(int s)
{
	int i;
	for (i=0;i<WIN_FIX_COUNT;i++)
	{
		if (winFix[i].hwnd && winFix[i].screen == s)
        	{
			//showHWND = winFix[i].hwnd;
			//AddShownWindow(winFix[i].hwnd);
			ShowWindow(winFix[i].hwnd, WIN_SHOW_METHOD);
			winFix[i].hwnd = NULL;
			winFix[i].screen = 0;
        	}
    }
}

void prefixWinFix(int s)
{
	int i;
	for (i=0;i<WIN_FIX_COUNT;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s) 
		{
			ShowWindow(winFix[i].hwnd, SW_HIDE);
		}
	}
}

int inFix(HWND hwnd)
{
	int i;
	
	for (i=0;i<WIN_FIX_COUNT;i++)
	{
		if(winFix[i].hwnd != NULL && winFix[i].hwnd == hwnd) break;
	}
	if (i>=WIN_FIX_COUNT) return 0;
	return 1;    
}

void DoEvents(int n)
{
	int i;
	BOOL b=TRUE;
	MSG msg;
	
	for (i=0;i<n && b;i++)
    	{
		b = GetMessage( &msg, NULL, 0, 0 );
		if (b) 
       		{
			TranslateMessage( &msg );
			DispatchMessage( &msg ); 
        	}
    	}
}

void CreateImageMasks(HWND hwnd)
{
	HBITMAP bPane, bOld;
	HDC	hdc = GetDC(hwnd), TempDC;
	int xoff, yoff;
	
	hBGList = ImageList_Create(wndSizeX, wndSizeY, ILC_COLOR32, 0, ScreensX * ScreensY + 1);
	TempDC = CreateCompatibleDC(hdc);
	bPane = CreateCompatibleBitmap(hdc, wndSizeX, wndSizeY);
	
	for (yoff = 0; yoff < ScreensY; yoff++)
		for (xoff = 0; xoff < ScreensX; xoff++)
		{
			bOld = (HBITMAP)SelectObject(TempDC, bPane);
			
			if (!BitBlt(TempDC, 0, 0, wndSizeX, wndSizeY, bgDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), SRCCOPY))
				MessageBox(hMainWnd, "BitBlt failed", "Error", MB_OK);
			SelectObject(TempDC, bOld);
			
			if (ImageList_Add(hBGList, bPane, NULL) == -1)
				MessageBox(hMainWnd, "Could not add image...", "Error", MB_OK);
		}
		
		ReleaseDC(hwnd, hdc);
		DeleteDC(TempDC);
		DeleteObject(bPane);
		DeleteObject(bOld);
}

void ReadConfig (void)
{
	char szTemp[256];
	int nDesks;
	int i;

    NoBorder = GetRCBool("VWMNoBorder", TRUE);
    NoWindows = GetRCBool("VWMNoWindows", TRUE);
	NoGather = GetRCBool("VWMNoGathering", TRUE);
	NeverSwitch = GetRCBool("VWMNoSwitchOnFocus", TRUE);
	FocusCenter = GetRCBool("VWMFocusCenter", TRUE);
	FocusLast = GetRCBool("VWMFocusLast", TRUE);
	noShow = GetRCBool("VWMNoShow", TRUE);
	snapWidth = GetRCInt("VWMSnapWidth", snapWidth);
	onTop = GetRCBool("VWMAlwaysOnTop", TRUE);
	noMove = GetRCBool("VWMNoMove", TRUE);
	VWMautohide = GetRCBool("VWMAutohide", TRUE);
	autoHideDistance = GetRCInt("VWMAutohideDistance", autoHideDistance);
	autoHideFix = GetRCBool("VWMAutohideFix", autoHideFix);
	titlebars = GetRCBool("VWMTitlebars", TRUE);
	titleHeightMod = GetRCInt("VWMTitlebarMod", titleHeightMod);
	bevel = GetRCBool("VWMBevel", TRUE);
	autoswitch = GetRCBool("VWMAutoSwitch", TRUE);
	autoSwitchDistance = GetRCInt("VWMAutoSwitchDistance", autoSwitchDistance);
	useIcons = GetRCBool("VWMShowIcons", TRUE);
	iconSize = GetRCInt("VWMIconSize", iconSize);
	useInitialDesk = GetRCBool("VWMUseInitialDesk", TRUE);
	initialDesk = GetRCInt("VWMInitialDesk", initialDesk);
	mouseLeft = GetRCInt("VWMMouseLeft", mouseLeft);
	mouseRight = GetRCInt("VWMMouseRight", mouseRight);
	mouseMiddle = GetRCInt("VWMMouseMiddle", mouseMiddle);
	
	// Chao-Kuo Lin
	mouseDoubleLeft = GetRCBool("VWMMouseDoubleLeft", TRUE);
	// end

	backColor = GetRCColor("vwmBackColor", 0x808080);
	winColor = GetRCColor("vwmWinColor", 0x808080);
	selBackColor = GetRCColor("vwmSelBackColor", 0x404040);
	foreColor = GetRCColor("VWMForeColor", 0xFFFFFF);
	borderColor = GetRCColor("VWMBorderColor", 0x000000);
	
	borderSize = GetRCInt("WharfBevelWidth", 1);

	ScreensX = GetRCInt("VWMDesksX", workingArea.left);
	ScreensY = GetRCInt("VWMDesksY", workingArea.top);
	
	mTimeout = GetRCInt("VWMAutoSwitchDelay", mTimeout);
	

	// Chao-Kuo Lin
	bHideTaskOnSwitch = GetRCBool("VWMHideTaskOnSwitch", TRUE);
	//	TRUE will cause sysvwm to switch to the first screen, 0,
	//  during quitModule
	bReturntoFirstScreenOnRecycle = GetRCBool("VWMReturnToFirstScreen", TRUE);
	//	TRUE will cause the vwm to act like circular instead of linear
	bWrapScreen = GetRCBool("VWMWrapScreen", TRUE);
	//	TREU will cause when dargging windows in mini-snapshot, window
	//	will retain its relative position
	bSnapWindowOnDrag = GetRCBool("VWMSnapWindowOnDrag", TRUE);

	//	TRUE will disable that direction when auto switching is enabled
	bVWMDisableVerticalAutoSwitch = GetRCBool("VWMDisableVerticalAutoSwitch", TRUE);
	bVWMDisableHorizontalAutoSwitch = GetRCBool("VWMDisableHorizontalAutoSwitch", TRUE);

	//  choose the window hiding method
	//bUseWin32Hide = GetRCBool("VWMUseAlternativeHidingMethod", FALSE);

	//  Dimension for the restored window
	//  The settings for BangRestore, window's dimention
	RestoreX = GetRCInt("VWMRestoreX", RestoreX);
	RestoreY = GetRCInt("VWMRestoreY", RestoreY);
	RestoreWidth = GetRCInt("VWMRestoreWidth", RestoreWidth);
	RestoreHeight = GetRCInt("VWMRestoreHeight", RestoreHeight);

	//  Setting for changing the determinating factor
	//  10 = 10%, 100 = 100%
	MaximizeThreshold = GetRCInt("VWMMaximizeThreshold", MaximizeThreshold);

	//bPureLS = GetRCBool("VWMPureLSUser", TRUE);

	//end

	// Modified - Maduin, 10-20-1999
	//   Changed to use new API LSGetImagePath rather than
	//   access the step.rc directly.
	mainX = GetRCInt("VWMx", mainX);
	mainY = GetRCInt("VWMy", mainY);
	mainWidth = GetRCInt("VWMwidth", mainWidth);
	mainHeight = GetRCInt("VWMheight", mainHeight);

	while(mainX < 0) mainX += ScreenWidth;
	while(mainY < 0) mainY += ScreenHeight;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;
	
	{
		FILE *f;
		char buffer[256];
		int num = 0;
		char *lpszBuffers[3];
		char token1[4096], token2[4096], token3[0xFF+1];

		//default sticky, temporary remedy
		//strcpy(StickyConfig[num++].match, "PSFloatC");	//photoshop toolz

		//read in sticky config
		f = LCOpen(NULL);
		if (f) 
		{
			while (LCReadNextConfig (f, "*VWMSticky", buffer, sizeof (buffer)))
			{
				lpszBuffers[0] = token1;
				lpszBuffers[1] = token2;

				LCTokenize (buffer, lpszBuffers, 2, NULL);
				strcpy(StickyConfig[num].match, token2);
				
				if( strlen(StickyConfig[num].match) > 0) 
					++num;
			}
			LCClose(f);
		}
		stickyTotal = num;

		num = 0;
		//read in fix config
		
		f = LCOpen(NULL);
		if (f) 
		{
			while (LCReadNextConfig (f, "*VWMFix", buffer, sizeof (buffer)))
			{
				lpszBuffers[0] = token1;
				lpszBuffers[1] = token2;

				LCTokenize (buffer, lpszBuffers, 2, NULL);
				strcpy(FixConfig[num].match, token2);
				
				if( strlen(FixConfig[num].match) > 0) 
					++num;
			}
			LCClose(f);
		}
		fixTotal = num;
		//read in startup window desktop config
		num = 0;
		f = LCOpen(NULL);
		if (f) 
		{
			while (LCReadNextConfig (f, "*VWMStartWindowsOnDesktop", buffer, sizeof (buffer)))
			{
				lpszBuffers[0] = token1;
				lpszBuffers[1] = token2;
				lpszBuffers[2] = token3;

				if( LCTokenize(buffer, lpszBuffers, 3, NULL) == 3)
				{
					strcpy(StartWindow[num].match, token2);
					//this way, the desktop number starts with 1
					StartWindow[num].desktop = atoi(token3) - 1;
					if( StartWindow[num].desktop >= 0 || StartWindow[num].desktop < (ScreensX*ScreensY))
					{
						if( strlen(StartWindow[num].match) > 0) 
						{
							#ifdef VWM_DEBUG_OUTPUT
							fputs("Window matching pattern ", debug_output);
							fputs(StartWindow[num].match, debug_output);
							fputs("  is being added to database.\n", debug_output);
							#endif
							++num;
						}
					}
				}
			}
			LCClose(f);
		}

		windowStartTotal = num;
		#ifdef VWM_DEBUG_OUTPUT
		{
			char buf[0xFF+1];
			fputs("Total window in database: ", debug_output);
			fputs(itoa(windowStartTotal, buf, 10), debug_output);
			fputs("\n", debug_output);
		}
		#endif

	}
	
	/*
	GetRCString("VWMBackBmp", szTemp, ".none", 256);
	if (!strnicmp(szTemp, ".snapshot", sizeof(".snapshot"))) 
	{
		snapshot = TRUE;
	}
	else 
	{
		bBGBitmap = LoadLSImage(szTemp, NULL);
		if (bBGBitmap) GetBMPSize(bBGBitmap, &backX, &backY);
	}
	*/

	GetRCString("VWMSelBmp", szTemp, ".none", 256);
	sBGBitmap = LoadLSImage(szTemp, NULL);
	if (sBGBitmap) GetBMPSize(sBGBitmap, &selX, &selY);

	GetRCString("VWMWinBmp", szTemp, ".none", 256);
	wBGBitmap = LoadLSImage(szTemp, NULL);
	if (wBGBitmap) GetBMPSize(wBGBitmap, &winX, &winY);

	GetRCString("VWMTitlebarBmp", szTemp, ".none", 256);
	tBGBitmap = LoadLSImage(szTemp, NULL);
	if (tBGBitmap) GetBMPSize(tBGBitmap, &titleX, &titleY);

	nDesks = ScreensX * ScreensY;

	nOnSwitch = nDesks;
	pszOnSwitch = (PTSTR *) malloc( nOnSwitch * sizeof(PTSTR) );

	for( i = 0; i < nOnSwitch; i++ )
	{
		TCHAR szCommand[32];
		TCHAR szBuffer[MAX_PATH];

		wsprintf( szCommand, TEXT("VWMOnSwitchTo%d"), i + 1 );
		GetRCLine( szCommand, szBuffer, MAX_PATH, TEXT("") );

		if( szBuffer[0] )
		{
			pszOnSwitch[i] = (PTSTR) malloc( (lstrlen( szBuffer ) + 1) * sizeof(TCHAR) );
			lstrcpy( pszOnSwitch[i], szBuffer );
		}
		else
		{
			pszOnSwitch[i] = NULL;
		}
	}

	for( i = 0; i < 256; i++ )
		pszWallpapers[i] = NULL;

	for( i = 0; i < nDesks; i++ )
	{//modified by Chao-Kuo Lin
		TCHAR szConfigLine[25];
		TCHAR Path[MAX_PATH+1];
		wsprintf( szConfigLine, TEXT("VWMDeskWallpaper%d"), i + 1 );
		GetRCString( szConfigLine, Path, TEXT(""), MAX_PATH );
		//GetRCString( szConfigLine, pszWallpapers[i], TEXT(""), MAX_PATH );

		if(*Path)
		{
			pszWallpapers[i] = (PTSTR) malloc(MAX_PATH+1);
			VarExpansion(pszWallpapers[i] , Path);
		}
	//end modification
	}
}

void BangGather(HWND caller , LPCSTR args)
{
	RECT r;
	HWND prev;
	int i;
	int width, height;

	refToplevel = NULL;

	for(i=0; i<MaxScreens; ++i)
		postfixWinFix(i);
	
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);

	while (true)
	{
		if (prev == NULL) break;

		//if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE) && !IsInHideList(prev))
		if ( (IsWindowVisible(prev) || IsInHideList(prev)) &&
			!(GetWindowLong(prev, GWL_STYLE) & WS_MINIMIZE) &&
			!(GetWindowLong(prev, GWL_USERDATA) == magicDWord))
		{
			
			GetWindowRect(prev, &r);
			width = r.right-r.left;
			height = r.bottom-r.top;

			if (r.left >= (ScreenWidth + 10))
			{
				r.left %= (ScreenWidth + 10);
				if (r.left > (ScreenWidth + 10))
					r.left -= (ScreenWidth + 10);
				//r.right %= (ScreenWidth + 10);
				r.right = r.left+width;
			}
			else if (r.right < 0)
			{
				r.right %= (ScreenWidth + 10);
				if (r.right < 0)
					r.right += (ScreenWidth + 10);
				/*
				r.left %= (ScreenWidth + 10);
				if (r.left < 0)
					r.left += (ScreenWidth + 10);
				*/
				r.left = r.right-width;
			}
			
			if (r.top > ScreenHeight)
			{
				r.top %= (ScreenHeight + 10);
				if (r.top > ScreenHeight + 10)
					r.top -= (ScreenHeight + 10);
				//r.bottom %= (ScreenHeight + 10);
				r.bottom = r.top+height;
			}
			else if (r.bottom < 0)
			{
				r.bottom %= (ScreenHeight + 10);
				if (r.bottom < 0)
					r.bottom += (ScreenHeight + 10);
				/*
				r.top %= (ScreenHeight + 10);
				if (r.top < 0)
					r.top += (ScreenHeight + 10);
				*/
				r.top = r.bottom-height;
			}

			MoveWindow(prev, r.left, r.top, width, height, TRUE);
		}
		prev = GetWindow(prev, GW_HWNDPREV);
	}
}

HICON getIconFromWindow(HWND hWnd, BOOL bBigIcon)
{
	HICON hIcon = NULL;
	
	int nBigOrSmall = bBigIcon ? ICON_BIG : ICON_SMALL;
	int nBigOrSmall2 = bBigIcon ? GCL_HICON : GCL_HICONSM;
	
	SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 0, 
		SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);
	if(!hIcon) SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 1, 
		SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);
	if(!hIcon) SendMessageTimeout(hWnd, WM_QUERYDRAGICON, nBigOrSmall, 
		0, SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	
	return hIcon;
}

void SetDeskWallpaper(void)
{
	if( pszWallpapers[currentScreen] && *pszWallpapers[currentScreen] )
	{
		SystemParametersInfo( SPI_SETDESKWALLPAPER, 0,
			(PVOID) pszWallpapers[currentScreen],
			SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
	}
}

//Chao-Kuo Lin
// Right now it's using the slowest comparing algorithm,
// Might change to sort the list first when it's enum'ed
// then we can do a binary search or something in this function
// return TRUE if the window is stored in our hideRect database
BOOL IsInHideList(HWND hwnd)
{
	winDataType *ptr = winHideRect;
	winDataType *endptr = winHideRect + nHideRect;

	if(!bHideTaskOnSwitch) // return FALSE if the user doesn't hide
		return FALSE;
		
	for( ; ptr < endptr ; ptr++)
		if( hwnd == ptr->hwnd) return TRUE;
	return FALSE;
}

BOOL IsRectOnScreen(LPRECT rect, HWND hwnd)
{
	BOOL ret = FALSE; // the return value
	RECT screen_rect;
	POINT ptlt, ptlb, ptrt, ptrb;

	#ifdef VWM_DEBUG_OUTPUT
	//debug
		char buffer[0xFF+1];
	#endif


	if(!bHideTaskOnSwitch)
	{
		return TRUE; 
		// window is always(fake) on screen to because user doesn't want to hide
	}


	#ifdef VWM_DEBUG_OUTPUT
	//debug
		wsprintf(buffer, "Checking Rect: (%d, %d) (%d, %d)\n", rect->left, rect->top, rect->right, rect->bottom);
		fputs(buffer, debug_output);
	#endif


//	screen_rect.top = screen_rect.left = 0;
//	screen_rect.right = ScreenWidth;
//	screen_rect.bottom = ScreenHeight;

	screen_rect = workingArea;

	ptlt.x = ptlb.x = rect->left;
	ptrt.x = ptrb.x = rect->right;
	ptlt.y = ptrt.y = rect->top;
	ptlb.y = ptrb.y = rect->bottom;

	//if any of the point of the window is in screen
	//then return true
	if( PtInRect(&screen_rect, ptlt) ||
		PtInRect(&screen_rect, ptrt) ||
		PtInRect(&screen_rect, ptlb) ||
		PtInRect(&screen_rect, ptrb))
	{
		ret = TRUE;
	}
	else
	{
		//if any point of the screen is inside the window right now,
		//then it also returns true
		ptlt.x = ptlb.x = screen_rect.left;
		ptrt.x = ptrb.x = screen_rect.right;
		ptlt.y = ptrt.y = screen_rect.top;
		ptlb.y = ptrb.y = screen_rect.bottom;

		if( PtInRect(rect, ptlt) ||
			PtInRect(rect, ptrt) ||
			PtInRect(rect, ptlb) ||
			PtInRect(rect, ptrb))
		{
			ret = TRUE;
		}
	}
	
	if(ret && (GetWindowLong(hwnd, GWL_STYLE) & WS_MAXIMIZE))
	{
		//it's maximized
		//we use the area under the current desktop of the rect to
		//determine if the window is under the current desktop

		// if less than Threshold of the window's area's is appearing,
		// we consider it as not in this desktop
		RECT area;
		int inter_area, rectarea;

		if(IntersectRect(&area, rect, &screen_rect))
		{
			#ifdef VWM_DEBUG_OUTPUT
			char buffer[0xFF+1];
			#endif

			rectarea = abs( (rect->right - rect->left) * (rect->bottom - rect->top) );
			inter_area = abs( (area.right - area.left) * (area.bottom - area.top) );

			#ifdef VWM_DEBUG_OUTPUT
			wsprintf(buffer, "Intersection Area: (%d, %d) (%d, %d)\n", area.left, area.top, area.right, area.bottom);
			fputs(buffer, debug_output);
			#endif
			
			if(inter_area < ((MaximizeThreshold * rectarea)/100) )
			{ //under threshold, let's exclude it
				ret = FALSE;
			}
		}
		else
			ret = FALSE; //it's not even intersecting
	}
	else if(!ret) // check if any border line intersects the rect
	{
		ret = 
			(
				(
					(rect->top < screen_rect.top && rect->bottom > screen_rect.top) ||	
					(rect->top < screen_rect.bottom && rect->bottom > screen_rect.bottom)
				) 
				&&
					(rect->left > screen_rect.left && rect->right < screen_rect.right)
			)
			||
			(rect->left < screen_rect.left && rect->right > screen_rect.left) ||
			(rect->left < screen_rect.right && rect->right > screen_rect.right);
	}

/*
	if(ret && (GetWindowLong(hwnd, GWL_STYLE) & WS_MAXIMIZE))
	{
		//it's maximized
		//we use the area under the current desktop of the rect to
		//determine if the window is under the current desktop

		// if less than Threshold of the window's area's is appearing,
		// we consider it as not in this desktop
		RECT area;
		int inter_area, rectarea;

		if(IntersectRect(&area, rect, &screen_rect))
		{
			#ifdef VWM_DEBUG_OUTPUT
			char buffer[0xFF+1];
			#endif

			rectarea = abs( (rect->right - rect->left) * (rect->bottom - rect->top) );
			inter_area = abs( (area.right - area.left) * (area.bottom - area.top) );

			#ifdef VWM_DEBUG_OUTPUT
			wsprintf(buffer, "Intersection Area: (%d, %d) (%d, %d)\n", area.left, area.top, area.right, area.bottom);
			fputs(buffer, debug_output);
			#endif
			
			if(inter_area < ((MaximizeThreshold * rectarea)/100) )
			{ //under threshold, let's exclude it
				ret = FALSE;
			}
		}
		else
			ret = FALSE; //it's not even intersecting
	}
*/
	return ret;
}


void RemoveWinFromList(void)
{
	winDataType *ptr = winHideRect;
	winDataType *endptr = winHideRect + nHideRect;

	#ifdef VWM_DEBUG_OUTPUT
		char buffer[0xFF+1];
	#endif
	
	for( ; ptr < endptr ; ptr++)
	{
		if( IsRectOnScreen(&(ptr->r), ptr->hwnd))
		{
			#ifdef VWM_DEBUG_OUTPUT
				//debug
				GetWindowText(ptr->hwnd, buffer, 0xFF);
				fputs("Window : ", debug_output);
				fputs(buffer, debug_output);
				fputs(" is being shown and valid changes to 3(RemoveWinFromList)\n", debug_output);
			#endif

			//ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
			ptr->valid = 3; // valid == 3 means that it's shown now
		}
		else if(IsIconic(ptr->hwnd))
		{
			#ifdef VWM_DEBUG_OUTPUT
				GetWindowText(ptr->hwnd, buffer, 0xFF);
				fputs("Window : ", debug_output);
				fputs(buffer, debug_output);
				fputs(" is being shown cause it's Iconic and valid changes to 3(RemoveWinFromList)\n", debug_output);
			#endif
			
			ptr->valid = 3; // valid == 3 
		}
		/* // guess this doesn't work for iconic or something?
		else if(IsWindow(ptr->hwnd))
		{
			ptr->valid = 3; //just to remove it from list
		}
		*/ 
		else
			ptr->valid = 1; // just in case
	}
}

void RegenerateHideList(void)
{
	winDataType tempRect[WIN_HIDE_COUNT];
	winDataType *ptr = winHideRect, *endptr = winHideRect + nHideRect, *temp = tempRect, *endtemp;
	
	#ifdef VWM_DEBUG_OUTPUT
		//debug output
		char buffer[0xFF];
		wsprintf(buffer, "Originally %d windows\n", nHideRect);
		if(nHideRect) fputs(buffer, debug_output);
	#endif
	
	for( ; ptr < endptr ; ptr++)
		{
			if(ptr->valid && ptr->valid != 3)
			{
				*(temp++) = *ptr;
			}
			/*
			else if(ptr->valid == 3)
			{
				ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
			}
			*/
			#ifdef VWM_DEBUG_OUTPUT
				//debug
				else
				{
					GetWindowText(ptr->hwnd, buffer, 0xFF);
					fputs("Window : ", debug_output);
					fputs(buffer, debug_output);
					wsprintf(buffer, "  is being removed from list cause its valid == %d (RegenHideList)\n", ptr->valid);
					fputs(buffer, debug_output);
				}
			#endif
		}
	// valid == 3 didn't occur
	endtemp = temp;
	temp = tempRect;
	ptr = winHideRect;
	
	if( (endtemp-temp) != (endptr-ptr) ) 
	{

		#ifdef VWM_DEBUG_OUTPUT
			//debug
			wsprintf(buffer, "%d temp windows\n", endtemp - temp);
			if(endtemp-temp) fputs(buffer, debug_output);
		#endif

		for(nHideRect = 0; temp < endtemp; temp++, ptr++, nHideRect++)
			*ptr = *temp;
		
		#ifdef VWM_DEBUG_OUTPUT
			//debug
			wsprintf(buffer, "%d windows copied\n", nHideRect);
			if(nHideRect) fputs(buffer, debug_output);
		#endif
		memset(ptr, 0, sizeof(winDataType));
	}
	else
		memset(endptr, 0, sizeof(winDataType));
}

winDataType *FindInList(HWND hwnd)
{
	winDataType *ptr = winHideRect;
	winDataType *endptr = winHideRect + nHideRect;

	for( ; ptr < endptr ; ptr++)
		if(ptr->hwnd == hwnd) return ptr;
	return NULL;
}

winDataType *FindInRectList(HWND hwnd)
{
	winDataType *ptr = winRect;
	int i;
	for(i = 0; i < nWinRect && ptr->valid; i++, ptr++)
		if(ptr->hwnd == hwnd) return ptr;
	return NULL;
}

//bang command for toggling HideTaskOnSwitch
void BangHideTask(HWND caller, LPCSTR args)
{
	//show all the windows first if we were hiding it
	winDataType *ptr = winHideRect, *endptr = winHideRect + nHideRect;

	if(bHideTaskOnSwitch)
	{
		for(; ptr < endptr; ptr++)
		{
			//showHWND = ptr->hwnd;
			AddShownWindow(ptr->hwnd);
			ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
		}
	}

	bHideTaskOnSwitch = !bHideTaskOnSwitch;
}

//bang command for toggling WrapScreen
void BangWrap(HWND caller, LPCSTR args)
{
	bWrapScreen = !bWrapScreen;
} 

//bang command for restoring the window if it disappeared
//well, probably should combine those two enumproc and make them 1.
//Send a struct with LPCSTR, ProcHanldler as data, send address as LPARAM
//then the enum will call the coresponding handler which will return BOOL
//to determine whether should stop or not??...anyway...
void BangRestore(HWND caller, LPCSTR args)
{
	EnumProcDataT data;
	if(!args || strlen(args) == 0) return;
	
	data.proc = RestoreWindowsProc;
	data.str = args;
	EnumWindows(EnumProc, (LPARAM)&data);
	
}

BOOL RestoreWindowsProc(HWND hwnd)
{
	if(hwnd)
	{//probably will change so user can specify the dimension
		if(RestoreWidth < 0 || RestoreHeight <0)
		{
			RECT r;
			GetWindowRect(hwnd, &r);
			MoveWindow(hwnd,	RestoreX, RestoreY, r.right-r.left, r.bottom-r.top, TRUE);
		}
		else
			MoveWindow(hwnd,	RestoreX, RestoreY, RestoreWidth, RestoreHeight, TRUE);

		ShowWindow(hwnd, SW_SHOW);
		return FALSE;
	}

	return TRUE;	
}

void BangRestoreAll(HWND caller, LPCSTR args)
{
	EnumProcDataT data;
	char token1[4096], token2[4096];
	char* tokens[2];
	int count;
   
	if(!args || *args == 0) return;
	
	tokens[0] = token1;
	tokens[1] = token2;
	count = LCTokenize (args, tokens, 2, NULL);
	data.str = token1;

	if(count == 1) // uses default overlap way
		data.proc = RestoreAllWindowsProc;
	else if(count == 2)
	{
		if(stricmp(token2, "overlap") == 0)
		{
			data.proc = RestoreAllWindowsProc;
		}
		if(stricmp(token2, "cascade") == 0)
		{
			data.proc = RestoreAllWindowsCascadeProc;
		}
	}
	else
		return;

	EnumWindows(EnumProc, (LPARAM)&data);
}


BOOL RestoreAllWindowsProc(HWND hwnd)
{
	if(hwnd)
	{
		if(RestoreWidth < 0 || RestoreHeight <0)
		{
			RECT r;
			GetWindowRect(hwnd, &r);
			MoveWindow(hwnd,	RestoreX, RestoreY, r.right-r.left, r.bottom-r.top, TRUE);
		}
		else
			MoveWindow(hwnd,	RestoreX, RestoreY, RestoreWidth, RestoreHeight, TRUE);

		ShowWindow(hwnd, SW_SHOW);
	}

	return TRUE;	
}

BOOL RestoreAllWindowsCascadeProc(HWND hwnd)
{
	RECT r;
	static int windowXcoord = -10, windowYcoord = -10;

	if(hwnd)
	{
		if(windowXcoord < RestoreX)
			windowXcoord = RestoreX;
		if(windowYcoord < RestoreY)
			windowYcoord = RestoreY;
		GetWindowRect(hwnd, &r);

		r.right = r.right - r.left + windowXcoord;
		r.bottom = r.bottom - r.top + windowYcoord;
		r.left = windowXcoord;
		r.top = windowYcoord;
		
		windowXcoord += 16;
		windowYcoord += 16;

		if(r.right > workingArea.right || r.bottom > workingArea.bottom)
		{
			windowXcoord = RestoreX;
			windowYcoord = RestoreY;
		}
				

		if(RestoreWidth < 0 || RestoreHeight <0)
			MoveWindow(hwnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
		else
			MoveWindow(hwnd, r.left, r.top, RestoreWidth, RestoreHeight, TRUE);
	
		ShowWindow(hwnd, SW_SHOW);
		SetForegroundWindow(hwnd);
		SwitchToThisWindow(hwnd, 1);
	}

	return TRUE;	
}

//Move the main window
void BangMove(HWND caller, LPCSTR args)
{
	char token1[4096], token2[4096];
	char* tokens[2];
	int count;

	if(!dockedOnWharf)
	{
		tokens[0] = token1;
		tokens[1] = token2;

		count = LCTokenize(args, tokens, 2, NULL);
		
		if(count == 2)
		{
			mainX = atoi(token1);
			mainY = atoi(token2);
		}
		else if(count == 0)
		{
			mainX = oldMainX;
			mainY = oldMainY;
		}
		
		while(mainX < 0) mainX += ScreenWidth;
		while(mainY < 0) mainY += ScreenHeight;

		if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
		if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;

		MoveWindow(hMainWnd, mainX, mainY, mainWidth, mainHeight, TRUE);
	}
}

// General Windows EnumProc that can perform a lot of group windows thingy
BOOL CALLBACK EnumProc(HWND hwnd, LPARAM lParam)
{
	char buffer[0xFF+1];
	lpEnumProcDataT ptr = (lpEnumProcDataT)lParam;
	 
	if(GetWindowText(hwnd, buffer, 0xFF))
	{
		if(match(ptr->str, buffer))
			return ptr->proc(hwnd);
	}

	if(GetClassName(hwnd, buffer, 0xFF))
	{
		if(match(ptr->str,buffer))
			return ptr->proc(hwnd);
	}

	return TRUE;

}

//return TRUE if the windata is:
//				1. shown, but now not on screen
//				2. 
//		 False if:
//				1. in hide list, and still not on screen
//
BOOL ProcessWinData(winDataType *ptr)
{
	BOOL result;
	#ifdef VWM_DEBUG_OUTPUT
	//debug
	char buffer[0xFF+1];
	GetWindowText(ptr->hwnd, buffer, 0xFF);
	fputs("Window: ", debug_output);
	fputs(buffer, debug_output);
	fputs(" is being examined......\n", debug_output);
	#endif
	assert(nHideRect < WIN_HIDE_COUNT);

	result = IsRectOnScreen(&(ptr->r), ptr->hwnd);

	if(result || IsIconic(ptr->hwnd)) // it's visible
	{
		if(IsInHideList(ptr->hwnd)) // in hide list
		{	//make the window appear, and remove it later
			// this show is remove to the removewinlist function
			// but if removed, then the z-order will be screwed .....
			
			#ifdef VWM_DEBUG_OUTPUT
			//debug
			fputs("Window: ", debug_output);
			fputs(buffer, debug_output);
			fputs(" from the hide list is being shown cause it's on screen.\n", debug_output);
			#endif

			//showHWND = ptr->hwnd;
			AddShownWindow(ptr->hwnd);
			ShowWindow(ptr->hwnd, WIN_SHOW_METHOD); 
			//ckShowWindow(ptr->hwnd);
			ptr->valid = 3;
		}
		return FALSE;
	}
	else if(!result) // it's now not on screen
	{
		ptr->valid = 1;
		ShowWindow(ptr->hwnd, SW_HIDE);
		//ckHideWindow(ptr->hwnd);

		if(!IsInHideList(ptr->hwnd))
		{//Let's add it
			#ifdef VWM_DEBUG_OUTPUT
			//debug
			fputs("Window: ", debug_output);
			fputs(buffer, debug_output);
			fputs(" is being added to the hide list because it's not on screen.\n", debug_output);
			#endif
			if(nHideRect < WIN_HIDE_COUNT)
				memcpy(&(winHideRect[nHideRect++]), ptr, sizeof(winDataType));
			else//we should show it cause we can't have it in our array 
			{
				//showHWND = ptr->hwnd;
				AddShownWindow(ptr->hwnd);
				ShowWindow(ptr->hwnd, WIN_SHOW_METHOD);
				//ckShowWindow(ptr->hwnd);
			}
		}
		else
		{//update it
			winDataType *old = FindInList(ptr->hwnd);
			memcpy(old, ptr, sizeof(winDataType));
			#ifdef VWM_DEBUG_OUTPUT
			//debug
			fputs("Window: ", debug_output);
			fputs(buffer, debug_output);
			fputs(" is being updated in hide list because it's not on screen.\n", debug_output);
			#endif
		}
		return TRUE;
	}

	return FALSE;
}

// Go through the array and check for match
// return true if match
int StartWindowCheck(HWND hwnd)
{
	int i;
	char windowTitle[0xFF+1];
	char windowClass[0xFF+1];
	GetWindowText(hwnd, windowTitle, 0xFF);
	GetClassName(hwnd, windowClass, 0xFF);

	for(i=0; i<windowStartTotal; i++)
	{
		if(match(StartWindow[i].match, windowTitle)) return i;
		if(match(StartWindow[i].match, windowClass)) return i;
	}

	//not found
	return -1;
}

//add hwnd to the list of shown windows that will be excluded from StartWindowCheck
void AddShownWindow(HWND hwnd)
{
	int i;

	if(currentShow >= WIN_SHOWN_LIST)
	{//get rid of the oldest one
		for(i=1; i<	WIN_SHOWN_LIST; i++)
			showHWND[i-1] = showHWND[i];
		currentShow = WIN_SHOWN_LIST-1;
	}
	
	showHWND[currentShow++] = hwnd; // add
}

//true if the window is just shown and shouldn't consider as first launched
BOOL IsShownWindow(HWND hwnd)
{
	int i, j;
	for(i=0; i<currentShow; i++)
	{
		if(showHWND[i] == hwnd)
		{
			for(j=i+1; j<currentShow; j++)
				showHWND[j-1] = showHWND[j];
			--currentShow;
			return TRUE;
		}
	}

	return FALSE;
}

//////////////////////////////////////////////
//  This exported function is to unse with other programs that
//	want to gain access hidden windows
//
//  To ensure that the module is loaded by Litstep, MaxScreens
//	is initialized to 0, so that unless Initmoduleex is called,
//	this function will always return FALSE
BOOL EnumTasks(int desk, WNDENUMPROC pEnumFunc, WNDENUMPROC ckEnumFunc, LPARAM lParam)
{
	int i;
	// dont know if this is good, but we check if the window is blank, if blank
	// we don't send to you
	char winTitle[0xFF+1];
	
	if(desk <= 0 || desk > MaxScreens)
		return FALSE;
	--desk; // so it starts with 1

	if(desk == currentScreen || desk < 0)
	{
		EnumWindows(pEnumFunc, lParam);
	}
	
	// if desk < 0 then it'll be called cause desk < 0 will never == currentScreen
	if(desk != currentScreen)
	{
		for(i=0; i<nHideRect; i++)
		{
			if(getDesktop(winHideRect[i].hwnd) == desk || desk < 0)
			{
				if(GetWindowText(winHideRect[i].hwnd, winTitle, 0xFF))
				{
					if(!ckEnumFunc(winHideRect[i].hwnd, lParam))
							break; // just like EnumWindows
				}
			}
		}
	}
	return TRUE;
}

//supply absolute coorinate to get it's relative in it's own desktop
//and where it is
void NormalizeCoordinate(RECT *r, int *deskx, int *desky)
{
	int H, V;
	if(r && deskx && desky)
	{
		getShifts(0, currentScreen, &H, &V);
		r->left += H;
		r->top += V;
		*deskx = r->left / (ScreenWidth + 10);
		*desky = r->top / (ScreenHeight + 10);
		r->left %= (ScreenWidth + 10);
		r->top	%= (ScreenHeight + 10);
	}
}

// you know what?? it seems that setting other window's LONG is Illigle!!
/*
void ckShowWindow(HWND hwnd)
{
	if(bUseWin32Hide)
		ShowWindow(hwnd, WIN_SHOW_METHOD);
	else
	{
		if(GetWindowLong(hwnd, GWL_USERDATA) == magicDWord)
			SetWindowLong(hwnd,	GWL_USERDATA, 0);
	}
}

void ckHideWindow(HWND hwnd)
{
	if(bUseWin32Hide)
		ShowWindow(hwnd, SW_HIDE);
	else
	{
		if(GetWindowLong(hwnd, GWL_USERDATA) == 0)
		{
			SetWindowLong(hwnd, GWL_USERDATA, magicDWord);
			if(SetWindowLong(hwnd, GWL_USERDATA, magicDWord) != magicDWord)
				MessageBox(NULL, "setting magic failed", "ckVWM", MB_OK);
		}
	}
}
*/
/*
//setup the mouse hook	
void SetShellHook(void)
{
	if(!g_Hook)
	{
		g_Hook = SetWindowsHookEx(WH_SHELL, ShellProc, inst, 0);
		if(g_Hook) MessageBox(NULL, "Registered our hook", "ckVWM", MB_OK);
	}
}

void RemoveShellHook(void)
{
	if(g_Hook)
		if(UnhookWindowsHookEx(g_Hook))
		{
			MessageBox(NULL, "unRegistered our hook", "ckVWM", MB_OK);
			g_Hook = NULL;
		}
}

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	HWND ckHWND;
	//damn our g_Hook value is sure to be fuxored
	if(nCode < 0)
		return CallNextHookEx(g_Hook, nCode, wParam, lParam);
	
	ckHWND = FindWindow(CKVWMCLASSNAME, NULL);
	if(ckHWND)
		PostMessage(ckHWND, nCode + 9500, wParam, lParam);

	return 0;
}
*/

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	UNREFERENCED_PARAMETER(pvReserved);
	UNREFERENCED_PARAMETER(dwReason);

	if(dwReason == DLL_PROCESS_ATTACH)
	{
		inst = hInstance;
		DisableThreadLibraryCalls(hInstance);
	}
	return TRUE;
}


//end Chao-Kuo Lin
