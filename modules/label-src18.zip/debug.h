#if !defined(__DEBUG_H)
#define __DEBUG_H

void DebugSetFileName(LPCTSTR pszFileName);
void DebugPrint(LPCTSTR pszFormat, ...);

#endif
