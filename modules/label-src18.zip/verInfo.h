#if !defined(__VERINFO_H)
#define __VERINFO_H

#define V_NAME "Label"
#define V_VERSION "1.8"
#define V_AUTHOR "Maduin"

#endif
