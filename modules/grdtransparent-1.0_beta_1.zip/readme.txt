<!>==============================================================<!>
< >                                                              < >
< >      grdTransparent.dll - make your world transparent!       < >
< >                                                              < >
<!>==============================================================<!>
< >                                                              < >
<#>    grdTransparent is module for LiteStep, which provides     <#>
< >  All Windows 2000 (and above) users with the functionality   < >
< >  of lsTransparent, but in the "right" way.                   < >
< >    This module is a quick hack from my much more             < >
< >  interesting, but at the stage of writing this,              < >
< >  not complete module grdMagic. What grdMagic does you'll     < >
< >  have to read about elsewhere, but the reason I brought it   < >
< >  up is that, the source of inspiration for that module was   < >
< >  the previously mentioned lsTransparent.                     < >
< >    And not only did I get inspired by lsTransparent, but     < >
< >  Carl Milano, aka carluchi, also let me look at the          < >
< >  source-code for lsTransparent. Allthough almost             < >
< >  everything, I owe great thanx to Carl.                      < >
< >                                                              < >
< >                                    developer: Gustav Munkby  < >
< >                                   grimreaperdesigns@gmx.net  < >
< >                                                              < >
< >                           with GREAT help from: Carl Milano  < >
< >                                        carluchi@stratos.net  < >
< >                                                              < >
< >                                                              < >
< >  updates                                                     < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >  [v1.0 beta 1]                                               < >
< >  <+> first verion.                                           < >
< >  <!> supports almost everything lsTransparent does.          < >
< >  <-> has to be loaded before the modules to transperize.     < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  installation                                                < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>  1) unpack the grdTransparent.dll into your mods directory.  <#>
< >                                                              < >
<#>  2) add the line to step.rc looking somewhat like this:      <#>
< >     LoadModule $LiteStepDir$\modules\grdTransparent.dll      < >
< >                                                              < >
<#>  3) start playin' around with the settings in your step.rc   <#>
< >                                                              < >
< >                                                              < >
< >  STEP.RC commands                                      < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>  *grdTransparent <module> <alpha> <group>                    <#>
< >                                                              < >
<W>  <module>; the name of the module you want to make           <W>
< >            transparent. Path and extension is ignored.       < >
< >                                                              < >
<O>  <alpha>; the alpha value of the module. Range: [0-255]      <O>
< >             0   = Completely transparent.                    < >
< >             255 = Completely opaque           
               < >
< >                                                              < >
<M>  <group>; group id, for usage with !BANG commands.           <M>
< >                                                              < >
<#>  Example:                                                    <#>
<.>  *grdTransparent popup2 196 1                                <.>
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  supported !BANG commands                                    < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>    grdTransparent supports a couple of bang commands:        <#>
< >                                                              < >
<#>  !grdTransparentSet <group> <alpha>                          <#>
< >  Set the transparency of a certain group.                    < >
< >  See *grdTransparent for reference of <group> & <alpha>      < >
< >                                                              < >
<#>  !grdTransparentFade <group> <alpha> <steps> <interval>      <#>
< >  Fade to a certain level of transparency.                    < >
< >                                                              < >
<P>  <alpha>; the alpha value to fade to. Range: [0-255]         <P>
< >                                                              < >
<M>  <steps>; the number of steps used when fading.              <M>
< >                                                              < >
<M>  <interval>; the number of milliseconds between each step.   <M>
< >                                                              < >
<#>    That was all the bang commands supported.                 <#>
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  known issues                                                < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    grdTransparent has to be loaded BEFORE the modules you    < >
< >  you want to have transparent.                               < >
< >                                                              < >
< >    popup2 seems to cause some malformed graphics, but        < >
< >  must be due to either popup2, desktop2 or                   < >
< >  the way SetLayeredWindowAttributes() works.                 < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  additional notes                                            < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    Nothing here yet, except the fact that I'd like to be     < >
< >  presented with a lot of ideas, help and stuff like that.    < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  source license                                              < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    The code is avaliable for free and you can get it by      < >
< >  contacting me through e-mail or another way.                < >
< >    Even if the code is free, and you're allowed to do        < >
< >  almost whatever you like with it, I have to restrict it     < >
< >  a little. The requirements to use it is:                    < >
< >                                                              < >
< >  >> source-code has to be included                           < >
< >  >> this documentatory file has to be included               < >
< >                                                              < >
< >  those were the requirements, my wishes are that:            < >
< >                                                              < >
< >  >> you tell me about using my source-code                   < >
< >  >> you also mention Carl Milano                             < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  the man                                                     < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >  Gustav Munkby, online known as grim reaper or grd           < >
< >  The man behind the concept "grd" which stands for;          < >
< >  grim reaper designs, which is my web-page and what I do     < >
< >  on the computer.                                            < >
< >  This is where you find my domains online:                   < >
< >                                                              < >
<?>  e-mail:         grimreaperdesigns@gmx.net                   <?>
< >                                                              < >
<?>  webpage:        http://floach.pimpin.net/grd/               <?>
< >                                                              < >
<?>  grdTransparent: <webpage>/ls/grdtransparent.zip             <?>
<?>  -source:        <webpage>/ls/grdtransparent.src.zip         <?>
< >                                                              < >
<?>  other modules:  <webpage>/ls/index.html                     <?>
< >                                                              < >
<?>  icq:         1349988                                        <?>
< >                                                              < >
<?>  irc:         #lsdev/#ls2k (nick: grd/grd_ls/grd-ls)         <?>
< >                                                              < >
< >                                                              < >
<!>==============================================================<!>


