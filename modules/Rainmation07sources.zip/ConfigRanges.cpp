// ConfigRanges.cpp : implementation file
//

#include "stdafx.h"
#include "Rainmation.h"
#include "ConfigRanges.h"
#include "Config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigRanges property page

IMPLEMENT_DYNCREATE(CConfigRanges, CPropertyPage)

CConfigRanges::CConfigRanges() : CPropertyPage(CConfigRanges::IDD)
{
	//{{AFX_DATA_INIT(CConfigRanges)
	m_ClickEnable = FALSE;
	m_ClickStartFrame = 0;
	m_NormalStartFrame = 0;
	m_OffStartFrame = 0;
	m_OnStartFrame = 0;
	m_OverEnable = FALSE;
	m_OverStartFrame = 0;
	m_OverStopFrame = 0;
	m_OnStopFrame = 0;
	m_OnEnable = FALSE;
	m_OffEnable = FALSE;
	m_OffStopFrame = 0;
	m_NormalStopFrame = 0;
	m_ClickStopFrame = 0;
	//}}AFX_DATA_INIT
}

CConfigRanges::~CConfigRanges()
{
}

void CConfigRanges::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigRanges)
	DDX_Control(pDX, IDC_OFFSTARTSLIDER, m_OffStartSlider);
	DDX_Control(pDX, IDC_OVERSTOPSLIDER, m_OverStopSlider);
	DDX_Control(pDX, IDC_OVERSTARTSLIDER, m_OverStartSlider);
	DDX_Control(pDX, IDC_ONSTOPSLIDER, m_OnStopSlider);
	DDX_Control(pDX, IDC_ONSTARTSLIDER, m_OnStartSlider);
	DDX_Control(pDX, IDC_OFFSTOPSLIDER, m_OffStopSlider);
	DDX_Control(pDX, IDC_NORMALSTOPSLIDER, m_NormalStopSlider);
	DDX_Control(pDX, IDC_NORMALSTARTSLIDER, m_NormalStartSlider);
	DDX_Control(pDX, IDC_CLICKSTOPSLIDER, m_ClickStopSlider);
	DDX_Control(pDX, IDC_CLICKSTARTSLIDER, m_ClickStartSlider);
	DDX_Check(pDX, IDC_CLICKRANGE, m_ClickEnable);
	DDX_Text(pDX, IDC_CLICKSTART, m_ClickStartFrame);
	DDX_Text(pDX, IDC_NORMALSTART, m_NormalStartFrame);
	DDX_Text(pDX, IDC_OFFSTART, m_OffStartFrame);
	DDX_Text(pDX, IDC_ONSTART, m_OnStartFrame);
	DDX_Check(pDX, IDC_OVERRANGE, m_OverEnable);
	DDX_Text(pDX, IDC_OVERSTART, m_OverStartFrame);
	DDX_Text(pDX, IDC_OVERSTOP, m_OverStopFrame);
	DDX_Text(pDX, IDC_ONSTOP, m_OnStopFrame);
	DDX_Check(pDX, IDC_ONRANGE, m_OnEnable);
	DDX_Check(pDX, IDC_OFFRANGE, m_OffEnable);
	DDX_Text(pDX, IDC_OFFSTOP, m_OffStopFrame);
	DDX_Text(pDX, IDC_NORMALSTOP, m_NormalStopFrame);
	DDX_Text(pDX, IDC_CLICKSTOP, m_ClickStopFrame);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigRanges, CPropertyPage)
	//{{AFX_MSG_MAP(CConfigRanges)
	ON_BN_CLICKED(IDC_ONRANGE, OnOnrange)
	ON_BN_CLICKED(IDC_OFFRANGE, OnOffrange)
	ON_BN_CLICKED(IDC_OVERRANGE, OnOverrange)
	ON_BN_CLICKED(IDC_CLICKRANGE, OnClickrange)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfigRanges message handlers

void CConfigRanges::OnOnrange() 
{
	UpdateData();

	if(m_OnEnable) {
		GetDlgItem(IDC_ONSTART)->EnableWindow(true);
		GetDlgItem(IDC_ONSTARTSLIDER)->EnableWindow(true);
		GetDlgItem(IDC_ONSTOP)->EnableWindow(true);
		GetDlgItem(IDC_ONSTOPSLIDER)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_ONSTART)->EnableWindow(false);
		GetDlgItem(IDC_ONSTARTSLIDER)->EnableWindow(false);
		GetDlgItem(IDC_ONSTOP)->EnableWindow(false);
		GetDlgItem(IDC_ONSTOPSLIDER)->EnableWindow(false);
	}	
}

void CConfigRanges::OnOffrange() 
{
	UpdateData();

	if(m_OffEnable) {
		GetDlgItem(IDC_OFFSTART)->EnableWindow(true);
		GetDlgItem(IDC_OFFSTARTSLIDER)->EnableWindow(true);
		GetDlgItem(IDC_OFFSTOP)->EnableWindow(true);
		GetDlgItem(IDC_OFFSTOPSLIDER)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_OFFSTART)->EnableWindow(false);
		GetDlgItem(IDC_OFFSTARTSLIDER)->EnableWindow(false);
		GetDlgItem(IDC_OFFSTOP)->EnableWindow(false);
		GetDlgItem(IDC_OFFSTOPSLIDER)->EnableWindow(false);
	}
}

void CConfigRanges::OnOverrange() 
{
	UpdateData();

	if(m_OverEnable) {
		GetDlgItem(IDC_OVERSTART)->EnableWindow(true);
		GetDlgItem(IDC_OVERSTARTSLIDER)->EnableWindow(true);
		GetDlgItem(IDC_OVERSTOP)->EnableWindow(true);
		GetDlgItem(IDC_OVERSTOPSLIDER)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_OVERSTART)->EnableWindow(false);
		GetDlgItem(IDC_OVERSTARTSLIDER)->EnableWindow(false);
		GetDlgItem(IDC_OVERSTOP)->EnableWindow(false);
		GetDlgItem(IDC_OVERSTOPSLIDER)->EnableWindow(false);
	}
}

void CConfigRanges::OnClickrange() 
{
	UpdateData();

	if(m_ClickEnable) {
		GetDlgItem(IDC_CLICKSTART)->EnableWindow(true);
		GetDlgItem(IDC_CLICKSTARTSLIDER)->EnableWindow(true);
		GetDlgItem(IDC_CLICKSTOP)->EnableWindow(true);
		GetDlgItem(IDC_CLICKSTOPSLIDER)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_CLICKSTART)->EnableWindow(false);
		GetDlgItem(IDC_CLICKSTARTSLIDER)->EnableWindow(false);
		GetDlgItem(IDC_CLICKSTOP)->EnableWindow(false);
		GetDlgItem(IDC_CLICKSTOPSLIDER)->EnableWindow(false);
	}
}

void CConfigRanges::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SetDlgItemInt(IDC_NORMALSTART, m_NormalStartSlider.GetPos());
	SetDlgItemInt(IDC_NORMALSTOP, m_NormalStopSlider.GetPos());
	SetDlgItemInt(IDC_ONSTART, m_OnStartSlider.GetPos());
	SetDlgItemInt(IDC_ONSTOP, m_OnStopSlider.GetPos());
	SetDlgItemInt(IDC_OFFSTART, m_OffStartSlider.GetPos());
	SetDlgItemInt(IDC_OFFSTOP, m_OffStopSlider.GetPos());
	SetDlgItemInt(IDC_OVERSTART, m_OverStartSlider.GetPos());
	SetDlgItemInt(IDC_OVERSTOP, m_OverStopSlider.GetPos());
	SetDlgItemInt(IDC_CLICKSTART, m_ClickStartSlider.GetPos());
	SetDlgItemInt(IDC_CLICKSTOP, m_ClickStopSlider.GetPos());

	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CConfigRanges::OnSetActive() 
{
	UINT FrameCount;

	UpdateData();
	
	OnOnrange();
	OnOffrange();
	OnOverrange();
	OnClickrange();

	FrameCount=((CConfig*)GetParent())->GetFrameCount();

	m_NormalStartSlider.SetRange(0, FrameCount-1);
	m_NormalStartSlider.SetPos(m_NormalStartFrame);
	m_NormalStopSlider.SetRange(0, FrameCount-1);
	m_NormalStopSlider.SetPos(m_NormalStopFrame);

	m_OnStartSlider.SetRange(0, FrameCount-1);
	m_OnStartSlider.SetPos(m_OnStartFrame);
	m_OnStopSlider.SetRange(0, FrameCount-1);
	m_OnStopSlider.SetPos(m_OnStopFrame);

	m_OffStartSlider.SetRange(0, FrameCount-1);
	m_OffStartSlider.SetPos(m_OffStartFrame);
	m_OffStopSlider.SetRange(0, FrameCount-1);
	m_OffStopSlider.SetPos(m_OffStopFrame);

	m_OverStartSlider.SetRange(0, FrameCount-1);
	m_OverStartSlider.SetPos(m_OverStartFrame);
	m_OverStopSlider.SetRange(0, FrameCount-1);
	m_OverStopSlider.SetPos(m_OverStopFrame);
	
	m_ClickStartSlider.SetRange(0, FrameCount-1);
	m_ClickStartSlider.SetPos(m_ClickStartFrame);
	m_ClickStopSlider.SetRange(0, FrameCount-1);
	m_ClickStopSlider.SetPos(m_ClickStopFrame);

	return CPropertyPage::OnSetActive();
}
