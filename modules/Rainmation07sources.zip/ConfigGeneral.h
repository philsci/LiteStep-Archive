#if !defined(AFX_CONFIGGENERAL_H__E9175981_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
#define AFX_CONFIGGENERAL_H__E9175981_DD9A_11D3_92A3_0080AD90417B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfigGeneral.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CConfigGeneral dialog

class CConfigGeneral : public CPropertyPage
{
	DECLARE_DYNCREATE(CConfigGeneral)

// Construction
public:
	CConfigGeneral();
	~CConfigGeneral();

	BOOL GetAlwaysOnTop() { return m_AlwaysOnTop; };
	UINT GetDelay() { return m_Delay; };
	BOOL GetNoMenu() { return m_NoMenu; };
	BOOL GetRunOnce() { return m_RunOnce; };
	BOOL GetStartDisabled() { return m_StartDisabled; };
	BOOL GetToolTip() { return m_ToolTip; };
	CString& GetToolTipText() { return m_ToolTipText; };
	BOOL GetRealTransparency() { return m_RealTransparency; };
	int GetXPos(bool Negative=false);
	int GetYPos(bool Negative=false);

	void SetToolTipText(char* ToolTipText ) { m_ToolTipText=ToolTipText; };
	void SetAlwaysOnTop(BOOL AlwaysOnTop ) { m_AlwaysOnTop=AlwaysOnTop; };
	void SetDelay(UINT Delay ) { m_Delay=Delay; };
	void SetNoMenu(BOOL NoMenu ) { m_NoMenu=NoMenu; };
	void SetRunOnce(BOOL RunOnce ) { m_RunOnce=RunOnce; };
	void SetStartDisabled(BOOL StartDisabled ) { m_StartDisabled=StartDisabled; };
	void SetToolTip(BOOL ToolTip ) { m_ToolTip=ToolTip; };
	void SetRealTransparency(BOOL RealTransparency ) { m_RealTransparency=RealTransparency; };
	void SetXPos(int XPos ) { m_XPos=XPos; };
	void SetYPos(int YPos ) { m_YPos=YPos; };

	// Dialog Data
	//{{AFX_DATA(CConfigGeneral)
	enum { IDD = IDD_GENERAL };
	BOOL	m_AlwaysOnTop;
	UINT	m_Delay;
	BOOL	m_NoMenu;
	BOOL	m_RunOnce;
	BOOL	m_StartDisabled;
	BOOL	m_ToolTip;
	CString	m_ToolTipText;
	BOOL	m_RealTransparency;
	int		m_XPos;
	int		m_YPos;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CConfigGeneral)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CConfigGeneral)
	afx_msg void OnTooltip();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGGENERAL_H__E9175981_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
