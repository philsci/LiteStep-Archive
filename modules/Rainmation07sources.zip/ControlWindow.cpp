/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"
#include "Rainmation.h"
#include "ControlWindow.h"
#include "..\ls-b24\lsapi\lsapi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define VERSION "0.7"

/////////////////////////////////////////////////////////////////////////////
// CControlWindow

CControlWindow::CControlWindow()
{
}

CControlWindow::~CControlWindow()
{
	CAnimWindow* tmpAnim;

	for(int i=0; i<=m_Anims.GetUpperBound(); i++) {
		tmpAnim=(CAnimWindow*)m_Anims.GetAt(i);
		delete tmpAnim;
	}
	m_Anims.RemoveAll();

	m_ToolTipWindow.DestroyWindow();
}



BEGIN_MESSAGE_MAP(CControlWindow, CWnd)
	//{{AFX_MSG_MAP(CControlWindow)
	ON_WM_TIMER()
	ON_MESSAGE(LM_GETREVID, OnGetRevID)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/* 
** Initialize
**
** Initializes the plugin. Reads the config-lines from Step.rc, Loads the bitmaps
** and creates the hidden controlwindow for all animations.
**
*/
bool CControlWindow::Initialize(HWND, HINSTANCE dllInst)
{
	LPCTSTR Classname;
	char tmpName[MAX_LINE+1];
	CString AnimName, FileName, PixPath;
	CAnimWindow* tmpAnim;
	int i;
	CRect R(0,0,0,0);
	int Msgs[]={LM_GETREVID, 0};

	m_DllInstance=dllInst;

	Classname=AfxRegisterWndClass(NULL, ::LoadCursor(NULL, IDC_ARROW), (HBRUSH)(COLOR_WINDOW+1));

	if(!CreateEx(WS_EX_TOOLWINDOW, Classname, NULL,  WS_POPUP, R, NULL, NULL, NULL)) return false;

	SetWindowLong(*this, GWL_USERDATA, magicDWord);

	// Register RevID message to Litestep
	::SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)m_hWnd, (LPARAM)Msgs);

	// ToolTips
	m_ToolTipWindow.CreateEx(NULL, TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP, R, NULL, NULL, NULL);
	m_ToolTipWindow.SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);


	AddBangCommand("!RAnimEnable", RAnimEnable);
	AddBangCommand("!RAnimDisable", RAnimDisable);
	AddBangCommand("!RAnimToggle", RAnimToggle);
	AddBangCommand("!RAnimRefresh", RAnimRefresh);
	AddBangCommand("!RAnimQuit", RAnimQuit);
	AddBangCommand("!RAnimConfig", RAnimConfig);
	AddBangCommand("!RAnimPlayFrames", RAnimPlayFrames);

	GetRCString("PixmapPath", tmpName, "c:\\Litestep\\Images\\", MAX_LINE+1);
	PixPath=tmpName;

	GetRCString("RAnimPixmapPath", tmpName, PixPath, MAX_LINE+1);
	if(strcmp(tmpName, PixPath)!=0) {
		PixPath=tmpName;	
	}

	if(!PixPath.IsEmpty() && PixPath[PixPath.GetLength()-1]!='\\') {
		PixPath+="\\";
	}

	CAnimWindow::SetPixmapPath(PixPath);

	m_StartDelay=GetRCInt("RAnimStartDelay", 1);


	// Scan for RAnims
	FILE *f = LCOpen(NULL);
	char Buffer[256];

	i=0;
	Buffer[0]=Buffer[7]=0;
    while (LCReadNextConfig (f, "*RAnim", Buffer, sizeof(Buffer))) {
		if(Buffer[7]!=0) {
			tmpAnim=new CAnimWindow(Buffer+7, this);
			tmpAnim->SetInstance(dllInst);
			m_Anims.SetAtGrow(i++, tmpAnim);
		}
		Buffer[0]=Buffer[7]=0;
	}
    LCClose(f);


	if(m_StartDelay==0) {
		m_StartDelay=1;
	} else {
		m_StartDelay*=1000;
	}

	SetTimer(1, m_StartDelay, NULL);

	return true;
}


CAnimWindow* CControlWindow::GetAnim(int Index)
{
	if(Index<0 || Index>m_Anims.GetUpperBound()) return NULL;

	return (CAnimWindow*)m_Anims.GetAt(Index);
}

CAnimWindow* CControlWindow::GetAnim(char* AnimName)
{
	int i;
	CAnimWindow* tmpAnim;

	if(AnimName==NULL) return NULL;

	for(i=0; i<=m_Anims.GetUpperBound(); i++) {
		tmpAnim=(CAnimWindow*)m_Anims.GetAt(i);
		if(tmpAnim && tmpAnim->GetName().CompareNoCase(AnimName)==0) {
			return tmpAnim;
		}
	}

	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// CControlWindow message handlers

void CControlWindow::OnTimer(UINT Timer) 
{
	CAnimWindow* tmpAnim;

	if(Timer==1) {
		KillTimer(1);

		for(int i=0; i<=m_Anims.GetUpperBound(); i++) {
			tmpAnim=(CAnimWindow*)m_Anims.GetAt(i);
			if(tmpAnim) {
				tmpAnim->Initialize();
			}
		}
	}
}

// Litestep revision control
// Not rcs-style but who cares
afx_msg LRESULT CControlWindow::OnGetRevID(WPARAM wParam, LPARAM lParam) {
	char* Buffer=(char*)lParam;
	CString Version;

	if(wParam==0) {
		Version.Format("Rainmation.dll: %s", VERSION);
	} else if(wParam==1) {
		Version.Format("Rainmation.dll: %s %s, Rainy", VERSION, __DATE__);
	}

	strcpy(Buffer, Version);

	return strlen(Buffer);
}

