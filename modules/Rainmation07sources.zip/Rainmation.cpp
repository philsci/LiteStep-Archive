/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"
#include "Rainmation.h"
#include "ControlWindow.h"
#include "..\ls-b24\lsapi\lsapi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CRainmationApp

BEGIN_MESSAGE_MAP(CRainmationApp, CWinApp)
	//{{AFX_MSG_MAP(CRainmationApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRainmationApp construction

CRainmationApp::CRainmationApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRainmationApp object

CRainmationApp theApp;

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	theApp.m_pMainWnd=new CControlWindow;

	if(!(theApp.m_pMainWnd && ((CControlWindow*)theApp.m_pMainWnd)->Initialize(ParentWnd, dllInst))) {
		MessageBox(ParentWnd, "Unable to initialize Rainmation!", "Error", MB_OK);
		return 1;	
	}

    return 0;
}


void quitModule(HINSTANCE)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	int Msgs[]={LM_GETREVID, 0};

	// Unregister RevID message
	::SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)theApp.m_pMainWnd->m_hWnd, (LPARAM)Msgs);

	RemoveBangCommand("!RAnimEnable");
	RemoveBangCommand("!RAnimDisable");
	RemoveBangCommand("!RAnimToggle");
	RemoveBangCommand("!RAnimRefresh");
	RemoveBangCommand("!RAnimQuit");
	RemoveBangCommand("!RAnimConfig");
	RemoveBangCommand("!RAnimPlayFrames");

	if(theApp.m_pMainWnd) {
		CControlWindow* CW=(CControlWindow*)theApp.m_pMainWnd;
		CW->DestroyWindow();
		delete CW;
		theApp.m_pMainWnd=NULL;
	}
}

/*
** Bang callbacks
*/

extern "C" void RAnimEnable(HWND, char* arg)
{
	int i;
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg==NULL || arg[0]=='\0') {
			i=0;
			do {
				tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(i++);
				if(tmpAnim) tmpAnim->EnableAnim();
			} while(tmpAnim);

		} else {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->EnableAnim();
		}
	}
}

extern "C" void RAnimDisable(HWND, char* arg)
{
	int i;
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg==NULL || arg[0]=='\0') {
			i=0;
			do {
				tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(i++);
				if(tmpAnim) tmpAnim->DisableAnim();
			} while(tmpAnim);

		} else {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->DisableAnim();
		}
	}
}

extern "C" void RAnimToggle(HWND, char* arg)
{
	int i;
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg==NULL || arg[0]=='\0') {
			i=0;
			do {
				tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(i++);
				if(tmpAnim) tmpAnim->ToggleAnim();
			} while(tmpAnim);

		} else {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->ToggleAnim();
		}
	}
}

extern "C" void RAnimRefresh(HWND, char* arg)
{
	int i;
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg==NULL || arg[0]=='\0') {
			i=0;
			do {
				tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(i++);
				if(tmpAnim) tmpAnim->RefreshAnim();
			} while(tmpAnim);

		} else {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->RefreshAnim();
		}
	}
}

extern "C" void RAnimQuit(HWND, char* arg)
{
	int i;
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg==NULL || arg[0]=='\0') {
			i=0;
			do {
				tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(i++);
				if(tmpAnim) tmpAnim->QuitAnim();
			} while(tmpAnim);

		} else {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->QuitAnim();
		}
	}
}

extern "C" void RAnimConfig(HWND, char* arg)
{
	CAnimWindow* tmpAnim;

	if(theApp.m_pMainWnd) {
		if(arg!=NULL && arg[0]!='\0') {
			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(arg);
			if(tmpAnim) tmpAnim->ConfigAnim();
		}
	}
}

extern "C" void RAnimPlayFrames(HWND, char* arg)
{
	CAnimWindow* tmpAnim;
	char tmpBuffer[256];
	int Start, Stop;

	if(theApp.m_pMainWnd) {
		if(arg!=NULL && arg[0]!='\0') {
			sscanf(arg, "%s %i %i", tmpBuffer, &Start, &Stop);

			tmpAnim=((CControlWindow*)(theApp.m_pMainWnd))->GetAnim(tmpBuffer);
			if(tmpAnim) tmpAnim->PlayFrames(Start, Stop);
		}
	}
}
