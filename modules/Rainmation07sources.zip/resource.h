//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rainmation.rc
//
#define IDD_GENERAL                     106
#define IDR_MENU1                       2000
#define IDC_XPOS                        2000
#define IDC_YPOS                        2001
#define IDC_DELAY                       2002
#define IDD_EXECUTE                     2002
#define IDC_TRANSPARENCY                2003
#define IDD_RANGES                      2003
#define IDC_ALWAYSONTOP                 2004
#define IDC_COMMAND                     2005
#define IDC_BROWSE                      2006
#define IDC_EXECUTE                     2007
#define IDC_NOMENU                      2008
#define IDC_MOUSEONEXECUTE              2008
#define IDC_WAITCLICK                   2009
#define IDC_NORMALSTART                 2010
#define IDC_MOUSEONCOMMAND              2010
#define IDC_STARTDISABLED               2011
#define IDC_MOUSEONBROWSE               2011
#define IDC_RUNONCE                     2012
#define IDC_TOOLTIPTEXT                 2013
#define IDC_MOUSEOFFEXECUTE             2013
#define IDC_TOOLTIP                     2014
#define IDC_MOUSEOFFCOMMAND             2014
#define IDC_MOUSEOFFBROWSE              2015
#define IDC_MOUSEDELAY                  2016
#define IDC_NORMALSTARTSLIDER           2029
#define IDC_NORMALSTOP                  2035
#define IDC_NORMALSTOPSLIDER            2036
#define IDC_ONSTART                     2037
#define IDC_ONSTOP                      2038
#define IDC_ONRANGE                     2039
#define IDC_ONSTARTSLIDER               2040
#define IDC_ONSTOPSLIDER                2041
#define IDC_OFFSTART                    2042
#define IDC_OFFSTOP                     2043
#define IDC_OFFRANGE                    2044
#define IDC_OFFSTARTSLIDER              2045
#define IDC_OFFSTOPSLIDER               2046
#define IDC_OVERSTART                   2047
#define IDC_OVERSTOP                    2048
#define IDC_OVERRANGE                   2049
#define IDC_OVERSTARTSLIDER             2050
#define IDC_OVERSTOPSLIDER              2051
#define IDC_CLICKSTART                  2052
#define IDC_CLICKSTOP                   2053
#define IDC_CLICKRANGE                  2054
#define IDC_CLICKSTARTSLIDER            2055
#define IDC_CLICKSTOPSLIDER             2056
#define ID_REFRESH                      32776
#define ID_DISABLE                      32777
#define ID_QUIT                         32778
#define ID_CONFIG                       32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2002
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         2032
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
