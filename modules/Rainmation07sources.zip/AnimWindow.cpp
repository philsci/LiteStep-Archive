/*
  Copyright (C) 2000 Kimmo Pekkola

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"
#include "Rainmation.h"
#include "AnimWindow.h"
#include "ControlWindow.h"
#include "Config.h"
#include "..\ls-b24\lsapi\lsapi.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString CAnimWindow::C_PixmapPath;

/////////////////////////////////////////////////////////////////////////////
// CAnimWindow

CAnimWindow::CAnimWindow(char* Name, CControlWindow* ControlWindow) : m_Config(C_PixmapPath, Name, this)
{
	m_Height=0;
	m_Width=0;
	m_CurrentFrame=0;
	m_MaxFrame=0;
	m_State=STOP;
	m_OldState=STOP;
	m_Clicked=false;
	m_Name=Name;
	m_ControlWindow=ControlWindow;
	m_MouseExecuted=false;
}

CAnimWindow::~CAnimWindow()
{
	HBITMAP tmpBitmap;
	HRGN tmpRegion;
	int i;

	for(i=0; i<=m_Bitmaps.GetUpperBound(); i++) {
		tmpBitmap=(HBITMAP)m_Bitmaps.GetAt(i);
		DeleteObject(tmpBitmap);
	}
	m_Bitmaps.RemoveAll();

	if(m_Config.GetRealTransparency()) {
		SetWindowRgn(NULL, false);
		for(i=0; i<=m_Regions.GetUpperBound(); i++) {
			tmpRegion=(HRGN)m_Regions.GetAt(i);
			DeleteObject(tmpRegion);
		}
		m_Regions.RemoveAll();
	}

	RemoveToolTip();

	DestroyWindow();
}

/* 
** Initialize
**
** Initializes the animation window
**
*/
bool CAnimWindow::Initialize()
{
	LPCTSTR Classname;

	m_Config.ReadConfig();
	if(!ReadAnim()) return false;

	Classname=AfxRegisterWndClass(0, ::LoadCursor(NULL, IDC_ARROW), (HBRUSH)(COLOR_WINDOW+1));

	if(!CreateEx(WS_EX_TOOLWINDOW, Classname, NULL,  WS_POPUP, 
		m_Config.GetXPos(), m_Config.GetYPos(), m_Width, m_Height, m_ControlWindow->m_hWnd, NULL, NULL)) return false;

	SetWindowLong(*this, GWL_USERDATA, magicDWord);

	CreateFrames();
	m_CurrentFrame=m_Config.GetNormalStartFrame();

	if(m_Config.GetStartDisabled()) {
		m_State=STOP;
	} else {
		m_State=RUN;
		SetTimer(1, m_Config.GetDelay(), NULL);
	}

	ShowWindow(SW_SHOWNOACTIVATE);

	if(m_Config.GetAlwaysOnTop()) {
		SetWindowPos(&wndTopMost, m_Config.GetXPos(), m_Config.GetYPos(), 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
	} else {
		SetWindowPos(NULL, m_Config.GetXPos(), m_Config.GetYPos(), 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	}

	if(GetConfig().GetToolTip()) AddToolTip();

	return true;
}

BEGIN_MESSAGE_MAP(CAnimWindow, CWnd)
	//{{AFX_MSG_MAP(CAnimWindow)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_REFRESH, OnRefresh)
	ON_COMMAND(ID_DISABLE, OnDisable)
	ON_COMMAND(ID_QUIT, OnQuit)
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_CONFIG, OnConfig)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/* 
** ReadAnim
**
** Read the animation frames
**
*/
bool CAnimWindow::ReadAnim() 
{
	HBITMAP BM;
	HBITMAP AlphaBM;
	BITMAP bm;
	CString AnimName;
	CString Error;
	int j=0;

	while(true) {
		AnimName.Format("%s%s\\%s%03i.bmp", C_PixmapPath, m_Name, m_Name, j);
		BM=LoadLSImage(AnimName, NULL);

		if(j==0 && BM==NULL) {
			Error.Format("Animation %s Failed!\nFirst animation frame not found!\n\n%s", m_Name, AnimName);
			MessageBox(Error, APPNAME, MB_OK);
			return false;
		}

		if(BM==NULL) break;	// No more frames

		GetObject(BM, sizeof(BITMAP), &bm);
		if(j==0) {
			m_Width=bm.bmWidth;
			m_Height=bm.bmHeight;
		} else {
			if(m_Width!=bm.bmWidth || m_Height!=bm.bmHeight) {
				Error.Format("Animation %s Failed in frame %03i!\nAll animation frames must be same size!", m_Name, j);
				MessageBox(Error, APPNAME, MB_OK);
				return false;
			}
		}
		m_Bitmaps.SetAtGrow(j, BM);

		// Try to read alpha-mask
		AnimName.Format("%s%s\\%s%03i-Alpha.bmp", C_PixmapPath, m_Name, m_Name, j);
		AlphaBM=LoadLSImage(AnimName, NULL);

		if(AlphaBM) {
			GetObject(AlphaBM, sizeof(BITMAP), &bm);
			if(m_Width!=bm.bmWidth || m_Height!=bm.bmHeight) {
				Error.Format("Animation %s Failed in frame %03i!\nAlpha-bitmaps must be same size as the frame-bitmaps!", m_Name, j);
				MessageBox(Error, APPNAME, MB_OK);
				return false;
			}
		}
		m_Alphas.SetAtGrow(j, AlphaBM);

		j++;
	}
	
	m_MaxFrame=j-1;
	m_Config.SetFrameCount(j);

	return true;
}

/* 
** Refresh
**
** Discards the old animation frames and loads new ones.
**
*/
void CAnimWindow::Refresh()
{
	HBITMAP tmpBitmap;
	HRGN tmpRegion;
	CString AnimName;
	int i;

	ShowWindow(SW_HIDE);
	KillTimer(1);
	m_CurrentFrame=0;

	m_OldState=m_State;
	m_State=REFRESH;
	m_Clicked=false;

	// Remove the old bitmaps
	for(i=0; i<=m_Bitmaps.GetUpperBound(); i++) {
		tmpBitmap=(HBITMAP)m_Bitmaps.GetAt(i);
		DeleteObject(tmpBitmap);
	}
	m_Bitmaps.RemoveAll();

	// Remove old regions
	SetWindowRgn(NULL, false);
	if(m_Config.GetRealTransparency()) {
		for(i=0; i<=m_Regions.GetUpperBound(); i++) {
			tmpRegion=(HRGN)m_Regions.GetAt(i);
			DeleteObject(tmpRegion);
		}
		m_Regions.RemoveAll();
	}
	
	m_Config.ReadConfig();
	ReadAnim();
	m_CurrentFrame=m_Config.GetNormalStartFrame();

	SetWindowPos(NULL, m_Config.GetXPos(), m_Config.GetYPos(), 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);

	SetTimer(1, m_Config.GetDelay(), NULL);	
}

/* 
** CreateFrames
**
** Takes a copy of the backround (desktop) and copies it behind all animation frames.
** Unless RealTransparency is set, in which case window regions are created for each frame.
**
*/
void CAnimWindow::CreateFrames()
{
	CWnd* Desktop;
	CDC* DDC;
	CBitmap* OldBitmap;
	CBitmap* OldBitmap2;
	CBitmap FrameBitmap;
	CBitmap tmpBitmap;
	CBitmap Background;
	CDC tmpDC;
	CDC bgDC;
	HRGN tmpRegion;
	HBITMAP tmpBM;
	int i, j;

	Desktop=GetDesktopWindow();
	DDC=Desktop->GetDC();

	if(DDC==NULL) return;	// Error

	tmpDC.CreateCompatibleDC(DDC);
	bgDC.CreateCompatibleDC(DDC);
	Background.CreateCompatibleBitmap(DDC, m_Width, m_Height);
	tmpBitmap.CreateCompatibleBitmap(DDC, m_Width, m_Height);

	// Fetch the background
	OldBitmap=bgDC.SelectObject(&Background);
	bgDC.BitBlt(0, 0, m_Width, m_Height, DDC, m_Config.GetXPos(), m_Config.GetYPos(), SRCCOPY);
	
	Desktop->ReleaseDC(DDC);

	OldBitmap2=tmpDC.SelectObject(&tmpBitmap);

	// Number of regions equals to the number of bitmaps (of course :)
	m_Regions.SetSize(m_Bitmaps.GetUpperBound());
	m_RegionIndices.SetSize(m_Bitmaps.GetUpperBound());

	for(i=0; i<=m_Bitmaps.GetUpperBound(); i++) {
		tmpBM=(HBITMAP)m_Bitmaps.GetAt(i);
		if(tmpBM==NULL) continue;

		FrameBitmap.Attach(tmpBM);

		if(!m_Config.GetRealTransparency()) {

			// If the frame has an alpha-mask, use it.
			if(m_Alphas.GetAt(i)) {
				bgDC.SelectObject(OldBitmap);
				tmpBM=(HBITMAP)m_Alphas.GetAt(i);
				CreateAlpha(FrameBitmap, tmpBM, Background);
				DeleteObject(tmpBM);	// We don't need the alpha-mask anymore, so let's delete it
			} else {

				// Blit BG to tmp
				bgDC.SelectObject(&Background);
				tmpDC.BitBlt(0, 0, m_Width, m_Height, &bgDC, 0, 0, SRCCOPY);

				// Blit Animframe over tmp
				bgDC.SelectObject(&FrameBitmap);
				TransparentBltLS(tmpDC, 0, 0, m_Width, m_Height, bgDC, 0, 0, RGB(255,0,255));

				// Blit tmp over Frame 
				bgDC.BitBlt(0, 0, m_Width, m_Height, &tmpDC, 0, 0, SRCCOPY);
			}
		} else {
			// Create a region from the bitmap
			tmpRegion=BitmapToRegion(FrameBitmap, RGB(255,0,255), 0x101010, 0, 0);
			m_Regions.SetAtGrow(i, tmpRegion);
		}
	
		FrameBitmap.Detach();
	}

	bgDC.SelectObject(OldBitmap);
	tmpDC.SelectObject(OldBitmap2);

	m_Alphas.RemoveAll();	// Alpha-masks are not needed after this

	// Set the window region
	if(m_Config.GetRealTransparency()) {
		if(m_Regions.GetUpperBound()!=-1) {
			// Create a temp region coz Windows destroys it after use.
			HRGN tmpRegion;
			tmpRegion=CreateRectRgn(0,0,0,0);
			CombineRgn(tmpRegion, (HRGN)m_Regions.GetAt(m_CurrentFrame), NULL, RGN_COPY);
			SetWindowRgn(tmpRegion, true);
		}
	}

	// Fill the RegionIndices array
	if(m_Config.GetRealTransparency()) {
		HRGN tmpRegion2;
		HRGN destRegion;
		destRegion=CreateRectRgn(0, 0, 0, 0);

		for(i=0; i<=m_Regions.GetUpperBound(); i++) {
			tmpRegion=(HRGN)m_Regions.GetAt(i);
			if(tmpRegion==NULL) continue;

			for(j=0; j<i; j++) {
				tmpRegion2=(HRGN)m_Regions.GetAt(j);
				if(NULLREGION==CombineRgn(destRegion, tmpRegion, tmpRegion2, RGN_XOR)) break;
			}

			m_RegionIndices.SetAtGrow(i, j);

		}
	}
}

/* 
** CreateAlpha
**
** Fills the Source-bitmap with new pixelvalues combined from Background, Source and Alpha.
** All bitmaps MUST be same size and same bitdepth. Only 16, 24 and 32 bit are supported.
**
*/
bool CAnimWindow::CreateAlpha(HBITMAP Source, HBITMAP Alpha, HBITMAP Background)
{
	int i,j;
	LPBYTE BBuffer;
	LPBYTE SBuffer;
	LPBYTE ABuffer;
	BITMAP bm;
	int Value, SColor, BColor, AColor;
	
	GetObject(Background, sizeof(BITMAP), &bm);

	if(bm.bmBitsPixel<16) return false;	// Need at least highcolor bitmaps!

	// All the bitmaps are same size and same colordepth (I hope :)
	BBuffer=new BYTE[bm.bmWidthBytes*bm.bmHeight];
	SBuffer=new BYTE[bm.bmWidthBytes*bm.bmHeight];
	ABuffer=new BYTE[bm.bmWidthBytes*bm.bmHeight];

	GetBitmapBits(Background, bm.bmWidthBytes*bm.bmHeight, BBuffer);
	GetBitmapBits(Source, bm.bmWidthBytes*bm.bmHeight, SBuffer);
	GetBitmapBits(Alpha, bm.bmWidthBytes*bm.bmHeight, ABuffer);

	for(j=0; j<bm.bmHeight; j++) {
		for(i=0; i<bm.bmWidthBytes; i++) {

			if(bm.bmBitsPixel==16) {	// 16bit must be handled a bit differently
				SColor=SBuffer[j*bm.bmWidthBytes+i] | SBuffer[j*bm.bmWidthBytes+i+1]<<8;
				BColor=BBuffer[j*bm.bmWidthBytes+i] | BBuffer[j*bm.bmWidthBytes+i+1]<<8;
				AColor=ABuffer[j*bm.bmWidthBytes+i] | ABuffer[j*bm.bmWidthBytes+i+1]<<8;

				Value=((((SColor&0x0F800)*(AColor&0x01F)+(BColor&0x0F800)*(0x01F-(AColor&0x01F))+0x0F800)>>5)&0x0F800) |
					  ((((SColor&0x007E0)*(AColor&0x01F)+(BColor&0x007E0)*(0x01F-(AColor&0x01F))+0x007E0)>>5)&0x007E0) |
					  ((((SColor&0x0001F)*(AColor&0x01F)+(BColor&0x0001F)*(0x01F-(AColor&0x01F))+0x0001F)>>5)&0x0001F);

				BBuffer[j*bm.bmWidthBytes+i]=(char)(Value&0x000FF);
				BBuffer[j*bm.bmWidthBytes+i+1]=(char)((Value&0x0FF00)>>8);

				i++;	// We'll use 2 bytes at the same time
			} else {
				Value=( SBuffer[j*bm.bmWidthBytes+i]*ABuffer[j*bm.bmWidthBytes+i]+
						BBuffer[j*bm.bmWidthBytes+i]*(0x0FF-ABuffer[j*bm.bmWidthBytes+i]) )>>8;
				BBuffer[j*bm.bmWidthBytes+i]=(char)Value;
			}
		}
	}

	SetBitmapBits(Source, bm.bmWidthBytes*bm.bmHeight, BBuffer);

	delete [] BBuffer;
	delete [] SBuffer;
	delete [] ABuffer;

	return true;
}

/* 
** ShowNextFrame
**
** Blits the next frame on the window
**
*/
void CAnimWindow::ShowNextFrame(CDC* dc)
{
	CBitmap tmpBitmap;
	CBitmap* OldBitmap;
	CDC bgDC;

	// If there's no frames we can exit
	if(m_Bitmaps.GetUpperBound()==-1) return;

	tmpBitmap.Attach((HBITMAP)m_Bitmaps.GetAt(m_CurrentFrame));

	CDC* WinDC=GetWindowDC();
	bgDC.CreateCompatibleDC(WinDC);

	OldBitmap=bgDC.SelectObject(&tmpBitmap);

	if(dc) {
		dc->BitBlt(0, 0, m_Width, m_Height, &bgDC, 0, 0, SRCCOPY);
	} else {
		WinDC->BitBlt(0,0, m_Width, m_Height, &bgDC, 0, 0, SRCCOPY);
	}

	ReleaseDC(WinDC);

	tmpBitmap.Detach();
	bgDC.SelectObject(OldBitmap);
}

/* 
** AnimStateMachine
**
** Function that handles the animation states and frames
**
*/
void CAnimWindow::AnimStateMachine(bool Reset) {
	int OldFrame=m_CurrentFrame;

	if(Reset) OldFrame=-1;

	if(m_State==MOUSEON || m_State==MOUSEOVER || m_Clicked) {
		POINT Pos;
		CRect Rect;
		bool HitOff=false;

		GetCursorPos(&Pos);
		GetWindowRect(&Rect);

		if(m_Config.GetRealTransparency()) {
			HRGN tmpRegion;
			tmpRegion=(HRGN)m_Regions.GetAt(m_CurrentFrame);
			if(!PtInRegion(tmpRegion, Pos.x-Rect.TopLeft().x, Pos.y-Rect.TopLeft().y)) HitOff=true;
		} else if(!Rect.PtInRect(Pos)) {
			HitOff=true;
		}
		
		if(HitOff) {
			KillTimer(2);	// Kill the MouseExecute timer cooz mouse didn't stay over enough amount of time

			// Run MouseOff-command
			if(!m_Config.GetMouseOffCommand().IsEmpty() && m_MouseExecuted) {
				LSExecute(NULL, m_Config.GetMouseOffCommand(), SW_SHOWNORMAL);
			}

			if(m_Clicked) {
				m_Clicked=false;
			} else {
				if(m_Config.GetOffEnable()) {
					m_State=MOUSEOFF;
					if(m_Config.GetOffStartFrame()>m_Config.GetOffStopFrame()) {
						// Reverse Play
						if(m_CurrentFrame<m_Config.GetOffStopFrame() || m_CurrentFrame>m_Config.GetOffStartFrame()) {
							m_CurrentFrame=m_Config.GetOffStartFrame();
						}
					} else {
						// Normal Play
						if(m_CurrentFrame<m_Config.GetOffStartFrame() || m_CurrentFrame>m_Config.GetOffStopFrame()) {
							m_CurrentFrame=m_Config.GetOffStartFrame();
						}
					}
				} else {
					m_State=RUN;
					m_CurrentFrame=m_Config.GetNormalStartFrame();
				}
			}
		}
	}

	switch(m_State) {
	case REFRESH:
		KillTimer(1);
		CreateFrames();
		ShowWindow(SW_SHOWNOACTIVATE);

		if(m_OldState==STOP || m_OldState==QUIT) {
			m_State=m_OldState;
		} else {
			m_State=RUN;
			m_CurrentFrame=m_Config.GetNormalStartFrame();
			SetTimer(1, m_Config.GetDelay(), NULL);	
		}
		break;

	case RUN:
		if(m_Config.GetNormalStartFrame()>m_Config.GetNormalStopFrame()) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_Config.GetNormalStopFrame()) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_Config.GetNormalStopFrame();
				} else {
					m_CurrentFrame=m_Config.GetNormalStartFrame();	// Loop
				}
			}
		} else { 
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_Config.GetNormalStopFrame()) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_Config.GetNormalStopFrame();
				} else {
					m_CurrentFrame=m_Config.GetNormalStartFrame();	// Loop
				}
			}
		}
		break;

	case PLAYFRAMES:
		if(m_PlayStartFrame>m_PlayStopFrame) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_PlayStopFrame) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_PlayStopFrame;
				} else {
					m_CurrentFrame=m_Config.GetNormalStartFrame();
					m_State=RUN;
				}
			}
		} else { 
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_PlayStopFrame) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_PlayStopFrame;
				} else {
					m_CurrentFrame=m_Config.GetNormalStartFrame();
					m_State=RUN;
				}
			}
		}
		break;

	case MOUSEON:
		if(m_Config.GetOnStartFrame()>m_Config.GetOnStopFrame()) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_Config.GetOnStopFrame()) {
				if(!m_Config.GetOverEnable()) {
					m_CurrentFrame++;	// Stay in place
				} else {
					m_State=MOUSEOVER;
					m_CurrentFrame=m_Config.GetOverStartFrame();
				}
			}
		} else {
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_Config.GetOnStopFrame()) {
				if(!m_Config.GetOverEnable()) {
					m_CurrentFrame--;	// Stay in place
				} else {
					m_State=MOUSEOVER;
					m_CurrentFrame=m_Config.GetOverStartFrame();
				}
			}
		}
		break;

	case MOUSEOFF:
		if(m_Config.GetOffStartFrame()>m_Config.GetOffStopFrame()) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_Config.GetOffStopFrame()) {
				m_State=RUN;
				m_CurrentFrame=m_Config.GetNormalStartFrame();
			}
		} else {
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_Config.GetOffStopFrame()) {
				m_State=RUN;
				m_CurrentFrame=m_Config.GetNormalStartFrame();
			}
		}
		break;

	case MOUSEOVER:
		if(m_Config.GetOverStartFrame()>m_Config.GetOverStopFrame()) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_Config.GetOverStopFrame()) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_Config.GetOverStopFrame();
				} else {
					m_CurrentFrame=m_Config.GetOverStartFrame();	// Loop
				}
			}
		} else { 
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_Config.GetOverStopFrame()) {
				if(m_Config.GetRunOnce()) {
					m_CurrentFrame=m_Config.GetOverStopFrame();
				} else {
					m_CurrentFrame=m_Config.GetOverStartFrame();	// Loop
				}
			}
		}
		break;

	case MOUSECLICK:
		if(m_Config.GetClickStartFrame()>m_Config.GetClickStopFrame()) { 
			m_CurrentFrame--; // Reverse Play
			if(m_CurrentFrame<m_Config.GetClickStopFrame()) {
				m_State=RUN;
				m_CurrentFrame=m_Config.GetNormalStartFrame();
			}
		} else {
			m_CurrentFrame++; // Normal Play
			if(m_CurrentFrame>m_Config.GetClickStopFrame()) {
				m_State=RUN;
				m_CurrentFrame=m_Config.GetNormalStartFrame();
			}
		}

		if(m_State==RUN && m_Config.GetWaitClickAnim() && m_Config.GetExecuteEnable()) {
			LSExecute(NULL, m_Config.GetCommand(), SW_SHOWNORMAL);
		}
		break;

	default:
		break;
	}

	if(m_Config.GetRealTransparency() && OldFrame!=m_CurrentFrame) {
		if(m_Regions.GetUpperBound()!=-1) {
			// Change window region only if necessary
			if(m_RegionIndices.GetAt(OldFrame)!=m_RegionIndices.GetAt(m_CurrentFrame)) {
				// Create a temp region coz windows destroys it after use.
				HRGN tmpRegion;
				tmpRegion=CreateRectRgn(0,0,0,0);
				CombineRgn(tmpRegion, (HRGN)m_Regions.GetAt(m_CurrentFrame), NULL, RGN_COPY);
				SetWindowRgn(tmpRegion, true);
			}
		}
	}
	ShowNextFrame(NULL);
}

/* 
** EnableAnim
**
** Enables the animation and goes to start frame
**
*/
void CAnimWindow::EnableAnim() 
{
	SetTimer(1, m_Config.GetDelay(), NULL); 
	m_State=RUN; 
	m_CurrentFrame=m_Config.GetNormalStartFrame(); 
};
 
/* 
** DisableAnim
**
** Disables the animation
**
*/
void CAnimWindow::DisableAnim() 
{ 
	KillTimer(1); 
	m_State=STOP; 
}

void CAnimWindow::PlayFrames(int StartFrame, int StopFrame)
{
	m_State=PLAYFRAMES;
	m_PlayStartFrame=max(StartFrame, 0);
	m_PlayStartFrame=min(m_PlayStartFrame, (int)(m_MaxFrame-1));
	m_PlayStopFrame=max(StopFrame, 0);
	m_PlayStopFrame=min(m_PlayStopFrame, (int)(m_MaxFrame-1));
	m_CurrentFrame=m_PlayStartFrame;
}

/* 
** AddToolTip
**
** Adds the Tooltip-message for  a window
**
*/
void CAnimWindow::AddToolTip() 
{
	static char TextBuffer[256];
	TOOLINFO ti;    // tool information
	RECT r;

	GetClientRect(&r);
	strncpy(TextBuffer, m_Config.GetToolTipText(), 255);
	TextBuffer[255]='\0';

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = m_hWnd;
	ti.hinst = m_DllInstance;
	ti.uId = 0;
	ti.lpszText = TextBuffer;
	ti.rect = r;

	if(m_ControlWindow && m_ControlWindow->GetToolTipWindow().m_hWnd) {
		m_ControlWindow->GetToolTipWindow().SendMessage(TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	}
}

/* 
** RemoveToolTip
**
** Removes the Tooltip message from the window
**
*/
void CAnimWindow::RemoveToolTip() 
{
	TOOLINFO ti;    // tool information

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = m_hWnd;
	ti.hinst = m_DllInstance;
	ti.uId = 0;
	ti.lpszText = NULL;

	if(m_ControlWindow && m_ControlWindow->GetToolTipWindow().m_hWnd) {
		m_ControlWindow->GetToolTipWindow().SendMessage(TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAnimWindow message handlers

void CAnimWindow::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	ShowNextFrame(&dc);
}


void CAnimWindow::OnTimer(UINT nIDEvent) 
{
	CWnd::OnTimer(nIDEvent);

	if(nIDEvent==2) {	// MouseExecute Timer
		if(m_Config.GetMouseOnExecute()) {
			LSExecute(NULL, m_Config.GetMouseOnCommand(), SW_SHOWNORMAL);
		}
		m_MouseExecuted=true;
		KillTimer(2);
	} else {
		AnimStateMachine(false);
	}

	// Eat spurious WM_TIMER messages
//	MSG msg;
//	while(::PeekMessage(&msg, m_hWnd, WM_TIMER, WM_TIMER, PM_REMOVE));
}

void CAnimWindow::OnDestroy() 
{
	KillTimer(1);
	KillTimer(2);

	CWnd::OnDestroy();
}

void CAnimWindow::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	if(!m_Config.GetAlwaysOnTop()) lpwndpos->flags|=SWP_NOZORDER;

	CWnd::OnWindowPosChanging(lpwndpos);
}

void CAnimWindow::OnContextMenu(CWnd*, CPoint point) 
{
	CMenu Menu;

	if(m_Config.GetNoMenu()) return;

	if(Menu.LoadMenu(IDR_MENU1)) {
		CMenu* Popup=Menu.GetSubMenu(0);
		if(m_State==STOP) {
			Popup->CheckMenuItem(0, MF_CHECKED | MF_BYPOSITION);
		}
		Popup->TrackPopupMenu(TPM_RIGHTBUTTON | TPM_LEFTALIGN,
							  point.x, point.y, this);
	}
}

void CAnimWindow::OnRefresh() 
{
	if(m_State!=QUIT) Refresh();
}

void CAnimWindow::OnDisable() 
{
	if(m_State==STOP) {
		SetTimer(1, m_Config.GetDelay(), NULL);	
		m_State=RUN;
	} else {
		KillTimer(1);
		m_State=STOP;
	}
}

void CAnimWindow::OnQuit() 
{
	// We won't actually quit, we'll just hide the window
	KillTimer(1);
	m_State=QUIT;

	ShowWindow(SW_HIDE);
}

void CAnimWindow::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_State==RUN && !m_Clicked) {
		
		// Start MouseOn-command timer
		if(m_Config.GetMouseOnExecute() || m_Config.GetMouseOffExecute()) {
			m_MouseExecuted=false;
			SetTimer(2, m_Config.GetMouseExecuteDelay(), NULL);
		}

		if(m_Config.GetOnEnable()) {
			m_State=MOUSEON;
			m_CurrentFrame=m_Config.GetOnStartFrame();
		} else if(m_Config.GetOverEnable()) {
			m_State=MOUSEOVER;
			m_CurrentFrame=m_Config.GetOverStartFrame();
		}
	}

	MSG TooltipMessage;

	if(m_Config.GetToolTip()) {
        TooltipMessage.hwnd=m_hWnd;
        TooltipMessage.message=WM_MOUSEMOVE;
        TooltipMessage.wParam=(WPARAM)nFlags;
        TooltipMessage.lParam=LOWORD(point.x)+HIWORD(point.y);
		if(m_ControlWindow && m_ControlWindow->GetToolTipWindow().m_hWnd) {
	        m_ControlWindow->GetToolTipWindow().SendMessage(TTM_RELAYEVENT, 0, (LPARAM)&TooltipMessage);
	        m_ControlWindow->GetToolTipWindow().SetWindowPos(&wndTopMost, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
		}
	}
	CWnd::OnMouseMove(nFlags, point);
}

void CAnimWindow::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if(m_Config.GetClickEnable()) {
		m_State=MOUSECLICK;
		m_CurrentFrame=m_Config.GetClickStartFrame();
	}

	m_Clicked=true;

	if(!m_Config.GetWaitClickAnim() && m_Config.GetExecuteEnable()) {
		LSExecute(NULL, m_Config.GetCommand(), SW_SHOWNORMAL);
	}

	CWnd::OnLButtonDown(nFlags, point);
}

void CAnimWindow::OnConfig() 
{
	if(m_Config.DoModal()==IDOK) {
		if(m_Config.GetAlwaysOnTop()) {
			SetWindowPos(&wndTopMost, m_Config.GetXPos(), m_Config.GetYPos(), 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
		} else {
			SetWindowPos(&wndNoTopMost, m_Config.GetXPos(), m_Config.GetYPos(), 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
		}

		// Reset Timer
		KillTimer(1);
		if(m_State!=STOP && m_State!=QUIT) SetTimer(1, m_Config.GetDelay(), NULL);

		// Reset ToolTip
		RemoveToolTip();
		if(m_Config.GetToolTip()) AddToolTip();
	}
}

BOOL CAnimWindow::OnEraseBkgnd(CDC*) 
{
	return TRUE;
}
