// Rainmation.h : main header file for the RAINMATION DLL
//

#if !defined(AFX_RAINMATION_H__20CA1DE6_4840_11D3_A66A_60A350C10000__INCLUDED_)
#define AFX_RAINMATION_H__20CA1DE6_4840_11D3_A66A_60A350C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "..\ls-b24\litestep\wharfdata.h"

#define	APPNAME "Rainmation"
#define	MAX_LINE 80

/////////////////////////////////////////////////////////////////////////////
// CRainmationApp
// See Rainmation.cpp for the implementation of this class
//

class CRainmationApp : public CWinApp
{
public:
	CRainmationApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRainmationApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CRainmationApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

void RAnimEnable(HWND caller, char* arg);
void RAnimDisable(HWND caller, char* arg);
void RAnimToggle(HWND caller, char* arg);
void RAnimRefresh(HWND caller, char* arg);
void RAnimQuit(HWND caller, char* arg);
void RAnimConfig(HWND caller, char* arg);
void RAnimPlayFrames(HWND caller, char* arg);

#ifdef __cplusplus
}
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RAINMATION_H__20CA1DE6_4840_11D3_A66A_60A350C10000__INCLUDED_)
