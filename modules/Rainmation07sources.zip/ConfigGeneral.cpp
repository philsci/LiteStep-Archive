// ConfigGeneral.cpp : implementation file
//

#include "stdafx.h"
#include "Rainmation.h"
#include "ConfigGeneral.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigGeneral property page

IMPLEMENT_DYNCREATE(CConfigGeneral, CPropertyPage)

CConfigGeneral::CConfigGeneral() : CPropertyPage(CConfigGeneral::IDD)
{
	//{{AFX_DATA_INIT(CConfigGeneral)
	m_AlwaysOnTop = FALSE;
	m_Delay = 0;
	m_NoMenu = FALSE;
	m_RunOnce = FALSE;
	m_StartDisabled = FALSE;
	m_ToolTip = FALSE;
	m_ToolTipText = _T("");
	m_RealTransparency = FALSE;
	m_XPos = 0;
	m_YPos = 0;
	//}}AFX_DATA_INIT
}

CConfigGeneral::~CConfigGeneral()
{
}

void CConfigGeneral::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigGeneral)
	DDX_Check(pDX, IDC_ALWAYSONTOP, m_AlwaysOnTop);
	DDX_Text(pDX, IDC_DELAY, m_Delay);
	DDX_Check(pDX, IDC_NOMENU, m_NoMenu);
	DDX_Check(pDX, IDC_RUNONCE, m_RunOnce);
	DDX_Check(pDX, IDC_STARTDISABLED, m_StartDisabled);
	DDX_Check(pDX, IDC_TOOLTIP, m_ToolTip);
	DDX_Text(pDX, IDC_TOOLTIPTEXT, m_ToolTipText);
	DDX_Check(pDX, IDC_TRANSPARENCY, m_RealTransparency);
	DDX_Text(pDX, IDC_XPOS, m_XPos);
	DDX_Text(pDX, IDC_YPOS, m_YPos);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigGeneral, CPropertyPage)
	//{{AFX_MSG_MAP(CConfigGeneral)
	ON_BN_CLICKED(IDC_TOOLTIP, OnTooltip)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

int CConfigGeneral::GetXPos(bool Negative)
{
	CRect r; 

	if(!Negative) {
		GetDesktopWindow()->GetClientRect(&r); 
		if(m_XPos<0) return m_XPos+r.Width(); 
	}
	
	return m_XPos;
}

int CConfigGeneral::GetYPos(bool Negative)
{
	CRect r; 

	if(!Negative) {
		GetDesktopWindow()->GetClientRect(&r); 
		if(m_YPos<0) return m_YPos+r.Height(); 
	}
	
	return m_YPos;
}

/////////////////////////////////////////////////////////////////////////////
// CConfigGeneral message handlers

void CConfigGeneral::OnTooltip() 
{
	UpdateData();

	if(m_ToolTip) {
		GetDlgItem(IDC_TOOLTIPTEXT)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_TOOLTIPTEXT)->EnableWindow(false);
	}	
}

BOOL CConfigGeneral::OnSetActive() 
{
	UpdateData();

	OnTooltip();
	
	return CPropertyPage::OnSetActive();
}
