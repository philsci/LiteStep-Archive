#if !defined(AFX_CONTROLWINDOW_H__20CA1DED_4840_11D3_A66A_60A350C10000__INCLUDED_)
#define AFX_CONTROLWINDOW_H__20CA1DED_4840_11D3_A66A_60A350C10000__INCLUDED_

#include <atlbase.h>
#include "AnimWindow.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ControlWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CControlWindow window

class CControlWindow : public CWnd
{
// Construction
public:
	CControlWindow();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlWindow)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CControlWindow();

	bool Initialize(HWND ParentWnd, HINSTANCE dllInst);

	CAnimWindow* GetAnim(int Index);
	CAnimWindow* GetAnim(char* AnimName);
	CWnd& GetToolTipWindow() { return m_ToolTipWindow; };

	// Generated message map functions
protected:
	//{{AFX_MSG(CControlWindow)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnGetRevID(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	HINSTANCE m_DllInstance;
	int m_StartDelay;

	CPtrArray m_Anims;

	CWnd m_ToolTipWindow;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLWINDOW_H__20CA1DED_4840_11D3_A66A_60A350C10000__INCLUDED_)
