#if !defined(AFX_CONFIGEXECUTE_H__E9175983_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
#define AFX_CONFIGEXECUTE_H__E9175983_DD9A_11D3_92A3_0080AD90417B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfigExecute.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CConfigExecute dialog

class CConfigExecute : public CPropertyPage
{
	DECLARE_DYNCREATE(CConfigExecute)

// Construction
public:
	CConfigExecute();
	~CConfigExecute();

	CString GetCommand() { if(!m_Command.IsEmpty() && m_Command[0]!='"') return '"'+m_Command+'"'; return m_Command; };
	UINT GetMouseExecuteDelay() { return m_MouseExecuteDelay; };
	CString GetMouseOffCommand() { if(!m_MouseOffCommand.IsEmpty() && m_MouseOffCommand[0]!='"') return '"'+m_MouseOffCommand+'"'; return m_MouseOffCommand; };
	BOOL GetMouseOffExecute() { return m_MouseOffExecute; };
	CString GetMouseOnCommand() { if(!m_MouseOnCommand.IsEmpty() && m_MouseOnCommand[0]!='"') return '"'+m_MouseOnCommand+'"'; return m_MouseOnCommand; };
	BOOL GetWaitClickAnim() { return m_WaitClickAnim; };
	BOOL GetMouseOnExecute() { return m_MouseOnExecute; };
	BOOL GetExecuteEnable() { return m_ExecuteEnable; };

	void SetCommand(char* Command ) { m_Command=Command; };
	void SetMouseExecuteDelay(UINT MouseExecuteDelay ) { m_MouseExecuteDelay=MouseExecuteDelay; };
	void SetMouseOffCommand(char* MouseOffCommand ) { m_MouseOffCommand=MouseOffCommand; };
	void SetMouseOffExecute(BOOL MouseOffExecute ) { m_MouseOffExecute=MouseOffExecute; };
	void SetMouseOnCommand(char* MouseOnCommand ) { m_MouseOnCommand=MouseOnCommand; };
	void SetWaitClickAnim(BOOL WaitClickAnim ) { m_WaitClickAnim=WaitClickAnim; };
	void SetMouseOnExecute(BOOL MouseOnExecute ) { m_MouseOnExecute=MouseOnExecute; };
	void SetExecuteEnable(BOOL ExecuteEnable ) { m_ExecuteEnable=ExecuteEnable; };

// Dialog Data
	//{{AFX_DATA(CConfigExecute)
	enum { IDD = IDD_EXECUTE };
	CString	m_Command;
	UINT	m_MouseExecuteDelay;
	CString	m_MouseOffCommand;
	BOOL	m_MouseOffExecute;
	CString	m_MouseOnCommand;
	BOOL	m_WaitClickAnim;
	BOOL	m_MouseOnExecute;
	BOOL	m_ExecuteEnable;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CConfigExecute)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CConfigExecute)
	afx_msg void OnBrowse();
	afx_msg void OnMouseonbrowse();
	afx_msg void OnMouseoffbrowse();
	afx_msg void OnExecute();
	afx_msg void OnMouseonexecute();
	afx_msg void OnMouseoffexecute();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGEXECUTE_H__E9175983_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
