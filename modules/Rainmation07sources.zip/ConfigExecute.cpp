// ConfigExecute.cpp : implementation file
//

#include "stdafx.h"
#include "Rainmation.h"
#include "ConfigExecute.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigExecute property page

IMPLEMENT_DYNCREATE(CConfigExecute, CPropertyPage)

CConfigExecute::CConfigExecute() : CPropertyPage(CConfigExecute::IDD)
{
	//{{AFX_DATA_INIT(CConfigExecute)
	m_Command = _T("");
	m_MouseExecuteDelay = 0;
	m_MouseOffCommand = _T("");
	m_MouseOffExecute = FALSE;
	m_MouseOnCommand = _T("");
	m_WaitClickAnim = FALSE;
	m_MouseOnExecute = FALSE;
	m_ExecuteEnable = FALSE;
	//}}AFX_DATA_INIT
}

CConfigExecute::~CConfigExecute()
{
}

void CConfigExecute::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigExecute)
	DDX_Text(pDX, IDC_COMMAND, m_Command);
	DDX_Text(pDX, IDC_MOUSEDELAY, m_MouseExecuteDelay);
	DDX_Text(pDX, IDC_MOUSEOFFCOMMAND, m_MouseOffCommand);
	DDX_Check(pDX, IDC_MOUSEOFFEXECUTE, m_MouseOffExecute);
	DDX_Text(pDX, IDC_MOUSEONCOMMAND, m_MouseOnCommand);
	DDX_Check(pDX, IDC_WAITCLICK, m_WaitClickAnim);
	DDX_Check(pDX, IDC_MOUSEONEXECUTE, m_MouseOnExecute);
	DDX_Check(pDX, IDC_EXECUTE, m_ExecuteEnable);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigExecute, CPropertyPage)
	//{{AFX_MSG_MAP(CConfigExecute)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_MOUSEONBROWSE, OnMouseonbrowse)
	ON_BN_CLICKED(IDC_MOUSEOFFBROWSE, OnMouseoffbrowse)
	ON_BN_CLICKED(IDC_EXECUTE, OnExecute)
	ON_BN_CLICKED(IDC_MOUSEONEXECUTE, OnMouseonexecute)
	ON_BN_CLICKED(IDC_MOUSEOFFEXECUTE, OnMouseoffexecute)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CConfigExecute message handlers

void CConfigExecute::OnBrowse() 
{
	CFileDialog FileDialog(TRUE);
	
	if(FileDialog.DoModal()) {
		m_Command=FileDialog.GetPathName();
		GetDlgItem(IDC_COMMAND)->SetWindowText(m_Command);
		UpdateData();
	}

}

void CConfigExecute::OnMouseonbrowse() 
{
	CFileDialog FileDialog(TRUE);
	
	if(FileDialog.DoModal()) {
		m_MouseOnCommand=FileDialog.GetPathName();
		GetDlgItem(IDC_MOUSEONCOMMAND)->SetWindowText(m_MouseOnCommand);
		UpdateData();
	}
	
}

void CConfigExecute::OnMouseoffbrowse() 
{
	CFileDialog FileDialog(TRUE);
	
	if(FileDialog.DoModal()) {
		m_MouseOffCommand=FileDialog.GetPathName();
		GetDlgItem(IDC_MOUSEOFFCOMMAND)->SetWindowText(m_MouseOffCommand);
		UpdateData();
	}
}

void CConfigExecute::OnExecute() 
{
	UpdateData();

	if(m_ExecuteEnable) {
		GetDlgItem(IDC_COMMAND)->EnableWindow(true);
		GetDlgItem(IDC_BROWSE)->EnableWindow(true);
		GetDlgItem(IDC_WAITCLICK)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_COMMAND)->EnableWindow(false);
		GetDlgItem(IDC_BROWSE)->EnableWindow(false);
		GetDlgItem(IDC_WAITCLICK)->EnableWindow(false);
	}	
}

void CConfigExecute::OnMouseonexecute() 
{
	UpdateData();

	if(m_MouseOnExecute) {
		GetDlgItem(IDC_MOUSEONCOMMAND)->EnableWindow(true);
		GetDlgItem(IDC_MOUSEONBROWSE)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_MOUSEONCOMMAND)->EnableWindow(false);
		GetDlgItem(IDC_MOUSEONBROWSE)->EnableWindow(false);
	}	

	if(!m_MouseOffExecute && !m_MouseOnExecute) {
		GetDlgItem(IDC_MOUSEDELAY)->EnableWindow(false);
	} else {
		GetDlgItem(IDC_MOUSEDELAY)->EnableWindow(true);
	}
}

void CConfigExecute::OnMouseoffexecute() 
{
	UpdateData();

	if(m_MouseOffExecute) {
		GetDlgItem(IDC_MOUSEOFFCOMMAND)->EnableWindow(true);
		GetDlgItem(IDC_MOUSEOFFBROWSE)->EnableWindow(true);
	} else {
		GetDlgItem(IDC_MOUSEOFFCOMMAND)->EnableWindow(false);
		GetDlgItem(IDC_MOUSEOFFBROWSE)->EnableWindow(false);
	}	
	
	if(!m_MouseOffExecute && !m_MouseOnExecute) {
		GetDlgItem(IDC_MOUSEDELAY)->EnableWindow(false);
	} else {
		GetDlgItem(IDC_MOUSEDELAY)->EnableWindow(true);
	}
}

BOOL CConfigExecute::OnSetActive() 
{
	UpdateData();

	OnExecute();
	OnMouseoffexecute();
	OnMouseonexecute();
	
	return CPropertyPage::OnSetActive();
}
