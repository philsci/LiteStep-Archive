#if !defined(AFX_CONFIGRANGES_H__E9175982_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
#define AFX_CONFIGRANGES_H__E9175982_DD9A_11D3_92A3_0080AD90417B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConfigRanges.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CConfigRanges dialog

class CConfigRanges : public CPropertyPage
{
	DECLARE_DYNCREATE(CConfigRanges)

// Construction
public:
	CConfigRanges();
	~CConfigRanges();

	BOOL GetClickEnable() { return m_ClickEnable; };
	UINT GetClickStartFrame() { return m_ClickStartFrame; };
	UINT GetNormalStartFrame() { return m_NormalStartFrame; };
	UINT GetOffStartFrame() { return m_OffStartFrame; };
	UINT GetOnStartFrame() { return m_OnStartFrame; };
	BOOL GetOverEnable() { return m_OverEnable; };
	UINT GetOverStartFrame() { return m_OverStartFrame; };
	UINT GetOverStopFrame() { return m_OverStopFrame; };
	UINT GetOnStopFrame() { return m_OnStopFrame; };
	BOOL GetOnEnable() { return m_OnEnable; };
	BOOL GetOffEnable() { return m_OffEnable; };
	UINT GetOffStopFrame() { return m_OffStopFrame; };
	UINT GetNormalStopFrame() { return m_NormalStopFrame; };
	UINT GetClickStopFrame() { return m_ClickStopFrame; };

	void SetClickEnable(BOOL ClickEnable ) { m_ClickEnable=ClickEnable; };
	void SetClickStartFrame(UINT ClickStartFrame ) { m_ClickStartFrame=ClickStartFrame; };
	void SetNormalStartFrame(UINT NormalStartFrame ) { m_NormalStartFrame=NormalStartFrame; };
	void SetOffStartFrame(UINT OffStartFrame ) { m_OffStartFrame=OffStartFrame; };
	void SetOnStartFrame(UINT OnStartFrame ) { m_OnStartFrame=OnStartFrame; };
	void SetOverEnable(BOOL OverEnable ) { m_OverEnable=OverEnable; };
	void SetOverStartFrame(UINT OverStartFrame ) { m_OverStartFrame=OverStartFrame; };
	void SetOverStopFrame(UINT OverStopFrame ) { m_OverStopFrame=OverStopFrame; };
	void SetOnStopFrame(UINT OnStopFrame ) { m_OnStopFrame=OnStopFrame; };
	void SetOnEnable(BOOL OnEnable ) { m_OnEnable=OnEnable; };
	void SetOffEnable(BOOL OffEnable ) { m_OffEnable=OffEnable; };
	void SetOffStopFrame(UINT OffStopFrame ) { m_OffStopFrame=OffStopFrame; };
	void SetNormalStopFrame(UINT NormalStopFrame ) { m_NormalStopFrame=NormalStopFrame; };
	void SetClickStopFrame(UINT ClickStopFrame ) { m_ClickStopFrame=ClickStopFrame; };

	CSliderCtrl& GetOverStopSlider() { return m_OverStopSlider; };
	CSliderCtrl& GetOverStartSlider() { return m_OverStartSlider; };
	CSliderCtrl& GetOnStopSlider() { return m_OnStopSlider; };
	CSliderCtrl& GetOnStartSlider() { return m_OnStartSlider; };
	CSliderCtrl& GetOffStopSlider() { return m_OffStopSlider; };
	CSliderCtrl& GetOffStartSlider() { return m_OffStartSlider; };
	CSliderCtrl& GetNormalStopSlider() { return m_NormalStopSlider; };
	CSliderCtrl& GetNormalStartSlider() { return m_NormalStartSlider; };
	CSliderCtrl& GetClickStopSlider() { return m_ClickStopSlider; };
	CSliderCtrl& GetClickStartSlider() { return m_ClickStartSlider; };

// Dialog Data
	//{{AFX_DATA(CConfigRanges)
	enum { IDD = IDD_RANGES };
	CSliderCtrl	m_OffStartSlider;
	CSliderCtrl	m_OverStopSlider;
	CSliderCtrl	m_OverStartSlider;
	CSliderCtrl	m_OnStopSlider;
	CSliderCtrl	m_OnStartSlider;
	CSliderCtrl	m_OffStopSlider;
	CSliderCtrl	m_NormalStopSlider;
	CSliderCtrl	m_NormalStartSlider;
	CSliderCtrl	m_ClickStopSlider;
	CSliderCtrl	m_ClickStartSlider;
	BOOL	m_ClickEnable;
	UINT	m_ClickStartFrame;
	UINT	m_NormalStartFrame;
	UINT	m_OffStartFrame;
	UINT	m_OnStartFrame;
	BOOL	m_OverEnable;
	UINT	m_OverStartFrame;
	UINT	m_OverStopFrame;
	UINT	m_OnStopFrame;
	BOOL	m_OnEnable;
	BOOL	m_OffEnable;
	UINT	m_OffStopFrame;
	UINT	m_NormalStopFrame;
	UINT	m_ClickStopFrame;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CConfigRanges)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CConfigRanges)
	afx_msg void OnOnrange();
	afx_msg void OnOffrange();
	afx_msg void OnOverrange();
	afx_msg void OnClickrange();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIGRANGES_H__E9175982_DD9A_11D3_92A3_0080AD90417B__INCLUDED_)
