#if !defined(AFX_CONFIG_H__4D060FC1_DE4C_11D3_92A3_0080AD90417B__INCLUDED_)
#define AFX_CONFIG_H__4D060FC1_DE4C_11D3_92A3_0080AD90417B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Config.h : header file
//

#include "ConfigGeneral.h"
#include "ConfigExecute.h"
#include "ConfigRanges.h"

/////////////////////////////////////////////////////////////////////////////
// CConfig

class CConfig : public CPropertySheet
{
	DECLARE_DYNAMIC(CConfig)

// Construction
public:
	CConfig(CString& Path, char* Anim, CWnd* pParent = NULL);   // standard constructor

	void ReadConfig();
	void WriteConfig();

	UINT GetFrameCount() { return m_FrameCount; };

	// General
	BOOL GetNoMenu() { return m_ConfigGeneral.GetNoMenu(); };
	BOOL GetRealTransparency() { return m_ConfigGeneral.GetRealTransparency(); };
	int GetXPos(bool Negative=false) { return m_ConfigGeneral.GetXPos(Negative); };
	int GetYPos(bool Negative=false) { return m_ConfigGeneral.GetYPos(Negative); };
	BOOL GetAlwaysOnTop() { return m_ConfigGeneral.GetAlwaysOnTop(); };
	BOOL GetStartDisabled() { return m_ConfigGeneral.GetStartDisabled(); };
	BOOL GetRunOnce() { return m_ConfigGeneral.GetRunOnce(); };
	BOOL GetToolTip() { return m_ConfigGeneral.GetToolTip(); };
	CString& GetToolTipText() { return m_ConfigGeneral.GetToolTipText(); };
	UINT GetDelay() { return m_ConfigGeneral.GetDelay(); };

	// Execute
	BOOL GetExecuteEnable() { return m_ConfigExecute.GetExecuteEnable(); };
	CString GetCommand() { return m_ConfigExecute.GetCommand(); };
	BOOL GetMouseOnExecuteEnable() { return m_ConfigExecute.GetExecuteEnable(); };
	CString GetMouseOnCommand() { return m_ConfigExecute.GetMouseOnCommand(); };
	BOOL GetMouseOffExecuteEnable() { return m_ConfigExecute.GetExecuteEnable(); };
	CString GetMouseOffCommand() { return m_ConfigExecute.GetMouseOffCommand(); };
	int GetMouseExecuteDelay() { return m_ConfigExecute.GetMouseExecuteDelay(); };
	BOOL GetWaitClickAnim() { return m_ConfigExecute.GetWaitClickAnim(); };
	int GetMouseOnExecute() { return m_ConfigExecute.GetMouseOnExecute(); };
	int GetMouseOffExecute() { return m_ConfigExecute.GetMouseOffExecute(); };

	// Ranges
	int GetNormalStopFrame() { return m_ConfigRanges.GetNormalStopFrame(); };
	int GetNormalStartFrame() { return m_ConfigRanges.GetNormalStartFrame(); };
	BOOL GetOverEnable() { return m_ConfigRanges.GetOverEnable(); };
	int GetOverStopFrame() { return m_ConfigRanges.GetOverStopFrame(); };
	int GetOverStartFrame() { return m_ConfigRanges.GetOverStartFrame(); };
	BOOL GetOnEnable() { return m_ConfigRanges.GetOnEnable(); };
	int GetOnStopFrame() { return m_ConfigRanges.GetOnStopFrame(); };
	int GetOnStartFrame() { return m_ConfigRanges.GetOnStartFrame(); };
	BOOL GetOffEnable() { return m_ConfigRanges.GetOffEnable(); };
	int GetOffStopFrame() { return m_ConfigRanges.GetOffStopFrame(); };
	int GetOffStartFrame() { return m_ConfigRanges.GetOffStartFrame(); };
	BOOL GetClickEnable() { return m_ConfigRanges.GetClickEnable(); };
	int GetClickStopFrame() { return m_ConfigRanges.GetClickStopFrame(); };
	int GetClickStartFrame() { return m_ConfigRanges.GetClickStartFrame(); };


	void SetFrameCount(int FrameCount) { m_FrameCount=FrameCount; };

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConfig)
	public:
	virtual int DoModal();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CConfig();

	// Generated message map functions
protected:
	//{{AFX_MSG(CConfig)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	// Dialog pages
	CConfigGeneral m_ConfigGeneral;
	CConfigExecute m_ConfigExecute;
	CConfigRanges m_ConfigRanges;

	UINT m_FrameCount;
	CString m_Path;
	CString m_Anim;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONFIG_H__4D060FC1_DE4C_11D3_92A3_0080AD90417B__INCLUDED_)
