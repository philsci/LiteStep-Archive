#if !defined(AFX_ANIMWINDOW_H__10178B65_4848_11D3_A66A_708650C1FFFF__INCLUDED_)
#define AFX_ANIMWINDOW_H__10178B65_4848_11D3_A66A_708650C1FFFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// AnimWindow.h : header file
//

#include <afxtempl.h> 
#include "Config.h"

class CControlWindow;

/////////////////////////////////////////////////////////////////////////////
// CAnimWindow window

class CAnimWindow : public CWnd
{
// Construction
public:
	CAnimWindow(char* Name, CControlWindow* ControlWindow);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnimWindow)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAnimWindow();
	bool Initialize();

	void AddBitmap(int Frame, HBITMAP Bitmap) { m_Bitmaps.SetAtGrow(Frame, Bitmap); };

	int GetWidth() { return m_Width; };
	int GetHeight() { return m_Height; };
	CString& GetName() { return m_Name; };
	int GetMaxFrame() { return m_MaxFrame; };
	CConfig& GetConfig() { return m_Config; };

	void SetInstance(HINSTANCE DllInstance ) { m_DllInstance=DllInstance; };

	void PlayFrames(int StartFrame, int StopFrame);

	void EnableAnim();
	void DisableAnim();
	void ToggleAnim() { OnDisable(); };
	void RefreshAnim() { Refresh(); };
	void QuitAnim() { OnQuit(); };
	void ConfigAnim() { OnConfig(); };

	void AddToolTip();
	void RemoveToolTip();

	static void SetPixmapPath(CString& PixmapPath ) { C_PixmapPath=PixmapPath; };

	// Generated message map functions
protected:
	//{{AFX_MSG(CAnimWindow)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnRefresh();
	afx_msg void OnDisable();
	afx_msg void OnQuit();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnConfig();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	enum STATE {
		STOP,
		RUN,
		QUIT,
		REFRESH,
		MOUSEON,
		MOUSEOFF,
		MOUSEOVER,
		MOUSECLICK,
		PLAYFRAMES
	};
	
	bool ReadAnim();
	void ShowNextFrame(CDC* dc);
	void CreateFrames();
	void Refresh();
	void AnimStateMachine(bool Reset);
	bool CreateAlpha(HBITMAP Background, HBITMAP Source, HBITMAP Alpha);

	HINSTANCE m_DllInstance;

	int m_Height;
	int m_Width;
	CPtrArray m_Alphas;
	CPtrArray m_Bitmaps;
	CPtrArray m_Regions;
	CArray<int, int> m_RegionIndices;

	int m_CurrentFrame;
	UINT m_MaxFrame;

	CString m_Name;

	STATE m_State;
	STATE m_OldState;

	int m_PlayStartFrame;
	int m_PlayStopFrame;

	bool m_Clicked;
	bool m_MouseExecuted;

	CConfig m_Config;

	CControlWindow* m_ControlWindow;

	static CString C_PixmapPath;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANIMWINDOW_H__10178B65_4848_11D3_A66A_708650C1FFFF__INCLUDED_)
