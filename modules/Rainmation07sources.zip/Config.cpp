// Config.cpp : implementation file
//

#include "stdafx.h"
#include "Rainmation.h"
#include "Config.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfig

IMPLEMENT_DYNAMIC(CConfig, CPropertySheet)

CConfig::CConfig(CString& Path, char* Anim, CWnd* pParent) : CPropertySheet(Anim, pParent, 0)
{
	m_FrameCount=0;
	m_Path=Path;
	m_Anim=Anim;

	AddPage(&m_ConfigGeneral);
	AddPage(&m_ConfigExecute);
	AddPage(&m_ConfigRanges);
	SetTitle(m_Anim);

	m_psh.dwFlags|=PSH_NOAPPLYNOW;
}

CConfig::~CConfig()
{
}


BEGIN_MESSAGE_MAP(CConfig, CPropertySheet)
	//{{AFX_MSG_MAP(CConfig)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CConfig::ReadConfig()
{
	CString INIPath;
	char Command[256];

	INIPath=m_Path+m_Anim+"\\"+"Rainmation.ini";

	// General
	m_ConfigGeneral.SetDelay(GetPrivateProfileInt( "Rainmation", "Delay", 50, INIPath ));
	m_ConfigGeneral.SetXPos(GetPrivateProfileInt( "Rainmation", "X", 0, INIPath ));
	m_ConfigGeneral.SetYPos(GetPrivateProfileInt( "Rainmation", "Y", 0, INIPath ));
	m_ConfigGeneral.SetAlwaysOnTop(GetPrivateProfileInt( "Rainmation", "AlwaysOnTop", 0, INIPath ));
	m_ConfigGeneral.SetRealTransparency(GetPrivateProfileInt( "Rainmation", "RealTransparency", 0, INIPath ));
	m_ConfigGeneral.SetNoMenu(GetPrivateProfileInt( "Rainmation", "NoMenu", 0, INIPath ));
	m_ConfigGeneral.SetRunOnce(GetPrivateProfileInt( "Rainmation", "RunOnce", 0, INIPath ));
	m_ConfigGeneral.SetStartDisabled(GetPrivateProfileInt( "Rainmation", "StartDisabled", 0, INIPath ));
	m_ConfigGeneral.SetToolTip(GetPrivateProfileInt( "Rainmation", "ToolTip", 0, INIPath ));
	if(0==GetPrivateProfileString( "Rainmation", "ToolTipText", "", Command, 255, INIPath )) {
		strcpy(Command, m_Anim);
	}
	m_ConfigGeneral.SetToolTipText(Command);


	// Execute
	m_ConfigExecute.SetExecuteEnable(GetPrivateProfileInt( "Rainmation", "ExecuteEnable", 0, INIPath ));
	GetPrivateProfileString( "Rainmation", "Execute", "", Command, 255, INIPath );
	m_ConfigExecute.SetCommand(Command);
	m_ConfigExecute.SetMouseOnExecute(GetPrivateProfileInt( "Rainmation", "MouseOnExecuteEnable", 0, INIPath ));
	GetPrivateProfileString( "Rainmation", "MouseOnExecute", "", Command, 255, INIPath );
	m_ConfigExecute.SetMouseOnCommand(Command);
	m_ConfigExecute.SetMouseOffExecute(GetPrivateProfileInt( "Rainmation", "MouseOffExecuteEnable", 0, INIPath ));
	GetPrivateProfileString( "Rainmation", "MouseOffExecute", "", Command, 255, INIPath );
	m_ConfigExecute.SetMouseOffCommand(Command);
	m_ConfigExecute.SetMouseExecuteDelay(GetPrivateProfileInt( "Rainmation", "MouseExecuteDelay", 0, INIPath ));
	m_ConfigExecute.SetWaitClickAnim(GetPrivateProfileInt( "Rainmation", "WaitClickAnim", 0, INIPath ));


	// Ranges
	m_ConfigRanges.SetNormalStartFrame(GetPrivateProfileInt( "Rainmation", "NormalStartFrame", 0, INIPath ));
	m_ConfigRanges.SetNormalStopFrame(GetPrivateProfileInt( "Rainmation", "NormalStopFrame", 0, INIPath ));
	m_ConfigRanges.SetOnEnable(GetPrivateProfileInt( "Rainmation", "OnEnable", 0, INIPath ));
	m_ConfigRanges.SetOnStartFrame(GetPrivateProfileInt( "Rainmation", "OnStartFrame", 0, INIPath ));
	m_ConfigRanges.SetOnStopFrame(GetPrivateProfileInt( "Rainmation", "OnStopFrame", 0, INIPath ));
	m_ConfigRanges.SetOffEnable(GetPrivateProfileInt( "Rainmation", "OffEnable", 0, INIPath ));
	m_ConfigRanges.SetOffStartFrame(GetPrivateProfileInt( "Rainmation", "OffStartFrame", 0, INIPath ));
	m_ConfigRanges.SetOffStopFrame(GetPrivateProfileInt( "Rainmation", "OffStopFrame", 0, INIPath ));
	m_ConfigRanges.SetOverEnable(GetPrivateProfileInt( "Rainmation", "OverEnable", 0, INIPath ));
	m_ConfigRanges.SetOverStartFrame(GetPrivateProfileInt( "Rainmation", "OverStartFrame", 0, INIPath ));
	m_ConfigRanges.SetOverStopFrame(GetPrivateProfileInt( "Rainmation", "OverStopFrame", 0, INIPath ));
	m_ConfigRanges.SetClickEnable(GetPrivateProfileInt( "Rainmation", "ClickEnable", 0, INIPath ));
	m_ConfigRanges.SetClickStartFrame(GetPrivateProfileInt( "Rainmation", "ClickStartFrame", 0, INIPath ));
	m_ConfigRanges.SetClickStopFrame(GetPrivateProfileInt( "Rainmation", "ClickStopFrame", 0, INIPath ));

}

void CConfig::WriteConfig()
{
	CString INIPath;
	char tmpSz[256];
	INIPath=m_Path+m_Anim+"\\"+"Rainmation.ini";

	// General
	sprintf(tmpSz, "%i", GetDelay());
	WritePrivateProfileString( "Rainmation", "Delay", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetXPos(true));
	WritePrivateProfileString( "Rainmation", "X", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetYPos(true));
	WritePrivateProfileString( "Rainmation", "Y", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetAlwaysOnTop());
	WritePrivateProfileString( "Rainmation", "AlwaysOnTop", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetRealTransparency());
	WritePrivateProfileString( "Rainmation", "RealTransparency", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetNoMenu());
	WritePrivateProfileString( "Rainmation", "NoMenu", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetRunOnce());
	WritePrivateProfileString( "Rainmation", "RunOnce", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetStartDisabled());
	WritePrivateProfileString( "Rainmation", "StartDisabled", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetToolTip());
	WritePrivateProfileString( "Rainmation", "ToolTip", tmpSz, INIPath );
	WritePrivateProfileString( "Rainmation", "ToolTipText", GetToolTipText(), INIPath );

	
	// Execute
	sprintf(tmpSz, "%i", GetWaitClickAnim());
	WritePrivateProfileString( "Rainmation", "WaitClickAnim", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetExecuteEnable());
	WritePrivateProfileString( "Rainmation", "ExecuteEnable", tmpSz, INIPath );
	WritePrivateProfileString( "Rainmation", "Execute", GetCommand(), INIPath );
	sprintf(tmpSz, "%i", GetMouseOnExecuteEnable());
	WritePrivateProfileString( "Rainmation", "MouseOnExecuteEnable", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetMouseOffExecuteEnable());
	WritePrivateProfileString( "Rainmation", "MouseOffExecuteEnable", tmpSz, INIPath );
	WritePrivateProfileString( "Rainmation", "MouseOnExecute", GetMouseOnCommand(), INIPath );
	WritePrivateProfileString( "Rainmation", "MouseOffExecute", GetMouseOffCommand(), INIPath );
	sprintf(tmpSz, "%i", GetMouseExecuteDelay());
	WritePrivateProfileString( "Rainmation", "MouseExecuteDelay", tmpSz, INIPath );
	
	
	// Ranges
	sprintf(tmpSz, "%i", GetNormalStartFrame());
	WritePrivateProfileString( "Rainmation", "NormalStartFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetNormalStopFrame());
	WritePrivateProfileString( "Rainmation", "NormalStopFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetClickEnable());
	WritePrivateProfileString( "Rainmation", "ClickEnable", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetClickStartFrame());
	WritePrivateProfileString( "Rainmation", "ClickStartFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetClickStopFrame());
	WritePrivateProfileString( "Rainmation", "ClickStopFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOffEnable());
	WritePrivateProfileString( "Rainmation", "OffEnable", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOffStartFrame());
	WritePrivateProfileString( "Rainmation", "OffStartFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOffStopFrame());
	WritePrivateProfileString( "Rainmation", "OffStopFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOnEnable());
	WritePrivateProfileString( "Rainmation", "OnEnable", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOnStartFrame());
	WritePrivateProfileString( "Rainmation", "OnStartFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOnStopFrame());
	WritePrivateProfileString( "Rainmation", "OnStopFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOverEnable());
	WritePrivateProfileString( "Rainmation", "OverEnable", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOverStartFrame());
	WritePrivateProfileString( "Rainmation", "OverStartFrame", tmpSz, INIPath );
	sprintf(tmpSz, "%i", GetOverStopFrame());
	WritePrivateProfileString( "Rainmation", "OverStopFrame", tmpSz, INIPath );

	WritePrivateProfileString( NULL, NULL, NULL, INIPath );	// FLUSH
}

/////////////////////////////////////////////////////////////////////////////
// CConfig message handlers

int CConfig::DoModal() 
{
	int value;
	
	ReadConfig();

	value=CPropertySheet::DoModal();

	if(value==IDOK) {
		WriteConfig();
	} else {
		// Reading the old config discards all changes
		ReadConfig();
	}

	return value;
}


