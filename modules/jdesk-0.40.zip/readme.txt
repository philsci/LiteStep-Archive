jDesk 0.40 - 99.08.13 - written by Chris Rempel (jugg)
jugg@dylern.com - http://aster.omega2.com/jugg/


Step.rc Commands:

; Sets the Work space Area for maximized applications (defaults to: "0,-50,0,-50")
: (order of values are: left,right,top,bottom. Negative values are valid.)
; (see the example section for a detailed explanation and sample setups.)

jDeskSetWorkArea "n,n,n,n"


; You can bind your mouse buttons to litestep !bang commands as well as programs using the following settings. (they all default to: "!None" accept jDeskMButton2 which defaults to "!Popup")
; (see the example section for a detailed explanation and sample setups.)

jDeskMButton1 "command"
jDeskMButton2 "command"
jDeskMButton3 "command"
jDeskCtrlMButton1 "command"
jDeskCtrlMButton2 "command"
jDeskCtrlMButton3 "command"
jDeskShiftMButton1 "command"
jDeskShiftMButton2 "command"
jDeskShiftMButton3 "command"


; Set to execute the mouse button commands on MouseDown instead of MouseUp.

jDeskOnMouseDown


; Use to set your Work Area on the fly
: (order of values are: left,right,top,bottom. Negative values are valid.)
; (see the example section for a detailed explanation and sample setups.)

!jDeskSetWorkArea "n,n,n,n"


; Use to reset your Work Area to the settings specified in the step.rc on the fly
; (This is not a recycle, it does not read new settings from the step.rc if you have changed them since your previous recycle of LiteStep)

!jDeskResetWorkArea


============
==EXAMPLES==
============

The following will set your Application Work Area 
=================================================
; NOTE: no opposite values can be closer then 101 pixels, so you can not specify "0,100,0,100" otherwise it will default to your full screen size.


; sets to your full screen width with a 20pixel space at the bottom of your screen in height.

jDeskSetWorkArea "0,0,0,-20"


; sets a 500x500 work area box anchored to the bottom right of your screen.

jDeskSetWorkArea "-500,0,-500,0"


; sets a 400x400 work area box anchored to the top left of your screen.

jDeskSetWorkArea "0,400,0,400"



The following explains the use of the jDeskxxxButtons
=====================================================
NOTE: You can not currently run a !bang command and program from the same line. However, you can run multiple !bang commands with or without parameters on a single line. You can also run a single program with or without parameters. Be SURE to suround the COMPLETE "command" with QUOTES. Anything not between a single set of quotes ("") are ignored. In other words do NOT use: jDeskMButton1 "c:\my path\notepad" c:\docs\text.txt   This will NOT work! You should use: jDeskMButton1 "c:\my path\notepad*c:\docs\text.txt"  This WILL work.


; sets your right mouse button to run "command.com"

jDeskMButton2 "command.com"


; sets your left mouse button to run "notepad.exe" with "c:\documents\readme.txt" as the parameter

jDeskMButton1 "notepad.exe*c:\documents\readme.txt"


; sets your right mouse button while the SHIFT key is held down to run "winzip.exe" located in a path with long file names

jDeskShiftMButton2 "c:\program files\winzip\winzip32.exe"


; does the same as above, but with opening "test.zip" which is also located in a long file name path

jDeskShiftMButton2 "c:\program files\winzip\winzip32.exe*c:\my zip files\test.zip"


; Runs multiple !bang commands using your middle mouse button with the CTRL key held down, even those that take parameters.

jDeskCtrlMButton3 "!jDeskSetWorkArea*20,-10,50,-10 !ToggleTasks !ToggleCommand !About Detailed"


; Basically how it works, is that you can specify the initial command, and then if you want to run multiple bang commands or set some paramters, you must follow the initial command immediatly by a "*" character, then put everything else after that. You can use ONLY ONE "*" character. If you use more then one, everything after then second "*" character is ignored, so do not do it.



The following explains the use of the !jDeskWetWorkArea bang command
====================================================================
; This is utilized exactly like the non !bang command version "jDeskSetWorkArea", the following is a single example anyway, utilizing a *HotKey.
; will set your work area to a 400x400 box in the bottom left of your screen when pressing Win+S

*Hotkey Win S !jDeskSetWorkArea "-400,0,-400,0"



Additional Notes and Tips
=========================
jDesk does NOT have a Systray OR TaskBar. You must download alternate modules to have access to those features. The suggested modules are systray.dll available at http://maduin.dasoft.org/ and tasks.dll available at http://aster.omega2.com/jugg/software/

Also, jDesk does NOT hide your minimized Application bars. If you have a TaskManager that does not perform that feature for you, you should contact the author and ask them to implement it. Tasks.dll is capable of this by adding the command "TasksHideMinAppBar" to your step.rc

If you have any features that you would like to see in jDesk.dll please let me know. However, think through your idea, and decided for yourself, if you really think it is a feature that should reside in a Desktop module.  A Taskbar and System Tray are not good suggestions, and will not be implemented, neither will jDesk implement the ability to hide Minimized App bars.


Send all comments, suggestions, bugs, praise to jugg@dylern.com
http://aster.omega2.com/jugg/