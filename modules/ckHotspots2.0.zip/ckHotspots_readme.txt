//============================================================
//ckHotspots.dll v2.0
//------------------------------------------------------------
//Filename	: 	ckHotspots.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This is a really simple hotpots module that let you define hotspots
//	and what to do when you enter or leave the spot
//
//------------------------------------------------------------
/****************** v2.0		2001/05/28************/
//	Now second version adds the ability to add and remove spots on the fly and to turn spots ON and OFF, and
//	you can also toggle them.
//	Second version also employs a differnt mouse coordinate trapping technique by installing a mouse hook.
//	I found that it feels a bit slower to use the hook, but if that works best for you then.  The only benefit
//	would be that you get instantaneous hotspot reaction.  So i would prefer that you specify ckHotspotsVersion1Style 
//	to make things more efficient.
//
//	*warning: YOU DO NOT NEED TO CHANGE ANY CONFIGUARTION FROM VERSION ONE AND IT'LL
//		STILL WORK! unless of course you want to use the new functionalities.
//
//	Step.rc config
//		Updated
//		-*ckHotspot x y width height [action to perform when mouse enters] [action to perform when mouse leaves] [name] on/off
//			>name is the new addition so you can have more control over your spots ;-)
//			just specify a text here, and the spot will be assigned with that name.  You'll need
//			the name to toggle it and stuff.  and remember, name is totally OPTIONAL! that means
//			you assign name only when you want to control them.
//			>the on/off is for you to specify the spot's initial status.  you can activate the spot after the module
//			is loaded by putting "on" or "true" or "yes" otherwise you can put "off", "false", "no".  If you didn't
//			specify anything, the spot will default to be on or activated.
//		-ckHotspotsVersion1Style
//			>By putting this in the step.rc you'll making the module to use the version one mouse trapping
//			engine.  Use it to tweak the module and see which works best for you.
//
//
//	Bang Commands
//		!HotspotON "name"
//		!HotspotOFF "name"
//		!HotspotToggle "name"
//			Description: these three are pretty self explanatory.  The name parameter is the name you assign to the spot in
//			step.rc.  You can turn different spots on and off by doing something like:
//				!HotspotON "mysexyspot" ; this will turn your sexy spot on.
//				!HotspotOFF "myGspot" ; this will turn your G spot off so it'll stop functioning until you turn it on again.
//			If the "name" parameter is not supplied, then all the spots are effected.
//				!HotspotON to turn on all the spots at once
//		!HotspotAdd x y width height [action to perform when mouse enters] [action to perform when mouse leaves] [name] on/off
//		!HotspotRemove "name"
//			Description: these two bangs allows you to add and remove spots dynamically.
//			The arguments for HotspotAdd is exactly the same as the *ckHotspot config in step.rc
//			section. So like:
//			!HotspotAdd -32 -32 0 0 !VWMRight !none
//			will add a spot located at -32, -32 and it's width and height are spanned to the rest of the screen.
//
//		!HotspotDebug
//			Description: This bang is for debug purpose only.  When you execute this bang, all your spots defintion
//			will be popped up in message box, so you can check if they are correct or not.
/****************** v1.0		2000/10/28************/
//	First release
//		I coded it up because hotspots.dll doesn't let me click through the spots, and
//		i just wanted something simple to achieve the autohide feature in some modules
//		that didn't implement it.  This hotspots module is a lot smaller than hotspots.dll
//		because of its simplicity and thus the speed.
//
//	Step.rc config
//		-ckHotspotsTimeOut #
//			>define how frequent the module will check the mouse, the smaller the more frequent, (default: 100)
//		-*ckHotspot x y width height [action to perform when mouse enters] [action to perform when mouse leaves]
//			>x, y, width and height can be negative
//			>x, y specifies the left top hotspot box
//			>width and height specifies the width and height for the hotspot box.  If you specify either one of them to be 0
//			the box width or height will span to the whole screen.
//			>the next two action can be bang commands or a path to a program
//	
//
//	*Important: none of your configurations from your Hotspots module will work because this has nothing
//	to do with the hotspots module
//
//
//------------------------------------------------------------
//Example Step.rc config (my config):
//	*ckHotspot -32 -32 0 0 !VWMRight !none ;the box is located at -32, -32 and it's width and height are spanned to the rest of the screen.
//	*ckHotspot 0 -32 32 0 !VWMLeft !none ;the box is located at 0, -32, and it's height is spanned to the bottom of the screen.
//	*ckHotspot 0 20 16 800 !QBoxShow !QBoxHide 
//
//
//-----------------------------------------------------------
