#include "../litestep/wharfdata.h"

class ListItem
{
private:
	HWND hwnd;
	HICON icon;

public:
	ListItem() { next = 0; }
	HWND GetWnd() { return hwnd; }
	HICON GetIcon() { return icon; }
	HICON GetWindowIcon(HWND hwnd);
	void SetWnd(HWND wnd);
	void SetIcon(HICON newicon) { icon = newicon; }
	void CreateHints();

	int x,y;
	HWND hMainWnd;
	char path[MAX_PATH];
	BOOL useicon;
	ListItem* next;
};

class List
{
public:
	List() { start = 0; }
	~List();
	BOOL AddItem(HWND hwnd);
	BOOL RemoveItem(HWND hwnd);
    BOOL GetSettings(char*, HWND hwnd);
	void SaveSettings(HWND, int, int, int useicon, char*);
	void LineUp();
	ListItem* FindListItem(HWND hwnd);
	ListItem* IsInList(HWND hwnd);
	int FirstAvailableX();
	int FirstAvailableY();

	ListItem* start;
};

#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);

__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);

__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
#ifdef __cplusplus
}
#endif