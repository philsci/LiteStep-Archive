/*
  This is a part of the LiteStep Shell Source code.
  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************

	2/3/99 - MrJukes - Released as pre-beta to public
	2/4/99 - MrJukes - Added transparency
	2/5/99 - MrJukes - Added popup
	4/4/99 - MrJukes - Added tons of stuff (remember)

****************************************************************************/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "min.h"

LRESULT CALLBACK MinWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK PropWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK GeneralDialogProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
VOID CALLBACK TimerProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime ); 
VOID CALLBACK CleanProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime ); 
BOOL CALLBACK EnumWindowsProc( HWND hwnd, LPARAM lParam );
void EditSettings(HWND hwnd);

HINSTANCE dll;
HWND desktop;
HWND iconHints;
HWND hPropWnd, hCurPropWnd;
HWND hNameEdit, hClassEdit, hIconButton, hBitmapButton, hBrowseButton, hBitmapEdit, hOkButton, hCancelButton;
int Timer=0;
int CleanTimer=0;
List* MinList = new List;
const char MinWnd[] = "MinWnd";
const char PropWnd[] = "PropWnd";
HFONT hf,oldFont;
int ScreenX, ScreenY;
HMENU Popup;
int BACK_COLOR, TEXT_COLOR;
int StartX=25, StartY=25;
char minini[MAX_PATH] = "";
int VERTICAL=0;

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)

{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{	
	char temp[256] = "";
	dll = dllInst;
	
	Popup = CreatePopupMenu();
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Restore");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 101, "Ma&ximize");
	AppendMenu(Popup, MF_SEPARATOR, 0, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "&Destroy");
	AppendMenu(Popup, MF_SEPARATOR, 0, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 103, "Icon &Properties");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 104, "&Line Up Icons");

    {
    	WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
    	wc.lpfnWndProc = MinWndProc;
    	wc.hInstance = dllInst;					// hInstance of DLL
    	wc.lpszClassName = MinWnd;			// our window class name
    	wc.style = CS_DBLCLKS;

    	if (!RegisterClass(&wc)) 
    	{
    		MessageBox(ParentWnd,"Error registering window class", MinWnd, MB_OK);
    		return 1;
    	}
    }

	{
    	WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
    	wc.lpfnWndProc = PropWndProc;
    	wc.hInstance = dllInst;					// hInstance of DLL
    	wc.lpszClassName = PropWnd;			// our window class name
    	wc.style = CS_DBLCLKS;

    	if (!RegisterClass(&wc)) 
    	{
    		MessageBox(ParentWnd,"Error registering window class", MinWnd, MB_OK);
    		return 1;
    	}
    }

	iconHints = CreateWindow
			(TOOLTIPS_CLASS,
			(LPSTR) NULL,
			TTS_ALWAYSTIP,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			NULL,
			(HMENU) NULL,
			dll,
			NULL
			);

	if (!iconHints) 
	{
		MessageBox(ParentWnd, "Error creating hints window", "Icon Hints Error", MB_OK);
		return 1;
	}

	SetWindowPos(iconHints, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);

	sprintf(minini, "%s\\min.ini", szPath);
	BACK_COLOR = GetPrivateProfileInt("min", "BackgroundColor", 0x00000000, minini);
	TEXT_COLOR = GetPrivateProfileInt("min", "TextColor", 0x00FFFFFF, minini);
	VERTICAL = GetPrivateProfileInt("min", "Vertical", 0, minini);
	StartX = GetPrivateProfileInt("min", "StartX", 25, minini);
	StartY = GetPrivateProfileInt("min", "StartY", 25, minini);

	Timer = SetTimer(NULL, 0, 250, (TIMERPROC)TimerProc);
	CleanTimer = SetTimer(NULL, 1, 10000, (TIMERPROC)CleanProc);
	
	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
	{
		desktop = GetDesktopWindow();
	}

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	return 0;
}

VOID CALLBACK TimerProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	EnumWindows((WNDENUMPROC)EnumWindowsProc, (LPARAM)0);
}

VOID CALLBACK CleanProc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	EnumWindows((WNDENUMPROC)EnumWindowsProc, (LPARAM)1);
}

BOOL CALLBACK EnumWindowsProc( HWND hwnd, LPARAM lParam )
{
	ListItem *p = MinList->IsInList(hwnd);

	if ((int)lParam == 0)
	{
		if (IsIconic(hwnd))
		{
			if (!p)
			{
				DWORD style = GetWindowLong(hwnd, GWL_STYLE);
				if ((style & WS_VISIBLE))
				{
					MinList->AddItem(hwnd);
				}
			}
			else 
			{
				ShowWindow(p->hMainWnd, SW_SHOW);
			}
		}
		else
		{
			if (p != 0)
			{
				ShowWindow(p->hMainWnd, SW_HIDE);
			}
		}
	}
	else
	{
		if (p)
		{
			if (!IsWindow(p->GetWnd()))
			{
				MinList->RemoveItem(p->GetWnd());
			}
		}
	}

	return TRUE;
}

void quitModule(HINSTANCE dllInst)
{
	KillTimer(NULL, Timer);
	KillTimer(NULL, CleanTimer);
	delete MinList;
	UnregisterClass(MinWnd, dll);
	if (hPropWnd) DestroyWindow(hPropWnd);
	UnregisterClass(PropWnd, dll);
	DestroyWindow(iconHints);
	DeleteObject(hf);
    DeleteObject(oldFont);
}

List::~List()
{
	ListItem* p = new ListItem;
	char temp[256] = "";
	char winclass[256] = "";
	p = start;

	while (p)
	{
		if (p->hMainWnd) 
		{
			SaveSettings(p->GetWnd(), p->x, p->y, p->useicon, p->path);
			DestroyWindow(p->hMainWnd);
			p->hMainWnd = 0;
			p->x = 0;
		}
		p = p->next;
	}

	while (start)
	{
		ListItem *q = start;
		ListItem *r = start;

		if (start->next)
		{
			while (r->next)	
			{
				q = r;
				r = r->next; 
			}
			q->next = 0;
			r=0;
		}
		else
		{
			start = 0;
			delete q;
			delete r;
		}
	}
	delete p;
}

BOOL List::AddItem(HWND hwnd)
{
	ListItem *newnode = new ListItem;
	char settings[256] = "";
	char temp[256] = "";

	newnode->SetWnd(hwnd);
	newnode->next = 0;

	if (start)						
	{
		newnode->next = start->next;
		start->next = newnode;
	}
	else
	{
		start = newnode;
	}

	if (MinList->GetSettings(settings, hwnd))
	{
		newnode->x = atoi(strtok(settings, " "));
		newnode->y = atoi(strtok(NULL, " "));
		newnode->useicon = atoi(strtok(NULL, " "));
		sprintf(newnode->path, "%s", strtok(NULL, " "));
		if (newnode->useicon) newnode->SetIcon(LoadImage(NULL, newnode->path, IMAGE_ICON, 32, 32, LR_LOADFROMFILE));
	}
	else
	{
		if (!VERTICAL)
		{
			newnode->x = MinList->FirstAvailableX();
			newnode->y = StartY;
		}
		else
		{
			newnode->x = StartX;
			newnode->y = MinList->FirstAvailableY();
		}
	}

	if (!newnode->GetIcon()) { newnode->SetIcon(newnode->GetWindowIcon(hwnd)); }

	newnode->hMainWnd = CreateWindowEx(
            WS_EX_TOOLWINDOW | WS_EX_TRANSPARENT,	// exstyles 
    		MinWnd,								// our window class name
    		"",									// use description for a window title
            WS_POPUP | WS_CLIPSIBLINGS,
    		newnode->x, newnode->y,				// position 
    		48, 48,
    		desktop,							// parent window 
    		NULL,								// no menu
    		dll,								// hInstance of DLL
    		NULL);								// no window creation data

	if (!newnode->hMainWnd) 
	{						   
   		MessageBox(desktop,"Error creating window",MinWnd,MB_OK);
   		return 1;
   	}

	SetWindowLong (newnode->hMainWnd, GWL_USERDATA, magicDWord);

	if (newnode->GetIcon())
	{
		ShowWindow(newnode->hMainWnd, SW_SHOWNORMAL);
		SetWindowPos(newnode->hMainWnd, desktop,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
		InvalidateRect(newnode->hMainWnd, NULL, TRUE);
		newnode->CreateHints();
	}
	else
	{
		ShowWindow(newnode->hMainWnd, SW_HIDE);
		newnode->x = -1;
		newnode->y = -1;
	}
	
	delete newnode;
	return TRUE;
}

BOOL List::GetSettings(char* temp, HWND hwnd)
{
	char winclass[256] = "";
	GetClassName(hwnd, winclass, 256);
	if (!GetPrivateProfileString("min", winclass, NULL, temp, 256, minini)) return FALSE;
	else return TRUE;
}

void List::SaveSettings(HWND hwnd, int x, int y, int useicon, char* path)
{
	char temp[256] = "";
	char winclass[256] = "";

	GetClassName(hwnd, winclass, 256);
	sprintf(temp, "%d %d %d %s", x, y, useicon, path);
	WritePrivateProfileString("min", winclass, temp, minini);
}

BOOL List::RemoveItem(HWND hwnd)
{
	ListItem *p = start;
	ListItem *q = start;

	if (start)
	{
		if (p->GetWnd() == hwnd)
		{
			if (!p->next) { start = 0; }
			else { start = p->next; }

			if (p->hMainWnd) 
			{
				SaveSettings(p->GetWnd(), p->x, p->y, p->useicon, p->path);
				DestroyWindow(p->hMainWnd);
				p->hMainWnd = 0;
				p->x = 0;
			}
			return TRUE;
		}
		else
		{
			while (p)
			{
				if (p->GetWnd() == hwnd)
				{
					q->next = p->next;

					if (p->hMainWnd) 
					{
						SaveSettings(p->GetWnd(), p->x, p->y, p->useicon, p->path);
						DestroyWindow(p->hMainWnd);
						p->hMainWnd = 0;
						p->x = 0;
					}
					return TRUE;
				}
				else		
				{
					q = p;
					p = p->next;
				}
			}
		}
	}
	return FALSE;
}

LRESULT CALLBACK MinWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_PAINT:
		{
			ListItem *p = MinList->FindListItem(hwnd);
			RECT r;
			char temp[256] = "";
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC desk = GetWindowDC(desktop);
			HDC buf = CreateCompatibleDC(NULL);
			HDC buf2 = CreateCompatibleDC(NULL);
			HBITMAP buf2BMP = CreateCompatibleBitmap(hdc, 48, 48);
			HBITMAP bufBMP = CreateCompatibleBitmap(hdc, 32, 32);

			GetWindowRect(hwnd, &r);
			SelectObject(buf2, buf2BMP);
			BitBlt(buf2, 0, 0, 48, 48, desk, r.left, r.top, SRCCOPY);
			
			SelectObject(buf, bufBMP);
			BitBlt(buf, 0, 0, 48, 48, buf2, 8, 4, SRCCOPY);
			
			if (p) 
			{
				if (!p->GetIcon()) 
				{ 
					p->SetIcon(LoadIcon(NULL, IDI_WINLOGO));
				}
				DrawIconEx(buf, 0, 0, p->GetIcon(), 32, 32, 0, NULL, DI_NORMAL);
			}
			
			BitBlt(buf2, 8, 4, 32, 32, buf, 0, 0, SRCCOPY);

			r.left = 1;
			r.right = 47;
			r.top = 37;
			r.bottom = 47;

			SetBkColor(buf2, BACK_COLOR);
			SetTextColor(buf2, TEXT_COLOR);
			SetBkMode(buf2, OPAQUE);
			if (!hf) { hf = CreateFont(10, 0, 0, 0, 0, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, NULL); }
			oldFont = SelectObject(buf2, hf); 
			GetWindowText(p->GetWnd(), temp, 256);
			DrawTextEx(buf2, temp, strlen(temp), &r, DT_SINGLELINE,	NULL);
			
			BitBlt(hdc, 0, 0, 48, 48, buf2, 0, 0, SRCCOPY);
			
			EndPaint(hwnd,&ps);
			ReleaseDC(desktop, desk);
			DeleteDC(buf);
			DeleteDC(buf2);
			DeleteObject(bufBMP);
			DeleteObject(buf2BMP);
		}
		return 0;
		case WM_COMMAND:
		{
			ListItem *p = MinList->FindListItem(hwnd);
			switch (wParam)
			{
			case 100: // Restore
				PostMessage(p->GetWnd(), WM_SYSCOMMAND, (WPARAM)SC_RESTORE, (LPARAM)0);
				break;
			case 101: // Maximize
				PostMessage(p->GetWnd(), WM_SYSCOMMAND, (WPARAM)SC_MAXIMIZE, (LPARAM)0);
				break;
			case 102: // Destroy
				PostMessage(p->GetWnd(), WM_SYSCOMMAND, (WPARAM)SC_CLOSE, (LPARAM)0);
				break;
			case 103: // Properties
				EditSettings(hwnd);
				break;
			case 104:
				MinList->LineUp();
				break;
			/*case 104: // Global Settings
				BACK_COLOR = GetPrivateProfileInt("min", "BackgroundColor", 0x00000000, minini);
				TEXT_COLOR = GetPrivateProfileInt("min", "TextColor", 0x00FFFFFF, minini);
				InvalidateRect(hwnd, NULL, TRUE);
				break;*/
			}
		}
		break;
		case WM_NCLBUTTONDBLCLK :
		{
			ListItem *p = MinList->FindListItem(hwnd);
			if (p) 
			{
				ShowWindow(p->GetWnd(), SW_RESTORE);
			}

		}
		return 0;
		case WM_NCHITTEST:
		{
			return HTCAPTION;
		}
		case WM_NCRBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
			return 0;
		}
		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			ListItem* p = MinList->FindListItem(hwnd);
			
			pos->flags |= SWP_NOZORDER;
			if (!(pos->flags & SWP_NOMOVE))
			{
				p->x = pos->x;
				p->y = pos->y;
			}
			InvalidateRect(p->hMainWnd, NULL, TRUE);
			MinList->SaveSettings(p->GetWnd(), p->x, p->y, p->useicon, p->path);
		}
		break;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

ListItem* List::FindListItem(HWND hwnd)
{
	ListItem *p = start;

	if (start)
	{
		while (p)
		{
			if (p->hMainWnd == hwnd)
			{
				return p;
			}
			p = p->next;
		}
	}

	return 0;
}

ListItem* List::IsInList(HWND hwnd)
{
	ListItem *p = start;

	if (start)
	{
		while (p)
		{
			if (p->GetWnd() == hwnd)
			{
				return p;
			}
			p = p->next;
		}
	}

	return 0;
}

void List::LineUp()
{
	ListItem* p = start;
	int x=StartX;
	int y=StartX;

	while (p)
	{
		if (!VERTICAL)
		{
			p->x = x;
			p->y = StartY;
			SetWindowPos(p->hMainWnd, 0, x, StartY, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}
		else
		{
			p->x = StartX;
			p->y = y;
			SetWindowPos(p->hMainWnd, 0, StartX, y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOZORDER);
		}

		
		x+=54;
		y+=54;
		p = p->next;
	}
}

int List::FirstAvailableX()
{
	ListItem *p = start;
	int pos=StartX;

	while (p)
	{
		if (p->x == pos)
		{
			pos += 54;
			p = start;
		}
		else
		{
			p = p->next;
		}
	}

	return pos;
}

int List::FirstAvailableY()
{
	ListItem *p = start;
	int pos=StartY;

	while (p)
	{
		if (p->y == pos)
		{
			pos += 54;
			p = start;
		}
		else
		{
			p = p->next;
		}
	}

	return pos;
}

HICON ListItem::GetWindowIcon(HWND Hwnd)
{
	HICON a;

    SendMessageTimeout(Hwnd, WM_GETICON, 1, 0, 0, 1000, (unsigned long*)&a);
    if (!a) a = (void *)GetClassLong(Hwnd, GCL_HICON);
    if (!a) SendMessageTimeout(Hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
    if (!a) SendMessageTimeout(Hwnd, WM_GETICON, 0, 0, 0, 1000, (unsigned long*)&a);
    if (!a) a = (void *)GetClassLong(Hwnd, GCL_HICONSM);

	return a;
}

void ListItem::CreateHints() 
{
	char txt[256] = "";
	RECT r;
	TOOLINFO ti;    // tool information

	GetWindowText(hwnd, txt, 256);
	GetClientRect(hMainWnd, &r);

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hMainWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = r;

	SendMessage(iconHints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void ListItem::SetWnd(HWND wnd) 
{ 
	hwnd = wnd; 
	x = -1;
	y = -1;
}

void EditSettings(HWND hwnd)
{
	ListItem *p = MinList->FindListItem(hwnd);
	HWND hTempWnd=NULL;
	char temp[256] = "";
	RECT r;
	int top=100, left=100;
	
	hCurPropWnd = hwnd;
	GetWindowRect(p->hMainWnd, &r);
	top = r.top - 10;
	left = r.right + 10;
	if ((top - 310) < 0) top = 10;
	if ((top + 310) > ScreenY) top = ScreenY-310;
	if ((left - 310) < 0) left = 10;
	if ((left + 310) > ScreenX) left = ScreenX - 310;

	if (!hPropWnd)
	{
		hPropWnd = CreateWindowEx(
							WS_EX_TOOLWINDOW,					// exstyles 
    						PropWnd,							// our window class name
    						"Icon Properties",					// use description for a window title
							WS_OVERLAPPEDWINDOW,
    						left, top,							// position 
    						300, 240,
    						p->hMainWnd,						// parent window 
    						NULL,								// no menu
    						dll,								// hInstance of DLL
    						NULL);								// no window creation data

		ShowWindow(hPropWnd, SW_SHOWNORMAL);

		ShowWindow(CreateWindowEx(0, "Static", "Window Name:", WS_CHILD | SS_CENTER, 10, 10, 55, 50, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);

		GetWindowText(p->GetWnd(), temp, 256);
		ShowWindow(hNameEdit = CreateWindowEx(0, "Edit", temp, WS_CHILD | WS_BORDER | ES_READONLY | ES_AUTOHSCROLL, 70, 15, 210, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		
		ShowWindow(CreateWindowEx(0, "Static", "Window Class:", WS_CHILD | SS_CENTER, 10, 55, 55, 50, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		
		GetClassName(p->GetWnd(), temp, 256);
		ShowWindow(hClassEdit = CreateWindowEx(0, "Edit", temp, WS_CHILD | WS_BORDER | ES_READONLY, 70, 60, 210, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);

		ShowWindow(hIconButton = CreateWindowEx(0, "Button", "Use Icon", WS_CHILD | BS_AUTORADIOBUTTON | BS_PUSHLIKE, 10, 100, 85, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		ShowWindow(hBitmapButton = CreateWindowEx(0, "Button", "Specify Icon", WS_CHILD | BS_AUTORADIOBUTTON | BS_PUSHLIKE, 120, 100, 90, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		ShowWindow(hBrowseButton = CreateWindowEx(0, "Button", "Browse", WS_CHILD | BS_PUSHLIKE, 215, 100, 60, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		ShowWindow(hBitmapEdit = CreateWindowEx(0, "Edit", p->path, WS_CHILD | WS_BORDER | ES_AUTOHSCROLL, 120, 130, 160, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);

		ShowWindow(hOkButton = CreateWindowEx(0, "Button", "Ok", WS_CHILD, 155, 185, 60, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);
		ShowWindow(hCancelButton = CreateWindowEx(0, "Button", "Cancel", WS_CHILD, 220, 185, 60, 23, hPropWnd, NULL, dll, NULL), SW_SHOWNORMAL);

		if (p->useicon) { PostMessage(hBitmapButton, WM_LBUTTONDOWN, 0, 0); PostMessage(hBitmapButton, WM_LBUTTONUP, 0, 0); }
		else { PostMessage(hIconButton, WM_LBUTTONDOWN, 0, 0); PostMessage(hIconButton, WM_LBUTTONUP, 0, 0); }
	}
}

LRESULT CALLBACK PropWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_PAINT:
		{
			RECT r;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufBMP = CreateCompatibleBitmap(hdc, 32, 32);
			ListItem *p = MinList->FindListItem(hCurPropWnd);
			
			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, (HBRUSH)(COLOR_3DFACE+1));

			r.left = 30;
			r.right = r.left+48;
			r.top = 130;
			r.bottom = r.top+48;

			FillRect(hdc, &r, (HBRUSH)0x00FFFFFF);
			FrameRect(hdc, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));

			SelectObject(buf, bufBMP);
			BitBlt(buf, 0, 0, 48, 48, hdc, r.left+2, r.top+2, SRCCOPY);
			DrawIconEx(buf, 0, 0, p->GetIcon(), 32, 32, 0, NULL, DI_NORMAL);
			BitBlt(hdc, r.left + 8, r.top + 4, 32, 32, buf, 0, 0, SRCCOPY);

			EndPaint(hwnd,&ps);
			DeleteDC(buf);
			DeleteObject(bufBMP);
		}
		return 0;
		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					if ((HWND)lParam == hIconButton)
					{
						EnableWindow(hBitmapEdit, FALSE);
						EnableWindow(hBrowseButton, FALSE);
					}
					else if ((HWND)lParam == hBitmapButton)
					{
						EnableWindow(hBitmapEdit, TRUE);
						EnableWindow(hBrowseButton, TRUE);
					}
					else if ((HWND)lParam == hOkButton)
					{
						ListItem*p = MinList->FindListItem(hCurPropWnd);
						if (IsWindowEnabled(hBitmapEdit))
						{
							GetWindowText(hBitmapEdit, p->path, MAX_PATH);
							p->useicon = TRUE;
							p->SetIcon(LoadImage(NULL, p->path, IMAGE_ICON, 32, 32, LR_LOADFROMFILE));
						}
						else
						{
							p->useicon = FALSE;
							p->SetIcon(p->GetWindowIcon(p->GetWnd()));
						}
						MinList->SaveSettings(p->GetWnd(), p->x, p->y, p->useicon, p->path);
						InvalidateRect(p->hMainWnd, NULL, TRUE);
						DestroyWindow(hPropWnd);
					}
					else if ((HWND)lParam == hCancelButton)
					{
						DestroyWindow(hPropWnd);
					}
					else if ((HWND)lParam == hBrowseButton)
					{
						char filename[MAX_PATH] = "";
						OPENFILENAME* of = new OPENFILENAME;

						of->lStructSize	= sizeof(OPENFILENAME);
						of->hwndOwner	= hwnd;
						of->hInstance	= NULL;
						of->lpstrFilter	= "Icons (*.ico)\0*.ico\0\0";
						of->lpstrCustomFilter = NULL;
						of->nMaxCustFilter	= 0;
						of->nFilterIndex	= 0;
						of->lpstrFile		= filename;
						of->nMaxFile		= MAX_PATH;
						of->lpstrFileTitle	= NULL;
						of->lpstrInitialDir	= NULL;
						of->lpstrTitle		= "Browse";
						of->Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;

						if (GetOpenFileName(of))
						{
							SetWindowText(hBitmapEdit, filename);
							delete of;
						}
					}
				}
				break;
			}
		}
		break;
		case WM_DESTROY:
		{
			hPropWnd = 0;
			hCurPropWnd = 0;
		}
		break;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

BOOL CALLBACK GeneralDialogProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{

	return FALSE;
}