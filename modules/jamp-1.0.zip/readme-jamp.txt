/////////////////////////////
// Module: jamp 1.0
// Written By: MrJukes
// Released: 9/18/00
/////////////////////////////

LoadModule c:\litestep\jamp.dll

step.rc
==========
LoadModule $ModulesDir$jamp.dll
jampStartHidden		; Starts hidden
jampX 0			; X position
jampY 0			; Y position
jampW 600		; Width
jampH 32		; Height
jampFont "8Pin Matrix"	; Font
jampFontSize 32		; Font Size
jampFontColor FFFFFF	; Font Color
jampBackColor 000000	; These are very obvious names. If you can't figure 
			; out what this does then just quit now
jampSpeed 100		; Speed at which it scrolls
jampBackBmp jamp.bmp	; Background image to use
			; If neither jampBackBmp or jampBackColor are specified
			; then it will paint the desktop beneath the window

bangs
=======
!jampShow		; Shows the window
!jampHide		; Hides the window
!jampToggle		; Formats your hard drive
!jampToggleScroll	; Toggles scrolling on or off

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes