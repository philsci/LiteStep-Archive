#include <windows.h>
#include <stdio.h>
#include <wininet.h>
#include "resource.h"
#include <winuser.h>
#include <process.h>
#include <stdlib.h>

#define FTPUPLOAD	110
#define FTPDOWNLOAD 210

int xPos;
int yPos;
int Width=450, Height=300;
int downloadnow;
char *szAppName = "Logicate";
char szBuffer[1345678] = "";
BOOL bully;
const int MAX = 256;
HWND hMainWnd;
HWND editor;
HWND titlebox;
HWND mainhwnd;
HINSTANCE hinst; 
HINTERNET inet;
HBITMAP BaseBMP=NULL;

void loadit(char lfile[256]);
int buttonclick(RECT *r,long xoff,long yoff,long bwidth, long bheight,long x,long y);
int downloadit(char filename[256]);
int testing(char lfile[256]);
BOOL ModifyTrayIcon( HWND, UINT, UINT, DWORD, int );
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

typedef struct
{
	//HWND hwnd;
	//int num1;
	//int num2;
	BOOL bkill;
}
PARAMS, *PPARAMS;

typedef struct
{
	char remotefilename[MAX];
	char localfilename[MAX];
//	char localdir[MAX];
	char remotedir[MAX];
	char address[MAX];
	char login[MAX];
	char password[MAX];
	int method;
}
linet, *llinet;

linet testi;


VOID Thread( PVOID pvoid)
{

	PPARAMS pparams;
	pparams = (PPARAMS) pvoid;

//	while(!pparams->bkill)
//	{
		
		
//	}
}


BOOL ModifyTrayIcon( HWND hWnd, UINT msg, UINT uID, DWORD dwType)//, int iIcon )
{
	NOTIFYICONDATA nid;
	
	memset( &nid, 0, sizeof(NOTIFYICONDATA) );         //  Initialize structure
	nid.cbSize = sizeof(NOTIFYICONDATA);             //  Plug in structure size
	nid.hWnd = hWnd;                                  //  Plug in passed values
	nid.uID = uID;
	nid.uFlags = NIF_ICON | NIF_MESSAGE;      //  We use icons and notification
	nid.uCallbackMessage = msg;                    //  Load icon from resources
	nid.hIcon = LoadIcon(hinst,MAKEINTRESOURCE(IDI_ICON2));//LoadImage(hinst, MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR );
		//LoadIcon(hinst,MAKEINTRESOURCE(IDI_ICON2));LoadIcon(hinst,MAKEINTRESOURCE(IDI_ICON2)); //LoadImage( hinst, MAKEINTRESOURCE( IDI_ICON1), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR );
	Shell_NotifyIcon( dwType, &nid );          //  Update icon using shell call
	return( TRUE );
}


int testing(char lfile[256])
{
	
	int  count = 0;
	int total = 0;
	char buf[4096];
	char buf2[4096];
	char buf3[4096];
	char buftop[4096] = "";
	char buffer[65535] = "";
	///char szBuffer[65535];
	char titleheader[256] = "<strong><font color=ffffff>\r\n";
	char titlefooter[256] = "\r\n</strong></font><br>\r\n";
	
   char *pdest;
   int  result;
   
	FILE *f;
	if (f = fopen (lfile, "r+"))
	{

		while (f && !feof (f))
		{
			
			fgets (buffer, 4096, f);
			strcat( szBuffer, buffer );
			total+=count;
		}
	pdest = strstr(buffer,"<!--inserthere-->");
	result = pdest - buffer + 1;
	strncpy(buftop,buffer,440);
	strcat(buffer,buftop);
	
/*
	//GetWindowText(titlebox,buf,4096);
	//GetWindowText(editor,buf2,4096);

	strcpy(buf3,titleheader);
	
	strcat(buf3,buf);
	strcat(buf3,titlefooter);

	strcat(buf3,"\r\n");
	strcat(buf3,buf2);
	SetWindowText(editor," ");
	UpdateWindow(editor);

	SetWindowText(editor, buf3);
	UpdateWindow(editor);
*/	
	
	fclose( f );
	}

		
	return 1;
}










int downloadit(linet inetset)
{

	if (inet = InternetOpen("inet",INTERNET_OPEN_TYPE_DIRECT, NULL,NULL,INTERNET_FLAG_ASYNC))
	{
		if(inet = InternetConnect(inet,inetset.address  ,INTERNET_DEFAULT_FTP_PORT ,inetset.login  ,inetset.password ,INTERNET_SERVICE_FTP,NULL,NULL))
		{
			bully = FtpSetCurrentDirectory(inet, inetset.remotedir );
			
				if (inetset.method == FTPDOWNLOAD)
				{
					
					if (FtpGetFile(inet,inetset.remotefilename ,inetset.localfilename  ,FALSE,FILE_ATTRIBUTE_NORMAL,FTP_TRANSFER_TYPE_BINARY ,NULL))
					{
					bully = InternetCloseHandle(inet);
					}
					else
					MessageBox(hMainWnd,"GetFile Failed","Geek", MB_OK);
				}
				else
				{
					if (FtpPutFile(inet,inetset.localfilename ,"beavis.shtml",FTP_TRANSFER_TYPE_BINARY ,NULL))
					{
					bully = InternetCloseHandle(inet);
					}
					else
					MessageBox(hMainWnd,"GetFile Failed","Geek", MB_OK);
				}
		}
		else
		MessageBox(hMainWnd,"InternetConnect Failed","Geek", MB_OK);
	}
	else
	{	
	MessageBox(hMainWnd,"InternetOpen Failed","Geek", MB_OK);
	}
	return 1;
}

int buttonclick(RECT r,long xoff, long yoff,long bwidth, long bheight,long x,long y)
{
	int xold = 0;
	int yold = 0;
	xold = r.right;
	yold = r.top;
	
	r.top = r.top + yoff;
	if (r.top < yold)
		{
		r.top = r.bottom;
		r.top -= yoff;
		}

	
	
	r.right = r.right + xoff;
	if (r.right > xold)
		{
			r.right = xoff;
		}
	
	if (( x > r.right ) &&(y > r.top)&&(x < r.right + bwidth) &&(y < r.top + bheight))
	{
	return 1;
	}
	else
	{
	return 0;
	}
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	MSG msg;

	{
		WNDCLASSEX wc;
		
		wc.cbSize = sizeof(wc);			
		wc.style = CS_HREDRAW | CS_VREDRAW;
		wc.lpfnWndProc = MainWndProc; 
		wc.cbClsExtra = 0; 
		wc.cbWndExtra = 0; 
		wc.hInstance = hInstance; 
		wc.hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(IDI_ICON1)); 
		wc.hCursor = LoadCursor(NULL, IDC_ARROW); 
		//wc.hbrBackground = NULL;
		wc.hbrBackground = (HBRUSH) GetStockObject(COLOR_MENU);//CreateSolidBrush(0x00FF33FF);;//GetStockObject (COLOR_MENU); 
		wc.lpszMenuName = "IDR_MENU1"; //the default menu of this window class
		wc.lpszClassName = szAppName; //the class name...
		wc.hIconSm = LoadIcon (hInstance,MAKEINTRESOURCE(IDI_ICON1)); 
		
		
		if(!RegisterClassEx(&wc)) //registering
		{
			MessageBox(NULL, "Error: Could not RegisterClassEx()", "This process sucks", MB_OK);
			//error message
			return -1; //quiting
		}
	}
 hinst = hInstance;

//ike = LoadImage(hinst, MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR );

	hMainWnd = CreateWindow(
		szAppName, //classname
		"Logicate",  //caption
		WS_POPUP , //style
		50,50, //x,y
		450,300, //width,height
		NULL, //parent
		NULL,
		//LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MENU1)), //menu
		hInstance, //your instance
		NULL //not needed
	); 

	titlebox = CreateWindowEx(0,
		"EDIT",
		"",
		WS_CHILD|WS_TABSTOP,
		5,40,
		440,20,
		hMainWnd,
		NULL,
		hInstance,
		NULL
	);
	
	editor = CreateWindowEx(0,
		"EDIT",
		"",
		WS_CHILD|WS_TABSTOP|ES_OEMCONVERT| ES_AUTOVSCROLL | ES_MULTILINE | WS_VSCROLL| WS_HSCROLL|ES_WANTRETURN| WS_EX_TRANSPARENT,
		5,65,
		440,230,
		hMainWnd,
		NULL,
		hInstance,
		NULL
	);
	

	BaseBMP = LoadBitmap(hInstance, MAKEINTRESOURCE(IDB_BITMAP1));


	ShowWindow(hMainWnd, nShowCmd);
	UpdateWindow(hMainWnd);
	//loadit("c:\\content.shtml");
	ShowWindow(editor, nShowCmd);
	ShowWindow(titlebox,nShowCmd);
	UpdateWindow(titlebox);
	UpdateWindow(editor);
	mainhwnd = hMainWnd;


	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (msg.wParam); 
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	xPos = LOWORD(lParam);
	yPos = HIWORD(lParam);
	static PARAMS params;
	
	switch (uMsg)
	{
	case WM_CTLCOLOREDIT:
		{
		HBRUSH hbc;
		hbc = CreateSolidBrush(0x00777777);
		SetBkColor((HDC)wParam,0x00777777);
		return (LRESULT) hbc;

		}
	case WM_CTLCOLORSCROLLBAR:
		{
		HBRUSH hbc;
		hbc = CreateSolidBrush(0x007fff77);
		SetBkColor((HDC)wParam,0x007fff77);
		return (LRESULT) hbc;

		}




	case WM_LBUTTONDOWN:
			RECT r;
			GetClientRect(hwnd, &r);
			xPos = LOWORD(lParam);
			yPos = HIWORD(lParam);
			
			if (buttonclick( r , -20,2,18,18,xPos , yPos ))
			{
				SendMessage(hwnd,WM_CLOSE,0,0);
				PostQuitMessage(9);
			}
			else if (buttonclick(r, -40, 2, 18,18,xPos,yPos))
			{
			SendMessage(hwnd,WM_SYSCOMMAND,SC_MINIMIZE,0);
			}
			else if (buttonclick(r, 2,16,18,18,xPos,yPos))
			{
			
				strcpy(testi.address , "techradioshow.com");
				strcpy(testi.localfilename , "c:\\beepbeep.shtml");
				strcpy(testi.login , "techradioshow.com");
				strcpy(testi.password , "youcantry1067");
				strcpy(testi.remotedir , "/Documents/whatsnew");
				strcpy(testi.remotefilename , "content.shtml");
				testi.method = FTPDOWNLOAD;

				if (downloadit(testi))
				{
			
				loadit(testi.localfilename );

				}		
				
			}
			else if (buttonclick(r,22,16,18,18,xPos,yPos))
			{
				params.bkill = TRUE;
				testing("c:\\beepbeep.shtml");
			}

		case WM_PAINT:
			{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
			RECT r;
			GetClientRect(hwnd, &r);
		
		
 				HDC buf = CreateCompatibleDC(NULL);
				HBITMAP bufBMP = CreateCompatibleBitmap(hdc, Width, Height);
//				HBRUSH hbr = CreateSolidBrush(0x00000000);

				//FillRect(hdc, &r, hbr);
				SelectObject(buf, BaseBMP);
				BitBlt(hdc, 0, 0, Width, Height, buf, 0, 0, SRCCOPY);
				EndPaint(hwnd,&ps);
//				DeleteObject(hbr);
				DeleteDC(buf);
				DeleteObject(bufBMP);
		
			EndPaint(hwnd,&ps);	
			}
		return 0;
		case WM_CREATE:
			{
			//params.bkill = FALSE;						
			//	_beginthread(Thread,0,&params);
			ModifyTrayIcon( hwnd, WM_COMMAND, 1000, NIM_ADD);//, MAKEINTRESOURCE(IDI_ICON1));
			return 0;
			}
			break; 
		case WM_DESTROY:
			{
				PostQuitMessage(0);
				ModifyTrayIcon( hwnd, WM_COMMAND, 1000, NIM_DELETE);
			}
			break;

		case WM_NCHITTEST:
		{

			long a,b,c;
			RECT r;
			GetClientRect(hwnd, &r);
			RECT dd;
			GetWindowRect(hwnd, &dd);
			a = r.left;
			b = dd.left;
			c = b - a;
			xPos = xPos - c;
			
			a = r.top;
			b = dd.top;
			c = b - a;
			yPos = yPos - c;
			

			
			if (buttonclick(r,1,1,350,15,xPos,yPos))
			{
				return HTCAPTION;
			}
		
		}
	}

	return DefWindowProc(hwnd, uMsg, wParam, lParam); 
}

void loadit(char lfile[256])
{
	int  count = 0;
	int total = 0;
	char buffer[4096] = "";
	
	FILE *f;
	if (f = fopen (lfile, "r+"))
	{

		while (f && !feof (f))
		{
			//count = fread( buffer, sizeof( char ), 100,f );
			fgets (buffer, 4096, f);
			//fseek(f,length, length+ 512);
			
			strcat( szBuffer, buffer );
			total+=count;

		

				
			//{
		//		break;
		//	}
		}
		//SetDlgItemText(editor,1,szBuffer);
		SetWindowText(editor,"");
		UpdateWindow(editor);
		SetWindowText(editor,szBuffer);
		UpdateWindow(editor);

		//strcat(szBuffer,"this works?");
		//fputs(szBuffer,f);
		fclose( f );
	}
	else
	{
		
		SetWindowText(editor,"Unable to load file.");
		UpdateWindow(editor);
	}


}


