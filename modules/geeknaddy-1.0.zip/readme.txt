******************************************************************************
		GeekNaddy version 1.0
******************************************************************************
******************************************************************************
This file was created on 2:05 AM 12/8/98 by GeekMaster
******************************************************************************
(	
	Lowell Heddings
	http://floach.pimpin.net/geekmaster
	lheddings@geocities.com
	AIM: lheddin
	IRC: Geekmasta / GeekMastr
	ICQ: 17869937
)
******************************************************************************
	This .dll file is used to control Nad / Naddy via !<commands> in the step.rc
file of litestep.
******************************************************************************

To use: Simply add a line to your step.rc file that looks like the following:

	LoadModule c:\litestep\geeknaddy.dll

I think this has to be loaded after the other modules, but I'm not sure.

******************************************************************************

Once you have loaded the module, you can use any of the commands anywhere
in litestep. This could be either a Shortcut or a Hotkey or a Wharf.

For Instance:
	*Hotkey Win F9 !Naddy_Play
	This line would assign the combo of Win + F9 to Play the current song
The commands are not case sensitive, either

To use the autolaunching feature, you must specify your Nad exe path.

For instance:
NadPath c:\nad\nad.exe

If you do not specify a path, it will try and launch it from the default path.
******************************************************************************
Commands:
******************************************************************************

!Naddy_Play
		This plays the current song
!Naddy_Stop
		This stops the current song
!Naddy_Pause
		This pauses the current song
!Naddy_Next
		This skips to the next song on the playlist
!Naddy_Prev
		This skips to the previous song on the playlist
!Naddy_Expand
		This opens the vis
!Naddy_Quit
		This closes Naddy
!Naddy_Show
		This toggles the main window on /off
!Naddy_Power
		This starts / stops Nad / Naddy

******************************************************************************
Future
******************************************************************************

I have a real lot more commands to add, and I will do so.
