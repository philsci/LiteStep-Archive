/////////////////////////////
// Module: ShortcutMap v1.0
// Written By: MrJukes
// Released: 11/8/2000
/////////////////////////////

LoadModule c:\litestep\ShortcutMap.dll

step.rc
==========
*ShortcutMap Name #TH X Y image.bmp
*Region "Bang Command" [x,y:x,y:x,y:x,y] "!left" "right.exe" "middle.exe -args"
*Region Executable [x,y:x,y:x,y:x,y:x,y] left.exe right.exe
~ShortcutMap Name

; You can specify up to 32 vertices in the region
; #T = Always on top
; #H = Start Hidden

!bangs
===========
!ShortcutMapShow Name
!ShortcutMapHide Name
!ShortcutMapToggle Name

example
===========
*ShortcutMap Map 100 100 smap.bmp
*Region "R1" [0,0:74,0:74,74:0,74:0,0] notepad.exe calc.exe
*Region R2 [75,0:150,0:150,74:75,74:75,0] calc.exe notepad.exe
*Region R3 [0,75:74,75:74,150:0,150] explorer.exe
*Region R4 [75,75:150,75:150,150:75,150] !About "!ShortcutMapToggle Map"
~ShortcutMap MyMap

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes