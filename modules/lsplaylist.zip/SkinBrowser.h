

#ifndef __SKINBROWSER_H
#define __SKINBROWSER_H

class SkinBrowser
{
public:
	SkinBrowser(HWND hwnd, HINSTANCE hinst, LPCTSTR skin_dir, LPCTSTR ini);
	~SkinBrowser();

	HWND m_parent, m_hwnd, m_list;
	HINSTANCE m_hinst;
	LPCTSTR m_skin_dir, m_ini;

	BOOL CALLBACK m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	void Go();
};

#endif