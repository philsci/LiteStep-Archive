#include <windows.h>
#include <stdio.h>
#include <commctrl.h>

#include "lsplaylist.h"
#include "skinbrowser.h"
#include "resource.h"

BOOL CALLBACK SkeletonSkinBrowserProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

SkinBrowser::SkinBrowser(HWND hwnd, HINSTANCE hinst, LPCTSTR skin_dir, LPCTSTR ini)
{
	m_parent=hwnd;
	m_hinst=hinst;
	m_skin_dir = _strdup(skin_dir);
	m_ini = _strdup(ini);
}

SkinBrowser::~SkinBrowser()
{
	RemoveProp(m_hwnd, "SkinBrowser");
	EndDialog(m_hwnd, 0);
}

void SkinBrowser::Go()
{
	m_hwnd = CreateDialog(m_hinst, MAKEINTRESOURCE(IDD_SKIN_BROWSER), m_parent, SkeletonSkinBrowserProc);
	SetProp(m_hwnd, "SkinBrowser", (HANDLE)this);
	m_list = GetDlgItem(m_hwnd, IDC_SKIN_LIST);

	HANDLE fff = NULL;
	WIN32_FIND_DATA* fd = new (WIN32_FIND_DATA);
	char path[256] = "";
	
	sprintf(path, "%s\\*", m_skin_dir);

	fff = FindFirstFile(path, fd);
	if (fff == INVALID_HANDLE_VALUE) return;

	while (FindNextFile(fff, fd))
	{
		if (fd->dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (strcmp(fd->cFileName, ".") && strcmp(fd->cFileName, ".."))
			{
				LVITEM item;
				item.iItem = 0;
				item.iSubItem = 0;
				item.mask = LVIF_TEXT;
				item.pszText=fd->cFileName;
				item.cchTextMax = strlen(fd->cFileName);
				ListView_InsertItem(m_list, &item);			
			}
		}
	}
}

BOOL CALLBACK SkeletonSkinBrowserProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	SkinBrowser* sb = (SkinBrowser*)GetProp(hwnd, "SkinBrowser");
	if (sb)
		return sb->m_proc(hwnd, msg, wParam, lParam);
	else return FALSE;
}

BOOL CALLBACK SkinBrowser::m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { EndDialog(hwnd, 0); return TRUE; }
			}
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							int sel = ListView_GetSelectionMark(m_list);
							char temp[256] = "";
							if (sel >= 0)
							{
								ListView_GetItemText(m_list, sel, 0, temp, 256);
								WritePrivateProfileString("Main", "Skin", temp, m_ini);
								PostMessage(m_parent, LSP_RECYCLE, 0, 0);
							}
						}
						case IDCANCEL:
						{
							EndDialog(hwnd, 0);
						}
						break;
					}
				}
			}
		}
		break;
	}

	return FALSE;
}