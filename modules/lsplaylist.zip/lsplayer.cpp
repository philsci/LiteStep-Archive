#include <stdio.h>
#include "lsplayer.h"

// Constructor
LSPlayer::LSPlayer(HINSTANCE instance, HWND parent):
    XaudioPlayer(instance), m_Scrolling(FALSE), m_State(XA_PLAYER_STATE_STOPPED)
{
	m_hwnd = parent;
}

void LSPlayer::OnNotifyReady()
{
    //PlayerDialog->m_Player->SetPlayerMode(XA_PLAYER_MODE_OUTPUT_AUTO_CLOSE_ON_STOP);
}

void LSPlayer::OnNotifyNack(XA_NackInfo *info)
{
    char message[256];
    sprintf(message,"Command %d failed\n[%s]", 
            info->command,
            xaudio_error_string(info->code));
    MessageBox(NULL, message, "Xaudio Command Failed", MB_OK | MB_ICONSTOP);
}

void LSPlayer::OnNotifyPlayerState(XA_PlayerState state)
{
    char state_name[256] = "";

    // compute state name
    switch (state) 
	{
		case XA_PLAYER_STATE_PLAYING:
		{
			strcpy(state_name, "PLAYING");
		}
        break;

		case XA_PLAYER_STATE_EOF:
		{
			strcpy(state_name, "EOF");
			// Move to next song in playlist
			SendMessage(m_hwnd, LSP_NEXTSONG, 0, 0);
		}
        break;

		case XA_PLAYER_STATE_STOPPED:
		{
			strcpy(state_name, "STOPPED");
        }
        break;

		case XA_PLAYER_STATE_PAUSED:
		{
			if (m_Scrolling) return;
			strcpy(state_name, "PAUSED");
		}
        break;

		default: return;
	}

    // remember the state
    m_State = state;

    // display the current state
    //PlayerDialog->m_StateLabel.SetWindowText(state_name);
}

void LSPlayer::OnNotifyInputName(const char *name)
{
    // File has been opened
	SendMessage(m_hwnd, LSP_INPUTNAME, (WPARAM)name, 0);
}

void LSPlayer::OnNotifyInputPosition(unsigned long offset, unsigned long range)
{
    SendMessage(m_hwnd, LSP_POS, (WPARAM)offset, (LPARAM)range);
}

void LSPlayer::OnNotifyInputState(XA_InputState state)
{
    BOOL enabled;

    switch(state) 
	{
		case XA_INPUT_STATE_OPEN:
		{
			// enable the play and stop buttons, and the slider
			enabled = TRUE;
			Play();
			// autoplay
			//if (PlayerDialog->m_AutoPlayCheckBox.GetCheck()) Play();
		}
        break;

		case XA_INPUT_STATE_CLOSED:
		{
			// disable the play and stop buttons, and the slider
			enabled = FALSE;
		}
        break;
    }

    //PlayerDialog->m_PlayButton.EnableWindow(enabled);
    //PlayerDialog->m_StopButton.EnableWindow(enabled);
    //PlayerDialog->m_Slider.EnableWindow(enabled);
}

void LSPlayer::OnNotifyInputDuration(unsigned long duration)
{
    char caption[128];
    sprintf(caption, "%d seconds", duration);
    //PlayerDialog->m_DurationLabel.SetWindowText(caption);
}

void LSPlayer::OnNotifyInputTimecode(XA_TimecodeInfo *info)
{
    char caption[128];

    sprintf(caption, "%02d:%02d:%02d", 
            info->h,
            info->m,
            info->s);
    //PlayerDialog->m_TimecodeLabel.SetWindowText(caption);
}

void LSPlayer::OnNotifyInputStreamInfo(XA_StreamInfo *info)
{
    char caption[128];

    sprintf(caption, "MPEG %d Layer %d, %d kbps, %d Hz", 
            info->level,
            info->layer,
            info->bitrate,
            info->frequency);
    //PlayerDialog->m_TypeLabel.SetWindowText(caption);
}

void LSPlayer::OnNotifyInputModuleInfo(XA_ModuleInfo *info)
{
    //if (InfoDialog == NULL) return;
    //InfoDialog->m_InputList.AddString(info->name);
}

void LSPlayer::OnNotifyOutputState(XA_OutputState state)
{
    switch(state) 
	{
		case XA_OUTPUT_STATE_OPEN:
		{
			// enable the volume button
			//PlayerDialog->m_VolumeButton.EnableWindow(TRUE);
		}
        break;

		case XA_INPUT_STATE_CLOSED:
		{
			// disable volume button
			//PlayerDialog->m_VolumeButton.EnableWindow(FALSE);
		}
        break;
    }
}

void LSPlayer::OnNotifyOutputModuleInfo(XA_ModuleInfo *info)
{
    //if (InfoDialog == NULL) return;
    //InfoDialog->m_OutputList.AddString(info->name);    
}

void LSPlayer::OnNotifyOutputMasterLevel(unsigned char level)
{
    //if (VolumeDialog == NULL) return;
    //VolumeDialog->m_MasterSlider.SetPos(level);
}

void LSPlayer::OnNotifyOutputPcmLevel(unsigned char level)
{
    //if (VolumeDialog == NULL) return;
    //VolumeDialog->m_PcmSlider.SetPos(level);
}

void LSPlayer::OnNotifyOutputBalance(unsigned char balance)
{
    //if (VolumeDialog == NULL) return;
    //VolumeDialog->m_BalanceSlider.SetPos(balance);
}

void LSPlayer::OnNotifyCodecEqualizer(XA_EqualizerInfo *equalizer)
{
    /*if (EqualizerDialog == NULL) return;

    // if the equalizer if NULL, it means it's disabled
    if (equalizer == NULL) {
        EqualizerDialog->m_EnableEQCheckBox.SetCheck(FALSE);
    } else {
        EqualizerDialog->m_EnableEQCheckBox.SetCheck(TRUE);

        // set the slider positions
        EqualizerDialog->m_Slider1.SetPos(-equalizer->left[ 0]);
        EqualizerDialog->m_Slider2.SetPos(-equalizer->left[ 1]);
        EqualizerDialog->m_Slider3.SetPos(-equalizer->left[ 2]);
        EqualizerDialog->m_Slider4.SetPos(-equalizer->left[ 4]);
        EqualizerDialog->m_Slider5.SetPos(-equalizer->left[ 6]);
        EqualizerDialog->m_Slider6.SetPos(-equalizer->left[ 8]);
        EqualizerDialog->m_Slider7.SetPos(-equalizer->left[14]);
        EqualizerDialog->m_Slider8.SetPos(-equalizer->left[20]);
    }*/
}