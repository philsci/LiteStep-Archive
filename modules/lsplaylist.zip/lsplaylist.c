//#pragma warning(disable:4786)

#include <windows.h>
//#include <string>
//#include <map>

#include "exports.h"
#include "lsapi.h"
#include "resource.h"


BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();
void Watch();
void CreateFileList(char*);

void BangHide(HWND caller, char* args);
void BangShow(HWND caller, char* args);
void BangToggle(HWND caller, char* args);
void BangFocus(HWND caller, char* args);

HINSTANCE hInstance;
HWND hwndMain;
HANDLE thread=NULL;
HANDLE notify=NULL;

char* szAppName = "LSPlayList";
char WATCH_DIRECTORY[MAX_PATH] = "";
int X, Y, W=200, H=100;
int ScreenX, ScreenY;

struct fnode
{
	char path[MAX_PATH];
	char fname[256];
	float size;

	struct fnode* next;
};

struct fnode* FileList[27];

/*using namespace std;

typedef map<int, string, less<int> > INT2STRING;
INT2STRING theMap;
INT2STRING::iterator theIterator;
string theString = "";
int index;*/

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	DWORD threadID;

	hInstance = dllInst;
	LoadSetup();
	CreateFileList(WATCH_DIRECTORY);

	hwndMain = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAIN), parent, DlgProc);
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);

	if (strlen(WATCH_DIRECTORY))
	{
		notify = FindFirstChangeNotification(WATCH_DIRECTORY, TRUE, FILE_NOTIFY_CHANGE_FILE_NAME);
		if (notify == INVALID_HANDLE_VALUE) 
		{
			LPVOID lpMsgBuf;
			FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
			MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
			LocalFree( lpMsgBuf );
			return -1;
		}	
		thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Watch, (LPVOID)NULL, 0, &threadID);
	}
	else MessageBox(parent, "You must specify a directory for LSPlayList to monitor.", szAppName, MB_SYSTEMMODAL);

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!LSPlayListHide");
	RemoveBangCommand("!LSPlayListShow");
	RemoveBangCommand("!LSPlayListToggle");
	
	TerminateThread(thread, 0);
	DestroyWindow(hwndMain);

	return 0;
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
				
			if (!(pos->flags & SWP_NOMOVE))
			{
				if (pos->x+W >= ScreenX-5) pos->x = ScreenX - W;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+H >= ScreenY-5) pos->y = ScreenY - H;
				else if (pos->y <= 5) pos->y = 0;
			}
		}
		break;

	}

	return 0;
}

void LoadSetup()
{
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	X = GetRCInt("LSPlayListX", 0);
	Y = GetRCInt("LSPlayListY", 0);
	GetRCString("LSPlayListDirectory", WATCH_DIRECTORY, "", MAX_PATH);
	
	AddBangCommand("!LSPlayListHide", BangHide);
	AddBangCommand("!LSPlayListShow", BangShow);
	AddBangCommand("!LSPlayListToggle", BangToggle);
}

void BangHide(HWND caller, char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangShow(HWND caller, char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangToggle(HWND caller, char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void Watch()
{
	while (1)
	{
		WaitForSingleObject(notify, INFINITE);

		//for (int x=0; 1; x++)
		//{
			//theIterator = theMap.find(x);
			//if(theIterator == theMap.end()) break;
		//}
        

		// Get the change...

		FindNextChangeNotification(notify);
	}
}

void CreateFileList(char* match)
{
	HANDLE fff = NULL;
	char path[MAX_PATH] = "";
	WIN32_FIND_DATA* fd = (WIN32_FIND_DATA*)malloc(sizeof(WIN32_FIND_DATA));

	sprintf(path, "%s\\*", match);
	fff = FindFirstFile(path, fd);

	while (FindNextFile(fff, fd))
	{
		if (fd->dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (strcmp(fd->cFileName, ".") && strcmp(fd->cFileName, ".."))
			{
				char temp[256] = "";
				strcpy(temp, fd->cFileName);
				sprintf(path, "%s\\%s", match, fd->cFileName);
				CreateFileList(path);
			}
		}
		else
		{
			if (strstr(fd->cFileName, ".mp3"))
			{
				static int count=0;
				//theMap.insert(INT2STRING::value_type(count++, fd->cFileName));
			}
		}
	}

	FindClose(fff);
}
