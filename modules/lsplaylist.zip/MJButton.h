#define MJ_BTN_CLICKED		WM_USER + 200
#define MJ_BTN_KEYDOWN		WM_USER + 201
#define P_PROPERTIES	100
#define P_ANCHOR_LEFT	101
#define P_ANCHOR_RIGHT	102
#define P_ANCHOR_TOP	103
#define P_ANCHOR_BOTTOM	104
#define P_ANCHOR_BR		105

#ifndef __MJBUTTON_H
#define __MJBUTTON_H

class MJButton
{
private:
	static int p_count;
	HMENU m_popup;
	BOOL m_size_change;

protected:
	enum Mouse_States
	{
		s_normal=0,
		s_over,
		s_clicked
	} m_state;

public:
	int m_x, m_y, m_w, m_h, m_anchor;
	HBITMAP m_normal, m_over, m_clicked;
	HWND m_parent, m_hwnd, m_tool;
	HINSTANCE m_hinst;
	char *m_name, *m_ini;

	MJButton(LPCTSTR name,
			 HWND parent, 
			 HINSTANCE hInstance,
			 LPCTSTR ini,
			 LPCTSTR ttip,
			 int def_x=0,
			 int def_y=0,
			 int def_w=0,
			 int def_h=0,
			 LPCTSTR skin_dir="",
			 LPCTSTR def_normal="",
			 LPCTSTR def_over="",
			 LPCTSTR def_clicked="");

	~MJButton();

	LRESULT CALLBACK m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	BOOL CALLBACK m_dlgproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

	void MoveWindow(int x, int y);
	void RMoveWindow(int cx, int cy);
	void ResizeWindow(int w, int h);
};

#endif