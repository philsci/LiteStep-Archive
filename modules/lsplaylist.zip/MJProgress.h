#define MJ_PRG_LBUTTONDOWN		WM_USER + 400
#define MJ_PRG_MOUSEMOVE		WM_USER + 401

#define P_PROG_VERTICAL		100
#define P_PROG_HORIZONTAL	101
#define P_PROG_STRETCH		102
#define P_PROG_REVEAL		103

#ifndef __MJPROGRESS_H
#define __MJPROGRESS_H

class MJProgress
{
private:
	LONG p_oldproc;
	BOOL m_size_change;
	int m_pos;

protected:

public:
	int m_x, m_y, m_w, m_h, m_range[2];
	HBITMAP m_bg, m_fg;
	BITMAP m_bbg, m_bfg;
	HINSTANCE m_hinst;
	HWND m_parent, m_hwnd;
	char *m_name, *m_ini, *m_pre;
	int m_direction;
	BOOL m_stretch, m_reveal;
	HMENU m_popup;

	MJProgress(LPCTSTR name, LPCTSTR pre, HWND progress, HWND parent, HINSTANCE hInstance, LPCTSTR ini,
				int def_x=0, int def_y=0,
				int def_w=0, int def_h=0,
				LPCTSTR skin_dir="",
				LPCTSTR def_bg="",
				LPCTSTR def_fg="");
	~MJProgress();

	LRESULT CALLBACK m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	void SetRange(int, int);
	void SetPos(int);
	int GetPos();
	void Resize(int w, int h);
};

#endif
