#ifndef EXPORTS_H
#define EXPORTS_H

#include "wharfdata.h"

#ifdef __cplusplus
extern "C" {
#endif

/* WHARF Functions */
__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
__declspec( dllexport ) int quitWharfModule(HINSTANCE dll);

/* LOAD MODULE Functions */
__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

__declspec( dllexport ) void NoLitestep();

#ifdef __cplusplus
}
#endif

#endif 
