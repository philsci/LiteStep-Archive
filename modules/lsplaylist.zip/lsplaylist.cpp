#pragma warning(disable:4786)

#include <windows.h>
#include <commctrl.h>
#include <time.h>
#include <string>
#include <malloc.h>

#include "exports.h"
#include "lsapi.h"
#include "resource.h"

#include "lsplayer.h"
#include "LSPlaylist.h"
#include "MJButton.h"
#include "MJProgress.h"
#include "HotkeyDlg.h"
#include "SkinBrowser.h"

#define WM_MOUSEWHEEL                   0x020A

#define P_SHUFFLE			101
#define P_AUTOPLAY			102
#define P_EXIT				103
#define P_PLAY				104
#define P_PAUSE				105
#define P_STOP				106
#define P_NEXT				107
#define P_PREV				108
#define P_HOTKEY			109
#define P_USETRANS			110
#define P_ALWAYSONTOP		111
#define P_EQ				112
#define P_EDITLAYOUT		113
#define P_SKINBROWSER		114
#define P_EQ_ZERO			115
#define P_ADD_DIR			116

LSPlayer* player;

//using namespace std;

//typedef list<string> SONGLIST;
//typedef map<string, ID3Data*> SONGMAP;
//SONGMAP theMap;
//SONGMAP::iterator mit;
//SONGLIST theList;
//SONGLIST::iterator lit;

int AddTrack(HWND hwnd, const char* name, const char* dir, int x);
BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK NewListDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AskNewListDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AskWatchDirectoryDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK EQProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK NewListProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ComboProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

void LoadSetup();
void LoadDirectories();
void SetupDialog();
void SetupHotkey(char* name, int id);
void SetupEQ();
void Watch(LPVOID);
void StartWatching();
void StopWatching();
DWORD WINAPI CreateFileList(LPVOID);
int ListView_SearchForItem(HWND, char*);
void WritePrivateProfileInt(char* lpAppName, char* lpKeyName, int val, char* lpFileName);
void ResizeAllWindows(int mode, int w, int h);
void ExportPlaylist();
void ImportPlaylist();
void SetupComboList(int cursel);
int myrand();
void EQUpdate();

void BangHide(HWND caller, char* args);
void BangShow(HWND caller, char* args);
void BangToggle(HWND caller, char* args);
void BangFocus(HWND caller, char* args);
void BangPlay(HWND caller, char* args);
void BangPause(HWND caller, char* args);
void BangStop(HWND caller, char* args);
void BangNext(HWND caller, char* args);
void BangPrev(HWND caller, char* args);
void BangFwd(HWND caller, char* args);
void BangBack(HWND caller, char* args);
void BangAlwaysOnTop(HWND caller, char* args);

HINSTANCE hInstance;
HWND hParent, hwndMain, hAllTracks, hNewTracks, hSomeTracks, NewTrackWnd, EditTrackWnd, ComboWnd, hCurrentList, EQWnd;
MJButton *LayoutBtn, *ImportBtn, *ExportBtn, *DeleteBtn, *TransferBtn, *ExitBtn;
MJButton *PlayBtn, *PauseBtn, *StopBtn, *PrevBtn, *NextBtn, *BackBtn, *FwdBtn;
MJButton *EditListBtn, *NewListBtn;
MJProgress *ProgressWnd, *EQ[16];
HANDLE *thread=NULL;
HANDLE *notify=NULL;
HMENU popup, eqpopup;

MJButton **GButtons;

BOOL NOTIFY=0, NOWATCH=FALSE, RECYCLE=FALSE;
BOOL STARTHIDDEN=FALSE;
BOOL LITESTEP=TRUE, SHUFFLE=FALSE, USETRANS=TRUE, ALWAYSONTOP=FALSE;
BOOL SIZECHANGE=TRUE, POSCHANGE=TRUE;
BOOL FAKE_WINAMP=FALSE, USEID3=TRUE;

char* szAppName = "LSPlayList";
char **WATCH_DIRECTORY;
char NEW_DIRECTORY[MAX_PATH] = "";
char SKIN_DIR[MAX_PATH] = "";
char SKIN[100] = "";
char SKIN_PATH[MAX_PATH] = "";
int X, Y, W, H, ListX, ListY, ListW, ListH, OW=0, OH=0;
int ProgX, ProgY, ProgW, ProgH, ComboX, ComboY, ComboW, ComboH;
int ScreenX, ScreenY;
int TrackCount=0, NewTrackCount=0, NumPlaylists=0;
char ini[MAX_PATH] = "", skin_ini[MAX_PATH];
BOOL EDITLIST=FALSE, LAYOUT_EDIT=FALSE;
char NEWLIST[256] = "";
DWORD ListThread, ThreadID;
HANDLE hListThread, mutex;
unsigned long TRACKPOS=0;
int GButtonCount=0, DirCount=0;

LONG OldNewListProc, OldComboProc;
char* WinampClass = "Winamp v1.x";
HWND FakeWinampWnd;

struct Images
{
	HBITMAP t, b, r, l;
	BITMAP bt, bb, br, bl;
	HBITMAP bg;
	BITMAP bbg;
	HBITMAP p_fg, p_bg;
	BITMAP p_bfg, p_bbg;
	HBITMAP l_bg;
	BITMAP l_bbg;
	COLORREF l_fgcolor, l_fgselcolor;
	HFONT l_font;
	int l_fontsize;
	HBITMAP eqt, eqb, eqr, eql;
	BITMAP beqt, beqb, beqr, beql;
	HBITMAP eq_bg;
	BITMAP eq_bbg;
} *imgs;


void NoLitestep()
{
	LITESTEP=FALSE;
}

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	hParent = parent;	
	hInstance = dllInst;
	LoadSetup();

	if (!RECYCLE)
	{
		player = new LSPlayer(dllInst, hwndMain);
	}

	hwndMain = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_PLAYLIST), parent, DlgProc);
	player->m_hwnd = hwndMain;
	NewTrackWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_NEWTRACKLIST), parent, NewListDlgProc);
	EditTrackWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_EDITTRACKLIST), parent, NewListDlgProc);
	EQWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_EQUALIZER), hwndMain, EQProc);

	if (FAKE_WINAMP)
	{
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = DefWindowProc;
		wc.hInstance = hInstance;
		wc.lpszClassName = WinampClass;
		RegisterClass(&wc);

		FakeWinampWnd = CreateWindowEx(WS_EX_TOOLWINDOW, WinampClass, "Playback", WS_POPUP, 0, 0, 0, 0, NULL, NULL, hInstance, 0);
	}

	SetupDialog();
	if (!STARTHIDDEN) ShowWindow(hwndMain, SW_SHOW);
	if (ALWAYSONTOP) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);

	StartWatching();

	RECYCLE=FALSE;

	return 0;
}

void StartWatching()
{
	DWORD threadID;

	if (WATCH_DIRECTORY)
	{
		for (int x=0; x<DirCount; x++)
		{
			if (strlen(WATCH_DIRECTORY[x]))
			{
				notify[x] = FindFirstChangeNotification(WATCH_DIRECTORY[x], TRUE, FILE_NOTIFY_CHANGE_FILE_NAME);
				if (notify[x] == INVALID_HANDLE_VALUE) 
				{
					LPVOID lpMsgBuf;
					FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) &lpMsgBuf, 0, NULL);
					MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
					LocalFree( lpMsgBuf );
				}	
				thread[x] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Watch, (LPVOID)notify[x], 0, &threadID);
			}
		}
	}
	else MessageBox(hwndMain, "You must specify a directory for LSPlayList to monitor.", szAppName, MB_SYSTEMMODAL);
}

void StopWatching()
{
	for (int x=0; x<DirCount; x++) TerminateThread(thread[x], 0);
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	int x=0;

	if (!RECYCLE)
	{
		player->Stop();
		player->Stop();
		player->InputClose();
		player->Exit();
		delete player;
	}
	
	StopWatching();
	TerminateThread(hListThread, 0);
	CloseHandle(mutex);

	if (IsWindowVisible(EQWnd)) WritePrivateProfileString("EQ", "Visible", "1", skin_ini);
	else WritePrivateProfileString("EQ", "Visible", "0", skin_ini);

	DestroyWindow(hwndMain);
	DestroyWindow(NewTrackWnd);
	DestroyWindow(EditTrackWnd);
	DestroyWindow(EQWnd);

	if (FAKE_WINAMP)
	{
		DestroyWindow(FakeWinampWnd);
		UnregisterClass(WinampClass, dll);
	}

	DestroyMenu(popup);
	DestroyMenu(eqpopup);

	UnregisterHotKey(hwndMain, HOTKEY_PLAY);
	UnregisterHotKey(hwndMain, HOTKEY_PAUSE);
	UnregisterHotKey(hwndMain, HOTKEY_STOP);
	UnregisterHotKey(hwndMain, HOTKEY_NEXT);
	UnregisterHotKey(hwndMain, HOTKEY_PREV);
	UnregisterHotKey(hwndMain, HOTKEY_FWD);
	UnregisterHotKey(hwndMain, HOTKEY_BACK);
	UnregisterHotKey(hwndMain, HOTKEY_SHOW);
	UnregisterHotKey(hwndMain, HOTKEY_HIDE);

	delete LayoutBtn;
	LayoutBtn=NULL;
	delete ImportBtn;
	ImportBtn=NULL;
	delete ExportBtn;
	ExportBtn=NULL;
	delete DeleteBtn;
	DeleteBtn=NULL;
	delete TransferBtn;
	TransferBtn=NULL;

	delete PlayBtn;
	PlayBtn=NULL;
	delete PauseBtn;
	PauseBtn=NULL;
	delete StopBtn;
	StopBtn=NULL;
	delete PrevBtn;
	PrevBtn=NULL;
	delete NextBtn;
	NextBtn=NULL;
	delete BackBtn;
	BackBtn=NULL;
	delete FwdBtn;
	FwdBtn=NULL;
	
	delete NewListBtn;
	NewListBtn=NULL;
	delete EditListBtn;
	EditListBtn=NULL;

	delete ProgressWnd;
	ProgressWnd=NULL;

	for (x=0; x < 16; x++)
	{
		delete EQ[x];
	}

	for (x=0; x < GButtonCount; x++)
	{
		delete GButtons[x];
	}
	delete GButtons;

	DeleteObject(imgs->b);
	DeleteObject(imgs->t);
	DeleteObject(imgs->r);
	DeleteObject(imgs->l);
	DeleteObject(imgs->bg);
	DeleteObject(imgs->p_fg);
	DeleteObject(imgs->p_bg);
	DeleteObject(imgs->l_bg);
	DeleteObject(imgs->l_font);
	DeleteObject(imgs->eq_bg);
	DeleteObject(imgs->eqb);
	DeleteObject(imgs->eqt);
	DeleteObject(imgs->eqr);
	DeleteObject(imgs->eql);

	delete imgs;
	imgs=NULL;

	OW=OH=0;

	if (LITESTEP)
	{
		RemoveBangCommand("!LSPlayListHide");
		RemoveBangCommand("!LSPlayListShow");
		RemoveBangCommand("!LSPlayListToggle");
		RemoveBangCommand("!LSPlayListPlay");
		RemoveBangCommand("!LSPlayListPause");
		RemoveBangCommand("!LSPlayListStop");
		RemoveBangCommand("!LSPlayListNext");
		RemoveBangCommand("!LSPlayListPrev");
		RemoveBangCommand("!LSPlayListFwd");
		RemoveBangCommand("!LSPlayListBack");
		RemoveBangCommand("!LSPlayListAlwaysOnTop");
	}
	else
	{
		delete ExitBtn;
		ExitBtn=NULL;
	}

	return 0;
}

int AddTrack(HWND hwnd, const char* name, const char* dir, int x)
{
	LVITEM item;
	int ret;

	item.iItem = x;
	item.iSubItem = 0;
	item.mask = LVIF_TEXT;
	item.pszText=(char*)name;
	item.cchTextMax = strlen(name);

	ret = ListView_InsertItem(hwnd, &item);

	if (ret >= 0)
	{
		item.iItem = ret;
		item.iSubItem = 1;
		item.mask = LVIF_TEXT;
		item.pszText = (char*)dir;
		item.cchTextMax = strlen(dir);
		
		ListView_SetItem(hwnd, &item);
	}

	return ret;
}

BOOL ListView_SearchForItem(HWND hwnd, char* find)
{
	LVFINDINFO* fi = new LVFINDINFO;
	fi->flags = LVFI_STRING;
	fi->psz = find;
	return ListView_FindItem(hwnd, -1, fi);
}

void WritePrivateProfileInt(char* lpAppName, char* lpKeyName, int val, char* lpFileName)
{
	char temp[256] = "";
	sprintf(temp, "%d", val);
	WritePrivateProfileString(lpAppName, lpKeyName, temp, lpFileName);
}

BOOL CALLBACK DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { PostQuitMessage(0); return TRUE; }
			}
		}
		break;

		case WM_NCHITTEST: 
		{
			RECT wr;
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);
			long ht;

			GetWindowRect(hwnd, &wr);

			if (x >= (wr.right-imgs->br.bmWidth)) ht = HTRIGHT;
			else if (x <= (wr.left+imgs->bl.bmWidth)) ht = HTLEFT;
			else if (y >= (wr.bottom-imgs->bb.bmHeight)) ht = HTBOTTOM;
			else if (y <= (wr.top+imgs->bt.bmHeight)) ht = HTTOP;
			else ht = HTCAPTION;

			SetWindowLong(hwnd, DWL_MSGRESULT, ht);
			return TRUE;
		}
		break;

		case WM_NCPAINT:
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbufbmp, oldsrcbmp;
			RECT r;
			int TW, TH;

			// Setup
			GetWindowRect(hwnd, &r);
			TW = r.right-r.left;
			TH = r.bottom-r.top;
			bufbmp = CreateCompatibleBitmap(hdc, TW, TH);
			oldbufbmp = (HBITMAP)SelectObject(buf, bufbmp);

			// PAINT!
			// Background
			if (hwnd != EQWnd)
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->bg);
				StretchBlt(buf, imgs->bl.bmWidth, imgs->bt.bmHeight, TW-imgs->bl.bmWidth-imgs->br.bmWidth, TH-imgs->bt.bmHeight-imgs->bb.bmHeight, src, 0, 0, imgs->bbg.bmWidth, imgs->bbg.bmHeight, SRCCOPY);
			}
			else
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->eq_bg);
				StretchBlt(buf, imgs->bl.bmWidth, imgs->bt.bmHeight, TW-imgs->bl.bmWidth-imgs->br.bmWidth, TH-imgs->bt.bmHeight-imgs->bb.bmHeight, src, 0, 0, imgs->eq_bbg.bmWidth, imgs->eq_bbg.bmHeight, SRCCOPY);
			}
			SelectObject(src, oldsrcbmp);

			// Top border
			if (hwnd != EQWnd)
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->t);
				StretchBlt(buf, 0, 0, TW, imgs->bt.bmHeight, src, 0, 0, imgs->bt.bmWidth, imgs->bt.bmHeight, SRCCOPY);
			}
			else
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->eqt);
				StretchBlt(buf, 0, 0, TW, imgs->beqt.bmHeight, src, 0, 0, imgs->beqt.bmWidth, imgs->beqt.bmHeight, SRCCOPY);
			}
			SelectObject(src, oldsrcbmp);

			// Left border
			if (hwnd != EQWnd)
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->l);
				StretchBlt(buf, 0, imgs->bt.bmHeight, imgs->bl.bmWidth, TH-imgs->bt.bmHeight-imgs->bb.bmHeight, src, 0, 0, imgs->bl.bmWidth, imgs->bl.bmHeight, SRCCOPY);
			}
			else
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->eql);
				StretchBlt(buf, 0, imgs->beqt.bmHeight, imgs->beql.bmWidth, TH-imgs->beqt.bmHeight-imgs->beqb.bmHeight, src, 0, 0, imgs->beql.bmWidth, imgs->beql.bmHeight, SRCCOPY);
			}
			SelectObject(src, oldsrcbmp);

			// Bottom border
			if (hwnd != EQWnd)
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->b);
				StretchBlt(buf, 0, TH-imgs->bb.bmHeight, TW, imgs->bb.bmHeight, src, 0, 0, imgs->bb.bmWidth, imgs->bb.bmHeight, SRCCOPY);
			}
			else
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->eqb);
				StretchBlt(buf, 0, TH-imgs->beqb.bmHeight, TW, imgs->beqb.bmHeight, src, 0, 0, imgs->beqb.bmWidth, imgs->beqb.bmHeight, SRCCOPY);
			}
			SelectObject(src, oldsrcbmp);

			// Right border
			if (hwnd != EQWnd)
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->r);
				StretchBlt(buf, TW-imgs->br.bmWidth, imgs->bt.bmHeight, imgs->br.bmWidth, TH-imgs->bt.bmHeight-imgs->bb.bmHeight, src, 0, 0, imgs->br.bmWidth, imgs->br.bmHeight, SRCCOPY);
			}
			else
			{
				oldsrcbmp = (HBITMAP)SelectObject(src, imgs->eqr);
				StretchBlt(buf, TW-imgs->beqr.bmWidth, imgs->beqt.bmHeight, imgs->beqr.bmWidth, TH-imgs->beqt.bmHeight-imgs->beqb.bmHeight, src, 0, 0, imgs->beqr.bmWidth, imgs->beqr.bmHeight, SRCCOPY);
			}
			SelectObject(src, oldsrcbmp);

			// Magic Pink(tm)
			if (SIZECHANGE) 
			{
				if (hwnd == hwndMain) SIZECHANGE=FALSE;
				if (USETRANS) SetWindowBitmapRgn(hwnd, buf, bufbmp);
				else SetWindowBitmapRgn(hwnd, NULL, NULL);
			}

			// Draw to screen
			BitBlt(hdc, 0, 0, TW, TH, buf, 0, 0, SRCCOPY);
			
			// Clean up
			DeleteDC(src);
			DeleteObject(oldsrcbmp);
			SelectObject(buf, oldbufbmp);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbufbmp);

			EndPaint(hwnd, &ps);
		}
		SetWindowLong(hwnd, DWL_MSGRESULT, 0);
		return TRUE;

		case LSP_RECYCLE:
		{
			RECYCLE=TRUE;
			quitModule(hInstance);
			initModuleEx(hParent, hInstance, ".");
		}
		break;

		case LSP_NEXTSONG:
		{
			if (!RECYCLE)
				SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)NextBtn, 0);
		}
		break;

		case LSP_POS:
		{
			if (!RECYCLE)
			{
				TRACKPOS = (unsigned long)wParam;
				ProgressWnd->SetPos(TRACKPOS);
			}
		}
		break;

		case LSP_INPUTNAME:
		{
			if (!RECYCLE)
			{
				WaitForSingleObject(mutex, INFINITE);

				char *title=NULL, *artist=NULL;
				char trackname[256] = "";
				strcpy(trackname, (char*)wParam);
			
				FILE* file = fopen(trackname, "r");
				char temp[256] = "";
				char dispname[256] = "";
							
				strcpy(dispname, strrchr(trackname, '\\')+1);

				fseek(file, -128L, SEEK_END);
				fgets(temp, 128, file);
				fclose(file);

				if (!strncmp(temp, "TAG", 3))
				{
					char* p = temp+3;
					int x;

					if (*p)
					{
						title = (char*)malloc(sizeof(char) * strlen(p));
						strncpy(title, p, 30);
						x=strlen(title)-1;
						while (title[x] == ' ')
						{
							title[x] = '\0';
							x--;
						}
						p+=30;

						if (*p)
						{
							artist = (char*)malloc(sizeof(char) * strlen(p));
							strncpy(artist, p, 30);
							x=strlen(artist)-1;
							while (artist[x] == ' ')
							{
								artist[x] = '\0';
								x--;
							}
						}
					}

					if ((title || artist) && USEID3)
					{
						sprintf(dispname, "%s - %s", artist, title);
					}
				}
				
				SetWindowText(hwndMain, dispname);
				if (FAKE_WINAMP) SetWindowText(FakeWinampWnd, dispname);

				SetEvent(mutex);
			}
		}
		break;

		case MJ_BTN_CLICKED:
		{
			static BOOL PLAYING=FALSE;
			static BOOL PAUSED=FALSE;

			if (!LAYOUT_EDIT)
			{
				if ((MJButton*)wParam == LayoutBtn)
				{
					EnableWindow(TransferBtn->m_hwnd, TRUE);
					EnableWindow(DeleteBtn->m_hwnd, TRUE);
					EnableWindow(EditListBtn->m_hwnd, TRUE);
					LAYOUT_EDIT=TRUE;
				}
				else if ((MJButton*)wParam == ImportBtn)
				{
					ImportPlaylist();
				}
				else if ((MJButton*)wParam == ExportBtn)
				{
					NOWATCH=TRUE;
					ExportPlaylist();
					NOWATCH=FALSE;
				}
				else if ((MJButton*)wParam == ExitBtn)
				{
					PostQuitMessage(0);
				}
				else if ((MJButton*)wParam == TransferBtn)
				{
					SendMessage(hAllTracks, WM_LBUTTONDBLCLK, 0, 0);
				}
				else if ((MJButton*)wParam == DeleteBtn)
				{
					if (IsWindowEnabled(DeleteBtn->m_hwnd))
					{
						int sel = ListView_GetSelectionMark(hSomeTracks);
						if (sel < 0) break;

						int selcount = ListView_GetSelectedCount(hSomeTracks);
						char temp[256] = "";
						char dir[256] = "";

						// Delete all selected items from playlist
						for (int count=0; count < selcount; count++)
						{
							ListView_GetItemText(hSomeTracks, sel, 0, temp, 256);
							ListView_GetItemText(hSomeTracks, sel, 1, dir, 256);
							AddTrack(hAllTracks, temp, dir, TrackCount--);
							ListView_DeleteItem(hSomeTracks, sel);
							sel = ListView_GetNextItem(hwnd, -1, LVNI_SELECTED);
						}

						// Write all contents of playlist to file
						sel = SendMessage(ComboWnd, CB_GETCURSEL, 0, 0);
						char list[256] = "";
						SendMessage(ComboWnd, CB_GETLBTEXT, (WPARAM)sel, (LPARAM)list);
						WritePrivateProfileSection(list, NULL, ini);
						for (count=0; count < ListView_GetItemCount(hSomeTracks); count++)
						{
							char track[256] = "";
							char name[256] = "";
							char dir[256] = "";
							ListView_GetItemText(hSomeTracks, count, 0, temp, 256);
							ListView_GetItemText(hSomeTracks, count, 1, dir, 256);
							sprintf(track, "Track%d", count);
							sprintf(name, "%s\\%s", dir, temp);
							WritePrivateProfileString(list, track, name, ini);
						}
					}
				}
				else if ((MJButton*)wParam == PlayBtn)
				{
					if (!PAUSED)
					{
						if (PLAYING) player->Stop();

						int sel = ListView_GetSelectionMark(hCurrentList);
						if (sel < 0)
						{							
							if (SHUFFLE) sel=myrand()%ListView_GetItemCount(hCurrentList);
							else sel=0;
							ListView_SetSelectionMark(hCurrentList, sel);
							ListView_SetItemState(hCurrentList, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
							ListView_EnsureVisible(hCurrentList, sel, FALSE);
						}
						
						char name[256] = "";
						char track[256] = "";
						char dir[256] = "";
						ListView_GetItemText(hCurrentList, sel, 0, name, 256);
						ListView_GetItemText(hCurrentList, sel, 1, dir, 256);
						sprintf(track, "%s\\%s", dir, name);

						player->InputOpen(track);
					}
					player->Play();
					PLAYING=TRUE;
					PAUSED=FALSE;
				}
				else if ((MJButton*)wParam == PauseBtn)
				{
					if (PLAYING) { player->Pause(); PLAYING=FALSE; PAUSED=TRUE; }
					else if (PAUSED) { player->Play(); PLAYING=TRUE; PAUSED=FALSE; }
				}
				else if ((MJButton*)wParam == StopBtn)
				{
					if (PLAYING)
					{
						player->Stop();
						PLAYING=FALSE;
						PAUSED=FALSE;
					}
				}
				else if ((MJButton*)wParam == BackBtn)
				{
					if (PLAYING)
					{
						//player->Pause();
						player->Seek(TRACKPOS-5, 400);						
						//player->Play();
					}
				}
				else if ((MJButton*)wParam == FwdBtn)
				{
					if (PLAYING)
					{
						//player->Pause();
						player->Seek(TRACKPOS+5, 400);
						//player->Play();
					}
				}
				else if ((MJButton*)wParam == PrevBtn)
				{
					int sel = ListView_GetSelectionMark(hCurrentList), oldsel;
					int count = ListView_GetItemCount(hCurrentList);

					if (PLAYING) player->Stop();

					if (sel < 0) 
					{
						if (SHUFFLE) sel = myrand() % count;
						else sel=0; 
						
						ListView_SetSelectionMark(hCurrentList, sel); 
						ListView_SetItemState(hCurrentList, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
					}

					char name[256] = "";
					char track[256] = "";
					char dir[256] = "";
					oldsel=sel;
					while (oldsel == sel)
					{
						if (SHUFFLE) sel = myrand() % count;
						else if (!sel) sel=count-1;
						else sel--;

						ListView_GetItemText(hCurrentList, sel, 0, name, 256);
						ListView_GetItemText(hCurrentList, sel, 1, dir, 256);
						oldsel = ListView_SetSelectionMark(hCurrentList, sel);
						
						ListView_EnsureVisible(hCurrentList, sel, FALSE);
						if (sel != oldsel)
						{
							ListView_SetItemState(hCurrentList, oldsel, 0, LVIS_SELECTED | LVIS_FOCUSED);
							ListView_SetItemState(hCurrentList, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
						}
					}
					
					if (PLAYING)
					{
						sprintf(track, "%s\\%s", dir, name);
						player->InputOpen(track);
						player->Play();
					}
				}
				else if ((MJButton*)wParam == NextBtn)
				{
					int sel = ListView_GetSelectionMark(hCurrentList), oldsel;
					int count = ListView_GetItemCount(hCurrentList);

					if (PLAYING) player->Stop();

					if (sel < 0) 
					{
						if (SHUFFLE) sel = myrand() % count;
						else sel=0; 
						
						ListView_SetSelectionMark(hCurrentList, sel); 
						ListView_SetItemState(hCurrentList, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
					}

					char name[256] = "";
					char track[256] = "";
					char dir[256] = "";
					oldsel=sel;
					while (oldsel == sel)
					{
						if (SHUFFLE) sel = myrand() % count;
						else if (sel < ListView_GetItemCount(hCurrentList)-1) sel++;
						else sel=0;

						ListView_GetItemText(hCurrentList, sel, 0, name, 256);
						ListView_GetItemText(hCurrentList, sel, 1, dir, 256);
						oldsel = ListView_SetSelectionMark(hCurrentList, sel);
						
						ListView_EnsureVisible(hCurrentList, sel, FALSE);
						if (sel != oldsel)
						{
							ListView_SetItemState(hCurrentList, oldsel, 0, LVIS_SELECTED | LVIS_FOCUSED);
							ListView_SetItemState(hCurrentList, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
						}
					}
					
					if (PLAYING)
					{
						sprintf(track, "%s\\%s", dir, name);

						player->InputOpen(track);
						player->Play();
					}
				}
				else if ((MJButton*)wParam == EditListBtn)
				{
					if (!EDITLIST)
					{
						EDITLIST=TRUE;
						SetParent(hAllTracks, EditTrackWnd);
						ShowWindow(hAllTracks, SW_SHOW);
						SetWindowPos(EditTrackWnd, NULL, X+W, Y, W, H, SWP_NOZORDER);
						ShowWindow(EditTrackWnd, SW_SHOW);
						EnableWindow(TransferBtn->m_hwnd, TRUE);
					}
					else
					{
						int sel = SendMessage(ComboWnd, CB_GETCURSEL, 0, 0);
						char list[256] = "";
						SendMessage(ComboWnd, CB_GETLBTEXT, (WPARAM)sel, (LPARAM)list);
						
						SetParent(hAllTracks, hwndMain);
						ShowWindow(EditTrackWnd, SW_HIDE);
						EnableWindow(TransferBtn->m_hwnd, FALSE);

						if (strcmp(list, "All Songs") && strcmp(list, "====================")) 
						{
							ShowWindow(hAllTracks, SW_HIDE);
						}
						ResizeAllWindows(0, W, H);
						EDITLIST=FALSE;
					}
				}
				else if ((MJButton*)wParam == NewListBtn)
				{
					if (DialogBox(hInstance, MAKEINTRESOURCE(IDD_NEWLIST), hwndMain, AskNewListDlgProc))
					{
						char list[256] = "";
						SendMessage(ComboWnd, CB_ADDSTRING, 0, (LPARAM)NEWLIST);
						sprintf(list, "List%d", NumPlaylists++);
						WritePrivateProfileString("Playlists", list, NEWLIST, ini);
					}
				}
			}
		}
		break;

		case MJ_PRG_LBUTTONDOWN:
		{
			SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0);
			player->Seek((int)wParam, 400);
		}
		break;

		case LSP_GETTRACKPOS:
		{
			SetWindowLong(hwnd, DWL_MSGRESULT, TRACKPOS);
			return TRUE;
		}
		break;

		case LSP_GETTRANS:
		{
			SetWindowLong(hwnd, DWL_MSGRESULT, USETRANS);
			return TRUE;
		}
		break;

		case LSP_NCHITTEST:
		{
			if (LAYOUT_EDIT)
				SetWindowLong(hwnd, DWL_MSGRESULT, HTCAPTION);
			else
				SetWindowLong(hwnd, DWL_MSGRESULT, HTCLIENT);

			return TRUE;
		}
		break;

		case WM_NCRBUTTONUP:
		case WM_RBUTTONUP:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		break;

		case WM_NCLBUTTONDOWN:
		case WM_LBUTTONDOWN: 
		{
			LAYOUT_EDIT=FALSE;
			if (!EDITLIST) EnableWindow(TransferBtn->m_hwnd, FALSE);
			if (hCurrentList == hAllTracks) 
			{
				EnableWindow(DeleteBtn->m_hwnd, FALSE);
				EnableWindow(EditListBtn->m_hwnd, FALSE);
			}

			RedrawWindow(hwndMain, NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE);
		}
		break;

		case MJ_BTN_KEYDOWN:
		{
			if (LAYOUT_EDIT)
			{
				MJButton* button = (MJButton*)lParam;
				int dist=1;
				
				if (HIWORD(GetKeyState(VK_CONTROL)) & 1 == 1) // Resize
				{
					switch ((int)wParam)
					{
						case VK_UP: button->m_h-=dist; break;
						case VK_DOWN: button->m_h+=dist; break;
						case VK_LEFT: button->m_w-=dist; break;
						case VK_RIGHT: button->m_w+=dist; break;
					}

					button->ResizeWindow(button->m_w, button->m_h);
					InvalidateRect(button->m_hwnd, NULL, TRUE);
				}
				else // Move
				{
					if (HIWORD(GetKeyState(VK_SHIFT)) & 1 == 1) dist=5;

					switch ((int)wParam)
					{
						case VK_UP: button->m_y-=dist; break;
						case VK_DOWN: button->m_y+=dist; break;
						case VK_LEFT: button->m_x-=dist; break;
						case VK_RIGHT: button->m_x+=dist; break;
					}
					button->MoveWindow(button->m_x, button->m_y);
				}
			}
		}
		break;

		case WM_ERASEBKGND: 
		{
			SetWindowLong(hwnd, DWL_MSGRESULT, 1);
			return TRUE;
		}

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			RECT r;

			if (!(pos->flags & SWP_NOMOVE))
			{
				if (pos->x+W >= ScreenX-5) pos->x = ScreenX - W;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+H >= ScreenY-5) pos->y = ScreenY - H;
				else if (pos->y <= 5) pos->y = 0;

				if (X != pos->x || Y != pos->y)
				{
					POSCHANGE=TRUE;
					X = pos->x;
					Y = pos->y;

					if (EDITLIST)
					{
						GetClientRect(EditTrackWnd, &r);
						if (pos->x+W+r.right >= ScreenX-5)
						{
							if (pos->y+H+r.bottom >= ScreenY-5)
								SetWindowPos(EditTrackWnd, NULL, X, Y-r.bottom, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
							else
								SetWindowPos(EditTrackWnd, NULL, X, Y+H, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
						}
						else SetWindowPos(EditTrackWnd, NULL, X+W, Y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
					}

					WritePrivateProfileInt("Main", "PlaylistX", X, skin_ini);
					WritePrivateProfileInt("Main", "PlaylistY", Y, skin_ini);
				}
			}
			
			if (!(pos->flags & SWP_NOSIZE))
			{
				if (W != pos->cx || H != pos->cy) 
				{
					SIZECHANGE=TRUE;
					W = pos->cx;
					H = pos->cy;
					WritePrivateProfileInt("Main", "PlaylistWidth", W, skin_ini);
					WritePrivateProfileInt("Main", "PlaylistHeight", H, skin_ini);
					ResizeAllWindows(EDITLIST, W, H);
				}
			}

			if (POSCHANGE || SIZECHANGE) InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_HOTKEY:
		{
			switch (wParam)
			{
				case HOTKEY_PLAY: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0);
					break;
				case HOTKEY_PAUSE: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)PauseBtn, 0);
					break;
				case HOTKEY_STOP: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)StopBtn, 0);
					break;
				case HOTKEY_NEXT: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)NextBtn, 0);
					break;
				case HOTKEY_PREV: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)PrevBtn, 0);
					break;
				case HOTKEY_FWD: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)FwdBtn, 0);
					break;
				case HOTKEY_BACK: SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)BackBtn, 0);
					break;
				case HOTKEY_HIDE: ShowWindow(hwndMain, SW_HIDE);
					break;
				case HOTKEY_SHOW: ShowWindow(hwndMain, SW_SHOW);
					break;
			}
		}
		break;

		case WM_NOTIFY:
		{
			LPNMHDR hdr = (LPNMHDR)lParam;
			switch (hdr->code)
			{
				case LVN_KEYDOWN:
				{
					if (hdr->hwndFrom == hSomeTracks)
					{
						LPNMLVKEYDOWN kd = (LPNMLVKEYDOWN)lParam;
						if (kd->wVKey == VK_DELETE)
						{
							SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)DeleteBtn, 0);
						}
					}
				}
			}
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case CBN_SELCHANGE:
				{
					int sel = SendMessage(ComboWnd, CB_GETCURSEL, 0, 0);
					char list[256] = "";
					char temp[256] = "";
					char dir[256] = "";
		
					// Add current songs back to all songs list
					if (IsWindowVisible(hSomeTracks))
					{
						for (int count=0; count < ListView_GetItemCount(hSomeTracks); count++)
						{
							ListView_GetItemText(hSomeTracks, count, 0, temp, 256);
							ListView_GetItemText(hSomeTracks, count, 1, dir, 256);
							AddTrack(hAllTracks, temp, dir, 0);
						}
					}

					SendMessage(ComboWnd, CB_GETLBTEXT, (WPARAM)sel, (LPARAM)list);

					if (strcmp(list, "All Songs") && strcmp(list, "===================="))
					{
						char track[256] = "";

						hCurrentList = hSomeTracks;

						if (!EDITLIST)
						{
							ShowWindow(hAllTracks, SW_HIDE);
							ShowWindow(hSomeTracks, SW_SHOW);
						}

						// Delete all items
						ListView_DeleteAllItems(hSomeTracks);
						TrackCount=0;

						EnableWindow(EditListBtn->m_hwnd, TRUE);
						EnableWindow(DeleteBtn->m_hwnd, TRUE);

						// Add items for this playlist
						sprintf(temp, "Track%d", TrackCount++);
						while (GetPrivateProfileString(list, temp, "", track, 256, ini))
						{
							char* name = strrchr(track, '\\')+1;
							char dir[256] = "";
							strncpy(dir, track, name-track);
							ListView_DeleteItem(hAllTracks, ListView_SearchForItem(hAllTracks, name));
							AddTrack(hSomeTracks, name, dir, TrackCount);
							sprintf(temp, "Track%d", TrackCount++);
						}
					}
					else
					{
						hCurrentList = hAllTracks;

						EnableWindow(EditListBtn->m_hwnd, FALSE);
						EnableWindow(DeleteBtn->m_hwnd, FALSE);
						ShowWindow(hAllTracks, SW_SHOW);
						ShowWindow(hSomeTracks, SW_HIDE);

						//if (EDITLIST) SendMessage(hwnd, WM_COMMAND, MAKEWPARAM(IDC_EDITLISTBTN, BN_CLICKED), 0);
						if (EDITLIST) SendMessage(hwnd, MJ_BTN_CLICKED, (WPARAM)EditListBtn, 0);
					}
				}
				break;
			}

			switch (LOWORD(wParam))
			{
				case P_PLAY: SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0); break;
				case P_PAUSE: SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PauseBtn, 0); break;
				case P_STOP: SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)StopBtn, 0); break;
				case P_NEXT: SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)NextBtn, 0); break;
				case P_PREV: SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PrevBtn, 0); break;
				case P_EXIT: PostQuitMessage(0); break;
				
				case P_HOTKEY:
				{
					HotkeyDlg* dlg = new HotkeyDlg(hwndMain, hInstance, ini);
					dlg->Go();
				}
				break;

				case P_ADD_DIR:
				{
					if (DialogBox(hInstance, MAKEINTRESOURCE(IDD_WATCHDIRECTORY), hwndMain, AskWatchDirectoryDlgProc))
					{
						if (strlen(NEW_DIRECTORY))
						{
							char temp[256] = "";
							int x=0;

							if (NEW_DIRECTORY[strlen(NEW_DIRECTORY)-1] == '\\')
								NEW_DIRECTORY[strlen(NEW_DIRECTORY)-1] = '\0';
							sprintf(temp, "Dir%d", DirCount);
							WritePrivateProfileString("Directories", temp, NEW_DIRECTORY, ini);
							sprintf(temp, "%d", DirCount+1);
							WritePrivateProfileString("Directories", "Count", temp, ini);

							StopWatching();
							free(WATCH_DIRECTORY);
							free(notify);
							free(thread);
							LoadDirectories();
							for (x=0; x<DirCount; x++)
							{
								hListThread = CreateThread(NULL, 0, CreateFileList, (LPVOID)WATCH_DIRECTORY[x], 0, &ListThread);
								//WaitForSingleObject(hListThread, INFINITE);
							}
							StartWatching();
						}
					}
				}
				break;

				case P_SHUFFLE:
				{
					if (SHUFFLE)
					{
						SHUFFLE=FALSE;
						CheckMenuItem(popup, P_SHUFFLE, MF_UNCHECKED);
						WritePrivateProfileString("Main", "Shuffle", "0", ini);
					}
					else
					{
						SHUFFLE=TRUE;
						CheckMenuItem(popup, P_SHUFFLE, MF_CHECKED);
						WritePrivateProfileString("Main", "Shuffle", "1", ini);
					}
				}
				break;

				case P_USETRANS:
				{
					if (USETRANS)
					{
						USETRANS=FALSE;
						CheckMenuItem(popup, P_USETRANS, MF_UNCHECKED);
						WritePrivateProfileString("Main", "UseTrans", "0", skin_ini);
						SetWindowBitmapRgn(hwndMain, NULL, NULL);
					}
					else
					{
						USETRANS=TRUE;
						CheckMenuItem(popup, P_USETRANS, MF_CHECKED);
						WritePrivateProfileString("Main", "UseTrans", "1", skin_ini);
						SIZECHANGE=TRUE;
					}
					InvalidateRect(hwndMain, NULL, TRUE);
				}
				break;

				case P_ALWAYSONTOP:
				{
					if (ALWAYSONTOP)
					{
						ALWAYSONTOP=FALSE;
						CheckMenuItem(popup, P_ALWAYSONTOP, MF_UNCHECKED);
						WritePrivateProfileString("Main", "AlwaysOnTop", "0", ini);
						SetWindowPos(hwndMain, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
					}
					else
					{
						ALWAYSONTOP=TRUE;
						CheckMenuItem(popup, P_ALWAYSONTOP, MF_CHECKED);
						WritePrivateProfileString("Main", "AlwaysOnTop", "1", ini);
						SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
					}
				}
				break;

				case P_EQ:
				{
					if (IsWindowVisible(EQWnd)) ShowWindow(EQWnd, SW_HIDE);
					else ShowWindow(EQWnd, SW_SHOW);
				}
				break;

				case P_EDITLAYOUT:
				{
					SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)LayoutBtn, 0);
				}
				break;

				case P_SKINBROWSER:
				{
					SkinBrowser* sb = new SkinBrowser(hwndMain, hInstance, SKIN_DIR, ini);
					sb->Go();
				}
				break;

				case P_AUTOPLAY:
				{
				}
				break;
			}
		}
		break;
	}

	return 0;
}

BOOL CALLBACK AskNewListDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { return EndDialog(hwnd, 0); }
			}
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_EDIT, NEWLIST, 256);
							if (NEWLIST[0] == '\\')
							{
								MessageBox(hwnd, "Invalid playlist name.\nPlaylists are not allowed to start with '\\'.\nPlease rename and try again.", szAppName, MB_SYSTEMMODAL);
								SendMessage(GetDlgItem(hwnd, IDC_EDIT), EM_SETSEL, 0, -1);
								break;
							}
							else if (SendMessage(ComboWnd, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM)NEWLIST) != CB_ERR)
							{
								MessageBox(hwnd, "Invalid playlist name.\nThis playlist already exists.\nPlease rename and try again.", szAppName, MB_SYSTEMMODAL);
								SendMessage(GetDlgItem(hwnd, IDC_EDIT), EM_SETSEL, 0, -1);
								break;
							}
							return EndDialog(hwnd, 1);
						}
						break;

						case IDCANCEL:
						{
							return EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}
	return FALSE;
}

BOOL CALLBACK AskWatchDirectoryDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { return EndDialog(hwnd, 0); }
			}
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
							GetDlgItemText(hwnd, IDC_EDIT, NEW_DIRECTORY, 256);
							return EndDialog(hwnd, 1);
						}
						break;

						case IDCANCEL:
						{
							return EndDialog(hwnd, 0);
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}
	return FALSE;
}


BOOL CALLBACK NewListDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { ShowWindow(hwnd, SW_HIDE); return TRUE; }
			}
		}
		break;

		case WM_NCHITTEST: 
		{
			DlgProc(hwnd, msg, wParam, lParam);
		}
		return TRUE;

		case WM_ERASEBKGND: 
		{
			SetWindowLong(hwnd, DWL_MSGRESULT, 1);
			return TRUE;
		}

		case WM_NCPAINT:
		case WM_PAINT:
		{
			DlgProc(hwnd, msg, wParam, lParam);
		}
		return TRUE;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			RECT r;
			GetClientRect(hwnd, &r);

			if (!(pos->flags & SWP_NOMOVE))
			{
				if (pos->x+r.right >= ScreenX-5) pos->x = ScreenX - r.right;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+r.bottom >= ScreenY-5) pos->y = ScreenY - r.bottom;
				else if (pos->y <= 5) pos->y = 0;
			}
			
			if (!(pos->flags & SWP_NOSIZE))
			{
				if (hwnd == NewTrackWnd)
				{
					SetWindowPos(hNewTracks, NULL, 
								 imgs->bl.bmWidth+6, 
								 imgs->bt.bmHeight+6, 
								 pos->cx-imgs->br.bmWidth-imgs->bl.bmWidth-12, 
								 pos->cy-imgs->bb.bmHeight-imgs->bt.bmHeight-12, 
								 SWP_NOZORDER);
				}
				else if (hwnd == EditTrackWnd)
				{
					SetWindowPos(hAllTracks, NULL, 
								 imgs->bl.bmWidth+6, 
								 imgs->bt.bmHeight+6, 
								 pos->cx-imgs->br.bmWidth-imgs->bl.bmWidth-12, 
								 pos->cy-imgs->bb.bmHeight-imgs->bt.bmHeight-12, 
								 SWP_NOZORDER);
				}

				InvalidateRect(hwnd, NULL, TRUE);
			}
		}
		break;
	}

	return 0;
}

LRESULT CALLBACK NewListProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case WM_NCHITTEST: 
		{
			if (LAYOUT_EDIT) return HTCAPTION;
		}
		break;

		case WM_NCPAINT: 
		{
			if (!LAYOUT_EDIT) break;
			CallWindowProc((WNDPROC)OldNewListProc, hwnd, msg, wParam, lParam);
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbufbmp, oldsrcbmp;
			int top = ListView_GetTopIndex(hwnd);
			int count = ListView_GetCountPerPage(hwnd);
			
			RECT r, ir;
			GetClientRect(hwnd, &r);
			bufbmp = CreateCompatibleBitmap(hdc, r.right, r.bottom);

			oldbufbmp = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrcbmp = (HBITMAP)SelectObject(src, imgs->l_bg);
			StretchBlt(buf, 0, 0, r.right, r.bottom, src, 0, 0, imgs->l_bbg.bmWidth, imgs->l_bbg.bmHeight, SRCCOPY);
			SelectObject(src, oldsrcbmp);

			ListView_GetItemRect(hwnd, top, &ir, LVIR_BOUNDS);
			SetBkMode(buf, TRANSPARENT);
			SelectObject(buf, (HFONT)imgs->l_font);
			for (int x=0; x<=count+1; x++)
			{
				RECT mr;
				char text[256] = "";
				ListView_GetItemText(hwnd, top+x, 0, text, 256);
				SetRect(&mr, ir.left, x*imgs->l_fontsize, ir.right, (x+1)*imgs->l_fontsize);
				UINT res = ListView_GetItemState(hwnd, top+x, LVIS_SELECTED);
				if (res & LVIS_SELECTED) SetTextColor(buf, imgs->l_fgselcolor);
				else SetTextColor(buf, imgs->l_fgcolor);
				DrawText(buf, text, -1, &mr, DT_END_ELLIPSIS);
			}

			if (LAYOUT_EDIT)
			{
				HBRUSH hbr = CreateSolidBrush(0x000000FF);
				FrameRect(buf, &r, hbr);
				DeleteObject(hbr);

				RECT cr;
				char coords[30] = "";
				sprintf(coords, "%d x %d", ListW, ListH);
				SetRect(&cr, 0, 0, 50, 20);
				DrawText(buf, coords, strlen(coords), &cr, DT_CALCRECT);
				SetRect(&cr, r.right-cr.right, r.bottom-cr.bottom, r.right, r.bottom);
				SetBkMode(buf, OPAQUE);
				SetBkColor(buf, RGB(255-GetRValue(imgs->l_fgcolor), 255-GetGValue(imgs->l_fgcolor), 255-GetBValue(imgs->l_fgcolor)));
				SetTextColor(buf, imgs->l_fgcolor);
				DrawText(buf, coords, -1, &cr, 0);
			}

			BitBlt(hdc, 0, 0, r.right, r.bottom, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbufbmp);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbufbmp);

			SelectObject(src, oldsrcbmp);
			DeleteDC(src);
			DeleteObject(oldsrcbmp);

			EndPaint(hwnd, &ps);
		}
		return 0;

		case WM_MOUSEWHEEL:
		case WM_VSCROLL:
		{
			CallWindowProc((WNDPROC)OldNewListProc, hwnd, msg, wParam, lParam);
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return TRUE;

		case WM_WINDOWPOSCHANGED:
		{
			if ((hwnd == hAllTracks || hwnd == hSomeTracks) && !EDITLIST)
			{
				LPWINDOWPOS wp = (LPWINDOWPOS)lParam;
				char temp[10] = "";

				ListX=wp->x;
				sprintf(temp, "%d", wp->x);
				WritePrivateProfileString("List", "X", temp, skin_ini);

				ListY=wp->y;
				sprintf(temp, "%d", wp->y);
				WritePrivateProfileString("List", "Y", temp, skin_ini);

				ListW=wp->cx;
				sprintf(temp, "%d", wp->cx);
				WritePrivateProfileString("List", "W", temp, skin_ini);

				ListH=wp->cy;
				sprintf(temp, "%d", wp->cy);
				WritePrivateProfileString("List", "H", temp, skin_ini);
			}
			RECT r;
			GetClientRect(hwnd, &r);
			ListView_SetColumnWidth(hwnd, 0, r.right);
		}
		break;

		case WM_KEYDOWN:
		{
			if (LAYOUT_EDIT)
			{
				int dist=1;
				RECT r;
				GetWindowRect(hwnd, &r);
				
				if (HIWORD(GetKeyState(VK_CONTROL)) & 1 == 1) // Resize
				{
					switch ((int)wParam)
					{
						case VK_UP: r.bottom-=dist; break;
						case VK_DOWN: r.bottom+=dist; break;
						case VK_LEFT: r.right-=dist; break;
						case VK_RIGHT: r.right+=dist; break;
					}

					SetWindowPos(hwnd, NULL, 0, 0, r.right-r.left, r.bottom-r.top, SWP_NOMOVE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				else // Move
				{
					if (HIWORD(GetKeyState(VK_SHIFT)) & 1 == 1) dist=5;

					switch ((int)wParam)
					{
						case VK_UP: ListY-=dist; break;
						case VK_DOWN: ListY+=dist; break;
						case VK_LEFT: ListX-=dist; break;
						case VK_RIGHT: ListX+=dist; break;
					}
					SetWindowPos(hwnd, NULL, ListX, ListY, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return TRUE;
			}

			switch ((int)wParam)
			{
				case VK_RETURN:
				{
					SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0);
				}
				break;
			}
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_NCLBUTTONDOWN:
		{
			SetFocus(hwnd);
		}
		break;

		case WM_NCLBUTTONDBLCLK: return TRUE;

		case WM_LBUTTONDOWN:
		{
			int y = HIWORD(lParam);
			int top = ListView_GetTopIndex(hwnd);
			int sel = top + y / imgs->l_fontsize;
			int oldsel = ListView_GetSelectionMark(hwnd);

			SetFocus(hwnd);
			if (!(wParam & MK_CONTROL)) ListView_SetItemState(hwnd, -1, 0, LVIS_SELECTED | LVIS_FOCUSED);

			if (wParam & MK_SHIFT)
			{
				if (sel < oldsel)
				{
					for (int x=sel; x<=oldsel; x++)
					{
						ListView_SetItemState(hwnd, x, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
					}
				}
				else
				{
					for (int x=oldsel; x<=sel; x++)
					{
						ListView_SetItemState(hwnd, x, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
					}
				}
			}
			else
			{
				ListView_SetItemState(hwnd, sel, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
			}
			ListView_SetSelectionMark(hwnd, sel);
		}
		return TRUE;

		case LVM_DELETEALLITEMS:
		case LVM_DELETEITEM:
		case LVM_INSERTITEM:
		case LVM_SETSELECTIONMARK:
		{
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_LBUTTONDBLCLK:
		{
			int x = ListView_GetSelectionMark(hwnd);
			if (x < 0) break;

			char temp[256] = "";
			int selcount = ListView_GetSelectedCount(hwnd);

			if ((!EDITLIST && hwnd == hAllTracks) || hwnd == hSomeTracks)
			{
				SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0);
			}
			else
			{
				for (int count=0; count < selcount; count++)
				{
					int newx;
					char dir[256] = "";

					ListView_GetItemText(hwnd, x, 0, temp, 256);
					ListView_GetItemText(hwnd, x, 1, dir, 256);
					if (hwnd == hNewTracks)
					{
						// Delete from new track list	
						ListView_DeleteItem(hwnd, x);
						NewTrackCount--;
					}
					else
					{
						if (ListView_DeleteItem(hNewTracks, ListView_SearchForItem(hNewTracks, temp)) != -1)
							NewTrackCount--;
					}

					// Add to actual playlist file
					int sel = SendMessage(ComboWnd, CB_GETCURSEL, 0, 0);
					char list[256] = "";
					SendMessage(ComboWnd, CB_GETLBTEXT, (WPARAM)sel, (LPARAM)list);
					if (strcmp(list, "All Songs") && strcmp(list, "===================="))
					{
						char track[256] = "";
						char name[256] = "";
						
						sprintf(track, "Track%d", TrackCount-1);
						sprintf(name, "%s\\%s", dir, temp);
						WritePrivateProfileString(list, track, name, ini);

						int blah = ListView_SearchForItem(hAllTracks, temp);
						if (blah >= 0) ListView_DeleteItem(hAllTracks, blah);

						// Add to playlist
						newx = AddTrack(hSomeTracks, temp, dir, TrackCount);
						ListView_EnsureVisible(hSomeTracks, newx, FALSE);

						TrackCount++;
					}
					
					x = ListView_GetNextItem(hwnd, -1, LVNI_SELECTED);
				}
			}
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;
	}

	return CallWindowProc((WNDPROC)OldNewListProc, hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK ComboProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCHITTEST: 
		{
			if (LAYOUT_EDIT) return HTCAPTION;
		}
		break;

		case WM_NCPAINT: 
		{
			if (!LAYOUT_EDIT) break;
			CallWindowProc((WNDPROC)OldNewListProc, hwnd, msg, wParam, lParam);

			RECT r;
			GetClientRect(hwnd, &r);
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HBRUSH hbr = CreateSolidBrush(0x000000FF);
			FrameRect(hdc, &r, hbr);
			DeleteObject(hbr);
			EndPaint(hwnd, &ps);
		}
		return TRUE;

		case WM_NCLBUTTONDOWN: SetFocus(hwnd); break;
		case WM_NCLBUTTONDBLCLK: return TRUE;

		case WM_KEYDOWN:
		{
			if (LAYOUT_EDIT)
			{
				int dist=1;
				RECT r;
				GetWindowRect(hwnd, &r);
				
				if (HIWORD(GetKeyState(VK_CONTROL)) & 1 == 1) // Resize
				{
					switch ((int)wParam)
					{
						case VK_LEFT: r.right-=dist; break;
						case VK_RIGHT: r.right+=dist; break;
					}

					SetWindowPos(hwnd, NULL, 0, 0, r.right-r.left, r.bottom-r.top, SWP_NOMOVE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				else // Move
				{
					if (HIWORD(GetKeyState(VK_SHIFT)) & 1 == 1) dist=5;

					switch ((int)wParam)
					{
						case VK_UP: ComboY-=dist; break;
						case VK_DOWN: ComboY+=dist; break;
						case VK_LEFT: ComboX-=dist; break;
						case VK_RIGHT: ComboX+=dist; break;
					}
					SetWindowPos(hwnd, NULL, ComboX, ComboY, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return TRUE;
			}
		}
		break;

		case WM_WINDOWPOSCHANGED:
		{
			LPWINDOWPOS wp = (LPWINDOWPOS)lParam;
			char temp[10] = "";

			ComboX=wp->x;
			sprintf(temp, "%d", wp->x);
			WritePrivateProfileString("Combo", "X", temp, skin_ini);

			ComboY=wp->y;
			sprintf(temp, "%d", wp->y);
			WritePrivateProfileString("Combo", "Y", temp, skin_ini);

			ComboW=wp->cx;
			sprintf(temp, "%d", wp->cx);
			WritePrivateProfileString("Combo", "W", temp, skin_ini);

			ComboH=wp->cy;
			sprintf(temp, "%d", wp->cy);
			WritePrivateProfileString("Combo", "H", temp, skin_ini);
		}
		break;
	}

	return CallWindowProc((WNDPROC)OldComboProc, hwnd, msg, wParam, lParam);
}

BOOL CALLBACK EQProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCHITTEST: 
		{
			DlgProc(hwnd, msg, wParam, lParam);
		}
		return TRUE;

		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: { ShowWindow(hwnd, SW_HIDE); return TRUE; }
			}
		}
		break;

		case WM_NCPAINT:
		case WM_PAINT:
		{
			DlgProc(hwnd, msg, wParam, lParam);
		}
		return TRUE;

		case WM_ERASEBKGND: 
		{
			SetWindowLong(hwnd, DWL_MSGRESULT, 1);
			return TRUE;
		}

		case WM_NCRBUTTONUP:
		case WM_RBUTTONUP:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(eqpopup, TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
			RECT r;
			GetClientRect(hwnd, &r);

			if (!(pos->flags & SWP_NOMOVE))
			{
				if (pos->x+r.right >= ScreenX-5) pos->x = ScreenX - r.right;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+r.bottom >= ScreenY-5) pos->y = ScreenY - r.bottom;
				else if (pos->y <= 5) pos->y = 0;

				char temp[256] = "";
				sprintf(temp, "%d", pos->x);
				WritePrivateProfileString("EQ", "X", temp, skin_ini);
				sprintf(temp, "%d", pos->y);
				WritePrivateProfileString("EQ", "Y", temp, skin_ini);
			}
			
			if (!(pos->flags & SWP_NOSIZE))
			{
				// Resize all the eq bars
				for (int x=0; x < 16; x++)
				{
					EQ[x]->Resize(pos->cx, pos->cy);
				}
				
				char temp[256] = "";
				sprintf(temp, "%d", pos->cx);
				WritePrivateProfileString("EQ", "W", temp, skin_ini);
				sprintf(temp, "%d", pos->cy);
				WritePrivateProfileString("EQ", "H", temp, skin_ini);
				SIZECHANGE=TRUE;
				InvalidateRect(hwnd, NULL, TRUE);
			}
		}
		break;

		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case P_EQ_ZERO:
				{
					for (int x=0; x < 16; x++)
					{
						EQ[x]->SetPos(0);
					}
					EQUpdate();
				}
				break;
			}
		}
		break;

		case MJ_PRG_LBUTTONDOWN:
		{
			EQUpdate();
		}
		break;
	}

	return FALSE;
}

void LoadSetup()
{
	// The config ini
	sprintf(ini, ".\\lsplaylist.cfg");
	
	LoadDirectories();
	
	// Basic screen information
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	GetPrivateProfileString("Main", "SkinDirectory", ".\\Skins", SKIN_DIR, MAX_PATH, ini);
	GetPrivateProfileString("Main", "Skin", "Default", SKIN, 100, ini);
	sprintf(SKIN_PATH, "%s\\%s\\", SKIN_DIR, SKIN);
	sprintf(skin_ini, "%sskin.ini", SKIN_PATH);
	WritePrivateProfileString("Main", "SkinDirectory", SKIN_DIR, ini);
	WritePrivateProfileString("Main", "Skin", SKIN, ini);

	FAKE_WINAMP = GetPrivateProfileInt("Main", "FakeWinamp", 0, ini);
	USEID3 = GetPrivateProfileInt("Main", "UseID3", 1, ini);
	
	// Popup menu
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_PLAY, "&Play");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_PAUSE, "P&ause");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_STOP, "&Stop");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_NEXT, "&Next Track");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_PREV, "P&revious Track");
	AppendMenu(popup, MF_SEPARATOR, 0, 0);
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_SHUFFLE, "&Shuffle");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_AUTOPLAY, "&Auto-Play");
	AppendMenu(popup, MF_SEPARATOR, 0, 0);
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_ALWAYSONTOP, "Always On &Top");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_USETRANS, "&Use Transparency");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_EDITLAYOUT, "Edit &Layout");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_EQ, "&Equalizer");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_HOTKEY, "&Hotkeys");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_SKINBROWSER, "&Change Skin");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_ADD_DIR, "&Add Directory");
	AppendMenu(popup, MF_ENABLED | MF_STRING, P_EXIT, "E&xit");

	eqpopup = CreatePopupMenu();
	AppendMenu(eqpopup, MF_ENABLED | MF_STRING, P_EQ_ZERO, "&Zero All");

	SHUFFLE = GetPrivateProfileInt("Main", "Shuffle", FALSE, ini);
	if (SHUFFLE) CheckMenuItem(popup, P_SHUFFLE, MF_CHECKED);

	USETRANS = GetPrivateProfileInt("Main", "UseTrans", TRUE, skin_ini);
	if (USETRANS) CheckMenuItem(popup, P_USETRANS, MF_CHECKED);

	ALWAYSONTOP = GetPrivateProfileInt("Main", "AlwaysOnTop", FALSE, ini);
	if (ALWAYSONTOP) CheckMenuItem(popup, P_ALWAYSONTOP, MF_CHECKED);

	// Thread control
	mutex = CreateEvent(NULL, FALSE, TRUE, "mutex");

	if (LITESTEP)
	{
		STARTHIDDEN = GetRCBool("LSPlayListStartHidden", TRUE);
	}
	
	// Dimensions
	W = GetPrivateProfileInt("Main", "PlaylistWidth", 335, skin_ini);
	H = GetPrivateProfileInt("Main", "PlaylistHeight", 245, skin_ini);
	X = GetPrivateProfileInt("Main", "PlaylistX", 196, skin_ini);
	Y = GetPrivateProfileInt("Main", "PlaylistY", 144, skin_ini);
	ListW = GetPrivateProfileInt("List", "W", 248, skin_ini);
	ListH = GetPrivateProfileInt("List", "H", 175, skin_ini);
	ListX = GetPrivateProfileInt("List", "X", 45, skin_ini);
	ListY = GetPrivateProfileInt("List", "Y", 35, skin_ini);
	ComboW = GetPrivateProfileInt("Combo", "W", 260, skin_ini);
	ComboH = GetPrivateProfileInt("Combo", "H", 21, skin_ini);
	ComboX = GetPrivateProfileInt("Combo", "X", 10, skin_ini);
	ComboY = GetPrivateProfileInt("Combo", "Y", 9, skin_ini);

	// Images
	char temp[256] = "";
	char src[256] = "";
	COLORREF tcolor;
	imgs = new Images;
	
	GetPrivateProfileString("Images", "TopBorder", "border-top.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->t = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->t) GetObject(imgs->t, sizeof(BITMAP), &imgs->bt);

	GetPrivateProfileString("Images", "BottomBorder", "border-bottom.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->b = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->b) GetObject(imgs->b, sizeof(BITMAP), &imgs->bb);

	GetPrivateProfileString("Images", "LeftBorder", "border-left.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->l = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->l) GetObject(imgs->l, sizeof(BITMAP), &imgs->bl);

	GetPrivateProfileString("Images", "RightBorder", "border-right.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->r = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->r) GetObject(imgs->r, sizeof(BITMAP), &imgs->br);

	GetPrivateProfileString("Images", "MainBackground", "bg-main.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->bg = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->bg) GetObject(imgs->bg, sizeof(BITMAP), &imgs->bbg);

	GetPrivateProfileString("Images", "ListBackground", "bg-list.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->l_bg = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->l_bg) GetObject(imgs->l_bg, sizeof(BITMAP), &imgs->l_bbg);

	// List setup
	GetPrivateProfileString("List", "FontColor", "0x00FFFFFF", temp, 256, skin_ini);
    tcolor = strtol( temp, NULL, 16 );
	imgs->l_fgcolor = RGB(GetBValue(tcolor), GetGValue(tcolor), GetRValue(tcolor));
	GetPrivateProfileString("List", "FontSelColor", "0x00FF0000", temp, 256, skin_ini);
    tcolor = strtol( temp, NULL, 16 );
	imgs->l_fgselcolor = RGB(GetBValue(tcolor), GetGValue(tcolor), GetRValue(tcolor));
	GetPrivateProfileString("List", "FontFace", "Arial", temp, 256, skin_ini);
	imgs->l_fontsize = GetPrivateProfileInt("List", "FontHeight", 12, skin_ini);
	imgs->l_font = CreateFont(imgs->l_fontsize, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);

	if (LITESTEP)
	{
		AddBangCommand("!LSPlayListHide", BangHide);
		AddBangCommand("!LSPlayListShow", BangShow);
		AddBangCommand("!LSPlayListToggle", BangToggle);
		AddBangCommand("!LSPlayListPlay", BangPlay);
		AddBangCommand("!LSPlayListPause", BangPause);
		AddBangCommand("!LSPlayListStop", BangStop);
		AddBangCommand("!LSPlayListNext", BangNext);
		AddBangCommand("!LSPlayListPrev", BangPrev);
		AddBangCommand("!LSPlayListFwd", BangFwd);
		AddBangCommand("!LSPlayListBack", BangBack);
		AddBangCommand("!LSPlayListAlwaysOnTop", BangAlwaysOnTop);
	}
}

void LoadDirectories()
{
	// The directories
	DirCount = GetPrivateProfileInt("Directories", "Count", 0, ini);
	if (DirCount)
	{
		WATCH_DIRECTORY = (char**)malloc(sizeof(char*) * DirCount);
		notify = (HANDLE*)malloc(sizeof(HANDLE) * DirCount);
		thread = (HANDLE*)malloc(sizeof(HANDLE) * DirCount);

		for (int x=0; x<DirCount; x++)
		{
			char temp[25] = "";
			char dir[MAX_PATH] = "";
			sprintf(temp, "Dir%d", x);
			GetPrivateProfileString("Directories", temp, "", dir, MAX_PATH, ini);
			WATCH_DIRECTORY[x] = _strdup(dir);
		}
	}
}

void SetupDialog()
{
	LVCOLUMN col;
	RECT r;
	int i=0;
	char temp[256] = "";
	char list[256] = "";

	SetWindowText(hwndMain, "Playback");
	if (FAKE_WINAMP) SetWindowText(FakeWinampWnd, "Playback");

	// Hotkeys
	SetupHotkey("Play", HOTKEY_PLAY);
	SetupHotkey("Pause", HOTKEY_PAUSE);
	SetupHotkey("Stop", HOTKEY_STOP);
	SetupHotkey("Next", HOTKEY_NEXT);
	SetupHotkey("Prev", HOTKEY_PREV);
	SetupHotkey("Fwd", HOTKEY_FWD);
	SetupHotkey("Back", HOTKEY_BACK);
	SetupHotkey("Hide", HOTKEY_HIDE);
	SetupHotkey("Show", HOTKEY_SHOW);

	// Progress Bar
	HWND TempProg = GetDlgItem(hwndMain, IDC_PROGRESS);
	ProgressWnd = new MJProgress("TrackProgress", "", TempProg, hwndMain, hInstance, skin_ini, 10, 35, 30, 203, SKIN_PATH, "bg-progress.bmp", "fg-progress.bmp");
	ProgressWnd->SetRange(0, 400);
	SendMessage(ProgressWnd->m_hwnd, WM_PAINT, 0, 0);

	// New buttons
	LayoutBtn = new MJButton("LayoutButton", hwndMain, hInstance, skin_ini, "Edit Layout", 300, 36, 24, 24, SKIN_PATH, "layout.bmp", "layout-over.bmp", "layout-clicked.bmp");
	ImportBtn = new MJButton("ImportButton", hwndMain, hInstance, skin_ini, "Import Playlist", 300, 64, 24, 24, SKIN_PATH, "import.bmp", "import-over.bmp", "import-clicked.bmp");
	ExportBtn = new MJButton("ExportButton", hwndMain, hInstance, skin_ini, "Export Playlist", 300, 92, 24, 24, SKIN_PATH, "export.bmp", "export-over.bmp", "export-clicked.bmp"); 
	DeleteBtn = new MJButton("DeleteButton", hwndMain, hInstance, skin_ini, "Delete Selected Track(s)", 300, 120, 24, 24, SKIN_PATH, "delete.bmp", "delete-over.bmp", "delete-clicked.bmp");
	TransferBtn = new MJButton("TransferButton", hwndMain, hInstance, skin_ini, "Transfer Selected Track(s)", 300, 148, 24, 24, SKIN_PATH, "transfer.bmp", "transfer-over.bmp", "transfer-clicked.bmp");
	if (!LITESTEP)
	{
		ExitBtn = new MJButton("ExitButton", hwndMain, hInstance, skin_ini, "Exit Playback", 300, 176, 24, 24, SKIN_PATH, "exit.bmp", "exit-over.bmp", "exit-clicked.bmp");
	}

	EnableWindow(DeleteBtn->m_hwnd, FALSE);
	EnableWindow(TransferBtn->m_hwnd, FALSE);

	// Playback buttons
	PrevBtn		= new MJButton("PrevButton",  hwndMain, hInstance, skin_ini, "Previous Track", 45, 214, 24, 24, SKIN_PATH, "prev.bmp", "prev-over.bmp", "prev-clicked.bmp");
	BackBtn		= new MJButton("BackButton",  hwndMain, hInstance, skin_ini, "Skip Back", 75, 214, 24, 24, SKIN_PATH, "back.bmp", "back-over.bmp", "back-clicked.bmp");
	PlayBtn		= new MJButton("PlayButton",  hwndMain, hInstance, skin_ini, "Play", 105, 214, 24, 24, SKIN_PATH, "play.bmp", "play-over.bmp", "play-clicked.bmp");
	PauseBtn	= new MJButton("PauseButton", hwndMain, hInstance, skin_ini, "Pause", 135, 214, 24, 24, SKIN_PATH, "pause.bmp", "pause-over.bmp", "pause-clicked.bmp");
	StopBtn		= new MJButton("StopButton",  hwndMain, hInstance, skin_ini, "Stop", 165, 214, 24, 24, SKIN_PATH, "stop.bmp", "stop-over.bmp", "stop-clicked.bmp");
	FwdBtn		= new MJButton("FwdButton",   hwndMain, hInstance, skin_ini, "Skip Forward", 195, 214, 24, 24, SKIN_PATH, "fwd.bmp", "fwd-over.bmp", "fwd-clicked.bmp");
	NextBtn		= new MJButton("NextButton",  hwndMain, hInstance, skin_ini, "Next Track", 225, 214, 24, 24, SKIN_PATH, "next.bmp", "next-over.bmp", "next-clicked.bmp");

	// Playlist controls
	NewListBtn = new MJButton("NewList", hwndMain, hInstance, skin_ini, "New Playlist", 278, 11, 22, 18, SKIN_PATH, "newlist.bmp", "newlist-over.bmp", "newlist-clicked.bmp");
	EditListBtn = new MJButton("EditList", hwndMain, hInstance, skin_ini, "Edit Playlist", 300, 11, 22, 18, SKIN_PATH, "editlist.bmp", "editlist-over.bmp", "editlist-clicked.bmp");
	EnableWindow(EditListBtn->m_hwnd, FALSE);

	// We need you to rewrite our controls!
	hAllTracks = GetDlgItem(hwndMain, IDC_ALL_TRACKS);
	hSomeTracks = GetDlgItem(hwndMain, IDC_SOME_TRACKS);
	hNewTracks = GetDlgItem(NewTrackWnd, IDC_NEW_TRACKS);
	
	ComboWnd = GetDlgItem(hwndMain, IDC_COMBO);

	GButtonCount=GetPrivateProfileInt("GButtons", "Count", 0, skin_ini);
	if (GButtonCount)
	{
		GButtons = (MJButton**)malloc(sizeof(MJButton*) * GButtonCount);
		for (int x=0; x<GButtonCount; x++)
		{
			char gb[256] = "";
			sprintf(gb, "GButton%d", x);

			GetPrivateProfileString("GButtons", gb, "", temp, 256, skin_ini);
			
			GButtons[x] = new MJButton(temp, hwndMain, hInstance, skin_ini, "GButton", 0, 0, 0, 0, SKIN_PATH, "", "", "");
		}
	}

	hCurrentList = hAllTracks;

	SetupComboList(0);

	// Setup the EQ
	SetupEQ();

	// Setup the lists
	GetClientRect(hAllTracks, &r);
	col.mask = LVCF_WIDTH | LVCF_TEXT;
	col.cx = r.right;
	col.pszText = "Title";
	col.cchTextMax = 5;
	ListView_InsertColumn(hAllTracks, 0, &col);
	ListView_InsertColumn(hSomeTracks, 0, &col);
	ListView_InsertColumn(hNewTracks, 0, &col);

	col.mask = LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	col.iSubItem = 1;
	col.cx = 0;
	col.pszText = "Directory";
	col.cchTextMax = 9;
	ListView_InsertColumn(hAllTracks, 1, &col);
	ListView_InsertColumn(hSomeTracks, 1, &col);
	ListView_InsertColumn(hNewTracks, 1, &col);

	if (WATCH_DIRECTORY)
	{
		for (int x=0; x<DirCount; x++)
		{
			hListThread = CreateThread(NULL, 0, CreateFileList, (LPVOID)WATCH_DIRECTORY[x], 0, &ListThread);
			//WaitForSingleObject(hListThread, INFINITE);
		}
	}

	OldNewListProc = SetWindowLong(hNewTracks, GWL_WNDPROC, (LONG)NewListProc);
	SetWindowLong(hAllTracks, GWL_WNDPROC, (LONG)NewListProc);
	SetWindowLong(hSomeTracks, GWL_WNDPROC, (LONG)NewListProc);

	OldComboProc = SetWindowLong(ComboWnd, GWL_WNDPROC, (LONG)ComboProc);

	SetWindowPos(hwndMain, NULL, X, Y, W, H, SWP_NOZORDER);
	ResizeAllWindows(0, W, H);
}

void SetupComboList(int cursel)
{
	WaitForSingleObject(mutex, INFINITE);

	char temp[256] = "";
	char list[256] = "";

	SendMessage(ComboWnd, CB_RESETCONTENT, 0, 0);
	NumPlaylists=0;

	SendMessage(ComboWnd, CB_ADDSTRING, 0, (LPARAM)"All Songs");
	sprintf(temp, "List%d", NumPlaylists++);
	GetPrivateProfileString("Playlists", temp, "", list, 256, ini);
	while (strlen(list))
	{
		SendMessage(ComboWnd, CB_ADDSTRING, 0, (LPARAM)list);
		sprintf(temp, "List%d", NumPlaylists++);
		GetPrivateProfileString("Playlists", temp, "", list, 256, ini);
	}
	NumPlaylists--;
	SendMessage(ComboWnd, CB_SETCURSEL, cursel, 0);

	SetEvent(mutex);
}

void SetupHotkey(char* name, int id)
{
	char i[4]="";
	GetPrivateProfileString("Hotkeys", name, "000", i, 4, ini);
	int mi = i[0]-'0';
	int ki = atoi(i+1);

	if (mi > 0 && ki > 0)
	{
		UINT mod;
		UINT key;

		if (mi == 1) mod = MOD_WIN;
		else if (mi == 2) mod = MOD_CONTROL;
		else if (mi == 3) mod = MOD_CONTROL | MOD_ALT;
		else if (mi == 4) mod = MOD_CONTROL | MOD_SHIFT;
		else if (mi == 5) mod = MOD_SHIFT | MOD_ALT;

		if (ki <= 26) key = 'A' + ki - 1;	
		else if (ki <= 36) key = '0' + ki - 27;
		else if (ki <= 48) key = VK_F1 + ki - 37;
		else if (ki == 49) key = VK_RIGHT;
		else if (ki == 50) key = VK_LEFT;
		else if (ki == 51) key = VK_UP;
		else if (ki == 52) key = VK_DOWN;
		else if (ki == 53) key = VK_HOME;
		else if (ki == 54) key = VK_END;
		else if (ki == 55) key = VK_INSERT;

		if (!RegisterHotKey(hwndMain, id, mod, key))
		{
			char errMsg[256] = "";
			sprintf(errMsg, "Unable to register hotkey for %s.", name);
			MessageBox(hwndMain, errMsg, "Hotkey Registration Error", MB_SYSTEMMODAL | MB_OK | MB_ICONERROR);
		}
	}
}

void ResizeAllWindows(int mode, int width, int height)
{
	if (!OW) OW=width;
	if (!OH) OH=height;

	LayoutBtn->RMoveWindow(OW-width, OH-height);
	ImportBtn->RMoveWindow(OW-width, OH-height);
	ExportBtn->RMoveWindow(OW-width, OH-height);
	DeleteBtn->RMoveWindow(OW-width, OH-height);
	TransferBtn->RMoveWindow(OW-width, OH-height);
	if (!LITESTEP) ExitBtn->RMoveWindow(OW-width, OH-height);

	PlayBtn->RMoveWindow(OW-width, OH-height);
	PauseBtn->RMoveWindow(OW-width, OH-height);
	StopBtn->RMoveWindow(OW-width, OH-height);
	PrevBtn->RMoveWindow(OW-width, OH-height);
	NextBtn->RMoveWindow(OW-width, OH-height);
	BackBtn->RMoveWindow(OW-width, OH-height);
	FwdBtn->RMoveWindow(OW-width, OH-height);
	EditListBtn->RMoveWindow(OW-width, OH-height);
	NewListBtn->RMoveWindow(OW-width, OH-height);

	for (int x=0; x < GButtonCount; x++)
	{
		GButtons[x]->RMoveWindow(OW-width, OH-height);
	}

	OW=width;
	OH=height;

	MoveWindow(ComboWnd, ComboX, ComboY, ComboW, ComboH, TRUE);
	if (!mode) MoveWindow(hAllTracks, ListX, ListY, ListW, ListH, TRUE);
	MoveWindow(hSomeTracks, ListX, ListY, ListW, ListH, TRUE);
}

void BangHide(HWND caller, char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangShow(HWND caller, char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangToggle(HWND caller, char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangPlay(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PlayBtn, 0); }
void BangPause(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PauseBtn, 0); }
void BangStop(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)StopBtn, 0); }
void BangNext(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)NextBtn, 0); }
void BangPrev(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)PrevBtn, 0); }
void BangFwd(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)FwdBtn, 0); }
void BangBack(HWND caller, char* args) { SendMessage(hwndMain, MJ_BTN_CLICKED, (WPARAM)BackBtn, 0); }
void BangAlwaysOnTop(HWND caller, char* args) 
{
	SendMessage(hwndMain, WM_COMMAND, MAKEWPARAM(P_ALWAYSONTOP, 0), 0);
}

void Watch(LPVOID event)
{
	while (1)
	{
		WaitForSingleObject((HANDLE)event, INFINITE);
		if (!NOWATCH)
		{
			SetupComboList(SendMessage(ComboWnd, CB_GETCURSEL, 0, 0));
			NOTIFY=TRUE;
			for (int x=0; x<DirCount; x++)
			{
				hListThread = CreateThread(NULL, 0, CreateFileList, (LPVOID)WATCH_DIRECTORY[x], 0, &ListThread);
				WaitForSingleObject(hListThread, INFINITE);
			}
		}
		FindNextChangeNotification((HANDLE)event);
	}
}

DWORD WINAPI CreateFileList(LPVOID v_match)
{
	static int depth=0;

	if (!depth) 
	{
		WaitForSingleObject(mutex, INFINITE);
		ShowWindow(hCurrentList, SW_HIDE);
	}
	depth++;

	char* match = (char*)v_match;
	HANDLE fff = NULL;
	char path[MAX_PATH] = "";
	WIN32_FIND_DATA* fd = (WIN32_FIND_DATA*)malloc(sizeof(WIN32_FIND_DATA));

	sprintf(path, "%s\\*", match);
	fff = FindFirstFile(path, fd);
	if (fff == INVALID_HANDLE_VALUE) return 0;

	while (FindNextFile(fff, fd))
	{
		if (fd->dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
		{
			if (strcmp(fd->cFileName, ".") && strcmp(fd->cFileName, ".."))
			{
				sprintf(path, "%s\\%s", match, fd->cFileName);
				CreateFileList(path);
			}
		}
		else
		{
			if (strstr(fd->cFileName, ".mp3"))
			{
				if (ListView_SearchForItem(hAllTracks, fd->cFileName) < 0)
				{
					if (NOTIFY)
					{
						if (!IsWindowVisible(NewTrackWnd)) ShowWindow(NewTrackWnd, SW_SHOW);
						AddTrack(hNewTracks, fd->cFileName, match, NewTrackCount++);
						AddTrack(hAllTracks, fd->cFileName, match, TrackCount);
					}
					else
					{
						AddTrack(hAllTracks, fd->cFileName, match, TrackCount++);
					}
				}
			}
		}
	}

	FindClose(fff);

	depth--;

	if (!depth) 
	{
		SetEvent(mutex);
		ShowWindow(hCurrentList, SW_SHOW);
	}
	return 1;
}

void ExportPlaylist()
{
	WaitForSingleObject(mutex, INFINITE);

	char filename[MAX_PATH] = "";
	OPENFILENAME* of = new OPENFILENAME;

	of->lStructSize = sizeof(OPENFILENAME);
	of->hwndOwner	= hwndMain;
	of->hInstance	= NULL;
	of->lpstrFilter =  "M3U List (*.m3u)\0*.m3u\0\0";
	of->lpstrCustomFilter = NULL;
	of->nMaxCustFilter		= 0;
	of->nFilterIndex		= 0;
	of->lpstrFile			= filename;
	of->nMaxFile			= MAX_PATH;
	of->lpstrFileTitle		= NULL;
	of->lpstrDefExt			= "m3u";
	of->lpstrInitialDir 	= WATCH_DIRECTORY[0];
	of->lpstrTitle			= "LSPlaylist - Export Playlist";
	of->Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;

	__try 
	{ 
		if (GetSaveFileName(of))
		{
			FILE* pl = fopen(filename, "w");
			for (int count=0; count < ListView_GetItemCount(hCurrentList); count++)
			{
				char track[256] = "";
				ListView_GetItemText(hSomeTracks, count, 0, track, 256);
				fprintf(pl, "%s\n", track);
			}
			fclose(pl);
		}
		delete of;
	}
	__except(1) { }

	SetEvent(mutex);
}

void ImportPlaylist()
{
	WaitForSingleObject(mutex, INFINITE);

	char filename[MAX_PATH] = "";
	OPENFILENAME* of = new OPENFILENAME;

	of->lStructSize = sizeof(OPENFILENAME);
	of->hwndOwner	= hwndMain;
	of->hInstance	= NULL;
	of->lpstrFilter =  "M3U List (*.m3u)\0*.m3u\0\0";
	of->lpstrCustomFilter = NULL;
	of->nMaxCustFilter		= 0;
	of->nFilterIndex		= 0;
	of->lpstrFile			= filename;
	of->nMaxFile			= MAX_PATH;
	of->lpstrFileTitle		= NULL;
	of->lpstrDefExt			= "m3u";
	of->lpstrInitialDir 	= WATCH_DIRECTORY[0];
	of->lpstrTitle			= "LSPlaylist - Import Playlist";
	of->Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;

	__try 
	{ 
		if (GetOpenFileName(of))
		{
			FILE* pl = fopen(filename, "r");
			while (!feof(pl))
			{
				char track[256] = "";
				fgets(track, 256, pl);
				if (strlen(track))
				{
					strcpy(track, strtok(track, "\r\n\0"));
					char* name = strrchr(track, '\\')+1;
					char dir[256] = "";
					strncpy(dir, track, name-track);
					AddTrack(hSomeTracks, track, dir, 0);
				}
			}
			fclose(pl);
		}
		delete of;

		int sel = SendMessage(ComboWnd, CB_GETCURSEL, 0, 0);
		char list[256] = "";
		SendMessage(ComboWnd, CB_GETLBTEXT, (WPARAM)sel, (LPARAM)list);
		if (strcmp(list, "All Songs"))
		{
			WritePrivateProfileSection(list, NULL, ini);
			for (int count=0; count < ListView_GetItemCount(hCurrentList); count++)
			{
				char track[256] = "";
				char name[256] = "";
				char dir[256] = "";
				char temp[256] = "";
				ListView_GetItemText(hSomeTracks, count, 0, temp, 256);
				ListView_GetItemText(hSomeTracks, count, 1, dir, 256);
				sprintf(track, "Track%d", count);
				sprintf(name, "%s\\%s", dir, temp);
				WritePrivateProfileString(list, track, name, ini);
			}
		}
	}
	__except(1) { }

	SetEvent(mutex);
}

void SetWindowBitmapRgn(HWND hwnd, HDC hdc, HBITMAP bmp)
{
	if (hwnd && hdc && bmp)
	{
		int x=0, y=0;
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;
		
		GetObject(bmp, sizeof(bitmap), &bitmap);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y <= bitmap.bmHeight; x=0, y++)
		{
			int blah=5;

			for (x=0; x <= bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, FALSE);

		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}

int myrand()
{
	srand(time(NULL));
	srand(rand() * rand() + rand());
	return rand();
}

void SetupEQ()
{
	char temp[256] = "";
	char src[256] = "";
	int eqx, eqy, eqw, eqh;
	int x=0;

	for (x=0; x < 16; x++)
	{
		HWND TempEQ = GetDlgItem(EQWnd, IDC_EQ1+x);
		sprintf(temp, "EQ%d", x+1);
		EQ[x] = new MJProgress("EQ", temp, TempEQ, EQWnd, hInstance, skin_ini, 5+(15*x), 5, 10, 100, SKIN_PATH, "bg-eq.bmp", "fg-eq.bmp");
	}

	GetPrivateProfileString("Images", "EQBackground", "bg-eqwnd.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->eq_bg = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->eq_bg) GetObject(imgs->eq_bg, sizeof(BITMAP), &imgs->eq_bbg);

	GetPrivateProfileString("Images", "TopEQBorder", "eqborder-top.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->eqt = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->eqt) GetObject(imgs->eqt, sizeof(BITMAP), &imgs->beqt);

	GetPrivateProfileString("Images", "BottomEQBorder", "eqborder-bottom.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->eqb = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->eqb) GetObject(imgs->eqb, sizeof(BITMAP), &imgs->beqb);

	GetPrivateProfileString("Images", "LeftEQBorder", "eqborder-left.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->eql = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->eql) GetObject(imgs->eql, sizeof(BITMAP), &imgs->beql);

	GetPrivateProfileString("Images", "RightEQBorder", "eqborder-right.bmp", temp, 256, skin_ini);
	sprintf(src, "%s%s", SKIN_PATH, temp);
	imgs->eqr = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (imgs->eqr) GetObject(imgs->eqr, sizeof(BITMAP), &imgs->beqr);
	
	// ask for the current equalizer settings
    player->GetCodecEqualizer();
	
    // set the range and position for the sliders
	for (x=0; x < 16; x++)
	{
		EQ[x]->SetRange(-100,100);
		sprintf(temp, "EQ%dpos", x+1);
		EQ[x]->SetPos(GetPrivateProfileInt("EQ", temp, 0, skin_ini));
	}
    
	eqx = GetPrivateProfileInt("EQ", "X", X, skin_ini);
	eqy = GetPrivateProfileInt("EQ", "Y", Y-120, skin_ini);
	eqw = GetPrivateProfileInt("EQ", "W", 125, skin_ini);
	eqh = GetPrivateProfileInt("EQ", "H", 120, skin_ini);
	SetWindowPos(EQWnd, NULL, eqx, eqy, eqw, eqh, SWP_NOZORDER);
	if (GetPrivateProfileInt("EQ", "Visible", 0, skin_ini)) ShowWindow(EQWnd, SW_SHOW);
}

void EQUpdate()
{
	XA_EqualizerInfo EQI;

	for (int x=0, y=0; x < 16; x++, y+=2)
	{
		EQI.left[y] = EQI.left[y+1] = -EQ[x]->GetPos();
	}

    // right channel is same as left
    for (int i=0; i<sizeof(EQI.right)/sizeof(EQI.right[0]); i++) {
        EQI.right[i] = EQI.left[i];
    }

    player->SetCodecEqualizer(&EQI);
}