//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LSPlayList.rc
//
#define IDD_MAIN                        101
#define IDD_PLAYLIST                    101
#define IDD_NEWTRACKLIST                102
#define IDD_NEWLIST                     104
#define IDD_EDITTRACKLIST               119
#define IDD_WATCHDIRECTORY              120
#define IDD_HOTKEYS                     121
#define IDD_PROPS_MJBUTTON              123
#define IDD_EQUALIZER                   124
#define IDD_SKIN_BROWSER                125
#define IDC_LIST                        1000
#define IDC_NEW_TRACKS                  1000
#define IDC_COMBO                       1001
#define IDC_EDIT                        1003
#define IDC_ALL_TRACKS                  1010
#define IDC_SOME_TRACKS                 1011
#define IDC_PROGRESS                    1013
#define IDC_MOD_PLAY                    1014
#define IDC_MOD_PAUSE                   1015
#define IDC_KEY_PLAY                    1016
#define IDC_KEY_PAUSE                   1017
#define IDC_MJBUTTON_X                  1017
#define IDC_MOD_NEXT                    1018
#define IDC_MJBUTTON_Y                  1018
#define IDC_KEY_NEXT                    1019
#define IDC_MJBUTTON_W                  1019
#define IDC_MOD_STOP                    1020
#define IDC_MJBUTTON_H                  1020
#define IDC_KEY_STOP                    1021
#define IDC_MJBUTTON_IMG_NORMAL         1021
#define IDC_MJBUTTON_IMG_OVER           1022
#define IDC_MJBUTTON_IMG_CLICKED        1023
#define IDC_MOD_PREV                    1024
#define IDC_MJBUTTON_IMG_NORMAL_BROWSE  1024
#define IDC_KEY_PREV                    1025
#define IDC_MJBUTTON_IMG_OVER_BROWSE    1025
#define IDC_MOD_FWD                     1026
#define IDC_MJBUTTON_IMG_CLICKED_BROWSE 1026
#define IDC_KEY_FWD                     1027
#define IDC_MOD_BACK                    1028
#define IDC_KEY_BACK                    1029
#define IDC_EQ1                         1029
#define IDC_MOD_SHOW                    1030
#define IDC_EQ2                         1030
#define IDC_SKIN_LIST                   1030
#define IDC_KEY_SHOW                    1031
#define IDC_EQ3                         1031
#define IDC_MOD_HIDE                    1032
#define IDC_EQ4                         1032
#define IDC_KEY_HIDE                    1033
#define IDC_EQ5                         1033
#define IDC_EQ6                         1034
#define IDC_EQ7                         1035
#define IDC_EQ8                         1036
#define IDC_EQ9                         1037
#define IDC_EQ10                        1038
#define IDC_EQ11                        1039
#define IDC_EQ12                        1040
#define IDC_EQ13                        1041
#define IDC_EQ14                        1042
#define IDC_EQ15                        1043
#define IDC_EQ16                        1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        126
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
