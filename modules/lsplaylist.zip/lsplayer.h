#include <XaudioPlayer.h>

#define LSP_NEXTSONG	WM_USER+100
#define LSP_POS			WM_USER+101
#define LSP_INPUTNAME	WM_USER+102

#ifndef __LSPLAYER_H
#define __LSPLAYER_H

class LSPlayer : public XaudioPlayer
{
public:
    // member variables
    BOOL m_Scrolling;
    XA_PlayerState m_State;
	HWND m_hwnd;

    // methods
    LSPlayer(HINSTANCE instance, HWND parent);
    void OnNotifyReady();
    void OnNotifyNack(XA_NackInfo *info);
    void OnNotifyPlayerState(XA_PlayerState state);
    void OnNotifyInputPosition(unsigned long offset, unsigned long range);
    void OnNotifyInputName(const char *name);
    void OnNotifyInputState(XA_InputState state);
    void OnNotifyInputDuration(unsigned long duration);
    void OnNotifyInputTimecode(XA_TimecodeInfo *info);
    void OnNotifyInputStreamInfo(XA_StreamInfo *info);
    void OnNotifyInputModuleInfo(XA_ModuleInfo *info);
    void OnNotifyOutputState(XA_OutputState state);
    void OnNotifyOutputModuleInfo(XA_ModuleInfo *info);
    void OnNotifyOutputMasterLevel(unsigned char level);
    void OnNotifyOutputPcmLevel(unsigned char level);
    void OnNotifyOutputBalance(unsigned char balance);
    void OnNotifyCodecEqualizer(XA_EqualizerInfo *equalizer);
};

#endif