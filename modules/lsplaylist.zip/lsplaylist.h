#define LSP_NCHITTEST	WM_USER + 300
#define LSP_GETTRACKPOS	WM_USER + 301
#define LSP_GETTRANS	WM_USER + 302
#define LSP_RECYCLE		WM_USER + 303

void SetWindowBitmapRgn(HWND hwnd, HDC hdc, HBITMAP bmp);