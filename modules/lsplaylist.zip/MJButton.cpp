#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "resource.h"
#include "MJButton.h"
#include "LSPlaylist.h"

LRESULT CALLBACK SkeletonButtonProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SkeletonDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void BrowseForFile(HWND hwnd, DWORD editbox, char* filter);

int MJButton::p_count = 0;

MJButton::MJButton(LPCTSTR name, HWND parent, HINSTANCE hInstance, LPCTSTR ini, LPCTSTR ttip, int def_x, int def_y, int def_w, int def_h, LPCTSTR skin_dir, LPCTSTR def_normal, LPCTSTR def_over, LPCTSTR def_clicked)
{
	char temp[256] = "";
	char src[256] = "";
	int def_anchor=1; // 0=left, 1=right, 2=top, 3=bottom, 4=bottom/right

	m_size_change=TRUE;
	m_name = _strdup(name);
	m_parent = parent;
	m_hinst = hInstance;
	m_ini = _strdup(ini);
	
	GetPrivateProfileString(m_name, "Normal", "NO GO", temp, 256, m_ini);
	if (!strcmp(temp, "NO GO"))
	{
		strcpy(temp, def_normal);
		WritePrivateProfileString(m_name, "Normal", temp, m_ini);
	}
	sprintf(src, "%s%s", skin_dir, temp);
	m_normal = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	
	GetPrivateProfileString(m_name, "Over", "NO GO", temp, 256, m_ini);
	if (!strcmp(temp, "NO GO"))
	{
		strcpy(temp, def_over);
		WritePrivateProfileString(m_name, "Over", temp, m_ini);
	}
	sprintf(src, "%s%s", skin_dir, temp);
	m_over = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	GetPrivateProfileString(m_name, "Clicked", "NO GO", temp, 256, m_ini);
	if (!strcmp(temp, "NO GO"))
	{
		strcpy(temp, def_clicked);
		WritePrivateProfileString(m_name, "Clicked", temp, m_ini);
	}
	sprintf(src, "%s%s", skin_dir, temp);
	m_clicked = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	m_x = GetPrivateProfileInt(m_name, "X", def_x, ini);
	m_y = GetPrivateProfileInt(m_name, "Y", def_y, ini);
	m_w = GetPrivateProfileInt(m_name, "W", def_w, ini);
	m_h = GetPrivateProfileInt(m_name, "H", def_h, ini);
	m_anchor = GetPrivateProfileInt(m_name, "Anchor", def_anchor, ini);

	WNDCLASS wc;
	memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc = SkeletonButtonProc;
    wc.hInstance = m_hinst;
	wc.lpszClassName = "MJButton";
	RegisterClass(&wc);
	
	m_hwnd = CreateWindow("MJButton", m_name, WS_VISIBLE | WS_CHILD, m_x, m_y, m_w, m_h, m_parent, NULL, m_hinst, 0);
	SetProp(m_hwnd, "MJButton", (HANDLE)this);

	MoveWindow(m_x, m_y);
	ResizeWindow(m_w, m_h);

	m_tool = CreateWindow(TOOLTIPS_CLASS, m_name, TTS_ALWAYSTIP, 0, 0, 0, 0, m_hwnd, NULL, m_hinst, 0);
	TOOLINFO ti;
	RECT r;
	GetClientRect(m_hwnd, &r);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_CENTERTIP;
	ti.hwnd = m_hwnd;
	ti.uId = 0;
	ti.rect = r;
	ti.hinst = m_hinst;
	ti.lpszText = (char*)ttip;
	SendMessage(m_tool, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);

	m_popup = CreatePopupMenu();
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_PROPERTIES, "&Properties");
	AppendMenu(m_popup, MF_SEPARATOR, 0, NULL);
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_ANCHOR_LEFT, "Anchor &Left");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_ANCHOR_RIGHT, "Anchor &Right");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_ANCHOR_TOP, "Anchor &Top");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_ANCHOR_BOTTOM, "Anchor &Bottom");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_ANCHOR_BR, "Anchor B&ottom/Right");
	
	SendMessage(m_hwnd, WM_COMMAND, MAKEWPARAM(P_ANCHOR_LEFT+m_anchor, 0), 0);

	p_count++;
}

MJButton::~MJButton()
{
	DestroyMenu(m_popup);

	DeleteObject(m_normal);
	DeleteObject(m_over);
	DeleteObject(m_clicked);
	RemoveProp(m_hwnd, "MJButton");
	DestroyWindow(m_hwnd);
	p_count--;

	if (!p_count) UnregisterClass("MJButton", m_hinst);
}

LRESULT CALLBACK SkeletonButtonProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	MJButton* button = (MJButton*)GetProp(hwnd, "MJButton");
	if (button)
		return button->m_proc(hwnd, msg, wParam, lParam);
	else return 1;
}

BOOL CALLBACK SkeletonDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	MJButton* button = (MJButton*)GetProp(hwnd, "MJButton");
	if (button)
		return button->m_dlgproc(hwnd, msg, wParam, lParam);
	else return FALSE;
}

LRESULT CALLBACK MJButton::m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static BOOL EDITMODE=FALSE;

	if (!this) return 0;

	switch (msg)
	{
		case WM_NCHITTEST:
		{
			LRESULT res = SendMessage(m_parent, LSP_NCHITTEST, 0, 0);
			if (res == HTCAPTION) 
			{ 
				if (!EDITMODE)
				{
					EDITMODE=TRUE; 
					RedrawWindow(m_parent, NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE);
				}
				return HTCAPTION;
			}
			else 
			{
				if (EDITMODE)
				{
					EDITMODE=FALSE; 
					RedrawWindow(m_parent, NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE);
				}
				return HTCLIENT; 
			}
		}
		break;

		case WM_NCRBUTTONUP:
		case WM_RBUTTONUP:
		{
			if (EDITMODE)
			{
				DWORD dw = GetMessagePos();
				TrackPopupMenu(m_popup, TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
			}
		}
		break;

		case WM_COMMAND:
		{
			char temp[256] = "";

			switch (LOWORD(wParam))
			{
				case P_PROPERTIES:
				{
					HWND dlg = CreateDialog(m_hinst, MAKEINTRESOURCE(IDD_PROPS_MJBUTTON), m_parent, SkeletonDlgProc);
					SetProp(dlg, "MJButton", (HANDLE)this);
					SetDlgItemInt(dlg, IDC_MJBUTTON_X, m_x, FALSE);
					SetDlgItemInt(dlg, IDC_MJBUTTON_Y, m_y, FALSE);
					SetDlgItemInt(dlg, IDC_MJBUTTON_W, m_w, FALSE);
					SetDlgItemInt(dlg, IDC_MJBUTTON_H, m_h, FALSE);
				}
				break;

				case P_ANCHOR_LEFT:
				{
					m_anchor = 0;
					CheckMenuRadioItem(m_popup, P_ANCHOR_LEFT, P_ANCHOR_BR, P_ANCHOR_LEFT, MF_BYCOMMAND);
					sprintf(temp, "%d", m_anchor);
					WritePrivateProfileString(m_name, "Anchor", temp, m_ini);
				}
				break;

				case P_ANCHOR_RIGHT:
				{
					m_anchor = 1;
					CheckMenuRadioItem(m_popup, P_ANCHOR_LEFT, P_ANCHOR_BR, P_ANCHOR_RIGHT, MF_BYCOMMAND);
					sprintf(temp, "%d", m_anchor);
					WritePrivateProfileString(m_name, "Anchor", temp, m_ini);
				}
				break;

				case P_ANCHOR_TOP:
				{
					m_anchor = 2;
					CheckMenuRadioItem(m_popup, P_ANCHOR_LEFT, P_ANCHOR_BR, P_ANCHOR_TOP, MF_BYCOMMAND);
					sprintf(temp, "%d", m_anchor);
					WritePrivateProfileString(m_name, "Anchor", temp, m_ini);
				}
				break;

				case P_ANCHOR_BOTTOM:
				{
					m_anchor = 3;
					CheckMenuRadioItem(m_popup, P_ANCHOR_LEFT, P_ANCHOR_BR, P_ANCHOR_BOTTOM, MF_BYCOMMAND);
					sprintf(temp, "%d", m_anchor);
					WritePrivateProfileString(m_name, "Anchor", temp, m_ini);
				}
				break;

				case P_ANCHOR_BR:
				{
					m_anchor = 4;
					CheckMenuRadioItem(m_popup, P_ANCHOR_LEFT, P_ANCHOR_BR, P_ANCHOR_BR, MF_BYCOMMAND);
					sprintf(temp, "%d", m_anchor);
					WritePrivateProfileString(m_name, "Anchor", temp, m_ini);
				}
				break;
			}
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			LPWINDOWPOS wp = (LPWINDOWPOS)lParam;

			if (!(wp->flags & SWP_NOSIZE))
			{
				if (wp->cx != m_w || wp->cy != m_h) m_size_change=TRUE;
			}
		}
		break;

		case WM_WINDOWPOSCHANGED:
		{
			LPWINDOWPOS wp = (LPWINDOWPOS)lParam;
			char temp[10] = "";

			if (this)
			{
				m_x = wp->x;
				sprintf(temp, "%d", m_x);
				WritePrivateProfileString(m_name, "X", temp, m_ini);

				m_y = wp->y;
				sprintf(temp, "%d", m_y);
				WritePrivateProfileString(m_name, "Y", temp, m_ini);

				m_w = wp->cx;
				sprintf(temp, "%d", m_w);
				WritePrivateProfileString(m_name, "W", temp, m_ini);

				m_h = wp->cy;
				sprintf(temp, "%d", m_h);
				WritePrivateProfileString(m_name, "H", temp, m_ini);
			}
		}
		break;

		case WM_ENABLE:
		{
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_NCPAINT:
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC bufdc = CreateCompatibleDC(NULL);
			HDC bmpdc = CreateCompatibleDC(NULL);
			HBITMAP oldbmp, oldbuf, bufbmp = CreateCompatibleBitmap(hdc, m_w, m_h);
			HBITMAP* curbmp;

			SendMessage(hwnd, WM_NCHITTEST, 0, 0);

			if (m_state == s_over && m_over) curbmp = &m_over;
			else if (m_state == s_clicked && m_clicked)	curbmp = &m_clicked;
			else curbmp = &m_normal;

			BITMAP bmp;
			GetObject(*curbmp, sizeof(bmp), &bmp);

			oldbuf = (HBITMAP)SelectObject(bufdc, bufbmp);

			oldbmp = (HBITMAP)SelectObject(bmpdc, *curbmp);
			BitBlt(bufdc, (m_w/2)-(bmp.bmWidth/2), (m_h/2)-(bmp.bmHeight/2), bmp.bmWidth, bmp.bmHeight, bmpdc, 0, 0, SRCCOPY);

			if (m_size_change)
			{
				m_size_change=FALSE;
				if (SendMessage(m_parent, LSP_GETTRANS, 0, 0)) SetWindowBitmapRgn(m_hwnd, bufdc, bufbmp);
				else SetWindowBitmapRgn(m_hwnd, NULL, NULL);
			}

			if (EDITMODE)
			{
				RECT r;
				GetClientRect(hwnd, &r);
				HBRUSH hbr = CreateSolidBrush(0x000000FF);
				FrameRect(bufdc, &r, hbr);
				DeleteObject(hbr);
			}

			if (!IsWindowEnabled(hwnd))
			{
				RECT r;
				GetClientRect(hwnd, &r);
				FillRect(hdc, &r, (HBRUSH)GetStockObject(GRAY_BRUSH));
				BitBlt(hdc, 0, 0, m_w, m_h, bufdc, 0, 0, SRCAND);
			}
			else BitBlt(hdc, 0, 0, m_w, m_h, bufdc, 0, 0, SRCCOPY);
			
			SelectObject(bmpdc, oldbmp);
			DeleteDC(bmpdc);
			DeleteObject(oldbmp);

			SelectObject(bufdc, oldbuf);
			DeleteDC(bufdc);
			DeleteObject(bufbmp);
			DeleteObject(oldbuf);
			
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_KEYDOWN:
		{
			SendMessage(m_parent, MJ_BTN_KEYDOWN, wParam, (LPARAM)this);
		}
		break;

		case WM_NCLBUTTONDOWN:
		case WM_LBUTTONDOWN:
		{
			SetFocus(hwnd);
			m_state = s_clicked;
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_NCLBUTTONUP:
		case WM_LBUTTONUP:
		{
			SendMessage(m_parent, MJ_BTN_CLICKED, (WPARAM)this, 0);
			m_state = s_normal;
			InvalidateRect(hwnd, NULL, TRUE);
		}
		break;

		case WM_NCMOUSEMOVE:
		case WM_MOUSEMOVE:
		{
			MSG TooltipMessage;
			TooltipMessage.hwnd=hwnd;
            TooltipMessage.message=msg;
            TooltipMessage.wParam=wParam;
            TooltipMessage.lParam=lParam;
            SendMessage(m_tool, TTM_RELAYEVENT, 0, (LPARAM)&TooltipMessage);

			if (m_state == s_normal)
			{
				m_state = s_over;
				InvalidateRect(hwnd, NULL, TRUE);
				SetTimer(hwnd, 0, 5, NULL);
			}
		}
		break;

		case WM_TIMER:
		{
			switch ((int)wParam)
			{
				case 0:
				{
					POINT p;
					GetCursorPos(&p);
					if (WindowFromPoint(p) != hwnd)
					{
						KillTimer(hwnd, 0);
						m_state = s_normal;
						InvalidateRect(hwnd, NULL, TRUE);
					}
				}
				break;
			}
		}
		break;
	}
	
	return DefWindowProc(hwnd, msg, wParam, lParam);
}

BOOL CALLBACK MJButton::m_dlgproc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
						case IDOK:
						{
						}
						case IDCANCEL:
						{
							RemoveProp(hwnd, "MJButton");
							EndDialog(hwnd, 0);
						}
						return TRUE;

						case IDC_MJBUTTON_IMG_NORMAL_BROWSE:
						{
							BrowseForFile(hwnd, IDC_MJBUTTON_IMG_NORMAL, "Bitmap (*.bmp)\0*.bmp\0\0");
						}
						break;

						case IDC_MJBUTTON_IMG_OVER_BROWSE:
						{
							BrowseForFile(hwnd, IDC_MJBUTTON_IMG_OVER, "Bitmap (*.bmp)\0*.bmp\0\0");
						}
						break;

						case IDC_MJBUTTON_IMG_CLICKED_BROWSE:
						{
							BrowseForFile(hwnd, IDC_MJBUTTON_IMG_CLICKED, "Bitmap (*.bmp)\0*.bmp\0\0");
						}
						break;
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

void MJButton::MoveWindow(int x, int y)
{
	m_x = x;
	m_y = y;

	SetWindowPos(m_hwnd, NULL, m_x, m_y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

void MJButton::RMoveWindow(int cx, int cy)
{
	switch (m_anchor)
	{
		case 0: // left
		{
		}
		break;

		case 1: // right
		{
			m_x -= cx;
		}
		break;

		case 2: // top
		{
		}
		break;

		case 3: // bottom
		{
			m_y -= cy;
		}
		break;

		case 4: // bottom/right
		{
			m_y -= cy;
			m_x -= cx;
		}
		break;
	}

	SetWindowPos(m_hwnd, NULL, m_x, m_y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}

void MJButton::ResizeWindow(int w, int h)
{
	m_w = w;
	m_h = h;

	SetWindowPos(m_hwnd, NULL, 0, 0, m_w, m_h, SWP_NOMOVE | SWP_NOZORDER);
}

void BrowseForFile(HWND hwnd, DWORD editbox, char* filter)
{
	char filename[MAX_PATH] = "";
	OPENFILENAME* of = new OPENFILENAME;

	of->lStructSize = sizeof(OPENFILENAME);
	of->hwndOwner	= hwnd;
	of->hInstance	= NULL;
	of->lpstrFilter =  filter;
	of->lpstrCustomFilter = NULL;
	of->nMaxCustFilter		= 0;
	of->nFilterIndex		= 0;
	of->lpstrFile			= filename;
	of->nMaxFile			= MAX_PATH;
	of->lpstrFileTitle		= NULL;
	of->lpstrDefExt			= "bmp";
	of->lpstrInitialDir 	= NULL;
	of->lpstrTitle			= "Select Image";
	of->Flags = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY;

	__try 
	{ 
		if (GetOpenFileName(of))
		{
			SetDlgItemText(hwnd, editbox, filename);
		}
		delete of;
	} __except(1) { }
}