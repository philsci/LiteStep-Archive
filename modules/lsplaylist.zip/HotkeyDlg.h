#define HOTKEY_PLAY 0
#define HOTKEY_PAUSE 1
#define HOTKEY_STOP 2
#define HOTKEY_NEXT 3
#define HOTKEY_PREV 4
#define HOTKEY_FWD 5
#define HOTKEY_BACK 6
#define HOTKEY_SHOW 7
#define HOTKEY_HIDE 8

#ifndef __HOTKEYDLG_H
#define __HOTKEYDLG_H

class HotkeyDlg
{
private:
	HWND m_parent;
	HWND m_hwnd;
	HINSTANCE m_hinst;
	LPCTSTR m_ini;

public:
	HotkeyDlg(HWND hwnd, HINSTANCE hinst, LPCTSTR ini);
	~HotkeyDlg();
	
	BOOL CALLBACK m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
	void Go();
	void SetupModCombo(int item, char* name);
	void SetupKeyCombo(int item, char* name);
	void Save(int mod, int key, char* name, int id);
};

#endif