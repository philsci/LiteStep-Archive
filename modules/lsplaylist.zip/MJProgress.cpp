#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "resource.h"
#include "LSPlaylist.h"
#include "MJProgress.h"

LRESULT CALLBACK SkeletonProgressProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

MJProgress::MJProgress(LPCTSTR name, LPCTSTR pre, HWND progress, HWND parent, HINSTANCE hInstance, LPCTSTR ini,
						int def_x, int def_y,
						int def_w, int def_h,
						LPCTSTR skin_dir,
						LPCTSTR def_bg,
						LPCTSTR def_fg)
{
	char temp[256] = "";
	char src[256] = "";

	m_pre = _strdup(pre);
	m_size_change=TRUE;
	m_hwnd = progress;
	m_name = _strdup(name);
	m_parent = parent;
	m_hinst = hInstance;
	m_ini = _strdup(ini);
	
	sprintf(src, "%sBackground", m_pre);
	GetPrivateProfileString(m_name, src, "NO GO", temp, 256, m_ini);
	if (!strcmp(temp, "NO GO"))
	{
		strcpy(temp, def_bg);
		WritePrivateProfileString(m_name, src, temp, m_ini);
	}
	sprintf(src, "%s%s", skin_dir, temp);
	m_bg = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (m_bg) GetObject(m_bg, sizeof(BITMAP), &m_bbg);
	
	sprintf(src, "%sForeground", m_pre);
	GetPrivateProfileString(m_name, src, "NO GO", temp, 256, m_ini);
	if (!strcmp(temp, "NO GO"))
	{
		strcpy(temp, def_fg);
		WritePrivateProfileString(m_name, src, temp, m_ini);
	}
	sprintf(src, "%s%s", skin_dir, temp);
	m_fg = (HBITMAP)LoadImage(NULL, src, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	if (m_fg) GetObject(m_fg, sizeof(BITMAP), &m_bfg);

	sprintf(src, "%sX", m_pre);
	m_x = GetPrivateProfileInt(m_name, src, def_x, ini);
	sprintf(src, "%sY", m_pre);
	m_y = GetPrivateProfileInt(m_name, src, def_y, ini);
	sprintf(src, "%sW", m_pre);
	m_w = GetPrivateProfileInt(m_name, src, def_w, ini);
	sprintf(src, "%sH", m_pre);
	m_h = GetPrivateProfileInt(m_name, src, def_h, ini);

	m_popup = CreatePopupMenu();
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_PROG_VERTICAL, "&Vertical");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_PROG_HORIZONTAL, "&Horizontal");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_PROG_STRETCH, "&Stretch");
	AppendMenu(m_popup, MF_ENABLED | MF_STRING, P_PROG_REVEAL, "&Reveal");

	m_direction = GetPrivateProfileInt(m_name, "Direction", 0, ini);
	if (m_direction) CheckMenuRadioItem(m_popup, P_PROG_VERTICAL, P_PROG_HORIZONTAL, P_PROG_HORIZONTAL, MF_BYCOMMAND);
	else CheckMenuRadioItem(m_popup, P_PROG_VERTICAL, P_PROG_HORIZONTAL, P_PROG_VERTICAL, MF_BYCOMMAND);

	m_stretch = GetPrivateProfileInt(m_name, "Stretch", 0, ini);
	if (m_stretch) CheckMenuItem(m_popup, P_PROG_STRETCH, MF_CHECKED);

	m_reveal = GetPrivateProfileInt(m_name, "Reveal", 1, ini);
	if (m_reveal) CheckMenuItem(m_popup, P_PROG_REVEAL, MF_CHECKED);

	LONG style = WS_CHILDWINDOW | WS_VISIBLE | PBS_SMOOTH | PBS_VERTICAL;
	SetWindowLong(m_hwnd, GWL_STYLE, style);
	LONG exstyle = WS_EX_LEFT | WS_EX_LTRREADING | WS_EX_RIGHTSCROLLBAR | WS_EX_NOPARENTNOTIFY;
	SetWindowLong(m_hwnd, GWL_EXSTYLE, exstyle);

	p_oldproc = SetWindowLong(m_hwnd, GWL_WNDPROC, (LONG)SkeletonProgressProc);
	SetProp(m_hwnd, "MJProgress", (HANDLE)this);

	SetWindowPos(m_hwnd, NULL, m_x, m_y, m_w, m_h, SWP_NOZORDER);
}

MJProgress::~MJProgress()
{
	DestroyMenu(m_popup);
	DeleteObject(m_bg);
	DeleteObject(m_fg);
	RemoveProp(m_hwnd, "MJProgress");
	DestroyWindow(m_hwnd);
}

LRESULT CALLBACK SkeletonProgressProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	MJProgress* prog = (MJProgress*)GetProp(hwnd, "MJProgress");
	if (prog)
		return prog->m_proc(hwnd, msg, wParam, lParam);
	else return 1;
}

LRESULT CALLBACK MJProgress::m_proc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static BOOL LAYOUT_EDIT=FALSE;

	if (!this) return 0;

	switch (msg)
	{
		case WM_NCHITTEST:
		{
			LRESULT res = SendMessage(m_parent, LSP_NCHITTEST, 0, 0);
			if (res == HTCAPTION) 
			{ 
				if (!LAYOUT_EDIT)
				{
					LAYOUT_EDIT=TRUE; 
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return HTCAPTION;
			}
			else 
			{
				if (LAYOUT_EDIT)
				{
					LAYOUT_EDIT=FALSE;
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return HTCLIENT;
			}
		}
		break;

		case WM_NCPAINT: 
		{
			if (!LAYOUT_EDIT) break;
			CallWindowProc((WNDPROC)p_oldproc, hwnd, msg, wParam, lParam);
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbufbmp, oldsrcbmp;
			int TRACKPOS=GetPos();

			bufbmp = (HBITMAP)CreateCompatibleBitmap(hdc, m_w, m_h);
			oldbufbmp = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrcbmp = (HBITMAP)SelectObject(src, m_bg);
			if (m_stretch)
				StretchBlt(buf, 0, 0, m_w, m_h, src, 0, 0, m_bbg.bmWidth, m_bbg.bmHeight, SRCCOPY);
			else
				BitBlt(buf, 0, 0, m_w, m_h, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrcbmp);

			if (m_size_change)
			{
				m_size_change=FALSE;
				if (SendMessage(m_parent, LSP_GETTRANS, 0, 0)) SetWindowBitmapRgn(m_hwnd, buf, bufbmp);
				else SetWindowBitmapRgn(m_hwnd, NULL, NULL);
			}

			oldsrcbmp = (HBITMAP)SelectObject(src, m_fg);	
			if (!m_direction) // Vertical
			{
				int range = m_range[1]-m_range[0];
				int bgy = (int)(m_h-(float)((float)TRACKPOS/(float)range)*m_h + m_h * (float)((float)m_range[0]/(float)range));
				int fgy = (int)(m_bfg.bmHeight-(float)((float)TRACKPOS/(float)range)*m_bfg.bmHeight + m_bfg.bmHeight * (float)((float)m_range[0]/(float)range));
			
				if (m_reveal)
				{
					if (m_stretch)
						StretchBlt(buf, 0, bgy, m_w, m_h, src, 0, fgy, m_bfg.bmWidth, m_bfg.bmHeight, SRCCOPY);
					else
						BitBlt(buf, 0, bgy, m_w, m_h, src, 0, bgy, SRCCOPY);
				}
				else
				{
					if (m_stretch)
						StretchBlt(buf, 0, bgy, m_w, m_h, src, 0, 0, m_bfg.bmWidth, m_bfg.bmHeight, SRCCOPY);
					else
						BitBlt(buf, 0, bgy, m_w, m_h, src, 0, 0, SRCCOPY);
				}
			}
			else // Horizontal
			{
				int bgw = (int)(TRACKPOS/(float)m_range[1]*m_w);

				if (m_reveal)
				{
					if (m_stretch)
						StretchBlt(buf, 0, 0, bgw, m_h, src, 0, 0, m_bfg.bmWidth, m_bfg.bmHeight, SRCCOPY);
					else
						BitBlt(buf, 0, 0, bgw, m_h, src, 0, 0, SRCCOPY);
				}
				else
				{
					if (m_stretch)
						StretchBlt(buf, 0, 0, bgw, m_h, src, m_bfg.bmWidth-bgw, 0, m_bfg.bmWidth, m_bfg.bmHeight, SRCCOPY);
					else
						BitBlt(buf, 0, 0, bgw, m_h, src, m_bfg.bmWidth-bgw, 0, SRCCOPY);
				}
			}
			SelectObject(src, oldsrcbmp);

			if (LAYOUT_EDIT)
			{
				RECT r;
				GetClientRect(hwnd, &r);
				HBRUSH hbr = CreateSolidBrush(0x000000FF);
				FrameRect(buf, &r, hbr);
				DeleteObject(hbr);
			}

			BitBlt(hdc, 0, 0, m_w, m_h, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbufbmp);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbufbmp);
			DeleteDC(src);
			DeleteObject(oldsrcbmp);
			EndPaint(hwnd, &ps);
		}
		return TRUE;

		case WM_ERASEBKGND: return TRUE;

		case WM_NCRBUTTONUP:
		case WM_RBUTTONUP:
		{
			if (LAYOUT_EDIT)
			{
				DWORD dw = GetMessagePos();
				TrackPopupMenu(m_popup, TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
			}
		}
		break;

		case WM_COMMAND:
		{
			char temp[256] = "";
			strcpy(temp, m_pre);
			switch (LOWORD(wParam))
			{
				case P_PROG_VERTICAL:
				{
					m_direction=0;
					CheckMenuRadioItem(m_popup, P_PROG_VERTICAL, P_PROG_HORIZONTAL, P_PROG_VERTICAL, MF_BYCOMMAND);
					strcat(temp, "Direction");
					WritePrivateProfileString(m_name, temp, "0", m_ini);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				break;

				case P_PROG_HORIZONTAL:
				{
					m_direction=1;
					CheckMenuRadioItem(m_popup, P_PROG_VERTICAL, P_PROG_HORIZONTAL, P_PROG_HORIZONTAL, MF_BYCOMMAND);
					strcat(temp, "Direction");
					WritePrivateProfileString(m_name, temp, "1", m_ini);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				break;

				case P_PROG_STRETCH:
				{
					if (m_stretch)
					{
						m_stretch=FALSE;
						CheckMenuItem(m_popup, P_PROG_STRETCH, MF_UNCHECKED);
						strcat(temp, "Stretch");
						WritePrivateProfileString(m_name, temp, "0", m_ini);
					}
					else
					{
						m_stretch=TRUE;
						CheckMenuItem(m_popup, P_PROG_STRETCH, MF_CHECKED);
						strcat(temp, "Stretch");
						WritePrivateProfileString(m_name, temp, "1", m_ini);
					}

					InvalidateRect(hwnd, NULL, TRUE);
				}
				break;

				case P_PROG_REVEAL:
				{
					if (m_reveal)
					{
						m_reveal=FALSE;
						CheckMenuItem(m_popup, P_PROG_REVEAL, MF_UNCHECKED);
						strcat(temp, "Reveal");
						WritePrivateProfileString(m_name, temp, "0", m_ini);
					}
					else
					{
						m_reveal=TRUE;
						CheckMenuItem(m_popup, P_PROG_REVEAL, MF_CHECKED);
						strcat(temp, "Reveal");
						WritePrivateProfileString(m_name, temp, "1", m_ini);
					}

					InvalidateRect(hwnd, NULL, TRUE);
				}
				break;
			}
		}
		break;

		case WM_NCLBUTTONDOWN: SetFocus(hwnd); break;
		case WM_LBUTTONDOWN:
		{
			int x = LOWORD(lParam), tx;
			int y = HIWORD(lParam), ty;
			RECT r;
			GetClientRect(hwnd, &r);
			ty = m_range[1] - y*(m_range[1]-m_range[0])/r.bottom;
			tx = x*m_range[1]/r.right;

			if (!m_direction) 
			{
				SetPos(ty);
				SendMessage(m_parent, MJ_PRG_LBUTTONDOWN, (WPARAM)ty, 0);
			}
			else 
			{
				SetPos(tx);
				SendMessage(m_parent, MJ_PRG_LBUTTONDOWN, (WPARAM)tx, 0);
			}
		}
		break;

		case WM_MOUSEMOVE:
		{
			if (wParam & MK_LBUTTON)
			{
				if (!(HIWORD(lParam) % 5))
					SendMessage(hwnd, WM_LBUTTONDOWN, wParam, lParam);
			}
		}
		break;

		case WM_KEYDOWN:
		{
			if (LAYOUT_EDIT)
			{
				int dist=1;
				RECT r;
				GetWindowRect(hwnd, &r);
				
				if (HIWORD(GetKeyState(VK_CONTROL)) & 1 == 1) // Resize
				{
					switch ((int)wParam)
					{
						case VK_UP: r.bottom-=dist; break;
						case VK_DOWN: r.bottom+=dist; break;
						case VK_LEFT: r.right-=dist; break;
						case VK_RIGHT: r.right+=dist; break;
					}

					SetWindowPos(hwnd, NULL, 0, 0, r.right-r.left, r.bottom-r.top, SWP_NOMOVE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				else // Move
				{
					if (HIWORD(GetKeyState(VK_SHIFT)) & 1 == 1) dist=5;

					switch ((int)wParam)
					{
						case VK_UP: m_y-=dist; break;
						case VK_DOWN: m_y+=dist; break;
						case VK_LEFT: m_x-=dist; break;
						case VK_RIGHT: m_x+=dist; break;
					}
					SetWindowPos(hwnd, NULL, m_x, m_y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				return TRUE;
			}
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			LPWINDOWPOS wp = (LPWINDOWPOS)lParam;

			if (!(wp->flags & SWP_NOSIZE))
			{
				if (wp->cx != m_w || wp->cy != m_h) m_size_change=TRUE;
			}
		}
		break;

		case WM_WINDOWPOSCHANGED:
		{
			LPWINDOWPOS wp = (LPWINDOWPOS)lParam;
			char temp[10] = "";
			char name[25] = "";

			m_x=wp->x;
			sprintf(temp, "%d", wp->x);
			sprintf(name, "%sX", m_pre);
			WritePrivateProfileString(m_name, name, temp, m_ini);

			m_y=wp->y;
			sprintf(temp, "%d", wp->y);
			sprintf(name, "%sY", m_pre);
			WritePrivateProfileString(m_name, name, temp, m_ini);

			m_w=wp->cx;
			sprintf(temp, "%d", wp->cx);
			sprintf(name, "%sW", m_pre);
			WritePrivateProfileString(m_name, name, temp, m_ini);

			m_h=wp->cy;
			sprintf(temp, "%d", wp->cy);
			sprintf(name, "%sH", m_pre);
			WritePrivateProfileString(m_name, name, temp, m_ini);
		}
		break;
	}

	return CallWindowProc((WNDPROC)p_oldproc, hwnd, msg, wParam, lParam);
}

void MJProgress::SetRange(int start, int end)
{
	m_range[0]=start;
	m_range[1]=end;
}

void MJProgress::SetPos(int pos)
{
	char temp[10] = "";
	char val[5] = "";
	sprintf(temp, "%spos", m_pre);
	sprintf(val, "%d", pos);
	WritePrivateProfileString("EQ", temp, val, m_ini);
	m_pos=pos;
	InvalidateRect(m_hwnd, NULL, TRUE);
}

int MJProgress::GetPos()
{
	return m_pos;
}

void MJProgress::Resize(int w, int h)
{
	SetWindowPos(m_hwnd, NULL, m_x, m_w, m_w, h-m_w*2, SWP_NOZORDER);
}