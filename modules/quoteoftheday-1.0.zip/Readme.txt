Quote Of The Day - Litestep module
Written in 1999 by Jan Erik Hanssen

version 1.0

** Installation: **
Enter "LoadModule c:\litestep\modules\quoteday.dll" in your step.rc file
Replace "c:\litestep\modules" with the directory where you put quoteday.dll


** Usage: **
This module introduces three new !bang commands:

!quote - Will display a random quote
!quoteAdd <param> - Will add a new quote to the quote-file
!quoteEdit - Will open notepad with the quote-file (if it exists)


** Notes: **
All quotes will be stored in the quote.txt-file in your litestep directory
(e.g. c:\litestep\quotes.txt)

This module was coded after I read some modules-suggestions at www.mindjunction.com.
One of the suggestions was a "quote of the day" module.

You can reach me at email: hanssen@who.net
or irc: nick "Kompis" at dal.net