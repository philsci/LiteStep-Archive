mIRC Command (v1.2) by WhiteShadow (changty@muohio.edu) on 4-10-00
*******************************************************************

This is a small module that adds a single bang command !mirccommand
which sends a command to mIRC.

Installation:

	1. Copy mirc.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\mirc.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Make sure that you have DDE server enabled in mIRC.  It is
	   found in Options->General->Servers
	4. Add the line

		mIRCDDEName <service_name>

	   to your step.rc if you want to use a service name other
	   than mIRC (the default value if the mIRCDDEName is
	   omitted).


Usage:

	!mIRCCommand <mirc_command>

	   mIRC will execute whatever follows !mirccommand.

	!mIRCChangeDDE <DDE name>

	   Changes the DDE name to DDE name.  This is useful if
	   you run multiple instances of mIRC at once.

Examples:

	1. !mirccommand hi everybody!

		This will have you say "hi everybody!" in whatever
		channel is on top

	2. !mirccommand /me waves

		This will have you do the /me action in whatever
		channel is on top

	3. !mircchangedde Clone | !mirccommand /msg #litestep poooooop!

		This will set the dde name to Clone and have Clone say
		poooooop! in #litestep.

History
	4-10-00 v1.2
	-Added !mircchangedde

	4-2-00 v1.1
	-Fixed closing of dde connection when module is unloaded.

	12-11-99 v1.0
	-Initial Release

Anyway, you could then bind any mIRC command to a hotkey or a shortcut.

Feel free to send me comments or bugs.
WhiteShadow
