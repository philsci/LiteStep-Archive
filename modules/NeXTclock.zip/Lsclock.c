 /*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/****************************************************************************
 12/16/99 - Joachim Calvert
			Finally got around to fix the "skin" to perfectly match the original
			NeXTSTEP clock. I still have a lot of cleaning up to do though.
****************************************************************************/

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <winsock.h>
#include <stdio.h>
#include <memory.h>
#include <malloc.h>

#include "lsapi.h"
#include "lsclock.h"
#include "resource.h"
#include "ntpfrac.h" // table de precalculs

char szAppName[] = "lsclock"; // window class, etc

#define MINUTE 60000

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
HWND hMainWnd; // main window handle
HWND parent;

// Double buffering data
HDC memDC;		// memory device context
HBITMAP	memBM,  // memory bitmap (for memDC)
oldBM;  // old bitmap (from memDC)

HDC memDC_date;		// memory device context
HDC memDC_day;		// memory device context
HDC memDC_month;	// memory device context
HDC memDC_time;		// memory device context
HDC memDC_fond;		// memory device context
HDC memDC_page;		// memory device context

HBITMAP bmp_date, odate;
HBITMAP bmp_day, oday;
HBITMAP bmp_month, omonth;
HBITMAP bmp_time, otime;
HBITMAP bmp_fond, ofond;
HBITMAP bmp_page, opage;

wharfDataType wharfData;

UINT Timer=0;

BOOL backInit=FALSE;
int usformat=0;

void createClock(void);


#define szNTPAppName "SNTPClientWnd"
LRESULT CALLBACK NTPWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void translatePacket(SYSTEMTIME received);
void ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
								unsigned int *resi, unsigned int *resf);
void ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
								 unsigned int *resi, unsigned int *resf);
void ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
void ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
void ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
void ConvertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time);
int socketError(int dontquit);
int closeup(void);
int do_ntp(void);
void EnablePriviledge(void);
void DisablePriviledge(void);

#define JAN_1_1900 2415021L // pre-computed JulianDayNumber(1900,1,1) 

typedef struct {
	int li					: 2;
	int vn					: 3;
	int mode				: 3;
	int stratum				: 8;
	int poll				: 8;
	signed int precision	: 8;
} bits_data;

HWND hNTPWnd=NULL;
int socketinit=0;
int wsainit=0;
SOCKET mysocket;
char xferdata[48];

bits_data bits;
unsigned int databits;

unsigned int rootdelay;
unsigned int rootdispersion;
unsigned int referenceidentifier;
unsigned int referencetimestamp_hi;
unsigned int referencetimestamp_lo;
unsigned int originatetimestamp_hi;
unsigned int originatetimestamp_lo;
unsigned int receivetimestamp_hi;
unsigned int receivetimestamp_lo;
unsigned int transmittimestamp_hi;
unsigned int transmittimestamp_lo;

HINSTANCE hInstance;

int maxderivation=3600;
int warnonmax=1;
int pollfrequency;
int notifyset=0;

char msgTitle[] = "NTP Clock Synchronization";

char hostname[256] = "smdlsdf";
int hostport = 123;

HMENU popup;
HWND NTPSetup;

int lockNTPtimer=0;

HANDLE tok_handle;
TOKEN_PRIVILEGES tok_priv;
int priv_modified=0;

//--------------------------------------------------------------------------------------------------

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	HDC pDC;
	HKEY key;
	int len=0;
	int tp=REG_SZ;
	//char ImagePath[1024];
	
	parent = ParentWnd;
	memcpy(&wharfData, wd, sizeof(*wd));
	
	usformat = wharfData.usClock;
	hInstance = dllInst;
	
	strcpy(hostname, "127.0.0.1");
	hostport = 123;
	maxderivation = 3600;
	pollfrequency = 0;
	warnonmax=1;
	notifyset=0;
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Aegis\\LiteSTEP\\Modules\\LSClock\\NTPClient", 0, KEY_READ | KEY_QUERY_VALUE, &key) == ERROR_SUCCESS)
	{
		len = 255;
		RegQueryValueEx(key, "Server", 0, &tp, (char *)&hostname[0], &len);
		len = sizeof(DWORD);
		RegQueryValueEx(key, "ServerPort", 0, &tp, (char *)&hostport, &len);
		RegQueryValueEx(key, "MaxDerivation", 0, &tp, (char *)&maxderivation, &len);
		RegQueryValueEx(key, "PollFrequency", 0, &tp, (char *)&pollfrequency, &len);
		RegQueryValueEx(key, "WarnOnAboveDelta", 0, &tp, (char *)&warnonmax, &len);
		RegQueryValueEx(key, "NotifyOnSetTime", 0, &tp, (char *)&notifyset, &len);
		RegCloseKey(key);
	}
	
	
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, 100, "&Open Time && Date panel");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 101, "&NTP Setup");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 102, "&Synchronize!");
	
	{	// Register our window class
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.style = CS_DBLCLKS; 
		
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class","lsclock",MB_OK);
			return 1;
		}
	}
	
	
	hMainWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,										// exstyles 
		szAppName,								// our window class name
		"lsclock",								// use description for a window title
		WS_CHILD,				
		wharfData.borderSize, wharfData.borderSize,				// position 
		64-wharfData.borderSize*2,64-wharfData.borderSize*2,		// width & height of window
		parent,									// parent window (winamp main window)
		NULL,									// no menu
		dllInst,								// hInstance of DLL
		0);										// no window creation data
	
	
	if (!hMainWnd) 
	{						   
		MessageBox(parent,"Error creating window","lsclock",MB_OK);
		return 1;
	}
	
	{    // Register the Window class
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = NTPWndProc;       // our window procedure
		wc.hInstance = hInstance;         // hInstance of DLL
		wc.lpszClassName = szNTPAppName;   // our window class name
		
		if (!RegisterClass(&wc)) 
		{
			MessageBox(NULL,"Error registering window class",msgTitle, MB_ICONHAND);
			return 1;
		}
		
		hNTPWnd = CreateWindowEx(
			0,											 // exstyles 
			szNTPAppName,								 // our window class name
			"",											 // use description for a window title
			0,											 // window style
			0, 0,										 // position 
			10, 10,										 // width & height of window
			NULL,										 // parent window (litestep wharf window)
			NULL,                                        // no menu
			hInstance,                                   // hInstance of DLL
			0);                                          // no window creation data
		
		if (!hNTPWnd)
		{
			MessageBox(NULL, "Unable to create NTP system window", msgTitle, MB_ICONHAND);
			return closeup();
		}
		
	}
	
	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); // set our user data to a "this" pointer
	
	// create our doublebuffer
	pDC = GetDC(parent);
	memDC = CreateCompatibleDC(pDC);
	
	memBM = CreateCompatibleBitmap(pDC,64-wharfData.borderSize*2,64-wharfData.borderSize*2);
	oldBM = SelectObject(memDC,memBM);
	
	bmp_day = LoadLSImage("NeXTday.bmp", NULL);
	bmp_month = LoadLSImage("NeXTmonth.bmp", NULL);

	// bmp_day = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP1), IMAGE_BITMAP,	20, 42, LR_DEFAULTCOLOR);
	bmp_time = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP1), IMAGE_BITMAP, 122, 11, LR_DEFAULTCOLOR);
	// bmp_month = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP3), IMAGE_BITMAP, 22, 72, LR_DEFAULTCOLOR);
	bmp_date = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP2), IMAGE_BITMAP, 100, 17, LR_DEFAULTCOLOR);
	bmp_fond = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP3), IMAGE_BITMAP, 55, 18, LR_DEFAULTCOLOR);
	bmp_page = LoadImage(dllInst,MAKEINTRESOURCE(IDB_BITMAP4), IMAGE_BITMAP, 48, 48, LR_DEFAULTCOLOR);
	
	memDC_date = CreateCompatibleDC(pDC);
	memDC_day = CreateCompatibleDC(pDC);
	memDC_month = CreateCompatibleDC(pDC);
	memDC_time = CreateCompatibleDC(pDC);
	memDC_fond = CreateCompatibleDC(pDC);
	memDC_page = CreateCompatibleDC(pDC);
	
	ReleaseDC(parent, pDC);
	
	oday = SelectObject(memDC_day, bmp_day);
	odate = SelectObject(memDC_date, bmp_date);
	otime = SelectObject(memDC_time, bmp_time);
	omonth = SelectObject(memDC_month, bmp_month);
	ofond = SelectObject(memDC_fond, bmp_fond);
	opage = SelectObject(memDC_page, bmp_page);
	
	//SelectObject(memDC, GetStockObject(NULL_PEN));
	//Rectangle(memDC,0,0,65,65);
	//BitBlt(memDC, 0, 0, 64-wharfData.borderSize*2, wharfData.borderSize*2, GetDC(parent), wharfData.borderSize, wharfData.borderSize, SRCCOPY);
	//SelectObject(memDC, GetStockObject(BLACK_PEN));
	
	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);
	
	if (pollfrequency) SetTimer(hMainWnd, 1, pollfrequency*MINUTE, NULL); 
	
	return 0;
}

//--------------------------------------------------------------------------------------------------

// cleanup (opposite of init()). Destroys the window, unregisters the window class
__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst/*struct winampVisModule *this_mod*/)
{
	HKEY key;
	DWORD status;
	//config_write(this_mod);		// write configuration
	DestroyMenu(popup);
	
	if (pollfrequency) KillTimer(hMainWnd, 1);
	KillTimer(hMainWnd, Timer);
	KillTimer(hNTPWnd, 0);
	
	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Aegis\\LiteSTEP\\Modules\\LSClock\\NTPClient", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &status) == ERROR_SUCCESS)
	{
		RegSetValueEx(key, "Server", 0, REG_SZ, hostname, strlen(hostname));
		RegSetValueEx(key, "ServerPort", 0, REG_DWORD, (char*)&hostport, 4);
		RegSetValueEx(key, "MaxDerivation", 0, REG_DWORD, (char*)&maxderivation, 4);
		RegSetValueEx(key, "PollFrequency", 0, REG_DWORD, (char *)&pollfrequency, 4);
		RegSetValueEx(key, "WarnOnAboveDelta", 0, REG_DWORD, (char *)&warnonmax, 4);
		RegSetValueEx(key, "NotifyOnSetTime", 0, REG_DWORD, (char *)&notifyset, 4);
		RegCloseKey(key);
	}
	
	SelectObject(memDC,oldBM);	// delete our doublebuffer
	DeleteObject(memDC);
	DeleteObject(memBM);	
	
	SelectObject(memDC_date,odate);	// delete our doublebuffer
	DeleteObject(memDC_date);
	DeleteObject(bmp_date);	
	SelectObject(memDC_time,otime);	// delete our doublebuffer
	DeleteObject(memDC_time);
	DeleteObject(bmp_time);	
	SelectObject(memDC_month,omonth);	// delete our doublebuffer
	DeleteObject(memDC_month);
	DeleteObject(bmp_month);	
	SelectObject(memDC_day,oday);	// delete our doublebuffer
	DeleteObject(memDC_day);
	DeleteObject(bmp_day);	
	SelectObject(memDC_fond,ofond);	// delete our doublebuffer
	DeleteObject(memDC_fond);
	DeleteObject(bmp_fond);	
	SelectObject(memDC_page,opage);	// delete our doublebuffer
	DeleteObject(memDC_page);
	DeleteObject(bmp_page);	
	
	/*	DeleteObject(ico);	
	DeleteObject(cadre);	*/
	
	DestroyWindow(hMainWnd); // delete our window
	UnregisterClass(szAppName,dllInst/*this_mod->hDllInstance*/); // unregister window class
	
	DestroyWindow(hNTPWnd);
	UnregisterClass(szNTPAppName, hInstance);
	
	if (wsainit)
		WSACleanup(); 
}

//----------------------------------------------------------------------------------------------------
BOOL CALLBACK DlgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_COMMAND:
		if (HIWORD(wParam) == BN_CLICKED)
		{
			switch (LOWORD(wParam))
			{
			case IDOK:
				{
					BOOL a;
					GetDlgItemText(hwndDlg, IDC_NTPSERVER, hostname, 255);
					hostport = GetDlgItemInt(hwndDlg, IDC_NTPPORT, &a, TRUE);
					maxderivation = GetDlgItemInt(hwndDlg, IDC_NTPMAX, &a, TRUE);
					pollfrequency = GetDlgItemInt(hwndDlg, IDC_NTPPOLL, &a, FALSE);
					warnonmax = IsDlgButtonChecked(NTPSetup, IDC_WARNCHECK);
					notifyset = IsDlgButtonChecked(NTPSetup, IDC_NOTIFYSET);
					if (pollfrequency && !lockNTPtimer) SetTimer(hMainWnd, 1, pollfrequency*MINUTE, NULL); 
					SendMessage(hMainWnd, WM_USER+2, 0, 0);
					break;
				}
			case IDCANCEL:
				SendMessage(hMainWnd, WM_USER+2, 0, 0);
				break;
			}
		}
		return TRUE;
	}
	return FALSE;//DefDlgProc(hwndDlg, uMsg, wParam, lParam);
}

//----------------------------------------------------------------------------------------------------
// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	HDC dp;
	
	switch (message)
	{
	case WM_CREATE:		return 0;
	case WM_ERASEBKGND: return 0;
	case WM_PAINT:
		{ // update from doublebuffer
			PAINTSTRUCT ps;
			RECT r;
			HDC hdc = BeginPaint(hwnd,&ps);
			GetClientRect(hwnd,&r);
			if (!backInit)
			{
				backInit = TRUE;
				Timer = SetTimer(hMainWnd, 0, 1000, NULL);
				dp = GetDC(parent);
				//BitBlt(memDC, 0, 0, r.right, r.bottom, dp, wharfData.borderSize, wharfData.borderSize, SRCCOPY);
				ReleaseDC(parent, dp);
				createClock();
			}
			TransparentBltLS(hdc, 1-wharfData.borderSize, 1-wharfData.borderSize, r.right, r.bottom, memDC, 0, 0, RGB(0xFF, 0x00, 0xFF));
			EndPaint(hwnd,&ps);
		}
		return 0;
		//case WM_DEST	ROY: PostQuitMessage(0); return 0;
	case WM_KEYDOWN: // pass keyboard messages to main winamp window (for processing)
	case WM_KEYUP:
		{	// get this_mod from our window's user data
			//				winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hwnd,GWL_USERDATA);
			PostMessage(parent,message,wParam,lParam);
		}
		return 0;
	case WM_RBUTTONUP:
		{
			RECT r;
			GetWindowRect(hwnd, &r);
			PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
		}
		return 0;
	case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			return 0;
		}
	case WM_LBUTTONDOWN:
	case WM_MBUTTONDOWN:
		PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
		return 0;
	case WM_TIMER:
		switch (wParam)
		{
		case 0:
			{
				RECT r;
				GetClientRect(hwnd,&r);
				createClock();
				InvalidateRect(hwnd, &r, FALSE);
			}
			break;
		case 1:
			SendMessage(hMainWnd, WM_COMMAND, 102, 0);
			break;
		}
		return 0;
		case WM_LBUTTONDBLCLK:
			{
				char winDir[128];
				GetSystemDirectory(winDir, 128);
				ShellExecute(hwnd, "open", "rundll32.exe", "shell32.dll,Control_RunDLL timedate.cpl", winDir, SW_SHOWNORMAL);
			}
			return 0;
		case WM_COMMAND:
			switch(wParam)
			{
			case 100:
				{
					char winDir[128];
					GetSystemDirectory(winDir, 128);
					ShellExecute(hwnd, "open", "rundll32.exe", "shell32.dll,Control_RunDLL timedate.cpl", winDir, SW_SHOWNORMAL);
					break;
				}
			case 101:
				// NTP Setup;
				NTPSetup=CreateDialog(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), parent, DlgProc);
				SetDlgItemText(NTPSetup, IDC_NTPSERVER, hostname);
				SetDlgItemText(NTPSetup, IDC_HINT, "Get a list of servers at: \r\nhttp://www.eecis.udel.edu/~mills/ntp/servers.html\r\nBe sure to read the policy before connecting to a NTP server!");
				SetDlgItemInt(NTPSetup, IDC_NTPPORT, hostport, FALSE);
				SetDlgItemInt(NTPSetup, IDC_NTPMAX, maxderivation, FALSE);
				SetDlgItemInt(NTPSetup, IDC_NTPPOLL, pollfrequency, FALSE);
				CheckDlgButton(NTPSetup, IDC_WARNCHECK, warnonmax);
				CheckDlgButton(NTPSetup, IDC_NOTIFYSET, notifyset);
				ShowWindow(NTPSetup, SW_NORMAL);
				break;
			case 102:
				{
					int thread;
					if (pollfrequency) KillTimer(hMainWnd, 1);
					CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)do_ntp, (LPVOID)hwnd, 0, &thread);
				}
				break;
			}
			return 0;
			case WM_USER+1: // close ntp main
				closeup();
				return 0;
			case WM_USER+2: // close ntp setup
				DestroyWindow(NTPSetup);
				return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}


//-------------------------------------------------------------------------------------------------
void createClock(void)
{
	char buffer[10];
	int x;
	char *p;
	int am=1; 
	int pflag=0;
	int y;
	SYSTEMTIME st; 
	int sh=usformat?1:9;

	HBRUSH GPBrush = CreateSolidBrush(RGB(0xFF, 0x00, 0xFF));
	RECT Rect = {0, 0, 64, 64};
	
	if (!backInit) return;

	
	//DrawIconEx(memDC, 10,16,ico,48,48,0,NULL,DI_NORMAL);
	//DrawIconEx(memDC, 4,2,cadre,55,18,0,NULL,DI_NORMAL);
	
	FillRect(memDC, &Rect, GPBrush);

	DeleteObject(GPBrush);

	TransparentBltLS(memDC, 8, 17, 48, 48, memDC_page, 0, 0, RGB(0xFF, 0x00, 0xFF));
	BitBlt(memDC, 3, 3, 58, 21, memDC_fond, 0, 0, SRCCOPY);
	
	GetLocalTime(&st);
	
	if (usformat && st.wHour >= 12)
		am=0;
	
	if (usformat && st.wHour > 12)
		st.wHour-=12;
	
	if ((float)st.wSecond /2 == st.wSecond /2)
		pflag=1;
	
	if (usformat && st.wHour == 0)
		st.wHour = 12;
	
	sprintf(buffer, "%2d:%02d", st.wHour, st.wMinute);
	
	p = buffer;
	x=0;
	for (x=0;x<5;x++)
	{
		switch (*p)
		{
		case ' ':
			p++;
			continue;
		case ':':
			if (pflag)
				BitBlt(memDC, sh+x*9-(x > 2 ? 6 : 0), 6, 4, 11, memDC_time, 10 * 9, 0, SRCCOPY);
			break;
		default:
			if ((x == 0) && usformat)
				BitBlt(memDC, sh+x*9-(x > 2 ? 6 : 0) + 4, 6, 9 - 4, 11, memDC_time, (*p - '0') * 9 + 4, 0, SRCCOPY);
			else
				BitBlt(memDC, sh+x*9-(x > 2 ? 6 : 0), 6, 9, 11, memDC_time, (*p - '0') * 9, 0, SRCCOPY);
			break;
		}
		p++;
	}  
	
	if (usformat)
		if (am)
			BitBlt(memDC, 2+4*9+4, 6, 12, 11, memDC_time, 10*9+6, 0, SRCCOPY);
		else
			BitBlt(memDC, 2+4*9+4, 6, 12, 11, memDC_time, 10*9+6+14, 0, SRCCOPY);
		
		
	st.wDayOfWeek--;
	if (st.wDayOfWeek == 65535) st.wDayOfWeek = 6;
	
	BitBlt(memDC, 20, 23, 20, 6, memDC_day, 0, 6*st.wDayOfWeek, SRCCOPY);
	BitBlt(memDC, 18, 48, 22, 6, memDC_month, 0, 6*(st.wMonth-1), SRCCOPY);
	
	
	sprintf(buffer, "%d", st.wDay);
	
	p = buffer;
	y = 24 - ((strlen(buffer) > 1)? 5 : 0);
	x=0;
	for (x=0;x<2 && *p;x++)
	{
		BitBlt(memDC, y + x * 11, 31, 10, 17, memDC_date, (*p - '0') * 10, 0, SRCCOPY);
		p++;
	}
	
	if (st.wDay == 1 && st.wMonth == 1 && st.wYear == 2000 && st.wHour == 0 && st.wMinute == 0 && st.wSecond == 0)
		MessageBox(NULL, "LiteSTEP wishes you a HAPPY new year, century and millenium!", "LiteStep", 0);
	
}

//--------------------------------------------------------------------------------------------------
int JulianDayNumber(WORD wYear, WORD wMonth, WORD wDay)
{
	long int y = (long int)wYear;
	long int d = (long int)wDay;
	long int m = (long int)wMonth;
	long int c;
	long int ya;
	long int j;
	
	if (m > 2)
	{
		m = m - 3;
	} 
	else 
	{
		m = m + 9;
		y = y - 1;
	}
	c = y / 100;
	ya = y - 100 * c;
	j = (146097L * c) / 4 + (1461L * ya) / 4 + (153L * m + 2) / 5 + d + 1721119L;
	return j;
}

//--------------------------------------------------------------------------------------------------
void GregorianDate(long julian_time, WORD *wYear, WORD *wMonth, WORD *wDay)
{
	long j = julian_time - 1721119;
	long y = (4 * j - 1) / 146097;
	long d;
	long m;
	
	j = 4 * j - 1 - 146097 * y;
	d = j / 4;
	j = (4 * d + 3) / 1461;
	d = 4 * d + 3 - 1461 * j;
	d = (d + 4) / 4;
	m = (5 * d - 3) / 153;
	d = 5 * d - 3 - 153 * m;
	d = (d + 5) / 5;
	y = 100 * y + j;
	if (m < 10) {
		m = m + 3;
	} else {
		m = m - 9;
		y = y + 1;
	}
	*wYear = (WORD)y;
	*wMonth = (WORD)m;
	*wDay = (WORD)d;
}

#define P1 ((double)2.0)
#define P2 (P1*P1)
#define P4 (P2*P2)
#define P8 (P4*P4)
#define P16 (P8*P8)
#define P32 (P16*P16)
#define CVT (((double)1000.0)/P32)

//--------------------------------------------------------------------------------------------------
void ConvertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time)
{
	unsigned long ip = int1;
	long int j;
	
	// Get seconds
	sys_time->wSecond = (WORD)(ip % 60L);
	ip /= 60L;
	
	// Get minutes
	sys_time->wMinute = (WORD)(ip % 60L);
	ip /= 60L;
	
	// Get hours
	sys_time->wHour = (WORD)(ip % 24L);
	ip /= 24L;
	
	// Convert to julian day number
	j = ((long int)ip) + JAN_1_1900;
	
	// Get weekday info
	sys_time->wDayOfWeek = (WORD)((j + 1) % 7L);
	
	// Get month, day, year
	GregorianDate(j, &sys_time->wYear, &sys_time->wMonth, &sys_time->wDay);
	
	// convert fraction to milliseconds
	sys_time->wMilliseconds = (WORD)((((double)frac1) * CVT) + 0.5);
}

//--------------------------------------------------------------------------------------------------

void ConvertTimeToFixed(SYSTEMTIME sys_time, unsigned int *integer, unsigned int *fractional)
{
	long int j;
	
	// First compute the (astronomical) julian day number
	j = JulianDayNumber(sys_time.wYear, sys_time.wMonth, sys_time.wDay);
	
	// Convert to NTP days
	j -= JAN_1_1900;
	
	// Hours
	j = (j * 24L) + (long int)sys_time.wHour;
	
	// Minutes
	j = (j * 60L) + (long int)sys_time.wMinute;
	
	// Seconds
	j = (j * 60L) + (long int)sys_time.wSecond;
	
	*integer = (unsigned long)j;
	*fractional = ntpfracTable[sys_time.wMilliseconds];
	
}


//--------------------------------------------------------------------------------------------------
int do_ntp(void)
{
	WORD wVersionRequested; 
	SYSTEMTIME now;
	WSADATA wsaData; 
	struct in_addr addr;
	struct sockaddr_in myaddr;
	struct sockaddr_in _addr;
	int err; 
	int on = 1;
	unsigned int integer, fractional;
	struct hostent *host;
	static int badsocket=0;
	
	lockNTPtimer=1;
	
	if (!wsainit)
	{
		wVersionRequested = MAKEWORD(1, 1); 
		memset(&wsaData, 0, sizeof(wsaData));
		err = WSAStartup(wVersionRequested, &wsaData); 
		
		if (err != 0) 						 
		{
			MessageBox(NULL, "Enable to start windows sockets", msgTitle, MB_ICONHAND);
			return closeup();
		}
		
		wsainit=1;
		if ( LOBYTE( wsaData.wVersion ) != 1 || 
			HIBYTE( wsaData.wVersion ) != 1 ) { 
			badsocket=1;
			MessageBox(NULL, "Incompatible Windows Socket version", msgTitle, MB_ICONHAND);
			return closeup();
		}
	}
	
	if (badsocket) return 0;
	
	mysocket = socket(PF_INET, SOCK_DGRAM, 0);
	memset((void *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons((u_short)hostport);
	
	socketinit=1;
	
	host = gethostbyname (hostname);
	if (host == NULL)
	{
		addr.s_addr = inet_addr (hostname);
		if (addr.s_addr == -1)
		{
			MessageBox(NULL, "Unknown remote host", msgTitle, MB_ICONHAND);
			return closeup();
		}
	}
	else
		memcpy((char *) &addr, host->h_addr, host->h_length);
	
	//addr.s_addr = inet_addr("10.0.1.64");
	myaddr.sin_addr = addr;
	
	memset((char *)&_addr, 0, sizeof(_addr));
	_addr.sin_family = AF_INET;
	_addr.sin_port = htons((u_short)hostport);
	_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(mysocket, (struct sockaddr *)&_addr, sizeof(_addr)) == SOCKET_ERROR) 
		return socketError(0);
	
	WSAAsyncSelect(mysocket, hNTPWnd, WM_USER+1, FD_READ);
	
	bits.li = 3;
	bits.vn = 2;
	bits.mode = 0;
	bits.stratum = 0;
	bits.poll = 0;
	bits.precision = 0;
	
	memcpy(&databits, &bits, sizeof(databits));
	
	rootdelay = 0;
	rootdispersion = 0;
	referenceidentifier = 0;
	referencetimestamp_hi = 0;
	referencetimestamp_lo = 0;
	originatetimestamp_hi = 0;
	originatetimestamp_lo = 0;
	receivetimestamp_hi = 0;
	receivetimestamp_lo = 0;
	
	GetSystemTime(&now);
	
	ConvertTimeToFixed(now, &integer, &fractional);
	transmittimestamp_hi = integer;
	transmittimestamp_lo = fractional;
	
	//databits = htonl(databits);
	rootdelay = htonl(rootdelay);
	rootdispersion = htonl(rootdispersion);
	referenceidentifier = htonl(referenceidentifier);
	referencetimestamp_hi = htonl(referencetimestamp_hi);
	referencetimestamp_lo = htonl(referencetimestamp_lo);
	originatetimestamp_hi = htonl(originatetimestamp_hi);
	originatetimestamp_lo = htonl(originatetimestamp_lo);
	receivetimestamp_hi = htonl(receivetimestamp_hi);
	receivetimestamp_lo = htonl(receivetimestamp_lo);
	transmittimestamp_hi = htonl(transmittimestamp_hi);
	transmittimestamp_lo = htonl(transmittimestamp_lo);
	
	memcpy(xferdata, &databits, sizeof(databits));
	memcpy(xferdata+4, &rootdelay, sizeof(rootdelay));
	memcpy(xferdata+8, &rootdispersion, sizeof(rootdispersion));
	memcpy(xferdata+12, &referenceidentifier, sizeof(referenceidentifier));
	memcpy(xferdata+16, &referencetimestamp_hi, sizeof(referencetimestamp_hi));
	memcpy(xferdata+20, &referencetimestamp_lo, sizeof(referencetimestamp_lo));
	memcpy(xferdata+24, &originatetimestamp_hi, sizeof(originatetimestamp_hi));
	memcpy(xferdata+28, &originatetimestamp_lo, sizeof(originatetimestamp_lo));
	memcpy(xferdata+32, &receivetimestamp_hi, sizeof(receivetimestamp_hi));
	memcpy(xferdata+36, &receivetimestamp_lo, sizeof(receivetimestamp_lo));
	memcpy(xferdata+40, &transmittimestamp_hi, sizeof(transmittimestamp_hi));
	memcpy(xferdata+44, &transmittimestamp_lo, sizeof(transmittimestamp_lo));
	
	
	if (sendto(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
		(struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR) 
		return socketError(0);
	
	SetTimer(hNTPWnd, 0, 20000, NULL);
	ExitThread(0);
}

//--------------------------------------------------------------------------------------------------
LRESULT CALLBACK NTPWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_USER+1:
		{
			struct sockaddr_in gotfrom;
			SYSTEMTIME now;
			int gotlen = sizeof(gotfrom);
			
			if (recvfrom(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
				(struct sockaddr *)&gotfrom, &gotlen) != SOCKET_ERROR)
			{
				GetSystemTime(&now);
				translatePacket(now);
			}
			else
				socketError(1);
			
			KillTimer(hNTPWnd, 0);
			PostMessage(hMainWnd, WM_USER+1, 0, 0);
		}
		return 0;
	case WM_TIMER: // Timeout;
		{
			KillTimer(hNTPWnd, 0);
			MessageBox(NULL, "Timeout occured while waiting for NTP reply", msgTitle, MB_ICONHAND);
			PostMessage(hMainWnd, WM_USER+1, 0, 0);
		}
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

//--------------------------------------------------------------------------------------------------
void translatePacket(SYSTEMTIME received)
{
	SYSTEMTIME now;
	unsigned int originatetimestamp_integer, originatetimestamp_fractional;
	unsigned int receivetimestamp_integer, receivetimestamp_fractional;
	unsigned int transmittimestamp_integer, transmittimestamp_fractional;
	unsigned int received_integer, received_fractional;
	
	unsigned int ti1, tf1, ti2, tf2, ti3, tf3;
	unsigned int d_i, d_f;
	unsigned int t_i, t_f;
	unsigned int i1, f1;
	
	memcpy(xferdata, &databits, sizeof(databits));
	memcpy(&rootdelay, xferdata+4, sizeof(rootdelay));
	memcpy(&rootdispersion, xferdata+8, sizeof(rootdispersion));
	memcpy(&referenceidentifier, xferdata+12, sizeof(referenceidentifier));
	memcpy(&referencetimestamp_hi, xferdata+16, sizeof(referencetimestamp_hi));
	memcpy(&referencetimestamp_lo, xferdata+20, sizeof(referencetimestamp_lo));
	memcpy(&originatetimestamp_hi, xferdata+24, sizeof(originatetimestamp_hi));
	memcpy(&originatetimestamp_lo, xferdata+28, sizeof(originatetimestamp_lo));
	memcpy(&receivetimestamp_hi, xferdata+32, sizeof(receivetimestamp_hi));
	memcpy(&receivetimestamp_lo, xferdata+36, sizeof(receivetimestamp_lo));
	memcpy(&transmittimestamp_hi, xferdata+40, sizeof(transmittimestamp_hi));
	memcpy(&transmittimestamp_lo, xferdata+44, sizeof(transmittimestamp_lo));
	
	originatetimestamp_integer = ntohl(originatetimestamp_hi);
	originatetimestamp_fractional = ntohl(originatetimestamp_lo);
	receivetimestamp_integer = ntohl(receivetimestamp_hi);
	receivetimestamp_fractional = ntohl(receivetimestamp_lo);
	transmittimestamp_integer = ntohl(transmittimestamp_hi);
	transmittimestamp_fractional = ntohl(transmittimestamp_lo);
	
	ConvertTimeToFixed(received, &received_integer, &received_fractional);
	
	ntp64_moins(received_integer, received_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
	ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, transmittimestamp_integer, transmittimestamp_fractional, &ti2, &tf2);
	
	ntp64_moins(ti1, tf1, ti2, tf2, &d_i, &d_f);
	
	ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
	ntp64_moins(transmittimestamp_integer, transmittimestamp_fractional, received_integer, received_fractional, &ti2, &tf2);
	ntp64_plus(ti1, tf1, ti2, tf2, &ti3, &tf3);
	ntp64_sdiv2(ti3, tf3, &t_i, &t_f);
	
	if (maxderivation)
	{
		if (t_i & 0x80000000)
			ntp64_umoins(t_i, t_f, &i1, &f1);
		else
		{ i1 = t_i; f1 = t_f; }
		if (i1 > (unsigned)maxderivation && warnonmax)
		{
			char txt[256];
			sprintf(txt, "Server time over maximum derivation (%d seconds). Check your timezone settings.\nClock was not set.", i1);
			MessageBox(NULL, txt, "Warning", MB_ICONWARNING);
			closeup();
			return;
		}
	}
	
	GetSystemTime(&now);
	ConvertTimeToFixed(now, &ti1, &tf1);
	
	ntp64_plus(ti1, tf1, t_i, t_f, &ti2, &tf2);
	
	ConvertToSYSTEMTIME(ti2, tf2, &now);
	
	EnablePriviledge();
	
	SetSystemTime(&now);
	
	DisablePriviledge();
	
	if (notifyset)
		MessageBox(NULL, "Time set!", msgTitle, MB_ICONINFORMATION);
	
}

//--------------------------------------------------------------------------------------------------
void ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
								unsigned int *resi, unsigned int *resf)
{
	unsigned long lo16 = (frac1 & 0xffff) + (frac2 & 0xffff);
	unsigned long hi16 = (frac1 >> 16) + (frac2 >> 16) + (lo16 >> 16);
	
	*resi = int1 + int2 + (hi16 >> 16);
	*resf = (hi16 << 16) | (lo16 & 0xffff);
}

//--------------------------------------------------------------------------------------------------
void ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
								 unsigned int *resi, unsigned int *resf)
{
	unsigned int i1, f1;
	ntp64_umoins(int2, frac2, &i1, &f1);
	ntp64_plus(int1, frac1, i1, f1, resi, resf);
}

//--------------------------------------------------------------------------------------------------
void ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	ntp64_plus(~int1, ~frac1, 0, 1, resi, resf);
}

//--------------------------------------------------------------------------------------------------
void ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	unsigned int i1, f1, i2, f2;
	
	if (int1 & 0x80000000)
	{
		ntp64_umoins(int1, frac1, &i1, &f1);
		ntp64_div2(i1, f1, &i2, &f2);
		ntp64_umoins(i2, f2, resi, resf);
	}	else
		ntp64_div2(int1, frac1, resi, resf);
}

//--------------------------------------------------------------------------------------------------
void ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	*resf = ((frac1 >> 1) | (int1 << 31));
	*resi = int1 >> 1;
}

//--------------------------------------------------------------------------------------------------
int closeup(void)
{
	if (socketinit)
		closesocket(mysocket);
	
	if (pollfrequency) SetTimer(hMainWnd, 1, pollfrequency*MINUTE, NULL); 
	lockNTPtimer=0;
	return 0;
}

//--------------------------------------------------------------------------------------------------
int socketError(int dontquit)
{
	char *p;
	char txt[256];
	int err = WSAGetLastError();
	switch (err)
	{
	case WSANOTINITIALISED:	
		p = "Sockets not iniatilized";
		break;
	case WSAENETDOWN:
		p = "Network subsystem has failed";
		break;
	case WSAEADDRINUSE:
		p = "Specified address already in use";
		break;
	case WSAEINTR:
		p = "Blocking call was canceled";
		break;
	case WSAEINPROGRESS:
		p = "Blocking call is in progress";
		break;
	case WSAEADDRNOTAVAIL:
		p = "The specified address is not available";
		break;
	case WSAEAFNOSUPPORT:
		p = "Addresses in the specified family cannot be used with this socket";
		break;
	case WSAECONNREFUSED:
		p = "Connection refused";
		break;
	case WSAEINVAL:
		p = "Unbound socket";
		break;
	case WSAEISCONN:
		p = "Socket already connected";
		break;
	case WSAENETUNREACH:
		p = "Network not reachable";
		break;
	case WSAETIMEDOUT:
		p = "Connetion timed out";
		break;
	default: 
		sprintf(txt, "Unknown winsock or internal error (error code = %d)", err);
		p = txt;
		break;
	}
	MessageBox(NULL, p, msgTitle, MB_ICONHAND);
	if (!dontquit) closeup();
	return 0;
}

//--------------------------------------------------------------------------------------------------
void EnablePriviledge(void)
{
	BOOL opt_ok = OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
		&tok_handle);
	if (! opt_ok) {
		if (GetLastError() == ERROR_CALL_NOT_IMPLEMENTED) {
			SetLastError(ERROR_SUCCESS);
			priv_modified=0;
			return;
		}
		//      throw ErrnoException("OpenProcessToken");
	}
	memset((void *)&tok_priv, 0, sizeof(tok_priv));
	LookupPrivilegeValue(NULL, SE_SYSTEMTIME_NAME,
		&tok_priv.Privileges[0].Luid);
	tok_priv.PrivilegeCount = 1;
	tok_priv.Privileges[0].Attributes |= SE_PRIVILEGE_ENABLED;
	AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
	/*if (GetLastError() != ERROR_SUCCESS) {
	throw ErrnoException("AdjustTokenPrivileges");*/
	priv_modified=1;
}

//--------------------------------------------------------------------------------------------------
void DisablePriviledge(void)
{
	if (priv_modified)
	{
		tok_priv.Privileges[0].Attributes &= (~ SE_PRIVILEGE_ENABLED);
		AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
	}
}
