//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lsclock.rc
//
//#define IDI_ICON1                       108
//#define IDI_ICON2                       114
#define IDB_BITMAP1                     115
#define IDB_BITMAP2                     116
#define IDB_BITMAP3                     117
#define IDB_BITMAP4                     121
#define IDD_DIALOG1                     122
//#define IDI_ICON3                       123
#define IDB_BITMAP5                     125
#define IDB_BITMAP6                     126
#define IDC_NTPSERVER                   1000
#define IDC_NTPPORT                     1002
#define IDC_NTPMAX                      1004
#define IDC_NTPPOLL                     1005
#define IDC_WARNCHECK                   1006
#define IDC_NOTIFYSET                   1008
#define IDC_HINT                        1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        128
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
