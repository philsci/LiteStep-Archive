Commands:

; Boolean to turn on the SDAx commands
SetDeskTopArea

; These can all except negative values.
SDALeft n
SDARight n
SDATop n
SDABottom n

; These work with any !bang command, except they don't take parameters. Use !None to disable
DeskMButton1 !bang
DeskMButton2 !bang
DeskMButton3 !bang

Send all comments, suggestions, bugs, praise to jugg@dylern.com
http://aster.omega2.com/jugg/