LSDrive v1b
webba
LiteStep Wharf Module


Hi. LSdrive is somewhat finished. I think so, at least. It seems to work nicely
on Windows 98 and NT, albiet through limited beta testing (1 other person). 
Please report any bugs to me, preferably on IRC, or via email if you're one of
those weird non-IRC people.

The concept is pretty simple. Up to nine drives on a wharf module. Single click
opens the drive. Easy? Yes. One thing, however, the default Pics *MUST* be in 
the images dir (This is set with the PixmapPath step.rc entry, for those of you
who may not know) or you must put the full path to your pics in modules.ini.


Modules.ini entries
-------------------
[LSDrive]		;header
Draw_Text=0 		;This tells lsdrive if you want to have the letter of 
			  the drive overtop of the pic. 0 = no, 1 = yes

Font_Color=0xFFFFFF 	;Color of the text..

Floppy_Pix="c:\litestep\lsdflop.bmp"	;full path of floppy drive pic
HardDrive_Pix="c:\litestep\lsdhdd.bmp"	;full path of HDD pic
NetDrive_Pix="c:\litestep\lsdnet.bmp"	;full path of Network drive pic
CDROM_Pix="c:\litestep\lsdcdr.bmp"	;full path of cdrom pic
RemovableDrive_Pix="c:\litestep\lsdremove.bmp"	;full path of removable drive 
						  pic
RAMDrive_Pix="c:\litestep\lsdram.bmp"	;full path of RAM drive pic