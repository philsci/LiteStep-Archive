----------------------------------------------------------------
hotspots.dll   v0.53                               June 29, 2000
----------------------------------------------------------------
Pavel Vitis



What the hell is "hotspots.dll"?
================================================================

With Hotspots you can define transparent rectangular areas on 
the screen called "hotspots". You will get ability to trigger 
events (execute programs or !bangs) on mouse over, or on mouse 
click. You can also attach different cursor shape to each hotspot.

I programmed this to simulate "active borders", nice feature
included in Pointix (Pop-Mouse) utility by Pointix Company
(http://www.pointix.com/). That was the original idea. Anyway
there is much more ways using this module. You can define 
hot-corners, toggle visibility of shortcut groups on mouse move,
change cursor shape in defined screen-areas, etc...


What's new
================================================================

v0.53 / June 29, 2000
	* bugfix: action_out was not properly disabled when "D"
	  flag used
	+ Added 'O' (OneInstance) flag
	+ Added experimental feature - Hotspots are disabled 
	  when any application is running fullscreen. It should
	  prevent conflicts with some games

_____ / June 28, 2000
	* Updated readme
	+ Added sample .rc file HOTSPOTS.RC

v0.52 / June 24, 2000
	+ Added 'P' flag
	+ Added ability to load custom mouse-over cursors from
	  file (.CUR, .ANI), added HotSpotCursorDir variable
	+ Added 18 new click+shiftkey actions
	+ Some sample cursors

v0.51 / June 23, 2000
	* Hotspots click-through bug now *should* be fixed. 
	  Hotspots weren't transparent for mouse-clicks in 
	  previous beta version.
	  Try it and let me know.

v0.51 beta / March 1, 2000
	+ Added !HotspotsToggle bang (To toggle single hotspot,
	  use !HotspotUpdate "Name" "D")
	+ Added six mouse-click actions: action_lb, action_rb,
	  action_mb, action_lbd, action_rbd, action_mbd
	+ Custom cursor change on hotspot mouse-over
	! Hotspots do not pass mouseclick to underlaying windows.
	  It might be a big problem for some sort of use. Please
	  take this into account and do not use this version if it
	  is problem for you.
	+ New LitestepGoodies mirror at http://lsg.come.to/

v0.5 / February 5, 2000
	* Hotspots under WinNT with no limitations. Key modifiers
	  now works here.
	* Fixed bug: Unable to disable hotspots
	* Flags are now "toggle" based
	+ New flag "0" - clear all previously set flags

v0.4a / January 24, 2000
	* Hotspots tested under WinNT, removed key-modifiers
	  actions in WinNT/2K.

v0.4 / November 10, 1999
	* Fixed bug that caused crashes on WinNT (timerproc)
	+ Hotspots are automatically disabled when screensaver is
	  running
	+ Hotspots.dll now returns RevisionID string
	+ Added some items into to-do list

v0.3 / September 26, 1999
	* Optimizations
	* Format of hotspot definition slightly changed
	+ Added separate actions for Ctrl/Shift/Alt key modifiers
	+ Added mouse-out action

v0.2 / September 07, 1999
	* Fixed some ugly bugs
	* Fixed some minor bugs
	* Some internal optimizations
	+ Coordinates can be negative values
	+ Sizes can be zero - they are recalculated to maximum
	+ Option to start hotspots disabled
	+ Added params to hotspots
	+ Added !HotspotsEnable
	+ Added !HotspotsDisable
	+ Added !HotspotUpdate

v0.1 / September 06, 1999
	+ First release, very raw



Installation
================================================================

(1) Installation is simple. Load the module in your step.rc:

LoadModule "c:\litestep\hotspots.dll"

Copy hotspots.dll directly into your Litestep directory.



(2) Then edit your step.rc and define some hotspots.
The syntax is:

*Hotspot Name Flags Cursor X-position Y-position Width Height [Delay In-Action]

-  "Name" is the unique identifier of the hotspot. Use some
descriptive name here. Multiple hotspots can share same name.
This name is used to identify the hotspots in further operations.

- "Flags" is string of additional flags:

  S - Silent mode - this hotspot doesn't beep
  D - Disabled mode - this hotspot is initially disabled
  X - Start application maximized
  M - Start application minimized
  P - Pass mouse-click events to underlaying window even when 
      click-action is set. 
  O - One Instance - Run application only once. If already 
      running - just activate its window
  0 - (zero) clear all previously set flags

Any specified flag toggles its previous state.

- "Cursor" defines custom mouse-over cursor
It is full path to .ANI or .CUR cursor file, or any of predefined
names:

  0             (zero) clear previously defined cursor
  APPSTARTING   Standard arrow and small hourglass
  ARROW         Standard arrow
  CROSS         Crosshair
  IBEAM         Text I-beam
  NO            Slashed circle
  SIZE          Windows NT only: Four-pointed arrow
  SIZEALL       Same as IDC_SIZE
  SIZENESW      Double-pointed arrow pointing northeast and southwest
  SIZENS        Double-pointed arrow pointing north and south
  SIZENWSE      Double-pointed arrow pointing northwest and southeast
  SIZEWE        Double-pointed arrow pointing west and east
  UPARROW       Vertical arrow
  WAIT          Hourglass
  HAND          Hand (hyperlink pointer)

There are some sample cursors included in cursor directory. 
I suggest to copy them to Litestep\Cursors directory and
set path variable (do not forget to put "\" at the end):
  
  HotspotCursorDir "c:\litestep\cursors\"

-  Position is in pixels. You can use negative values.
-  Width, Height are in pixels. Zero value "0" means maximum
size (hotspot width/height reaches opposite screen border).

-  "Delay" is the time interval (in 1/10 sec) that defines how
long should mouse pointer stay in the hotspot area before
triggering associated action. It is here to avoid accidental
actions when working with mouse.
Delay should be in 0..10.

- "In-Action" can be any executable, file, or !bang command. If the
non-executable file is specified, it will activate application
associated to file-type, if any. This action will be executed when
mouse enters the hotspot area. This parameter is optional, you can
leave it off or add it later (same as other actions - see below) with
*HotspotUpdate command or !HotspotUpdate bang.


Note: "Delay" and "In-action" are optional. When not specified,
the hotspot does nothing, and it can be updated via bangs at
runtime.


(3) Update defined hotspots

Now you can add "out" action, add shift-modifier actions, or modify
flags:

*HotspotUpdate Name Flags Cursor [Action-type Action]

This command will update data of already defined hotspot.
"Action-type" can be one of following constants:

  action_in         Mouse in
  action_out        Mouse out
  action_shift      Mouse in + Shift key
  action_alt        Mouse in + Alt key
  action_ctrl       Mouse in + Ctrl key
  action_lb         Left button click
  action_rb         Right button click
  action_mb         Middle button click
  action_lbd        Left button double-click
  action_rbd        Right button double-click
  action_mbd        Middle button double-click

  action_shift_lb   Left button click + ShiftKey
  action_shift_rb   
  action_shift_mb

  action_alt_lb
  action_alt_rb
  action_alt_mb

  action_ctrl_lb
  action_ctrl_rb
  action_ctrl_mb

  action_shift_lbd  Left button double-click + ShiftKey
  action_shift_rbd
  action_shift_mbd

  action_alt_lbd
  action_alt_rbd
  action_alt_mbd

  action_ctrl_lbd
  action_ctrl_rbd
  action_ctrl_mbd

You can update just the flags, of course. Flag toggles previously
defined flag state.
This command exists also as !bang.

(4) You can also define sound that will play when action is triggered:

  HotspotBeep "path_to\beep.wav"


You can disable hotspots functionality at startup by specifying:

  HotspotsDisabled


And there are some !Bangs:

  !HotspotsEnable
  !HotspotsDisable
  !HotspotsToggle

Update hotstpot values:

  !HotspotUpdate Name Flags Cursor [Action-type Action]


For example:

Hotspot is defined as:

  *Hotspot LeftBar "" "" 0 0 4 0 10 notepad

then, to disable hotspot:
  !HotspotUpdate LeftBar D ""
to reenable and mute hotspot (toggle 'disable' flag):
  !HotspotUpdate LeftBar DS ""
to unmute hotspot (toggle 'silent' flag):
  !HotspotUpdate LeftBar S ""
to add shift-key action (leave flags as is):
  !HotspotUpdate LeftBar "" "" action_shift "notepad.exe"
to set mouse-over cursor
  !HotspotUpdate LeftBar "" IDC_HAND
to clear all previously set flags, set Maximize flag and clear cursor:
  !HotspotUpdate LeftBar 0X "0"
to setup left mouse button action - open display properties:
  !HotspotUpdate LeftBar "" "" action_lb control display.cpl

Example	step.rc entries:
================================================================

There I provide some example settings.
I define three active borders on the left, right and top of
the screen to run frequently used applications (substitute
yours). Next I define four hot corners, top-left to instantly
activate screen saver, top-right to disable screen saver,
bottom-left to shutdown windows and bottom-right to run step.rc
editor.
First two hotspots provide simple functionality of hiding
taskbar like in explorer. "HideTaskbar" is defined over whole
desktop area and will hide taskbar after the mouse leaves
taskbar	strip. Taskbar will be shown when touching bottom
edge of screen ("ShowTaskbar").	Use geekfunk.dll for taskbar
bangs. This cool tip was first introduced by Jorje from Modulo -
http://chunkymunky.com/modulo/.
You can use my scrsaver.dll for screen saver controlling bangs.


;===============================================================
; SAMPLE STEP.RC SECTION
;===============================================================

; SndDir variable is here to demonstrate using predefined path
SndDir c:\media\audio\

;HotspotsDisabled
HotspotBeep "$SndDir$tick.wav"
HotspotCursorDir "c:\litestep\cursors\"

; Change cursor on wharf
*Hotspot Wharf "" "open.cur" -64 0 0 0

; Hide/show taskbar
*Hotspot HTaskbar S "" 0 0 0 -20 10 !Hide_Taskbar
*Hotspot STaskbar S "" 0 -1 0 0 2 !Show_Taskbar

; Run programs
*Hotspot Left MS "" 0 2 2 0 4 notepad.exe
*Hotspot Right "" "" -2 2 0 0 4 calc.exe
*Hotspot Top "" "" 2 0 -2 2 10 explorer.exe

; Run screensaver
*Hotspot TopLeft S "zzz.cur" 0 0 2 2 8 !ScreenSaver
; Disable/enable screensaver
*Hotspot TopRight S "" -2 0 0 2 8 !ScreenSaverDisable
; Add mouse out-action to TopRight hotspot
*HotspotUpdate TopRight "" "" action_out !ScreenSaverEnable

*Hotspot BottomLeft "" "" 0 -2 2 0 10 !Popup
*Hotspot BottomRight "" "" -2 -2 0 0 10 "notepad c:\litestep\step.rc"

; Add mouse action and cursor to TICKER.DLL bar
*Hotspot Ticker "" "set_time.cur" 800 0 300 20
*HotspotUpdate Ticker "" "" action_lb control timedate.cpl

;===============================================================



Features, limitations
================================================================

If any of your hotspots will overlap, the control over overlapped
region takes hotspot that is defined later. They are defined
"from bottom to topmost".

You can define up to maximum of 50 hotspots.
"This should be enough for everyone..." ;)



Plans for future versions - TO-DO list
================================================================

1. Add ability to auto-disable hotspots when any app runs in
   fullscreen
   *** Added in 0.53 - experimental ***
2. Optional list of excluded apps (especially games running in
   fullscreen)
3. Rewrite this blahblah to html format to make it more readable.



Known bugs
================================================================

1. When mouse cursor leaves the hotspot too fast after triggering
in_action, the out_action does not execute. I have no idea... :-\
2. Activating hotspot steal focus to currently active litestep
child window 
  *** should be fixed in 0.51 ***
3. The hotspot isn't transparent for mouseclicks. 
  *** should be fixed in 0.51 ***.

Any suggestions will be welcome too, don't hesitate and email me.



Contact & additional info, resources
================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www   : http://floach.pimpin.net/pavel/
mirror: http://lsg.come.to/

Programmed in Delphi 4, using LSDevKit (modified TR3) by Murphy:
http://www.dev0.de/