#include <windows.h>
#include <stdio.h>
#include "resource.h"

// Function Prototypes
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
BOOL ModifyTrayIcon( HWND, UINT, UINT, DWORD, int );

int UpdateWindows();
int ChangeWindow(char from[256]);
int AddRuleFrom();
int AddRuleTo();
int DeleteRule();
int ListRules();

// Globals
HINSTANCE hinst; 
HWND hwndMain; 
HWND hwndList;
HWND hwndEdit;
HWND hwndRules;
HWND hwndRuleFrom;
HWND hwndRuleTo;
HWND hwndBAddRule;
HWND hwndBDeleteRule;
HWND hwndBViewRules;

DWORD MB = MB_OK | MB_SETFOREGROUND;
int BUSY=0;
char ini[MAX_PATH] = "titletext.ini";
char First[256] = "";
char ChangeFrom[256] = "";
char RuleFrom[256] = "";
char RuleTo[256] = "";
int LAST=0;
int FIRST=1;

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg; 
    WNDCLASS wc; 
    UNREFERENCED_PARAMETER(lpszCmdLine);
	
    if (!hPrevInstance) 
    {
        wc.style = 0; 
        wc.lpfnWndProc = (WNDPROC) WndProc; 
        wc.cbClsExtra = 0; 
        wc.cbWndExtra = 0; 
        wc.hInstance = hInstance; 
        wc.hIcon = LoadIcon(hInstance, 
            MAKEINTRESOURCE(IDI_ICON));
        wc.hCursor = LoadCursor((HINSTANCE) NULL, 
            IDC_ARROW); 
        wc.hbrBackground = GetStockObject(WHITE_BRUSH);
        wc.lpszClassName = "TitleText"; 
 
        if (!RegisterClass(&wc)) 
		{
			DWORD FAIL = GetLastError();
		
			LPVOID lpMsgBuf;
			FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
				NULL, 
				FAIL,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				(LPTSTR) &lpMsgBuf,
				0,
				NULL );

			MessageBox( NULL, lpMsgBuf, "TitleText", MB_OK | MB_ICONEXCLAMATION );
			LocalFree( lpMsgBuf );

			UnregisterClass("TitleText", hinst);
            return FALSE; 
		}
    } 

    hinst = hInstance;  // save instance handle 
    // Create the main window. 

    hwndMain = CreateWindowEx(0,
							"TitleText",		
							"TitleText",		
							WS_OVERLAPPEDWINDOW,
							100, 100,				
							300, 500,			
							NULL,			
							(HMENU) NULL,		
							hinst,				
							(LPVOID) NULL);		
	
	if (!hwndMain) 
	{
		MessageBox(NULL, "Unable to create Main Window", "TitleText", MB | MB_ICONEXCLAMATION);
        return FALSE; 
	}
	
	
	hwndBAddRule = CreateWindowEx(0, 
							"Button",
							"Add Rule",
							WS_CHILD | BS_PUSHBUTTON,
							0, 0,
							73, 25,
							hwndMain,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);
	
	if (!hwndBAddRule)
	{
		MessageBox(NULL, "Unable to create Add Rule Button", "TitleText", MB | MB_ICONEXCLAMATION);
		return FALSE;
	}

	hwndBDeleteRule = CreateWindowEx(0, 
							"Button",
							"Delete Rule",
							WS_CHILD | BS_PUSHBUTTON,
							73, 0,
							95, 25,
							hwndMain,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);
	
	if (!hwndBDeleteRule)
	{
		MessageBox(NULL, "Unable to create Delete Rule Button", "TitleText", MB | MB_ICONEXCLAMATION);
		return FALSE;
	}

	hwndBViewRules = CreateWindowEx(0, 
							"Button",
							"View Rules",
							WS_CHILD | BS_PUSHBUTTON,
							168, 0,
							124, 25,
							hwndMain,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);
	
	if (!hwndBViewRules)
	{
		MessageBox(NULL, "Unable to create View Rules Button", "TitleText", MB | MB_ICONEXCLAMATION);
		return FALSE;
	}

	hwndList = CreateWindowEx(0, 
							"ListBox",
							"",
							WS_CHILD | WS_BORDER | LBS_NOTIFY,
							0, 25,
							300, 475,
							hwndMain,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);
	
	if (!hwndList)
	{
		MessageBox(NULL, "Unable to create List Window", "TitleText", MB | MB_ICONEXCLAMATION);
		return FALSE;
	}

	hwndRules = CreateWindowEx(0, 
							"ListBox",
							"",
							WS_CHILD | WS_BORDER | LBS_NOTIFY,
							0, 25,
							300, 475,
							hwndMain,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);
	
	if (!hwndRules)
	{
		MessageBox(NULL, "Unable to create Rules Window", "TitleText", MB | MB_ICONEXCLAMATION);
		return FALSE;
	}

	ShowWindow(hwndMain, nCmdShow); 
	ShowWindow(hwndBAddRule, nCmdShow);
	ShowWindow(hwndBDeleteRule, nCmdShow);
	EnableWindow(hwndBAddRule, FALSE);
	EnableWindow(hwndBDeleteRule, FALSE);
	ShowWindow(hwndBViewRules, nCmdShow);
	ShowWindow(hwndList, nCmdShow);
	UpdateWindows();

	SetTimer(hwndMain, 1, 1000, NULL);

    while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg);
		switch (msg.message)
		{
			case WM_KEYDOWN:
			{
				if ((int)msg.wParam == 13)
				{
					if (msg.hwnd == hwndEdit)
					{
						HWND hwndTemp;
						char temp[256] = "";
						GetWindowText(hwndEdit, temp, 256);
						DestroyWindow(hwndEdit);
						hwndEdit=NULL;
						hwndTemp = FindWindow(NULL, ChangeFrom);
						SetWindowText(hwndTemp, temp);
						SetWindowPos(hwndTemp, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
					}
					else if (msg.hwnd == hwndRuleFrom)
					{
						GetWindowText(hwndRuleFrom, RuleFrom, 256);
						DestroyWindow(hwndRuleFrom);
						hwndRuleFrom=NULL;
						AddRuleTo();
					}
					else if (msg.hwnd == hwndRuleTo)
					{
						char temp[256] = "";
						GetWindowText(hwndRuleTo, RuleTo, 256);
						DestroyWindow(hwndRuleTo);
						hwndRuleTo=NULL;
						sprintf(temp, "From%d", LAST);
						WritePrivateProfileString("TitleText", temp, RuleFrom, ini);
						sprintf(temp, "To%d", LAST);
						WritePrivateProfileString("TitleText", temp, RuleTo, ini);
						sprintf(RuleFrom, "");
						sprintf(RuleTo, "");
						LAST++;
						ListRules();
					}
				}
			}
		}
	} 
 
    return 0; 
} 

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
		case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
		{ 
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
			RECT r;
			HBRUSH hbr = CreateSolidBrush(0x00FFFFFF);
			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, hbr);
			EndPaint(hwnd,&ps);
			DeleteObject(hbr);
		}
		return 0;
		case WM_SIZE:
		{
			DWORD fwSizeType = wParam;      // resizing flag 
			int nWidth = LOWORD(lParam);  // width of client area 
			int nHeight = HIWORD(lParam); // height of client area 

			SetWindowPos(hwndList,0,0,0, nWidth+1, nHeight+10, SWP_NOMOVE | SWP_NOZORDER);
			SetWindowPos(hwndRules,0,0,0, nWidth+1, nHeight+10, SWP_NOMOVE | SWP_NOZORDER);
		}
		return 0;
		case WM_COMMAND:
		{
			char temp[256] = "";
			if ((HWND) lParam == hwndList)
			{
				if (HIWORD(wParam) == LBN_DBLCLK)
				{
					SendMessage(hwndList, LB_GETTEXT, (WPARAM) SendMessage(hwndList, LB_GETCURSEL, 0, 0), (LPARAM) (LPCTSTR) temp);
					ChangeWindow(temp);
				}
			}
			else if ((HWND) lParam == hwndBAddRule)
			{
				AddRuleFrom();
			}
			else if ((HWND) lParam == hwndBViewRules)
			{
				if (IsWindowVisible(hwndRules))
				{
					ShowWindow(hwndRules, SW_HIDE);
					SetWindowText(hwndBViewRules, "View Rules");
					EnableWindow(hwndBAddRule, FALSE);
					EnableWindow(hwndBDeleteRule, FALSE);
					ShowWindow(hwndList, SW_SHOW);
				}
				else
				{
					ShowWindow(hwndList, SW_HIDE);
					SetWindowText(hwndBViewRules, "View Windows");
					EnableWindow(hwndBAddRule, TRUE);
					EnableWindow(hwndBDeleteRule, TRUE);
					ListRules();
					ShowWindow(hwndRules, SW_SHOW);

				}
			}
			else if ((HWND) lParam == hwndBDeleteRule)
			{
				DeleteRule();
			}
			else if (wParam == 1000)
			{
				if( lParam == 0x0201 )
				{
					ModifyTrayIcon( hwndMain, WM_COMMAND, 1000, NIM_DELETE, IDI_ICON );
					ShowWindow(hwnd, SW_SHOW);
					ShowWindow(hwnd, SW_RESTORE);
				}
			}
		}
		return 0;
		case WM_TIMER:
		{
			switch (wParam)
			{
				case 1:
				{
					UpdateWindows();
				}
				break;
			}
		}
		return 0;
		case WM_SYSCOMMAND:
			if (wParam == SC_CLOSE)
			{
				ModifyTrayIcon( hwndMain, WM_COMMAND, 1000, NIM_DELETE, IDI_ICON );
				DestroyWindow(hwndMain); 
				DestroyWindow(hwndList);
				DestroyWindow(hwndEdit);
				DestroyWindow(hwndRules);
				DestroyWindow(hwndRuleFrom);
				DestroyWindow(hwndRuleTo);
				DestroyWindow(hwndBAddRule);
				DestroyWindow(hwndBDeleteRule);
				DestroyWindow(hwndBViewRules);
				UnregisterClass("TitleText", hinst);
				exit(0);
			}
			else if (wParam == SC_MINIMIZE)
			{
				ShowWindow(hwnd, SW_MINIMIZE);
				ShowWindow(hwnd, SW_HIDE);
				ModifyTrayIcon( hwndMain, WM_COMMAND, 1000, NIM_ADD, IDI_ICON );
			}
	}
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int UpdateWindows()
{
	FIRST=1;
	EnumWindows(EnumWindowsProc, 0);
	return 1;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	char WndTxt[256] = "";
	char From[256] = "";
	char To[256] = "";
	char temp[256] = "";
	int x=0;
	int y=0;
	char *pdest=0;
	char *blah=0;
	int result=0;
	
	if (IsWindowVisible(hwnd))
	{
		GetWindowText(hwnd, WndTxt, 256);
		if (WndTxt[0] != '\0' && strcmp(WndTxt, "LiteStep") && strcmp(WndTxt, "TitleText"))
		{
			if (FIRST && !strcmp(WndTxt, First))
				return FALSE;
			else if (FIRST && strcmp(WndTxt, First) != 0)
			{
				strcpy(First, WndTxt);
				SendMessage(hwndList, LB_RESETCONTENT, 0, 0);
			}
			
			FIRST=0;

			sprintf(temp, "From%d", x);
			while (GetPrivateProfileString("TitleText", temp, "", From, 256, ini))
			{
				if (pdest = strstr(WndTxt, From))
				{
					result = pdest - WndTxt;
					sprintf(temp, "To%d", x);
					GetPrivateProfileString("TitleText", temp, "", To, 256, ini);
					strcpy(temp, WndTxt);
					while (y <= (int)strlen(To))
					{
						temp[result] = To[y];
						y++;
						result++;
					}
					pdest = strstr(WndTxt, From);
					pdest += strlen(From);
					strcat(temp, pdest);
					SetWindowText(hwnd, temp);
					break;
				}
				x++;
				sprintf(temp, "From%d", x);
			}
			GetWindowText(hwnd, WndTxt, 256);
			SendMessage(hwndList, LB_ADDSTRING, 0, (LPARAM)(LPCTSTR)WndTxt);
		}
	}
	return TRUE;
}

int ChangeWindow(char from[256])
{
		hwndEdit = CreateWindowEx(0, 
								"Edit",
								from,
								WS_OVERLAPPEDWINDOW| ES_AUTOHSCROLL,
								200, 200,
								300, 50,
								NULL,
								(HMENU) NULL,
								hinst,
								(LPVOID) NULL);

		if (!hwndEdit)
			return 0;
    
		ShowWindow(hwndEdit, SW_SHOWNORMAL);
		strcpy(ChangeFrom, from);
	return 1;
}

int AddRuleFrom()
{
	hwndRuleFrom = CreateWindowEx(0, 
							"Edit",
							"",
							WS_OVERLAPPEDWINDOW | ES_AUTOHSCROLL,
							200, 200,
							300, 50,
							NULL,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);

	if (!hwndRuleFrom)
		return 0;
    
	ShowWindow(hwndRuleFrom, SW_SHOWNORMAL);
	return 1;
}

int AddRuleTo()
{
	hwndRuleTo = CreateWindowEx(0, 
							"Edit",
							"",
							WS_OVERLAPPEDWINDOW | ES_AUTOHSCROLL,
							200, 200,
							300, 50,
							NULL,
							(HMENU) NULL,
							hinst,
							(LPVOID) NULL);

	if (!hwndRuleTo)
		return 0;
    
	ShowWindow(hwndRuleTo, SW_SHOWNORMAL);
	return 1;
}

int ListRules()
{
	int x=0;
	char temp[256] = "";
	char From[256] = "";
	char To[256] = "";

	SendMessage(hwndRules, LB_RESETCONTENT, 0, 0);
	sprintf(temp, "From%d", x);
	while (GetPrivateProfileString("TitleText", temp, "", From, 256, ini))
	{
		sprintf(temp, "To%d", x);
		GetPrivateProfileString("TitleText", temp, "", To, 256, ini);
		sprintf(temp, "%s -> %s", From, To);
		SendMessage(hwndRules, LB_ADDSTRING, 0, (LPARAM)(LPCTSTR)temp);
		x++;
		sprintf(temp, "From%d", x);
	}
	LAST=x;
	return 1;
}

int DeleteRule()
{
	char temp[256] = "";
	char From[256] = "";
	char To[256] = "";
	int x=0;
	int which = SendMessage(hwndRules, LB_GETCURSEL, 0, 0);
	SendMessage(hwndRules, LB_DELETESTRING, (WPARAM)which, 0);
	sprintf(temp, "From%d", which);
	WritePrivateProfileString("TitleText", temp, NULL, ini);
	sprintf(temp, "To%d", which);
	WritePrivateProfileString("TitleText", temp, NULL, ini);
	
	x=which+1;
	sprintf(temp, "From%d", x);
	while (GetPrivateProfileString("TitleText", temp, "", From, 256, ini))
	{
		sprintf(temp, "To%d", x);
		GetPrivateProfileString("TitleText", temp, "", To, 256, ini);
		sprintf(temp, "From%d", x-1);
		WritePrivateProfileString("TitleText", temp, From, ini);
		sprintf(temp, "To%d", x-1);
		WritePrivateProfileString("TitleText", temp, To, ini);
		x++;
		sprintf(temp, "From%d", x);
	}
	sprintf(temp, "From%d", x-1);
	WritePrivateProfileString("TitleText", temp, NULL, ini);
	sprintf(temp, "To%d", x-1);
	WritePrivateProfileString("TitleText", temp, NULL, ini);
	LAST--;
	ListRules();
	return 1;
}

BOOL ModifyTrayIcon( HWND hWnd, UINT msg, UINT uID, DWORD dwType, int iIcon )
{
	NOTIFYICONDATA nid;

	memset( &nid, 0, sizeof(NOTIFYICONDATA) );         //  Initialize structure
	nid.cbSize = sizeof(NOTIFYICONDATA);             //  Plug in structure size
	nid.hWnd = hWnd;                                  //  Plug in passed values
	nid.uID = uID;
	nid.uFlags = NIF_ICON | NIF_MESSAGE;      //  We use icons and notification
	nid.uCallbackMessage = msg;                    //  Load icon from resources
	nid.hIcon = LoadImage( hinst, MAKEINTRESOURCE( iIcon ),
						   IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR );
	Shell_NotifyIcon( dwType, &nid );          //  Update icon using shell call
	return( TRUE );
}
