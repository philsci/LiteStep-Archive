WinPlace (v1.1) by WhiteShadow (changty@muohio.edu) on 07-17-01
*******************************************************************

This module allows you to place windows that are showing using
bang commands.  It's useful for letting you quickly reposition
a group of windows after they get moved (possibly by a game or
something that changed your resolution).

Installation:

	1. Copy winplace.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\winplace.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep


Usage:
	Bang Commands
	-------------

	!winplace "title" x y width height

	   Title is the title of the window you want to position.
	   x and y are the screen coordinates (top left is 0, 0)
	   If you enter a width and a height, the window will be
	   resized.  If you omit width and height, the window will
	   not be resized.  You can also place a * before or after
	   the title to match all windows that end or begin with
	   the title.  If you enclose title in *'s, it will match
	   any titlebar that contains the text.
	   Examples are listed below.

	!winplacedesk "title" x y width height

	   Same as the above command except that it only moves 
	   windows that are on the screen (current virtual window).
	   "On the screen" means that the top left corner is on
	   your desktop.

	!winplacegroup "name"

	   Places all windows that are defined in your step.rc
	   using WinPlaceSet.  See below for an explaination of
	   WinPlaceSet.

	!winplacedeskgroup "name"

	   Same as above except for WinPlaceDeskSet lines in your
	   step.rc


	step.rc Commands
	----------------

	WinPlaceSet "name" "title" x y height width

	   This makes entries to be used by !winplacegroup.  Put
	   multiple WinPlaceSet lines in your step.rc with the
	   same name to set a group of windows using one bang.

	WinPlaceDeskSet "name" "title" x y height width

	   Same as above except like !winplacedesk, it only moves
	   windows that are on your desktop (top left corner of
	   the window is visible).

Notes:

	"name" and "title" are both case sensitive.  The use of
	quotes or the lack of quotes shouldn't matter.

	Also, negative numbers do *not* reference from the right
	or bottom of the screen because you may want to place
	a window off the screen.

Examples:

	!winplace "mIRC32*" 50 25
	   Places your mIRC window at 50 25.

	!winplace "ShellFront*" 100 100 600 400
	   Places a browser window open to ShellFront at 100, 100
	   and resizes the window to 600x400.

	!winplacedesk "*Internet Explorer*" 50 50
	   Moves all IE windows open on the current desktop to
	   50, 50 and does not resize.

	WinPlaceSet "diablo" "Eterm1" 0 0 400 300
	WinPlaceSet "diablo" "Eterm2" 0 300 400 300
	WinPlaceSet "diablo" "Eterm3" 400 0 400 300
	WinPlaceSet "diablo" "Eterm4" 400 300 400 300
	!winplacegroup "diablo"
	   Places four Eterm windows that were set in the step.rc.

	WinPlaceSet "left" "title1" 0 0
	WinPlaceSet "left" "title2" 0 300
	WinPlaceSet "right" "title1" 700 0
	WinPlaceSet "right" "title2" 700 300
	!winplacegroup "left"
	!winplacegroup "right"
	   Moves title1 & title2 back and forth from the left and
	   right side of the screen.

History:

	v1.1 (07-17-01)
	+added !winplacedesk, !winplacedeskgroup, and winplacedeskset
	+added wildcard matching to the beginning of the title.

	v1.0 (07-16-01)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
