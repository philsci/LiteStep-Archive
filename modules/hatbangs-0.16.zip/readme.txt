HatBangs v0.16
An improved VariousBangs by Andrew Sutherland (sombrero@catgufu.org)

This is a bangs module based off of "Remco de Jong - [rDJ]"'s VariousBangs
LoadModule (bangs.dll).

--- What's New

Version 0.16 adds:

Now will load on NT4/95 systems.  Multi-monitor features are automatically
disabled.

Version 0.15 adds:

!CloseCurWindow
!ToggleOnTop

!GotoBookmark now toggles the window to minimized if it was already in the
foreground.


--- Overview

VariousBangs supported:
!SetWallPaper <bitmap>
!ChangeRes <bitsperpixel> <width> <height>
!ToggleScreenSaver

HatBangs modified the following to work as such:
!ChangeRes <bitsperpixel> <width> <height> <monitor number> <refresh rate>

HatBangs adds the following:
!SetBookmark <0 through 9, inclusive>
!GotoBookmark <0 through 9, inclusive>
!SwapAppMonitor (noresize)
!CloseCurWindow
!ToggleOnTop


--- More in-depth info

!ChangeRes <bitsperpixel> <width> <height> <monitor number> <refresh rate>

The addition of ChangeRes allows you to change the resolutions of any monitor
in a multimonitor setup.  It also allows you to optionally specify the refresh
rate that should be used on that monitor.  (That option is thanks to my Rage128
under Win2k which has no 'optimal' refresh rate and thus seems to believe that
70Hz is more aesthetically pleasing than 85Hz.)

If you want to leave a setting as is, you can put "default" in its place.  In 
the case of the monitor number, that will opt to use your first monitor. This
default value also takes effect if you opt to omit an option.  (Omitting is
defined as the bang command running out of parameters. Using two spaces and 
thinking that means you're omitting something doesn't count.)


!SetBookmark <0 through 9, inclusive>
!GotoBookmark <0 through 9, inclusive>

This is for all of you who use bookmarks in your IDE.  I have no clue whether
this will be useful or not, but I could see it being useful.  When you invoke
the SetBookmark command, the window which currently has foreground status is
saved into the specified slot number.  When you invoke the GotoBookmark
command, the window stored in that slot number is returned to foreground
status.  (Foreground status == currently active window.)

If you 'goto' a bookmark for a window that currently has foreground status,
the window will be minimized.

This would probably be useful in the cases where you have many IE windows
open and you don't want to have to hover over the icons/click on them
to get where you want to be.  


!SwapAppMonitor (noresize)

This moves the window which currently has foreground status to your *other*
monitor.  If you have more than 2 monitors, this will only work for windows
on the first two monitors, and it will only move it from one of the monitors
to the other.  If I find a way to expand my usable desk space to fit a third
monitor on, then maybe I'll add support for more.  Source is supplied if you
have three monitors (or more).

Because the monitors may be running at different resolutions, if you omit the
"noresize" parameter, the window will be resized to make it take up the same
percentage of horiz/vert space on the other monitor.  If you tack on
"noresize", then it will simply re-position the window without resizing it.
On two monitors running at the same resolution, either way you get the same
result.


!CloseCurWindow

As one might expect, it closes the current window.  This is for those of you
who are lazy like me and don't want to have to reach all the way for Alt-F4.


!ToggleOnTop

Toggles the always-on-top status of the current window.  I didn't want to have
to assign two keys to accomplish this, hence this bang.


--- Update Log

v 0.11 - Fixed bookmark so minimized windows are restored.

--- Installation Info

It's a LoadModule.  An example line for your step.rc, assuming you put it in
'modules' off of your LiteStep root is:

LoadModule "$LiteStepDir$\modules\hatbangs.dll"
   
    
--- Example step.rc stuff

Here's a hunk'o my step.rc.  Note that the resolution stuff operates on my
second monitor and has it run at 85Hz at both resolutions.  One might
suspect that the monitor can run at much higher refresh rates at 640x480,
and you're right.  It runs at 160Hz.  But, in a confusing move, the monitor
claimed it was still running at 85Hz (and it doesn't lie normally).  When
I went to the refresh rate options in Win2k for it, it claimed it was running
at the proper refresh rate, so I can only conclude that ATI is evil.

; --- Res Change 
*HotKey       Win    O !ChangeScreenRes 16 640 480 2 85
*HotKey       Win    P !ChangeScreenRes 16 1280 1024 2 85
; --- Bookmarks
;  Set
*HotKey       Ctrl+Win 1 !SetBookmark 1
*HotKey       Ctrl+Win 2 !SetBookmark 2
*HotKey       Ctrl+Win 3 !SetBookmark 3
*HotKey       Ctrl+Win 4 !SetBookmark 4
*HotKey       Ctrl+Win 5 !SetBookmark 5
*HotKey       Ctrl+Win 6 !SetBookmark 6
*HotKey       Ctrl+Win 7 !SetBookmark 7
*HotKey       Ctrl+Win 8 !SetBookmark 8
*HotKey       Ctrl+Win 9 !SetBookmark 9
*HotKey       Ctrl+Win 0 !SetBookmark 0
;  Goto
*HotKey       Win    1   !GotoBookmark 1
*HotKey       Win    2   !GotoBookmark 2
*HotKey       Win    3   !GotoBookmark 3
*HotKey       Win    4   !GotoBookmark 4
*HotKey       Win    5   !GotoBookmark 5
*HotKey       Win    6   !GotoBookmark 6
*HotKey       Win    7   !GotoBookmark 7
*HotKey       Win    8   !GotoBookmark 8
*HotKey       Win    9   !GotoBookmark 9
*HotKey       Win    0   !GotoBookmark 0
; --- Swap App
*HotKey       Win    A      !SwapAppMonitor


--- License

Since this is a derivative work of [rDJ]'s, I suppose it's licensed under
whatever license he had it under.  (Which he forgot to specify.)  But since
it's a LiteStep module which is dynamically linked into LiteStep and LS is
GPL, I'm presuming it *must* be GPL.  So, for all intents and purposes,
this code is released under the GPL, version 2 or later at your preference.

There is no warranty.  You use it at your own risk.  Especially if you try
to use a refresh rate your monitor doesn't support.  Using a refresh rate
your monitor doesn't support while driving is right out.



--- Source Code Notes

The source is attached.  [rDJ]'s VariousBangs originally built under Visual
C++.  My install of Visual C++ has been downright bitchy, causing me to give
up on it.  After deeming it possessed, I returned to my Borland roots and
built the dll using Borland C++ Builder.  (Maybe if I remembered what
the MS equivalent of implib was, I wouldn't have had to do this.)

The .dll is currently statically linked against the BCB RTL which explains
why it's not quite as slender as it could be.  I tried to trick it into 
using MSVCRT, but I ran into some bad voodoo and gave up.  It's 54k or so
now which is all I care about.  It only uses sprintf and atoi/atol, so 
this isn't causing any horrible malloc side-effects to occur.

If you make any improvements, I'd appreciate it if you'd let me know/send
me the changes so I can stick them in my copy.  If not, that's fine.


--- Requests

If you run some form of LiteStep website and want to put this on there,
please link to the catgufu webserver instead of hosting the file locally.
(I like to watch the webhits graphs change.)  The server is more than fast
enough to handle the 20 hits you'd otherwise serve yourself.  Also, please
provide a link directly to its specific page on the server.

The webpage:
http://www.catgufu.org/projects/hatbangs.html

The file:
http://www.catgufu.org/downloads/hatbangs.zip


--- Author Contact Info

Andrew Sutherland
sombrero@catgufu.org

http://www.catgufu.org/

