//============================================================
//ckVWM.dll v1.2 - a vwm based on sysvwm
//------------------------------------------------------------
//Filename	: 	ckVWM.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This module adds some new function to the sysvwm
//------------------------------------------------------------
//
/****************** v1.2		10/28/2000************///
// Changes:
//	Bang commands:
//		changed:
//		-!VWMRESTOREALLWINDOWS
//			>changed to !VWMRESTOREALLWINDOWS "window title or class name" "method"
//		  	where method could be blank(default to overlap), overlap, or cascade
//		-!VWMRESTOREWINDOW and !VWMRESTOREALLWINDOWS
//			>changed the window title or class name matching scheme to use the match() function.
//			The syntax for matching a specific word such as MIRC would be:  *MIRC*
//			The matching is not case sensitive
//		added:
//		-!VWMMove x y
//			>change the position of the VWM to x, y (x and y can be negative)
//			>if nothing is supplied, the VWM will move back it's old position specified in step.rc
//
//
//	Step.rc configs:
//		-Added configs to disable the vertical or horizontal autoswitch
//			>VWMDisableVerticalAutoSwitch
//			>VWMDisableHorizontalAutoSwitch
//
//		-Changed the RestoreWidth, and RestoreHeight so that if you don't specify them or
//		one of them is negative, then when restoring windows using !VWMRESTOREWINDOW or
//		!VWMRESTOREALLWINDOWS the windows' original width and heigh will not be changed.
//
//		-Added config *VWMStartWindowsOnDesktop "Window title or class name" "Desktop Number"
//		so that windows that match will always start on the desktop number you specify
//		(doesn't work with PureLS at this time)
//
//		-Added config VWMSnapWindowOnDrag so that window will retain its relative coordinate to
//		the desktop when dragging the miniwindows
//
//	Misc:
//		In this release, i added a two modified popup modules, popup r9.3 and popup2, that will work with ckvwm.
//		They will allow you to have popup tasks for hidden windows on differnt desktops when you have the 
//		config VWMHideTaskOnSwitch.  
//		The step.rc config for these added popup feature is:
//			PopupckVWMPath "path"
//		where path equals to the path to your ckvwm.dll, the one you load module with.
//		
//		When you dont use ckvwm, you can simply comment out the PopupckVWMPath, and everything
//		will be the same as before.
//
//		The syntax to see windows on other desktop is the same as !PopupTasks,
//		just replace !PopupTasks with !PopupTasks1, !PopupTasks2, !PopupTasks3.....depending on your
//		vwm configuration.  !PopupTasksAll Allows you to tasks from all desktops.
//
//		*Note: if a warning dialog popups up from your shell saying that the module ckvwm is already
//		loaded, simply change the order you load ckvwm and popup in step.rc  Load ckvwm before popup
//
//	Bug Fix:
//		-Fix the problem that !VWMTOGGLEHIDETASKONSWITCH will make windows disappear
//		-Fix !MoveApp bang so that it will work with VWMWrapScreen
//		-Fix !MoveApp bang so that for examle you click on a shortcut which calls this bang, the program will
//		look for the topmost visible window to move.
//		-Fix the bug that when clicking on task, the wrong desktop will be shown.
//		-Fix the config VWMDeskWallpaper# so that it can use e-vars, and save the time to allocate unnecessary memory spaces
//
//	Future Plan:
//		-Add a lock feature so that you can't switch to other desktop or control other desktop
//		unless you enter the right password
//		-The ability to double click on a miniwindow to maximize or restore the window.
//		-When dragging miniwindows, vwm will automatically switch to the desktop that the window is in.
//		-Add bang commands to control group of windows
//
//
//	Note:
//		Special thanks to [steve] in helping me to diagnose a bug, and a lot of people who contributed their
//		ideas, or told me their problems.  If there is a bug that isn't fixed, or any ideas that you have either
//		new or i forgot to implement it and it's not in the Future Plan list, please send an e-mail to me (even
//		if you did already and it's still not fixed) to chaokuo@iname.com or 
//		go to irc channel @ EFnet, in #ls_help and tell me.  My nick is Chaku, thanks.
//
/****************** v1.0		9/30/2000************/
//
// Finally found the bug that was causing my v0.81(internal version) to be unstable.
// First, I want to thank those who had contributed to any part of this code
// and those who helped spreading it.  Also, thanks for those who sent me e-mail  
// with suggestions and bug reports.  This version should be stable and....
// Anyway, here we go...
//
// Changes:
//	Added Bang commands:
//			!VWMRESTOREWINDOW <text>
//				This command will help you retrieve hidden window that's lost in your desktop.
//				The text specify any word or sentence in the window's title that you want to restore.
//			!VWMRESTOREALLWINDOWS <text>
//				Same as the bang above, except this one will restore all the window that contains text
//				in its title.
//					
//	Added Step.rc configs:
//		The following 4 fonfigs will determine where the window will show when you
//		use the restore bangs above:
//			VWMRestoreX # (default 10)
//			VWMRestoreY # (default 10)
//			VWMRestoreWidth # (default 400)
//			VWMRestoreHeight # (default 300)
//
//		The following config will allow you to change how VWM will determine whether the maximized
//		window is out of the current desktop.  The # represents portion of the area where 10
//		means 10%, and 20 means 20%.  Unless you really know what you are doing, it is not
//		recommend that you change this config.  It's default to 10( which means 10%)
//
//			VWMMaximizeThreshold #
//
//
// Bug Fix:
//	-Fix the problem that VWMWrapScreen doesn't work when AutoSwitching
//	-Fix the bang commands, VWMOpen and VWMInitialDesk, so that the first desktop will be 1 instead of 0
//	-Fix the bang command, VWMReset.
//	-Fix the problem that maximized or full screen stuff will disappear. (sorry guys)
//	-Fix the problem that it will occasionally lock up.
//	-Others that i can't think of right now.....
//
// *Note:
//		-VWMReturnToFirstScreen i think is for users of Litestep families(such as PureLS)that don't
//		support the message LM_SAVEDATA, so your windows won't disappear after recycle.
//		-Source code is availabe at my site.
//
//
/****************** v0.8b		9/24/2000************/
//Changes:
//	Added Step.rc Config:
//		VWMHideTaskOnSwitch
//			-This will cause the sysvwm hide the tasks from task bar if
//			 its window is not on the current screen.  It will not hide the minimized window
//			from task bar, and it'll carry it to differnt desktop.  So when restored, the window
//			will be in the current desktop, and not in the old
//			
//		VWMWrapScreen
//			-This will alow your desktops to be kind of circular.  Let's say the you are in the 
//			first desktop. When you use !VWMLeft, this config will allow you to move to the last
//			desktop.
//		VWMReturnToFirstScreen
//			-For those whose sysvwm will behave weird when not recycling in the first desktop,
//			this config will force the sysvwm to go back to the first desktop.
//			(I don't know about most of the people, but i guess you won't experience this kind of problem)
//
//	Added Bang Commands:
//		!VWMTOGGLEHIDETASKONSWITCH
//			-This is for toggling the VWMHideTaskOnSwitch config
//		!VWMTOGGLEWRAPSCREEN
//			-This is for toggling the VWMWrapScreen config
//	
//	*Note: 
//		-In this version of !VWMDesk #, the # will start from 1 and not 0
//		-This is just a beta version.  I welcome any suggestions, and if you found a bug
//		please please report to me @ chaokuo@iname.com  Thanks.
//------------------------------------------------------------
//Example Step.rc config:
//	LoadModule "C:\Litestep\ckVWM.dll"
//	VWMHideTaskOnSwitch
//	VWMReturnToFirstScreen
//	VWMWrapScreen
//	
