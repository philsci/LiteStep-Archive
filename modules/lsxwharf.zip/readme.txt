Found out about this on IRC... apparently it's lsxcommand as a wharf module. So,
you can load it in a wharf or lsbox.

It's based on lsxcommand 1.8.x... so it should work just like the regular
lsxcommand... sounds like this was just a small patch the lsx code.


lsxwharf was written/patched by whytheluckystiff
whytheluckystiff@mailcity.com


--
rootrider
http://floach.pimpin.net/
2000.10.20