////////////////////////////////
// WharfLaunch V1.1 Add-on
// By: MrJukes
// Released: 8/31/98

Basically, these are the same as WharfLaunch.app, but they look into different
sections of your modules.ini.  So, WharfLaunch2.app will look in the [WharfLaunch2]
section of your modules.ini, and so on.

Have fun,
        MrJukes
	mrjukes@litestep.net
