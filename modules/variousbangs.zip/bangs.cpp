#include <windows.h>
#include <stdio.h>
#include "bangs.h"
#include "lsapi.h"

void SetWallPaper(HWND caller, char* arg);
void ChangeRes(HWND caller, char* arg);
void ToggleScreenSaver(HWND caller, char* arg);
HWND parent;

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
  return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  parent = ParentWnd;

  AddBangCommand("!SETWALLPAPER", SetWallPaper);
  AddBangCommand("!CHANGESCREENRES", ChangeRes);
  AddBangCommand("!TOGGLESCREENSAVER", ToggleScreenSaver);
  return 0;
}

void quitModule(HINSTANCE dllInst)
{
// nothing to do
}

void SetWallPaper(HWND caller, char* arg)
{
  if (arg)
    SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, arg, SPIF_UPDATEINIFILE);
}

void ChangeRes(HWND caller, char* arg)
{
  DEVMODE DevMode;
  char bpp[10], width[10], height[10];
  int i = 0, j = 0;
  while (arg[i] != ' ')
  {
    bpp[i] = arg[i];
	i++;
  }
  bpp[i] = '\0';
  i++;
  while (arg[i] != ' ')
  {
    width[j] = arg[i];
	i++;
	j++;
  }
  width[j] = '\0';
  i++;
  strcpy(height, arg + i);
  EnumDisplaySettings(NULL, 0, &DevMode);
  DevMode.dmBitsPerPel= atoi(bpp);
  DevMode.dmPelsWidth = atoi(width);
  DevMode.dmPelsHeight = atoi(height);
  DevMode.dmFields = DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
  switch (ChangeDisplaySettings(&DevMode, CDS_UPDATEREGISTRY))
  {
    case DISP_CHANGE_RESTART:
	  MessageBox(parent,"The computer must be restarted in order for the graphics mode to work.","Change resolution",MB_OK);
      break;
	case DISP_CHANGE_FAILED:
	  MessageBox(parent,"The display driver failed the specified graphics mode.","Change resolution",MB_OK);
      break;
	case DISP_CHANGE_BADMODE:
	  MessageBox(parent,"The graphics mode is not supported.","Change resolution",MB_OK);
      break;
  }
}

void ToggleScreenSaver(HWND caller, char* arg)
{
  BOOL IsActive;
  SystemParametersInfo(SPI_GETSCREENSAVEACTIVE, 0, &IsActive, 0);
  SystemParametersInfo(SPI_SETSCREENSAVEACTIVE, !IsActive, NULL, SPIF_UPDATEINIFILE);
}