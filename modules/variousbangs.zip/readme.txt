A few bang commands written from ideas at MindStorm.

!SetWallPaper <bitmap>
!ChangeRes <bitsperpixel> <width> <height>
!ToggleScreenSaver

Ps. these are ideas 11, 48 and 54.
Source is included.

Remco de Jong - [rDJ]