#define M_DELETE_NOTE	200
#define M_NEW_NOTE		201
#define M_EDIT_NOTE		203

#define M_BG_RED		204
#define M_BG_GREEN		205
#define M_BG_BLUE		206
#define M_BG_YELLOW		207
#define M_BG_WHITE		208
#define M_BG_BLACK		209

#define M_TX_RED		210
#define M_TX_GREEN		211
#define M_TX_BLUE		212
#define M_TX_YELLOW		213
#define M_TX_WHITE		214
#define M_TX_BLACK		215

#define M_ALIGN_LEFT	216
#define M_ALIGN_CENTER	217
#define M_ALIGN_RIGHT	218

#define M_ABOUT			219
#define M_HIDE_NOTE		220

#define M_BG_CUSTOM		221		// 221-230
#define M_TX_CUSTOM		231		// 231-240

#define M_FONT			232
