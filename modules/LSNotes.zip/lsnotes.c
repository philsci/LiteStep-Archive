/***********************************************************
*        Sample - Sample Litestep Module Code              *
* This single source file is the code to sample.           *
*                         *  *  *  *                       *
* Last Update:  September 27, 1999 10:00 PM                *
*                         *  *  *  *                       *
* Copyright (c) 1999 Shaheen Gandhi                        *
***********************************************************/

#include <windows.h>
#include <richedit.h>
#include <lsapi.h>

#include "exports.h"
#include "lsnotes.h"
#include "resource.h"

char *szAppName = "LSNotes";
void SetWindowBitmapRgn(HWND hwnd, HDC hdc);

enum COLOR 
{
	CUSTOM=-1,
	RED=0x000000FF, 
	GREEN=0x0000FF00, 
	BLUE=0x00FF0000, 
	YELLOW=0x0000FFFF, 
	CYAN=0x00FFFF00, 
	MAGENTA=0x00FF00FF, 
	WHITE=0x00FFFFFF, 
	BLACK=0x00000000
};

struct NOTE
{
	HWND hwnd;
	HWND edit;
	HWND close;
	HWND track, scroll;
	enum COLOR bg;
	enum COLOR fg;

	char CustomBG[256];
	char CustomFG[256];

	POINT pos;
	RECT r;

	int count;
	int trackoffset;
	char data[2048];

	int width, height, ow, oh;
	int scrolly;

	HFONT font;
	char fontname[256];
	int fontsize;

	DWORD align;
	BOOL USEOFFSET;
};

struct SettingsStruct
{
	HWND desktop, parent, hwndAbout;
	HINSTANCE hInstance;
	HBRUSH RED_BRUSH, GREEN_BRUSH, BLUE_BRUSH, YELLOW_BRUSH, CYAN_BRUSH, MAGENTA_BRUSH;
	HMENU NOTE_MAIN_MENU, NOTE_BGCOLOR_MENU, NOTE_TXCOLOR_MENU, NOTE_ALIGN_MENU, NC_MENU, NOTE_BGCUSTOM_MENU, NOTE_TXCUSTOM_MENU;
	HBITMAP bgbmp, closebmp, closeclickbmp, trackbmp, scrollbmp;
	int closex, closey, closew, closeh;
	int CURRENT;
	int width, height, posx, posy;
	int top, right, bottom, left;
	int track_w, track_h, scroll_w, scroll_h;
	int track_up, track_down;
	int ScreenX, ScreenY;
	char notefile[MAX_PATH];
	COLORREF CC[10];

	int fontsize;
	char fontname[256];
	COLORREF fontcolor;

	BOOL confirmdelete;
} settings;

void SetRichEditTextColor(HWND edit, COLORREF color)
{
	CHARFORMAT2* cf = (CHARFORMAT2*)malloc(sizeof(CHARFORMAT2));
	cf->cbSize = sizeof(CHARFORMAT2);
	cf->dwMask = CFM_COLOR;
	cf->crTextColor = color;
	SendMessage(edit, EM_SETCHARFORMAT, (WPARAM)SCF_ALL, (LPARAM)(CHARFORMAT2 FAR*)cf);
}

void AddNote(struct NOTE* p)
{
	char temp[25] = "";

	settings.CURRENT = p->count + 1;
	
	p->USEOFFSET=FALSE;	
	p->font = CreateFont(p->fontsize, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, p->fontname);

	sprintf(temp, "%%%%_StartNote%d_%%%%", p->count);
	p->hwnd = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, temp, WS_POPUP | WS_CLIPCHILDREN, p->pos.x, p->pos.y, p->width, p->height, NULL, NULL, settings.hInstance, 0);
	
	{
		CHARFORMAT2* cf = (CHARFORMAT2*)malloc(sizeof(CHARFORMAT2));
		p->edit = CreateWindowEx(WS_EX_TRANSPARENT, RICHEDIT_CLASS, p->data, WS_CHILD | ES_AUTOVSCROLL | ES_MULTILINE | ES_WANTRETURN, settings.left, settings.top, p->width-settings.left-settings.right, p->height-settings.top-settings.bottom, p->hwnd, NULL, settings.hInstance, 0);
		if (!p->edit) return;
		//SendMessage(p->edit, EM_AUTOURLDETECT, (WPARAM)FALSE, 0);
		//SendMessage(p->edit, EM_SETEVENTMASK, 0, (LPARAM)(ENM_LINK | ENM_MOUSEEVENTS));
		cf->cbSize = sizeof(CHARFORMAT2);
		cf->dwMask = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_WEIGHT;
		cf->dwEffects = 0;
		cf->crTextColor = p->fg;
		strcpy(cf->szFaceName, p->fontname);
		cf->yHeight = p->fontsize*12;
		cf->wWeight = 0;
		SendMessage(p->edit, EM_SETCHARFORMAT, (WPARAM)SCF_ALL, (LPARAM)(CHARFORMAT2 FAR*)cf);
	}
	
	SetProp(p->hwnd, "NOTE", (HANDLE)p);
	GetClientRect(p->hwnd, &p->r);
	if (settings.closebmp) 
	{
		p->close = CreateWindowEx(WS_EX_TRANSPARENT, "Button", "", 
								WS_CHILD | BS_OWNERDRAW, 
								(settings.closex < 0)? p->width+settings.closex : settings.closex, 
								(settings.closey < 0)? p->height+settings.closey : settings.closey, 
								settings.closew, settings.closeh, 
								p->hwnd, NULL, settings.hInstance, 0);
		ShowWindow(p->close, SW_SHOWNORMAL);
	}

	if (settings.scrollbmp && settings.trackbmp)
	{
		p->trackoffset = 0;
		p->track = CreateWindowEx(0, "MJTrack", "", WS_CHILD, p->width-settings.right-settings.track_w, settings.top, settings.track_w, p->height-settings.top-settings.bottom, p->hwnd, NULL, settings.hInstance, 0);
		p->scroll = CreateWindowEx(0, "MJScroll", "", WS_CHILD | WS_VISIBLE, settings.track_w/2 - settings.scroll_w/2, settings.track_up, settings.scroll_w, settings.scroll_h, p->track, NULL, settings.hInstance, 0);
	}

	ShowWindow(p->hwnd, SW_SHOW);
	InvalidateRect(p->hwnd, NULL, TRUE);
	SetActiveWindow(p->hwnd);
}

void BangNewNote(HWND caller, const char *args)
{
	struct NOTE* p = (struct NOTE*)malloc(sizeof(struct NOTE));

	p->count = settings.CURRENT;
	sprintf(p->data, " ");
	strcpy(p->fontname, settings.fontname);
	p->fontsize = settings.fontsize;
	p->bg = YELLOW;
	p->fg = settings.fontcolor;
	p->width = settings.width;
	p->height = settings.height;
	p->pos.x = settings.posx;
	p->pos.y = settings.posy;
	p->align=DT_LEFT;
		
	AddNote(p);
}

void BangNextNote(HWND caller, const char *args)
{
}

void BangHideNote(HWND caller, const char *args)
{
	HWND hwnd = GetForegroundWindow();
	char temp[256] = "";

	GetClassName(hwnd, temp, 256);

	if (!strcmp(temp, szAppName))
	{
		ShowWindow(hwnd, SW_HIDE);
	}
}

void BangHideAllNotes(HWND caller, const char *args)
{
	struct NOTE* p = (struct NOTE*)malloc(sizeof(struct NOTE));
}

void BangShowAllNotes(HWND caller, const char *args)
{
	struct NOTE* p = (struct NOTE*)malloc(sizeof(struct NOTE));
}

void BangDeleteNote(HWND caller, const char *args)
{
	HWND hwnd = GetForegroundWindow();
	char temp[256] = "";

	GetClassName(hwnd, temp, 256);

	if (!strcmp(temp, szAppName))
	{
		SendMessage(hwnd, WM_COMMAND, (WPARAM)M_DELETE_NOTE, 0);
	}
}

COLORREF GetColor(char* color)
{
	if (!_stricmp(color, "red")) return RED;
	else if (!_stricmp(color, "green")) return GREEN;
	else if (!_stricmp(color, "blue")) return BLUE;
	else if (!_stricmp(color, "yellow")) return YELLOW;
	else if (!_stricmp(color, "white")) return WHITE;
	else if (!_stricmp(color, "black")) return BLACK;
	else 
	{
		int x=0;
		for (x=0; x<10; x++)
		{
			char temp[256] = "";
			sprintf(temp, "%x", settings.CC[x]);
			if (!_stricmp(color, temp)) return settings.CC[x];
		}
	}

	return YELLOW;
}

void LoadSettings()
{
	int count=0, MAX=50;
	FILE* file = fopen(settings.notefile, "r");
	FILE* step;
	char temp[256] = "";
	char token1[4096], token2[4096], token3[4096], extra_text[4096];
	char* tokens[3];
	BITMAP bmp;

	LoadLibrary("RichEd20.Dll");

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;

	settings.NOTE_BGCUSTOM_MENU = CreatePopupMenu();
	settings.NOTE_TXCUSTOM_MENU = CreatePopupMenu();
	step = LCOpen(NULL);
	if (step)
	{
		int x=0;

		while (LCReadNextConfig(step, "*NoteColor", temp, 256))
		{
			if (x < 10)
			{
				int count = LCTokenize (temp, tokens, 3, extra_text);
				if (count == 3)
				{
					AppendMenu(settings.NOTE_BGCUSTOM_MENU, MF_ENABLED | MF_STRING, M_BG_CUSTOM + x, token2);
					AppendMenu(settings.NOTE_TXCUSTOM_MENU, MF_ENABLED | MF_STRING, M_TX_CUSTOM + x, token2);
					settings.CC[x] = strtol(token3, NULL, 16);
					x++;
				}
			}
			else
			{
				MessageBox(NULL, "Only 10 custom colors are allowed", szAppName, MB_ICONWARNING | MB_OK | MB_SYSTEMMODAL);
				break;
			}
		}
	}

	settings.NOTE_BGCOLOR_MENU = CreatePopupMenu();
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_RED, "&Red");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_GREEN, "&Green");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_BLUE, "&Blue");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_YELLOW, "&Yellow");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_WHITE, "&White");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_BLACK, "&Black");
	AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING | MF_POPUP, (int)settings.NOTE_BGCUSTOM_MENU, "Custom");

	settings.NOTE_TXCOLOR_MENU = CreatePopupMenu();
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_RED, "&Red");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_GREEN, "&Green");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_BLUE, "&Blue");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_YELLOW, "&Yellow");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_WHITE, "&White");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING, M_TX_BLACK, "&Black");
	AppendMenu(settings.NOTE_TXCOLOR_MENU, MF_ENABLED | MF_STRING | MF_POPUP, (int)settings.NOTE_TXCUSTOM_MENU, "Custom");

	settings.NOTE_ALIGN_MENU = CreatePopupMenu();
	AppendMenu(settings.NOTE_ALIGN_MENU, MF_ENABLED | MF_STRING, M_ALIGN_LEFT, "&Left");
	AppendMenu(settings.NOTE_ALIGN_MENU, MF_ENABLED | MF_STRING, M_ALIGN_CENTER, "&Center");
	AppendMenu(settings.NOTE_ALIGN_MENU, MF_ENABLED | MF_STRING, M_ALIGN_RIGHT, "&Right");

	settings.NOTE_MAIN_MENU = CreatePopupMenu();
    AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING, M_DELETE_NOTE, "&Delete Note");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING, M_NEW_NOTE, "Add &New Note");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING, M_EDIT_NOTE, "&Edit Note");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING, M_HIDE_NOTE, "&Hide Note");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING, M_FONT, "&Font");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING | MF_POPUP, (int)settings.NOTE_BGCOLOR_MENU, "&Background Color");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING | MF_POPUP, (int)settings.NOTE_TXCOLOR_MENU, "&Text Color");
	AppendMenu(settings.NOTE_MAIN_MENU, MF_ENABLED | MF_STRING | MF_POPUP, (int)settings.NOTE_ALIGN_MENU, "&Alignment");

	settings.NC_MENU = CreatePopupMenu();
	AppendMenu(settings.NC_MENU, MF_ENABLED | MF_STRING, M_ABOUT, "&About LSNotes");

	settings.RED_BRUSH = CreateSolidBrush(RED);
	settings.GREEN_BRUSH = CreateSolidBrush(GREEN);
	settings.BLUE_BRUSH = CreateSolidBrush(BLUE);
	settings.YELLOW_BRUSH = CreateSolidBrush(YELLOW);
	settings.CYAN_BRUSH = CreateSolidBrush(CYAN);
	settings.MAGENTA_BRUSH = CreateSolidBrush(MAGENTA);

	GetRCString("NoteScrollTrackBmp", temp, "lsnotes-track.bmp", 256);
	settings.trackbmp = LoadLSImage(temp, temp);
	if (settings.trackbmp)
	{
		GetObject(settings.trackbmp, sizeof(bmp), &bmp);
		settings.track_w = bmp.bmWidth;
		settings.track_h = bmp.bmHeight;

		settings.track_up = GetRCInt("NoteScrollUp", 10);
		settings.track_down = GetRCInt("NoteScrollDown", 10);
	}

	GetRCString("NoteScrollBmp", temp, "lsnotes-scroll.bmp", 256);
	settings.scrollbmp = LoadLSImage(temp, temp);
	if (settings.scrollbmp)
	{
		GetObject(settings.scrollbmp, sizeof(bmp), &bmp);
		settings.scroll_w = bmp.bmWidth;
		settings.scroll_h = bmp.bmHeight;
	}

	GetRCString("NoteCloseButtonBmp", temp, "lsnotes-close.bmp", 256);
	settings.closebmp = LoadLSImage(temp, temp);
	settings.closex = GetRCInt("NoteCloseX", -15);
	settings.closey = GetRCInt("NoteCloseY", 3);
	if (settings.closebmp)
	{
		GetObject(settings.closebmp, sizeof(bmp), &bmp);
		settings.closew = bmp.bmWidth;
		settings.closeh = bmp.bmHeight;
	}

	GetRCString("NoteCloseButtonClickedBmp", temp, "lsnotes-close-clicked.bmp", 256);
	settings.closeclickbmp = LoadLSImage(temp, temp);

	GetRCString("NoteDefBG", temp, "lsnotes.bmp", 256);
	settings.bgbmp = LoadLSImage(temp, temp);
	settings.top = GetRCInt("NoteBorderTop", 15);
	settings.right = GetRCInt("NoteBorderRight", 5);
	settings.bottom = GetRCInt("NoteBorderBottom", 5);
	settings.left = GetRCInt("NoteBorderLeft", 5);
	settings.desktop = FindWindow("DesktopBackgroundClass", NULL);
	settings.CURRENT = 0;
	settings.width = GetRCInt("NoteDefWidth", 150);
	settings.height = GetRCInt("NoteDefHeight", 150);
	settings.posx = GetRCInt("NoteDefX", 100);
	settings.posy = GetRCInt("NoteDefY", 100);
	settings.fontcolor = GetRCColor("NoteDefFontColor", 0x00000000);
	settings.confirmdelete = GetRCBool("NoteConfirmDelete", TRUE);

	settings.ScreenX = GetSystemMetrics(SM_CXSCREEN);
	settings.ScreenY = GetSystemMetrics(SM_CYSCREEN);
	
	settings.fontsize = GetRCInt("NoteDefFontSize", 12);
	GetRCString("NoteDefFontFace", settings.fontname, "Arial", 256);

	if (!file) return;

	while (!feof(file))
	{
		char line[2048] = "";
		fgets(line, 2048, file);

		if (!_strnicmp(line, "%%_StartNote", 12))
		{
			struct NOTE* p = (struct NOTE*)malloc(sizeof(struct NOTE));
			char fontname[256] = "";
			char fontcolor[256] = "";
			char bgcolor[256]= "";
			char image[MAX_PATH] = "";
			char fontsize[10] = "";
			char width[10] = "";
			char height[10] = "";
			char posx[10] = "";
			char posy[10] = "";
			char align[15] = "";

			sscanf(line, "%%%%_StartNote%d_%%%%\n", &p->count);
			
			while (1)
			{
				fgets(line, 256, file);
				if (!_strnicmp(line, "%%_EndNote", 10) || feof(file)) break;
				else if (!_strnicmp(line, "FontFace", 8)) { strncpy(fontname, line+9, strlen(line)-10); }
				else if (!_strnicmp(line, "FontSize", 8)) { strncpy(fontsize, line+9, strlen(line)-10); }
				else if (!_strnicmp(line, "FontColor", 9)) { strncpy(fontcolor, line+10, strlen(line)-11); }
				else if (!_strnicmp(line, "BgColor", 7)) { strncpy(bgcolor, line+8, strlen(line)-9); }
				else if (!_strnicmp(line, "Image", 5)) strncpy(image, line+6, strlen(line)-7);
				else if (!_strnicmp(line, "Width", 5)) { strncpy(width, line+6, strlen(line)-7); }
				else if (!_strnicmp(line, "Height", 6))	{ strncpy(height, line+7, strlen(line)-8); }
				else if (!_strnicmp(line, "PosX", 4)) { strncpy(posx, line+5, strlen(line)-6); }
				else if (!_strnicmp(line, "PosY", 4)) { strncpy(posy, line+5, strlen(line)-6); }
				else if (!_strnicmp(line, "Align", 5)) { strncpy(align, line+6, strlen(line)-7); }
				else if (!_strnicmp(line, "%%_StartData_%%", 15))
				{
					int y = 0;
					memset(&p->data, 0, sizeof(p->data));

					while (1)
					{
						fgets(line, 2048, file);

						if (!_strnicmp(line, "%%_EndData_%%", 13)
							|| !_strnicmp(line, "%%_EndNote", 10) 
							|| feof(file)) break;
						else
						{
							int x=0;

							while (line[x] != '\0' && (x < (int)strlen(line)-1))
							{
								p->data[y] = line[x];
								if (p->data[y] == '\r')
								{
									p->data[++y] = '\n';
								}
								x++;
								y++;
							}
						}
					}
					p->data[y] = '\0';
				}
			}

			strcpy(p->fontname, fontname);
			p->fontsize = atoi(fontsize);
			p->height = atoi(height);
			p->width = atoi(width);
			p->pos.x = atoi(posx);
			p->pos.y = atoi(posy);

			p->bg = GetColor(bgcolor);
			p->fg = GetColor(fontcolor);

			if (!_stricmp(align, "right")) p->align = DT_RIGHT;
			else if (!_stricmp(align, "center")) p->align = DT_CENTER;
			else p->align = DT_LEFT;

			AddNote(p);
		}
	}
	fclose(file);
}

void SaveNote(struct NOTE* p, int c)
{
	FILE* file = (c)? fopen(settings.notefile, "a+") : fopen(settings.notefile, "w");
				
	if (!file) { MessageBox(p->hwnd, "Error opening LSNotes data file!", szAppName, MB_ICONEXCLAMATION | MB_SYSTEMMODAL);  return; }
	
	fprintf(file, "%%%%_StartNote%d_%%%%\n", c);
	fprintf(file, "FontFace %s\n", p->fontname);
	fprintf(file, "FontSize %d\n", p->fontsize);

	fprintf(file, "BGColor ");
	if (p->bg == RED) fprintf(file, "red\n");
	else if (p->bg == GREEN) fprintf(file, "green\n");
	else if (p->bg == BLUE) fprintf(file, "blue\n");
	else if (p->bg == YELLOW) fprintf(file, "yellow\n");
	else if (p->bg == WHITE) fprintf(file, "white\n");
	else if (p->bg == BLACK) fprintf(file, "black\n");
	else fprintf(file, "%x\n", p->bg);
			
	fprintf(file, "FontColor ");
	if (p->fg == RED) fprintf(file, "red\n");
	else if (p->fg == GREEN) fprintf(file, "green\n");
	else if (p->fg == BLUE) fprintf(file, "blue\n");
	else if (p->fg == YELLOW) fprintf(file, "yellow\n");
	else if (p->fg == WHITE) fprintf(file, "white\n");
	else if (p->fg == BLACK) fprintf(file, "black\n");
	else fprintf(file, "%x\n", p->fg);
	
	fprintf(file, "PosX %d\n", p->pos.x);
	fprintf(file, "PosY %d\n", p->pos.y);
	fprintf(file, "Width %d\n", p->width);
	fprintf(file, "Height %d\n", p->height);
	
	if (p->align == DT_LEFT) fprintf(file, "Align left\n");
	else if (p->align == DT_CENTER) fprintf(file, "Align center\n");
	else if (p->align == DT_RIGHT) fprintf(file, "Align right\n"); 
	
	fprintf(file, "%%%%_StartData_%%%%\n");
	fprintf(file, "%s", p->data);
	fprintf(file, "\n%%%%_EndData_%%%%\n");
	fprintf(file, "%%%%_EndNote%d_%%%%\n\n", c);
	
	fclose(file);
}

LRESULT CALLBACK NoteProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	struct NOTE* p = (struct NOTE*)GetProp(hwnd, "NOTE");

	if (message == LM_GETREVID)
	{
		LPSTR buf = (LPSTR)(lParam);

		switch (wParam)
		{
			case 0:
				sprintf(buf, "LSNotes 2.1 (MrJukes)\0");
			break;
			case 1:
				sprintf(buf, "LSNotes 2.1 (MrJukes)\0");
			break;
			default:
				sprintf(buf, "LSNotes 2.1 (MrJukes)\0");
		}
		return strlen(buf);
	}
	else if (p)
	{
		switch (message)
		{
			case WM_ERASEBKGND: return 0;

			case WM_DRAWITEM:
			{
				DRAWITEMSTRUCT* dis = (DRAWITEMSTRUCT*)lParam;

				if (dis->hwndItem == p->close)
				{
					HDC src = CreateCompatibleDC(dis->hDC);
					
					if (dis->itemState & ODS_SELECTED)
					{
						SelectObject(src, settings.closeclickbmp);
					}
					else
					{
						SelectObject(src, settings.closebmp);
					}

					BitBlt(dis->hDC, 0, 0, dis->rcItem.right, dis->rcItem.bottom, src, 0, 0, SRCCOPY);

					DeleteObject(src);
					return TRUE;
				}
			}
			break;

			case WM_NCHITTEST: 
			{
				int x = LOWORD(lParam);
				int y = HIWORD(lParam);
				RECT r;
				long htx=0;
				long hty=0;
				long ht=0;

				GetWindowRect(hwnd, &r);

				if ((y - r.top) < settings.top) hty=HTCAPTION;
				else if ((y-r.top) > r.bottom-r.top-settings.bottom) hty=HTBOTTOM;
				else hty=0;
				
				if ((x-r.left) < settings.left) htx=HTLEFT;
				else if ((x-r.left) > r.right-r.left-settings.right) htx=HTRIGHT;
				else htx=0;

				if (htx && hty)
				{
					if (hty == HTBOTTOM)
					{
						if (htx == HTLEFT) ht=HTBOTTOMLEFT;
						else if (htx == HTRIGHT) ht = HTBOTTOMRIGHT;
					}
				}
				else if (htx) ht = htx;
				else if (hty) ht = hty;
				else ht=HTCLIENT;

				return ht;
			}
			return 0;

			case WM_PAINT:
			{
				if (p)
				{
					RECT r;
					PAINTSTRUCT ps;
					HDC hdc = BeginPaint(hwnd, &ps);
					HDC buf = CreateCompatibleDC(NULL);
					HDC src = CreateCompatibleDC(NULL);
					HBITMAP bufbmp = CreateCompatibleBitmap(hdc, p->width, p->height);
					HBITMAP oldsrc, oldbuf;
					HBRUSH title;
					
					oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

					if (settings.bgbmp)
					{
						BITMAP bmp;
						
						GetObject(settings.bgbmp, sizeof(bmp), &bmp);
						oldsrc = (HBITMAP)SelectObject(src, settings.bgbmp);

						// Top Left Corner
						StretchBlt(buf, 0, 0, settings.right, settings.top, src, 0, 0, settings.right, settings.top, SRCCOPY);

						// Top Right Corner
						StretchBlt(buf, p->width-settings.right, 0, settings.right, settings.top, src, bmp.bmWidth-settings.right, 0, settings.right, settings.top, SRCCOPY);

						// Top
						StretchBlt(buf, settings.left, 0, p->width-settings.right-settings.left, settings.top, src, settings.left, 0, bmp.bmWidth-settings.right-settings.left, settings.top, SRCCOPY);

						// Bottom Left Corner
						StretchBlt(buf, 0, p->height-settings.bottom, settings.right, settings.top, src, 0, bmp.bmHeight-settings.bottom, settings.right, settings.top, SRCCOPY);

						// Bottom Right Corner
						StretchBlt(buf, p->width-settings.right, p->height-settings.bottom, settings.right, settings.top, src, bmp.bmWidth-settings.right, bmp.bmHeight-settings.bottom, settings.right, settings.top, SRCCOPY);

						// Bottom
						StretchBlt(buf, settings.left, p->height-settings.bottom, p->width-settings.left-settings.right, settings.bottom, src, settings.left, bmp.bmHeight-settings.bottom, bmp.bmWidth-settings.left-settings.right, settings.bottom, SRCCOPY);
						
						// Left
						StretchBlt(buf, 0, settings.top, settings.left, p->height-settings.top-settings.bottom, src, 0, settings.top, settings.left, bmp.bmHeight-settings.top-settings.bottom, SRCCOPY);
						
						// Right
						StretchBlt(buf, p->width-settings.right, settings.top, settings.right, p->height-settings.top-settings.bottom, src, bmp.bmWidth-settings.right, settings.top, settings.right, bmp.bmHeight-settings.top-settings.bottom, SRCCOPY);
						
						// Client
						StretchBlt(buf, settings.left, settings.top, p->width-settings.left-settings.right, p->height-settings.top-settings.bottom, src, settings.left, settings.top, bmp.bmWidth-settings.left-settings.right, bmp.bmHeight-settings.top-settings.bottom, SRCCOPY);

						if (p->width != p->ow || p->height != p->oh)
						{
							p->ow = p->width;
							p->oh = p->height;
							SetWindowBitmapRgn(hwnd, buf);
						}
					}
					else
					{
						SetRect(&r, 0, 0, p->r.right, settings.top);

						if (p->bg == RED) 
						{
							title = CreateSolidBrush(RGB(GetRValue(p->bg)-55, 0, 0));
							FillRect(buf, &p->r, settings.RED_BRUSH);
						}
						else if (p->bg == GREEN) 
						{
							title = CreateSolidBrush(RGB(0, GetGValue(p->bg)-55, 0));
							FillRect(buf, &p->r, settings.GREEN_BRUSH);
						}
						else if (p->bg == BLUE) 
						{
							title = CreateSolidBrush(RGB(0, 0, GetBValue(p->bg)-55));
							FillRect(buf, &p->r, settings.BLUE_BRUSH);
						}
						else if (p->bg == YELLOW) 
						{
							title = CreateSolidBrush(RGB(GetRValue(p->bg)-55, GetGValue(p->bg)-55, 0));
							FillRect(buf, &p->r, settings.YELLOW_BRUSH);
						}
						else if (p->bg == CYAN) FillRect(buf, &p->r, settings.CYAN_BRUSH);
						else if (p->bg == MAGENTA) FillRect(buf, &p->r, settings.MAGENTA_BRUSH);
						else if (p->bg == WHITE) 
						{
							title = CreateSolidBrush(RGB(GetRValue(p->bg)-55, GetGValue(p->bg)-55, GetBValue(p->bg)-55));
							FillRect(buf, &p->r, GetStockObject(WHITE_BRUSH));
						}
						else if (p->bg == BLACK) 
						{
							title = CreateSolidBrush(RGB(200, 200, 200));
							FillRect(buf, &p->r, GetStockObject(BLACK_BRUSH));
						}
						else
						{
							HBRUSH body;
							int r = GetRValue(p->bg);
							int g = GetGValue(p->bg);
							int b = GetBValue(p->bg);
							body = CreateSolidBrush(RGB(r,g,b));
							r-=55;
							if (r<0) r=0;
							g-=55;
							if (g<0) g=0;
							b-=55;
							if (b<0) b=0;
							title = CreateSolidBrush(RGB(r,g,b));
							FillRect(buf, &p->r, body);
							DeleteObject(body);
						}

						FillRect(buf, &r, title);
					}

					SelectObject(buf, p->font);
					SetBkMode(buf, TRANSPARENT);
					SetTextColor(buf, p->fg);

					if (!IsWindowVisible(p->edit))
					{
						char temp[2048] = "";
						RECT d;

						GetWindowText(p->edit, temp, 2048);
						
						SetRect(&d, p->r.left+settings.left+1, p->r.top+settings.top+1, p->r.right-settings.right-1, p->r.bottom-settings.bottom-1);
						DrawText(buf, temp, -1, &d, DT_CALCRECT | DT_EDITCONTROL | DT_WORDBREAK | p->align);

						if (d.bottom > (p->r.bottom-settings.bottom-1))
						{
							char* t = temp;
							int c=0;
							if (!IsWindowVisible(p->track)) ShowWindow(p->track, SW_SHOW);
							SetRect(&d, d.left, d.top, p->r.right-settings.right-settings.track_w-1, p->r.bottom-settings.bottom-1);

							for (c=0; c<p->trackoffset && t; c++)
							{
								t = strstr(t, "\n");
								if (t) t++;
							}
							p->trackoffset=c;

							DrawText(buf, t, -1, &d, DT_EDITCONTROL | DT_WORDBREAK | p->align);
						}
						else 
						{
							if (IsWindowVisible(p->track)) ShowWindow(p->track, SW_HIDE);
							DrawText(buf, temp, -1, &d, DT_EDITCONTROL | DT_WORDBREAK | p->align);
						}
					}

					BitBlt(hdc, 0, 0, p->width, p->height, buf, 0, 0, SRCCOPY);

					SelectObject(buf, oldbuf);
					DeleteDC(buf);
					DeleteObject(bufbmp);
					DeleteObject(oldbuf);
					SelectObject(src, oldsrc);
					DeleteDC(src);
					DeleteObject(oldsrc);
					DeleteObject(title);
					EndPaint(hwnd, &ps);
					DeleteDC(hdc);

					InvalidateRect(p->close, NULL, TRUE);
				}
				else break;
			}
			break;

			case WM_ACTIVATE:
			{	
				if (p)
				{
					if (!IsWindowVisible(p->edit)) break;
				}
				else break;
			}

			case WM_LBUTTONDBLCLK:
			{
				if (!p) return 0;

				if (IsWindowVisible(p->edit))
				{			
					ShowWindow(p->edit, SW_HIDE);
					GetWindowText(p->edit, p->data, 2048);
					InvalidateRect(hwnd, NULL, TRUE);
				}
				else
				{
					ShowWindow(p->edit, SW_SHOWNORMAL);
					ShowWindow(p->track, SW_HIDE);
					SetFocus(p->edit);
				}
			}
			break;

			case WM_MOUSEMOVE:
			{
				SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
			}
			break;

			case WM_KEYDOWN:
			{
				int key = (int)wParam;
				if (key == 46) SendMessage(hwnd, WM_COMMAND, (WPARAM)M_DELETE_NOTE, 0);
				else if (key == 9 || key == 16 || key == 17 || key == 20 ||
						 key == 91 || key == 92 || key == 93) break;
				else
				{
					if (p)
					{
						ShowWindow(p->edit, SW_SHOWNORMAL);
						SetFocus(p->edit);
					}
				}

				//char temp[256] = "";
				//sprintf(temp, "%d", key);
				//MessageBox(hwnd, temp, szAppName, MB_SYSTEMMODAL);
			}
			break;

			case WM_WINDOWPOSCHANGING:
			{
				if (p)
				{
					WINDOWPOS* pos = (WINDOWPOS*)lParam;
					
					if (!(pos->flags & SWP_NOMOVE))
					{		
						if (pos->x+settings.width >= settings.ScreenX-5) pos->x = settings.ScreenX - settings.width;
						else if (pos->x <= 5) pos->x = 0;
						if (pos->y+settings.height >= settings.ScreenY-5) pos->y = settings.ScreenY - settings.height;
						else if (pos->y <= 5) pos->y = 0;
						
						p->pos.x = pos->x;
						p->pos.y = pos->y;
					}

					if ((pos->cx != p->width || pos->cy != p->width) && (pos->cx && pos->cy))
					{
						p->width = pos->cx;
						p->height = pos->cy;
						GetClientRect(hwnd, &p->r);
						SetWindowPos(p->edit, 0, 0, 0, pos->cx-settings.left-settings.right, pos->cy-settings.top-settings.bottom, SWP_NOMOVE | SWP_NOZORDER);
						SetWindowPos(p->close, 0, 
							(settings.closex < 0)? p->width+settings.closex : settings.closex,
							(settings.closey < 0)? p->height+settings.closex : settings.closey,
							0, 0, SWP_NOSIZE | SWP_NOZORDER);
						SetWindowPos(p->track, 0, p->width-settings.right-settings.track_w, settings.top, settings.track_w, p->height - settings.top - settings.bottom, SWP_NOZORDER);
						InvalidateRect(hwnd, NULL, TRUE);
					}
				}
			}
			break;

			case WM_RBUTTONDOWN:
			{
				DWORD dw = GetMessagePos();
				TrackPopupMenu(settings.NOTE_MAIN_MENU, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
			}
			return 0;

			case WM_NCRBUTTONDOWN:
			{
				DWORD dw = GetMessagePos();
				TrackPopupMenu(settings.NC_MENU, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
			}
			break;

			case WM_SYSCOMMAND:
			{
				switch (wParam)
				{
					case SC_CLOSE: SendMessage(hwnd, WM_COMMAND, (WPARAM)M_DELETE_NOTE, 0); break;
				}
			}
			break;

			case WM_COMMAND:
			{
				switch (wParam)
				{
					case BN_CLICKED:
					{
						SendMessage(hwnd, WM_COMMAND, (WPARAM)M_DELETE_NOTE, 0);
					}
					break;

					case M_NEW_NOTE:
					{
						BangNewNote(settings.desktop, "");
					}
					break;

					case M_HIDE_NOTE:
					{
						ShowWindow(hwnd, SW_HIDE);
					}
					break;

					case M_FONT:
					{
						CHOOSEFONT cf;
						LOGFONT lf;
						
						strcpy(lf.lfFaceName, p->fontname);
						lf.lfItalic = 0;
						lf.lfStrikeOut = 0;
						lf.lfUnderline = 0;
						lf.lfHeight = -MulDiv(p->fontsize, GetDeviceCaps(GetDC(p->hwnd), LOGPIXELSY), 72);
						
						cf.lStructSize = sizeof(CHOOSEFONT);
						cf.hwndOwner = p->hwnd;
						cf.hDC = (HDC)NULL;
						cf.lpLogFont = &lf;
						cf.iPointSize = 0;
						cf.Flags = CF_SCREENFONTS | CF_EFFECTS | CF_INITTOLOGFONTSTRUCT;
						cf.rgbColors = p->fg;
						cf.lCustData = 0L;
						cf.lpfnHook = (LPCFHOOKPROC)NULL;
						cf.lpTemplateName = (LPSTR)NULL;
						cf.hInstance = (HINSTANCE) NULL;
						cf.lpszStyle = (LPSTR)NULL;
						cf.nFontType = SCREEN_FONTTYPE; 
						cf.nSizeMin = 0;
						cf.nSizeMax = 0;
		
						if (ChooseFont(&cf))
						{
							CHARFORMAT2* cf2 = (CHARFORMAT2*)malloc(sizeof(CHARFORMAT2));

							p->fg = cf.rgbColors;
							p->fontsize = cf.iPointSize/10;
							strcpy(p->fontname, lf.lfFaceName);
							DeleteObject(p->font);
							p->font = NULL;
							p->font = CreateFont(p->fontsize, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, p->fontname);

							cf2->cbSize = sizeof(CHARFORMAT2);
							cf2->dwMask = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_WEIGHT;
							cf2->dwEffects = 0;
							cf2->crTextColor = p->fg;
							strcpy(cf2->szFaceName, p->fontname);
							cf2->yHeight = p->fontsize*12;
							cf2->wWeight = 0;
							SendMessage(p->edit, EM_SETCHARFORMAT, (WPARAM)SCF_ALL, (LPARAM)(CHARFORMAT2 FAR*)cf2);

							InvalidateRect(p->hwnd, NULL, TRUE);
						}
					}
					break;

					case M_DELETE_NOTE:
					{
						if (settings.confirmdelete)
						{
							if (MessageBox(hwnd, "Are you sure you would like to delete this note?", szAppName, MB_SYSTEMMODAL | MB_YESNO) == IDNO) break;
						}

						if (p)
						{
							DeleteObject(p->font);
							RemoveProp(hwnd, "NOTE");
						}

						DestroyWindow(hwnd);
					}
					break;

					case M_ABOUT:
					{
						MessageBox(hwnd, "LSNotes v2.1\n\nWritten By: MrJukes\n", "LSNotes", MB_SYSTEMMODAL);
					}

					case M_EDIT_NOTE:
					{
						HWND edit = FindWindowEx(hwnd, NULL, "Edit", NULL);
						ShowWindow(edit, SW_SHOWNORMAL);
						SetFocus(edit);
					}
					break;

					case M_ALIGN_LEFT:
					{
						p->align = DT_LEFT;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_ALIGN_CENTER:
					{
						p->align = DT_CENTER;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_ALIGN_RIGHT:
					{
						p->align = DT_RIGHT;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_RED:
					{
						p->bg = RED;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_GREEN:
					{
						p->bg = GREEN;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_BLUE:
					{
						p->bg = BLUE;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_YELLOW:
					{
						p->bg = YELLOW;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_WHITE:
					{
						p->bg = WHITE;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_BG_BLACK:
					{
						p->bg = BLACK;
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_RED:
					{
						p->fg = RED;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_GREEN:
					{
						p->fg = GREEN;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_BLUE:
					{
						p->fg = BLUE;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_YELLOW:
					{
						p->fg = YELLOW;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_WHITE:
					{
						p->fg = WHITE;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					case M_TX_BLACK:
					{
						p->fg = BLACK;
						SetRichEditTextColor(p->edit, p->fg);
						InvalidateRect(hwnd, NULL, TRUE);
					}
					break;

					default:
					{
						if (wParam - M_BG_CUSTOM >= 0 && wParam - M_BG_CUSTOM < 10)
						{
							p->bg = settings.CC[wParam-M_BG_CUSTOM];
							InvalidateRect(hwnd, NULL, TRUE);
						}
						else if (wParam - M_TX_CUSTOM >= 0 && wParam - M_TX_CUSTOM < 10)
						{
							p->fg = settings.CC[wParam-M_TX_CUSTOM];
							SetRichEditTextColor(p->edit, p->fg);
							InvalidateRect(hwnd, NULL, TRUE);
						}
					}
					break;
				}
			}
			break;
		}
	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}

LRESULT CALLBACK TrackProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	struct NOTE* p = (struct NOTE*)GetProp(GetParent(hwnd), "NOTE");
	
	if (p)
	{
		switch (message)
		{
			case WM_PAINT:
			{
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hwnd, &ps);
				HDC src = CreateCompatibleDC(NULL);
				RECT r;
				GetWindowRect(hwnd, &r);

				SelectObject(src, settings.trackbmp);
				BitBlt(hdc, 0, 0, r.right-r.left, settings.track_up, src, 0, 0, SRCCOPY);
				StretchBlt(hdc, 0, settings.track_up, r.right-r.left, r.bottom-r.top-settings.track_up-settings.track_down, src, 0, settings.track_up, settings.track_w, settings.track_h-settings.track_up-settings.track_down, SRCCOPY);
				BitBlt(hdc, 0, r.bottom-r.top-settings.track_down, r.right-r.left, settings.track_down, src, 0, settings.track_h-settings.track_down, SRCCOPY);

				DeleteDC(src);
				EndPaint(hwnd, &ps);
			}
			break;

			case WM_LBUTTONDOWN:
			{
				int lc = SendMessage(p->edit, EM_GETLINECOUNT, 0, 0);
				int y = HIWORD(lParam);
				int newoffset=0;
				RECT r;
				GetClientRect(hwnd, &r);

				if (y < settings.track_up) newoffset = -1;
				else if (y > r.bottom - settings.track_down) newoffset = 1;
				else if (y < p->scrolly) newoffset = -5;
				else if (y > p->scrolly) newoffset = 5;

				p->trackoffset += newoffset;
				p->USEOFFSET = TRUE;
				SetWindowPos(p->scroll, 0, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
			}
			break;

			case WM_MOUSEMOVE: SetCursor(LoadCursor(NULL, IDC_ARROW)); break;
			case WM_ERASEBKGND: return 0;
		}
	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}

LRESULT CALLBACK ScrollProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	struct NOTE* p = (struct NOTE*)GetProp(GetParent(GetParent(hwnd)), "NOTE");
	
	if (p)
	{
		switch (message)
		{
			case WM_NCHITTEST: return HTCAPTION;
			case WM_MOUSEMOVE: SetCursor(LoadCursor(NULL, IDC_ARROW)); break;
			case WM_ERASEBKGND: return 0;

			case WM_NCPAINT:
			case WM_PAINT:
			{
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hwnd, &ps);
				HDC src = CreateCompatibleDC(NULL);

				SelectObject(src, settings.scrollbmp);
				BitBlt(hdc, 0, 0, settings.scroll_w, settings.scroll_h, src, 0, 0, SRCCOPY);

				DeleteDC(src);
				EndPaint(hwnd, &ps);
			}
			break;

			case WM_NCLBUTTONDOWN: p->USEOFFSET=FALSE; break;

			case WM_WINDOWPOSCHANGING:
			{
				WINDOWPOS* pos = (WINDOWPOS*)lParam;
				int lc = SendMessage(p->edit, EM_GETLINECOUNT, 0, 0);
				RECT r;
				GetClientRect(p->track, &r);
				
				pos->x = settings.track_w/2 - settings.scroll_w/2;

				if (p->USEOFFSET)
				{
					p->USEOFFSET=FALSE;
				}
				else
				{
					if (pos->y < settings.track_up) pos->y = settings.track_up;
					else if (pos->y > (r.bottom-settings.track_down-settings.scroll_h)) pos->y = r.bottom-settings.track_down-settings.scroll_h;
					p->trackoffset = (int)((float)(lc * (pos->y - settings.track_up)) / (float)(r.bottom-settings.track_down-settings.scroll_h));
				}

				if (p->trackoffset > 0) pos->y = (int)((float)(p->trackoffset * (r.bottom-settings.track_down-settings.track_up)) / (float)(lc-1)) + settings.track_up;
				else pos->y = settings.track_up;

				if (pos->y < settings.track_up) pos->y = settings.track_up;
				else if (pos->y > (r.bottom-settings.track_down-settings.scroll_h)) pos->y = r.bottom-settings.track_down-settings.scroll_h;
					
				p->scrolly = pos->y;
				InvalidateRect(p->hwnd, NULL, TRUE);
			}
			break;
		}
	}

	return DefWindowProc(hwnd,message,wParam,lParam);
}

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = NoteProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	wc.style = CS_DBLCLKS;

	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = TrackProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = "MJTrack";   // our window class name
	wc.style = 0;

	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", "MJTrack", MB_OK);
		return 1;
	}

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = ScrollProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = "MJScroll";   // our window class name
	wc.style = 0;

	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", "MJScroll", MB_OK);
		return 1;
	}
    
	AddBangCommand("!NewNote", BangNewNote);
	AddBangCommand("!NextNote", BangNextNote);
	AddBangCommand("!HideNote", BangHideNote);
	AddBangCommand("!HideAllNotes", BangHideAllNotes);
	AddBangCommand("!ShowAllNotes", BangShowAllNotes);
	AddBangCommand("!DeleteNote", BangDeleteNote);

	sprintf(settings.notefile, "%s\\lsnotes.lsn", szPath);

	settings.hInstance = dllInst;
	settings.parent = parent;

	settings.hwndAbout = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, "", WS_POPUP, 0, 0, 0, 0, parent, NULL, dllInst, NULL);
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)settings.hwndAbout, (LPARAM)msgs);
  
	LoadSettings();

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, 0};
	HWND hwnd;
	int x=0;

	DestroyWindow(settings.hwndAbout);

	DeleteFile(settings.notefile);

	while ((hwnd = FindWindow(szAppName, NULL)) != NULL)
	{
		struct NOTE* p = (struct NOTE*)GetProp(hwnd, "NOTE");
		
		if (p)
		{
			SaveNote(p, x++);
			RemoveProp(hwnd, "NOTE");
			DestroyWindow(hwnd);
			DeleteObject(p->font);
			free(p);
		}
	}

	// Bangs
	RemoveBangCommand("!NewNote");
	RemoveBangCommand("!NextNote");
	RemoveBangCommand("!HideNote");
	RemoveBangCommand("!HideAllNotes");
	RemoveBangCommand("!ShowAllNotes");
	RemoveBangCommand("!DeleteNote");

	// Bitmaps
	DeleteObject(settings.bgbmp);
	DeleteObject(settings.closebmp);
	DeleteObject(settings.closeclickbmp);
	DeleteObject(settings.trackbmp);
	DeleteObject(settings.scrollbmp);

	// Brushes
	DeleteObject(settings.RED_BRUSH);
	DeleteObject(settings.GREEN_BRUSH);
	DeleteObject(settings.BLUE_BRUSH);
	DeleteObject(settings.YELLOW_BRUSH);
	DeleteObject(settings.CYAN_BRUSH);
	DeleteObject(settings.MAGENTA_BRUSH);

	// Menus
	DestroyMenu(settings.NOTE_MAIN_MENU);
	DestroyMenu(settings.NOTE_BGCOLOR_MENU);
	DestroyMenu(settings.NOTE_TXCOLOR_MENU);
	DestroyMenu(settings.NOTE_BGCUSTOM_MENU);
	DestroyMenu(settings.NOTE_TXCUSTOM_MENU);
	DestroyMenu(settings.NOTE_ALIGN_MENU);
	DestroyMenu(settings.NC_MENU);
	
	SendMessage(settings.parent, LM_UNREGISTERMESSAGE, (WPARAM)settings.hwndAbout, (LPARAM)msgs);
	UnregisterClass(szAppName, settings.hInstance);
	UnregisterClass("MJTrack", settings.hInstance);
	UnregisterClass("MJScroll", settings.hInstance);
 	return 0;
}

void SetWindowBitmapRgn(HWND hwnd, HDC hdc)
{
	if (hwnd && hdc)
	{
		int x=0, y=0;
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		RECT r;
		GetClientRect(hwnd, &r);
		hMainRgn = CreateRectRgn(0, 0, r.right, r.bottom);

		// Top Border
		for (y=0; y <= settings.top; y++)
		{
			for (x=0; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}

		// Left and Right Borders
		for (y=settings.top; y <= r.bottom-settings.bottom; y++)
		{
			for (x=0; x < settings.left; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}

			for (x=r.right-settings.right; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		// Bottom Border
		for (y=r.bottom-settings.bottom; y < r.bottom; y++)
		{
			for (x=0; x < r.right; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == RGB(255, 0, 255))
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, TRUE);

		DeleteObject(hTransRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}