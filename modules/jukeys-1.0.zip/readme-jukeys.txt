//////////////////////////
// Module: jukeys v1.0
// Written By: MrJukes
// Released: 9/26/00
//////////////////////////

what is it
============
jukeys is a replacement for hotkey.dll.  It has pretty much the same functionality except
that is has hotkey groups.  This means you can have multiple functionalities assigned to the
same hotkeys depending on the current group.  

how to load it
================
LoadModule c:\litestep\jukeys.dll

step.rc
==========
jukeysStartHidden
jukeysAlwaysOnTop
jukeysX -478
jukeysY -105
jukeysW 198
jukeysH 16
jukeysFontSize 12
jukeysFontFace "Small Fonts"
jukeysFontColor 84FF94
jukeysDefaultGroup Home ; This is the first group when jukeys is loaded
; If neither a background bmp or background color are specified
; then the background will be transparent.
jukeysBackBmp jukeysback.bmp ; This has Magic Pink(tm) support
jukeysBackColor 000000

*jukey Group Mod Key command
; Group = whatever group you want the hotkey to be in.
;   If this is multiple words "use quotes".
;   There is a group named "All" that will always be active no matter
;   what the current group is.
; Mod = Win or Alt or Ctrl or Win+Alt or Win+Ctrl etc...
; Key = The key you want to set the hotkey to
; command = exe or !bang command you want executed

bangs
=======
!jukeysShow
!jukeysHide
!jukeysToggle
!jkSwitchTo Group ; Makes Group the active group

example setup
===============
*jukey All Win H !jkSwitchTo Home
*jukey All Win R !FocusCommand

*jukey Home Win A !jkSwitchTo Applications
*jukey Home Win I !jkSwitchTo Internet
*jukey Home Win S !jkSwitchTo System

*jukey System Win E notepad $LitestepDir$step.rc
*jukey System Win Q !Quit
*jukey System Win T !Recycle

*jukey Internet Win F h:\leapftp\leapftp.exe
*jukey Internet Win I iexplore.exe
*jukey Internet Win M h:\mirc\mirc32.exe
*jukey Internet Win N "$netscape$"

*jukey Applications Win C calc.exe
*jukey Applications Win N notepad.exe
*jukey Applications Win V "c:\program files\microsoft visual studio\common\msdev98\bin\msdev.exe"
*jukey Applications Win W winword.exe

Have fun,
	MrJukes
