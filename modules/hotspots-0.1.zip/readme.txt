----------------------------------------------------------------
hotspots.dll   v0.1			09/06/99
----------------------------------------------------------------
Pavel Vitis



What are "hotspots.dll"?
================================================================

Hotspots is my experimental module, now in very early stage of
completion.
It allows you to define hot areas on the screen called "hotspots"
that will trigger event (run program or !bang command) when
the mouse pointer passes in the area and stays here awhile.

I programmed this to simulate "active borders", nice feature
included in famous Pointix (Pop-Mouse) utility by
Pointix Company (http://www.pointix.com/).


Installation
================================================================

Installation is simple. Load the module in your step.rc as:

LoadModule "c:\litestep\hotspots.dll"

Copy hotspots.dll directly into your Litestep directory.

Then edit your step.rc and define some hotspots. The syntax
is:

*Hotspot "Name" X-position Y-position Width Height Delay "Action"

-  "Name" is the unique identifier of the hotspot, not used yet,
included for future needs. Use some descriptive name here.

-  Positions and Sizes are in pixels.

-  Delay is the time interval (in 1/10 sec) that defines how
long should mouse pointer stay in the hotspot area before
triggering associated action. It is here to avoid accidental
actions when working with mouse.

- "Action" can be any executable, file, or !bang command. If the
non-executable file is specified, it will activate application
associated to file-type, if any.


You can also define sound that will play when action is triggered:

HotspotBeep "path_to\beep.wav"


Example
================================================================

There I provide example settings for 1024x768 resolution.
I define three active borders on the left, right and top of
the screen to run frequently used applications (substitute
yours). Next I define four hot corners, top-left to instantly
activate screen-saver, top-right to disable screen-saver,
bottom-left to shutdown windows and bottom-right to run step.rc
editor:


HotSpotBeep "c:\sounds\tick.wav"

*Hotspot "Left" 0 2 2 764 4 "notepad.exe"
*Hotspot "Right" 1022 2 2 764 4 "calc.exe"
*Hotspot "Top" 2 0 1020 2 10 "explorer.exe"
*Hotspot "TopLeft" 0 0 2 2 10 !ActivateScreenSaver
*Hotspot "TopRight" 1022 0 2 2 10 !DisableScreenSaver
*Hotspot "BottomLeft" 0 766 2 2	10 !Shutdown
*Hotspot "BottomRight" 1022 766 2 2 10 "notepad c:\litestep\step.rc"


Features, limitations
================================================================

If any of your hotspots will overlap, the control over overlapped
region takes hotspot in step.rc defined later. They are
defined "from bottom to topmost".

In this version you cannot attach action to mouse leaving the
hotspot. So the setting for !DisableScreenSaver in example above
is slightly uselles now, because it will stay in disabled state
even when the mouse cursor leaves top-right corner. It will be
fixed in next versions.


Plans for future versions
================================================================

1. There should be more control over on-the-fly changing of
hotspots, via !bang commands.

2. Add support for Shift/Ctrl/Alt key modifiers

3. Specify flags for starting of applications - start minimized,
hidden, only one instance, etc.

4. Allow the "ScreenWidth" and "ScreenHeight" constants in
the hotspot definition to easy snap the hotspots at screen
borders when changing screen resolution.

5. ...... fill in the blanks yourself :)


Version history
================================================================

v0.1		09/06/99
	- First release



Contact & info
================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www   : http://come.to/pavel.vitis/

Programmed in Delphi 3, usind LSDevKit (modified TR3) by Murphy:
http://www.dev0.de/
