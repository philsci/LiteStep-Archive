*** DeaskMenu v 0.1
** by _TAG_ <dream.king@iol.it>


*** installation
- unzip deskmenu.dll in your LS directory (e.g. c:\litestep\)
- add this line to your step.rc
	LoadModule C:\LITESTEP\deskmenu.dll
  where (of course) C:\litestep\ is the directory in which deskmenu.dll is.


*** settings
DeskMenu gets its settings from the step.rc; it behaves like the popup and will
look like it in every aspect (bitmaps, stretching, etc.).
Still it is not as stupid as you think...
It gets its structure from the step.rc and uses a syntax like the popup, but, instead
of *popup it uses *deskmenu
e.g. 
	*deskmenu Programmi "!PopupFolder:C:\Windows\Menu Avvio\Programmi"
	*deskmenu ShufflePlay C:\mp3enc\ShufflePlay2\shuffle2.exe
	*deskmenu CodAxe C:\mp3enc\CodAXE\Codaxe.exe
	*deskmenu WinDAC C:\mp3enc\WINDAC32\WinDAC32.exe
	*deskmenu Rain C:\bin\Rain.exe
	*deskmenu "Visual C++ 5.0" C:\Programmi\DevStudio\SharedIDE\bin\Msdev.exe
	*deskmenu "Recycling Bin" explorer /root,,::{645FF040-5081-101B-9F08-00AA002F954E}
	*deskmenu "4DOS Prompt" D:\4Dos\4DOS.pif
	*deskmenu WinAmp C:\Programmi\Winamp\Winamp.exe
	*deskmenu "Kill Win" c:\litestep\links\shutdown.lnk
as you can see it copies the popup in every aspect, as you can use !PopupFolder ,
!PopupDynamicFolder , !PopupTasks and Folder .

I've only added two 'size' keys, to differenciate it from the popup:
DeskMenuIconSize ##		(defaults to 16)
DeskMenuSubmenuHeight ##	(defaults to 20)
the former changes the size of the icons (if they are showed), the latter the height of
the menu items (if IconSize>SubmenuHeight then IconSize=SubmenuHeight).
If DeskMenuIconSize is > 25 then DeskMenu gets the big icon from the application (the
32x32 one) not the small one (so it looks better).


*** usage
It's pretty obvious:
Moving the mouse over it you highlight the items, while clicking on them you execute
whatever they're linked to... just like the popup.


*** hardcore tech infos (for LSDevs and whoever is curious enough)
[will write them as soon as I can]


*** sources
The sources are all hacked from the LS sources for the 26/04/99 build.


*** known bugs
- it doesn't close when it loses focus or when the mouse is not over it anymore (this 
  is the first thing I'll fix). 
- it gets almost all the settings from the Popup's ones (what did u expect... this is 
  a beta!), but its structure can be configured in the step.rc using 
  *deskmenu instead of *popup 
- there's something wrong... not sure what but I'll find out. 

*** thanks
#ls_help and #mindstorm (EFNet)
Fahim for his popup and everyone in the LS Dev Team!


*** contacts
write me (comments, bugs, ideas, money, girls):  dream.king@iol.it
[ flames > /dev/null ]
the 'official' site should be	http://aula6.cjb.net/
				http://users.iol.it/dream.king
ICQ UIN #1584291


*** other
[none right now]


*** history
v 0.1	29/04/99
- first release with many bugs