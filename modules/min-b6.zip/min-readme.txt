///////////////////////////////
// Minimize to Desktop Icon
// By: MrJukes (Bret Anderson)
// Released: 4/4/99
///////////////////////////////

// BETA 6
// New in this version
1) Line up icons function
2) Got rid of the phantom icons
3) User definable starting position
4) User definable direction (horizontal/vertical)

// Settings in min.ini
// The format is 0x00BBGGRR
[min]
Vertical=0
StartX=10
StartY=10
BackgroundColor=0x00000000 
TextColor=0x00FFFFFF

Left click and drag will drag the icon around.
Double click with the left will restore the window.
Right click will bring up the popup menu.

To load in your step.rc put this line AFTER loading desktop.dll:
	LoadModule c:\litestep\min.dll

Have fun,
	MrJukes