
////
/// common include
//

#ifndef __COMMON_H
#define __COMMON_H

#ifndef EXTERN_C
  #ifdef __cplusplus
    #define EXTERN_C extern "C"
  #else
    #define EXTERN_C
  #endif
#endif

#ifndef DECLSPEC_EXPORT
  #define DECLSPEC_EXPORT __declspec(dllexport)
#endif

//
// typedefs
//

typedef BOOL (*REMOVEBANGCOMMAND)( LPCTSTR );

//
// structs
//

// globals
typedef struct _GLOBALS {
	HWND hWnd;
	BOOL fAlwaysOnTop;
	BOOL fDockedToWharf;
	BOOL fHidden;
	int ScreenX;
	int ScreenY;

	int nX;
	int nY;
	int nWidth;
	int nHeight;
	HWND PanelWnds[20];
	int PanelNum;
	int TimerMsgs[100];
	int TimerNum;
	int WorldTimerID;
	int WorldTimerDelay;
	char ImageDir[255];
	int OldMouseX;
	int OldMouseY;
} GLOBALS;



//
// constants
//

// the ST_ constants should be changed to reflect
// the info for your module. if you add RC or bang
// commands add the constants here.

// strings
#define ST_SHORTNAME      TEXT("Sample")
#define ST_NAME           TEXT("Sample Module")
#define ST_VERSION        TEXT("1.0")
#define ST_AUTHOR         TEXT("Maduin")
#define ST_REVID          ST_NAME TEXT(" ") ST_VERSION TEXT(" by ") ST_AUTHOR

// window classes
#define WC_LSDESKTOP      TEXT("DesktopBackgroundClass")
#define WC_MAIN           ST_SHORTNAME

// RC commands
#define RC_NAME           ST_SHORTNAME
#define RC_ALWAYSONTOP    RC_NAME TEXT("AlwaysOnTop")
#define RC_HIDDEN         RC_NAME TEXT("Hidden")
#define RC_X              RC_NAME TEXT("X")
#define RC_Y              RC_NAME TEXT("Y")
#define RC_WIDTH          RC_NAME TEXT("Width")
#define RC_HEIGHT         RC_NAME TEXT("Height")

// bang commands
#define BC_NAME           TEXT("!") ST_SHORTNAME
#define BC_HIDE           BC_NAME TEXT("Hide")
#define BC_SHOW           BC_NAME TEXT("Show")
#define BC_TOGGLE         BC_NAME TEXT("Toggle")
#define BC_MOVE           BC_NAME TEXT("Move")

//
// global variables
//

// so we don't have a ton of extern statements,
// we place all global variables in a single
// struct.

extern GLOBALS globals;

//
// functions
//

// main window procedure
LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );

// bang command callbacks
void BangHide( HWND, LPCSTR );
void BangShow( HWND, LPCTSTR );
void BangToggleAll( HWND, LPCSTR );
void BangMove( HWND, LPCSTR );
void BangPopup( HWND, LPCSTR );
void BangUnGroup( HWND, LPCSTR );
void BangGroup( HWND, LPCSTR );
void BangToggle( HWND, LPCSTR );
void BangSnapSize( HWND, LPCSTR );
//void BangMove( HWND, LPCSTR );

#endif
