// The first test plugin for a panel
#define WIN32_LEAN_AND_MEAN

// These are our defines for panelProc
#define PPAINT									1
#define PCLICK									2
#define POVER									3
#define PLEAVE									4
#define PTIMER									5


#include <windows.h>
#include <winuser.h>
#include <commctrl.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "common.h"
#include "PanelPlugin.h"

// Prototypes
BOOL SendDebugMessage(LPCTSTR message, BOOL Erase);
EXTERN_C DECLSPEC_EXPORT int initPanelPlugin(HWND);
EXTERN_C DECLSPEC_EXPORT HDC getPluginBuffer();
EXTERN_C DECLSPEC_EXPORT int panelPluginProc(int Call, LPCSTR Args, LPARAM);
int Timer();
int Paint();
void SetBuffer(HDC);
void UpdateTime();

// Globals
// Bad programming style I know

// The Panel's wnd to draw to
HWND PanelWnd;
// The text on the plugin
char PluginText[255];
// The variable to tell which text to use
int Blah = 0;
// The window rectangle
RECT WindowRect;
// The World Timer
int CurrentTimer = 1;
// Was the time updated last time?
int TimeUpdated = 1;
// Transparent brush (always useful)
HBRUSH TransBrush = CreateSolidBrush(RGB(255,0,255));
// This is the character in between the time
char MiddleChar[2] = ":";
// This is the option to have the colonon blink.  This hogs resources a bit
int Blinker = 0;
// The over var
int Over = 0;

// This inits the plugin.  You must have this function.
EXTERN_C DECLSPEC_EXPORT int initPanelPlugin(HWND CallingWnd)
{

	// Set the global panel window to the calling panels wnd
	PanelWnd = CallingWnd;
	
	// Get the rectangle for the window
	GetClientRect(PanelWnd, &WindowRect);

	// Set the text to nothing
	strcpy(PluginText, "");

	// Set up the plugin buffer
	SetupPluginBuffer(PanelWnd);

	// Format the text
	SetBkMode(pluginBuffer, TRANSPARENT);
	SetTextColor(pluginBuffer, RGB(117,160,255));
	
	return 1;
}



// Paint the plugin

int Paint()
{
	if(TimeUpdated == 1)
	{
		// Fill the plugin buffer with magic pink
		FillRect(pluginBuffer, &WindowRect, TransBrush);

		// Draw the current time string to the plugin buffer
		DrawText(pluginBuffer, PluginText, strlen(PluginText), &WindowRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

		// Tell LSPanels to update the panel		
		UpdatePanel(PanelWnd);
				
		// Set timeupdated to 0, so it will update next time the time changes
		TimeUpdated = 0;
	}

	return 1;
}


// This is the processor for plugin "messages"
// See defines above
// You must have this function

EXTERN_C DECLSPEC_EXPORT int panelPluginProc(int Call, LPCSTR Args, LPARAM lParam)
{
	switch(Call)
	{

	case PPAINT:
		{
			SendDebugMessage("Plugin paint through panelProc", false);
			Paint();
			break;
		}

	case PCLICK:
		{
			SendDebugMessage("Panel click through panelProc", false);
			if(Blinker == 1)
				Blinker = 0;
			else
				Blinker = 1;
			break;
		}

	case PTIMER:
		{
			Timer();
			break;
		}
	
	case POVER:
		{
			if(Over != 1)
			{
				SetTextColor(pluginBuffer, RGB(167,210,255));
				TimeUpdated = 1;
				Paint();
				Over = 1;
			}
			break;
		}

	case PLEAVE:
		{
			SendDebugMessage("Mouse left plugin", false);
			if(Over != 0)
			{
				SetTextColor(pluginBuffer, RGB(117,160,255));
				TimeUpdated = 1;
				Paint();
				Over = 0;
			}
			break;
		}

	}

	return 1;
}



int Click()
{
	SendDebugMessage("Plugin click received", false);
	return 1;
}



// This is called every world timer (10 msec)

int Timer()
{
	if(CurrentTimer * 10 == 1000)
	{
		CurrentTimer = 1;

		if(MiddleChar[0] == ':' && Blinker == 1)
			MiddleChar[0] = ' ';
		
		else 
		
		if(MiddleChar[0] == ' ' && Blinker == 1)
			MiddleChar[0] = ':';

		UpdateTime();
		Paint();
	}

	else
		CurrentTimer++;

	return 1;
}


// Update the time string
void UpdateTime()
{
	time_t CurrentTime;
	struct tm* StTime;
	char Time[10];
	char TempTime[10];
	char TempTime2[10];
	int TempNum;


	time(&CurrentTime);
	StTime = localtime(&CurrentTime);
	strftime(TempTime, sizeof(TempTime), "%I", StTime);
	TempNum = atoi(TempTime);
	itoa(TempNum, Time, 10);

	if(strlen(Time) == 1)
	{
		strcpy(TempTime, "0");
		strcat(TempTime, Time);
		strcpy(Time, TempTime);
	}

	strcat(Time, MiddleChar);
	strftime(TempTime, sizeof(TempTime), "%M", StTime);
	TempNum = atoi(TempTime);
	itoa(TempNum, TempTime, 10);

	if(strlen(TempTime) == 1)
	{
		strcpy(TempTime2, "0");
		strcat(TempTime2, TempTime);
		strcpy(TempTime, TempTime2);
	}

	strcat(Time, TempTime);

	if(strcmp(PluginText, Time) == 0)
	{
		strcpy(PluginText, Time);
		TimeUpdated = 0;
	}
	else
	{
		strcpy(PluginText, Time);
		TimeUpdated = 1;
		SendDebugMessage("Updating time", false);
	}
}



// Debug message function

BOOL SendDebugMessage(LPCTSTR message, BOOL Erase)
{
	BOOL breturn;
	typedef struct debugdata
	{
		char	strtext[255];
		bool	berase;
	} DEBUGDATA, *LPDEBUGDATA;
	DEBUGDATA *dbdata = NULL;
	HANDLE hmem;
	
	hmem = OpenFileMapping(FILE_MAP_ALL_ACCESS,FALSE,"IanDebug");
	dbdata = (DEBUGDATA *)MapViewOfFile(hmem,FILE_MAP_WRITE,0,0,sizeof(DEBUGDATA));
	if(dbdata != NULL)
	{
		strcpy(dbdata->strtext, message);
		if(Erase)
			dbdata->berase = true;
		else
			dbdata->berase = false;
		breturn = true;
	}
	else
	    breturn = false;
	UnmapViewOfFile(dbdata);
	SendMessage(FindWindow("DEBUGPAD", 0), WM_TIMER, 0, 0);
	return breturn;
}

