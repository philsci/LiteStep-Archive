// These are our defines for panelProc
#define PPAINT									1
#define PCLICK									2
#define POVER									3
#define PLEAVE									4
#define PTIMER									5

#define WM_UPDATEPANEL							WM_USER + 202

// Create a new memory dc
HDC NewDC(int, int);

// Set up the plugin buffer
void SetupPluginBuffer(HWND);

// Destroy the plugin buffer
void DestroyPluginBuffer();

// Update the panel
void UpdatePanel();

// Send LSPanels the buffer for drawing (used internally by LSPanels)
EXTERN_C DECLSPEC_EXPORT HDC getPluginBuffer();

// This is the global pluginBuffer.  Draw to this.
HDC pluginBuffer;



// Functions

// Make a memory bitmap

HDC NewDC(INT sx, INT sy)
{
 	HDC hdc;
 	HBITMAP hbm;
 	hbm = (HBITMAP)CreateCompatibleBitmap(GetDC(NULL), sx, sy);
 	hdc = (HDC)CreateCompatibleDC(GetDC(NULL));
 	SelectObject(hdc, hbm);
 	DeleteObject(hbm);
 	return hdc;
}

// This sets up the pluginBuffer for drawing
void SetupPluginBuffer(HWND PanelWnd)
{
	RECT r;
	GetClientRect(PanelWnd, &r);
	pluginBuffer = NewDC(r.right, r.bottom);
}

// This deletes the pluginBuffer from memory
void DestroyPluginBuffer()
{
	DeleteObject(SelectObject(pluginBuffer, (HBITMAP)NULL));
	DeleteDC(pluginBuffer);
}

// This sends LSPanels the buffer for drawing

EXTERN_C DECLSPEC_EXPORT HDC getPluginBuffer()
{
	return pluginBuffer;
}

// Update the panel

void UpdatePanel(HWND PanelWnd)
{
	SendNotifyMessage(PanelWnd, WM_UPDATEPANEL, NULL, NULL);
}