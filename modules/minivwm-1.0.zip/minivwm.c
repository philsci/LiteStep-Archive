/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
/****************************************************************************
 15/10/98 - B. Kilian
			Brushing off the Dust for the release. Adding the full hotkey
			Functionality and !Gather.
 07/20/98 - MholmesIV
			Removed the erroneous need for a BgBMP value in modules.ini,
			now using the standard method for getting the background BMP.
 07/18/98 - j_edge
			Moved the Hotkey stuff to after LoadStickySettings() since it
			uses inipath which is initialized in that function.
 07/15/98 - j_edge
			Added the BgBMP entry in MODULES.INI to allow user to specify a 
			different bmp than the default bmp. 
			Added the Hotkey entry in MODULES.INI to allow user to choose
			which key is pressed with arrow keys to switch virtual windows.
 06/17/98 - Sehnsucht
			Cleaned up some of the warnings
			Added window 'class' stickies
 06/16/98 - [Drizzt]
			Added transparency to the default bmp
 06/14/98 - Sehnsucht
			Changed the alt-cursors to mskey-cursors.
			Able to use alt-cursors in programs again (Netscape, IE, etc).
 06/02/98 - F. Gastellu
            This file contains the source code for the virtual window
            manager

****************************************************************************/

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <commctrl.h>

#include "minivwm.h"
#include "lsapi.h"

#define VWM_DESKNO 0x11110000;

char szAppName[] = "lsvwm"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.13 $"; // Our Version 
const char rcsId[] = "$Id: vwm.c,v 1.13 1998/12/10 23:08:15 jre Exp $"; // The Full RCS ID.

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void (__stdcall *SwitchToThisWindow)(HWND, int);
BOOL CALLBACK searchLSVWMproc(HWND hWnd, LPARAM lParam );
void BangGather(HWND caller ,char* args);

void ReadConfig (void);

void MoveCursor(int o, int n);
void prefixWinFix(int s);
void postfixWinFix(int s);
void removeWinFix(HWND hwnd);
void addWinFix(HWND hwnd, int s);
int inFix(HWND hwnd);

HWND hMainWnd=NULL; // main window handle
HWND parent;

//wharfDataType wharfData;

UINT Timer=0;
UINT TimerAct=1;

BOOL backInit=FALSE;

int wndSizeX, wndSizeY;
UINT nOffsetX, nOffsetY;
int currentScreen=0;
int ratioX, ratioY;

int ScreenWidth = 800;//1152;
int ScreenHeight = 600;//864;

HWND refToplevel;

void switchToDesktop(int desk);
void gatherAll();
int getDesktop(HWND h);
int outsideAnyScreen(RECT r);
int getDesktopByRect(RECT r);
void DoEvents(int n);
int First = 1;

int ScreensX = 2;
int ScreensY = 2;

int MaxScreens = 4;

RECT *deskRect = NULL;

winDataType winRect[500];
winFixType winFix[500];

int nWinRect=0;
int movingWin=-1;

int ticksNewW=0;
HWND newW=(HWND)-1;

HWND lastActive=NULL;
RECT oldWinPos;
POINTS lastPoint;
BOOL taskMgrSwitch=FALSE;
BOOL NoBmps = FALSE;
BOOL NeverSwitch = FALSE;

// Automatically set focus to the application
// in the midle of the sceen after having switched
// desktops.
BOOL FocusCenter = FALSE;

// Shall i test for blocked applications before
// i switch the desktop.
BOOL BlockedTimeout = FALSE;

volatile int lock=0;

int inchk=0;
int mpos=0;
UINT mTimer=2;
UINT mcTimer=3;
int mTimeout=50;

int searched=0;
HINSTANCE inst;
HWND photoshop;
HWND eudora;

BOOL autoswitch=TRUE;
int VWMDistance=2;
HWND tapp, desk, winswitch;

BOOL NoAuto = FALSE, NoGather = FALSE;

char szLitestepPath [256];
char szImagePath [256];
char inipath[256];

int backColor;
int foreColor;
int selBackColor;
int borderColor;

int borderSize = 0;

//////////// Sticky Window Config Types etc
typedef struct {
	char match[80]; //this is the matching text
	int type; //0 (default) for titlematch, 1 (must be specified) for classmatch
} StickyConfigInfoT;
StickyConfigInfoT StickyConfig[256];
////////////////////////////////
// Loads Sticky Window settings
////////////////////////////////
void LoadStickySettings()
{
	char tmpbuf[80];
	char tmpbuf2[80];
	int x, len;
	strcpy((char *)&inipath,szLitestepPath);
	len = strlen (inipath);
	if (len && inipath[len-1] != '\\')
	{
		inipath[len-1] = '\\';
	}
	strcat(inipath,"modules.ini");
	StickyConfig[0].type = GetPrivateProfileInt("lsvwm","stickies",0,inipath);
	for (x=StickyConfig[0].type;x>0;x--)
	{
		_itoa(x,(char *)&tmpbuf,10);
		strcpy((char *)&tmpbuf2,"sticky");
		strcat((char *)&tmpbuf2,(char *)&tmpbuf);
		GetPrivateProfileString("lsvwm",(char *)&tmpbuf2,"",(char *)&StickyConfig[x].match,79,inipath);
		strcpy((char *)&tmpbuf2,"stype");
		strcat((char *)&tmpbuf2,(char *)&tmpbuf);
		StickyConfig[x].type = GetPrivateProfileInt("lsvwm",(char *)&tmpbuf2,0,inipath);
	}
}

//-------------------------------------------------------------------------------------------------
// Init
//-------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}


void BangUp(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen > (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen - ScreensX);
	}
}

void BangDown(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
	{
		switchToDesktop(currentScreen+ ScreensX);
	}
}

void BangLeft(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) > 0 ) && !lock)
	{
		switchToDesktop(currentScreen-1);
	}
}

void BangRight(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen+1);
	}
}

void BangDesk(HWND caller ,char* args)
{
	RECT r;
	int i = atoi(args);

	if ((currentScreen != i) && (i >= 0) && (i < MaxScreens) && !lock)
	{
		switchToDesktop(i);
	}
}


void RegisterBangCommands(void)
{
	AddBangCommand("!GATHER", BangGather);
	AddBangCommand("!VWMUP", BangUp);
	AddBangCommand("!VWMDOWN", BangDown);
	AddBangCommand("!VWMLEFT", BangLeft);
	AddBangCommand("!VWMRIGHT", BangRight);
	AddBangCommand("!VWMDESK", BangDesk);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	HDC pDC;
	UINT Msgs[10];
//	int iHotkey;
	int XPos, YPos;
	int sze;

    memset(winFix, 0, sizeof(winFix));

	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	strcpy (szLitestepPath, szPath);

	ReadConfig ();

	MaxScreens = ScreensX * ScreensY;
	deskRect = malloc(MaxScreens * sizeof(RECT));

	for (YPos = 0; YPos < ScreensY; YPos ++)
		for (XPos = 0; XPos < ScreensX; XPos ++)
		{
			int desk = (YPos * ScreensX) + XPos;
			int top = YPos * (ScreenHeight + 10);
			int left = XPos * (ScreenWidth + 10);

			deskRect[desk].top = top;
			deskRect[desk].left = left;
			deskRect[desk].right = left + ScreenWidth;
			deskRect[desk].bottom = top + ScreenHeight;
		}

	parent = ParentWnd;
	wndSizeX = (64 - borderSize*2) / ScreensX;
	wndSizeY = (64 - borderSize*2) / ScreensY;
	nOffsetX = ((wndSizeX*ScreensX) - 64)+borderSize;
	nOffsetY = ((wndSizeY*ScreensY) - 64)+borderSize;
	ratioX = ScreenWidth/wndSizeX;
	ratioY = ScreenHeight/wndSizeY;
    inst = dllInst;

    if (NoAuto) autoswitch = FALSE;

    tapp = GetLitestepWnd();

	sze = sizeof(int) | VWM_DESKNO;

    SendMessage(tapp, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &currentScreen);

	desk = FindWindow("DesktopBackgroundClass", NULL);
    winswitch = FindWindow("#32771", NULL);
    (long)SwitchToThisWindow = (long)GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.style = CS_DBLCLKS;
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class",szAppName,MB_OK);
			return 1;
		}
	}


	hMainWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,									// exstyles 
		szAppName,												// our window class name
		szAppName,												// use description for a window title
		0,
		0, 0,													// position
		0, 0,													// width & height of window
		NULL,													// parent window
		NULL,													// no menu
		dllInst,												// hInstance of DLL
		0);														// no window creation data

	if (!hMainWnd) 
	{						   
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		return 1;
	}

	Msgs[0] = 8891;
	Msgs[1] = 9355;
	Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;

	SendMessage(tapp, 9263, (WPARAM) hMainWnd, (LPARAM) Msgs);

	RegisterBangCommands();

	//load sticky windows settings
	LoadStickySettings();

	// Determine which modifier key is being used for the hotkey & register it

	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
    SetTimer(hMainWnd, mcTimer, 50, NULL);
	return 0;

}


//-------------------------------------------------------------------------------------------------
// cleanup
//-------------------------------------------------------------------------------------------------
int quitModule(HINSTANCE dllInst)
{
	//config_write(this_mod);		// write configuration

	gatherAll();

	
/*	UnregisterHotKey(hMainWnd, 0);
	UnregisterHotKey(hMainWnd, 1);
	UnregisterHotKey(hMainWnd, 2);
	UnregisterHotKey(hMainWnd, 3);
*/
    if (mpos)
        {
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
        }
	
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);

	DestroyWindow(hMainWnd); // delete our window
	UnregisterClass(szAppName,dllInst/*this_mod->hDllInstance*/); // unregister window class

	free(deskRect);
	deskRect = NULL;
	return 0;
}


////////////////////////////////////////////////////////////////
// Checks to see if given window is supposed to be left alone
////////////////////////////////////////////////////////////////
int StickyCheck1(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetClassName(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

int StickyCheck0(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetWindowText(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

int topWindowAlways(HWND targetWin)
{
	int x;
	int issticky;
	issticky = 0;
	x = StickyConfig[0].type;
	//while we havent finished checking against windows to ignore
	while ((x > 0) && (!issticky)) {
		if (StickyConfig[x].type == 1) {issticky = StickyCheck1(targetWin,StickyConfig[x].match);}
		else {issticky = StickyCheck0(targetWin,StickyConfig[x].match);}
		x--;
	}
	return issticky;
}

//-------------------------------------------------------------------------------------------------
// window procedure for our window
//-------------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//HDC dp;

	switch (message)
	{
		case LM_GETREVID:
			{
				char *buf = (char *) lParam;

				if (wParam == 0)
				{
					strcpy(buf, "vwm.dll: ");
					strcat(buf, &rcsRevision[11]);
					buf[strlen(buf)-1] = '\0';
				}
				else if (wParam == 1)
				{
					strcpy(buf, &rcsId[1]);
					buf[strlen(buf)-1] = '\0';
				} else
				{
					strcpy(buf, "");
				}
				return strlen(buf);

			}
		case WM_CREATE:		
            return 0;
		case WM_ERASEBKGND: return 0;
		
		case 9355:
			{
				RECT r;
				int i = wParam;

				if ((currentScreen != i) && !lock)
				{
					switchToDesktop(i);
//					MessageBox(0, "Switched Windows", "VWM", MB_OK|MB_TOPMOST);
				}
				return TRUE;
			}

		case 8891: // Change window focus via message (change desktop if needed)
			//taskMgrSwitch = TRUE;
			if (lock)
            { // Try later
				PostMessage(hwnd, message, wParam, lParam);
				return TRUE;
			}
			lock = 1;
			{
				int n = getDesktop((HWND)lParam);
				if (n != currentScreen) switchToDesktop(n);
				//SetForegroundWindow((HWND)lParam);
				SwitchToThisWindow((HWND)lParam, 1);
			}
			lock=0;
			return TRUE;

/*		case WM_DISPLAYCHANGE:
            { // Intercept dynamic resolution changes
            int cxScreen = LOWORD(lParam); 
            int cyScreen = HIWORD(lParam);
            int i,d,s;
            RECT r;
            for (i=0;winRect[i].valid;i++)
	            {
                s = GetWindowLong(winRect[i].hwnd, GWL_STYLE) & WS_MAXIMIZE; 
                d = getDesktop(winRect[i].hwnd);
	            GetWindowRect(winRect[i].hwnd, &r);
                if (d & 1)
                    {
   	                r.left-=(ScreenWidth-cxScreen);
                    r.right-=(ScreenWidth-cxScreen);
                    if (s) 
                        r.right-=(ScreenWidth-cxScreen);
                    }
                if (d & 2)
                    {
                    r.top-=(ScreenHeight-cyScreen);
       	            r.bottom-=(ScreenHeight-cyScreen);
    	            if (s)
   	                    r.bottom-=(ScreenHeight-cyScreen);
                    }
                MoveWindow(winRect[i].hwnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
                ScreenWidth = cxScreen;
                ScreenHeight = cyScreen;
            	deskRect[0].top = 0;
	            deskRect[0].left = 0;
	            deskRect[0].right = ScreenWidth;
	            deskRect[0].bottom = ScreenHeight;
	            deskRect[1].top = 0;
	            deskRect[1].left = ScreenWidth+10;
	            deskRect[1].right = ScreenWidth*2+10;
	            deskRect[1].bottom = ScreenHeight;
	            deskRect[2].top = ScreenHeight+10;
	            deskRect[2].left = 0;
	            deskRect[2].right = ScreenWidth;
	            deskRect[2].bottom = ScreenHeight*2+10;
	            deskRect[3].top = ScreenHeight+10;
	            deskRect[3].left = ScreenWidth+10;
	            deskRect[3].right = ScreenWidth*2+10;
	            deskRect[3].bottom = ScreenHeight*2+10;
                }
            }
        return 0;
*/
	case WM_TIMER:
		{ 
			if (lock) // cancel
				return 0;
            if (wParam == mTimer)
            {
                if (autoswitch)
                { // We need to autoswitch (mouse stayed longer than timeout onb a border of the screen)
                    int nmpos=0;
                    int newScreen = currentScreen;
                    DWORD a = GetMessagePos();
                    POINTS pts;
                    pts = MAKEPOINTS(a);

                    if (pts.x == 0) nmpos |= 1;
                    if (pts.y == 0) nmpos |= 2;
                    if (pts.x == ScreenWidth-1) nmpos |= 4;
                    if (pts.y == ScreenHeight-1) nmpos |= 8;

                    if (nmpos)
                    {
                        if ((nmpos & 1) && ((currentScreen % ScreensX) > 0))
	                            newScreen--;
                        if ((nmpos & 2) && ((currentScreen / ScreensX) > 0))
		                        newScreen -= ScreensX;
                        if ((nmpos & 4) && ((currentScreen % ScreensX) < (ScreensX - 1)))
                                newScreen++;
                        if ((nmpos & 8) && ((currentScreen / ScreensX) < (ScreensY - 1)))
                                newScreen += ScreensX;
                    
                        if (currentScreen != newScreen)
                        {
                            RECT r;
                            MoveCursor(currentScreen, newScreen);
                            switchToDesktop(newScreen);
    
                            mpos = 0;
                        }
                    }
                }
                KillTimer(hMainWnd, mTimer);
                return 0;
            }
            else
                if (wParam == mcTimer)
                {
                    POINTS pts;
                    DWORD a = GetMessagePos();
                    int nmpos = 0;
                    pts = MAKEPOINTS(a);

                    if (pts.x == 0) nmpos |= 1;
                    if (pts.y == 0) nmpos |= 2;
                    if (pts.x == ScreenWidth-1) nmpos |= 4;
                    if (pts.y == ScreenHeight-1) nmpos |= 8;

                    if (!nmpos)
                    {
                        if (mpos)
                        {
                            KillTimer(hMainWnd, mTimer);
                            mpos = 0;
                        }
                    }
                    else
                    {
                        if (!mpos)
                        {
                            mpos = nmpos;
                            SetTimer(hMainWnd, mTimer, mTimeout, NULL);
                        }
                    }
                    return 0;
                }

           	lock = 1;

            if (!wParam) // main timer, update view, check focus change
            {
			}
            else
   			{
   				int style=0;
    			int a=0;
	    		RECT r;
		    	HWND newFGWin = GetForegroundWindow();

   				if (newFGWin)
    			{
	    			style = GetWindowLong(newFGWin, GWL_STYLE);
		    		a = GetWindowLong(newFGWin, GWL_USERDATA);
			   	}
				
    			if ((newFGWin != lastActive) && !NeverSwitch)
	    		{
// This causes a timeout to be applied against focus change, obsolete?
//		   			if (newFGWin == newW)
//		    			{
//			    		ticksNewW++;
//				    	if (ticksNewW > 0)
//					    	{
							if (newFGWin)
							{
								GetWindowRect(newFGWin, &r);
								if (!outsideAnyScreen(r) && 
									!(a == magicDWord || !newFGWin || (newFGWin && IsIconic(newFGWin)) || 
    								  !(style & WS_VISIBLE) || (style & WS_DISABLED) || 
	    							  (lastActive && IsWindow(lastActive) && IsIconic(lastActive)) ||
									  (lastActive && !IsWindow(lastActive))
		   							  || (!taskMgrSwitch && lastActive && GetWindowLong(lastActive, GWL_USERDATA) == magicDWord))
		    						 )
			   					{
				    				int newScr = getDesktop(newFGWin);
					    			if (newScr != currentScreen)
						    			switchToDesktop(newScr);
									taskMgrSwitch=FALSE;
    							}
							}
	    					lastActive = newFGWin;
// End timeout
//		   					newW = (HWND)-1;
//		    				}
//			    		}
//				    else
//  					{
//	    				newW = newFGWin;
//		   				ticksNewW = 0;
//		    			}
			    	}
                }
			}
			lock = 0;
		return 0;

	}

return DefWindowProc(hwnd,message,wParam,lParam);
}

//----------------------------------------------------------------------------
// Get shifting value from a desktop to another
//----------------------------------------------------------------------------
void getShifts(int old, int desk, int *addH, int *addV)
{
	int oldDeskX = old % ScreensX;
	int oldDeskY = old / ScreensX;

	int deskX = desk % ScreensX;
	int deskY = desk / ScreensX;

	int shiftX = deskX - oldDeskX;
	int shiftY = deskY - oldDeskY;

	*addH = shiftX * (ScreenWidth + 10);
	*addV = shiftY * (ScreenHeight + 10);
}

//-------------------------------------------------------------------------------------------------
// Callback function. Windows enumeration
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{

	/*if (!refTopmost && (GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
		{
		refTopmost = hwnd;
		return !refToplevel;
		}*/

	if (!refToplevel && !(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
		refToplevel = hwnd;
		return FALSE;//!refTopmost;
	}

	return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Callback functions, check for eudora
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EudoraEnumChildProc(HWND hwnd, LPARAM lParam)
{
	HWND owner = GetWindow(hwnd, GW_OWNER);

	if (owner != eudora) return TRUE;
    {
	    int style = GetWindowLong(hwnd, GWL_STYLE);

		if (style & WS_VISIBLE && style & WS_POPUP)
        {
	        char txt[25];
		    GetWindowText(hwnd, txt, 23);
			if (!strcmp(txt, "Progress") || !strcmp(txt, "No New Mail") || !strcmp(txt, "New Mail!") || !strcmp(txt, "Eudora Network Timeout"))
            {
				RECT r;
				RECT r2;
				RECT r3;
				GetWindowRect(eudora, &r);
				GetWindowRect(hwnd, &r2);
				r3.left = ((r.right-r.left-(r2.right-r2.left)) / 2) + r.left;
				r3.top = ((r.bottom-r.top-(r2.bottom-r2.top)) / 2) + r.top;
				r3.right = r3.left + (r2.right-r2.left);
				r3.bottom = r3.top + (r2.bottom-r2.top);
				MoveWindow(hwnd, r3.left, r3.top, r3.right-r3.left, r3.bottom-r3.top, TRUE);
            }
        }
    }

	return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Callback functions. Enumerates windows to be fixed (hidden when not in active desktop)
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK FixEnumChildProc(HWND hwnd, LPARAM lParam)
{
HWND owner = GetWindow(hwnd, GW_OWNER);

if (owner != photoshop) return TRUE;
    {
    int style = GetWindowLong(hwnd, GWL_STYLE);

    if (style & WS_VISIBLE && style & WS_POPUP)
        if (!inFix(hwnd))
            {
            ShowWindow(hwnd, SW_HIDE);
            addWinFix(hwnd, currentScreen);
            }
    }

return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Does the desktop switching
//-------------------------------------------------------------------------------------------------
void switchToDesktop(int _desk)
{
	RECT r;
	HWND prev, p;
	HDWP dwp;

	int addH=0, addV=0;

	lock = 1;
	if (movingWin > -1) return;

	getShifts(currentScreen, _desk, &addH, &addV);

	// Fix photoshop
	photoshop = FindWindow("Photoshop", NULL);
	if (photoshop)
		EnumWindows(FixEnumChildProc, 0);

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);

	DoEvents(2);

	dwp = BeginDeferWindowPos(nWinRect+16);

	goto inside;
	while (1)
	{
		DWORD dwResult;
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord /*|| prev == 0xE44*/)
			continue;
	/*	if (SendMessage(tapp, 9212, 0, (long)prev))
			continue;
	*/
	//inserted code here to check if the window has been set to be ignored
		if (!topWindowAlways(prev)) {
			GetWindowRect(prev, &r);
			r.left-=addH;
			r.right-=addH;
			r.top -=addV;
			r.bottom-=addV;

			//MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
			
			// first 'probe' the window, if it does not anser immediately then do not defere it
			// the reason is that defer will issue a SendMessage that is blocking, and if we do that
			// on a blocked window then entire litestep will be blocked.
			if(!BlockedTimeout)
				dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
			else if(SendMessageTimeout(prev, WM_NULL, 0, 0, SMTO_ABORTIFHUNG, 100, &dwResult) != 0)
				dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
			}
		}

	currentScreen = _desk;
	EndDeferWindowPos(dwp);

	postfixWinFix(currentScreen);

	if(FocusCenter)
	{// set focus to the window in the middle of the screen
		POINT p;
		p.x = GetSystemMetrics(SM_CXSCREEN)/2;
		p.y = GetSystemMetrics(SM_CYSCREEN)/2;
		SetForegroundWindow(WindowFromPoint(p));
	}

	lock = 0;
}

//-------------------------------------------------------------------------------------------------
// Gather all windows in one desktop
//-------------------------------------------------------------------------------------------------
void gatherAll()
{
	//int i;
	RECT r;
	HWND prev, p;

	if (NoGather) 
    {
		int sze = sizeof(int) | VWM_DESKNO;

		SendMessage(tapp, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &currentScreen);

		return;
    }


	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);
		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			r.right %= (ScreenWidth+10);
		}
		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			r.bottom %= (ScreenHeight+10);
		}
		if (r.left < -10)
		{
			r.right %= (ScreenWidth+10);
			r.right += ScreenWidth;
			r.left %= (ScreenWidth+10);
			r.left += ScreenWidth;
		}
		if (r.top < -10)
		{
			r.bottom %= (ScreenHeight+10);
			r.bottom += ScreenHeight;
			r.top %= (ScreenHeight+10);
			r.top += ScreenHeight;
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}

	currentScreen = 0;
}

//-------------------------------------------------------------------------------------------------
// Returns the desktop associated with a window
//-------------------------------------------------------------------------------------------------
int getDesktop(HWND h)
{
	RECT r;
	GetWindowRect(h, &r);
	return (getDesktopByRect(r));
}

//-------------------------------------------------------------------------------------------------
// Get a desktop associated with a RECT
//-------------------------------------------------------------------------------------------------
int getDesktopByRect(RECT r)
{

	int offsetx = currentScreen % ScreensX;
	int offsety = currentScreen / ScreensX;
	int desk = 0;

	r.left += offsetx * (ScreenWidth + 10);
	r.top += offsety * (ScreenHeight + 10);

	offsetx = ((r.left + 10) / (ScreenWidth + 10));
	offsety = ((r.top + 10) / (ScreenHeight + 10));

	desk = (offsety * ScreensX) + offsetx;

	if (desk < 0 || desk > MaxScreens) desk = 0;
	return desk;
}

//-------------------------------------------------------------------------------------------------
// Check if a RECT is outside of the virtual space
//-------------------------------------------------------------------------------------------------
int outsideAnyScreen(RECT r)
{
return (r.left > ScreensX * (ScreenWidth +10) || r.top > ScreensY*(ScreenHeight +10));
}

//-------------------------------------------------------------------------------------------------
// Changes cursor position 
//-------------------------------------------------------------------------------------------------
void MoveCursor(int o, int n)
{
int h, v;
POINT ps;

getShifts(o, n, &h, &v);

GetCursorPos(&ps);
if (h) h -= (h > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
if (v) v -= (v > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
ps.x -= h;
ps.y -= v;
SetCursorPos(ps.x, ps.y);
}

//-------------------------------------------------------------------------------------------------
// Add a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void addWinFix(HWND hwnd, int s)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd;i++);

	if (i >= 500) return;
	winFix[i].hwnd = hwnd;
	winFix[i].screen = s;
}

//-------------------------------------------------------------------------------------------------
// Remove a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void removeWinFix(HWND hwnd)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);

	if (i >= 500) return;
	winFix[i].hwnd = NULL;
	winFix[i].screen = 0;
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part2)
//-------------------------------------------------------------------------------------------------
void postfixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s)
        {
			ShowWindow(winFix[i].hwnd, SW_SHOWNA);
			winFix[i].hwnd = NULL;
			winFix[i].screen = 0;
        }
    }
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part 1)
//-------------------------------------------------------------------------------------------------
void prefixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s)
			ShowWindow(winFix[i].hwnd, SW_HIDE);
    }
}

//-------------------------------------------------------------------------------------------------
// Checks if a window is in fixed windows list
//-------------------------------------------------------------------------------------------------
int inFix(HWND hwnd)
{
	int i;

	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);
		if (i>=500) return 0;
	return 1;    
}
 
//-------------------------------------------------------------------------------------------------
// Non blocking wait
// -------------------------------------------------------------------------------------------------------
void DoEvents(int n)
{
	int i;
	BOOL b=TRUE;
	MSG msg;

	for (i=0;i<n && b;i++)
    {
		b = GetMessage( &msg, NULL, 0, 0 );
		if (b) 
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg ); 
		}
    }
}

void ReadConfig (void)
{
	NoAuto = GetRCBool("VwmNoAuto", TRUE);
	NoGather = GetRCBool("VwmNoGathering", TRUE);
	NoBmps = GetRCBool("VWMNoBackBmp", TRUE);
	NeverSwitch = GetRCBool("VWMNoSwitchOnFocus", TRUE);
	
	FocusCenter = GetRCBool("VWMFocusCenter", TRUE);
	BlockedTimeout = GetRCBool("VWMBlockedTimeout", TRUE);
		
	backColor = GetRCColor("vwmBackColor", 0x808080);
	selBackColor = GetRCColor("vwmSelBackColor", 0x404040);
	foreColor = GetRCColor("VWMForeColor", 0xFFFFFF);
	borderColor = GetRCColor("VWMBorderColor", 0x000000);   

	ScreensX = GetRCInt("VWMDesksX", ScreensX);
	ScreensY = GetRCInt("VWMDesksY", ScreensY);

	mTimeout = GetRCInt("VWMVelocity", 300);
	VWMDistance = GetRCInt("VWMSecurityDistance", 5);
	borderSize = GetRCInt("WharfBevelWidth", 1);

	GetRCString("PixmapPath", szImagePath, "C:\\litestep\\images\\", 256);
}


void BangGather(HWND caller ,char* args)
{
	RECT r;
	HWND prev, p;

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;

	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);

		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			if (r.left > ScreenWidth)
				r.left -= (ScreenWidth + 10);
			r.right %= (ScreenWidth+10);
		}
		else if (r.right < 0)
		{
			r.right %= (ScreenWidth+10);
			if (r.right < 0)
				r.right += (ScreenWidth + 10);
			r.left %= (ScreenWidth+10);
			if (r.left < -10)
				r.left += (ScreenWidth + 10);
		}

		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			if (r.top > ScreenHeight)
				r.top -= (ScreenHeight + 10);
			r.bottom %= (ScreenHeight+10);
		}
		else if (r.bottom < 0)
		{
			r.bottom %= (ScreenHeight+10);
			if (r.bottom < 0)
				r.bottom += (ScreenHeight + 10);
			r.top %= (ScreenHeight+10);
			if (r.top < -10)
				r.top += (ScreenHeight + 10);
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
}

extern int APIENTRY DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	return 1;
}

/*
	$Log: vwm.c,v $
	Revision 1.13  1998/12/10 23:08:15  jre
	Set focus to the application in the middle of the desktop after a desktop switch, VWMFocusCenter (neat with VWMNoSwitchOnFocus)(J Redestig)
	Added a check for blocked applications when switching desktop, VWMBlockedTimeout (J Redestig)
	
	Revision 1.11  1998/11/27 09:00:51  bryan
	Pseudo Transparency for the wharf. eliminates those awful pink module backgrounds
	
	Revision 1.10  1998/11/17 00:36:07  bryan
	Fixed the crash on recycle bug in VWM.dll.
	Also added new abilities LM_SAVEDATA and LM_RESTOREDATA.
	
	Revision 1.9  1998/11/16 06:07:27  bryan
	Some fixes in VWM and a fix for transparency in popups.
	
	Revision 1.8  1998/11/14 00:18:12  bryan
	We finally now have a n*n working VWM. use VWMDesksX and VWMDesksY
	Also fixed a VWM mode with no background BMP. use VWMNoBackBmp
	
	Revision 1.7  1998/11/06 19:11:57  bryan
	Added automatic versioning info. The CVS will take care of the
	versioning numbers.
	Bind !About to a key (and !About Detailed)
	
 */
