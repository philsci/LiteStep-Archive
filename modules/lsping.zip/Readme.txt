LSPing:
-------

Install:

copy .dll into your LiteStep directory
Just add LoadModule c:\litestep\lsping.dll to your step.rc

Bangs:
------

!Ping <Adress>
!PingStop

Bugs:
-----
Please report bugs to pla.ton@usa.net
