<!>==============================================================<!>
< >                                                              < >
< >        grdTray.dll - system tray module for Litestep!        < >
< >                                                              < >
<!>==============================================================<!>
< >                                                              < >
<#>    grdTray is a system tray replacement module for           <#>
< >  LiteStep which provides greater control over appearance,    < >
< >  placement and icon layout.                                  < >
< >    This text is directly ripped from Maduin's systray.dll    < >
< >  readme. That is done to point out that this is just my      < >
< >  version of the module. I must also point out that large     < >
< >  portions of the code has not yet been modified to suit my   < >
< >  desires, so I have to thank Maduin greatly for the code.    < >
< >    At this moment I haven't even been in contact with        < >
< >  Maduin self, so I don't know whether I'm allowed to do      < >
< >  this. :) If you'd rather don't see this published Maduin    < >
< >  please just contact me, and I'll just keep using it for     < >
< >  myself.                                                     < >
< >                                                              < >
< >                                    developer: Gustav Munkby  < >
< >                                              grd@swipnet.se  < >
< >                                                              < >
< >                                with GREAT help from: Maduin  < >
< >                                           maduin@dasoft.org  < >
< >                                                              < >
< >                                                              < >
< >  updates                                                     < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >  [v2.1 beta 2]                                               < >
< >  <+> yet another feature has been imported from systray,     < >
< >      AutoSizing is now included!!!                           < >
< >      just set grdTrayAutoSize in step.rc, and you're done    < >
< >  <+> removed a completely useless function, that I left      < >
< >      inside the source by mistake                            < >
< >                                                              < >
< >  [v2.1 beta 1]                                               < >
< >  <+> yet another feature has been imported from systray,     < >
< >      with grdBorderDrag set, you can drag the tray around    < >
< >  <+> recoded the bang commands, using AddBangCommandEx       < >
< >      and moved the actual code into the wndproc, which       < >
< >      makes all the bang commands accessible through          < >
< >      the SendMessage function...                             < >
< >  <+> added another setting, grdTrayBorderSize, which         < >
< >      will be used if the other Border settings are omitted   < >
< >      updated the document which spoke of a similar           < >
< >      setting                                                 < >
< >                                                              < >
< >  [v2.0 beta 5]                                               < >
< >  <+> this update includes the version that should have       < >
< >      packaged together with beta 4, so this one does work!   < >
< >  <+> added a new bang, namely; grdTraySize                   < >
< >                                                              < >
< >  [v2.0 beta 4]                                               < >
< >  <+> bangs now work even if grdTrayAlwaysOnTop isn't set     < >
< >  <+> corrected an issue concerning win2k's way of handling   < >
< >      notifyicon structures                                   < >
< >  <+> made sure the tray gets redrawn when an icon is         < >
< >      deleted, accidentially removed this in another update   < >
< >  <+> removed some outdated files from the source-code and    < >
< >      added compiled version, lsapi.lib and this file         < >
< >  <+> corrected some bugs and tweaked the code a little       < >
< >                                                              < >
< >  [v2.0 beta 3]                                               < >
< >  <+> grdTray can now load icons saved from systray during    < >
< >      recycle, so it's easier to switch to grdTray            < >
< >  <+> changed the effect routine slightly to improve speed    < >
< >  <+> corrected some bugs to correct the "known issues"       < >
< >                                                              < >
< >  [v2.0 beta 2.1]                                             < >
< >  <+> actually deletes the deleted icons from memory          < >
< >  <+> fix for applications not removing their icons on        < >
< >      termination, such as ICQ                                < >
< >  <+> swapped the Icon Hue effect colors, to make it RGB      < >
< >      instead of BGR, don't know why, but it was BGR          < >
< >                                                              < >
< >  [v2.0 beta 2]                                               < >
< >  <+> IconHue effect is recoded (no need for msimg32.dll)     < >
< >  <+> Saturnation (or rather desaturnation effect added)      < >
< >  <+> re-added the bang-commands                              < >
< >                                                              < >
< >  [v2.0 beta 1]                                               < >
< >  <+> completely rewritten in a c++ object-oriented way       < >
< >  <+> new IconHue effect included                             < >
< >  <+> fixed some bugs and tweaked the code a lot              < >
< >  <+> made it open-source [ see source license ]              < >
< >  <-> temporarily removed the bang-commands                   < >
< >                                                              < >
< >  [v1.0 pre-beta 1]                                           < >
< >  <+> a complete systray module                               < >
< >  <+> including all features of Maduin's systray except       < >
< >      moving, sizing and some more.                           < >
< >  <+> supporting true transparency                            < >
< >                                                              < >
< >                                                              < >
< >  installation                                                < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>  1) unpack the grdTray.dll into your modules directory.      <#>
< >                                                              < >
<#>  2) add the line to step.rc looking somewhat like this:      <#>
< >     LoadModule C:\LITESTEP\modules\grdTray.dll               < >
< >                                                              < >
<#>  3) start playin' around with the settings in your step.rc   <#>
< >     and images for the frontend. (final version will         < >
< >     contain a default "skin", anyone want to create one?)    < >
< >                                                              < >
< >                                                              < >
< >  configuring                                                 < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>    grdTray supports a couple of step.rc settings:            <#>
< >                                                              < >
<#>  grdTrayAlwaysOnTop                                          <#>
< >  This is boolean value, which doesn't seam to work if        < >
< >  desktop.dll is loaded.                                      < >
< >                                                              < >
<#>  grdTrayHidden                                               <#>
< >  This is boolean value, which toggles wether the tray is     < >
< >  to be shown on startup.                                     < >
< >                                                              < >
<#>  grdTrayHideIfEmpty                                          <#>
< >  This is boolean value. Pretty self-explaining.              < >
< >                                                              < >
<#>  grdTrayX <integer>             DEFAULT: 0                   <#>
< >  The trays position horizontally on the screen, it does      < >
< >  support negative values, which then will be relative to     < >
< >  righthand egde of the screen.                               < >
< >                                                              < >
<#>  grdTrayY <integer>             DEFAULT: 0                   <#>
< >  The trays position vertically on the screen, it does        < >
< >  support negative values, which then will be relative to     < >
< >  bottom egde of the screen.                                  < >
< >                                                              < >
<#>  grdTrayWidth <integer>         DEFAULT: 100                 <#>
< >  Pretty self-explaining.                                     < >
< >                                                              < >
<#>  grdTrayHeight <integer>        DEFAULT: 20                  <#>
< >  Pretty self-explaining.                                     < >
< >                                                              < >
<#>  grdTrayAutoSize                                             <#>
< >  This is boolean value, which toggles wether the tray is     < >
< >  autosizing (adjusting it's size to the number of icons)     < >
< >                                                              < >
<#>  grdTrayIconSize                DEFAULT: 16                  <#>
< >  Pretty self-explaining.                                     < >
< >                                                              < >
<#>  grdTrayIconSpacingX <integer>  DEFAULT: 1                   <#>
< >  The horizontal space between the tray icons.                < >
< >                                                              < >
<#>  grdTrayIconSpacingY <integer>  DEFAULT: 1                   <#>
< >  The vertical space between the tray icons.                  < >
< >                                                              < >
<#>  grdTrayIconHueColor <color>    DEFAULT: FFFFFF              <#>
< >  The color for the IconHue effect.                           < >
< >                                                              < >
<#>  grdTrayIconHueIntensity <int>  DEFAULT: 0   RANGE: 0-255    <#>
< >  The intensity of the color above in the Icon Hue effect.    < >
< >                                                              < >
<#>  grdTrayIconSaturnation <int>   DEFAULT: 255 RANGE: 0-255    <#>
< >  Icon saturnation, where 255 results in the normal icon      < >
< >  and 0 results in a monochrome icon. This is applied         < >
< >  before the Icon Hue effect.                                 < >
< >                                                              < >
<#>  grdTrayDirection <string>      DEFAULT: right               <#>
< >  The direction which the icons will go in, right means the   < >
< >  second icon will be placed on the right hand side of the    < >
< >  first icon. Possible values: right/left/up/down             < >
< >                                                              < >
<#>  grdTrayWrapCount <integer>     DEFAULT: 0                   <#>
< >  After this number of icons a new line of icons will be      < >
< >  started. If the parameter equals zero this will never.      < >
< >  happen.                                                     < >
< >                                                              < >
<#>  grdTrayWrapDirection <string>  DEFAULT: down                <#>
< >  The direction which the new lines  will go in, right means  < >
< >  the second icon will be placed on the right hand side of    < >
< >  the first icon. Possible values: right/left/up/down         < >
< >                                                              < >
<#>  grdTrayBGColor <color>         DEFAULT: FF00FF              <#>
< >  Pretty self-explaining. FF00FF equals transparent.          < >
< >                                                              < >
<#>  grdTrayBorderColor <color>     DEFAULT: FFFFFF              <#>
< >  Pretty self-explaining. FF00FF equals transparent.          < >
< >                                                              < >
<#>  grdTrayBitmap <string>         DEFAULT: (none)              <#>
< >  this should be a regular "ls-path" to a .bmp file.          < >
< >                                                              < >
<#>  grdTrayBitmapTiled                                          <#>
< >  This is boolean value, which toggles wether the bitmap      < >
< >  should be stretched or tiled to fit the tray.               < >
< >                                                              < >
<#>  grdTrayBorderSize <integer>        DEFAULT: 0               <#>
< >  The width of the default border, which is used only when    < >
< >  seperate values for the different directions isn't used.    < >
< >                                                              < >
<#>  grdTrayBorderLeft <integer>    DEFAULT: 0                   <#>
< >  The width of the left border, applies to both color and     < >
< >  bitmap.                                                     < >
< >                                                              < >
<#>  grdTrayBorderRight <integer>   DEFAULT: 0                   <#>
< >  The width of the right border, applies to both color and    < >
< >  bitmap.                                                     < >
< >                                                              < >
<#>  grdTrayBorderTop <integer>     DEFAULT: 0                   <#>
< >  The width of the top border, applies to both color and      < >
< >  bitmap.                                                     < >
< >                                                              < >
<#>  grdTrayBorderBottom <integer>  DEFAULT: 0                   <#>
< >  The width of the bottom border, applies to both color and   < >
< >  bitmap.                                                     < >
< >                                                              < >
<#>  grdTrayBorderDrag                                           <#>
< >  This is boolean value. If specified, you can move the tray  < >
< >  if you click on the border.                                 < >
< >                                                              < >
<#>    That was all the configuration parameters in step.rc      <#>
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  supported !BANG commands                                    < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>    grdTray supports a couple of bang commands:               <#>
< >                                                              < >
<#>  !grdTrayShow                                                <#>
< >  shows the tray if it's hidden.                              < >
< >                                                              < >
<#>  !grdTrayHide                                                <#>
< >  hides the tray if it's visible.                             < >
< >                                                              < >
<#>  !grdTrayToggle                                              <#>
< >  shows the tray if it's hidden & hides the tray if it's      < >
< >  visible.                                                    < >
< >                                                              < >
<#>  !grdTrayMove <int>|x <int>|y                                <#>
< >  move the tray to coordinates x,y (negative values are       < >
< >  supported!                                                  < >
< >                                                              < >
<#>  !grdTraySize <int>|w <int>|h                                <#>
< >  size the tray to w=width & h=height (negative values are    < >
< >  NOT supported!                                              < >
< >                                                              < >
<#>    That was all the bang commands supported.                 <#>
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  info about !BANG commands ( only for developers )           < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
<#>    The !BANG commands all exist in the window procedure      <#>
< >  and can be accessed through the SendMessage function.       < >
< >                                                              < >
<#>  To access the functions this way, use SendMessage like:     <#>
< >                                                              < >
<#>  SendMessage( hTrayWnd, WM_USER, <fn>, (LPCTSTR)args );      <#>
< >                                                              < >
<#>  <fn> is a number representing a bangcommand, which could    <#>
< >       be; 142 - show, 143 - hide, 144 - toggle, 145 - move   < >
< >       or 146 - size                                          < >
< >                                                              < >
<#>  args is the arguments string which is the part of the       <#>
< >       !BANG command, that isn't the bangcommand name.        < >
< >                                                              < >
<#>  Don't really know if this makes anyone happier, but I       <#>
< >  just wanted to mention it if anyone would be intrested.     < >
< >  the only thing this proves is how easy it would be to       < >
< >  the !BANG commands into a seperate module... :)             < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  known issues                                                < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    none, at the moment                                       < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  additional notes                                            < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    Nothing here yet, except the fact that I'd like to be     < >
< >  presented with a lot of ideas, help and stuff like that.    < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  source license                                              < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >    The code is avaliable for free and you can get it by      < >
< >  contacting me through e-mail or another way.                < >
< >    Even if the code is free, and you're allowed to do        < >
< >  almost whatever you like with it, I have to restrict it     < >
< >  a little. The requirements to use it is:                    < >
< >                                                              < >
< >  >> source-code has to be included                           < >
< >  >> this documentatory file has to be included               < >
< >                                                              < >
< >  those were the requirements, my wishes are that:            < >
< >                                                              < >
< >  >> you tell me about using my source-code                   < >
< >  >> you also mention Maduin                                  < >
< >                                                              < >
< >                                                              < >
< >                                                              < >
< >  the man                                                     < >
<!>--------------------------------------------------------------<!>
< >                                                              < >
< >  Gustav Munkby, online known as grim reaper or grd           < >
< >  The man behind the concept "grd" which stands for;          < >
< >  grim reaper designs, which is my web-page and what I do on  < >
< >  the computer.                                               < >
< >  This is where you my remains online:                        < >
< >                                                              < >
<?>  e-mail:      grd@swipnet.se                                 <?>
< >                                                              < >
<?>  webpage:     http://home.swipnet.se/grd/                    <?>
< >                                                              < >
<?>  grdTray:     http://home.swipnet.se/grd/ls/grdtray.zip      <?>
<?>  -source:     http://home.swipnet.se/grd/ls/grdtray.src.zip  <?>
< >                                                              < >
<?>  lsAmp:       http://home.swipnet.se/grd/ls/lsamp.zip        <?>
< >                                                              < >
<?>  icq:         1349988                                        <?>
< >                                                              < >
<?>  irc:         #lsdev/#litestep (nick: grd/grd_ls/grd-ls)     <?>
< >                                                              < >
< >                                                              < >
<!>==============================================================<!>


