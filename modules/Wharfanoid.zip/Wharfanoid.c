#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "Wharfanoid.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "Wharfanoid"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
int BorderRect(HDC hdc, RECT* r);
int NewGame();
int CheckBounce();
int SetupLevel();
int Missed();
int LoadSetup();

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
DWORD MB = MB_OK | MB_SETFOREGROUND;
HBITMAP backImage = NULL;
int CursorTimer=0;
int Timer=0;
char ini[MAX_PATH] = "c:\\litestep\\modules.ini";
HMENU Popup;


// Globals
int LIVES=3;
int LEVEL=1;
int SPEED=2;
int OSPEED=2;
int DEMO=0;
HBRUSH hbr[4], hpaddle, hball, silver, hlives;
HPEN border1;
HPEN border2;
RECT r[20];
RECT paddle;
RECT pea;
BOOL GAMEON=FALSE;
BOOL LEFT=FALSE, RIGHT=FALSE, UP=FALSE, DOWN=FALSE;
int rarray[20] = {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
int sarray[20] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;
    if (wharfData.borderSize < 0)
		wharfData.borderSize = 0;


    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }

	sprintf(ini, "%smodules.ini", wharfData.lsPath);
	LoadSetup();
	NewGame();

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	if (DEMO) 
	{
		SendMessage(hMainWnd, WM_LBUTTONDOWN, 0, 0);
	}

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	DeleteObject(border1);
	DeleteObject(border2);
	DeleteObject(hpaddle);
	DeleteObject(hball);
	DeleteObject(hlives);
	DeleteObject(silver);
	DeleteObject(hbr[0]);
	DeleteObject(hbr[1]);
	DeleteObject(hbr[2]);
	DeleteObject(hbr[3]);
	DestroyMenu(Popup);
	KillTimer(hMainWnd, CursorTimer);
    DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
                if (!backImage)
				{
					HDC hdc = GetDC(parent);
					HDC buf = CreateCompatibleDC(NULL);

					backImage = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, backImage);
					BitBlt(buf, 0, 0, 64, 64, hdc, 0, 0, SRCCOPY);

					ReleaseDC(hdc,hwnd);
					DeleteDC(buf);
				}
				{
					PAINTSTRUCT ps;
					RECT life;
					int count=0;
					int x=2, y=5;
					int row=0;
					int GO=0;
					HDC hdc = BeginPaint(hwnd,&ps);
					HDC src = CreateCompatibleDC(NULL);
					HDC buf = CreateCompatibleDC(NULL);
					HBITMAP bufBMP = CreateCompatibleBitmap(hdc, 64, 64);
					char temp[25] = "";

					SelectObject(buf, bufBMP);
					
					if (backImage)
					{
						SelectObject(src, backImage);
						BitBlt(buf, 0, 0, 64, 64, src, 0, 0, SRCCOPY);
					}
					
					life.top = 60;
					life.bottom = 62;
					while (count < LIVES)
					{
						life.left = x;
						life.right = x+2;
						FillRect(buf, &life, hlives);
						count++;
						x+=4;
					}
					
					count=0;
					x=5;
					while ( y <= 23 && count <= 20)
					{
						while ( x <= 49  && count <= 20)
						{
							if (rarray[count])
							{
								r[count].left = x;
								r[count].right = x+10;
								r[count].top = y;
								r[count].bottom = y+5;
								if (!sarray[count])
									FillRect(buf, &r[count], hbr[row]);
								else
									FillRect(buf, &r[count], silver);
								BorderRect(buf, &r[count]);
								GO=1;
							}
							
							x += 11;
							count++;
						}
						x = 5;
						y += 6;
						row++;
					}

					if (!GO)
					{
						char temp[25] = "";
						GAMEON=0;
						KillTimer(hwnd, Timer);
						Timer=0;
						LEVEL++;
						DeleteMenu(Popup, 106, MF_BYCOMMAND);
						sprintf(temp, "Level: %d", LEVEL);
						AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, temp);
						NewGame();
						InvalidateRect(hwnd, NULL, TRUE);
					}
							
					FillRect(buf, &pea, hball);
					FillRect(buf, &paddle, hpaddle);

					BitBlt(hdc, 0, 0, 64, 64, buf, 0, 0, SRCCOPY);

					EndPaint(hwnd,&ps);
					DeleteDC(src);
					DeleteDC(buf);
					DeleteObject(bufBMP);
				}
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
			{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			}
			return 0;
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_LBUTTONDOWN:
		{
			if (!GAMEON)
			{
				GAMEON=TRUE;
				Timer = SetTimer(hwnd, 1, 50, NULL);
			}
			else
			{
				GAMEON=FALSE;
				KillTimer(hwnd, Timer);
			}
		}
		return 0;
		case WM_MOUSEMOVE:
		{
			if (!DEMO)
			{
				int x = LOWORD(lParam);
				if (x <= wndSize-15)
					paddle.left = x;
				else
					paddle.left = wndSize-15;
				paddle.right = paddle.left + 15;
			}

			SetCursor(NULL);
			CursorTimer = SetTimer(hMainWnd, 2, 50, NULL);

			if (!GAMEON && !Timer)
			{
				pea.left = paddle.left + 6;
				pea.right = pea.left + 3;
				pea.top = paddle.top - 3;
				pea.bottom = pea.top + 3;
			}
			InvalidateRect(hwnd, NULL, TRUE);
		}
		return 0;
		case WM_TIMER:
		{
			switch (wParam)
			{
			case 1:
			{
				if (UP)
				{
					pea.top -= SPEED;
					pea.bottom -= SPEED;
				}
				else if (DOWN)
				{
					pea.top += SPEED;
					pea.bottom += SPEED;
				}
				if (RIGHT)
				{
					pea.left += SPEED;
					pea.right += SPEED;
				}
				else if (LEFT)
				{
					pea.left -= SPEED;
					pea.right -= SPEED;
				}
				if (DEMO)
				{
					if (pea.left+1 < paddle.left)
					{
						paddle.left -= SPEED;
						paddle.right -= SPEED;
					}
					else if (pea.left+1 > paddle.right)
					{
						paddle.left += SPEED;
						paddle.right += SPEED;
					}
				}
				CheckBounce();
				InvalidateRect(hwnd, NULL, TRUE);
			}
			return 0;
			case 2:
			{
				POINT pos;
				RECT rtemp;

				KillTimer(hwnd, CursorTimer);
				GetCursorPos(&pos);
				GetWindowRect(hwnd, &rtemp);
				if (((pos.x < rtemp.left)||(pos.x > rtemp.right))||
					((pos.y < rtemp.top)|| (pos.y > rtemp.bottom)))
				{
					SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
				}
				else
				{
					SetCursor(NULL);
				}
			}
			return 0;
			}
		}
		return 0;
		case WM_COMMAND:
		{
			switch (wParam)
			{
			case 100:
			{
				OSPEED=SPEED=1;
				WritePrivateProfileString("Wharfanoid", "BallSpeed", "1", ini);
				CheckMenuItem(Popup, 100, MF_CHECKED);
				CheckMenuItem(Popup, 101, MF_UNCHECKED);
				CheckMenuItem(Popup, 102, MF_UNCHECKED);
				CheckMenuItem(Popup, 103, MF_UNCHECKED);
			}
			return 0;
			case 101:
			{
				OSPEED=SPEED=2;
				WritePrivateProfileString("Wharfanoid", "BallSpeed", "2", ini);
				CheckMenuItem(Popup, 100, MF_UNCHECKED);
				CheckMenuItem(Popup, 101, MF_CHECKED);
				CheckMenuItem(Popup, 102, MF_UNCHECKED);
				CheckMenuItem(Popup, 103, MF_UNCHECKED);
			}
			return 0;
			case 102:
			{
				OSPEED=SPEED=3;
				WritePrivateProfileString("Wharfanoid", "BallSpeed", "3", ini);
				CheckMenuItem(Popup, 100, MF_UNCHECKED);
				CheckMenuItem(Popup, 101, MF_UNCHECKED);
				CheckMenuItem(Popup, 102, MF_CHECKED);
				CheckMenuItem(Popup, 103, MF_UNCHECKED);
			}
			return 0;
			case 103:
			{
				OSPEED=SPEED=4;
				WritePrivateProfileString("Wharfanoid", "BallSpeed", "4", ini);
				CheckMenuItem(Popup, 100, MF_UNCHECKED);
				CheckMenuItem(Popup, 101, MF_UNCHECKED);
				CheckMenuItem(Popup, 102, MF_UNCHECKED);
				CheckMenuItem(Popup, 103, MF_CHECKED);
			}
			return 0;
			case 104:
			{
				char temp[25] = "";
				if (DEMO)
				{
					DEMO=0;
					WritePrivateProfileString("Wharfanoid", "DEMO", "0", ini);
					CheckMenuItem(Popup, 104, MF_UNCHECKED);
					GAMEON=FALSE;
					KillTimer(hwnd, Timer);
					Timer=0;
					LIVES=3;
					LEVEL=1;
					SPEED=OSPEED;
					NewGame();
					InvalidateRect(hwnd, NULL, TRUE);
				}
				else
				{
					DEMO=1;
					WritePrivateProfileString("Wharfanoid", "DEMO", "1", ini);
					CheckMenuItem(Popup, 104, MF_CHECKED);
					GAMEON=FALSE;
					LIVES=3;
					LEVEL=1;
					NewGame();
				}
				DeleteMenu(Popup, 106, MF_BYCOMMAND);
				sprintf(temp, "Level: %d", LEVEL);
				AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, temp);
			}
			return 0;
			case 105:
			{
				MessageBox(NULL, "Wharfanoid V1.0\n\n- Written By: MrJukes\n- Graphics By: Floach\n\nE-Mail me at mrjukes@litestep.net\n", "Wharfanoid V1.0", MB | MB_ICONINFORMATION);
			}
			return 0;
			}
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int BorderRect(HDC hdc, RECT* r)
{
	SelectObject(hdc, border2);
	MoveToEx(hdc, r->left, r->bottom, NULL);
	LineTo(hdc, r->left, r->top);
	LineTo(hdc, r->right, r->top);
	SelectObject(hdc, border1);
	LineTo(hdc, r->right, r->bottom);
	LineTo(hdc, r->left, r->bottom);
	return 1;
}

int NewGame()
{
	int count=0;
	while (count <= 20)
	{
		rarray[count] = 0;
		count++;
	}

	if (!(LEVEL % 10) && SPEED < 4 && !DEMO) SPEED++;
	SetupLevel();
	
	paddle.left = 15;
	paddle.right = 30;
	paddle.top = 55;
	paddle.bottom = 58;

	pea.left = 21;
	pea.right = 24;
	pea.top = 52;
	pea.bottom = 55;

	UP = RIGHT = TRUE;
	DOWN = LEFT = FALSE;

	if (DEMO) SendMessage(hMainWnd, WM_LBUTTONDOWN, 0, 0);

	return 1;
}

int CheckBounce()
{
	int count=0;

	// Check to see if its at a wall
	if (pea.left <= 0) { LEFT=0; RIGHT=1; }
	else if (pea.right >= wndSize) { LEFT=1; RIGHT=0; }
	if (pea.bottom >= wndSize) { UP=1; DOWN=0; }
	else if (pea.top <= 0) { UP=0; DOWN=1; }

	// Check to see if its at the paddle
	if (pea.right >= paddle.left && pea.left <= paddle.right
		&& pea.bottom >= paddle.top && DOWN)
	{
		if (DOWN) { UP=1; DOWN=0; }
		else { UP=0; DOWN=1; }
		// Check to go right or left
		if (pea.right <= (paddle.left + ((paddle.right - paddle.left)/2)))
		{
			LEFT=1;
			RIGHT=0;
		}
		else
		{
			LEFT=0;
			RIGHT=1;
		}
	}
	
	// Check to see if it is a miss
	if (pea.bottom > paddle.top) Missed();

	// Check to see if its at a block
	while (1)
	{
		if (rarray[count])
		{
			
			if (pea.top <= r[count].bottom && pea.bottom >= r[count].top
				&& pea.right >= r[count].left && pea.left <= r[count].right)
			{
				int VertMid = r[count].left + ((r[count].right-r[count].left)/2);
				int HorMid = r[count].top + ((r[count].bottom-r[count].top)/2);
				
				if (sarray[count] == 2) sarray[count] = 1;
				else if (sarray[count] == 1) sarray[count] = 0;
				if (!sarray[count])
					rarray[count] = 0;

				if (pea.right <= r[count].left || pea.left >= r[count].right)
				{
					if (LEFT) { RIGHT=1; LEFT=0; }
					else { RIGHT=0; LEFT=1; }
					if (pea.left+1 <= VertMid)
					{
						pea.right = r[count].left;
						pea.left = pea.right - 3;
						break;
					}
					else if (pea.left+1 > VertMid)
					{
						pea.left = r[count].right;
						pea.right = pea.left + 3;
						break;
					}
				}
				else
				{
					if (UP) { DOWN=1; UP=0; }
					else { DOWN=0; UP=1; }
				}
			}
		}
		if (count < 22) count++;
		else break;	
	}
	return 1;
}

int SetupLevel()
{
	int count=0;
	int chosen=0;
	int silver=0;
	srand( (unsigned)time( NULL ) );
	silver = rand() % 5;
	while (count <= 20)
	{
		rarray[rand() % 20] = 1;
		count++;
	}
	count = 0;
	while (count <= silver)
	{
		chosen = rand() % 20;
		if (rarray[chosen])
		{
			sarray[chosen] = 2;
			count++;
		}
	}
	return 1;
}

int Missed()
{
	KillTimer(hMainWnd, Timer);
	Timer=0;
	GAMEON=FALSE;
	LIVES--;
	if (LIVES < 1)
	{
		LIVES=3;
		SPEED=OSPEED;
		NewGame();
	}
	else
	{
		pea.left = paddle.left+6;
		pea.right = pea.left+3;
		pea.top = 52;
		pea.bottom = 55;
		InvalidateRect(hMainWnd, NULL, TRUE);
		UP = RIGHT = TRUE;
		DOWN = LEFT = FALSE;
	}
	if (DEMO) SendMessage(hMainWnd, WM_LBUTTONDOWN, 0, 0);
	return 1;
}

int LoadSetup()
{
	COLORREF temp;
	int test=0;
	if ((test = GetPrivateProfileInt("Wharfanoid", "PaddleColor", -69, ini)) == -69)
	{
		WritePrivateProfileString("Wharfanoid", "PaddleColor", "0x00FFFFFF", ini);
		WritePrivateProfileString("Wharfanoid", "BallColor", "0x00FFFFFF", ini);
		WritePrivateProfileString("Wharfanoid", "Line1Color", "0x00FF0000", ini);
		WritePrivateProfileString("Wharfanoid", "Line2Color", "0x0000FF00", ini);
		WritePrivateProfileString("Wharfanoid", "Line3Color", "0x000000FF", ini);
		WritePrivateProfileString("Wharfanoid", "Line4Color", "0x00FFFF00", ini);
		WritePrivateProfileString("Wharfanoid", "BallSpeed", "2", ini);
		WritePrivateProfileString("Wharfanoid", "Demo", "0", ini);
	}

	temp = GetPrivateProfileInt("Wharfanoid", "PaddleColor", 0x00FFFFFF, ini);
	hpaddle = CreateSolidBrush(temp);
	temp = GetPrivateProfileInt("Wharfanoid", "BallColor", 0x00FFFFFF, ini);
	hball = CreateSolidBrush(temp);
	temp = GetPrivateProfileInt("Wharfanoid", "Line1Color", 0x00FF0000, ini);
	hbr[0] = CreateSolidBrush(temp);
	temp = GetPrivateProfileInt("Wharfanoid", "Line2Color", 0x0000FF00, ini);
	hbr[1] = CreateSolidBrush(temp);
	temp = GetPrivateProfileInt("Wharfanoid", "Line3Color", 0x000000FF, ini);
	hbr[2] = CreateSolidBrush(temp);
	temp = GetPrivateProfileInt("Wharfanoid", "Line4Color", 0x00FFFF00, ini);
	hbr[3] = CreateSolidBrush(temp);

	OSPEED = SPEED = GetPrivateProfileInt("Wharfanoid", "BallSpeed", 2, ini);
	DEMO = GetPrivateProfileInt("Wharfanoid", "Demo", 0, ini);
	silver = CreateSolidBrush(0x00D2D2D2);
	border1 = CreatePen(PS_SOLID, 0, 0x006E6E6E);
	border2 = CreatePen(PS_SOLID, 0, 0x00FFFFFF);

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Slow");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 101, "&Medium");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "&Fast");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 103, "&Insane");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 104, "&Demo Mode");
	AppendMenu(Popup, MF_SEPARATOR, 0, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 105, "&About Wharfanoid");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, "Level: 1");
	
	switch (SPEED)
	{
		case 1:
			CheckMenuItem(Popup, 100, MF_CHECKED);
			break;
		case 2:
			CheckMenuItem(Popup, 101, MF_CHECKED);
			break;
		case 3:
			CheckMenuItem(Popup, 102, MF_CHECKED);
			break;
		case 4:
			CheckMenuItem(Popup, 103, MF_CHECKED);
			break;
	}
	if (DEMO) CheckMenuItem(Popup, 104, MF_CHECKED);
	return 1;
}
