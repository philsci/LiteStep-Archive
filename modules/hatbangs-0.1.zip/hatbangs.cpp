// Hack to not preface all symbols with underscores
#define sprintf _sprintf
#define atoi _atoi
#define atol _atol
#define stricmp _stricmp


#include <windows.h>
#pragma hdrstop
#include <condefs.h>


//---------------------------------------------------------------------------
//   Important note about DLL memory management in a VCL DLL:
//
//
//
// If your DLL uses VCL and exports any functions that pass VCL String objects
// (or structs/classes containing nested Strings) as parameter or function
// results, you will need to build both your DLL project and any EXE projects
// that use your DLL with the dynamic RTL (the RTL DLL).  This will change your
// DLL and its calling EXE's to use BORLNDMM.DLL as their memory manager. In
// these cases, the file BORLNDMM.DLL should be deployed along with your DLL
// and the RTL DLL (CP3240MT.DLL). To avoid the requiring BORLNDMM.DLL in
// these situations, pass string information using "char *" or ShortString
// parameters and then link with the static RTL.
//
//---------------------------------------------------------------------------
#pragma argsused

#include <stdio.h>
#include "hatbangs.h"
#include "../../litestep/lsapi/lsapi.h"

/*
//extern unsigned __turboFloat;    // provide external linkage
unsigned __turboFloat;
*/

/***********/
/* Globals */
/***********/
HWND parent;

// Tokenization variables
#define MAX_TOKENIZATION_STRING 256
char tok_buf[MAX_TOKENIZATION_STRING];
char *tok_ptr;

// Bookmark Code
HWND hBookmarks[10];

// Monitor info -- I only care about 2 currently!
#define MAX_MONITORS 2
int num_monitors;
RECT     monRects[MAX_MONITORS];
HMONITOR monHandles[MAX_MONITORS];

/*****/  /********/  /*****/
/*****/  /* Code */  /*****/
/*****/  /********/  /*****/

/*************/
/* Init Code */
/*************/
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
  return initModuleEx(ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  parent = ParentWnd;

  initMultiMonitor();

  AddBangCommand("!SETWALLPAPER", SetWallPaper);
  AddBangCommand("!CHANGESCREENRES", ChangeRes);
  AddBangCommand("!TOGGLESCREENSAVER", ToggleScreenSaver);
  AddBangCommand("!SETBOOKMARK", SetBookmark);
  AddBangCommand("!GOTOBOOKMARK", GotoBookmark);
  AddBangCommand("!SWAPAPPMONITOR", SwapAppMonitor);
  return 0;
}

void initMultiMonitor(void)
{
 num_monitors = 0;

 if(!EnumDisplayMonitors(NULL, NULL, monitorCallback, 0))
  {
  }
}

BOOL CALLBACK monitorCallback(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData)
{
 monHandles[num_monitors] = hMonitor;
 monRects[num_monitors]   = *lprcMonitor;

 num_monitors++;

 // Stop enumerating if we don't have any more spots left...
 if(num_monitors == MAX_MONITORS)
  return(false);
}

/*****************/
/* shutdown code */
/*****************/

void quitModule(HINSTANCE dllInst)
{
// nothing to do
}

void SetWallPaper(HWND caller, char* arg)
{
  if (arg)
    SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, arg, SPIF_UPDATEINIFILE);
}

/* Format is now: bits-per-pixel, width, height, display number, frequency */
void ChangeRes(HWND caller, char* arg)
{
  DEVMODE DevMode;
  int bpp, width, height, frequency, display_num;
  int i = 0, j = 0;
  char displayName[256];

  if(arg == NULL)
   return;

  init_tokenize(arg);
  bpp    = int_token(0);
  width  = int_token(0);
  height = int_token(0);
  display_num = int_token(1);
  frequency = int_token(0);

  sprintf(displayName, "\\\\.\\Display%d", display_num);

  EnumDisplaySettings(displayName, 0, &DevMode);

  DevMode.dmFields = 0;

  if(bpp)
   {
    DevMode.dmBitsPerPel = bpp;
    DevMode.dmFields     |= DM_BITSPERPEL;
   }

  if(width)
   {
    DevMode.dmPelsWidth  = width;
    DevMode.dmFields     |= DM_PELSWIDTH;
   }

  if(height)
   {
    DevMode.dmPelsHeight = height;
    DevMode.dmFields     |= DM_PELSHEIGHT;
   }

  if(frequency)
   {
    DevMode.dmDisplayFrequency = frequency;
    DevMode.dmFields           |= DM_DISPLAYFREQUENCY;
   }

  switch (ChangeDisplaySettingsEx(displayName, &DevMode, NULL, CDS_UPDATEREGISTRY, NULL))
   {
    case DISP_CHANGE_RESTART:
	    MessageBox(parent,"The computer must be restarted in order for the graphics mode to work.","Change resolution",MB_OK);
     break;
	   case DISP_CHANGE_FAILED:
	    MessageBox(parent,"The display driver failed the specified graphics mode.","Change resolution",MB_OK);
     break;
	   case DISP_CHANGE_BADMODE:
	    MessageBox(parent,"The graphics mode is not supported.","Change resolution",MB_OK);
     break;
   }

 // We need to update our monitor rects!
 initMultiMonitor(); 
}

void ToggleScreenSaver(HWND caller, char* arg)
{
  BOOL IsActive;
  SystemParametersInfo(SPI_GETSCREENSAVEACTIVE, 0, &IsActive, 0);
  SystemParametersInfo(SPI_SETSCREENSAVEACTIVE, !IsActive, NULL, SPIF_UPDATEINIFILE);
}

/* Flip the current application to the other monitor */
void SetBookmark(HWND caller, char* arg)
{
 int iBookmark;

 if(arg == NULL)
  return;

 iBookmark = atoi(arg);
 if(iBookmark < 0)
  iBookmark = 0;
 else if(iBookmark >= 10)
  iBookmark = 9;

 hBookmarks[iBookmark] = GetForegroundWindow();               
}

void GotoBookmark(HWND caller, char* arg)
{
 int iBookmark;

 if(arg == NULL)
  return;

 init_tokenize(arg);

 iBookmark = int_token(0);
 if(iBookmark < 0)
  iBookmark = 0;
 else if(iBookmark >= 10)
  iBookmark = 9;

 if(hBookmarks[iBookmark] != 0)
  {
   if(IsWindow(hBookmarks[iBookmark]))
    SetForegroundWindow(hBookmarks[iBookmark]);
   else
    hBookmarks[iBookmark] = 0; // flag it out so we don't inadvertantly end up pointing to a new, unrelated window
  }
}

/* Flip the current application to the other monitor */
void SwapAppMonitor(HWND caller, char* arg)
{
 HWND hActive;
 HMONITOR hCurMon;
 WINDOWPLACEMENT wp;
 int curMonitor, targetMonitor;
 int iMonitor;

 if(num_monitors == 1) // no point if there's only one of them...
  return;

 hActive = GetForegroundWindow();

 hCurMon = MonitorFromWindow(hActive, MONITOR_DEFAULTTONEAREST);

 // Find out which monitor that is in our array
 curMonitor = -1;
 for(iMonitor=0; iMonitor < num_monitors; iMonitor++)
  {
   if(hCurMon == monHandles[iMonitor])
    curMonitor = iMonitor;
  }
 if(curMonitor == -1)
  return; // Escape because it's on a monitor we don't know about.

 // We want to work with the other monitor
 targetMonitor = (curMonitor + 1)%2;

 // Get its current position
 wp.length = sizeof(WINDOWPLACEMENT);
 if(GetWindowPlacement(hActive, &wp))
  {
   // change its max position
   wp.ptMaxPosition.x = monRects[targetMonitor].left;
   wp.ptMaxPosition.y = monRects[targetMonitor].top;

   // change it's normal position, taking care to be friendly to people with monitors at different resolutions
/* Old constant location code
   wp.rcNormalPosition.left   += monRects[targetMonitor].left - monRects[curMonitor].left;
   wp.rcNormalPosition.top    += monRects[targetMonitor].top - monRects[curMonitor].top;
   wp.rcNormalPosition.right  += monRects[targetMonitor].left - monRects[curMonitor].left;
   wp.rcNormalPosition.bottom += monRects[targetMonitor].top - monRects[curMonitor].top;
*/
   if((arg != NULL) && (stricmp(arg, "noresize") == 0))
    {
     int save_left, save_top;

     save_left = wp.rcNormalPosition.left;
     save_top  = wp.rcNormalPosition.top;

     wp.rcNormalPosition.left = (wp.rcNormalPosition.left - monRects[curMonitor].left) *
                                (monRects[targetMonitor].right - monRects[targetMonitor].left) /
                                (monRects[curMonitor].right - monRects[curMonitor].left) +
                                monRects[targetMonitor].left;
     wp.rcNormalPosition.top = (wp.rcNormalPosition.top - monRects[curMonitor].top) *
                                (monRects[targetMonitor].bottom - monRects[targetMonitor].top) /
                                (monRects[curMonitor].bottom - monRects[curMonitor].top) +
                                monRects[targetMonitor].top;
     wp.rcNormalPosition.right = wp.rcNormalPosition.right - save_left + wp.rcNormalPosition.left;
     wp.rcNormalPosition.bottom = wp.rcNormalPosition.bottom - save_top + wp.rcNormalPosition.top;
    }
   else
    {
     wp.rcNormalPosition.left = (wp.rcNormalPosition.left - monRects[curMonitor].left) *
                                (monRects[targetMonitor].right - monRects[targetMonitor].left) /
                                (monRects[curMonitor].right - monRects[curMonitor].left) +
                                monRects[targetMonitor].left;
     wp.rcNormalPosition.top = (wp.rcNormalPosition.top - monRects[curMonitor].top) *
                                (monRects[targetMonitor].bottom - monRects[targetMonitor].top) /
                                (monRects[curMonitor].bottom - monRects[curMonitor].top) +
                                monRects[targetMonitor].top;
     wp.rcNormalPosition.right = (wp.rcNormalPosition.right - monRects[curMonitor].left) *
                                (monRects[targetMonitor].right - monRects[targetMonitor].left) /
                                (monRects[curMonitor].right - monRects[curMonitor].left) +
                                monRects[targetMonitor].left;
     wp.rcNormalPosition.bottom = (wp.rcNormalPosition.bottom - monRects[curMonitor].top) *
                                (monRects[targetMonitor].bottom - monRects[targetMonitor].top) /
                                (monRects[curMonitor].bottom - monRects[curMonitor].top) +
                                monRects[targetMonitor].top;
    }

   SetWindowPlacement(hActive, &wp);
   if(wp.showCmd == SW_SHOWMAXIMIZED)
    {
     ShowWindow(hActive, SW_SHOWMINNOACTIVE);
     ShowWindow(hActive, SW_SHOWMAXIMIZED);
    }
  }

}

void init_tokenize(char *str)
{
 strcpy(tok_buf, str);
 tok_ptr = &tok_buf[0];
}

int int_token(int defval)
{
 char *val_ptr;

 if((tok_ptr == NULL) || (*tok_ptr == '\0'))
  return defval;

 val_ptr = tok_ptr;

 for(;(*tok_ptr != '\0') && (*tok_ptr != ' '); tok_ptr++)
  {
  }

 if(*tok_ptr == ' ')
  {
   *tok_ptr = '\0';
   tok_ptr++;
  }

 if(stricmp(val_ptr, "default") == 0)
  return(defval);
 else
  return(atoi(val_ptr));
}

int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
 return 1;
}
