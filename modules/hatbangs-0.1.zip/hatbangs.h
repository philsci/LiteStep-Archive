#ifndef __RDJBANGS_H_
#define __RDJBANGS_H_

#include "wharfdata.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Exports */
__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

/* Prototypes */
void SetWallPaper(HWND caller, char* arg);

void ChangeRes(HWND caller, char* arg);

void ToggleScreenSaver(HWND caller, char* arg);

void SetBookmark(HWND caller, char* arg);
void GotoBookmark(HWND caller, char* arg);

void SwapAppMonitor(HWND caller, char* arg);

void initMultiMonitor(void);
BOOL CALLBACK monitorCallback(HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData);

// Utility Functions
void init_tokenize(char *str);
int  int_token(int defval);

#ifdef __cplusplus
}
#endif


#endif

