/**************************************
/	Soniquez.dll by Azathoth
/	
/	(c) 2000	All code written by Azathoth	
/
/**************************************/

Description:
*********

This module controls sonique through a series of bang commands. It works in the same way as geekamp but expect a slightly slower response than geekamp (not my fault, its sonique's cruddy programming =) )

Usage:
*****

Load it as you would a normal module ie. 
Enter the line:
LoadModule "c:\litestepdir\soniquez.dll" 
into your step.rc where litestepdir is you actual LiteStep directory.

Commands:
*********

Step specific:
========

SoniquePath "c:\path_to_sonique" 
	(If you don't enter this command, soniquez will default to c:\program files\sonique\sonique.exe)

Bang Commands:
===========

!SoniqueRun
	Opens up a new instance of Sonique.

!SoniquePlay
	Plays the currently selected song.

!SoniqueStop
	Stops playback.

!SoniqueNext
	Skips to the next track in the playlist.

!SoniquePrev
	Skips to the previous track in the playlist.

!SoniquePause
	Pauses playback.

!SoniqueResume
	Resume playback.

!SoniqueSeekNumber <number>
	Seeks to the track in the playlist specified by the <number>.

!SoniqueScanTo <position>
	Scans through the song to the desired position.

!SoniqueSetVolume <volume>
	Sets the sonique volume from a range between 0 (mute) and 65535 (ear shatteringly loud).

!SoniqueRemoveCurrent
	This will remove the current track in the playlist.

!SoniqueCDInsert <path>
	Enables the CDInsert setting.

!SoniqueShuffle
	Toggles shuffle.

!SoniqueLoop
	Toggles looping.

!SoniqueInstallSkin <path>
	This will install the specified skin.

!SoniqueLoadSkin <path>
	This will load the specified skin.

!SoniqueOpenFileDialog
	This will open the file select dialog.

!SoniqueClearPlaylist
	This clears the whole playlist.

!SoniqueAppend <file>
	This will append the specified file to the playlist.

!SoniqueStartSong <file>
	This starts a specified song.

!SoniqueQuit
	This quits Sonique.

!SoniqueShowWindow <window> <mode>
	This changes the sonique window mode with the follows settings:
	
	Window:	1. Small Mode
		2. Mid Mode
		3. Navigator Mode

	Mode:	1. Online Tools
		2. Playlist
		3. Visual Mode
		4. Setup Options
		5. About Sonique
		6. Audio Controls
		7. Media Search

	NB. The mode settings only work in Navigator mode.


Thats it.

Contact:
*******

Any bugs, suggestions, praise, money, hardware can be sent via these methods:

E-Mail:		azathoth@intricatechaos.com
ICQ:		25810657
Website:		http://www.ls2k.org/
IRC:		EFNet, #litestep + #ls_help c/o Azathoth


Shout Outs:
**********

o GeekMaster for the original idea. I am saving him a job and giving him at least 1 e-mail less a week!
o Jalist for being Mr. Cool and generally being a good mate.
o Demigod for ignoring me when i say something clever and laughing at me when i don't.
o Jesterace, TNL, Galois, [steve], Allout and everyone else who helps out on #ls_help.
o Rootrider for making life just /that/ bit more interesting.
o My girlfriend... oh wait, i don't have one... any takers? =)

Final:
****

Later gators...
