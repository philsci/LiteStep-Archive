MIDPOP README - Nov 14, 1998

What is it?
-----------
MidPop is a small system module for Litestep which allows you to use
your middle mouse button to display the popup menu at any location

How do I use it?
----------------
1. Extract MIDPOP.ZIP in your Litestep directory.
2. The zip include two DLLs. One for LS b24 and one for LS b23e.
   If you use Litestep 0.24.x add this line :

   loadModule C:\LITESTEP\MIDPOP24.DLL

   If you use Litestep <= b23e add this line :

   loadModule C:\LITESTEP\MIDPOP23.DLL

   Replace C:\LITESTEP with the full path of your LS directory.
   You can delete the DLL you're not using - they are totally independent.	

Notes
-----
I only tested this thing on Win95 with LS 0.24.3 and LS b23e. Any other variations,
well, it should work but you are on your own. E-mail me if it doesn't work though.
Who knows I might be able to do something about it ;)

Contact
--------
E-mail : illusion@cryogen.com (StarQuake)