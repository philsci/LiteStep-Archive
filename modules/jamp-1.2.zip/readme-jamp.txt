/////////////////////////////
// Module: jamp 1.2
// Written By: MrJukes
// Released: 9/21/00
/////////////////////////////

// New to v1.2
- jampNoScroll
= jampFormat "%title% - %status% - %length% - %pos% - %rem%"
- jampLeftClick !bang, jampRightClick !bang, jampMiddleClick !bang
- jampNoWinampText "jAMP"


// New to v1.1
- jampAlwaysOnTop
- !jampMove X Y
- !jampHome

LoadModule c:\litestep\jamp.dll

step.rc
==========
LoadModule $ModulesDir$jamp.dll
jampStartHidden		; Starts hidden
jampAlwaysOnTop		; The jamp window will always be on top
jampNoScroll		; Starts with scrolling disabled
jampX 0			; X position
jampY 0			; Y position
jampW 600		; Width
jampH 32		; Height

; The format must be contained in quotes
; Inside the quotes you can have any of the following:
;   %title%  - Displays what is in the winamp title bar
;   %status% - Playing, Paused, or Stopped
;   %length% - The length of the current track
;   %pos%    - The current position
;   %rem%    - How much time remaining on the current track
; All other text will be displayed as it appears
jampFormat "%title% - %status% - %length% - %pos% - %rem%"	

jampNoWinampText "jAMP"	; Text to be displayed when winamp is not currently loaded
jampFont "8Pin Matrix"	; Font
jampFontSize 32		; Font Size
jampFontColor FFFFFF	; Font Color
jampBackColor 000000	; These are very obvious names. If you can't figure 
			; out what this does then just quit now
jampSpeed 100		; Speed at which it scrolls
jampBackBmp jamp.bmp	; Background image to use
			; If neither jampBackBmp or jampBackColor are specified
			; then it will paint the desktop beneath the window
jampLeftClick cmd	; Command to execute on left click (can be bang or exe)
jampRightClick cmd	; Command to execute on right click (can be bang or exe)
jampRigthClick cmd	; Command to execute on middle click (can be bang or exe)

bangs
=======
!jampShow		; Shows the window
!jampHide		; Hides the window
!jampToggle		; Formats your hard drive
!jampToggleScroll	; Toggles scrolling on or off
!jampMove X Y		; Moves the jamp window to X,Y
!jampHome		; Moves the jamp window back to its starting position

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes