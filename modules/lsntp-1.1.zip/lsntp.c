/*
 * LSNTP, ported from LSClock by Lone Runner
 * Pigeon, 2001
 * pigeon@iname.com
 *
 */


// Original file comment header from LSClock

/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
/****************************************************************************

 06/03/98 - F. Gastellu
            This file contains the source code for the lsclock module

            48 bits numbers operations & dates computations (used in my own
            NTP implementation) were originally based on Tom Horsley's work

****************************************************************************/


#include "lsntp.h"
#include "ntpfrac.h"

#define szAppName		"LSNTP"
#define szNTPAppName	"SNTPClientWnd"
#define JAN_1_1900		2415021L			// January 1st 1900 (julian)
#define MINUTE			60000


#define P1				((double) 2.0)
#define P2				(P1 * P1)
#define P4				(P2 * P2)
#define P8				(P4 * P4)
#define P16				(P8 * P8)
#define P32				(P16 * P16)
#define CVT				(((double) 1000.0) / P32)


void addBangCommands();
void removeBangCommands();
void ReadConfig();

void sync_ntp();
void info_ntp();
void enable_ntp();
void disable_ntp();
void toggle_ntp();

int do_ntp();
int closeup();
int socketError(int dontquit);

void ConvertTimeToFixed(SYSTEMTIME sys_time, unsigned int *integer, unsigned int *fractional);
int JulianDayNumber(WORD wYear, WORD wMonth, WORD wDay);

LRESULT CALLBACK NTPWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

void translatePacket(SYSTEMTIME received);

void ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2,
				 unsigned int *resi, unsigned int *resf);
void ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2,
				unsigned int *resi, unsigned int *resf);
void ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
void ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);
void ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf);

void GregorianDate(long julian_time, WORD *wYear, WORD *wMonth, WORD *wDay);
void ConvertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time);

void EnablePriviledge();
void DisablePriviledge();


typedef struct
{
	int li					: 2;
	int vn					: 3;
	int mode				: 3;
	int stratum				: 8;
	int poll				: 8;
	signed int precision	: 8;
} bits_data;

bits_data bits;


char xferdata[48];

unsigned int databits;
unsigned int rootdelay;
unsigned int rootdispersion;
unsigned int referenceidentifier;
unsigned int referencetimestamp_hi;
unsigned int referencetimestamp_lo;
unsigned int originatetimestamp_hi;
unsigned int originatetimestamp_lo;
unsigned int receivetimestamp_hi;
unsigned int receivetimestamp_lo;
unsigned int transmittimestamp_hi;
unsigned int transmittimestamp_lo;


// Global variables

HWND hMainWnd = NULL;
HWND hNTPWnd = NULL;

int wsainit = 0;
int socketinit = 0;
int lockNTPtimer = 0;
SOCKET mysocket;

HANDLE tok_handle;
TOKEN_PRIVILEGES tok_priv;
int priv_modified = 0;


// RC related variables

// Default value is set in ReadConfig()
char ntp_host[MAX_LEN];

// Default port 123
int ntp_port = 123;

// Default poll frequency, 5 minutes
int ntp_pollfreq = 5;

// Default max delta value, 3600
int ntp_maxdelta = 3600;

// Default ntp server timeout, 20 seconds
int ntp_timeout = 20;

// Default enabled
BOOL ntp_disabled = FALSE;

// Sync on startup or not
BOOL ntp_startupsync = TRUE;

// Offset used when it syncs
int ntp_offset = 0;


// Main function
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{

	ReadConfig();

	addBangCommands();

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.style = CS_DBLCLKS; 
	
		if(!RegisterClass(&wc))
		{
			MessageBox(ParentWnd, "Error registering window class", szAppName, MB_OK);
			return 1;
		}
	}

	
	hMainWnd = CreateWindowEx(
		0,												// exstyles 
		szAppName,										// our window class name
		"",												// use description for a window title
		0,												// window style
		0, 0,											// position 
		10, 10,											// width & height of window
		NULL,											// parent window (winamp main window)
		NULL,									// no menu
		dllInst,								// hInstance of DLL
		0);										// no window creation data


	if(!hMainWnd) 
	{						   
		MessageBox(ParentWnd, "Error creating window", szAppName, MB_OK);
		return 1;
	}
	

	{

		WNDCLASS wc;

		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = NTPWndProc;			// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szNTPAppName;		// our window class name

		if(!RegisterClass(&wc))
		{
			MessageBox(NULL,"Error registering window class", szAppName, MB_ICONHAND);
			return 1;
		}

		hNTPWnd = CreateWindowEx(
			0,											// exstyles 
			szNTPAppName,								// our window class name
			"",											// use description for a window title
			0,											// window style
			0, 0,										// position 
			10, 10,										// width & height of window
			NULL,										// parent window (litestep wharf window)
			NULL,										// no menu
			dllInst,									// hInstance of DLL
			0);											// no window creation data

		if(!hNTPWnd)
		{
			MessageBox(NULL, "Enable to create NTP system window", szAppName, MB_ICONHAND);
			return closeup();
		}

	}

	if(ntp_pollfreq && !ntp_disabled)
	{
		SetTimer(hMainWnd, 1, ntp_pollfreq * MINUTE, NULL);
	}

	if(ntp_startupsync)
	{
		sync_ntp();
	}

	return 0;

}


// Startup
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx(ParentWnd, dllInst, wd->lsPath);
}


// Finalize
int quitModule(HINSTANCE dllInst)
{
	removeBangCommands();

	if(ntp_pollfreq)
	{
		KillTimer(hMainWnd, 1);
	}

	KillTimer(hNTPWnd, 0);

	DestroyWindow(hMainWnd);						// delete our window
	UnregisterClass(szAppName, dllInst);			// unregister window class

	DestroyWindow(hNTPWnd);
	UnregisterClass(szNTPAppName, dllInst);

	if(wsainit)
	{
		WSACleanup(); 
	}

	return 1;
}


// Add all bang commands
void addBangCommands()
{
	AddBangCommand("!LSNTPSYNC", sync_ntp);
	AddBangCommand("!LSNTPINFO", info_ntp);
	AddBangCommand("!LSNTPEnable", enable_ntp);
	AddBangCommand("!LSNTPDisable", disable_ntp);
	AddBangCommand("!LSNTPToggle", toggle_ntp);
}


void removeBangCommands()
{
	RemoveBangCommand("!LSNTPSYNC");
	RemoveBangCommand("!LSNTPINFO");
	RemoveBangCommand("!LSNTPEnable");
	RemoveBangCommand("!LSNTPDisable");
	RemoveBangCommand("!LSNTPToggle");
}


void check_enabled()
{
	if(ntp_pollfreq && !ntp_disabled)
	{
		SetTimer(hMainWnd, 1, ntp_pollfreq * MINUTE, NULL);
	}
}

void enable_ntp()
{
	ntp_disabled = FALSE;
	check_enabled();
}


void disable_ntp()
{
	// Note: this will not kill any active polling
	ntp_disabled = TRUE;
}


void toggle_ntp()
{
	ntp_disabled = !ntp_disabled;
	check_enabled();
}


void info_ntp()
{
	char buf[MAX_LEN];
	sprintf(buf,
		"NTP server: %s\nNTP port: %d\nPoll frequency: %d minute(s)\nMax delta: %d\nNTP timeout: %d second(s)\nOffset is %d second(s)\nLSNTP is now %s",
		ntp_host, ntp_port, ntp_pollfreq, ntp_maxdelta, ntp_timeout, ntp_offset,
		ntp_disabled ? "disabled" : "enabled");

	MessageBox(NULL, buf, szAppName, MB_ICONINFORMATION);

}


void sync_ntp()
{
	PostMessage(hMainWnd, WM_TIMER, (WPARAM) 1L, (LPARAM) NULL);
}


int do_ntp()
{
	WORD wVersionRequested; 
	SYSTEMTIME now;
	WSADATA wsaData; 
	struct in_addr addr;
	struct sockaddr_in myaddr;
	struct sockaddr_in _addr;
	int err; 
	int on = 1;
	unsigned int integer, fractional;
	struct hostent *host;
	static int badsocket = 0;

	lockNTPtimer = 1;

	if(!wsainit)
	{
		wVersionRequested = MAKEWORD(1, 1); 
		memset(&wsaData, 0, sizeof(wsaData));
		err = WSAStartup(wVersionRequested, &wsaData); 

		if (err != 0) 						 
		{
			MessageBox(NULL, "Enable to start windows sockets", szAppName, MB_ICONHAND);
			return closeup();
		}

		wsainit = 1;

		if(LOBYTE(wsaData.wVersion) != 1 || HIBYTE(wsaData.wVersion) != 1)
		{
			badsocket = 1;
			MessageBox(NULL, "Incompatible Windows Socket version", szAppName, MB_ICONHAND);
			return closeup();
		}
	}

	if(badsocket)
	{
		return 0;
	}
 
	mysocket = socket(PF_INET, SOCK_DGRAM, 0);
	memset((void *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons((u_short) ntp_port);

	socketinit = 1;
      
	host = gethostbyname (ntp_host);

	if(host == NULL)
	{
		addr.s_addr = inet_addr (ntp_host);
		if(addr.s_addr == -1)
		{
			MessageBox(NULL, "Unknown remote host", szAppName, MB_ICONHAND);
			return closeup();
		}
	}
	else
	{
		memcpy((char *) &addr, host->h_addr, host->h_length);
	}

	myaddr.sin_addr = addr;

	memset((char *) &_addr, 0, sizeof(_addr));
	_addr.sin_family = AF_INET;
	_addr.sin_port = htons((u_short) ntp_port);
	_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	if(bind(mysocket, (struct sockaddr *) &_addr, sizeof(_addr)) == SOCKET_ERROR)
	{
		return socketError(0);
	}

	WSAAsyncSelect(mysocket, hNTPWnd, WM_USER + 1, FD_READ);

	bits.li = 3;
	bits.vn = 2;
	bits.mode = 0;
	bits.stratum = 0;
	bits.poll = 0;
	bits.precision = 0;

	memcpy(&databits, &bits, sizeof(databits));

	rootdelay = 0;
	rootdispersion = 0;
	referenceidentifier = 0;
	referencetimestamp_hi = 0;
	referencetimestamp_lo = 0;
	originatetimestamp_hi = 0;
	originatetimestamp_lo = 0;
	receivetimestamp_hi = 0;
	receivetimestamp_lo = 0;

	GetSystemTime(&now);

	ConvertTimeToFixed(now, &integer, &fractional);
	transmittimestamp_hi = integer;
	transmittimestamp_lo = fractional;

	rootdelay = htonl(rootdelay);
	rootdispersion = htonl(rootdispersion);
	referenceidentifier = htonl(referenceidentifier);
	referencetimestamp_hi = htonl(referencetimestamp_hi);
	referencetimestamp_lo = htonl(referencetimestamp_lo);
	originatetimestamp_hi = htonl(originatetimestamp_hi);
	originatetimestamp_lo = htonl(originatetimestamp_lo);
	receivetimestamp_hi = htonl(receivetimestamp_hi);
	receivetimestamp_lo = htonl(receivetimestamp_lo);
	transmittimestamp_hi = htonl(transmittimestamp_hi);
	transmittimestamp_lo = htonl(transmittimestamp_lo);

	memcpy(xferdata, &databits, sizeof(databits));
	memcpy(xferdata+4, &rootdelay, sizeof(rootdelay));
	memcpy(xferdata+8, &rootdispersion, sizeof(rootdispersion));
	memcpy(xferdata+12, &referenceidentifier, sizeof(referenceidentifier));
	memcpy(xferdata+16, &referencetimestamp_hi, sizeof(referencetimestamp_hi));
	memcpy(xferdata+20, &referencetimestamp_lo, sizeof(referencetimestamp_lo));
	memcpy(xferdata+24, &originatetimestamp_hi, sizeof(originatetimestamp_hi));
	memcpy(xferdata+28, &originatetimestamp_lo, sizeof(originatetimestamp_lo));
	memcpy(xferdata+32, &receivetimestamp_hi, sizeof(receivetimestamp_hi));
	memcpy(xferdata+36, &receivetimestamp_lo, sizeof(receivetimestamp_lo));
	memcpy(xferdata+40, &transmittimestamp_hi, sizeof(transmittimestamp_hi));
	memcpy(xferdata+44, &transmittimestamp_lo, sizeof(transmittimestamp_lo));
  
	if(sendto(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
		(struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR)
	{
		return socketError(0);
	}

	SetTimer(hNTPWnd, 0, ntp_timeout * 1000, NULL);

	ExitThread(0);

	return 1;

}


void ReadConfig()
{

	// LSNTPHost
	GetRCString("LSNTPHost", ntp_host, "127.0.0.1", MAX_LEN);

	// LSNTPPort
	ntp_port = GetRCInt("LSNTPPort", ntp_port);

	// LSNTPPollFreq
	ntp_pollfreq = GetRCInt("LSNTPPollFreq", ntp_pollfreq);

	// LSNTPMaxDelta
	ntp_maxdelta = GetRCInt("LSNTPMaxDelta", ntp_maxdelta);

	// LSNTPTimeout
	ntp_timeout = GetRCInt("LSNTPTimeout", ntp_timeout);

	// LSNTPDisabled
	ntp_disabled = GetRCBool("LSNTPDisabled", TRUE);

	// LSNTPStartupSync
	ntp_startupsync = GetRCBool("LSNTPStartupSync", TRUE);

	// LSNTPOffset
	ntp_offset = GetRCInt("LSNTPOffset", ntp_offset);
}


int closeup(void)
{
	if(socketinit)
	{
		closesocket(mysocket);
		socketinit = 0;
	}

	if(ntp_pollfreq && !ntp_disabled)
	{
		SetTimer(hMainWnd, 1, ntp_pollfreq * MINUTE, NULL);
	}

	lockNTPtimer = 0;

	return 0;
}


int socketError(int dontquit)
{
	char *p;
	char txt[256];

	int err = WSAGetLastError();

	switch (err)
	{
		case WSANOTINITIALISED:	
			p = "Sockets not iniatilized";
			break;
		case WSAENETDOWN:
			p = "Network subsystem has failed";
			break;
		case WSAEADDRINUSE:
			p = "Specified address already in use";
			break;
		case WSAEINTR:
			p = "Blocking call was canceled";
			break;
		case WSAEINPROGRESS:
			p = "Blocking call is in progress";
			break;
		case WSAEADDRNOTAVAIL:
			p = "The specified address is not available";
			break;
		case WSAEAFNOSUPPORT:
			p = "Addresses in the specified family cannot be used with this socket";
			break;
		case WSAECONNREFUSED:
			p = "Connection refused";
			break;
		case WSAEINVAL:
			p = "Unbound socket";
			break;
		case WSAEISCONN:
			p = "Socket already connected";
			break;
		case WSAENETUNREACH:
			p = "Network not reachable";
			break;
		case WSAETIMEDOUT:
			p = "Connetion timed out";
			break;
		default: 
			sprintf(txt, "Unknown winsock or internal error (error code = %d)", err);
			p = txt;
			break;
	}

	MessageBox(NULL, p, szAppName, MB_ICONHAND);

	if(!dontquit)
	{
		closeup();
	}

	return 0;
}


void ConvertTimeToFixed(SYSTEMTIME sys_time, unsigned int *integer, unsigned int *fractional)
{
	long int j;

	j = JulianDayNumber(sys_time.wYear, sys_time.wMonth, sys_time.wDay);
	j -= JAN_1_1900;
	j = (j * 24L) + (long int) sys_time.wHour;
	j = (j * 60L) + (long int) sys_time.wMinute;
	j = (j * 60L) + (long int) sys_time.wSecond;

	*integer = (unsigned long) j;
	*fractional = ntpfracTable[sys_time.wMilliseconds];
}


int JulianDayNumber(WORD wYear, WORD wMonth, WORD wDay)
{
	long int y = (long int)wYear;
	long int d = (long int)wDay;
	long int m = (long int)wMonth;
	long int c;
	long int ya;
	long int j;

	if (m > 2)
	{
		m = m - 3;
	}
	else 
	{
		m = m + 9;
		y = y - 1;
	}

	c = y / 100;
	ya = y - 100 * c;
	j = (146097L * c) / 4 + (1461L * ya) / 4 + (153L * m + 2) / 5 + d + 1721119L;

	return j;
}



LRESULT CALLBACK NTPWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_USER + 1:
		{
			struct sockaddr_in gotfrom;
			SYSTEMTIME now;
			int gotlen = sizeof(gotfrom);

			if(recvfrom(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
				(struct sockaddr *)&gotfrom, &gotlen) != SOCKET_ERROR)
			{
				GetSystemTime(&now);
				translatePacket(now);
			}
			else
			{
				socketError(1);
			}

			KillTimer(hNTPWnd, 0);
			PostMessage(hMainWnd, WM_USER + 1, 0, 0);
		}
        return 0;

		case WM_TIMER: // Timeout;
		{
			KillTimer(hNTPWnd, 0);
			MessageBox(NULL, "Timeout occured while waiting for NTP reply", szAppName, MB_ICONHAND);
			PostMessage(hMainWnd, WM_USER + 1, 0, 0);
		}
    }

    return DefWindowProc(hwnd, message, wParam, lParam);
}


void translatePacket(SYSTEMTIME received)
{
	SYSTEMTIME now;
	unsigned int originatetimestamp_integer, originatetimestamp_fractional;
	unsigned int receivetimestamp_integer, receivetimestamp_fractional;
	unsigned int transmittimestamp_integer, transmittimestamp_fractional;
	unsigned int received_integer, received_fractional;

	unsigned int ti1, tf1, ti2, tf2, ti3, tf3;
	unsigned int d_i, d_f;
	unsigned int t_i, t_f;
	unsigned int i1, f1;

	memcpy(xferdata, &databits, sizeof(databits));
	memcpy(&rootdelay, xferdata+4, sizeof(rootdelay));
	memcpy(&rootdispersion, xferdata+8, sizeof(rootdispersion));
	memcpy(&referenceidentifier, xferdata+12, sizeof(referenceidentifier));
	memcpy(&referencetimestamp_hi, xferdata+16, sizeof(referencetimestamp_hi));
	memcpy(&referencetimestamp_lo, xferdata+20, sizeof(referencetimestamp_lo));
	memcpy(&originatetimestamp_hi, xferdata+24, sizeof(originatetimestamp_hi));
	memcpy(&originatetimestamp_lo, xferdata+28, sizeof(originatetimestamp_lo));
	memcpy(&receivetimestamp_hi, xferdata+32, sizeof(receivetimestamp_hi));
	memcpy(&receivetimestamp_lo, xferdata+36, sizeof(receivetimestamp_lo));
	memcpy(&transmittimestamp_hi, xferdata+40, sizeof(transmittimestamp_hi));
	memcpy(&transmittimestamp_lo, xferdata+44, sizeof(transmittimestamp_lo));

	originatetimestamp_integer = ntohl(originatetimestamp_hi);
	originatetimestamp_fractional = ntohl(originatetimestamp_lo);
	receivetimestamp_integer = ntohl(receivetimestamp_hi);
	receivetimestamp_fractional = ntohl(receivetimestamp_lo);
	transmittimestamp_integer = ntohl(transmittimestamp_hi);
	transmittimestamp_fractional = ntohl(transmittimestamp_lo);

	ConvertTimeToFixed(received, &received_integer, &received_fractional);

	ntp64_moins(received_integer, received_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
	ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, transmittimestamp_integer, transmittimestamp_fractional, &ti2, &tf2);

	ntp64_moins(ti1, tf1, ti2, tf2, &d_i, &d_f);

	ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
	ntp64_moins(transmittimestamp_integer, transmittimestamp_fractional, received_integer, received_fractional, &ti2, &tf2);
	ntp64_plus(ti1, tf1, ti2, tf2, &ti3, &tf3);
	ntp64_sdiv2(ti3, tf3, &t_i, &t_f);

	if(ntp_maxdelta)
	{
		if(t_i & 0x80000000)
		{
			ntp64_umoins(t_i, t_f, &i1, &f1);
		}
		else
		{
			i1 = t_i; f1 = t_f;
		}

		/*
		if(i1 > (unsigned) maxderivation && warnonmax)
		{
			char txt[256];
			sprintf(txt, "Server time over maximum derivation (%d seconds). Check your timezone settings.\nClock was not set.", i1);
			MessageBox(NULL, txt, "Warning", MB_ICONWARNING);
			closeup();
			return;
		}
		*/
	}

	GetSystemTime(&now);
	ConvertTimeToFixed(now, &ti1, &tf1);

	ntp64_plus(ti1, tf1, t_i, t_f, &ti2, &tf2);

	ConvertToSYSTEMTIME(ti2, tf2, &now);

	EnablePriviledge();

	SetSystemTime(&now);

	DisablePriviledge();

	/*
	if(notifyset)
	{
		MessageBox(NULL, "Time set!", szAppName, MB_ICONINFORMATION);
	}
	*/

}


void ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2,
				 unsigned int *resi, unsigned int *resf)
{
	unsigned int i1, f1;
	ntp64_umoins(int2, frac2, &i1, &f1);
	ntp64_plus(int1, frac1, i1, f1, resi, resf);
}


void ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2,
				unsigned int *resi, unsigned int *resf)
{
	unsigned long lo16 = (frac1 & 0xffff) + (frac2 & 0xffff);
	unsigned long hi16 = (frac1 >> 16) + (frac2 >> 16) + (lo16 >> 16);

	*resi = int1 + int2 + (hi16 >> 16);
	*resf = (hi16 << 16) | (lo16 & 0xffff);
}


void ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	unsigned int i1, f1, i2, f2;

	if(int1 & 0x80000000)
	{
		ntp64_umoins(int1, frac1, &i1, &f1);
		ntp64_div2(i1, f1, &i2, &f2);
		ntp64_umoins(i2, f2, resi, resf);
	}
	else
	{
		ntp64_div2(int1, frac1, resi, resf);
	}
}


void ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	ntp64_plus(~int1, ~frac1, 0, 1, resi, resf);
}


void ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
	*resf = ((frac1 >> 1) | (int1 << 31));
	*resi = int1 >> 1;
}


void ConvertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time)
{
	unsigned long ip = int1;
	long int j;

	if(ntp_offset)
	{
		ip += ntp_offset;
	}

	sys_time->wSecond = (WORD) (ip % 60L);

	ip /= 60L;
	sys_time->wMinute = (WORD) (ip % 60L);
	ip /= 60L;
	sys_time->wHour = (WORD) (ip % 24L);
	ip /= 24L;
	j = ((long int) ip) + JAN_1_1900;

	sys_time->wDayOfWeek = (WORD) ((j + 1) % 7L);

	GregorianDate(j, &sys_time->wYear, &sys_time->wMonth, &sys_time->wDay);
	sys_time->wMilliseconds = (WORD) ((((double) frac1) * CVT) + 0.5);
}


void EnablePriviledge()
{
	BOOL opt_ok = OpenProcessToken(GetCurrentProcess(),
		TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
		&tok_handle);

	if(!opt_ok)
	{
		if(GetLastError() == ERROR_CALL_NOT_IMPLEMENTED)
		{
			SetLastError(ERROR_SUCCESS);
			priv_modified=0;
			return;
		}
	}

	memset((void *)&tok_priv, 0, sizeof(tok_priv));
	LookupPrivilegeValue(NULL, SE_SYSTEMTIME_NAME, &tok_priv.Privileges[0].Luid);
	tok_priv.PrivilegeCount = 1;
	tok_priv.Privileges[0].Attributes |= SE_PRIVILEGE_ENABLED;
	AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
	priv_modified=1;

}


void DisablePriviledge()
{
	if(priv_modified)
	{
		tok_priv.Privileges[0].Attributes &= (~ SE_PRIVILEGE_ENABLED);
		AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
	}
}


void GregorianDate(long julian_time, WORD *wYear, WORD *wMonth, WORD *wDay)
{
	long j = julian_time - 1721119;
	long y = (4 * j - 1) / 146097;
	long d;
	long m;

	j = 4 * j - 1 - 146097 * y;
	d = j / 4;
	j = (4 * d + 3) / 1461;
	d = 4 * d + 3 - 1461 * j;
	d = (d + 4) / 4;
	m = (5 * d - 3) / 153;
	d = 5 * d - 3 - 153 * m;
	d = (d + 5) / 5;
	y = 100 * y + j;

	if (m < 10)
	{
		m = m + 3;
	}
	else
	{
		m = m - 9;
		y = y + 1;
	}

	*wYear = (WORD)y;
	*wMonth = (WORD)m;
	*wDay = (WORD)d;
}



LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_TIMER:
		{
			switch(wParam)
			{
				case 1:
				{
					int thread;

					if(ntp_pollfreq && !ntp_disabled)
					{
						KillTimer(hMainWnd, 1);
					}

					CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) do_ntp, (LPVOID)hwnd, 0, &thread);
				}
			}
			break;
		}
		return 0;

		case WM_USER + 1:		// Sent by NTPWndProc
		{
			closeup();
			return 0;
		}
	}

	return DefWindowProc(hwnd, message, wParam, lParam);

}
