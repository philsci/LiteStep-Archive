#ifndef __LSNTP_H__
#define __LSNTP_H__

#include <windows.h>
#include "../lsapi/lsapi.h"
#include "../litestep/wharfdata.h"

#define MAX_LEN		256

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

#ifdef __cplusplus
}
#endif

#endif
