DESCRIPTION
-----------------------------------------
V_wharf let you control the volume of your 
sound card from the Wharf bar instead from 
the Systray.


INs AND OUTs
-----------------------------------------
Current Version 0.1 (Bulid 060199)

Ins:
  *Volume Control of the AUX, WAVE and MAIN
   Channels.
  *Changeable Background

Outs(Until future versions):
  *Customizable arrangement of AUX, WAVE, 
   MIDI and MAIN channel slider bars
  *Transparent Background
  *Separate left/right channel control
  *Right-click Configuration
  *Systray Icon capability


INSTALLATION
-----------------------------------------
Just copy the .dll and the .bmp in your 
Litestep and your Images Directory. 
Then add the following line to your 
Step.rc:
   
 *Wharf "Apps" .none @c:\Litestep\v_wharf.dll
   

OPTIONS
----------------------------------------
The only option so far you can change is 
the Background of the Wharf. To do so you 
just need to add the value "Backbmp" in
the [V_Wharf] section of your Modules.ini.

Note: The Picture *must* be in your Images dir.

Example:
.
..
..
[V_wharf]
Backbmp=any.bmp
..
.

DISCLAIMER
----------------------------------------
I AM NOT IN ANYWAY RESPONSIBLE FOR THE CHAOS 
THIS PROGRAM COULD DO TO YOUR COMPUTER, THE 
WORLD OR MICROSOFT. DON'T USE THIS PROGRAM 
UNDER WATER.
[....]

SUPPORT
----------------------------------------
If you have a suggestion, found a little 
bug or just want send me a grammatical 
correct version of this text mail me at:

     blkhawk49@geocities.com


     
----------------------------------------
(C)1999 by No More Bytes (6.1.1999)