#include <windows.h>

char* szAppName = "CursorShell";
HWND hwndMain;
HBITMAP hbmpMain;
POINT op, p;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{
	MSG msg; 
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = hInstance;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	hbmpMain = (HBITMAP)LoadImage(NULL, "d:\\temp\\cs.bmp", IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	hwndMain = CreateWindowEx(WS_EX_TOPMOST, szAppName, szAppName, WS_VISIBLE | WS_POPUP,
							  0, 0, 200, 200, NULL, NULL, hInstance, NULL);

	if (!hwndMain) return 1;

	SetWindowBitmapRgn(hwndMain, hbmpMain);

	SetTimer(hwndMain, 0, 50, NULL);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}

	KillTimer(hwndMain, 0);
	DeleteObject(hbmpMain);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, hInstance);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE: return 0;
			}
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			RECT r;
			HPEN pen;
			HBRUSH hbr;

			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));

			pen = CreatePen(PS_SOLID, 0, 0x00000000);
			hbr = CreateSolidBrush(RGB(0, 0, 255));
			SelectObject(hdc, pen);
			SelectObject(hdc, hbr);

			//Ellipse(hdc, 49, 49, r.right-50, r.bottom-50);
			Chord(hdc, 0, 0, r.right, r.bottom, 0, 0, r.right, r.bottom);

			DeleteObject(hbr);
			hbr = CreateSolidBrush(RGB(255, 0, 0));
			SelectObject(hdc, hbr);
			Chord(hdc, r.right-25, r.bottom-25, 24, 24, r.right-25, r.bottom-25, 24, 24);

			EndPaint(hwnd, &ps);
			DeleteObject(pen);
			DeleteObject(hbr);
		}
		return 0;

		case WM_TIMER:
		{
			GetCursorPos(&p);
	
			if (p.x != op.x || p.y != op.y)
			{
				op = p;
				SetWindowPos(hwndMain, NULL, p.x-99, p.y-99, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
			}
		}
		return 0;

		case WM_MOUSEMOVE:
		{
			SetCursor(LoadCursor(NULL, IDC_ARROW));
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wParam, lParam);
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, TRUE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, TRUE);
	}
}