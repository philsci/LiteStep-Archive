Rainmeter 0.1 for litestep

This is a simple CPU/MEM Meter plugin for Litestep. It is a LoadModule plugin and not a Wharf module as most of the others. This one works only in Windows 2000 (and maybe in NT4). Win9x is not supported.

The configuration is done in the Rainmeter.ini file. The settings should be quite clear, so I'm not going to explain them here. I might implement equivalent step.rc settings later (as well as better documentation).

If you want to get rid of one of the meters (e.g. the MEM), just set its color to pink (255,0,255).

There are also two bangs you can use:
!RainmeterShow
!RainmeterHide

The example configuration's graphics are from the excellent Kgnome3 theme by KanedA.

Kimmo 'Rainy' Pekkola
rainy@iki.fi

