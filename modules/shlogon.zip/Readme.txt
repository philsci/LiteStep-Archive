Readme for Shell Logon
Updated Friday 30 June 2000

Thank you for downloading Shell Logon Version 0.4 Build.

Note:-
Shell Logon is for Windows 2000 and NT4 only. (I think it works on NT4, please let me know if it does or does not, I do not currently have NT4 installed, but I did start developing Shell Logon using it)
SHELL LOGON SHOULD WORK, BUT IN SOME CASES MAY NOT, Because of this it may stop you being able to logon, but you can rescue you computer if this does happen, please read the Saving Your Computer section below, and preferably print it.
Hopefully Shell Logon will install perfectly but I cannot guarantee this, but it works on my computer ok.
Please read my disclaimer first (It's at the bottom of the file)

Bug Fixes:-
Ive fixed several bugs if you want a list you can get it at my web page

Installation:-
Read section later in this readme file for if it goes wrong. And print it, as you might need it and you probably won't want to reinstall windows.
Unzip the 'Shell Logon.Zip' file (I guess you've already done this)
Run the 'Install.Inf' file (Right click it and select Install)
Run the 'Configure.exe' file, this will allow you to select the logon program your going to use (Shell Logon or M$ Logon). It also allows you to add/remove shells.
Reboot Your Computer.


Configure Program:-
To Add a shell:
Type in the shell name click the little ... button to the right of the Shell Path text box, and select the Shell's EXE file. Then press the Add/Update button.

To Update a Shell Path:
Double click on the shell you want to update, change the Path name and press the Add/Update button.

To Remove a shell:
Single or Double click on the shell and press the Remove button.


Saving Your Computer If it all goes Horribly Wrong:-
If after installing Shell Logon your are not able to logon or your computer doesn't work properly, or you get Blue Screens of Death at start up then please follow the following instruction.

In Windows 2000:
At boot up press F8 to get the boot up option screen
Select Safe Mode Command Line
Press Ctrl, Alt, Del and Type in your Username and Password
At the command line type 'regedit' (Without Quotes)
Go to 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' in the Registry
Double click on GinaDll
And type in 'MSGina.dll' (If you try again and it doesn't work please email me if you can and I will help)

In Windows NT4:
I haven't tried this but it should work,
Boot off the CD or the Emergency disk or the initial boot disks and tell the setup to check the files and replace incorrect ones (I'm not sure how this is worded), you don't have to get it to replace the SAM file, You may have to replace the Registry if it still doesn't work. I do have NT4 but it's not installed on any computer.

Web Site:-
www.uranium238.co.uk

Email:-
Grant@Uranium238.co.uk

Bug Reports:-
Bugs@Uranium238.co.uk


Disclaimer:-
I am not responsible for anything that happens to you, your computer, or anything associated to you and your life, when you use Shell Logon or the Configure program. If your computer goes into nuclear meltdown I'm not responsible for this either. By using Shell Logon or the Configure program you are agreeing to take full responsibility of any consequences related to using these programs. I am not guaranteeing that Shell Logon or the Configure program will be Bug free and will not harm you computer in any way. I AM NOT RESPONSIBLE FOR ANYTHING.
