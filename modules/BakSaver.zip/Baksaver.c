/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

05/17/00 - T. Crouson
			Added options to set position and size of the BakSaver window
			Fixed bug where mouse clicks were ignored
			Added option to disable mouse clicks (some screensaves don't like them)
  
05/15/00 - T. Crouson
			Updated to run on newer LiteStep Builds
			Added bangs to Start/Stop BakSaver
			Added option to allow BakSaver to start disabled

06/03/98 - F. Gastellu
            This file contains the source code for the Desktop-ScreenSaver
            module

****************************************************************************/

#include <windows.h>
#include <stdio.h>
#include "baksaver.h"
#include "..\\lsapi\\lsapi.h"

const char szAppName[] = "BakSaver"; // Our window class, etc
const char rcsRevision[] = "$Revision: r1 $"; // Our Version 

char szSaverPath [256];
char param[261];

void BangStopSaver(HWND sender, LPCSTR args);
void BangStartSaver(HWND sender, LPCSTR args);

void RegisterBangCommands(void);

void GetSettings(void);

BOOL StartRunning=TRUE;
BOOL DisableMouse=FALSE;
int BakSaverX = 0;
int BakSaverY = 0;
int BakSaverW = 0;
int BakSaverH = 0;
int ScreenWidth = 800;
int ScreenHeight = 600;

HWND desktop = NULL;
HWND SSaver = NULL;
HWND Pwin = NULL;

// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	Pwin = ParentWnd;

	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
		{
		MessageBox(ParentWnd, "Could not locate desktop!", "Background ScreenSaver - Error", 0);
		return 1;
		}
	GetSettings();

	if (StartRunning == TRUE)
	{
		BangStartSaver(ParentWnd, NULL);
	}
	RegisterBangCommands();

	return 0;
}


void RegisterBangCommands(void)
{
	
	AddBangCommand("!BakSaverStop", BangStopSaver);
	AddBangCommand("!BakSaverStart", BangStartSaver);
}


void BangStartSaver(HWND sender, LPCSTR args)
{
	SSaver = FindWindowEx(desktop, NULL, "WindowsScreenSaverClass", NULL);
	if (!SSaver)
	{
		sprintf(param, "%s /P %d", szSaverPath, (int)desktop);
		if (WinExec(param, SW_SHOW) > 32);
		{
			SSaver = FindWindowEx(desktop, NULL, "WindowsScreenSaverClass", NULL);
			MoveWindow(SSaver, BakSaverX, BakSaverY, BakSaverW, BakSaverH, TRUE);
			UpdateWindow(SSaver);
			if (DisableMouse == FALSE) EnableWindow(SSaver, FALSE);
		}
	}
}


void BangStopSaver(HWND sender, LPCSTR args)
{
	EnableWindow(SSaver, TRUE);
	if (!SSaver)
	{
		MessageBox(sender, "Could not locate screensaver! - Cannot Stop BakSaver!", "Background ScreenSaver - Error", MB_ICONEXCLAMATION);
	}
	else
	{
		PostMessage(SSaver, WM_SYSCOMMAND, SC_CLOSE, 0);
	}
}


void GetSettings(void)
{
	StartRunning = GetRCBool("BakSaverStartDisabled", FALSE);
	DisableMouse = GetRCBool("BakSaverDisableMouseClicks", TRUE);
	BakSaverX = GetRCInt("BakSaverX", BakSaverX);
	BakSaverY = GetRCInt("BakSaverY", BakSaverY);
	BakSaverW = GetRCInt("BakSaverW", BakSaverW);
	BakSaverH = GetRCInt("BakSaverH", BakSaverH);

	if (BakSaverX < 0) BakSaverX = ScreenWidth-BakSaverX;
	if (BakSaverY < 0) BakSaverY = ScreenHeight-BakSaverY;
	if (BakSaverW == 0) BakSaverW = ScreenWidth;
	if (BakSaverH == 0) BakSaverH = ScreenHeight;

	if (! GetRCString("BackScreenSaver", szSaverPath, "", 256))
		{
		MessageBox(Pwin, "No ScreenSaver specified, use BackScreenSaver in step.rc", "Background ScreenSaver - Error", MB_ICONEXCLAMATION);
		}										   


}


// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
	EnableWindow(SSaver, TRUE);
	PostMessage(SSaver, WM_SYSCOMMAND, SC_CLOSE, 0);
	// WM_DESTROY is automatically sent to desktop's childs upon destoywindow(desktop)
}
