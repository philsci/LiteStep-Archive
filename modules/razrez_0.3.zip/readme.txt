=========================================
Razrez.dll by Azathoth (2000) version 0.3
=========================================

I was writing an app to hack the resolutions on the pc's at school (they're locked out) when i got bored :)
This is the result. I just took the ole DEVMODE code and stuck it somewhere new.

Whats New: erm.. not much. We now have a frequency addition. This allows you to specify what frequency you wish to run at. This was a requested feature by Don Diego.
Also, i forgot it last time but you can now change resolution on starting and quitting litestep.
Aussi, misc code updates. Cleaned some stuff up. (Still working on getting that char* running through a damn message tho).

usage:
loadmodule c:\path_to_dll\razrez.dll

change resolution by using:
!razrez <bpp> <width> <height> <freq>
ie. !razrez 16 800 600 60

or put:

*razrez <bpp> <width> <height> <freq>
ie. *razrez 32 1024 768 75

in yer step to have razrez.dll change the display on startup..
btw, this function is to the best of my knowledge useless, i was just bored...

new funtion:

*razrezout <bpp> <width> <height> <freq>
ie. *razrezout 24 1600 1200 80

use this to change the resolution on quitting litestep. This enables you to change the res on entry and exit of ls allowing youto use different res' for ls and other shells.

well that's it i think...

thanks to no-one really... i did it all on my lonesome...

btw. the name razrez comes from A Clockwork Orange by Anthony Burgess and means "cut-up". It also derives from Az & Rez.
neways...

contact info: 
e-mail: azathoth@intricatechaos.com
web: http://www.intricatechaos.com/
icq: 25810657