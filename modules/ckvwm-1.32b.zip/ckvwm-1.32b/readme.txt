ckVWM 1.32b - a patch by Erik Christiansson, aka Sci

The only difference is when you are using *VWMStartWindowsOnDesktop lines. If you append the word true afte the desk number (*VWMStartWindowsOnDesktop "IEFrame" 3 true), the focus will follow the window into the new desk. It seems to work most of the time for me. Sometimes it fails to give the window focus, but it does atleast change desk. Haven't had to much time to test it yet, but it seems stable on my machine.
