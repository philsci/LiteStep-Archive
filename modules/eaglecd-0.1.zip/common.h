
////
/// common include
//

#ifndef __COMMON_H
#define __COMMON_H

#ifndef EXTERN_C
  #ifdef __cplusplus
    #define EXTERN_C extern "C"
  #else
    #define EXTERN_C
  #endif
#endif

#ifndef DECLSPEC_EXPORT
  #define DECLSPEC_EXPORT __declspec(dllexport)
#endif

//
// typedefs
//

typedef BOOL (*REMOVEBANGCOMMAND)( LPCTSTR );

//
// structs
//

// Global variables are defined here
typedef struct _GLOBALS {
	HWND hWnd;
	char nDrive[3]; //define the drive we will be using
	int track; //define the track number we want to play
	int ntracks; //define the total number of tracks on the 
} GLOBALS;

//
// constants
//

// the ST_ constants should be changed to reflect
// the info for your module. if you add RC or bang
// commands add the constants here.

// strings
#define ST_SHORTNAME      TEXT("eagleCD")
#define ST_NAME           TEXT("Eagle CD Control")
#define ST_VERSION        TEXT("0.1")
#define ST_AUTHOR         TEXT("Aaron Meola (Eagle)")
#define ST_REVID          ST_NAME TEXT(" ") ST_VERSION TEXT(" by ") ST_AUTHOR

// window classes
#define WC_LSDESKTOP      TEXT("DesktopBackgroundClass")
#define WC_MAIN           ST_SHORTNAME

// RC commands
#define RC_NAME           ST_SHORTNAME
#define RC_DRIVE		  RC_NAME TEXT("Drive")

// Our bang commands are defined here
#define BC_NAME           TEXT("!") ST_SHORTNAME
#define BC_PLAY			  "!CD_Play"
#define BC_PAUSE		  "!CD_Pause"
#define BC_STOP			  "!CD_Stop"
#define BC_RESUME		  "!CD_Resume"
#define BC_PREV			  "!CD_Prev"
#define BC_NEXT			  "!CD_Next"
#define BC_EJECT		  "!CD_Eject"
#define BC_TRACK		  "!CD_SetTrack"

//
// global variables
//

// so we don't have a ton of extern statements,
// we place all global variables in a single
// struct.

extern GLOBALS globals;

//
// functions
//

// main window procedure
LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );

// Definition of our bang commands
void BangPlay( void );
void BangStop( void );
void BangPause( void );
void BangResume( void );
void BangPrevious( void );
void BangNext( void );
void BangEject( void );
void BangSetTrack (  HWND, LPCTSTR );

#endif
