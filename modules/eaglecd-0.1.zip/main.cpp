/**************************************************
 * eagleCD v0.1 (22/07/2001)                      *
 * By Aaron Meola (Eagle)                         *
 *                                                *
 * This source is mainly released for educational *
 * purposes. If you want to use it, please let my *
 * know by sending an E-mail to                   *
 * aaronm@chariot.net.au                          *
 *                                                *
 * This code was based on the module template     *
 * produced by maduin@dasoft.org                  *
 *                                                *
 * Check out the readme.txt file for more         *
 * information on the source code                 *
 **************************************************/


////
/// Better import functions we'll need
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdio.h>
#include <vfw.h>
#include "lsapi.h"
#include "common.h"
#include "wharfdata.h"

//
// Defining some variables
//

GLOBALS globals;

UINT nMessages[] = {
	LM_GETREVID,
	0
};


//
// Function for reading in the configuration in step.rc and for doing some inital setting up
//

void ReadConfig()
{
	GetRCString( RC_DRIVE, globals.nDrive, 0, 2);
	if(strcmp(globals.nDrive,"")==1)
	{
		wsprintf(globals.nDrive, "d:"); 
	}
	globals.track=1;
	globals.ntracks=0;
}

//
// Initialise the module and let litestep know we're here.
//

EXTERN_C DECLSPEC_EXPORT int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	HWND hLitestep;
	
	hLitestep = GetLitestepWnd();
	
	// read in config
	ReadConfig();
	
	// register for messages from the LS core
	SendMessage( hLitestep, LM_REGISTERMESSAGE, (WPARAM) globals.hWnd, (LPARAM) nMessages );
	

	// add our bang commands
	AddBangCommand( BC_PLAY, BangPlay );
	AddBangCommand( BC_STOP, BangStop );
	AddBangCommand( BC_PAUSE, BangPause );
	AddBangCommand( BC_RESUME, BangResume );
	AddBangCommand( BC_PREV, BangPrevious );
	AddBangCommand( BC_NEXT, BangNext );
	AddBangCommand( BC_EJECT, BangEject );
	AddBangCommand( BC_TRACK, BangSetTrack );
	
	return 1;
}

//
// initModule
//

EXTERN_C DECLSPEC_EXPORT int initModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	return initModuleEx( hParent, hInstance, wd->lsPath );
}

//
// When we exit, we need to cleanup after ourselves
//

EXTERN_C DECLSPEC_EXPORT void quitModule( HINSTANCE hInstance )
{
	REMOVEBANGCOMMAND pRemoveBangCommand;
	
	// since RemoveBangCommand is only available in the
	// devbuilds for now, we need link to it dynamically
	// in case the user only has 24.4. eventually this
	// will no longer be necessary.
	
	pRemoveBangCommand = (REMOVEBANGCOMMAND) GetProcAddress(
		GetModuleHandle( TEXT("LSAPI.DLL") ), TEXT("RemoveBangCommand") );
	
	if( pRemoveBangCommand )
	{
		(*pRemoveBangCommand)( BC_PLAY );
		(*pRemoveBangCommand)( BC_PAUSE );
		(*pRemoveBangCommand)( BC_STOP );
		(*pRemoveBangCommand)( BC_RESUME );
		(*pRemoveBangCommand)( BC_PREV );
		(*pRemoveBangCommand)( BC_NEXT );
		(*pRemoveBangCommand)( BC_EJECT );
		(*pRemoveBangCommand)( BC_TRACK );
	}
	
	// Stop the cd from playing and close the open device

	char lpstrCommand[2000];
	BangStop();
	wsprintf(lpstrCommand, "close cd2"); 
	mciSendString(lpstrCommand, NULL, 0, NULL);

	// unregister our window for messages we registered
	// during initModuleEx
	
	SendMessage( GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM) globals.hWnd,
		(LPARAM) nMessages );
	
	// destroy the module window and unregister the window
	// class.

}


//
// DllMain
//

EXTERN_C int APIENTRY DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )
	{
		memset( &globals, 0, sizeof(GLOBALS) );
		DisableThreadLibraryCalls( hInstance );
	}
	
	return 1;
}
