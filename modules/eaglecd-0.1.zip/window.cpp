
////
/// main window procedure
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <afxwin.h>
#include <stdio.h>
#include "lsapi.h"
#include "common.h"

LRESULT WINAPI WndProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam )
{
	char txt[20];
	switch( nMessage )
	{
		case LM_GETREVID:
		{
			LPTSTR pszBuf = (LPTSTR) lParam;
			
			if( wParam == 0 || wParam == 1 )
				strcpy( pszBuf, ST_REVID );
			else
				pszBuf[0] = 0;
			
			return strlen( pszBuf );
		}
		
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;
			RECT r;
			
			if( !wParam )
				hDC = BeginPaint( hWnd, &ps );
			else
				hDC = (HDC) wParam;
			
			// insert paint code here...
			GetClientRect( hWnd, &r );
			DrawEdge( hDC, &r, EDGE_RAISED, BF_RECT | BF_MIDDLE );
			SetBkMode( hDC, TRANSPARENT );
			wsprintf(txt, "$d", globals.track); 
			DrawTextEx( hDC, TEXT(txt), 16, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE, NULL );
			
			if( !wParam )
				EndPaint( hWnd, &ps );
			
			return 0;
		}
		
		case WM_WINDOWPOSCHANGING:
		{
			LPWINDOWPOS pwp = (LPWINDOWPOS) lParam;
			
			// if we're on the desktop and not always on top
			// make sure we stay below toplevel windows.
			
			if( !globals.fAlwaysOnTop )
				pwp->flags |= SWP_NOZORDER;
			
			return 0;
		}
	}
	
	return DefWindowProc( hWnd, nMessage, wParam, lParam );
}
