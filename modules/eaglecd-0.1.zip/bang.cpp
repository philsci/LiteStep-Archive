
////
/// Bang command functions are stored here
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <afxwin.h>
#include <vfw.h>
#include "lsapi.h"
#include "common.h"


//
// Command to play a CD
//

void BangPlay()
{
	char lpstrCommand[200];
	char result[200];
	
	wsprintf(lpstrCommand, "open %s type cdaudio alias cd2", globals.nDrive); 
    mciSendString(lpstrCommand, NULL, 0, NULL);
	mciSendString("status cd2 number of tracks",result,200,NULL);
	globals.ntracks=strtol(result,NULL,10);

	mciSendString("set cd2 time format tmsf",NULL,0,NULL);
    wsprintf(lpstrCommand, "play cd2 from %d:0:0:0", globals.track); 
	mciSendString(lpstrCommand, NULL, 0, NULL);
}

//
// Command to eject a cd
//

void BangEject()
{
	mciSendString("set cd2 door open",NULL,0,NULL);

    //Reset the track and number of tracks to 0 and the track to start from to 1

	globals.track=1;
	globals.ntracks=0;

}

//
// Command for next track
//

void BangNext()
{
	char lpstrCommand[2000];
	wsprintf(lpstrCommand, "status cd2 current track"); 
	char result[200];
	mciSendString(lpstrCommand,result,200,NULL);

//Ensure we are not at the last track

	if(strtol(result,NULL,10)!=globals.ntracks)
	{
		wsprintf(lpstrCommand,"play cd2 from %d:0:0:0",(strtol(result,NULL,10)+1));
		mciSendString(lpstrCommand,NULL,0,NULL);
	}
}

//
// Command for previous track
//

void BangPrevious()
{
	char lpstrCommand[2000];
	wsprintf(lpstrCommand, "status cd2 current track"); 
	char result[200];
	mciSendString(lpstrCommand,result,200,NULL);

//Ensure we are not at the first track

	if(strtol(result,NULL,10)!=1)
	{
		wsprintf(lpstrCommand,"play cd2 from %d:0:0:0",(strtol(result,NULL,10)-1));
		mciGetErrorString(mciSendString(lpstrCommand,NULL,0,NULL),lpstrCommand,2000);
	}
}

//
// Command to resume playback
//

void BangResume()
{
	char lpstrCommand[2000];
	wsprintf(lpstrCommand, "resume cd2"); 
	mciSendString(lpstrCommand, NULL, 0, NULL); 
}

//
// Command to pause playback
//

void BangPause()
{
	char lpstrCommand[2000];
	wsprintf(lpstrCommand, "pause cd2");
	mciSendString(lpstrCommand, NULL, 0, NULL); 
}

//
// Command to stop playback
//

void BangStop()
{
	char lpstrCommand[2000];
	wsprintf(lpstrCommand, "stop cd2");
	mciSendString(lpstrCommand, NULL, 0, NULL);
	globals.track=1; //Reset the track number to 1
}

//
// Set the track number to play
//

void BangSetTrack( HWND hCaller, LPCTSTR pszArgs )
{
	LPTSTR rgszTokens[1];
	char lpstrCommand[2000];

	//ensure we have the right number of arguemnts

	if( LCTokenize( pszArgs, rgszTokens, 1, NULL ) == 1 )
    {

		//If we have not set the number of tracks on the CD, do so

		if (globals.ntracks==0)
		{
			wsprintf(lpstrCommand, "open %s type cdaudio alias cd2", globals.nDrive); 
			mciSendString(lpstrCommand, NULL, 0, NULL);
			char result[200];
			mciSendString("status cd2 number of tracks",result,200,NULL);
			globals.ntracks=strtol(result, NULL, 10);

		}

		//If the track number set is below the number of tracks on the CD, set the track to play.

		if (strtol(pszArgs,NULL,10) < globals.ntracks)
		{
			globals.track = strtol(pszArgs, NULL, 10);
			wsprintf(lpstrCommand, "We have $d tracks", globals.nDrive); 
		}
	}
}
