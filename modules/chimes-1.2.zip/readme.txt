--------------------------------------------------------------------
  Chimes.dll v1.2					  09/16/99
--------------------------------------------------------------------

Chimes is Litestep loadmodule. It plays specified WAV file every
15 minutes. You can specify different WAV for hour, half-hour, and
quarter-hour intervals. There can be multiple WAV files in one
chime, each one can be played multiple times (x hour).

This module was written in Delphi 3, using LSDevKit by Murphy.


--------------------------------------------------------------------
  Installation
--------------------------------------------------------------------

Simply load at startup as:

  LoadModule "c:\litestep\chimes.dll"


--------------------------------------------------------------------
  Setup
  step.rc commands:
--------------------------------------------------------------------

; Disable chimes at startup
; (default: enabled)
; ChimesStartDisabled

; Specify which WAV file to play every hour
ChimeHour "path_to\filename.wav"

; Specify which WAV file to play at half-hour
ChimeHalf "path_to\filename.wav"

; Specify which WAV file to play at quarter after hour
ChimeQuarterAfter "path_to\filename.wav"

; Specify which WAV file to play at quarter before hour
ChimeQuarterBefore "path_to\filename.wav"

; Bang commands:
;
; Play WAV
;   !Chime "path_to\filename.wav"
; Enable chimes
;   !ChimesEnable
; Disable chimes
;   !ChimesDisable
; Toggle chimes
;   !ChimesToggle


There can be multiple WAV files in one chime, separated by '|'.
They will be played sequentially:

  ChimeHour c:\sounds\hour.wav|c:\sounds\hourbell.wav

Also, if the wave-filename is preceded by '*', it will be played
multiple times (x hour):

  ChimeHour c:\sounds\hour.wav|*c:\sounds\hourbell.wav

i.e. at six o'clock it will play hour.wav, then 6x hourbell.wav.
This feature brings greater flexibility to define more complex
chimes.

--------------------------------------------------------------------
  History
--------------------------------------------------------------------

v1.2	09/16/99
  + Added separate chimes for quarter intervals
  - Removed 'Multiple chimes' switch - replaced by '*' prefix
  * Changed chime format - multiple waves, multiple playing
  * Optimizations

v1.1	09/06/99
  * Lower memory requirements
  * Minor bugfixes
  + Added 'Multiple chimes' feature (on request)

v1.0
  Initial version

Known bugs:
  In rare cases, if your audio device is busy, chime won't play
at all. In multiple mode, when Chimes doesn't succeed playing
the first chime at exact hour interval, it aborts remaining
chimes.

====================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www:	http://come.to/pavel.vitis/

LSDevKit by Murphy:
http://www.dev0.de/
