This is the new-and-improved version of ripple!
Commands:

;Load
LoadModule ripple.dll

;Bools:
RippleStartHidden
	start ripple hidden (default shown)
RippleUp
	reverse ripple direction from down to up (default down)

;Ints:
RippleFrequency 3
	frequency of waves (default 3)
RippleAmplitude 5
	amplitude of waves (default 5)

;Position:
*Ripple 0 500 531 100 
	;*Ripple [x-coord] [y-coord] [x-length] [y-width]

The ripple window can be shown or hidden with the !ToggleRipple bang command.

Have fun,
Crank