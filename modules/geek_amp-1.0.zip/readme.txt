******************************************************************************
This file was created on 1:09 AM 11/17/98 by GeekMaster
******************************************************************************
(	
	Lowell Heddings
	lheddings@geocities.com
	AIM: lheddin
	IRC: Geekmasta
	ICQ: 17869937
)
******************************************************************************
	This .dll file is used to control Winamp via !<commands> in the step.rc
file of litestep.
******************************************************************************

To use: Simply add a line to your step.rc file that looks like the following:

	LoadModule c:\litestep\geek_amp.dll

I think this has to be loaded after the other modules, but I'm not sure.

******************************************************************************

Once you have loaded the module, you can use any of the commands anywhere
in litestep. This could be either a Shortcut or a Hotkey or a Wharf.

For Instance:
	*Hotkey Win F9 !Amp_Play
	This line would assign the combo of Win + F9 to Play the current song
The commands are not case sensitive, either

******************************************************************************
New Commands:
******************************************************************************

!AMP_PLAY
	Pretty Obvious

!AMP_PAUSE
	""
!AMP_STOP
	""
!AMP_NEXT
	""
!AMP_PREV
	This changes to the previous song
!AMP_VOLUMEUP
	This turns the volume up a little
!AMP_VOLUMEDOWN
	This turns the volume down a little
!AMP_LOADFILE
	This pops up the load file box
!AMP_FFWD5S
	This Fast Forwards 5 seconds
!AMP_REW5S
	This Rewinds 5 seconds
!AMP_EQ
	This TOGGLES the EQ window. This means, for instance, if you create
	a hotkey with this action, that you press it once to display, and
	again to hide.
!AMP_PLAYLIST
	This TOGGLES the Playlist window. See Above
!AMP_PREFS
	This TOGGLES the Preferences window. See Above
!AMP_ONTOP
	This TOGGLES whether or not WinAmp is on top
!AMP_REW
	This rewinds as well. This actually executes the function of the rewind button
!AMP_ABOUT
	This displays the About dialog for Winamp


