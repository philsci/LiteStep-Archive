install:
extract to litestep directory and load with LoadModule

step.rc commands:
*Alarm - time/command to execute
         ex: *Alarm 1:00AM "C:\program files\winamp\winamp.exe" c:\mp3s\
		 this will execute winamp at 1am
*AlarmInt - will execute a command every however minutes
			ex: *AlarmInt 5 "C:\4dos\4dos.com"
			this will execute 4dos every 5 minutes (don't know why you'd want to =)

bang commands:
!togglealarm - toggles the alarm on/off
!disablealarm - disables the alarm
!enablealarm - enables the alarm
!alarmstat - shows some status information


changes:
	0.9:
		- changed version numbers
		- can have more than 1 alarm now
		- added alarm interval, this will execute a command every however minutes
	1b:
		- first release.


please email me with comments/suggestions/bugs

- pod (danielb@vnet.net)
http://thunder.prohosting.com/~danielb/
