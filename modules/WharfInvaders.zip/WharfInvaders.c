#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "WharfInvaders.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "WharfInvaders"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
int LoadSetup();
int DrawOne(HDC buf, int x, int y, COLORREF I);
int DrawTwo(HDC buf, int x, int y, COLORREF I);
int DrawThree(HDC buf, int x, int y, COLORREF I);
int DrawShip(HDC buf, int x, int y, COLORREF I);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
DWORD MB = MB_OK | MB_SETFOREGROUND;
HBITMAP backImage = NULL;
int CursorTimer=0;
int Timer=0;
char ini[MAX_PATH] = "c:\\litestep\\modules.ini";
HMENU Popup;

// Globals
int LIVES=3;
int DEMO=0;
int SHIPX=25, SHIPY=55;
int IX=10, IY=5;
HBRUSH hpaddle;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;
    if (wharfData.borderSize < 0)
		wharfData.borderSize = 0;


    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }

	sprintf(ini, "%smodules.ini", wharfData.lsPath);
	LoadSetup();

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	//if (DEMO) 
	//{
	//	SendMessage(hMainWnd, WM_LBUTTONDOWN, 0, 0);
	//}

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	DeleteObject(hpaddle);
	DestroyMenu(Popup);
    DestroyWindow(hMainWnd);                // delete our window
    UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
                if (!backImage)
				{
					HDC hdc = GetDC(parent);
					HDC buf = CreateCompatibleDC(NULL);

					backImage = CreateCompatibleBitmap(hdc, 64, 64);
					SelectObject(buf, backImage);
					BitBlt(buf, 0, 0, 64, 64, hdc, 0, 0, SRCCOPY);

					ReleaseDC(hdc,hwnd);
					DeleteDC(buf);
				}
				{
					PAINTSTRUCT ps;
					HDC hdc = BeginPaint(hwnd,&ps);
					HDC src = CreateCompatibleDC(NULL);
					HDC buf = CreateCompatibleDC(NULL);
					HBITMAP bufBMP = CreateCompatibleBitmap(hdc, 64, 64);
					COLORREF G = 0x0000FF00;
					COLORREF Y = 0x0000FFFF;
					COLORREF P = 0x00FF00FF;
					COLORREF B = 0x00FFFF00;
					int x=25, y=25;

					SelectObject(buf, bufBMP);
					
					if (backImage)
					{
						SelectObject(src, backImage);
						BitBlt(buf, 0, 0, 64, 64, src, 0, 0, SRCCOPY);
					}
					
					DrawOne(buf, 12, 5, G);
					DrawOne(buf, 24, 5, G);
					DrawOne(buf, 36, 5, G);
					DrawOne(buf, 48, 5, G);
					DrawTwo(buf, 10, 15, Y);
					DrawTwo(buf, 22, 15, Y);
					DrawTwo(buf, 34, 15, Y);
					DrawTwo(buf, 46, 15, Y);
					DrawThree(buf, 10, 25, P);
					DrawThree(buf, 22, 25, P);
					DrawThree(buf, 34, 25, P);
					DrawThree(buf, 46, 25, P);
					
					DrawShip(buf, SHIPX, SHIPY, B);

					BitBlt(hdc, 0, 0, 64, 64, buf, 0, 0, SRCCOPY);

					EndPaint(hwnd,&ps);
					DeleteDC(src);
					DeleteDC(buf);
					DeleteObject(bufBMP);
				}
			}
            return 0;
        case WM_KEYDOWN:
		{
			char temp[25] = "";
			sprintf(temp, "%d", (int) wParam);
			MessageBox(NULL, temp, "WharfInvaders", MB);
		}
		return 0;
        case WM_KEYUP:
            //PostMessage(parent,message,wParam,lParam);
            return 0;
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
			{
			//DWORD dw = GetMessagePos();
			//TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			}
			return 0;
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_LBUTTONDOWN:
		{
			SetFocus(hwnd);
		}
		return 0;
		case WM_MOUSEMOVE:
		{
		}
		return 0;
		case WM_TIMER:
		{
		}
		return 0;
		case WM_COMMAND:
		{
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int LoadSetup()
{
	return 1;
}

int DrawOne(HDC buf, int x, int y, COLORREF I)
{
	x+=2;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	y++;
	x-=2;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=4;
	y++;
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x-=5;
	y++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=4;
	y++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x-=4;
	y++;
	SetPixel(buf, x, y, I);
	x+=5;
	SetPixel(buf, x, y, I);
	x-=4;
	y++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	return 1;
}

int DrawTwo(HDC buf, int x, int y, COLORREF I)
{
	x+=2;
	SetPixel(buf, x, y, I);
	x+=5;
	SetPixel(buf, x, y, I);
	y++;
	x-=7;

	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x-=9;
	y++;
	
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x+=2;
	SetPixel(buf, x, y, I);
	x-=8;
	y++;
	
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=6;
	y++;
	
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=5;
	y++;
	
	SetPixel(buf, x, y, I);
	x+=5;
	SetPixel(buf, x, y, I);
	x-=6;
	y++;
	SetPixel(buf, x, y, I);
	x+=7;
	SetPixel(buf, x, y, I);
	return 1;
}

int DrawThree(HDC buf, int x, int y, COLORREF I)
{
	x+=3;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=5;
	y++;

	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=8;
	y++;

	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=9;
	y++;

	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=7;
	y++;

	SetPixel(buf, x, y, I);
	x+=5;
	SetPixel(buf, x, y, I);
	x-=6;
	y++;

	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x+=3;
	SetPixel(buf, x, y, I);
	x-=6;
	y++;

	SetPixel(buf, x, y, I);
	x+=5;
	SetPixel(buf, x, y, I);
	return 1;
}

int DrawShip(HDC buf, int x, int y, COLORREF I)
{
	HPEN pen = CreatePen(PS_SOLID, 0, I);
	SelectObject(buf, pen);

	x+=5;
	SetPixel(buf, x, y, I);
	x--;
	y++;
	
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x++;
	SetPixel(buf, x, y, I);
	x-=5;
	y++;
	
	MoveToEx(buf, x, y, NULL);
	LineTo(buf, x+8, y);
	x--;
	y++;
	
	MoveToEx(buf, x, y, NULL);
	LineTo(buf, x+10, y);
	y++;
	
	MoveToEx(buf, x, y, NULL);
	LineTo(buf, x+10, y);

	DeleteObject(pen);
	return 1;
}
