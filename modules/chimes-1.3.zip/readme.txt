--------------------------------------------------------------------
  Chimes.dll v1.3					  09/27/99
--------------------------------------------------------------------

Chimes is Litestep loadmodule. It plays specified WAV file every
15 minutes. You can specify different WAV for hour, half-hour, and
quarter-hour intervals. There can be multiple WAV files in one
chime, each one can be played multiple times (x hour).

This module was written in Delphi 3, using LSDevKit by Murphy.


--------------------------------------------------------------------
  Installation
--------------------------------------------------------------------

Simply load at startup as:

  LoadModule "c:\litestep\chimes.dll"


--------------------------------------------------------------------
  Setup
  step.rc commands:
--------------------------------------------------------------------

; Disable chimes at startup
; (default: enabled)
; ChimesStartDisabled

; Specify chime waves directory
; default: empty
ChimesDir "path_to_wave_files"

; Specify which WAV file to play every hour
ChimeHour "[path_to\]filename.wav"

; Specify which WAV file to play at half-hour
ChimeHalf "[path_to\]filename.wav"

; Specify which WAV file to play at quarter after hour
ChimeQuarterAfter "[path_to\]filename.wav"

; Specify which WAV file to play at quarter before hour
ChimeQuarterBefore "[path_to\]filename.wav"

; Bang commands:
;
; Play WAV - You should specify *FULL PATH* here!
;   !Chime "path_to\filename.wav"
; Enable chimes
;   !ChimesEnable
; Disable chimes
;   !ChimesDisable
; Toggle chimes
;   !ChimesToggle
; Abort any currently playing chime
;   !ChimeAbort


There can be multiple WAV files in one chime, separated by '|' character.
They will be played sequentially:

  ChimeHour c:\sounds\hour.wav|c:\sounds\hourbell.wav

Also, if the wave-filename is preceded by '*', it will be played
multiple times (x hour):

  ChimeHour c:\sounds\hour.wav|*c:\sounds\hourbell.wav

i.e. at six o'clock it will play hour.wav, then 6x hourbell.wav.
This feature brings greater flexibility to define more complex
chimes.

When the chime is not the last chime in the chain, you can limit
its playing duration by specifying time in 1/100 sec, preceding
the number by '#' character (1..1000):

  ChimeHour c:\sounds\hour.wav|*#80c:\sounds\hourbell.wav

i.e. at six o'clock it will play hour.wav, then 5x hourbell.wav
each playing at 80*1/100sec duration, and then 1x hourbell.wav at
full duration. It is useful when the hourbell.wav is for example
some "tower bell" sound, and has very long sustain. This sustain
should be heard at the last bell strike only.
If you specify longer limit than the real wave duration is,
it will produce gap after the wave has been played.
If you wish to specify this limit and your wave filename begins
with number(s), specify the limit as four digit number, preceded
by zeros, as needed:

  ChimeHour c:\sounds\hour.wav|*#0080101hourbell.wav

It will play 101hourbell.wav with 80*1/100 second duration limit.


--------------------------------------------------------------------
  History
--------------------------------------------------------------------

v1.3	09/27/99
  + Added optional "ChimesDir" parameter to aid shorter chimes
    definitions
  + Added option to limit/extent playing-duration for multiple chimes
  + Added bang !ChimeAbort to abort (mute) currently played chime
    (twelve bell strikes at 12:00 is sometimes too much for your
    ears, especially at night, playing your favorite game or doing
    some litestep-module coding :)

v1.2	09/16/99
  + Added separate chimes for quarter intervals
  - Removed 'Multiple chimes' switch - replaced by '*' prefix
  * Changed chime format - multiple waves, multiple playing
  * Optimizations

v1.1	09/06/99
  * Lower memory requirements
  * Minor bugfixes
  + Added 'Multiple chimes' feature (on request)

v1.0
  Initial version


Future plans:
  Add option to "sleep" chimes in certain time interval.


Known bugs:
  In rare cases, if your audio device is busy, chime won't play
at all. In multiple mode, when Chimes doesn't succeed playing
the first chime at exact hour interval, it aborts remaining
chimes.

====================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www:	http://come.to/pavel.vitis/

LSDevKit by Murphy:
http://www.dev0.de/
