/*
!AUTORAISETIME <timeout> 	initial windows default is 0
!TOGGLEAUTOFOCUS 	initial windows default is OFF (changes Zorder)
!TOGGLEAUTORAISE 	initial windows default is OFF (window tracking)
!CLICKTORAISE
!AUTOFOCUSRAISE
<timeout> is the time in milliseconds that the cursor has 
to be in a window before focus changes;

TOGGLEAUTORAISE toggles the window being automatically brought to the front. 
TOGGLEAUTOFOCUS toggles window under mouse to getting focus.

llornkcor@llornkcor.com
*/
#include <windows.h>
#include <stdio.h>
#include <winuser.h>
#include "xmouse.h"
#include "..\ls-b24\lsapi\lsapi.h"

void SetAutoRaiseTime(HWND caller, char* arg);
void ToggleFocus(HWND caller, char* arg);
void ToggleAutoRaise(HWND caller, char* arg);

void ClickToFocus(HWND caller, char* arg);
void AutoFocusRaise(HWND caller, char* arg);
bool checkOSVersion();

bool bTracking;
DWORD dwTrkTimeout;
bool bRaise;

HWND parent;

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
  return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  parent = ParentWnd;
  
  if( checkOSVersion() == TRUE)
  {
 
  bTracking = false;
  dwTrkTimeout = NULL;
  bRaise = false;

  AddBangCommand("!AUTORAISETIME", SetAutoRaiseTime);
  AddBangCommand("!TOGGLEAUTOFOCUS", ToggleFocus); 
  AddBangCommand("!TOGGLEAUTORAISE", ToggleAutoRaise);
  AddBangCommand("!CLICKTORAISE", ClickToFocus);
  AddBangCommand("!AUTOFOCUSRAISE", AutoFocusRaise);
  }
  else
     quitModule( dllInst);
  return 0;
}

void quitModule(HINSTANCE dllInst)
{
   RemoveBangCommand("!AUTORAISETIME");
   RemoveBangCommand("!TOGGLEAUTOFOCUS");
   RemoveBangCommand("!TOGGLEAUTORAISE");
   RemoveBangCommand("!CLICKTORAISE");
   RemoveBangCommand("!AUTOFOCUSRAISE"); 
// nothing to do
}

void SetAutoRaiseTime(HWND caller, char* arg)
{//AUTORAISETIME
	SystemParametersInfo( SPI_GETACTIVEWNDTRKTIMEOUT, 0, &dwTrkTimeout, 0 );
	 dwTrkTimeout = (DWORD) atol(arg);
	 if (dwTrkTimeout < 2000)
	 SystemParametersInfo(  SPI_SETACTIVEWNDTRKTIMEOUT, 0, (PVOID) dwTrkTimeout,  SPIF_SENDCHANGE | SPIF_UPDATEINIFILE );
}

void ToggleFocus(HWND caller, char* arg)
{ //TOGGLEAUTOFOCUS
	SystemParametersInfo( SPI_GETACTIVEWINDOWTRACKING, 0, &bTracking, 0 );
	
	if ( !bTracking ) // turn on window tracking
	   SystemParametersInfo( SPI_SETACTIVEWINDOWTRACKING,0, (PVOID) TRUE,   SPIF_SENDCHANGE | SPIF_UPDATEINIFILE  );	
	else if ( bTracking ) // turn off window tracking
	   SystemParametersInfo( SPI_SETACTIVEWINDOWTRACKING,0, (PVOID) FALSE,   SPIF_SENDCHANGE | SPIF_UPDATEINIFILE  );	
}

void ToggleAutoRaise(HWND caller, char* arg)
{ //TOGGLEAUTORAISE
	SystemParametersInfo( SPI_GETACTIVEWNDTRKZORDER, 0,  &bRaise, 0 );

	if ( !bRaise ) // turn on autoraise
		SystemParametersInfo( SPI_SETACTIVEWNDTRKZORDER, 0, (PVOID) TRUE,  SPIF_SENDCHANGE | SPIF_UPDATEINIFILE );
	else if ( bRaise) // turn off autoraise
		SystemParametersInfo( SPI_SETACTIVEWNDTRKZORDER, 0, (PVOID) FALSE,  SPIF_SENDCHANGE | SPIF_UPDATEINIFILE ); 
}

void ClickToFocus(HWND caller, char* arg)
{ //CLICKTORAISE
	SystemParametersInfo( SPI_GETACTIVEWINDOWTRACKING, 0, &bTracking, 0 );
    SystemParametersInfo( SPI_GETACTIVEWNDTRKZORDER, 0,  &bRaise, 0 );

	if ( !bTracking ) // turn on window tracking
		SystemParametersInfo( SPI_SETACTIVEWINDOWTRACKING,0, (PVOID) TRUE,   SPIF_SENDCHANGE | SPIF_UPDATEINIFILE  );	
	      
	if ( bRaise ) // turn off autoraise
		SystemParametersInfo( SPI_SETACTIVEWNDTRKZORDER, 0, (PVOID) FALSE,  SPIF_SENDCHANGE | SPIF_UPDATEINIFILE );

}

void AutoFocusRaise(HWND caller, char* arg)
{ //AUTOFOCUSRAISE
	SystemParametersInfo( SPI_GETACTIVEWINDOWTRACKING, 0, &bTracking, 0 );
	SystemParametersInfo( SPI_GETACTIVEWNDTRKZORDER, 0,  &bRaise, 0 );
		
	if ( !bTracking ) // turn on window tracking
		SystemParametersInfo( SPI_SETACTIVEWINDOWTRACKING,0, (PVOID) TRUE,   SPIF_SENDCHANGE | SPIF_UPDATEINIFILE  );	

	if ( !bRaise ) // turn on autoraise
		SystemParametersInfo( SPI_SETACTIVEWNDTRKZORDER, 0, (PVOID) TRUE,  SPIF_SENDCHANGE | SPIF_UPDATEINIFILE );
}		

bool checkOSVersion()
{
	char *sMsg = "This version of xmouse requires Windows 98, or Windows 2000\n";

    OSVERSIONINFO osvi;
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
      if (! GetVersionEx ( (OSVERSIONINFO *) &osvi) ) 
          {
            MessageBox(parent,"Error getting OS version information","xmouse", MB_OK);
//          printf( "Error getting OS version information: %d\n", GetLastError() );
         return false;
          }
   switch (osvi.dwPlatformId)
   {
      case VER_PLATFORM_WIN32_NT:
         if ( osvi.dwMajorVersion <= 4 ) // if not Windows 2000
             {
            MessageBox(parent,sMsg,"xmouse", MB_OK);
             return false;
             }
         break;

      case VER_PLATFORM_WIN32_WINDOWS:
         if ((osvi.dwMajorVersion == 4) && (osvi.dwMinorVersion == 0)) // if not Windows 98
             {
            MessageBox(parent,sMsg,"xmouse", MB_OK);
             return false;
             }
         break;

      case VER_PLATFORM_WIN32s: // if window 3.1
          if ( osvi.dwMajorVersion <= 4 ) // if not Windows 2000
          {
            MessageBox(parent,sMsg,"xmouse", MB_OK);
              return false;
          }
          break;
   };
return true;	
}
