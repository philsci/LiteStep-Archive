/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __POPUP_H
#define __POPUP_H

#include "../litestep/wharfdata.h"
#include "../lsapi/lsapi.h"

const MAX_TEXT = 256;
const MAX_TOKEN = 2048;
const MENU_TIMER = 701;
const SCROLL_TIMER = 702;
const SCROLL_DELAY = 10;

enum {
  gi_clsid = 0x01,   //lookup among predefined CLSIDs
  gi_shell = 0x02    //ask shell to provide icon info
};

//pre-decl
class Popup;

//---------------------------------------------------------
// the list class
//---------------------------------------------------------
template<class T> class list {
public:
  T *data;
protected:
  size_t count;
  size_t increment;
  size_t allocated;
public:
  list(int alloc = 16, int inc = 8);
  virtual ~list();
  T& operator[](size_t i);
  const T& operator[](size_t i) const;
  size_t add(const T& t);
  size_t size() const;
  void copy( const list<T>& l);
  void clear();
  void sort(int (__cdecl *compare )(const void *elem1, const void *elem2));
  bool validIndex(size_t indx) const;
protected:
  void reallocate(size_t num = 0);
};

//---------------------------------------------------------
// simple bitmap class
//---------------------------------------------------------
class BitMP {
public:
  HBITMAP bitmap;
  HRGN region;
  _TCHAR name[MAX_TEXT];
  int x;
  int y;
  COLORREF backColor;
  COLORREF foreColor;

  BitMP();
  ~BitMP();
};

//---------------------------------------------------------
// menuItem class
//---------------------------------------------------------
class menuItem {
public:
  enum itemType {mi_basic, mi_folder, mi_static, mi_dynamic, mi_tasks};
  Popup *owner;
  _TCHAR name[MAX_TEXT];
  _TCHAR command[MAX_TEXT];
  _TCHAR params[MAX_TEXT];
  Popup *sub;
  HICON hIcon;
  itemType type;

  menuItem();
  menuItem(LPTSTR lpszText, LPTSTR lpszCommand, LPTSTR lpszParams = NULL, Popup* pop = NULL);
  ~menuItem();
protected:
  void init();
};

//---------------------------------------------------------
// the menu item list
//---------------------------------------------------------
class itemList : public list<menuItem> {
public:
  int add(LPTSTR lpszText, LPTSTR lpszCommand, LPTSTR lpszParams = NULL, Popup *lp = NULL);
};

class timer {
  int id;
  bool timerSet;
  Popup *tmPop;
  int tmNdx;   // item in this popup
public:
  timer(int i) {id=i, timerSet=false, tmPop=NULL, tmNdx=-1;}
  void setTimer(Popup *p, int indx, int interval = 0);
  void killTimer();
  bool sameItem(Popup *p, int indx) const;
  void resetIndex() {tmNdx = -1;}
};

//---------------------------------------------------------
// the popup list container
//---------------------------------------------------------
class Popup {
public:
  Popup *parent;
  _TCHAR title[MAX_TEXT];
  size_t current;
  size_t first;
  size_t last;
  size_t numVisible;
  bool onLeft;  // For drawing menus on the left
  bool autoMenu;
  HWND hwnd;
  itemList list;
  static BOOL init;
  HRGN region;
public:
  Popup(Popup *parent = NULL);
  ~Popup();
  friend LRESULT CALLBACK wndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  menuItem* safeItem(int indx) const;
  size_t firstVisible();
  size_t lastVisible();
  void firstVisible(size_t n);
  void lastVisible(size_t n);
  void scroll(bool downd);
  bool createWindow();
  void destroyWindow();
  void showWindow(bool show = true);
  void openSubMenu(int num);
  void display(int x, int y);
  void display(POINT pt) {display(pt.x, pt.y);}
  void paint();
  void paintBMP(HDC dest, HDC src, BitMP& bmp, RECT r);
  void drawItem(const menuItem& mi, HDC hdc, HDC mem, BitMP &bmp, RECT r);
  bool itemRect(size_t indx, RECT *lpRect) const;
  int calcSize(SIZE& s) const;
  int  itemAt(POINT pt) const;
  bool highlight(int indx, bool snapCursor = false);
  int  hittest(POINT pt, int *pindx = NULL) const; // HTCAPTION/HTCLIENT/HTNOWHERE
  void moveMenu(Popup *p, int indx);
  void closeSubmenus(Popup *p = NULL);
  bool execute(int indx = -1); // -1 means execute 'current'
  bool isPopupWnd(HWND hwnd);
  void openDynamic(int indx, bool dynamic = true);
  void showTasks(int indx);
  void selectItem(BOOL selected);
  void GetRegion();
  int AlphaNav(_TCHAR chSearchChar, int nStartPoint);
};

#ifdef  __cplusplus
extern "C" {
#endif  /* __cplusplus */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCTSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef  __cplusplus
};
#endif  /* __cplusplus */

#endif  /* __LSAPI_H */
