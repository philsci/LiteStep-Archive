			*******************************************
			* LSRC Editor module - Version 1.0 readme *
			*******************************************

	0. Contents
*******************

	1. Introduction
	2. Installation
	3. Reference
	4. About
	
	1. Introduction
***********************
	
	First of all, sorry for my bad grammatical errors, I hope you'll understand 
this piece! 

	This module enables You to edit directly items of LiteStep configuration file
with !bang commands, it is usefull if You create scripts of them with use of bscript.dll
module. It is also included in this archive. 

	2. Installation
***********************

	1) Unzip lsrc.dll
	2) Copy the file in Your LiteStep modules path
	3) Add lswchanger.dll to the list with modules loaded with LiteStep in step.rc
	4) Recycle LiteStep
	
	3. Reference
********************

!rc-add <item_name> <value>		- add a item to step.rc
	
!rc-set <item_name> <value>		- changes the value of a item

!rc-del <item_name>			- deletes a item

!rc-enable <item_name>			- enables item by uncommentig it, if needs

!rc-disable <item_name>			- disables item by commentig it, if needs

!rc-toggle <item_name>			- toggles the state of a item

Here is a sample use of all this:

	- Part of sample script.rc, the full version is included in this archive

*bscript popup_sky
	!rc-set PopupGradientTitle 0000FF
	!rc-set PopupTitleColor FFFFFF
	!rc-set PopupTitleBgColor 000000
	!rc-set PopupGradientEntry 00FFFF
	!rc-set PopupEntryColor FFF000
	!rc-set PopupEntryBgColor 0000FF
*end popup_sky

*bscript popup_windows
	!rc-enable NoPopupBevel
	!rc-enable ShowPopupIcons
	!rc-disable PopupGradientEntry
	!rc-disable PopupGradientTitle
	!rc-set PopupTitleColor FFFFFF
	!rc-disable PopupTitleBgColor
	!rc-disable PopupEntryColor
	!rc-disable PopupEntryBgColor
*end popup_windows

*bscript popup_default
	!rc-disable NoPopupBevel
	!rc-disable ShowPopupIcons
	!rc-disable PopupGradientEntry
	!rc-disable PopupGradientTitle
	!rc-set PopupTitleColor FFFFFF
	!rc-disable PopupTitleBgColor
	!rc-disable PopupEntryColor
	!rc-disable PopupEntryBgColor
*end popup_default

	- Part of step.rc:

LoadModule c:\litestep\modules\lsrc.dll
LoadModule c:\litestep\modules\bscript.dll

*Popup "Popup look" Folder
	*Popup "Bevel on/off" !rc-toggle NoPopupBevel
	*Popup "IconsShow on/off" !rc-toggle PopupIcons
	*Popup "Pinned-on-top" !rc-toggle PinnedPopupNotOnTop
	*Popup  "" !none
	*Popup "blue" !bscript popup_blue
	*Popup "green" !bscript popup_green
	*Popup "red" !bscript popup_red
	*Popup "hot" !bscript popup_hot
	*Popup "cool" !bscript popup_cool
	*Popup "sky" !bscript popup_sky
	*Popup "redblue" !bscript popup_redblue
	*Popup "dark" !bscript popup_dark
	*Popup "light" !bscript popup_light
	*Popup "windows" !bscript popup_windows
	*Popup "airborne" !bscript popup_airborne
	*Popup "teranish" !bscript popup_teranish
	*Popup "default" !bscript popup_default
*Popup ~Folder

	4. About
****************

	I am Tzvetan Raikov, I am from Bulgaria and now I am study at Sofia university. 
To send a bug reports, when you have good ideas, or to contact with me you can use:

	e-mail:	craikov@hotmail.com
	www:	http://www.geocities.com/wchangerbg
