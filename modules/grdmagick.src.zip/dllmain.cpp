#include "StdAfx.h"

#include "grdMagick.h"
//#include "lsapi.h"

#define GRDMAGICAPI extern "C" __declspec(dllexport)

grdMagick *theMagic = NULL;

GRDMAGICAPI int initModuleEx(HWND hwndParent, HINSTANCE hInstance, LPCSTR) {
  int code = 0;
  Window::init(hInstance);

  if(FAILED(grdMagick::Create(&theMagic))) {
    code = 1;
  }

  return code;
}
GRDMAGICAPI void quitModule(HINSTANCE){
  delete theMagic;
}
