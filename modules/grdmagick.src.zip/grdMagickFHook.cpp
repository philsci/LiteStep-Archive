#include "grdMagickDef.h"
#include "grdMagick.h"
#include "helper\grdFunctionHooker.h"
#include <tlhelp32.h>

grdMagick *theClass = NULL;

typedef HINSTANCE (WINAPI *procLoadLibrary)(LPCTSTR);

// Stub functions for calling the the objects methods...
HINSTANCE WINAPI StubLoadLibrary(LPCTSTR szLibraryName) {
  return theClass->MagicLoadLibrary(szLibraryName);
}
HDC WINAPI StubBeginPaint(HWND hWnd, LPPAINTSTRUCT lpPs) {
	return theClass->MagicBeginPaint(hWnd, lpPs);
}
BOOL WINAPI StubEndPaint(HWND hWnd, CONST LPPAINTSTRUCT lpPs) {
	return theClass->MagicEndPaint(hWnd, lpPs);
}

HRESULT grdMagick::StartFunctionHooks() {
  if(pFuncHooker == NULL) {
    pFuncHooker = new grdFunctionHooker();
  }
  if(pFuncHooker != NULL) {
    grdFunctionHooker::HookFunc hf;

    // set class pointer, so stub functions know where to get us...
    theClass = this;

    hf.fdDescription.hModule = GetModuleHandle(_T("dllmgr.dll"));
    if(hf.fdDescription.hModule==NULL) { // older versions of litestep don't utilize dllmgr.dll
      hf.fdDescription.hModule = GetModuleHandle(_T("litestep.exe"));

      // if the applications name is not "litestep.exe" look it up
      if(hf.fdDescription.hModule==NULL) {
        DWORD dwProcessID = GetCurrentProcessId();
        HANDLE hss = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32 pe;
        pe.dwSize = sizeof(PROCESSENTRY32);
        if(Process32First(hss, &pe)) {
          do {
            if(pe.th32ProcessID == dwProcessID) {
              hf.fdDescription.hModule = GetModuleHandle(pe.szExeFile);
              break;
            }
          } while(Process32Next(hss, &pe));
        }
        CloseHandle(hss);
      }

    }
    strcpy(hf.fdDescription.szLibraryName, _T("kernel32.dll"));

#ifdef _UNICODE
    strcpy(hf.fdDescription.szFunctionName, _T("LoadLibraryW"));
#else
    strcpy(hf.fdDescription.szFunctionName, _T("LoadLibraryA"));
#endif

    hf.procReplacement = (PROC)::StubLoadLibrary;

    HRESULT hr = pFuncHooker->RerouteFunction(&hf);
    if(SUCCEEDED(hr)) {
      oldLoadLibrary = hf.procOriginal;
    }
    return hr;
  }
  return E_FAIL;
}


HRESULT grdMagick::StopFunctionHooks() {
  if(pFuncHooker != NULL) {
    delete pFuncHooker;
    pFuncHooker = NULL;
  }
  return S_OK;
}

HINSTANCE grdMagick::MagicLoadLibrary(LPCTSTR szLibraryName) {
  HINSTANCE hInstance = ((procLoadLibrary)oldLoadLibrary)(szLibraryName);

#ifdef _DEBUG
  char buffer[4096];
  sprintf(buffer, "grdMagick::MagicLoadLibrary (\"%s\")\n", szLibraryName);
  OutputDebugString(buffer);
#endif

  TCHAR szBuffer[256];
  GetModuleShortName(szBuffer, szLibraryName);
  // szBuffer now contains the lowercased name of the module without path and without .dll

  // look to see if there is any magic-effects to be applied...
  ModuleFXIterator it = moduleMagics.find(stdTString(szBuffer));
  if(it != moduleMagics.end()) {

    if(pFuncHooker != NULL) {
      grdFunctionHooker::HookFunc hf;

      hf.fdDescription.hModule = hInstance;
      strcpy(hf.fdDescription.szLibraryName, _T("user32.dll"));

      strcpy(hf.fdDescription.szFunctionName, _T("BeginPaint"));
      hf.procReplacement = (PROC)::StubBeginPaint;
      if(SUCCEEDED(pFuncHooker->RerouteFunction(&hf))) {
        strcpy(hf.fdDescription.szFunctionName, _T("EndPaint"));
        hf.procReplacement = (PROC)::StubEndPaint;
        // if we fail with rerouting EndPaint, unroute BeginPaint...
        if(FAILED(pFuncHooker->RerouteFunction(&hf))) {
          strcpy(hf.fdDescription.szFunctionName, _T("BeginPaint"));
          pFuncHooker->UnrouteFunction(&hf);
        }
      }

      // TODO : Add code to process GetDC / GetWindowDC and ReleaseDC....
    }
  }

  return hInstance;
}

