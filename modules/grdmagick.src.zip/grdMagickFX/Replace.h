#ifndef __GRD_MAGIC_REPLACE_H__
#define __GRD_MAGIC_REPLACE_H__

#include "FX.h"
namespace grdMagickFX {

  class Replace : public FX {
  private:
    COLORREF clFrom, clTo;

  public:
    Replace();
    ~Replace();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_REPLACE_H__)