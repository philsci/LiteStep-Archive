#include "..\StdAfx.h"
#include "..\ls\lsapi.h"
#include "Factory.h"
#include "Rect.h"

namespace grdMagickFX {

  Rect::Rect(Factory *factory) : FX(),
  pFactory(factory),
  pFX(NULL) {
    memset(&rc, 0, sizeof(rc));
  }
  Rect::~Rect() {
    partDesc.dibResult.Destroy();
    if(pFX!=NULL) {
      pFactory->Release(pFX);
      pFX = NULL;
    }
  }

  HRESULT Rect::SetUp(LPCTSTR szConfig) {
    HRESULT hr = E_FAIL;
    TCHAR szEffect[4096], szParams[4096];
    LPTSTR strings[4];

    for(int i=0; i<4; i++) {
      strings[i] = new TCHAR[4096];
      strings[i][0] = _T('\0');
    }
    strings[4] = szEffect;

    LCTokenize(szConfig, strings, 5, szParams);

    TCHAR *stop;
    rc.left   = _tcstoul(strings[0], &stop, 0);
    rc.top    = _tcstoul(strings[1], &stop, 0);
    rc.right  = _tcstoul(strings[2], &stop, 0);
    rc.bottom = _tcstoul(strings[3], &stop, 0);

    hr = pFactory->Get(szEffect, &pFX);
    if(SUCCEEDED(hr)) {
      hr = pFX->SetUp(szParams);
    }

    if(SUCCEEDED(hr)) {
      int w = (rc.right>0) ? rc.right-rc.left : 100;
      int h = (rc.bottom>0) ? rc.bottom-rc.top : 100;
      partDesc.dibResult.Create(w, h);
    }else {
      partDesc.dibResult.Destroy();
    }

    for(i=0; i<4; i++) {
      delete[] strings[i];
    }

    return hr;
  }


  HRESULT Rect::Process(Description *ppd) {
    if(pFX==NULL) {
      return S_OK;
    }

    int bw, bh, w, h;
    ppd->dibResult.GetSize(&w, &h);
    w = min(rc.right-rc.left + ((rc.right<0) ? w : 0), w);
    h = min(rc.bottom-rc.top + ((rc.bottom<0) ? h : 0), h);

    partDesc.dibResult.GetSize(&bw, &bh);
    if(bw<w || bh<h) {
      partDesc.dibResult.Create(w, h);
      bw = w; bh = h;
    }

#ifdef _DEBUG
    char buffer[4096];
    sprintf(buffer, "x:%d,y:%d,w:%d,h:%d\n", rc.left, rc.top, w, h);
    OutputDebugString(buffer);
#endif

    HRESULT hr = partDesc.dibResult.Copy(&(ppd->dibResult), 0, 0, w, h, rc.left, rc.top);
    if(SUCCEEDED(hr)) {
      hr = pFX->Process(&partDesc);
      if(SUCCEEDED(hr)) {
        hr = ppd->dibResult.Copy(&(partDesc.dibResult), rc.left, rc.top, w, h, 0, 0);
      }
    }
    return hr;
  }

}

