#include "..\StdAfx.h"
#include "Factory.h"
#include "..\ls\lsapi.h"

#include "Chain.h"
#include "Desaturation.h"
#include "Hue.h"
#include "Invert.h"
#include "Replace.h"
#include "Gaus.h"
#include "Filter.h"
#include "Rect.h"

namespace grdMagickFX {

  Factory::Factory() {
    InitChains();
  }

  Factory::~Factory() {
    chains.clear();
  }

  HRESULT Factory::Get(LPCTSTR szName, FX **ppFX) {
    if(ppFX==NULL) return E_POINTER;

    *ppFX = NULL;
    LPTSTR szBuffer = _tcslwr(_tcsdup(szName));

    if(strcmp(szBuffer, _T("hue"))==0) {
      *ppFX = new Hue();
    }else if(strcmp(szBuffer, _T("desaturnation"))==0 || strcmp(szBuffer, _T("desat"))==0) {
      *ppFX = new Desaturation();
    }else if(strcmp(szBuffer, _T("invert"))==0) {
      *ppFX = new Invert();
    }else if(strcmp(szBuffer, _T("replace"))==0) {
      *ppFX = new Replace();
    }else if(strcmp(szBuffer, _T("gaus"))==0 || strcmp(szBuffer, _T("blur"))==0) {
      *ppFX = new Gaus();
    }else if(strcmp(szBuffer, _T("filter"))==0) {
      *ppFX = new Filter();
    }else if(strcmp(szBuffer, _T("rect"))==0) {
      *ppFX = new Rect(this);
    }else {
      SSIterator it = chains.find(stdTString(szBuffer));
      if(it != chains.end()) {
        *ppFX = new Chain(this, szBuffer, it->second.c_str());
      }
    }

    free(szBuffer);
    szBuffer = NULL;

    if(*ppFX != NULL) {
      return S_OK;
    }

    return E_FAIL;
  }

  HRESULT Factory::Release(FX *pFX) {
    if(pFX==NULL) return E_POINTER;

    delete pFX;

    return S_OK;
  }

  HRESULT Factory::IsValidName(LPCTSTR szName, bool *pbIsValid) {
    if(pbIsValid==NULL) return E_POINTER;

    *pbIsValid = false;
    if(chains.find(stdTString(szName)) != chains.end()) {
      *pbIsValid = true;
    }else {
      // TODO : Replace ugly solution with better...
      FX *pFX = NULL;
      Get(szName, &pFX);
      if(pFX != NULL) {
        *pbIsValid = true;
      }
      delete pFX;
    }

    return S_OK;
  }

  HRESULT Factory::InitChains() {
#ifdef _DEBUG
    OutputDebugString("Loading Magick Chains\n");
#endif

    // now go create the user-defined magics...
	  FILE * f;
	  _TCHAR szBuffer[4096];

	  f = LCOpen(NULL);
	  if(f!=NULL) {
		  while(LCReadNextConfig(f, _T("*grdmagickchain"), szBuffer, 4096)) {
			  // 10 is because we don't need the part "*grdmagickchain "
        if(FAILED(InitChain(szBuffer + 16))) {
          OutputDebugString("Failed Loading MagickChain\n");
        }
		  }
		  LCClose(f);
	  }

    return S_OK;
  }

  HRESULT Factory::InitChain(LPCTSTR szConfig) {
#ifdef _DEBUG
    OutputDebugString("Loading Magic Chain {\n");
    OutputDebugString(szConfig);
    OutputDebugString("\n}\n");
#endif

	  TCHAR szName[4096], szParams[4096], szBuffer[4096];
    TCHAR *tokens[1] = {szName};

    // expand environment variables
    VarExpansion(szBuffer, szConfig);

    LCTokenize(szBuffer, tokens, 1, szParams);

    // make sure we got both command name and params
    if(*szName != _T('\0') && *szParams != _T('\0')) {
      // save the chain magic...
      chains[stdTString(szName)] = stdTString(szParams);

      return S_OK;
    }

	  return E_FAIL;
  }

}