#include "..\StdAfx.h"
#include "..\ls\lsapi.h"
#include "Filter.h"

namespace grdMagickFX {

  Filter::Filter() : FX() {
    memset(&filter, 0, sizeof(filter));
  }
  Filter::~Filter() {

  }

  HRESULT Filter::SetUp(LPCTSTR szConfig) {
    int i;
    LPTSTR strings[10];

    for(i=0; i<10; i++) {
      strings[i] = new TCHAR[256];
      strings[i][0] = _T('\0');
    }

    LCTokenize(szConfig, strings, 10, NULL);

    TCHAR *stop;
    for(i=0; i<9; i++) {
      filter.data[i] = _tcstoul(strings[i], &stop, 0);
    }
    filter.factor = _tcstoul(strings[9], &stop, 0);
    // if factor is 0 we'll get devision by zero... we don't want that...
    if(filter.factor==0) {
      filter.factor = 1;
    }

    for(i=0; i<10; i++) {
      delete[] strings[i];
    }

    return S_OK;
  }


  HRESULT Filter::Process(Description *ppd) {
    return ppd->dibResult.ApplyFilter(&filter);
  }

}

