#ifndef __GRD_MAGIC_FX_H__
#define __GRD_MAGIC_FX_H__

#include "..\helper\grdDIBBitmap.h"

namespace grdMagickFX {

  // this structure might seem pointless,
  // but would make extensions easier...
  struct Description {
    // the result dib
    grdDIBBitmap dibResult;
  };


  class FX {
  protected:
    FX() {};
  public:
    virtual ~FX() {};

  public:
    virtual HRESULT SetUp(LPCTSTR szConfig) = 0;
    virtual HRESULT Process(Description *ppd) = 0;
  };

}
  
#endif // !defined(__GRD_MAGIC_FX_H__)