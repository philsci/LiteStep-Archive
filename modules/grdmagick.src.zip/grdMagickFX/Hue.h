#ifndef __GRD_MAGIC_HUE_H__
#define __GRD_MAGIC_HUE_H__

#include "FX.h"
namespace grdMagickFX {

  class Hue : public FX {
  private:
    COLORREF cl;
    int alpha;

  public:
    Hue();
    ~Hue();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_HUE_H__)