#ifndef __GRD_MAGIC_INVERT_H__
#define __GRD_MAGIC_INVERT_H__

#include "FX.h"
namespace grdMagickFX {

  class Invert : public FX {
  public:
    Invert();
    ~Invert();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_INVERT_H__)