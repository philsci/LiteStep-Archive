#include "..\StdAfx.h"
#include "..\StdSTL.h"
#include "..\ls\lsapi.h"
#include "Factory.h"

#include "Chain.h"

namespace grdMagickFX {

  Chain::Chain(Factory *pFactory, LPCTSTR szName, LPCTSTR szChain):
  FX() {
    ParseChain(pFactory, szName, szChain);
  }
  Chain::~Chain() {
    FXVector::iterator it = chain.begin();
    for(; it!=chain.end(); it++) {
      delete (*it).pFX;
    }
    chain.clear();
  }

  HRESULT Chain::SetUp(LPCTSTR szConfig) {
    // Determine if we need to do extra variable processing
    // We don't want to waste ourselves doing lotsa replace operations
    // for nothing
    SSVector vConfig;
    bool doeasy = false;

    if(szConfig == NULL || *szConfig == _T('\0') || params.size() == 0) {
      doeasy = true;
    }else {
      TCHAR szBuffer1[4096], szBuffer2[4096];
      TCHAR *tokens[1] = {szBuffer1};
      TCHAR *szRemaining = (TCHAR *)szConfig;
      while(*szRemaining != _T('\0')) {
        LCTokenize(szRemaining, tokens, 1, szBuffer2);
        vConfig.push_back(stdTString(szBuffer1));
        szRemaining = szBuffer2;
      }
      doeasy = (vConfig.size() == 0);
    }

    // don't perform any special parsing...
    if(doeasy) {
      FXVector::iterator it = chain.begin();
      for(; it!=chain.end(); it++) {
        (*it).pFX->SetUp((*it).strParams.c_str());
      }

    // more complicated parsing on the street... =)
    }else {
      SSVector::iterator itpname, itpvalue;
      FXVector::iterator itfx = chain.begin();
      for(; itfx!=chain.end(); itfx++) {
        stdTString strTemp((*itfx).strParams);
        // if the string contains at least one ?, start looking
        // for params to replace
        if(strTemp.find(_T('?'), 0) != stdTString::npos) {
          itpname = params.begin();
          itpvalue = vConfig.begin();
          for(; itpname!=params.end() && itpvalue!=vConfig.end(); itpname++, itpvalue++) {
            size_t n = strTemp.find((*itpname), 0);
            if(n != stdTString::npos) {
              strTemp.replace(n,(*itpname).length(), (*itpvalue));
            }
          }
        }
        (*itfx).pFX->SetUp(strTemp.c_str());
      }
    }

    return S_OK;
  }

  HRESULT Chain::Process(Description *pDesc) {
    HRESULT hr;
    FXVector::iterator it = chain.begin();
    for(; it!=chain.end(); it++) {
      hr = (*it).pFX->Process(pDesc);
      if(FAILED(hr)) {
        return hr;
      }
    }
    return hr;
  }

  HRESULT Chain::ParseChain(Factory *pFactory, LPCTSTR szName, LPCTSTR szChain) {
    ChainFX cfx;
	  TCHAR szBuffer1[4096], szBuffer2[4096], szBuffer3[4096];
    TCHAR *tokens[1] = {szBuffer1};
    TCHAR *szCommands, *szParams;

    // TODO : Add saving of params, so they can be used with setup
    // *grdmagickchain inverthue [? alpha color ?][ invert ][ hue ?alpha? ?color? ]


    // either params are specified first, or not at all
    CommandTokenize(szChain, tokens, 1, szBuffer2);
    if(szBuffer1[0] == _T('?')) {
      szParams = szBuffer1+1;
      szParams[strlen(szParams)] = _T('\0');
      szCommands = szBuffer2;
    }else {
      szParams = NULL;
      szCommands = (TCHAR*)szChain;
    }

    if(szCommands[0] == _T('\0')) {
      return E_FAIL; // no commands
    }

    // check szBuffer1 for params
    HRESULT hr = ParseParams(szParams);
    if(FAILED(hr)) {
      return hr;
    }
    
#ifdef _DEBUG
    TCHAR szBufferX[4096];
    sprintf(szBufferX, _T("Chain::ParseChain([params:\"%s\"][commands:\"%s\"])\n"), szParams, szCommands);
    OutputDebugString(szBufferX);
#endif

    // loop through all commands, and try to get the FX from them
    while(*szCommands != _T('\0')) {
      CommandTokenize(szCommands, tokens, 1, szBuffer2);
      tokens[0] = szBuffer3;
      LCTokenize(szBuffer1, tokens, 1, szBuffer1);

#ifdef _DEBUG
      sprintf(szBufferX, _T("Chain::ParseChain([name:\"%s\"][params:\"%s\"])\n"), szBuffer3, szBuffer1);
      OutputDebugString(szBufferX);
#endif

      // check for references to our selves, this is not fool proof
      // as you migth still create two different chains referencing 
      // each other, but if you do, you'll just have yourself to blame...
      if(_tcscmp(szBuffer3, szName)!=0) {

        if(SUCCEEDED(pFactory->Get(szBuffer3, &(cfx.pFX)))) {
          cfx.strParams = stdTString(szBuffer1);
          chain.push_back(cfx);
        }

      }

      tokens[0] = szBuffer1;
      szCommands = szBuffer2;
    }

    return (chain.size()>0) ? S_OK : E_FAIL;
  }

  // Saving of params, so they can be used with setup
  // [? alpha color ?]
  HRESULT Chain::ParseParams(LPCTSTR szParams) {
    if(szParams != NULL) {
      TCHAR szBuffer1[4096], szBuffer2[4096], szBuffer3[4096];
      TCHAR *tokens[1] = {szBuffer1};
      TCHAR *szRemaining = (TCHAR *)szParams;

      szBuffer3[0] = _T('?');
      TCHAR *pFrom, *pTo;

      // loop through all commands, and try to get the FX from them
      while(*szRemaining != _T('\0')) {
        LCTokenize(szRemaining, tokens, 1, szBuffer2);
      
        // make sure it follows the syntax [a-zA-Z][a-zA-Z0-9]
        pFrom = szBuffer1;
        if(_istalpha(*pFrom)) {
          pTo = szBuffer3+1;
          do {
            if(_istalnum(*pFrom)) {
              *pTo++ = *pFrom++;
            }else {
              break;
            }
          }while(*pFrom != _T('\0'));

          // if it reached the end (it was a correct var, add it...
          if(*pFrom == _T('\0')) {
            *pTo++ = _T('?'); *pTo = _T('\0');
            params.push_back(stdTString(szBuffer3));
          }
        }

        szRemaining = szBuffer2;
      }

      return S_OK;
    }
    return S_OK;
  }
}