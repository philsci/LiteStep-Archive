#include "..\StdAfx.h"
#include "Gaus.h"

namespace grdMagickFX {

  Gaus::Gaus() : FX() {
    // initialize the filter...
    filter.data[0] = 1; filter.data[1] = 2; filter.data[2] = 1;
    filter.data[3] = 2; filter.data[4] = 4; filter.data[5] = 2;
    filter.data[6] = 1; filter.data[7] = 2; filter.data[8] = 1;
    filter.factor = 16;
  }
  Gaus::~Gaus() {
  }

  HRESULT Gaus::SetUp(LPCTSTR szConfig) {
    return S_OK;
  }


  HRESULT Gaus::Process(Description *ppd) {
    return ppd->dibResult.ApplyFilter(&filter);
  }

}
