#ifndef __GRD_MAGIC_RECT_H__
#define __GRD_MAGIC_RECT_H__

#include "FX.h"
namespace grdMagickFX {

  class Rect : public FX {
  private:
    Factory *pFactory;
    FX *pFX;
    Description partDesc;
    RECT rc;

  public:
    Rect(Factory *pFactory);
    ~Rect();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_RECT_H__)