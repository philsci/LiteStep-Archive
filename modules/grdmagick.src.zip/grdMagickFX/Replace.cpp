#include "..\StdAfx.h"
#include "..\ls\lsapi.h"
#include "Replace.h"

namespace grdMagickFX {

  Replace::Replace() : FX(),
  clFrom(0x00000000), 
  clTo(0x00000000) {

  }
  Replace::~Replace() {

  }

  HRESULT Replace::SetUp(LPCTSTR szConfig) {
    LPTSTR strings[2];

    LPTSTR szColorFrom = new TCHAR[4096];
    LPTSTR szColorTo   = new TCHAR[4096];

    strings[0] = szColorFrom;
    strings[1] = szColorTo;

    LCTokenize(szConfig, strings, 2, NULL);

    TCHAR *stop;
    clFrom = _tcstoul(szColorFrom, &stop, 0);
    clTo   = _tcstoul(szColorTo, &stop, 0);

    delete[] szColorFrom;
    delete[] szColorTo;

    return S_OK;
  }


  HRESULT Replace::Process(Description *ppd) {
    // if no alpha value for our hue, then don't paint
    if(clFrom != clTo) {
      return ppd->dibResult.ReplaceColor(clFrom, clTo);
    }
    return S_OK;
  }

}

