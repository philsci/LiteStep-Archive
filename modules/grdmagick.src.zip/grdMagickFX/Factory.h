#ifndef __GRD_MAGIC_FX_FACTORY_H__
#define __GRD_MAGIC_FX_FACTORY_H__

#include "..\stdstl.h"
#include <map>

#include "FX.h"
namespace grdMagickFX {

  class Factory {
  protected:
#ifdef _UNICODE
    typedef std::wstring TString;
#else
    typedef std::string  TString;
#endif
    typedef std::map<TString, TString> SSMap;
    typedef SSMap::iterator            SSIterator;

    SSMap chains;

  public:
    Factory();
    ~Factory();

    // Used to get the desired FX by name
    HRESULT Get(LPCTSTR szName, FX **ppFX);
    // To make the classes using Factory independent of how
    // it is implemented, you must call the release function here...
    HRESULT Release(FX *pFX);

    HRESULT IsValidName(LPCTSTR szName, bool *pbIsValid);

  protected:
    HRESULT InitChains();
    HRESULT InitChain(LPCTSTR szConfig);
  };

}
  
#endif // !defined(__GRD_MAGIC_FX_FACTORY_H__)