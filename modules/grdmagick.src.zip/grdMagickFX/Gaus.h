#ifndef __GRD_MAGIC_GAUS_H__
#define __GRD_MAGIC_GAUS_H__

#include "FX.h"
namespace grdMagickFX {

  class Gaus : public FX {
  private:
    grdDIBBitmap::Filter filter;

  public:
    Gaus();
    ~Gaus();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_GAUS_H__)