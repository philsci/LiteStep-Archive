#include "..\StdAfx.h"
#include "Desaturation.h"

namespace grdMagickFX {

  Desaturation::Desaturation() : FX(),
  desaturation(0) {
  }
  Desaturation::~Desaturation() {
  }

  HRESULT Desaturation::SetUp(LPCTSTR szConfig) {
    TCHAR *stop;
    desaturation = 255 - _tcstoul(szConfig, &stop, 0);
    if(desaturation > 255 || desaturation < 0) {
      desaturation = 0;
    }
    return S_OK;
  }

  HRESULT Desaturation::Process(Description *ppd) {
    if(desaturation==0) {
      return S_OK;
    }else {
      return ppd->dibResult.Desaturate(desaturation);
    }
  }

}



