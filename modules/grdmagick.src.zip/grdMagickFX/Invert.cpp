#include "..\StdAfx.h"
#include "Invert.h"

namespace grdMagickFX {

  Invert::Invert() : FX() {
  }
  Invert::~Invert() {
  }

  HRESULT Invert::SetUp(LPCTSTR szConfig) {
    return S_OK;
  }


  HRESULT Invert::Process(Description *ppd) {
    return ppd->dibResult.Invert();
  }

}
