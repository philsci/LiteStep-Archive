#ifndef __GRD_MAGIC_FILTER_H__
#define __GRD_MAGIC_FILTER_H__

#include "FX.h"
namespace grdMagickFX {

  class Filter : public FX {
  private:
    grdDIBBitmap::Filter filter;

  public:
    Filter();
    ~Filter();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };
  
}

#endif // !defined(__GRD_MAGIC_FILTER_H__)