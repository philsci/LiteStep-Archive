#ifndef __GRD_MAGIC_DESATURATION_H__
#define __GRD_MAGIC_DESATURATION_H__

#include "FX.h"

namespace grdMagickFX { 

  class Desaturation : public FX {
  private:
    int desaturation;

  public:
    Desaturation();
    ~Desaturation();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);
  };

}
  
#endif // !defined(__GRD_MAGIC_DESATURATION_H__)