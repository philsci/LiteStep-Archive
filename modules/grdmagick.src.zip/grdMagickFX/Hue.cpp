#include "..\StdAfx.h"
#include "..\ls\lsapi.h"
#include "Hue.h"

namespace grdMagickFX {

  Hue::Hue() : FX(),
  cl(0x00000000),
  alpha(0) {

  }
  Hue::~Hue() {

  }

  HRESULT Hue::SetUp(LPCTSTR szConfig) {
    LPTSTR strings[2];

    LPTSTR szColor = new TCHAR[4096];
    LPTSTR szAlpha = new TCHAR[4096];

    strings[0] = szAlpha;
    strings[1] = szColor;

    LCTokenize(szConfig, strings, 2, NULL);

    TCHAR *stop;
    cl = _tcstoul(szColor, &stop, 0);
    alpha = _tcstoul(szAlpha, &stop, 0);
    if(alpha > 255 || alpha < 0) {
      alpha = 0;
    }

    delete[] szColor;
    delete[] szAlpha;

    return S_OK;
  }


  HRESULT Hue::Process(Description *ppd) {
    // if no alpha value for our hue, then don't paint
    if(alpha!=0) {
      return ppd->dibResult.FillAlpha(GetRValue(cl), GetGValue(cl), GetBValue(cl), alpha);
    }
    return S_OK;
  }

}

