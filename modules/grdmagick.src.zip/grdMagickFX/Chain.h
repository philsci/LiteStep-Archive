#ifndef __GRD_MAGIC_FX_CHAIN_H__
#define __GRD_MAGIC_FX_CHAIN_H__

#include <vector>

#include "FX.h"
namespace grdMagickFX {
  class Factory;

  class Chain : public FX {
  protected:
    struct ChainFX {
      FX *pFX;
      stdTString strParams;
    };
    typedef std::vector<ChainFX>    FXVector;
    typedef std::vector<stdTString> SSVector;

    FXVector chain;
    SSVector params;

  public:
    Chain(Factory *pFactory, LPCTSTR szName, LPCTSTR szChain);
    ~Chain();

    HRESULT SetUp(LPCTSTR szConfig);
    HRESULT Process(Description *ppd);

  protected:
    HRESULT ParseParams(LPCTSTR szParams);
    HRESULT ParseChain(Factory *pFactory, LPCTSTR szName, LPCTSTR szChain);
  };
  
}

#endif // !defined(__GRD_MAGIC_FX_CHAIN_H__)