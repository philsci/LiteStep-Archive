#include "grdMagickDef.h"
#include "grdMagick.h"
#include "ls\lsapi.h"

grdMagick *theBangClass = NULL;

// BANG COMMAND FUNCTIONS
void BangModuleWindowFX(HWND, LPCTSTR szArgs) {
  TCHAR szBuffer[4096], szModule[256];
  TCHAR *tokens[] = {szModule};

#ifdef _DEBUG
  OutputDebugString(_T("BangModuleWindowFX(HWND, \""));
  OutputDebugString(szArgs);
  OutputDebugString(_T("\")\n"));
#endif

  LCTokenize(szArgs, tokens, 1, szBuffer);

  theBangClass->SetModuleWindowFX(szModule, szBuffer);
}

HRESULT grdMagick::StartBangCommands() {
  theBangClass = this;

  AddBangCommand(_T("!grdmagickset"), BangModuleWindowFX);

  return S_OK;
}


HRESULT grdMagick::StopBangCommands() {
  RemoveBangCommand(_T("!grdmagickset"));

  theBangClass = NULL;

  return S_OK;
}