#ifndef __GRD_MAGIC_DEFINES_H__
#define __GRD_MAGIC_DEFINES_H__

#include "StdAfx.h"
#include "StdSTL.h"

const TCHAR szAppName[]  = _T("grdMagick");
const TCHAR szRevision[] = _T("grdMagick v 1.3");
const TCHAR szId[]       = _T("grdMagick v 1.3 2001/10/28 00:00:00 grd");

#endif // !defined(__GRD_MAGIC_DEFINES_H__)