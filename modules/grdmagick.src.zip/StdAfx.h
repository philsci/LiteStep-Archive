#ifndef __GRD_STD_AFX_H__
#define __GRD_STD_AFX_H__

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <tchar.h>

#endif // __GRD_STD_AFX_H__