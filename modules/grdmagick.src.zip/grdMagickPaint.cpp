#include "grdMagickDef.h"
#include "grdMagick.h"

#include "grdMagickFX\FX.h"
#include "grdMagickFX\Factory.h"


struct grdMagick::WindowFX {
  // the FX generator
  grdMagickFX::FX *pFX;
  // the description object... passed to pFX
  grdMagickFX::Description fxDesc;
  // the replaced dc
  HDC hdcReplaced;
  // the replaced dc bitmap
  HBITMAP hbmReplaced;
  // the string identifying the module it belongs to
  LPTSTR szModule;
};


HDC grdMagick::MagicBeginPaint(HWND hwnd, LPPAINTSTRUCT pps) {
#ifdef _DEBUG
  OutputDebugString("grdMagick::MagicBeginPaint ()\n");
#endif

  WindowFX *pWFX;
  if(SUCCEEDED(GetWindowFX(hwnd, &pWFX))) {
    pWFX->hdcReplaced = ::BeginPaint(hwnd, pps);

    RECT rc;
    GetWindowRect(hwnd, &rc);

    pps->hdc = CreateCompatibleDC(pWFX->hdcReplaced);
    pWFX->fxDesc.dibResult.Create(rc.right-rc.left, rc.bottom-rc.top);
    pWFX->hbmReplaced = (HBITMAP)SelectObject(pps->hdc, (HBITMAP)pWFX->fxDesc.dibResult);

    return pps->hdc;

  }

  // provide a failback so that when failing,
  // repainting doesn't freak out for the window...
  // just don't give it the effect
  return ::BeginPaint(hwnd, pps);
}

BOOL grdMagick::MagicEndPaint(HWND hwnd, const LPPAINTSTRUCT pps) {
#ifdef _DEBUG
  OutputDebugString("grdMagick::MagicEndPaint ()\n");
#endif

  WindowFX *pWFX;
  if(SUCCEEDED(GetWindowFX(hwnd, &pWFX))) {
    // delete the dc wrapping our pDIBSource bitmap
    SelectObject(pps->hdc, pWFX->hbmReplaced);
    pWFX->hbmReplaced = NULL;
    DeleteDC(pps->hdc);

    // move the old "correct" dc back
    pps->hdc = pWFX->hdcReplaced;
    pWFX->hdcReplaced = NULL;

    // do the magic...
    pWFX->pFX->Process(&(pWFX->fxDesc));

    RECT rc;
    GetWindowRect(hwnd, &rc);

    pWFX->fxDesc.dibResult.Blt(pps->hdc, 0, 0, rc.right-rc.left, rc.bottom-rc.top);

    return ::EndPaint(hwnd, pps);
  }
  
  // provide a failback so that when failing,
  // repainting doesn't freak out for the window...
  // just don't give it the effect
  return ::EndPaint(hwnd, pps);
}


HRESULT grdMagick::GetWindowFX(HWND hwnd, WindowFX **ppWFX) {
  if(ppWFX==NULL) return E_POINTER;

  if(GetWindowLong(hwnd,GWL_USERDATA) != 0x49474541) { // usually called magic-d-word
    // this is not a litestep-window... FAIL
    return E_FAIL;
  }

  WindowFXIterator it = windowMagics.find(hwnd);
  if(it != windowMagics.end()) {
    *ppWFX = it->second;
    return S_OK;
  }else {
    TCHAR szModule[256], szBuffer[256];

    HINSTANCE hInst = (HINSTANCE)::GetWindowLong(hwnd, GWL_HINSTANCE);
    GetModuleFileName(hInst, szModule, 256);
    GetModuleShortName(szBuffer, szModule);

    // look to see if there is any magic-effects to be applied...
    ModuleFXIterator it = moduleMagics.find(stdTString(szBuffer));
    if(it != moduleMagics.end()) {
      WindowFX *pWFX = new WindowFX;

      pFXFactory->Get(it->second.strName.c_str(), &(pWFX->pFX));
      pWFX->pFX->SetUp(it->second.strParams.c_str());
      pWFX->szModule = new TCHAR[_tcslen(szBuffer)+1];
      _tcscpy(pWFX->szModule, szBuffer);
      pWFX->hdcReplaced = NULL;
      pWFX->hbmReplaced = NULL;

      windowMagics[hwnd] = pWFX;
      *ppWFX = pWFX;

      return S_OK;
    }
  }

  return E_FAIL;
}

HRESULT grdMagick::ReleaseWindowFX(HWND hwnd, WindowFX *pWFX) {
  pFXFactory->Release(pWFX->pFX);
  pWFX->pFX = NULL;
  delete[] pWFX->szModule;
  pWFX->szModule = NULL;
  if(pWFX->hdcReplaced != NULL || pWFX->hbmReplaced != NULL) {
#ifdef _DEBUG
    OutputDebugString("grdMagick::DeleteWindowFX() {In the middle of window repaint}\n");
#endif
    // post a WM_PAINT message, so that the window repaints itself again
    // because the current round will fail, and we will leak memory... =(
    PostMessage(hwnd, WM_PAINT, 0, 0);
  }
  delete pWFX;

  return S_OK;
}

HRESULT grdMagick::DeleteWindowFXs() {
  WindowFXIterator it = windowMagics.begin();
  for(; it!=windowMagics.end(); it++) {
    ReleaseWindowFX(it->first, it->second);
    it->second = NULL;
  }
  windowMagics.clear();

  return S_OK;
}

HRESULT grdMagick::SetModuleWindowFX(LPCTSTR szModule, LPCTSTR szConfig) {
  TCHAR szBuffer[256], szBuffer2[4096];

  GetModuleShortName(szBuffer, szModule);
  _tcscpy(szBuffer2, szBuffer);
  _tcscat(szBuffer2, _T(" "));
  _tcscat(szBuffer2, szConfig);

  if(SUCCEEDED(CreateModuleMagic(szBuffer2))) {
    WindowFXIterator it = windowMagics.begin();
    for(; it!=windowMagics.end(); it++) {
      if(_tcsicmp(it->second->szModule, szBuffer) == 0) {
        WindowFXIterator it2 = it++;

        HWND hwnd = it2->first;
        ReleaseWindowFX(hwnd, it2->second);
        windowMagics.erase(it2);
        InvalidateRect(hwnd, NULL, TRUE);

        // make sure we don't continue past the last window-magic...
        if(it==windowMagics.end()) {
          break;
        }
      }
    }
    return S_OK;
  }
  return E_FAIL;
}

