#include "StdAfx.h"
#include "StdSTL.h"

#include <tlhelp32.h>
#include "ls\lsapi.h"
#include "grdMagick.h"
#include "grdMagickDef.h"
#include "helper\grdFunctionHooker.h"
#include "helper\grdDIBBitmap.h"

#include "grdMagickFX\Factory.h"


HRESULT grdMagick::Create(grdMagick **ppSingleton) {
  if(ppSingleton==NULL) return E_POINTER;

  // if window already exists... fail...
  HWND hwnd = FindWindow(szAppName, szAppName);
  if(hwnd != NULL) {
    return E_FAIL;
  }

  *ppSingleton = new grdMagick();

  return S_OK;
}

grdMagick::grdMagick() : Window(szAppName),
pFuncHooker(NULL),
pFXFactory(NULL),
oldLoadLibrary(NULL) {
  createWindow(WS_EX_TOOLWINDOW, szAppName, WS_CHILD, 0, 0, 0, 0, GetLitestepWnd());

  pFXFactory = new grdMagickFX::Factory();

  CreateModuleMagics();

  StartFunctionHooks();
  StartBangCommands();
}

grdMagick::~grdMagick() {
  destroyWindow();

  StopBangCommands();
  StopFunctionHooks();

  DeleteWindowFXs();
  DeleteModuleMagics();

  if(pFXFactory != NULL) {
    delete pFXFactory;
    pFXFactory = NULL;
  }
}






HRESULT grdMagick::CreateModuleMagics() {
#ifdef _DEBUG
  OutputDebugString("Creating Module Magics\n");
#endif

  // now go create the user-defined magics...
	FILE * f;
	_TCHAR szBuffer[4096];

	f = LCOpen(NULL);
	if(f!=NULL) {
		while(LCReadNextConfig(f, _T("*grdMagick"), szBuffer, 4096)) {
			// 10 is because we don't need the part "*grdMagick "
      if(FAILED(CreateModuleMagic(szBuffer + 11))) {
        OutputDebugString("Failed loading Module Magic\n");
      }
		}
		LCClose(f);
	}

  return S_OK;
}


HRESULT grdMagick::CreateModuleMagic(LPCTSTR szConfig) {
#ifdef _DEBUG
  char buffer[4096];
  sprintf(buffer, "grdMagick::CreateModuleMagic (\"%s\")\n", szConfig);
  OutputDebugString(buffer);
#endif

  TCHAR szName[4096], szMagic[4096], szBuffer[4096];
  TCHAR *tokens[1] = {szName};

  // expand environment variables
  VarExpansion(szBuffer, szConfig);

  LCTokenize(szBuffer, tokens, 1, szMagic);

  // make sure we got both command name and params
  if(*szName != _T('\0') && *szMagic != _T('\0')) {
    tokens[0] = szMagic;
    LCTokenize(szMagic, tokens, 1, szBuffer);

    ModuleFX mfx;
    mfx.strName = stdTString(szMagic);
    mfx.strParams = stdTString(szBuffer);

    // check validity
    bool isValid = false;
    if(SUCCEEDED(pFXFactory->IsValidName(szMagic, &isValid)) && isValid) {
      
      // save the module magic...
      GetModuleShortName(szBuffer, szName);
      moduleMagics[stdTString(szBuffer)] = mfx;
    }

    return S_OK;
  }

	return E_FAIL;
}

HRESULT grdMagick::DeleteModuleMagics() {
#ifdef _DEBUG
  OutputDebugString("Deleting Module Magics\n");
#endif

  moduleMagics.clear();

  return S_OK;
}



HRESULT grdMagick::GetModuleShortName(LPTSTR szDest, LPCTSTR szSource) {
  if(szDest==NULL) return E_POINTER;

  if(szSource==NULL) {
    return E_FAIL;
  }

  // remove path...
  LPTSTR szStart = _tcsrchr(szSource, _T('\\'));
  if(szStart == NULL) {
    _tcscpy(szDest, szSource);
  }else {
    _tcscpy(szDest, szStart + 1);
  }

  // remove extension
  szStart = _tcsrchr(szDest, _T('.'));
  if(szStart != NULL) {
    *szStart = _T('\0');
  }

  // make lowercase
  _tcslwr(szDest);

  return S_OK;
}
