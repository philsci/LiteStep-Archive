

#include <windows.h>
#include "grdFunctionHooker.h"


#define MakePtr(type, ptr, AddValue)       (type)((DWORD)(ptr) + (DWORD)(AddValue))
#define DeclPtr(type, name, ptr, AddValue) type name = MakePtr(type, ptr, AddValue)

grdFunctionHooker::grdFunctionHooker() {

}

grdFunctionHooker::~grdFunctionHooker() {
  // clear all the functions in the list...
  HFVector::iterator it = functions.begin();
  for(; it!=functions.end(); it = functions.begin()) {
    UnrouteFunction(&(*it));
  }
  functions.clear();
}

grdFunctionHooker::HFVector::iterator grdFunctionHooker::FindIterator(HookFunc *phf) {
  HFVector::iterator it = functions.begin();

  for(; it!=functions.end() && &(*it)==phf; it++);

  if(it==functions.end()) {
    for(it=functions.begin(); it!=functions.end(); it++) {
      if( ((*it).fdDescription.hModule==phf->fdDescription.hModule) &&
          (_tcscmp((*it).fdDescription.szLibraryName, phf->fdDescription.szLibraryName)==0) &&
          (_tcscmp((*it).fdDescription.szFunctionName, phf->fdDescription.szFunctionName)==0) ) {
        break;
      }
    }
  }

  return it;
}

HRESULT grdFunctionHooker::UnrouteFunction(HookFunc *phf) {
  if(phf==NULL) return E_POINTER;

  // Check input parameters
  if( (phf->fdDescription.hModule == NULL) ||
      (phf->fdDescription.szLibraryName == NULL) ||
      (phf->fdDescription.szLibraryName[0] == '\0') ||
      (phf->fdDescription.szFunctionName == NULL) ||
      (phf->fdDescription.szFunctionName[0] == '\0') ) {
    OutputDebugString("grdFunctionHooker::HookFunction (Invalid Input Parameters)\n");
    return E_INVALIDARG;
  }

  HFVector::iterator it = FindIterator(phf);
  if(it != functions.end()) {
    (*it).procReplacement = (*it).procOriginal;

    HRESULT hr = RerouteFunction(&(*it));
    if(SUCCEEDED(hr)) {
      (*it).procOriginal = (*it).procReplacement; // don't store any strange pointers
      functions.erase(it);

      return S_OK;
    }

    OutputDebugString("grdFunctionHooker::UnrouteFunction (Couldn't reroute back to original function)\n");
    return E_FAIL;
  }
  OutputDebugString("grdFunctionHooker::UnrouteFunction (Tried to unload a function not belonging to us)\n");
  return E_FAIL;
}

HRESULT grdFunctionHooker::RerouteFunction(HookFunc *phf) {
  if(phf==NULL) return E_POINTER;

  // Check input parameters
  if( (phf->fdDescription.hModule == NULL) ||
      (phf->fdDescription.szLibraryName == NULL) ||
      (phf->fdDescription.szLibraryName[0] == '\0') ||
      (phf->fdDescription.szFunctionName == NULL) ||
      (phf->fdDescription.szFunctionName[0] == '\0') ) {
    OutputDebugString("grdFunctionHooker::HookFunction (Invalid Input Parameters)\n");
    return E_INVALIDARG;
  }

  // Is this a system DLL, which Win9X will not let you patch
  if(!osvi.IsNT() && ((DWORD)phf->fdDescription.hModule >= 0x80000000)) {
    OutputDebugString("grdFunctionHooker::HookFunction (Cannot hook system dlls in Win9X)\n");
    return E_FAIL;
  }

  // Get the specific import descriptor.
  PIMAGE_IMPORT_DESCRIPTOR pImportDesc = GetImportDescriptor(phf->fdDescription.hModule,
                                                             phf->fdDescription.szLibraryName);
  if(pImportDesc == NULL) {
    OutputDebugString("grdFunctionHooker::HookFunction (Failed getting library)\n");
    return TRUE;
  }

  // Get the original thunk information for this DLL.  I cannot use
  //  the thunk information stored in the pImportDesc->FirstThunk
  //  because the that is the array that the loader has already
  //  bashed to fix up all the imports.  This pointer gives us acess
  //  to the function names.
  DeclPtr(PIMAGE_THUNK_DATA, pOrigThunk, phf->fdDescription.hModule, pImportDesc->OriginalFirstThunk);

  // Get the array pointed to by the pImportDesc->FirstThunk.  This is
  //  where I will do the actual bash.
  DeclPtr(PIMAGE_THUNK_DATA, pRealThunk, phf->fdDescription.hModule, pImportDesc->FirstThunk);

  // Loop through and look for the one that matches the name.
  while(NULL != pOrigThunk->u1.Function) {
    // Only look at those that are imported by name, not ordinal.
    if(IMAGE_ORDINAL_FLAG != (pOrigThunk->u1.Ordinal & IMAGE_ORDINAL_FLAG)) {
      // Look get the name of this imported function.
      DeclPtr(PIMAGE_IMPORT_BY_NAME, pByName, phf->fdDescription.hModule, pOrigThunk->u1.AddressOfData);

      // if it has no name, bail out...
      if(pByName->Name[0] == '\0') {
        continue;
      }

      // check for right function...
      // RED ALERT!! : (TCHAR*) probably is always a standard (char*)
      if(_tcscmp(phf->fdDescription.szFunctionName, (TCHAR*)pByName->Name)==0) {
        // We found it, now we only need to change the protection to writable before
        // we do the blast. Note that we're now blasting into the real thunk area!
        MEMORY_BASIC_INFORMATION mbi_thunk;

        VirtualQuery(pRealThunk, &mbi_thunk, sizeof(MEMORY_BASIC_INFORMATION));
        VirtualProtect(mbi_thunk.BaseAddress, mbi_thunk.RegionSize,
                       PAGE_READWRITE, &mbi_thunk.Protect);

        HFVector::iterator it = FindIterator(phf);
        HookFunc *hfArray = NULL;
        if(it==functions.end()) {
          HookFunc hf;

          // set the values of hookfunc
          hf.fdDescription.hModule = phf->fdDescription.hModule;
          _tcscpy(hf.fdDescription.szLibraryName, phf->fdDescription.szLibraryName);
          _tcscpy(hf.fdDescription.szFunctionName, phf->fdDescription.szFunctionName);
          hf.procOriginal = (PROC)pRealThunk->u1.Function;

          it = functions.insert(functions.end(), hf);
        }
        // Change the value of procReplacement
        (*it).procReplacement = phf->procReplacement;
        phf->procOriginal = (*it).procOriginal;

        // Do the actual hook.
        pRealThunk->u1.Function = (DWORD)phf->procReplacement;

        // Change the protection back
        DWORD dwOldProtect;
        VirtualProtect(mbi_thunk.BaseAddress, mbi_thunk.RegionSize,
                       mbi_thunk.Protect, &dwOldProtect);
        
        return S_OK;
      }
    }

    // Increment both tables.
    pOrigThunk++;
    pRealThunk++;
  }

  return E_FAIL;
}

PIMAGE_IMPORT_DESCRIPTOR grdFunctionHooker::GetImportDescriptor(HMODULE hModule,
                                                                LPCTSTR szLibraryName) {
  if((NULL == szLibraryName) || (NULL == hModule)) {
    OutputDebugString("GetNamedImportDescriptor :: Invalid parameters\n");
    return NULL;
  }

  PIMAGE_DOS_HEADER pDOSHeader = (PIMAGE_DOS_HEADER)hModule;
  if(IsBadReadPtr(pDOSHeader, sizeof(IMAGE_DOS_HEADER)) ||
     (IMAGE_DOS_SIGNATURE != pDOSHeader->e_magic) ) {
    OutputDebugString("GetNamedImportDescriptor :: No standard DOS header\n");
    return NULL;
  }

  // Get the PE header.
  PIMAGE_NT_HEADERS pNTHeader = MakePtr(PIMAGE_NT_HEADERS, pDOSHeader, pDOSHeader->e_lfanew);
  if(IsBadReadPtr(pNTHeader, sizeof(IMAGE_NT_HEADERS)) ||
     (IMAGE_NT_SIGNATURE != pNTHeader->Signature) ) {
    OutputDebugString("GetNamedImportDescriptor :: No Windows PE header\n");
    return NULL;
  }

  // If there is no imports section, leave now.
  if(0 == pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress) {
    OutputDebugString("GetNamedImportDescriptor :: No imports\n");
    return NULL;
  }

  // Get the pointer to the imports section.
  DeclPtr(PIMAGE_IMPORT_DESCRIPTOR, pImportDesc, pDOSHeader,
          pNTHeader->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);

  // Loop through the import module descriptors looking for the
  //  module whose name matches szLibraryName.
  while(NULL != pImportDesc->Name) {
    PSTR szCurrMod = MakePtr(PSTR, pDOSHeader, pImportDesc->Name);
    if(!stricmp(szCurrMod, szLibraryName)) {
      // Found it.
      break ;
    }
    // Look at the next one.
    pImportDesc++ ;
  }

  // If the name is NULL, then the module is not imported.
  if(NULL == pImportDesc->Name) {
    return NULL;
  }

  return pImportDesc;
}
