#ifndef __GRD_DIB_BITMAP_H__
#define __GRD_DIB_BITMAP_H__

class grdDIBBitmap {
public:
  struct Filter {
    int data[9];
    int factor;
  };

private:
  // private internal state...
	COLORREF   *colorBits;
	BITMAPINFO  bmpInfo;
	HBITMAP     hBitmap;
  int         iWidth, iHeight;

public:
  // constructors / destructors
  grdDIBBitmap();
	virtual ~grdDIBBitmap();

  // public methods
  HRESULT Create(int Width, int Height);
	HRESULT Destroy();

  HRESULT Blt(HDC hdc, int x, int y);
	HRESULT Blt(HDC hdc, int x, int y, int w, int h);
	
	HRESULT Fill(int R, int G, int B);
	HRESULT FillAlpha(int R, int G, int B, int A);

	HRESULT Copy(grdDIBBitmap *dib);
	HRESULT CopyAlpha(grdDIBBitmap *dib, int A);
	HRESULT Copy(grdDIBBitmap *dib, int x, int y, int w, int h, int sx, int sy);
  HRESULT Copy(HDC hdc);

  HRESULT Invert();
  HRESULT Desaturate(int amount); // 0 <= amount <= 255
  HRESULT ReplaceColor(COLORREF clFrom, COLORREF clTo);

  HRESULT ApplyFilter(Filter *pFilter);

  HRESULT GetSize(int *width, int *height);
	operator HBITMAP() const;
};

#endif // !defined(__GRD_DIB_BITMAP_H__)
