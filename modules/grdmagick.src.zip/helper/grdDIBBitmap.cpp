#include <windows.h>
#include "grdDIBBitmap.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

grdDIBBitmap::grdDIBBitmap() :
colorBits(NULL),
hBitmap(NULL),
iWidth(0), iHeight(0) {
}

grdDIBBitmap::~grdDIBBitmap() {
	Destroy();
}

HRESULT grdDIBBitmap::Create(int Width, int Height) {
  if(hBitmap != NULL) {
    // if we already got the correct size... then just keep what we have...
    if(iWidth == Width && iHeight == Height) {
      return S_OK;
    }
	  HRESULT hr = Destroy();
    if(FAILED(hr)) {
      return hr;
    }
  }

	ZeroMemory(&bmpInfo, sizeof(BITMAPINFO));
	bmpInfo.bmiHeader.biSize        = sizeof (BITMAPINFOHEADER);
	bmpInfo.bmiHeader.biWidth       = Width;
	bmpInfo.bmiHeader.biHeight      = Height;
	bmpInfo.bmiHeader.biPlanes      = 1;
	bmpInfo.bmiHeader.biBitCount    = 32; 
	bmpInfo.bmiHeader.biCompression = BI_RGB;
	bmpInfo.bmiHeader.biSizeImage   = (Width*Height) << 2;
	
	hBitmap = CreateDIBSection(NULL, &bmpInfo, DIB_RGB_COLORS, (void **)&colorBits, NULL, NULL); 
  if(hBitmap == NULL) {
    iWidth = 0;
    iHeight = 0;

    return E_FAIL;
  }

  iWidth = Width;
  iHeight = Height;
	
  return S_OK;
}

HRESULT grdDIBBitmap::Destroy() {
  if(hBitmap != NULL) {
		DeleteObject(hBitmap);
    hBitmap = NULL;
  }
  iWidth = 0;
  iHeight = 0;

  return S_OK;
}

HRESULT grdDIBBitmap::Blt(HDC hdc, int x, int y) {
  return Blt(hdc, x, y, iWidth, iHeight);
}

HRESULT grdDIBBitmap::Blt(HDC hdc, int x, int y, int cx, int cy) {
  if(cy == SetDIBitsToDevice(hdc, x, y,
                             cx, cy, 0, 0, 0, cy,
                             colorBits, &bmpInfo, DIB_RGB_COLORS) ) {
    return S_OK;
  }
  return E_FAIL;
}

HRESULT grdDIBBitmap::Fill(int R, int G, int B) {
	COLORREF cl = RGB(B, G, R);
	int iSize = iWidth * iHeight;
  for(int i=0; i<iSize; i++) {
		colorBits[i] = cl;
  }
  return S_OK;
}

HRESULT grdDIBBitmap::FillAlpha(int R, int G, int B, int A) {
	BYTE *dst = (BYTE*)colorBits;
	int iSize = iWidth * iHeight;
		
	while(iSize-- > 0){
		dst[2] = (BYTE)(((B-dst[2])*A+(dst[2]<<8))>>8);
		dst[1] = (BYTE)(((G-dst[1])*A+(dst[1]<<8))>>8);
		dst[0] = (BYTE)(((R-dst[0])*A+(dst[0]<<8))>>8);	
		dst += 4;
	}
  return S_OK;
}

HRESULT grdDIBBitmap::Copy(HDC hdc) {
  if(hdc == NULL) {
    OutputDebugString("grdDIBBitmap::Copy (Invalid Arguments)\n");
		return E_INVALIDARG;
  }

  HDC hTempDC = CreateCompatibleDC(hdc);
  HBITMAP hbmOld = (HBITMAP)SelectObject(hTempDC, hBitmap);

  BitBlt(hTempDC, 0, 0, iWidth, iHeight, hdc, 0, 0, SRCCOPY);

  SelectObject(hTempDC, hbmOld);
  DeleteDC(hTempDC);
  return S_OK;
}

HRESULT grdDIBBitmap::Copy(grdDIBBitmap *dib) {
  if(dib == NULL) {
    OutputDebugString("grdDIBBitmap::Copy (Invalid Arguments)\n");
		return E_INVALIDARG;
  }
  if(iWidth!=dib->iWidth || iHeight!=dib->iHeight) {
    OutputDebugString("grdDIBBitmap::Copy (Tried to copy dibs of different sizes)\n");
		return E_INVALIDARG;
  }

  memcpy(colorBits, dib->colorBits, (iWidth * iHeight) << 2);
  return S_OK;
}

HRESULT grdDIBBitmap::CopyAlpha(grdDIBBitmap *dib, int A) {
  if(dib == NULL) {
    OutputDebugString("grdDIBBitmap::CopyAlpha (Invalid Arguments)\n");
		return E_INVALIDARG;
  }
  if(iWidth!=dib->iWidth || iHeight!=dib->iHeight) {
    OutputDebugString("grdDIBBitmap::CopyAlpha (Tried to copy dibs of different sizes)\n");
		return E_INVALIDARG;
  }

	BYTE *src = (BYTE*)dib->colorBits;
	BYTE *dst = (BYTE*)colorBits;
	int iSize = iWidth * iHeight;
		
	while(iSize-- > 0) {
		dst[0] = (BYTE)(((src[0]-dst[0])*A+(dst[0]<<8))>>8);
		dst[1] = (BYTE)(((src[1]-dst[1])*A+(dst[1]<<8))>>8);
		dst[2] = (BYTE)(((src[2]-dst[2])*A+(dst[2]<<8))>>8);	
		dst += 4;
		src += 4;
	}
  return S_OK;
}

HRESULT grdDIBBitmap::Copy(grdDIBBitmap *dib, int x, int y, int cx, int cy, int sx, int sy) {
 if(dib == NULL) {
    OutputDebugString("grdDIBBitmap::CopyRect (Invalid Arguments)\n");
		return E_INVALIDARG;
  }
  if(sx < 0 || (sx+cx) > dib->iWidth || (sy+cy) > dib->iHeight ||
     x < 0 || (x+cx) > iWidth || (y+cy) > iHeight) {
    OutputDebugString("grdDIBBitmap::CopyRect (Invalid Coords passed)\n");
		return E_INVALIDARG;
  }

	COLORREF *src, *dst;
  int tx = x+cx, ty = y+cy;

  for(; y<ty; y++, sy++) {
    src = dib->colorBits + sy * dib->iWidth + sx;
    dst = colorBits +      y  * iWidth      +  x;
    for(; x<tx; x++) {
      *dst++ = *src++;
    }
    x = tx-cx;
	}
  return S_OK;
}

HRESULT grdDIBBitmap::Invert() {
	COLORREF *dst = (COLORREF*)colorBits;
	int iSize = iWidth * iHeight;
		
	while(iSize-- > 0){
    *dst = *dst++ ^ 0x00ffffff;
	}

  return S_OK;
}

HRESULT grdDIBBitmap::Desaturate(int A) {
	BYTE *dst = (BYTE*)colorBits;
	int iSize = iWidth * iHeight;
		
	while(iSize-- > 0){
	  int gray = (int)(dst[0]*0.3086 + dst[1]*0.6094 + dst[2]*0.0820);
    if(gray > 255) gray = 255;

		dst[0] = (BYTE)(((gray-dst[0])*A+(dst[0]<<8))>>8);
		dst[1] = (BYTE)(((gray-dst[1])*A+(dst[1]<<8))>>8);
		dst[2] = (BYTE)(((gray-dst[2])*A+(dst[2]<<8))>>8);	

		dst += 4;
	}
  return S_OK;
}

HRESULT grdDIBBitmap::ReplaceColor(COLORREF clFrom, COLORREF clTo) {
	COLORREF *dst = (COLORREF*)colorBits;
	int iSize = iWidth * iHeight;

  // discard alpha value...
	clFrom &= 0x00ffffff;
  clTo   &= 0x00ffffff;

	while(iSize-- > 0){
    if((*dst & 0xffffff) == clFrom) {
      *dst = (*dst & 0xff000000) | clTo;
    }
    dst++;
	}

  return S_OK;
}

HRESULT grdDIBBitmap::ApplyFilter(Filter *pFilter) {
  grdDIBBitmap dibDst;
  dibDst.Create(iWidth, iHeight);
  dibDst.Copy(this);

	BYTE *dst  = (BYTE*)colorBits + (iWidth << 2) + 4;
 	BYTE *src1 = (BYTE*)dibDst.colorBits;
 	BYTE *src2 = (BYTE*)dibDst.colorBits + (iWidth << 2);
 	BYTE *src3 = (BYTE*)dibDst.colorBits + (iWidth << 3);

  int *p = pFilter->data;

  int x, y, fcolor;

  for(y=2; y<iHeight; y++) {
    for(x=2; x<iWidth; x++) {
      fcolor = p[0] * src1[0]  +  p[1] * src1[4]  +  p[2] * src1[8] +
               p[3] * src2[0]  +  p[4] * src2[4]  +  p[5] * src2[8] +
               p[6] * src3[0]  +  p[7] * src3[4]  +  p[8] * src3[8];
      dst[0] = (int)((float)fcolor / pFilter->factor + 0.5);
      fcolor = p[0] * src1[1]  +  p[1] * src1[5]  +  p[2] * src1[9] +
               p[3] * src2[1]  +  p[4] * src2[5]  +  p[5] * src2[9] +
               p[6] * src3[1]  +  p[7] * src3[5]  +  p[8] * src3[9];
      dst[1] = (int)((float)fcolor / pFilter->factor + 0.5);
      fcolor = p[0] * src1[2]  +  p[1] * src1[6]  +  p[2] * src1[10] +
               p[3] * src2[2]  +  p[4] * src2[6]  +  p[5] * src2[10] +
               p[6] * src3[2]  +  p[7] * src3[6]  +  p[8] * src3[10];
      dst[2] = (int)((float)fcolor / pFilter->factor + 0.5);

      // move to next pixel...
		  dst += 4; src1 += 4; src2 += 4; src3 += 4;
    }
    // move to next line...
    dst += 8; src1 += 8; src2 += 8; src3 += 8;
  }

  dibDst.Destroy();
  return S_OK;
}


HRESULT grdDIBBitmap::GetSize(int *width, int *height) {
  HRESULT hr = E_POINTER;
  if(width != NULL) {
    *width = iWidth;
    hr = S_OK;
  }
  if(height != NULL) {
    *height = iHeight;
    hr = S_OK;
  }
  return hr;
}

grdDIBBitmap::operator HBITMAP() const {
  return hBitmap;
}
