#ifndef __GRD_STD_STL_H__
#define __GRD_STD_STL_H__

#pragma warning(disable: 4786)
#include <string>

#ifdef _UNICODE
typedef std::wstring stdTString;
#else
typedef std::string  stdTString;
#endif

using namespace std;

#endif //!defined(__GRD_STD_STL_H__)