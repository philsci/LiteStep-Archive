#ifndef __GRD_MAGIC_H__
#define __GRD_MAGIC_H__

#pragma warning(disable: 4786)

namespace grdMagickFX {
  class Factory;
}
class grdFunctionHooker;

#include "ls\lswinbase.h"
#include "StdSTL.h"
#include <map>

class grdMagick : public Window {
protected:
  struct WindowFX;
  struct ModuleFX {
    stdTString strName;
    stdTString strParams;
  };

  typedef std::map<stdTString, ModuleFX> ModuleFXMap;
  typedef ModuleFXMap::iterator          ModuleFXIterator;
  typedef std::map<HWND, WindowFX*>      WindowFXMap;
  typedef WindowFXMap::iterator          WindowFXIterator;

  ModuleFXMap moduleMagics;
  WindowFXMap windowMagics;

  PROC oldLoadLibrary;

  grdFunctionHooker   *pFuncHooker;
  grdMagickFX::Factory *pFXFactory;

  // constructor
protected:
  grdMagick();

public:
  static HRESULT Create(grdMagick **ppSingleton);
  virtual ~grdMagick();

public:
  HINSTANCE MagicLoadLibrary(LPCTSTR szLibraryName);
  HDC MagicBeginPaint(HWND hwnd, LPPAINTSTRUCT pps);
  BOOL MagicEndPaint(HWND hwnd, const LPPAINTSTRUCT pps);

public:
  HRESULT SetModuleWindowFX(LPCTSTR szModule, LPCTSTR szConfig);

protected:
  HRESULT StartFunctionHooks();
  HRESULT StopFunctionHooks();

  HRESULT StartBangCommands();
  HRESULT StopBangCommands();

  HRESULT CreateModuleMagics();
  HRESULT CreateModuleMagic(LPCTSTR szConfig);
  HRESULT DeleteModuleMagics();

  HRESULT GetWindowFX(HWND hwnd, WindowFX **ppWFX);
  HRESULT ReleaseWindowFX(HWND hwnd, WindowFX *pWFX);
  HRESULT DeleteWindowFXs();

// static helper
  static HRESULT GetModuleShortName(LPTSTR szDest, LPCTSTR szSource);


public:
  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);
};

#endif //!defined(__GRD_MAGIC_H__)