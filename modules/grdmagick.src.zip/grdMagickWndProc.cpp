#include "grdMagickDef.h"
#include "grdMagick.h"
#include "ls\lsapi.h"

void grdMagick::windowProc(Message& message) {
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate,     WM_CREATE)
    MESSAGE(onDestroy,    WM_DESTROY)
    MESSAGE(onEndSession, WM_ENDSESSION)
    MESSAGE(onEndSession, WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,   LM_GETREVID) 
    MESSAGE(onSysCommand, WM_SYSCOMMAND)
  END_MESSAGEPROC
}

void grdMagick::onEndSession(Message& message) {
  message.lResult = SendMessage(GetLitestepWnd(), message.uMsg, message.wParam, message.lParam);
}
void grdMagick::onSysCommand(Message& message) {
  if(message.wParam == SC_CLOSE) {
    PostMessage(GetLitestepWnd(), WM_KEYDOWN, LM_SHUTDOWN, 0);
  }else {
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
  }
}

void grdMagick::onCreate(Message& message) {
  int msgs[] = {LM_GETREVID,0};
  SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  SetWindowLong(hWnd, GWL_USERDATA, 0x49474541); // usually called magic-d-word
}

void grdMagick::onDestroy(Message& message) {
	int msgs[] = {LM_GETREVID,0};
	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
}

void grdMagick::onGetRevId(Message& message) {
  char* buf = (char*)(message.lParam);
  switch(message.wParam) {
    case 0:
      strcpy(buf, szRevision);
      break;
    case 1:
      strcpy(buf, szId);
      break;
    default:
      *buf = '\0';
  }
  message.lResult = strlen(buf);
}