#define INITGUID

#include <windows.h>
#include <d3drmwin.h>
#include <stdio.h>

const long magicDWord = 0x49474541;

#define D3_MIN		0x8001
#define D3_RESTORE	0x8002
#define D3_DO		0x8003
#define D3_DESTROY	0x8004

#define VERTEX(px,py,pz,nx,ny,nz,tu,tv)  \
	{ { (D3DVALUE)px,(D3DVALUE)py,(D3DVALUE)pz }, \
	  { (D3DVALUE)nx,(D3DVALUE)ny,(D3DVALUE)nz, }, \
	  (D3DVALUE)tu,(D3DVALUE)tv,(D3DCOLOR)0 }

unsigned vertorder[] = { 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23 };

void SetStatusText(char* text)
{
	HWND hwnd = FindWindowEx(FindWindow("D3", "D3"), NULL, "Edit", NULL);
	char buffer[1024] = "";

	GetWindowText(hwnd, buffer, 1024);
	strcat(text, "\r\n");
	strcat(buffer, text);
	SetWindowText(hwnd, buffer);
}