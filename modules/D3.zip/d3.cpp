#include "d3.h"
#include <commctrl.h>
#include <commdlg.h>
#include <malloc.h>
#include <math.h>
#include <crtdbg.h>

#define MAXDRV 5  // Maximum D3D drivers expected  
#define PI 3.14159

// Global variables

HWND hwndMain;
LPDIRECT3DRM lpD3DRM;
LPDIRECTDRAW lpDD;
LPDIRECTDRAWCLIPPER lpDDClipper;

struct _gInfo {
    LPDIRECT3DRMDEVICE dev;     // Direct3DRM device 
    LPDIRECT3DRMVIEWPORT view;  // Direct3DRM viewport through which 
                                // scene is viewed
	LPDIRECT3DRMVIEWPORT radar; // The radar

    LPDIRECT3DRMFRAME scene;  // Master frame
    LPDIRECT3DRMFRAME camera;  // Frame describing user's POV 
	LPDIRECT3DRMFRAME becamera;  // Bird's Eye Camera

    GUID drvGUID[MAXDRV];     // GUIDs of available D3D drivers 
    char drvName[MAXDRV][50]; // Names of available D3D drivers 
    int  numDrv;  // available D3D drivers 
    int  curr;  // D3D driver currently used 

    BOOL bQuit;  // Program is about to terminate 
    BOOL bInit;  // All D3DRM objects are initialized 
    BOOL bMin;   // Window is minimized 

    int bpp;  // Bit depth of current display mode
} gInfo;

struct d3window {
	char path[256];
	HWND hwnd;
	LPDIRECT3DRMMESH mesh;
	LPDIRECT3DRMFRAME frame;
	LPDIRECT3DRMVISUAL shadow;
	D3DRMGROUPINDEX group;
	BOOL MAX;

	d3window* next;
};

d3window* d3winlist;

struct _hotspot {
	D3DVECTOR pos, y, z;
	int set;
} HotSpot[5];

//LPDIRECT3DRMFRAME HotSpot[5];

LPDIRECT3DRMLIGHT dlight;
LPDIRECT3DRMFRAME tc;
D3DVALUE camx=0, camy=2, camz=-25;
int ScreenX, ScreenY;
float step = 1.0;
BOOL FIRST=TRUE;
int zorder=0;
HINSTANCE hInstance;
int GROUND, SHADOWS, RADAR=1;
int ICON_DEPTH = 32, WINDOW_DEPTH=512, GROUND_DEPTH=128;
char ini[MAX_PATH] = "h:\\d3\\d3.ini";
char* AppName = "D3";
char AppPath[MAX_PATH] = "";
int JoyPosX, JoyPosY;
BOOL ANIMATION=FALSE;
RECT OldDesktop;

HWND HIDEME;
HINSTANCE HookDll;
HHOOK Hook;
HOOKPROC (FAR* HookProc)(int, WPARAM, LPARAM);
void (FAR* HookQuit)();

HINSTANCE CommandDll;
int (FAR* CommandInit)(HWND, HINSTANCE, char*);
void (FAR* CommandQuit)();

// Function prototypes.
 
BOOL InitApp(HINSTANCE, int);
long FAR PASCAL WindowProc(HWND, UINT, WPARAM, LPARAM);
BOOL EnumDrivers(HWND win);
HRESULT WINAPI enumDeviceFunc(LPGUID lpGuid, 
    LPSTR lpDevDesc, LPSTR lpDevName, LPD3DDEVICEDESC lpHWDesc,
    LPD3DDEVICEDESC lpHELDesc, LPVOID lpContext);
DWORD bppToDDBD(int bpp);
BOOL CreateDevAndView(LPDIRECTDRAWCLIPPER lpDDClipper, 
    int driver, int width, int height);
BOOL SetRenderState(void);
BOOL RenderLoop(void);
BOOL MyScene(LPDIRECT3DRMDEVICE dev, LPDIRECT3DRMVIEWPORT view,
    LPDIRECT3DRMFRAME scene, LPDIRECT3DRMFRAME camera);
void AddMyTexture(HWND hwnd, RECT r, LPDIRECT3DRMMESH lpMesh, 
    LPDIRECT3DRMTEXTURE *lplpTex, HBITMAP bmp, int trans, int DEPTH);
void CleanUp(void);
void MakeMyWrap(LPDIRECT3DRMMESH mesh, LPDIRECT3DRMWRAP * lpWrap);

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
void SetVertexList(LPDIRECT3DRMMESH, D3DRMGROUPINDEX, int, int, int);
void MoveCamera(D3DVALUE x, D3DVALUE y, D3DVALUE z);
void RotateCamera(D3DVALUE x, D3DVALUE y, D3DVALUE z, D3DVALUE amount, BOOL FLAG);
void DeleteWindow(d3window* d);
void AddWindow(d3window* d);
void AddLaunchBox(int x, int y, int z, int rx, int ry, int rz, int r, int g, int b, int trans, HBITMAP bmp, int ix, int iy, char* path);
void AddBillboard(int x, int y, int z, int rx, int ry, int rz, int trans, HBITMAP bmp, int width, int height);
HBITMAP BitmapFromIcon (HICON hIcon);
void SetHotSpot(int);
void MoveToHotSpot(int);
void DoCommand(char* command);
HICON GetWindowIcon(HWND Hwnd);
void StartConfiguration();
void LoadSetup();

int CheckForJoystick();

// Initializes the application and enters a message loop.
// Message loop renders scene until quit message is received.
int PASCAL WinMain (HINSTANCE hInst, HINSTANCE hPrevInst,
    LPSTR cmdline, int cmdshow) 
{
    MSG msg;
    HACCEL accel = NULL;
	char temp[256] = "";

	hInstance = hInst;

	if (GetModuleFileName (hInstance, AppPath, sizeof (AppPath)) > 0) 
	{
		int x = strlen(AppPath);
		while (x && AppPath[x-1] != '\\') AppPath[--x] = '\0';
		if (x) AppPath[--x] = '\0';
	}

	sprintf(ini, "%s\\d3.ini", AppPath);

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	SystemParametersInfo(SPI_GETWORKAREA,0,(PVOID)&OldDesktop,SPIF_SENDCHANGE);

    if ( !InitApp(hInst, cmdshow) ) return 1;
	CreateWindow("Edit", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_MULTILINE | ES_WANTRETURN, 0, ScreenY-150, 400, 124, hwndMain, NULL, hInstance, 0);

	ANIMATION=GetPrivateProfileInt("Main", "Animation", 1, ini);
	ICON_DEPTH = GetPrivateProfileInt("Main", "IconDepth", 32, ini);
	sprintf(temp, "Icon Depth -> %d", ICON_DEPTH);
	SetStatusText(temp);
	WINDOW_DEPTH = GetPrivateProfileInt("Main", "WindowDepth", 512, ini);
	sprintf(temp, "Window Depth -> %d", WINDOW_DEPTH);
	SetStatusText(temp);
	GROUND_DEPTH = GetPrivateProfileInt("Main", "GroundDepth", 128, ini);
	sprintf(temp, "Ground Depth -> %d", GROUND_DEPTH);
	SetStatusText(temp);

	sprintf(temp, "%s\\command.dll", AppPath);
	CommandDll = LoadLibrary(temp);
	if (CommandDll)
	{
		SetStatusText("command.dll loaded");
		CommandInit = (int (FAR*)(HWND, HINSTANCE, char*))GetProcAddress(CommandDll, "InitModule");
		CommandQuit = (void (FAR*)())GetProcAddress(CommandDll, "QuitModule");
		CommandInit(hwndMain, CommandDll, ini);
	}

	sprintf(temp, "%s\\hook.dll", AppPath);
	HookDll = LoadLibrary(temp);
	if (HookDll)
	{
		SetStatusText("hook.dll loaded");
		HookProc = (HOOKPROC (FAR*)(int, WPARAM, LPARAM))GetProcAddress(HookDll, "HookFunction");
		HookQuit = (void (FAR*)())GetProcAddress(HookDll, "Quit");
		Hook =  SetWindowsHookEx(WH_CBT,(HOOKPROC)HookProc,HookDll,0);
		if (Hook) SetStatusText("- Windows hook set");
	}

	EnumWindows((WNDENUMPROC)EnumWindowsProc, 0);
	FIRST=FALSE;
	RenderLoop();
	CheckForJoystick();

	ATOM D3Break = GlobalAddAtom("D3Break");
	RegisterHotKey(hwndMain, D3Break, MOD_WIN, 'B');
	ATOM D3Command = GlobalAddAtom("D3Command");
	RegisterHotKey(hwndMain, D3Command, MOD_WIN, 'C');

	while ( !gInfo.bQuit ) 
	{
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) 
		{
            if (!TranslateAccelerator(msg.hwnd, accel, &msg)) 
			{
                TranslateMessage(&msg);
                DispatchMessage(&msg);
			}

			if (GetFocus() == hwndMain && ANIMATION)	RenderLoop();
        }
    }

	UnregisterHotKey(hwndMain, D3Break);
	GlobalDeleteAtom(D3Break);
	UnregisterHotKey(hwndMain, D3Command);
	GlobalDeleteAtom(D3Command);

	UnhookWindowsHookEx(Hook);
	HookQuit();
    FreeLibrary(HookDll);
	CommandQuit();
	FreeLibrary(CommandDll);

	SystemParametersInfo(SPI_SETWORKAREA,0,(PVOID)&OldDesktop,SPIF_SENDCHANGE);

	if (d3winlist)
	{
		d3window* p = d3winlist;
		while (p)
		{
			if (p->MAX) ShowWindow(p->hwnd, SW_SHOWMAXIMIZED);
			else ShowWindow(p->hwnd, SW_SHOWNORMAL);
			p=p->next;
		}
	}

    return msg.wParam;
}

void LoadSetup()
{
}

// Creates window and initializes all objects necessary to begin 
// rendering.
 
BOOL InitApp(HINSTANCE hInst, int cmdshow) 
{
    HWND win;
    HDC hdc;
    WNDCLASS wc;
    RECT rc;

    // Set up and register the window class.
    wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = sizeof(DWORD);
    wc.hInstance = hInst;
    wc.hIcon = LoadIcon(hInst, "AppIcon");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszMenuName = NULL;        
    wc.lpszClassName = "D3";
    if (!RegisterClass(&wc)) return FALSE;
    
    // Initialize the global variables.
    memset(&gInfo, 0, sizeof(gInfo));

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

    // Create the window.
    hwndMain = win = CreateWindowEx(WS_EX_TOOLWINDOW, "D3",
            "D3",
            WS_VISIBLE | WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
            0,0,
            ScreenX, ScreenY, NULL, NULL, hInst, NULL);
    if ( !win ) return FALSE;
   
    // Record the current display bits-per-pixel.
    hdc = GetDC(win);
    gInfo.bpp = GetDeviceCaps(hdc, BITSPIXEL);
    ReleaseDC(win, hdc);
   
    // Enumerate the D3D drivers and select one.
    if ( !EnumDrivers(win) ) return FALSE;
   
    // Create the D3DRM object and the D3DRM window object.
    lpD3DRM = NULL;
    Direct3DRMCreate(&lpD3DRM);
	_ASSERT(lpD3DRM != NULL);
    
    // Create the master scene frame and camera frame.
	gInfo.scene = NULL;
	gInfo.camera = NULL;
    lpD3DRM->CreateFrame(NULL, &gInfo.scene);
	_ASSERT(gInfo.scene != NULL);

    lpD3DRM->CreateFrame(gInfo.scene, &gInfo.camera);
	_ASSERT(gInfo.camera != NULL);
    gInfo.camera->SetPosition(gInfo.scene,
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0));

	// Create the radar camera
	RADAR = GetPrivateProfileInt("Main", "Radar", 1, ini);
	if (RADAR)
	{
		gInfo.becamera = NULL;
		lpD3DRM->CreateFrame(gInfo.scene, &gInfo.becamera);
		_ASSERT(gInfo.becamera != NULL);
		gInfo.becamera->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(1), D3DVAL(0), D3DVAL(0), D3DDivide(PI, 2));
		gInfo.becamera->SetPosition(gInfo.scene, D3DVAL(0.0), D3DVAL(100.0), D3DVAL(0.0));
	}

    // Create a DirectDrawClipper object and associate the 
    // window with it.
	lpDDClipper=NULL;
    DirectDrawCreateClipper(0, &lpDDClipper, NULL);
	_ASSERT(lpDDClipper != NULL);
    lpDDClipper->SetHWnd(0, win);
    
    // Create the D3DRM device by using the selected D3D driver.
    GetClientRect(win, &rc);
    CreateDevAndView(lpDDClipper, gInfo.curr, rc.right, rc.bottom);
    
    // Create the scene to be rendered.
    MyScene(gInfo.dev, gInfo.view, gInfo.scene, gInfo.camera);
    
    gInfo.bInit = TRUE;  // Initialization completed
    
    // Display the window.
    ShowWindow(win, cmdshow);
    UpdateWindow(win);

    return TRUE;
}

// Main window message handler.
LONG FAR PASCAL WindowProc(HWND win, UINT msg, 
    WPARAM wparam, LPARAM lparam) 
{
    RECT r; PAINTSTRUCT ps;
    LPDIRECT3DRMWINDEVICE lpD3DRMWinDev;

    switch (msg) 
	{
	case WM_SYSCOMMAND:
	{
		switch (wparam)
		{
			case SC_CLOSE: break;
		}
	}
	break;

    case WM_DESTROY:
	{
        CleanUp(); 
	}
	break;

    case WM_ACTIVATE: 
	{
        // Create a Windows-specific D3DRM window device to handle this
        // message.
        LPDIRECT3DRMWINDEVICE lpD3DRMWinDev;
        if (!gInfo.dev) break;
        gInfo.dev->QueryInterface(IID_IDirect3DRMWinDevice,
            (void **) &lpD3DRMWinDev);
        lpD3DRMWinDev->HandleActivate((WORD) wparam);
        lpD3DRMWinDev->Release();
    }
    break;

    case WM_PAINT:
	{
        if (!gInfo.bInit || !gInfo.dev)
            return DefWindowProc(win, msg, wparam, lparam);
       
        // Create a Windows-specific D3DRM window device to handle this
        // message.
        if (GetUpdateRect(win, &r, FALSE)) 
		{
            BeginPaint(win, &ps);
            gInfo.dev->QueryInterface(IID_IDirect3DRMWinDevice, (void **) &lpD3DRMWinDev);
            if (FAILED(lpD3DRMWinDev->HandlePaint(ps.hdc))) lpD3DRMWinDev->Release();
            EndPaint(win, &ps);
        }
		RenderLoop();
	}
	break;

	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	{
		SetFocus(hwndMain);
	}
	break;

	case WM_LBUTTONDBLCLK:
	{
		HRESULT r;
			
		LPDIRECT3DRMPICKEDARRAY pickarray;
		LPDIRECT3DRMFRAME selected;
		r=gInfo.view->Pick( LOWORD(lparam), HIWORD(lparam), &pickarray );
		if (r!=D3DRM_OK) return FALSE;

		DWORD numpicks=pickarray->GetSize();
		if (numpicks>0)
		{
			LPDIRECT3DRMVISUAL visual;
			LPDIRECT3DRMFRAMEARRAY framearray;
			D3DRMPICKDESC pickdesc;

			r=pickarray->GetPick( 0, &visual, &framearray, &pickdesc );
			if (r==D3DRM_OK)
			{
				framearray->GetElement( framearray->GetSize()-1, &selected );
				d3window* p = (d3window*)malloc(sizeof(d3window));

				if (d3winlist)
				{
					for (p=d3winlist; p; p=p->next)
					{
						if (p)
						{
							if ( p->frame == selected )
							{
								if (p->hwnd)
								{
									if (p->MAX) ShowWindow(p->hwnd, SW_SHOWMAXIMIZED);
									else ShowWindow(p->hwnd, SW_SHOWNORMAL);

									SetForegroundWindow(p->hwnd);
									if (!HIWORD(GetKeyState(VK_CONTROL)))
									{
										gInfo.scene->DeleteChild(selected);
										DeleteWindow(p);
									}
								}
								else if (p->path[0])
								{
									if (p->path[0] == '!')
									{
										DoCommand(p->path+1);
									}
									else
									{
										WinExec(p->path, SW_NORMAL);
									}
								}
								break;
							}
						}
					}
				}

				visual->Release();
				framearray->Release();
				selected->Release();
				p=0;
			}
		}
		pickarray->Release();
	}
	break;

	case WM_SETFOCUS:
	{
		//if (!FIRST) 
		//{ 
		//	EnumWindows((WNDENUMPROC)EnumWindowsProc, 0); 
		//	SetForegroundWindow(hwndMain);
		//}
	}
	break;
	
	case WM_WINDOWPOSCHANGING:
	{
		WINDOWPOS* pos = (WINDOWPOS*)lparam;
		pos->flags |= SWP_NOZORDER;
	}
	break;

	case WM_MOUSEMOVE:
	{
		int x = LOWORD(lparam);
		int y = HIWORD(lparam);
		if ((ScreenX - x) < 5) // Right
		{
			if (HIWORD(GetKeyState(VK_CONTROL)))
				MoveCamera(step, 0, 0);
			else
				RotateCamera(0, 1, 0, D3DVAL(.1), TRUE);
		}
		else if (x < 5) // Left
		{
			if (HIWORD(GetKeyState(VK_CONTROL)))
				MoveCamera(-step, 0, 0);
			else
				RotateCamera(0, 1, 0, -D3DVAL(.1), TRUE);
		}
		else if (y < 5) // Up
		{
			if (HIWORD(GetKeyState(VK_CONTROL)))
				MoveCamera(0, step, 0);
			else
				MoveCamera(0, 0, step);
		}
		else if ((ScreenY - y) < 5) // Down
		{
			if (HIWORD(GetKeyState(VK_CONTROL)))
				MoveCamera(0, -step, 0);
			else
				MoveCamera(0, 0, -step);
		}
	}
	break;

	case WM_HOTKEY:
	{
		switch (HIWORD(lparam))
		{
			case 'B':
			{
				SetForegroundWindow(hwndMain);
				SetFocus(hwndMain);
			}
			break;

			case 'C':
			{
				HWND command = FindWindowEx(hwndMain, NULL, "D3CommandWindow", NULL);
				SetForegroundWindow(hwndMain);
				SetFocus(command);
			}
			break;
		}
	}
	break;

	case WM_KEYDOWN:
	{
		switch ((int)wparam)
		{
			case VK_UP:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					MoveCamera(0, step, 0);
				else
					MoveCamera(0, 0, step);
			break;
			case VK_DOWN:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					MoveCamera(0, -step, 0);
				else
					MoveCamera(0, 0, -step);
			break;
			case 33: // Page Up
				RotateCamera(1, 0, 0, D3DVAL(-.1), FALSE);
			break;
			case 34: // Page Down
				RotateCamera(1, 0, 0, D3DVAL(.1), FALSE);
			break;
			case VK_LEFT:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					MoveCamera(-step, 0, 0);
				else
					RotateCamera(0, 1, 0, D3DVAL(-.1), TRUE);
			break;
			case VK_RIGHT:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					MoveCamera(step, 0, 0);
				else
					RotateCamera(0, 1, 0, D3DVAL(.1), TRUE);
			break;
			case VK_F1:
				if (HIWORD(GetKeyState(VK_CONTROL)))  // Set Position
					SetHotSpot(0);
				else // Move To
					MoveToHotSpot(0);
			break;
			case VK_F2:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					SetHotSpot(1);
				else
					MoveToHotSpot(1);
			break;
			case VK_F3:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					SetHotSpot(2);
				else
					MoveToHotSpot(2);
			break;
			case VK_F4:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					SetHotSpot(3);
				else
					MoveToHotSpot(3);
			break;
			case VK_F5:
				if (HIWORD(GetKeyState(VK_CONTROL)))
					SetHotSpot(4);
				else
					MoveToHotSpot(4);
			break;
			case 67: // C
			{
				zorder=0;
				gInfo.camera->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0),D3DVAL(0),D3DVAL(0),D3DVAL(0));
				gInfo.camera->SetPosition(gInfo.scene, camx, camy, camz);
				if (RADAR) gInfo.becamera->SetPosition(gInfo.scene, camx, camy, 100);
				RenderLoop();
			}
			break;
			/*default:
			{
				char temp[256] = "";
				sprintf(temp, "%d", (int)wparam);
				MessageBox(hwndMain, temp, "Key Pressed", MB_SYSTEMMODAL);
			}*/
		}
	}
	break;

	case MM_JOY1MOVE:
	{
		JoyPosX = LOWORD(lparam);
		JoyPosY = HIWORD(lparam);
	}
    break;
	
	case D3_MIN:
	{
		RECT r;
		D3DVALUE x, y, z;
		D3DVALUE RADIUS=25.0, OFFSET=0;

		d3window* add = (d3window*)malloc(sizeof(d3window));
		
		if (IsZoomed((HWND)wparam)) add->MAX=TRUE;
		GetClientRect((HWND)wparam, &r);
		
		// Mesh
		LPDIRECT3DRMTEXTURE texture;
		lpD3DRM->CreateMesh(&add->mesh);
		add->mesh->AddGroup( 24, 6, 4, vertorder, &add->group);
		SetVertexList(add->mesh, add->group, r.right, r.bottom, 1);
		add->mesh->Scale(D3DVALUE(.01), D3DVALUE(.01), D3DVALUE(1));
		add->mesh->SetGroupColorRGB(add->group, D3DVALUE(1), D3DVALUE(1), D3DVALUE(1));
		AddMyTexture((HWND)wparam, r, add->mesh, &texture, NULL, 0, WINDOW_DEPTH);
		texture->Release();
		texture=0;
				
		// Mesh Frame
		lpD3DRM->CreateFrame(gInfo.scene, &add->frame);

		if (zorder > 7) { RADIUS += (RADIUS/2)*(zorder/7); OFFSET=(D3DVALUE)(sqrt(pow(RADIUS, 2)/2))/2; }
		switch (zorder%8)
		{
			case 0: x=0; y=2; z=RADIUS; break;
			case 1: x=(D3DVALUE)sqrt(pow(RADIUS, 2)/2); y=2; z=x; break;
			case 2: x=RADIUS; y=2; z=0; break;
			case 3: x=(D3DVALUE)sqrt(pow(RADIUS, 2)/2); y=2; z=-x; break;
			case 4: x=0; y=2; z=-RADIUS; break;
			case 5: x=(D3DVALUE)-sqrt(pow(RADIUS, 2)/2); y=2; z=x; break;
			case 6: x=-RADIUS; y=2; z=0; break;
			case 7: x=(D3DVALUE)-sqrt(pow(RADIUS, 2)/2); y=2; z=-x; break;
		}

		add->frame->SetPosition(gInfo.camera, x+OFFSET, y, z-OFFSET);
		add->frame->LookAt(gInfo.camera, gInfo.scene, D3DRMCONSTRAIN_Z);
		add->frame->AddVisual(add->mesh);
		
		if (GROUND && SHADOWS)
		{
			// Shadow
			lpD3DRM->CreateShadow(add->mesh, dlight,
								D3DVALUE(0), D3DVALUE(.05), D3DVALUE(0),
								D3DVALUE(0), D3DVALUE(1), D3DVALUE(0),
								&add->shadow);
			add->frame->AddVisual(add->shadow);
		}

		add->hwnd = (HWND)wparam;
		AddWindow(add);
		SetForegroundWindow(hwndMain);
		ShowWindow(add->hwnd, SW_HIDE);
		//HIDEME=(HWND)wparam;
		//SetTimer(hwndMain, 0, 500, NULL);
		zorder++;
	}
	break;

	case D3_DO:
	{
		HWND edit = (HWND)lparam;
		char command[MAX_PATH] = "";
		char alias[MAX_PATH] = "";

		GetWindowText(edit, alias, MAX_PATH);
		GetPrivateProfileString("Alias",  alias+1, alias, command, MAX_PATH, ini);

		if (command[0] == '!') DoCommand(command+1);
		else DoCommand(command);
	}
	break;

	case D3_DESTROY:
	{
		d3window* p = (d3window*)malloc(sizeof(d3window));

		for (p=d3winlist; p; p=p->next)
		{
			if (p->hwnd == (HWND)wparam)
			{
				gInfo.scene->DeleteChild(p->frame);
				DeleteWindow(p);
				break;
			}
		}
	}
	break;

	case WM_TIMER:
	{
		KillTimer(hwndMain, 0);
		ShowWindow(HIDEME, SW_HIDE);
	}
	break;

	case D3_RESTORE:
	{
		//MessageBox(hwndMain, "Restoring", AppName, MB_SYSTEMMODAL);
	}
	break;

	default:
        return DefWindowProc(win, msg, wparam, lparam);
    }

    return 0L;
}

// Enumerate the available D3D drivers and choose one.
BOOL EnumDrivers(HWND win) 
{
    LPDIRECT3D lpD3D; HRESULT rval;

    // Create a DirectDraw object and query for the Direct3D interface 
    // to use to enumerate the drivers.
    DirectDrawCreate(NULL, &lpDD, NULL);
	rval = lpDD->QueryInterface(IID_IDirectDraw, (void**) &lpDD);
	if (rval != DD_OK)
	{
		lpDD->Release();
		_ASSERT(0);
		return FALSE;
	}
	
	lpDD->SetCooperativeLevel(NULL, DDSCL_NORMAL);

    rval = lpDD->QueryInterface(IID_IDirect3D, (void**) &lpD3D);
    if (rval != DD_OK) 
	{
        lpDD->Release();
		_ASSERT(0);
        return FALSE;
    }
    
    // Enumerate the drivers, setting curr to -1 to initialize the
    // driver selection code in enumDeviceFunc.
     
    gInfo.curr = -1;
    lpD3D->EnumDevices(enumDeviceFunc, &gInfo.curr);
    
    // Ensure at least one valid driver was found.
     
    if (gInfo.numDrv == 0) { _ASSERT(0); return FALSE; }

    lpD3D->Release();
    
    return TRUE;
}

// Callback function that records each usable D3D driver's name 
// and GUID. Chooses a driver and sets *lpContext to this driver.
HRESULT WINAPI enumDeviceFunc(LPGUID lpGuid, LPSTR lpDevDesc, 
    LPSTR lpDevName, LPD3DDEVICEDESC lpHWDesc, 
    LPD3DDEVICEDESC lpHELDesc, LPVOID lpContext) 
{
    static BOOL hardware = FALSE; // Current start driver is hardware 
    static BOOL mono = FALSE;     // Current start driver is mono light 
    LPD3DDEVICEDESC lpDesc;
    int *lpStartDriver = (int *)lpContext;
   
    // Decide which device description should be consulted.
    lpDesc = lpHWDesc->dcmColorModel ? lpHWDesc : lpHELDesc;
    
    // If this driver cannot render in the current display bit-depth, 
    // skip it and continue with the enumeration.
    if (!(lpDesc->dwDeviceRenderBitDepth & bppToDDBD(gInfo.bpp)))
        return D3DENUMRET_OK;
    
    // Record this driver's name and GUID.
    memcpy(&gInfo.drvGUID[gInfo.numDrv], lpGuid, sizeof(GUID));
    lstrcpy(&gInfo.drvName[gInfo.numDrv][0], lpDevName);
   
    // Choose hardware over software, RGB lights over mono lights.
    if (*lpStartDriver == -1) 
	{
        // This is the first valid driver.
        *lpStartDriver = gInfo.numDrv;
        hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
        mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
    } 
	else if (lpDesc == lpHWDesc && !hardware) 
	{
        // This driver is hardware and the start driver is not.
        *lpStartDriver = gInfo.numDrv;
        hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
        mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
    } 
	else if ((lpDesc == lpHWDesc && hardware ) || 
             (lpDesc == lpHELDesc && !hardware))
	{
        if (lpDesc->dcmColorModel == D3DCOLOR_MONO && !mono) 
		{
            // This driver and the start driver are the same type, and 
            // this driver is mono whereas the start driver is not.
            *lpStartDriver = gInfo.numDrv;
            hardware = lpDesc == lpHWDesc ? TRUE : FALSE;
            mono = lpDesc->dcmColorModel & D3DCOLOR_MONO ? TRUE : FALSE;
        }
    }

    gInfo.numDrv++;
    if (gInfo.numDrv == MAXDRV) return (D3DENUMRET_CANCEL);
    return (D3DENUMRET_OK);
}

// Converts bits-per-pixel to a DirectDraw bit-depth flag.
DWORD bppToDDBD(int bpp) 
{
    switch(bpp) 
	{
        case 1: return DDBD_1;
        case 2: return DDBD_2;
        case 4: return DDBD_4;
        case 8: return DDBD_8;
        case 16: return DDBD_16;
        case 24: return DDBD_24;
        case 32: return DDBD_32;
        default: return 0;
    }
}

// Create the D3DRM device and viewport with the given D3D driver and 
// with the specified size.
BOOL CreateDevAndView(LPDIRECTDRAWCLIPPER lpDDClipper, int driver, 
    int width, int height) 
{
    HRESULT rval;
	int back = GetPrivateProfileInt("Main", "BackDistance", 200, ini);

    // Create the D3DRM device from this window by using the specified 
    // D3D driver.
    lpD3DRM->CreateDeviceFromClipper(lpDDClipper, 
        &gInfo.drvGUID[driver], width, height, &gInfo.dev);
    
    // Create the D3DRM viewport by using the camera frame.  Set the 
    // background depth to a large number. The width and height
    // might have been slightly adjusted, so get them from the device.
    width = gInfo.dev->GetWidth();
    height = gInfo.dev->GetHeight();
    rval = lpD3DRM->CreateViewport(gInfo.dev, gInfo.camera,
               0, 0, width, height, &gInfo.view);
    if (rval != D3DRM_OK) 
	{
        gInfo.dev->Release();
		_ASSERT(0);
        return FALSE;
    }

    rval = gInfo.view->SetBack(D3DVAL(back));
    if (rval != D3DRM_OK) 
	{
        gInfo.dev->Release();
        gInfo.view->Release();
		_ASSERT(0);
        return FALSE;
    }
    
	if (RADAR)
	{
		rval = lpD3DRM->CreateViewport(gInfo.dev, gInfo.becamera,
				   width-100, 0, 100, 100, &gInfo.radar);
		if (rval != D3DRM_OK) 
		{
			gInfo.dev->Release();
			_ASSERT(0);
			return FALSE;
		}
		rval = gInfo.radar->SetBack(D3DVAL(99));
		if (rval != D3DRM_OK) 
		{
			gInfo.dev->Release();
			gInfo.radar->Release();
			_ASSERT(0);
			return FALSE;
		}
	}

    // Set the render quality, fill mode, lighting state,
    // and color shade info.
    if (!SetRenderState()) { _ASSERT(0); return FALSE; }
    return TRUE;
}

// Set the render quality and shade information.
BOOL SetRenderState(void) 
{
    HRESULT rval;
    
    // Set the render quality (light toggle, fill mode, shade mode).
    rval = gInfo.dev->SetQuality(D3DRMLIGHT_ON |
            D3DRMFILL_SOLID | D3DRMSHADE_GOURAUD);
    if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
    
    switch (gInfo.bpp) 
	{
        case 1:
            if (FAILED(gInfo.dev->SetShades(4)))
                goto shades_error;
            if (FAILED(lpD3DRM->SetDefaultTextureShades(4)))
                goto shades_error;
            break;
        case 16:
            if (FAILED(gInfo.dev->SetShades(32)))
                goto shades_error;
            if (FAILED(lpD3DRM->SetDefaultTextureColors(64)))
                goto shades_error;
            if (FAILED(lpD3DRM->SetDefaultTextureShades(32)))
                goto shades_error;
            break;
        case 24:
        case 32:
            if (FAILED(gInfo.dev->SetShades(64)))
                goto shades_error;
            if (FAILED(lpD3DRM->SetDefaultTextureColors(64)))
                goto shades_error;
            if (FAILED(lpD3DRM->SetDefaultTextureShades(256)))
                goto shades_error;
            break;
    }
    return TRUE;
shades_error:
	_ASSERT(0);
    return FALSE;
}

// Clear the viewport, render the next frame, and update the window.
BOOL RenderLoop() 
{
    HRESULT rval;
   
    // Tick the scene.
    rval = gInfo.scene->Move(D3DVAL(1.0));
    if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
    
    // Clear the viewport.
    rval = gInfo.view->Clear();
    if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
   
    // Render the scene to the viewport.
    rval = gInfo.view->Render(gInfo.scene);
    if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }

	if (RADAR)
	{
		rval = gInfo.radar->Clear();
		if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
		rval = gInfo.radar->Render(gInfo.scene);
		if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
	}
    
    // Update the window.
    rval = gInfo.dev->Update();
    if (rval != D3DRM_OK) { _ASSERT(0); return FALSE; }
    return TRUE;
}

// Calls the functions that create the frames, lights, mesh, and
// texture. Releases all interfaces on completion.
BOOL MyScene(LPDIRECT3DRMDEVICE dev, LPDIRECT3DRMVIEWPORT view, LPDIRECT3DRMFRAME lpScene, LPDIRECT3DRMFRAME lpCam) 
{
	int count=1;

	// Background Color
	int r, g, b;
	r = GetPrivateProfileInt("Main", "bgR", 25, ini);
	g = GetPrivateProfileInt("Main", "bgG", 25, ini);
	b = GetPrivateProfileInt("Main", "bgB", 25, ini);
	lpScene->SetSceneBackgroundRGB(D3DDivide(r, 255), D3DDivide(g, 255), D3DDivide(b, 255));

	// Omni Light
	LPDIRECT3DRMLIGHT olight;
	r = GetPrivateProfileInt("Main", "OmniR", 75, ini);
	g = GetPrivateProfileInt("Main", "OmniG", 75, ini);
	b = GetPrivateProfileInt("Main", "OmniB", 0, ini);
	lpD3DRM->CreateLightRGB(D3DRMLIGHT_AMBIENT, D3DDivide(r, 255), D3DDivide(g, 255), D3DDivide(b, 255), &olight);

	LPDIRECT3DRMFRAME olightframe;
	lpD3DRM->CreateFrame(lpScene, &olightframe);
	olightframe->AddLight(olight);
	olight->Release();
	olight=0;
	olightframe->Release();
	olightframe=0;
	
	// Directional Light
	r = GetPrivateProfileInt("Main", "DirR", 255, ini);
	g = GetPrivateProfileInt("Main", "DirG", 255, ini);
	b = GetPrivateProfileInt("Main", "DirB", 255, ini);
	lpD3DRM->CreateLightRGB(D3DRMLIGHT_DIRECTIONAL, D3DDivide(r, 255), D3DDivide(g, 255), D3DDivide(b, 255), &dlight);
	LPDIRECT3DRMFRAME dlightframe;
	lpD3DRM->CreateFrame(lpScene, &dlightframe);
	dlightframe->SetOrientation(lpScene, D3DVALUE(0), D3DVALUE(-1), D3DVALUE(1), 
										 D3DVALUE(0), D3DVALUE(1), D3DVALUE(1));
	dlightframe->AddLight(dlight);
	dlightframe->Release();
	dlightframe=0;

	// Ground
	GROUND = GetPrivateProfileInt("Main", "Ground", 1, ini);
	SHADOWS = GetPrivateProfileInt("Main", "Shadows", 1, ini);

	if (GROUND)
	{
		LPDIRECT3DRMMESH ground;
		D3DRMGROUPINDEX group;
		lpD3DRM->CreateMesh(&ground);
		ground->AddGroup( 24, 6, 4, vertorder, &group);
		SetVertexList(ground, group, 1000, 1, 1000);
		ground->SetGroupColorRGB(group, D3DVALUE(1), D3DVALUE(1), D3DVALUE(1));

		// Ground Texture
		LPDIRECT3DRMTEXTURE texture;
		char bmppath[MAX_PATH] = "";
		GetPrivateProfileString("Main", "GroundBmp", "", bmppath, MAX_PATH, ini);
		HBITMAP bmp = (HBITMAP)LoadImage(NULL, bmppath, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (bmp)
		{
			RECT rect;
			rect.top = 0;
			rect.left = 0;
			rect.right = GetPrivateProfileInt("Main", "GroundBmpWidth", 100, ini);
			rect.bottom = GetPrivateProfileInt("Main", "GroundBmpHeight", 100, ini);
			AddMyTexture(NULL, rect, ground, &texture, bmp, 0, GROUND_DEPTH);
			DeleteObject(bmp);

			LPDIRECT3DRMWRAP wrap;
			MakeMyWrap(ground, &wrap);
		}
		
		// Ground Frame
		LPDIRECT3DRMFRAME groundframe;
		lpD3DRM->CreateFrame(lpScene, &groundframe);
		groundframe->SetPosition(lpScene, D3DVALUE(0), D3DVALUE(-1), D3DVALUE(0));
		groundframe->AddVisual(ground);
		ground->Release();
		groundframe->Release();
	}

	// LaunchBoxes
	for (count=1; count; count++)
	{
		char temp[15] = "";
		int x, y, z, rx, ry, rz, t, ix, iy;
		char path[MAX_PATH] = "";
		HBITMAP bmp = NULL;

		sprintf(temp, "LaunchBox%d", count);

		x = GetPrivateProfileInt(temp, "X", 696969, ini);
			if (x == 696969) break;
		y = GetPrivateProfileInt(temp, "Y", 696969, ini);
			if (y == 696969) break;
		z = GetPrivateProfileInt(temp, "Z", 696969, ini);
			if (z == 696969) break;
		
		rx = GetPrivateProfileInt(temp, "RX", 0, ini);
		ry = GetPrivateProfileInt(temp, "RY", 0, ini);
		rz = GetPrivateProfileInt(temp, "RZ", 0, ini);

		t = GetPrivateProfileInt(temp, "Transparent", 1, ini);
		r = GetPrivateProfileInt(temp, "R", 255, ini);
		g = GetPrivateProfileInt(temp, "G", 255, ini);
		b = GetPrivateProfileInt(temp, "B", 255, ini);
		
		GetPrivateProfileString(temp, "Icon", "", path, 256, ini);
		if (strlen(path)) bmp = (HBITMAP)LoadImage(NULL, path, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (bmp)
		{
			ix = GetPrivateProfileInt(temp, "IconWidth", 696969, ini);
				if (ix == 696969) break;
			iy = GetPrivateProfileInt(temp, "IconHeight", 696969, ini);
				if (iy == 696969) break;
		}
		
		memset(&path, 0, sizeof(path));
		GetPrivateProfileString(temp, "Path", "", path, 256, ini);
			if (!strlen(path)) break;

		if (!bmp) 
		{
			HICON hIcon = ExtractIcon (hInstance, path, 0);
				if (!hIcon) continue;

			bmp = BitmapFromIcon (hIcon);
			DestroyIcon (hIcon);
			ix = 32;
			iy = 32;
		}

		AddLaunchBox(x,y,z,rx,ry,rz,r,g,b,t,bmp,ix,iy,path);
	}

	for (count=1; count; count++)
	{
		char temp[15] = "";
		int x, y, z, rx, ry, rz, t, width, height;
		HBITMAP bmp = NULL;
		char path[MAX_PATH] = "";

		sprintf(temp, "Billboard%d", count);

		x = GetPrivateProfileInt(temp, "X", 696969, ini);
			if (x == 696969) break;
		y = GetPrivateProfileInt(temp, "Y", 696969, ini);
			if (y == 696969) break;
		z = GetPrivateProfileInt(temp, "Z", 696969, ini);
			if (z == 696969) break;
		
		rx = GetPrivateProfileInt(temp, "RX", 0, ini);
		ry = GetPrivateProfileInt(temp, "RY", 0, ini);
		rz = GetPrivateProfileInt(temp, "RZ", 0, ini);

		t = GetPrivateProfileInt(temp, "Transparent", 1, ini);
		
		GetPrivateProfileString(temp, "Bitmap", "", path, 256, ini);
		if (strlen(path)) bmp = (HBITMAP)LoadImage(NULL, path, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
		if (bmp)
		{
			width = GetPrivateProfileInt(temp, "BitmapWidth", 696969, ini);
				if (width == 696969) break;
			height = GetPrivateProfileInt(temp, "BitmapHeight", 696969, ini);
				if (height == 696969) break;
		}
		else continue;
		
		AddBillboard(x,y,z,rx,ry,rz,t,bmp,width,height);
	}

	MoveCamera(camx, camy, camz);

    return TRUE;
}

// Creates and applies wrap for texture.
void MakeMyWrap(LPDIRECT3DRMMESH mesh, LPDIRECT3DRMWRAP * lpWrap)
{
    D3DVALUE miny, maxy, height; 
	D3DRMBOX box;

    mesh->GetBox(&box);
    maxy = box.max.y; 
	miny = box.min.y; 
	height = maxy - miny;

    lpD3DRM->CreateWrap(D3DRMWRAP_FLAT, NULL,
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
        D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(.5), D3DVAL(.5),
        lpWrap);
    (*lpWrap)->Apply((LPDIRECT3DRMOBJECT)mesh);
}

// Creates and applies wrap for texture.
void AddMyTexture(HWND hwnd, RECT r, LPDIRECT3DRMMESH lpMesh, 
    LPDIRECT3DRMTEXTURE * lplpTex, HBITMAP bmp, int trans, int DEPTH) 
{
	LPDIRECTDRAWSURFACE surf;
	DDSURFACEDESC desc;
	
	memset( &desc, 0, sizeof(desc) );
	desc.dwSize = sizeof(desc);
	desc.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH;
	desc.dwWidth = DEPTH;
	desc.dwHeight = DEPTH;
	desc.ddsCaps.dwCaps = DDSCAPS_TEXTURE | DDSCAPS_SYSTEMMEMORY;
	HRESULT res = lpDD->CreateSurface(&desc, &surf, NULL);
	if (res == DD_OK)
	{
		if (!bmp)
		{
			SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
			Sleep(500);
		}

		HDC hdc;
		surf->GetDC(&hdc);
		HDC buf;

		if (bmp)
		{
			buf = CreateCompatibleDC(NULL);
		}
		else
		{
			bmp  = CreateCompatibleBitmap(hdc, r.right, r.bottom);
			buf = GetDC(hwnd);
		}

		SelectObject(buf, bmp);
		StretchBlt(hdc, 0, 0, DEPTH, DEPTH, buf, 0, 0, r.right, r.bottom, SRCCOPY);
		ReleaseDC(hwnd, buf);
		if (buf) DeleteDC(buf);
		surf->ReleaseDC(hdc);
		DeleteObject(bmp);
		SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
		SetForegroundWindow(hwndMain);
	}
	
	lpD3DRM->CreateTextureFromSurface(surf, lplpTex);

	// This is for transparency
	if (trans)
	{
		(*(lplpTex))->SetDecalTransparency(TRUE);
		(*(lplpTex))->SetDecalTransparentColor(0x00FF00FF);
	}
	else
	{
		(*(lplpTex))->SetDecalTransparency(FALSE);
	}

    lpMesh->SetGroupTexture(0, *lplpTex);
	lpMesh->SetGroupMapping(0, D3DRMMAP_PERSPCORRECT);

	LPDIRECT3DRMMATERIAL mat;
	lpD3DRM->CreateMaterial(15, &mat);
	lpMesh->SetGroupMaterial(0, mat);
	mat->Release();
	mat=0;

	surf->Release();
}

// Release all D3DRM objects and set the bQuit flag.
void CleanUp(void) 
{
    gInfo.scene->Release(); gInfo.camera->Release();
    gInfo.view->Release(); gInfo.dev->Release();
    lpD3DRM->Release(); lpDDClipper->Release();
	lpDD->Release();
	dlight->Release();
	
	if (RADAR)
	{
		gInfo.becamera->Release();
		gInfo.radar->Release();
	}

    gInfo.bInit = FALSE; gInfo.bQuit = TRUE;
} 

void MoveCamera(D3DVALUE x, D3DVALUE y, D3DVALUE z)
{
	(FIRST)? zorder=1 : zorder=0;
	gInfo.camera->SetPosition(gInfo.camera, x, y, z);
	if (RADAR) gInfo.becamera->SetPosition(gInfo.becamera, x, z, 0);
	RenderLoop();
}

void RotateCamera(D3DVALUE x, D3DVALUE y, D3DVALUE z, D3DVALUE amount, BOOL FLAG)
{
	zorder=0;
	gInfo.camera->AddRotation(D3DRMCOMBINE_BEFORE, x, y, z, amount);
	if (RADAR && FLAG) gInfo.becamera->AddRotation(D3DRMCOMBINE_BEFORE, 0, 0, y, -amount);
	RenderLoop();
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	DWORD wsex = GetWindowLong(hwnd, GWL_EXSTYLE);
	DWORD ws = GetWindowLong(hwnd, GWL_STYLE);
	
	if (IsIconic(hwnd)) ShowWindow(hwnd, SW_SHOWNORMAL);

	if ((ws & WS_VISIBLE) && !(wsex & WS_EX_TOOLWINDOW) && (ws & WS_CAPTION) && !(ws & WS_CHILD) && GetWindowLong(hwnd, GWL_USERDATA) != magicDWord)
	{
		ShowWindow(hwnd, SW_MINIMIZE);
		ShowWindow(hwnd, SW_HIDE);
	}

	return TRUE;
}

void DeleteWindow(d3window* d)
{
	d->frame->DeleteVisual(d->mesh);
	if (GROUND && SHADOWS) d->frame->DeleteVisual(d->shadow);
	d->frame->Release();
	d->hwnd = 0;
	d->mesh->Release();
	d->mesh = 0;
	if (GROUND && SHADOWS)
	{
		d->shadow->Release();
		d->shadow = 0;
	}
	
	d3window* p = d3winlist;
	while (p)
	{
		if (p->next == d) break;
		p=p->next;
	}

	if (d == d3winlist)
	{
		if (d->next)
		{
			d3winlist = d3winlist->next;
		}
		else
		{
			d3winlist = 0;
			d3winlist->next = 0;
		}
	}
	else if (!d->next)
	{
		p->next = 0;
	}
	else
	{
		p->next = d->next;
	}

	d->next = 0;
	d = 0;
	RenderLoop();
}

void AddWindow(d3window* d)
{
	if (d3winlist)
	{
		d3window* p = d3winlist;
		while (p->next) p = p->next;
		d->next = 0;
		p->next = d;
	}
	else
	{
		d3winlist = (d3window*)malloc(sizeof(d3window));
		d3winlist = d;
		d3winlist->next = 0;
	}
}

void AddLaunchBox(int x, int y, int z, int rx, int ry, int rz, int r, int g, int b, int trans, HBITMAP bmp, int ix, int iy, char* path)
{
	d3window* add = (d3window*)malloc(sizeof(d3window));

	// Mesh
	lpD3DRM->CreateMesh(&add->mesh);
	add->mesh->AddGroup( 24, 6, 4, vertorder, &add->group);
	SetVertexList(add->mesh, add->group, 1, 1, 1);
	add->mesh->SetGroupColorRGB(add->group, D3DDivide(r, 255), D3DDivide(g, 255), D3DDivide(b, 255));
	
	if (bmp)
	{
		// Texture
		LPDIRECT3DRMTEXTURE texture;
		RECT rect;
		rect.top = 0;
		rect.left = 0;
		rect.right = ix;
		rect.bottom = iy;
		AddMyTexture(NULL, rect, add->mesh, &texture, bmp, trans, ICON_DEPTH);
		DeleteObject(bmp);
	}
				
	// Mesh Frame
	lpD3DRM->CreateFrame(gInfo.scene, &add->frame);
	add->frame->SetPosition(gInfo.scene, D3DVALUE(x), D3DVALUE(y), D3DVALUE(z));
	add->frame->AddVisual(add->mesh);
			
	if (GROUND && SHADOWS)
	{
		// Shadow
		lpD3DRM->CreateShadow(add->mesh, dlight,
							D3DVALUE(0), D3DVALUE(.05), D3DVALUE(0),
							D3DVALUE(0), D3DVALUE(1), D3DVALUE(0),
							&add->shadow);
		add->frame->AddVisual(add->shadow);
	}

	if (rx || ry || rz) add->frame->SetRotation(gInfo.scene, D3DVALUE(rx), D3DVALUE(ry), D3DVALUE(rz), D3DVALUE(.1));

	add->hwnd = 0;
	strcpy(add->path, path);

	AddWindow(add);
}

void AddBillboard(int x, int y, int z, int rx, int ry, int rz, int trans, HBITMAP bmp, int width, int height)
{
	d3window* add = (d3window*)malloc(sizeof(d3window));

	// Mesh
	lpD3DRM->CreateMesh(&add->mesh);
	add->mesh->AddGroup( 24, 6, 4, vertorder, &add->group);
	SetVertexList(add->mesh, add->group, width, height, 1);
	add->mesh->Scale(D3DVALUE(.01), D3DVALUE(.01), D3DVALUE(1));
	add->mesh->SetGroupColorRGB(add->group, D3DVALUE(1), D3DVALUE(1), D3DVALUE(1));
	
	if (bmp)
	{
		// Texture
		LPDIRECT3DRMTEXTURE texture;
		RECT rect;
		rect.top = 0;
		rect.left = 0;
		rect.right = width;
		rect.bottom = height;
		AddMyTexture(NULL, rect, add->mesh, &texture, bmp, trans, ICON_DEPTH);
		DeleteObject(bmp);
	}
	else return;
				
	// Mesh Frame
	lpD3DRM->CreateFrame(gInfo.scene, &add->frame);
	add->frame->SetPosition(gInfo.scene, D3DVALUE(x), D3DVALUE(y), D3DVALUE(z));
	add->frame->AddVisual(add->mesh);
			
	if (GROUND && SHADOWS)
	{
		// Shadow
		lpD3DRM->CreateShadow(add->mesh, dlight,
							D3DVALUE(0), D3DVALUE(.05), D3DVALUE(0),
							D3DVALUE(0), D3DVALUE(1), D3DVALUE(0),
							&add->shadow);
		add->frame->AddVisual(add->shadow);
	}

	if (rx || ry || rz) add->frame->SetRotation(gInfo.scene, D3DVALUE(rx), D3DVALUE(ry), D3DVALUE(rz), D3DVALUE(.1));

	add->hwnd = 0;
	
	AddWindow(add);
}

// This is from Litestep Source Code
HBITMAP BitmapFromIcon (HICON hIcon)
{
	ICONINFO info;

	if (GetIconInfo (hIcon, &info))
	{
		HDC		dc;
		HBITMAP	hBitmap;
		HBRUSH	hBrush;
		BITMAP	bitmap;

		dc = CreateCompatibleDC (NULL);

		GetObject (info.hbmColor, sizeof (BITMAP), &bitmap);
		hBitmap = CreateBitmapIndirect (&bitmap);

		SelectObject (dc, hBitmap);

		hBrush = CreateSolidBrush (RGB (255,0,255));
		DrawIconEx (dc, 0, 0, hIcon, 0, 0, 0, hBrush, DI_NORMAL);
		DeleteObject (hBrush);

		DeleteObject (info.hbmMask);
		DeleteObject (info.hbmColor);
		DeleteDC (dc);
		return hBitmap;
	}

	return NULL;
}

void SetHotSpot(int num)
{
	char section[15] = "";
	char buffer[256] = "";

	gInfo.camera->GetPosition(gInfo.scene, &HotSpot[num].pos);
	gInfo.camera->GetOrientation(gInfo.scene, &HotSpot[num].z, &HotSpot[num].y);

	sprintf(section, "HotSpot%d", num);
	sprintf(buffer, "X=%.2f%cY=%.2f%cZ=%.2f%cZX=%.2f%cZY=%.2f%cZZ=%.2f%cYX=%.2f%cYY=%.2f%cYZ=%.2f%c", 
					 HotSpot[num].pos.x, '\0', 
					 HotSpot[num].pos.y, '\0', 
					 HotSpot[num].pos.z, '\0', 
					 HotSpot[num].z.x, '\0', 
					 HotSpot[num].z.y, '\0', 
					 HotSpot[num].z.z, '\0', 
					 HotSpot[num].y.x, '\0', 
					 HotSpot[num].y.y, '\0', 
					 HotSpot[num].y.z, '\0');
	WritePrivateProfileSection(section, buffer, ini);
	HotSpot[num].set = 62978;
}

void MoveToHotSpot(int num)
{
	zorder=0;

	if (HotSpot[num].set != 62978)
	{
		char section[15] = "";
		char temp[256] = "";
		sprintf(section, "HotSpot%d", num);

		GetPrivateProfileString(section, "X", "0.00", temp, 256, ini);
			HotSpot[num].pos.x = (float)atof(temp);
		GetPrivateProfileString(section, "Y", "0.00", temp, 256, ini);
			HotSpot[num].pos.y = (float)atof(temp);
		GetPrivateProfileString(section, "Z", "0.00", temp, 256, ini);
			HotSpot[num].pos.z = (float)atof(temp);
		GetPrivateProfileString(section, "ZX", "0.00", temp, 256, ini);
			HotSpot[num].z.x = (float)atof(temp);
		GetPrivateProfileString(section, "ZY", "0.00", temp, 256, ini);
			HotSpot[num].z.y = (float)atof(temp);
		GetPrivateProfileString(section, "ZZ", "0.00", temp, 256, ini);
			HotSpot[num].z.z = (float)atof(temp);
		GetPrivateProfileString(section, "YX", "0.00", temp, 256, ini);
			HotSpot[num].y.x = (float)atof(temp);
		GetPrivateProfileString(section, "YY", "0.00", temp, 256, ini);
			HotSpot[num].y.y = (float)atof(temp);
		GetPrivateProfileString(section, "YZ", "0.00", temp, 256, ini);
			HotSpot[num].y.z = (float)atof(temp);

		HotSpot[num].set = 62978;
	}

	D3DVECTOR pos, ry, rz;
	D3DVALUE x, y, z, rrx=0, rry=0, rrz=0;
	int inc = 5;
	gInfo.camera->GetPosition(gInfo.scene, &pos);
	gInfo.camera->GetOrientation(gInfo.scene, &rz, &ry);

	x = D3DDivide(HotSpot[num].pos.x - pos.x, inc);
	y = D3DDivide(HotSpot[num].pos.y - pos.y, inc);
	z = D3DDivide(HotSpot[num].pos.z - pos.z, inc);
	

	//gInfo.camera->SetRotation(gInfo.scene, 0, 1, 0, D3DDivide(HotSpot[num].z.x - rz.x, inc));
	//for (int c=0; c<inc; c++) RenderLoop();
	//while (abs((int)(HotSpot[num].z.x - rz.x)) > 5) { RenderLoop(); gInfo.camera->GetOrientation(gInfo.scene, &rz, &ry); }
	//gInfo.camera->SetRotation(gInfo.scene, 0, 0, 0, FALSE);

	gInfo.camera->SetVelocity(gInfo.scene, x, y, z, TRUE);
	if (RADAR) gInfo.becamera->SetVelocity(gInfo.scene, x, 0, z, TRUE);
	//gInfo.camera->SetRotation(gInfo.scene, 1, 0, 0, D3DDivide(HotSpot[num].z.x, inc));
	
	//if (HotSpot[num].z.x <= rz.x)
	//	gInfo.camera->SetRotation(gInfo.scene, 0, 1, 0, D3DDivide(HotSpot[num].z.x - rz.x, inc));
	//else
	//	gInfo.camera->SetRotation(gInfo.scene, 0, 1, 0, -D3DDivide(HotSpot[num].z.x - rz.x, inc));
	
	//gInfo.camera->SetRotation(gInfo.scene, 0, 0, 1, D3DDivide(HotSpot[num].z.z, inc));
	gInfo.camera->SetOrientation(gInfo.scene, HotSpot[num].z.x, HotSpot[num].z.y, HotSpot[num].z.z, HotSpot[num].y.x, HotSpot[num].y.y, HotSpot[num].y.z);
	if (RADAR) gInfo.becamera->SetOrientation(gInfo.scene, 0, 0, 0, HotSpot[num].y.x, HotSpot[num].y.y, 0);
		
	for (int w=0; w<inc; w++) RenderLoop();
	
	gInfo.camera->SetVelocity(gInfo.scene, 0, 0, 0, TRUE);
	if (RADAR) gInfo.becamera->SetVelocity(gInfo.scene, 0, 0, 0, TRUE);
}

void DoCommand(char* command)
{
	int rep=0, count=0;

	if (!_strnicmp(command, "logout", 6))
	{
		if (MessageBox(hwndMain, "Are you sure you would like to logoff?", "Logoff Warning", MB_SYSTEMMODAL | MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
			ExitWindowsEx(EWX_LOGOFF, 0);
	}
	else if (!_strnicmp(command, "shutdown", 8))
	{
		if (MessageBox(hwndMain, "Are you sure you would like to shut down?", "Shut Down Warning", MB_SYSTEMMODAL | MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
			ExitWindowsEx(EWX_POWEROFF, 0);
	}
	else if (!_strnicmp(command, "reboot", 8))
	{
		if (MessageBox(hwndMain, "Are you sure you would like to reboot?", "Reboot Warning", MB_SYSTEMMODAL | MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
			ExitWindowsEx(EWX_REBOOT, 0);
	}
	else if (!_strnicmp(command, "reload", 8))
	{
		// reload
	}
	else if (!_strnicmp(command, "quit", 4))
	{
		if (MessageBox(hwndMain, "Are you sure you would like to quit?", "Quit Warning", MB_SYSTEMMODAL | MB_YESNO | MB_ICONEXCLAMATION) == IDYES)
			DestroyWindow(hwndMain);
	}
	else if (!_strnicmp(command, "configure", 9))
	{
		StartConfiguration();
	}
	else if (!_strnicmp(command, "left", 4))
	{
		if (strlen(command) > 4) rep = atoi(command+5);
		for(count=0; count < rep; count++) MoveCamera(-step, 0, 0);
	}
	else if (!_strnicmp(command, "right", 5))
	{
		if (strlen(command) > 5) rep = atoi(command+6);
		for (count=0; count < rep; count++) MoveCamera(step, 0, 0);
	}
	else if (!_strnicmp(command, "up", 2))
	{
		if (strlen(command) > 2) rep = atoi(command+3);
		for(count=0; count < rep; count++) MoveCamera(0, step, 0);
	}
	else if (!_strnicmp(command, "down", 4))
	{
		if (strlen(command) > 4) rep = atoi(command+5);
		for (count=0; count < rep; count++) MoveCamera(0, -step, 0);
	}
	else if (!_strnicmp(command, "forward", 7))
	{
		if (strlen(command) > 7) rep = atoi(command+8);
		for (count=0; count < rep; count++) MoveCamera(0, 0, step);
	}
	else if (!_strnicmp(command, "back", 4))
	{
		if (strlen(command) > 4) rep = atoi(command+5);
		for (count=0; count < rep; count++) MoveCamera(0, 0, -step);
	}
	else if (!_strnicmp(command, "look", 4))
	{
		command += 5;

		if (!_strnicmp(command, "up", 2))
		{
			if (strlen(command) > 2) rep = atoi(command+3);
			for (count=0; count < rep; count++) RotateCamera(1, 0, 0, D3DVAL(-.1), FALSE);
		}
		else if (!_strnicmp(command, "down", 4))
		{
			if (strlen(command) > 4) rep = atoi(command+5);
			for (count=0; count < rep; count++) RotateCamera(1, 0, 0, D3DVAL(.1), FALSE);
		}
		else if (!_strnicmp(command, "left", 4))
		{
			if (strlen(command) > 4) rep = atoi(command+5);
			for (count=0; count < rep; count++) RotateCamera(0, 1, 0, D3DVAL(-.1), TRUE);
		}
		else if (!_strnicmp(command, "right", 5))
		{
			if (strlen(command) > 5) rep = atoi(command+6);
			for (count=0; count < rep; count++) RotateCamera(0, 1, 0, D3DVAL(.1), TRUE);
		}
	}
	else if (!_strnicmp(command, "center", 6))
	{
		zorder=0;
		gInfo.camera->AddRotation(D3DRMCOMBINE_REPLACE, D3DVAL(0),D3DVAL(0),D3DVAL(0),D3DVAL(0));
		gInfo.camera->SetPosition(gInfo.scene, camx, camy, camz);
		if (RADAR) gInfo.becamera->SetPosition(gInfo.scene, camx, camy, 100);
		RenderLoop();
	}
	else if (!_strnicmp(command, "break", 5))
	{
		SetForegroundWindow(hwndMain);
		SetFocus(hwndMain);
	}
	else if (!_strnicmp(command, "hotspot", 7))
	{
		command+=8;

		switch (atoi(command))
		{
			case 1: MoveToHotSpot(0); break;
			case 2: MoveToHotSpot(1); break;
			case 3: MoveToHotSpot(2); break;
			case 4: MoveToHotSpot(3); break;
			case 5: MoveToHotSpot(4); break;
		}
	}
	else if (!_strnicmp(command, "anim", 4))
	{
		char temp[10] = "";
		command+=5;

		if (!_strnicmp(command, "on", 2)) ANIMATION=TRUE;
		else if (!_strnicmp(command, "off", 3)) ANIMATION=FALSE;
		
		sprintf(temp, "%d", ANIMATION);
		WritePrivateProfileString("Main", "Animation", temp, ini);
	}
}

HICON GetWindowIcon(HWND Hwnd)
{
	HICON a;

    SendMessageTimeout(Hwnd, WM_GETICON, 1, 0, 0, 1000, (unsigned long*)&a);
    if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICON);
    if (!a) SendMessageTimeout(Hwnd, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long*)&a);
    if (!a) SendMessageTimeout(Hwnd, WM_GETICON, 0, 0, 0, 1000, (unsigned long*)&a);
    if (!a) a = (HICON)GetClassLong(Hwnd, GCL_HICONSM);

	return a;
}

void StartConfiguration()
{
	LPDIRECT3DRMVIEWPORT config;
	LPDIRECT3DRMFRAME frame;
	LPDIRECT3DRMMESH mesh;
	D3DRMGROUPINDEX group;

	lpD3DRM->CreateViewport(gInfo.dev, gInfo.camera, ScreenX/2-250, ScreenY/2-250, 500, 500, &config);
	lpD3DRM->CreateMesh(&mesh);
	mesh->AddGroup( 24, 6, 4, vertorder, &group);
	SetVertexList(mesh, group, 20, 20, 20);
	mesh->SetGroupColorRGB(group, D3DVAL(1), D3DVAL(1), D3DVAL(1));
	lpD3DRM->CreateFrame(gInfo.scene, &frame);
	//frame->SetPosition(frame, D3DVAL(-10), D3DVAL(-8), D3DVAL(0));
	frame->SetRotation(NULL, D3DVAL(0), D3DVAL(1), D3DVAL(0), D3DVAL(.25));
	frame->AddVisual(mesh);

	for (int x=0; x<30; x++)
	{
		frame->Move(D3DVAL(1.0));
		config->Clear();
		config->Render(frame);
		gInfo.dev->Update();
	}

	config->Release();
	frame->DeleteVisual(mesh);
	frame->Release();
	mesh->Release();
}

int CheckForJoystick()
{
	JOYINFO joyinfo; 
	UINT wNumDevs, wDeviceID; 
	BOOL bDev1Attached, bDev2Attached; 
 
    if((wNumDevs = joyGetNumDevs()) == 0) 
        return 1;

    bDev1Attached = joyGetPos(JOYSTICKID1,&joyinfo) != JOYERR_UNPLUGGED; 
    bDev2Attached = wNumDevs == 2 && joyGetPos(JOYSTICKID2,&joyinfo) != JOYERR_UNPLUGGED; 

    if(bDev1Attached || bDev2Attached)   // decide which joystick to use 
        wDeviceID = bDev1Attached ? JOYSTICKID1 : JOYSTICKID2; 
    else 
        return 1; 

	if(joySetCapture(hwndMain, wDeviceID, NULL, FALSE)) 
    { 
        MessageBeep(MB_ICONEXCLAMATION);
        //MessageBox(hwndMain, "Couldn't capture the joystick.", NULL, MB_OK | MB_ICONEXCLAMATION);
    } 

	return 0;
}

void SetVertexList(LPDIRECT3DRMMESH mesh, D3DRMGROUPINDEX group, int w, int h, int d)
{
	D3DVALUE x = D3DDivide(w, 2);
	D3DVALUE y = D3DDivide(h, 2);
	D3DVALUE z = D3DDivide(d, 2);

	D3DRMVERTEX vertexlist[]=
	{
		// left face
		VERTEX( -x,-y,-z, -1,0,0,  1,1 ), // vertex 0
		VERTEX( -x,-y,z, -1,0,0,  0,1 ),
		VERTEX( -x,y,z, -1,0,0,  0,0 ),
		VERTEX( -x,y,-z, -1,0,0,  1,0 ),
		// right face
		VERTEX( x,-y,-z,  1,0,0,  0,1 ),
		VERTEX( x,y,-z,  1,0,0,  0,0 ),
		VERTEX( x,y,z,  1,0,0,  1,0 ), // vertex 6
		VERTEX( x,-y,z,  1,0,0,  1,1 ),
		// front face
		VERTEX( -x,-y,-z,  0,0,-1, 0,1), // vertex 8
		VERTEX( -x,y,-z,  0,0,-1, 0,0),
		VERTEX( x,y,-z,  0,0,-1, 1,0),
		VERTEX( x,-y,-z,  0,0,-1, 1,1),
		// back face
		VERTEX( -x,-y,z,  0,0,1,  1,1 ),
		VERTEX( x,-y,z,  0,0,1,  0,1 ),
		VERTEX( x,y,z,  0,0,1,  0,0 ), // vertex 14
		VERTEX( -x,y,z,  0,0,1,  1,0 ),
		// top face
		VERTEX( -x,y,-z,  0,1,0,  0,1 ),
		VERTEX( -x,y,z,  0,1,0,  0,0 ),
		VERTEX( x,y,z,  0,1,0,  1,0 ), // vertex 18
		VERTEX( x,y,-z,  0,1,0,  1,1 ),
		// bottom face
		VERTEX( -x,-y,-z,  0,-1,0, 1,1 ), // vertex 20
		VERTEX( x,-y,-z,  0,-1,0, 0,1 ),
		VERTEX( x,-y,z,  0,-1,0, 0,0 ),
		VERTEX( -x,-y,z,  0,-1,0, 1,0 ),
	};	

	mesh->SetVertices( group, 0, 24, vertexlist );
}
