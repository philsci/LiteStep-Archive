#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include <time.h>
#include "..\\d3.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

__declspec( dllexport ) int InitModule(HWND hwnd, HINSTANCE dllInst, char* ConfigFile);
__declspec( dllexport ) void QuitModule();

char* szAppName = "D3CommandWindow";
char EditText[256] = "NO TEXT";
char ini[MAX_PATH] = "";
HWND hMainWnd;
HWND parent;
HWND TimeWnd, CommandWnd, TaskWnd;
HINSTANCE Instance;

int ScreenX, ScreenY;

int InitModule(HWND hwnd, HINSTANCE dllInst, char* ConfigFile)
{
	RECT r;
	char temp[256] = "";

	Instance = dllInst;
	parent = hwnd;
	strcpy(ini, ConfigFile);

	{    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = 0;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(hwnd,"Error registering window class",szAppName, MB_OK);
            return 0;
        }
    }

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	sprintf(temp, "- Screen Resolution: %dx%d", ScreenX, ScreenY);
	SetStatusText(temp);

	SetRect(&r, 0, 0, ScreenX, ScreenY-28);
	if (SystemParametersInfo(SPI_SETWORKAREA,0,(PVOID)&r,SPIF_SENDCHANGE))
	{
		SetStatusText("- Work area set");
	}
	else SetStatusText("- Error setting work area");

	hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName,
        WS_VISIBLE | WS_CHILD | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,                                   // window style
        0, ScreenY-25, ScreenX, 25,
		hwnd, NULL, dllInst, 0);

    if (!hMainWnd) 
    {						   
        SetStatusText("- Error creating main command window");
        return 0;
    }

	CommandWnd = CreateWindow("Edit", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL | ES_MULTILINE | ES_WANTRETURN, 5, 2, 200, 21, hMainWnd, NULL, dllInst, 0);
	if (!CommandWnd) SetStatusText("- Error creating command edit window");
	TimeWnd = CreateWindow("Edit", "", WS_VISIBLE | WS_CHILD | ES_READONLY, 955, 5, 65, 15, hMainWnd, NULL, dllInst, 0);
	if (!TimeWnd) SetStatusText("- Error creating command time window");

	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

	SetTimer(hMainWnd, 0, 100, NULL);

	return 1;
}

void QuitModule()
{
	KillTimer(hMainWnd, 0);
	DestroyWindow(hMainWnd);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, ScreenX, 25);
			RECT r;
			
			SelectObject(buf, bufbmp);

			GetClientRect(hwnd, &r);
			FillRect(buf, &r, GetStockObject(GRAY_BRUSH));

			BitBlt(hdc, 0, 0, ScreenX, 25, buf, 0, 0, SRCCOPY);

			EndPaint(hwnd, &ps);
			DeleteDC(buf);
			DeleteObject(bufbmp);
		}
		break;

		case WM_SETFOCUS:
		{
			HWND edit = FindWindowEx(hMainWnd, NULL, "Edit", NULL);
			SetFocus(edit);
			SendMessage(edit, EM_SETSEL, (WPARAM)0, (LPARAM)-1);
		}
		break;

		case WM_TIMER:
		{
			time_t tVal;
			struct tm *stVal;
			char Time[25] = "";;

			time(&tVal);
			stVal = localtime(&tVal);
			strftime(Time, sizeof(Time), "%I:%M %p", stVal);
			
			SetWindowText(TimeWnd, Time);
		}
		break;

		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case EN_UPDATE:
				{
					if ((HWND)lParam == CommandWnd)
					{
						HWND edit = (HWND)lParam;
						char NewEditText[256] = "";

						GetWindowText(edit, NewEditText, 256);
						if (!strcmp(NewEditText, EditText))
						{
							if (EditText[0] == '!')
							{
								PostMessage(parent, D3_DO, wParam, lParam);
							}
							else if (!_strnicmp(EditText, "http://", 7))
							{
								ShellExecute(NULL, "open", EditText, NULL, NULL, SW_SHOWNORMAL);
							}
							else
							{
								if (WinExec(EditText, SW_SHOWNORMAL) < 32)
								{
									char alias[MAX_PATH] = "";
									GetPrivateProfileString("Alias",  EditText, "", alias, MAX_PATH, ini);
									WinExec(alias, SW_SHOWNORMAL);
								}
							}
						}
						else strcpy(EditText, NewEditText);
					}
				}
				break;
			}
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wParam, lParam);
}