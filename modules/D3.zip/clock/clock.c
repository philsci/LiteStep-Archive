#include "..\\d3.h"
#include <time.h>

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

__declspec( dllexport ) int InitModule(HWND hwnd, HINSTANCE dllInst);
__declspec( dllexport ) void QuitModule();

char* szAppName = "D3ClockWindow";
HWND hMainWnd;
HWND parent;
HINSTANCE Instance;

int InitModule(HWND hwnd, HINSTANCE dllInst)
{
	Instance = dllInst;
	parent = hwnd;
			
	return 1;
}

void QuitModule()
{
}