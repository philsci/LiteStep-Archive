#include <windows.h>
#include <stdio.h>
#include "..\\d3.h"

LRESULT CALLBACK WndProc(HWND hwnd, int msg, WPARAM wParam, LPARAM lParam);

__declspec( dllexport ) HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam);
__declspec( dllexport ) void Quit();

HWND MainWnd, CommandWnd, TaskWnd;

// Trap keyboard messages
HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	//if (code < 0) return (HOOKPROC)CallNextHookEx(0, code, wParam, lParam);

	switch (code)
	{
		case HCBT_MINMAX:
		{
			if (LOWORD(lParam) == SW_MINIMIZE)
			{
				if (!MainWnd) MainWnd = FindWindow("D3", "D3");
				SendMessage(MainWnd, D3_MIN, wParam, 0);
				return (HOOKPROC)1;
			}
		}
		return 0;

		case HCBT_SYSCOMMAND:
		{
			if (wParam == SC_RESTORE)
			{
				if (!MainWnd) MainWnd = FindWindow("D3", "D3");
				SendMessage(MainWnd, D3_RESTORE, 0, 0);
			}
		}
		return 0;

		case HCBT_DESTROYWND:
		{
			if (!MainWnd) MainWnd = FindWindow("D3", "D3");
			SendMessage(MainWnd, D3_DESTROY, wParam, 0);
		}
		return 0;
	}

	return 0;
}

void Quit()
{
  //int x;
 // for (x=0; list[x] && x<1000; x++)
  //{
	//  if (IsWindow(list[x])) SetWindowLong(list[x], GWL_WNDPROC, (LONG)listproc[x]);
  //}
}