Text Edit (v2.1l) by | l e a f - r & d | (info@leafrd.cjb.net) 10th Apr 2001
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

This is a slightly modified version following the release of the source code
by Tony Chang.

The only modification that has been made is to add one new escape code to those
recognised by this module. It is a very important change, as will become evident.

Issue in v2.0
=-=-=-=-=-=-=

In newer versions of LiteStep 0.24.6, the parser strips any text following comment
markers (;) out when loading files into memory. This breaks operations like:

	!textreplace "myfile.txt" "(.*) ;MYMARKER$" ";MY MARKER \1"

Essentially this becomes

	!textreplace "myfile.txt" "(.*)" ""

So white space is created throughout the file.

Solution in v2.1l
=-=-=-=-=-=-=-=-=

Added a new escape code \~ for ;

See the documentation given below for usage.


 | l e a f - r & d |
http://leafrd.cjb.net


Text Edit (v2.0) by WhiteShadow (changty@muohio.edu) on 09-30-00
*******************************************************************

This is a small module that can be used to edit text files.  It 
could be useful in allowing you to edit your step.rc file on the 
fly.  However, it could also be very dangerous if used on the wrong 
file.  NOTE:  Textedit v2.0 is a complete rewrite of Textedit and
many features have been removed or changed.

Installation:

	1. Copy textedit2.dll into your litestep folder
	2. Add the line 

		LoadModule c:\litestep\textedit2.dll

	   to your step.rc (with the appropriate drive letter and 
	   path)
	3. Recycle Litestep

Usage:

	Bang Commands
	-------------

	!textappend "filename" "text to be added"

	   Appends "text to be added" (minus the quotes) to filename.
	   Look below for various escape codes.


	!textdel "filename" "regular expression"

	   This will delete every line in "filename" that matches
	   the regular expression in quotes.  Regular expressions
	   are described below.


	!textreplace "filename" "regular expression" "replace string"

	   Files the lines that match the regular expression and
	   replaces it with replace string.  More explained below
	   in the regular expressions secion.


	Step.rc Options
	---------------

	TextDebug
	   If you have this line in your step.rc, lots of message boxes
	   will popup and help you debug problems using the module. 


	Escape Codes
	------------

	They backslash (\) character is used as an escape code. The
	following are valid escape sequences:

	\\	Backslash
	\"	Double quote
	\^	Replaces with a bang (!)
	\#	Replaces with a dollar sign ($) (Useful for evars.
		  for example \#litestepdir\# will become $litestepdir$)
	\1	Ignored and used in !textreplace for () matches
		  (explained below)

	Any other use of backslash will be ignored (and if TextDebug is
	in your step.rc, you will get an error message).


	Regular Expressions
	-------------------

	Ok, if you know what regular expressions are, you should still
	read this because only a handful of regex features are 
	implemented.  I'm using relib, a a slightly midified REGEXP 
	library by Henry Spencer to handle the regular expressions.
	Read the included relib-readme.txt for more details.

	The quick run down of supported features is the use of the
	following special characters:

	.  ?  *  +  [  ]  $  ^  (  )  |  \

	Ok, now to explain what all these are and what regular
	expressions are in general.

	The simplest regular expression is just a string.  For example,
	"a" would match all strings with the character a in it, "abc"
	would match all strings with abc in it.

	Now, the first special character is a period.  This is the wild
	card character.  So "a.b" would match any string that contained
	an 'a' followed by any character followed by a 'b'.  It would
	match "abb", "a1b", "ajhdakjs a b aslkjf", "a b", "extra a_b 
	extra", and so forth.

	The next special character is a ?.  This means that the previous
	character occurs zero or one time.  So "a.?b" would match 
	everything that "a.b" matched and everything that "ab" would
	match.

	* means that the previous character is repeated zero or more
	times.  This is pretty much a catch all.  So ".*" would match
	any string.

	+ matches the previous character one or more times.

	[]'s are used to enclose a group of characters to match.
	For example, "A[a-z]+Z" would match "AanczZ", "AaZ", or any set
	of lowercase letters enclosed by an 'A' and a 'Z'.  Note that
	because a + is used, "AZ" would not match while "A[a-z]*Z]"
	would match "AZ".  You can also negate what is encosed in
	brackets with the ^ character (so [^a-z] would mean not a
	lower case letter).

	$ and ^ are anchor characters.  $ means that the match has to
	occur at the end of the string and ^ means that the match has
	to occur and the beginning of the string.  For example, "test$"
	would match "this is a test" but would not match "test is a
	this".

	()'s are used to enclose a group.  For example, (AB)+ would
	match "AB", "ABAB", "ABABAB", etc.  This gives more flexibility
	for patters.

	The pipe is used as an "or" operator.  So "A|B" would match
	all strings with an upper case A or an upper case B.  Combine
	this with parenthesis and do things like "Z(A|B)+Z" to match
	"ZABABABZ".

	And finally the \ is used as an esacpe code so you can use
	the special characters in your matches.

	Ok, so if that didn't completely confuse you, try searching
	for some regular expression tutorials online.  Note that relib
	doesn't support all the neat regex stuff that perl does.


	TextReplace
	-----------

	Hmm, a couple notes about TextReplace.  In the replace field,
	you can use a couple special characters.  For example, & is
	replaced by the whole string.  So 

	!textreplace "file" "find" "&-found"

	would convert "find" to "find-found".  Or better yet,

	!textreplace "file" "^*Shortcut" "; &"

	would comment all *Shortcuts definied in file.

	Also, \1 matches with the inner-most, left-most parenthesis,
	\2 matches the second inner-most, left-most parenthesis, etc.
	So

	!textreplace "file" "(hello)(.*)(there)" "\3\2\1"

	would convert "hello test there" to "there test hello".

	Here's another example:

	!textreplace "file" "; *(*Shortcut.*)" "\1"

	This would uncomment all shortcuts.

History:

	v2.0 (09-30-00)
	-complete rewite of TextEdit.

	v1.41 (07-08-00)
	-I'm an idiot.  Fixed the error using ^" in textreplace.

	v1.4 (07-03-00)
	+Added !textcopyfile
	+Added TextCalculate

	v1.3 (04-30-00)
	-Changed !textadd to !textappend
	+Added !textinsert
	+Added !textreplace
	+Added !textcomment and !textsetcommentchar
	+Added TextNotCaseSensitive

	v1.2 (04-10-00)
	+Added * at end of strings
	+Added !textdelsingle

	v1.1 (04-04-00)
	+Added TextSubst

 	v1.0 (04-02-00)
	-initial release

Anyway, that's all, enjoy!
Feel free to send me comments or bugs.
WhiteShadow
