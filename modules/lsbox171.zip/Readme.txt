Lsbox release version 1.71

--------------
I. About LsBox
--------------
LsBox is a skinable easy to customize and 
resource-friendly alternative to the "normal" 
shortcutgroups for a number of applications like 
freefloating menues, messageboxes and 
configuration dialogs. 


----------------
II. Requirements
----------------
You will need a newer build to run LsBox
LsBox will now load under Win95 and WinNT 4

-----------------
III. Installation
-----------------
Just copy LsBox.dll to your LiteStep dir and add the following 
line to your step.rc: 

   Loadmodule C:\Litestep\LsBox.dll
(*assuming you have your LS stuff in C:\Litestep*)

----------
IV. Useage
----------
To actually use LsBox you have to have a .box 
file and a few gfx to use with it.
I include a example skin with every release, so you
can start right out of the box.
Modifying it shouldn't be a problem for you if 
you ever customised a theme for your use. 
The .Box file's syntax is much like the syntax of the 
Step.rc.

After having placed everything in the right directorys
and editing you can call
      
        !LsBoxCreate <path and filename of the .Box file>

Examples:
	!LsBoxCreate recycle.box
        Or
	!LsBoxCreate Lsbox\Shutdown.box

to create a box.

There are three ways to destroy a Box.......
The first one is to call !LsBoxDestroy without anything
from inside a Box. This Box will be promptly destroyed.
The second one is to call !LsBoxDestroy <Name of the Box to destoy>
from the outside. With LsXcommand for instance. The Box 
with the matching name will be destroyed.
And the last way is to call !LsBoxDestroy <Name of the Box to destroy>
from inside a Box.
You should be aware that the Box-names are handled case-sensitive.

--------------------------------------
V. Box File Options and Bang commands
--------------------------------------

  -LsBoxName <Name Of the Box>
   The name of the box is used to identify a box. It's the 
   window title shown in the taskbar and it is needed to 
   destroy a box from the outside 
   ( like calling !LsBoxDestroy from LsXcommand )
   and to destroy a Box from within an other Box.
 
  -LsBoxX <xpos>
   and 
  -LsBoxY <yPos>
   These can have negative values too.

  -LsBoxHeight <Height>
   and
  -LsBoxWidth <Width>
   Use these to override the bitmap width/height autodetection.
   there is no support for Stretch Skinning yet.

  -LsBoxBackGround <Image>
   Can be made transparent with great magic pink(tm)
   This also sets the Width&Height of the box.
  
  -LsBoxDRLeft,
  -LsBoxDRRight, 
  -LsBoxDRTop
   And
  -LsBoxDRBottom
   These set the dragable area of the box.

  -LsBoxSticky
   Shows the Box on all Desktops

  -LsBoxUnique
   This in a unique feature
   it makes a Box unique
   so there can be only one 
   unique box of a kind.

  -LsBoxRememberPosition
   This let the Box save it's Position on Destroy

  -LsBoxAlwaysOnTop
   This makes the box AlwaysOnTop

  -LsBoxPopupAtMousePos
   Thil will make the box pop up at your mouse pointer

  -!LsBoxShow <Name of the Box>
   And
  -!LsBoxHide <Name of the Box>
   Show and Hide a Box. This wil NOT unload the box and 
   is much faster than to recreate the box everytime.
   However this will permantly lock systemresources.

  -LsboxFont <Name of Font to display>
   Name Of the Font to Use  

  -LsboxFontSize <Size of Font>
   Size of the font in Pixel

  -LsboxFontColor <Colorvalue>
   Use RGB Values for this option
      
  -*Shortcut <Hint> <xPos> <yPos> <Normal> <Over> <Clicked> <Command(s)>
   Use these to toggle bangs. Use Magic Pink(tm) to 
   get transparent ones.
   don't use these to create dummys - use *image instead

  -*Image <xPos> <yPos> <image>
   Resource-friendly dummy images. These will be 
   combined with the background at creation-time.

  -*Text <xPos> <yPos> <Text to display>
   This will paint text to the background of the box. This works much 
   like the *Image command and uses no extra resources.

  -*Module <xPos> <yPos> <width> <height> <Wharfmodule to load>
   Brandnew Wharfmodule loading. Can be unstable at times and may cause
   memoryleaks. Only use this together with LsBoxUnique and don't try
   to load a wharfmodule twice.

-----------
VI. History
-----------
rel 1.71
    -fixed LsBox for Win95
    -Module paths should now be relative to the Litestep dir 

rel 1.7 
    -added native support for Wharfmodules
    -added native support for displaying Text
    -added !LsBoxShow and !LsBoxHide
    -Paths are now handled relative to the Litestep Path.
    -Trying to call !LsBoxCreate for an already created unique hidden 
     box will automatically call !LsBoxShow
    -LsBoxX and LsBoxY can now have negative values
    -fixed the all-tooltips-show-last-tooltip-text bug
    -removed the LsBoxstatistics bang - wasn't worth the trouble

rel 1.5
    -added failsave functions to prevent crashes caused by incorrect
     options set in the .box file.
    -evars in commands should work now
    -a box can now save its position to the .box file
    -LsBox should now work right with older Ls-Builds
    -minor compatibily fix with PureLs ;=)
     (changed initModuleEx return value to none-zero)
    -LsBox should now work right with pureLs
    -changed the way the Cfg pointer memory structure is created
    -removed some useless code
    -replaced window enumerating and box-destroy functions with
     recursive versions.
    -fixed a bug that caused crashes on !recycle in some cases
    -added a !LsBox_Statistics bang - This bang will give detailed 
     infos about Memory useage of the boxes that are currently running


rel 1.1
    -added hints to the shortcuts   
    -added LsBoxPopupAtMousePos by request
    -added LsBoxWidth and LsBoxHeight - 
      no support for Stretch Skinning, yet
    -removed old work-around code for pre-041600 builds
    -fixed my tokenize functions - delimeters should work now.
    -the windowclass "Lsboxclass" will now be unregistered at recycle

rel 1.0
    -Rewrote cfg-destroy mechanism
    -fixed the cfg leak

rel 0.98
    -Added LsBoxSticky
    -Added LsBoxUnique
    -Added LsBoxAlwaysOnTop
    -Added Destroy of other boxes from inside a box
    -Added Creation of a box from inside a box

rel 0.95
    -improved *image painting
    -rewrote *shortcut handeling

rel 0.9
    -first preview release

-------------------------
VII. working wharfmodules
-------------------------
lsCpuIT
Wharfanoid
Bounce
burnclk
