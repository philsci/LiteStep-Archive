//============================================================
//ckHotspots.dll v1.0 - bangs for CD tray actions
//------------------------------------------------------------
//Filename	: 	ckHotspots.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This is a really simple hotpots module that let you define hotspots
//	and what to do when you enter or leave the spot
//
//------------------------------------------------------------
/****************** v1.0		2000/10/28************/
//	First release
//
//	Step.rc config
//		-ckHotspotsTimeOut #
//			>define how frequent the module will check the mouse, the smaller the more frequent, (default: 100)
//		-*ckHotspot x y width height [action to perform when mouse enters] [action to perform when mouse leaves]
//			>x, y, width and height can be negative
//			>x, y specifies the left top hotspot box
//			>width and height specifies the width and height for the hotspot box.  If you specify either one of them to be 0
//			the box width or height will span to the whole screen.
//			>the next two action can be bang commands or a path to a program
//	
//
//	*Important: none of your configurations from your Hotspots module will work because this has nothing
//	to do with the hotspots module
//
//
//------------------------------------------------------------
//Example Step.rc config (my config):
//	*ckHotspot -32 -32 0 0 !VWMRight !none ;the box is located at -32, -32 and it's width and height are spanned to the rest of the screen.
//	*ckHotspot 0 -32 32 0 !VWMLeft !none ;the box is located at 0, -32, and it's height is spanned to the bottom of the screen.
//	*ckHotspot 0 20 16 800 !QBoxShow !QBoxHide 
//
//
//-----------------------------------------------------------
