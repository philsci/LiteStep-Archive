Add two lines like this to step.rc:

LoadModule c:\LITESTEP\ripple.dll
*Ripple 600 200 300 400

The numbers are xcoord, ycoord, width, height. Simple stuff.  I like to use:
*Ripple 0 700 1024 68

Things to look out for:
-It may look bad if you try to ripple a region above the top of the screen.
	DON'T.  For example *Ripple 10 10 300 300 ripples 300-10 from -290 
	off the top of the screen.
-You CAN break the string parser, DON'T.  =)

Regards,
