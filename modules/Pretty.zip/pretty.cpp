#include <windows.h>
#include <stdlib.h>
#include <time.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void GenerateRegions();

#define MAGIC_NUMBER 64

char* szAppName = "pretty colors";
HWND hwndMain;
HRGN regions[MAGIC_NUMBER];
COLORREF colors[MAGIC_NUMBER];
COLORREF tocolors[MAGIC_NUMBER];
HBRUSH brushes[MAGIC_NUMBER];

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{
    MSG msg;
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = szAppName;

	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	GenerateRegions();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, 0, 0, 1024, 768, NULL, NULL, hInstance, NULL);
	if (!hwndMain) return 1;

	SetCursor(NULL);

	SendMessage(hwndMain, WM_TIMER, 0, 0);
	SetTimer(hwndMain, 0, 100, NULL);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}

	KillTimer(hwndMain, 0);
	for (int x=0; x < MAGIC_NUMBER; x++)
	{
		if (brushes[x]) DeleteObject(brushes[x]);
		if (regions[x]) DeleteObject(regions[x]);
	}
	DestroyWindow(hwndMain);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, 1024, 768);
			HBITMAP oldbuf;

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			for (int x=0; x<MAGIC_NUMBER; x++)
			{
				FillRgn(buf, regions[x], brushes[x]);
				FrameRgn(buf, regions[x], (HBRUSH)GetStockObject(BLACK_BRUSH), 1, 1);
			}

			BitBlt(hdc, 0, 0, 1024, 768, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteObject(buf);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wparam)
			{
				case SC_CLOSE: PostQuitMessage(0); break;
			}
		}
		break;

		case WM_LBUTTONUP:
		{
			GenerateRegions();
		}
		break;

		case WM_TIMER:
		{
			for (int x=0; x<MAGIC_NUMBER; x++)
			{
				int r, g, b;
				int tr, tg, tb;

				if (brushes[x]) DeleteObject(brushes[x]);
				
				r = GetRValue(colors[x]);
				g = GetGValue(colors[x]);
				b = GetBValue(colors[x]);
				tr = GetRValue(tocolors[x]);
				tg = GetGValue(tocolors[x]);
				tb = GetBValue(tocolors[x]);
				if ( abs(r-tr)<5 && abs(g-tg)<5 && abs(b-tb)<5)
				{
					colors[x] = RGB(rand()%255, rand()%255, rand()%255);
					tocolors[x] = RGB(rand()%255, rand()%255, rand()%255);
				}
				colors[x] = RGB((r < tr)? r+2:r-2, (g < tg)? g+2:g-2, (b < tb)? b+2:b-2); 
				brushes[x] = CreateSolidBrush(colors[x]);
			}

			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wparam, lparam);
}

void GenerateRegions()
{
	int ox=0;
	int x=0;
	int y=0;
	srand(time(NULL));

	for (int count=0; count < MAGIC_NUMBER; count++)
	{
		POINT p[4];
		int width = 8;

		if (x == width) 
		{ 
			ox=0;
			x=0; 
			y++; 
		}
		
		p[0].x = x * 1024 / width;
		p[1].x = (x+1) * 1024 / width;
		p[2].x = (rand()%2)? p[1].x+(rand()%5) : p[1].x-(rand()%5);
		p[3].x = ox;

		ox = p[2].x;

		p[0].y = y * 768 / width;
		p[1].y = p[0].y;
		p[2].y = (y+1) * 768 / width;
		p[3].y = (y+1) * 768 / width;

		if (regions[count]) DeleteObject(regions[count]);
		regions[count] = CreatePolygonRgn((const POINT*)&p, 4, WINDING);

		colors[count] = RGB(rand()%255, rand()%255, rand()%255);
		tocolors[count] = RGB(rand()%255, rand()%255, rand()%255);

		x++;
	}
}