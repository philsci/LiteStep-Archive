DVWM (Dimension Virtual Window Manager)

step 1.Unzip to C:\dvwm\
	note- if you don't unzip to c:\dvwm you will
	      need to change modify your registry settings
	      before you start DVWM to point to a different
	      directory. Remember \'s in registry entries
	      are replaced with double-backslashes (\\).

step 2.Go into \dvwm\themes\ and pick one of the 3 theme 
       .reg files included. Double click it to merge it into
       your registry. You can now start DVWM by double clicking
       on dvwm.exe. 

step 3.Make your own themes. Go to the \dvwm\dvwm documentation\
       folder and open index.html. This is AznRomeo's Skinning
       Tutorial for DVWM.

---
__/\__  Brandon Sneed
\ oO /  Tumyeto Software
/_/\_\  nivenh@airmail.net

