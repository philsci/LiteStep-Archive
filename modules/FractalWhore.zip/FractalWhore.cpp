#include <windows.h>
#include <stdlib.h>
#include <time.h>

#define FRACTALS	100

char* szAppName = "Fractal Whore";
HWND hwndMain;
int ScreenX, ScreenY;
COLORREF color;
BOOL FIRST=TRUE;

class LINE
{
public:
	LINE(int _sx, int _sy, int _tx, int _ty) { sx=cx=_sx; sy=cy=_sy; tx=_tx; ty=_ty; next=0; done=FALSE; }
	void draw(HDC buf);
	LINE* next;
	BOOL done;

	int sx, sy;
	int cx, cy;
	int tx, ty;	
};

void LINE::draw(HDC hdc)
{
	SetPixel(hdc, cx, cy, color);
}

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
void MoveLines();
void StartHerUp();

LINE* start;

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{
    MSG msg;
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInstance;
	wc.lpszClassName = szAppName;

	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, "Error registering window class", szAppName, MB_OK);
		return 1;
	}

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	StartHerUp();
	
	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_VISIBLE | WS_POPUP, 0, 0, ScreenX, ScreenY, NULL, NULL, hInstance, NULL);
	if (!hwndMain) return 1;

	SetCursor(NULL);

	SendMessage(hwndMain, WM_TIMER, 0, 0);
	SetTimer(hwndMain, 0, 100, NULL);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
	{ 
		TranslateMessage(&msg); 
		DispatchMessage(&msg); 
	}

	KillTimer(hwndMain, 0);
	while (start)
	{
		LINE* l = start;
		start=start->next;
		delete l;
	}
	DestroyWindow(hwndMain);
	
	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);

			if (FIRST)
			{
				RECT r;
				GetClientRect(hwndMain, &r);
				FillRect(hdc, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));
				FIRST=FALSE;
			}

			for (LINE* l = start; l; l=l->next)
			{
				l->draw(hdc);
			}

			EndPaint(hwnd, &ps);
		}
		break;

		case WM_SYSCOMMAND:
		{
			switch (wparam)
			{
				case SC_CLOSE: PostQuitMessage(0); break;
			}
		}
		break;

		case WM_LBUTTONUP:
		{
			while (start)
			{
				LINE* l = start;
				start=start->next;
				delete l;
			}
			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;

		case WM_RBUTTONUP: PostQuitMessage(0); break;

		case WM_TIMER:
		{
			MoveLines();
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wparam, lparam);
}

void MoveLines()
{
	BOOL INSIDE=FALSE;

	for (LINE* l = start; l; l=l->next)
	{
		if (!l->done)
		{
			INSIDE=TRUE;

			if (l->cx == l->tx && l->cy == l->ty)
			{
				if (l->tx < ScreenX && l->tx > 0 &&
					l->ty < ScreenY && l->ty > 0)
				{
					LINE* nl1 = new LINE(l->cx, l->cy, (rand()%2)? l->cx + rand()%FRACTALS:l->cx - rand()%FRACTALS, (rand()%2)? l->cy + rand()%FRACTALS : l->cy - rand()%FRACTALS);
					LINE* nl2 = new LINE(l->cx, l->cy, (rand()%2)? l->cx + rand()%FRACTALS:l->cx - rand()%FRACTALS, (rand()%2)? l->cy + rand()%FRACTALS : l->cy - rand()%FRACTALS);

					nl2->next = nl1;
					nl1->next = start;
					start = nl2;
				}

				l->done = TRUE;
			}
			else
			{
				if (l->cx < l->tx) l->cx++;
				else if (l->cx > l->tx) l->cx--;

				if (l->cy < l->ty) l->cy++;
				else if (l->cy > l->ty) l->cy--;

				if (l->cx < 0 || l->cx > ScreenX ||
					l->cy < 0 || l->cy > ScreenY) l->done=TRUE;

				HDC hdc = GetDC(hwndMain);
				COLORREF color = GetPixel(hdc, l->cx, l->cy);
				if (color != 0) l->done=TRUE;
				ReleaseDC(hwndMain, hdc);
			}
		}
	}

	if (!INSIDE)
	{
		while (start)
		{
			LINE* l = start;
			start=start->next;
			delete l;
		}

		StartHerUp();
	}

	InvalidateRect(hwndMain, NULL, TRUE);
}

void StartHerUp()
{
	srand(time(NULL));
	start = new LINE(0, 0, (rand()%FRACTALS)+FRACTALS, (rand()%FRACTALS)+FRACTALS);
	start->next = new LINE(ScreenX, 0, ScreenX-(rand()%FRACTALS)-FRACTALS, (rand()%FRACTALS)+FRACTALS);
	start->next->next = new LINE(0, ScreenY, (rand()%FRACTALS)+FRACTALS, ScreenY-(rand()%FRACTALS)-FRACTALS);
	start->next->next->next = new LINE(ScreenX, ScreenY, ScreenX-(rand()%FRACTALS)-FRACTALS, ScreenY-(rand()%FRACTALS)-FRACTALS);

	int num = rand() % 4;
	if (num == 0) color = RGB(255, 0, 0);
	if (num == 1) color = RGB(0, 255, 0);
	if (num == 2) color = RGB(0, 0, 255);
	if (num == 3) color = RGB(0, 255, 255);

	FIRST=TRUE;
}