                    ***********************************
                    *            MetaDesk             *
                    *           by Visigoth           *
                    *   gandhimail@worldnet.att.net   *
                    *         ==============          *
                    *          Version: 1.1           *
                    *          July 14, 1999          *
                    *         ==============          *
                    * http://home.att.net/~gandhimail *
                    ***********************************

Table of Contents
=================
i     Quick & Dirty Install
ii    WARNING & DISCLAIMER
iii   Change Log
I.    About MetaDesk
II.   How to use MetaDesk

      II.1 MetaDesk Properties
      II.2 RC Commands
      II.3 !Bang Commands
      II.4 Obtaining Metastream Objects
      II.5 Recommended *Metastream RC Commands

III.  Known Bugs / Limitations
IV.   Comments / Questions / Flames / Bug Reports
V.    Source Code
VI.   Source Code License


i. Quick & Dirty Install
========================
   Place metadesk.dll into your modules directory and add LoadModule
   <module-dir>\metadesk.dll into your step.rc file.
   
   There's more, however.  To use this module, you will have to
   download the Metastream Plug-In & ActiveX control from
   http://www.metastream.com.  Choose to download the installer and
   run it.  It's less than 800K I think, so it's not that big at all.


ii. WARNING & DISCLAIMER
========================
   WARNING: Do NOT go overboard with this.  Currently, because I am
   so crappy at COM programming, this thing basically takes a
   workaround approach and uses Internet Explorer to host the
   Metastream ActiveX control.  So, for now, that means loading
   Internet Explorer into memory.  This WILL slow down your startup
   a lot unless you have something like a PII-300 / K6-300 or higher.
   This is not to discourage the use of this module, but just to
   discourage the over-use of it.  Having more than 2 metastream
   objects on the desktop is probably not the best idea at present,
   and I don't see a reason to really have more than two anyway...

   DISCLAIMER: Although I work for MetaCreations (the company who owns
   the Metastream trademark and creators of the technology), the
   company in no way endorses, supports, or guarantees that this
   product works.  This was created by me (Visigoth) as a project to
   extend this technology beyond its original goals.  Again,
   MetaCreations has no official knowledge of this product and will
   not support it.  All questions and such should be directed toward
   me.  Contact information may be found in section IV.


iii. Change Log
===============

   Version 1.1
   -----------
   
     Documentation Changes
     `````````````````````
     - Fixed "Source/Src" issue.  The proper MetaDesk property is
       Source.
     
     Bug Fixes
     `````````
     - Hopefully fixed the "MetaDesk doesn't do anything" bug
       by implementing the new features.  See the Notes below
     
     New Features
     ````````````
     - Added following RC Commands:
     
       * MetaDeskUseWinTempPath
       * MetaDeskFilePath

     Notes
     `````
     For those of you who have gotten MetaDesk to work, great.  Just
     turn on MetaDeskUseWinTempPath and it'll work just like it did
     before.  If it doesn't, just turn MetaDeskUseWinTempPath off and
     see if that works.  If not, then keep reading...  For the many
     of you who couldn't get it to work, try using the
     MetaDeskFilePath RC Command like this: MetaDeskFilePath <path>
     
     The path must exist.  I haven't tried it with LFNs (Long
     FileNames - ones with spaces), so try it with something simple
     like c:\ and see if that works.  If not, then something is still
     fucked in MetaDesk land.  I shall have to do some more debugging
     if this doesn't work for all of you....


I. About MetaDesk
=================
   MetaDesk is a module that enables you to put 3D objects directly on
   your desktop in Litestep.  These objects must be in Metastream
   format - http://www.metastream.com  The format is a breakthrough
   in 3D modelling and enables people to "dial-down" the quality of a
   3D model to suit the available performance on any machine.  So,
   even if you have an old Pentium 200, you should still be able to
   use this module, though you'll probably have problems.  (It *is*
   ActiveX, you know...)


II. How to use MetaDesk
=======================
   MetaDesk can be used as a decoration in any theme to provide an
   animated 3D object on the desktop.  It can also become functional
   by setting certain properties - when the user double clicks, a
   program or !Bang command may be run.  If you have my LSXCommand
   (version 1.7.1 or higher), MetaDesk will use the !Command !bang
   command - so using aliases or search engines are also possible.
   More about this is explained below.
   
   MetaDesk step.rc commands are in the form of Maduin's DeskFolders
   module:
   
   *Metastream property(value) property(value) ....
   
   All the properties and their meanings are explained below.  To see
   some examples of RC Commands, see section II.4  For more
   information about Metastream and the way it works, please visit the
   Metastream web site at http://www.metastream.com


   II.1 MetaDesk Properties
   ------------------------
     NOTE: The following are all the MetaDesk properties.  I would
     *strongly* recommend at least skimming through all of these.
     Also, recommended *Metastream lines are in section II.4, so
     start from those unless you're a real web developer that knows
     about ActiveX Controls and such!


     [BOOLEANS]
     All the following are boolean properties.  They can be set by
     using the following:
     
     TRUE:  property(true)   -or-  property(1)
     FALSE: property(false)  -or-  property(0)
     
     AutoResolution
     ``````````````
     Description: Turns on automatic adjustment for performance.  The
     technical side of it is that it dynamically changes the
     resolution of the model based on frame rates.  Turning this off
     assumes you want full detail all the time.
     
     Default: TRUE
     
     
     RotationMode
     ````````````
     Description: If set to true, this makes the model rotate *only*
     when the user has the mouse over it.
     
     Default: FALSE  (always rotating)
     
     
     AllowZoom
     `````````
     Description: If true, allows the user to zoom in on the model.
     
     Default: TRUE
     
     
     AllowPan
     ````````
     Description: If true, allows the user to pan the view of the
     model.
     
     Default: TRUE
     
     
     EnableMenu
     ``````````
     Description: This enables the right-click (context) menu.
     
     Default: FALSE (menu is off)
     
     
     MouseRotation
     `````````````
     Description: Enables the user to rotate the model with the mouse.
     
     Default: TRUE
     
     
     MouseRes
     ````````
     Description: Lets the user change the model's resolution by
     dragging the mouse left & right with the right mouse button
     held down.
     
     Default: TRUE
     
     
     BackFaceCulling
     ```````````````
     Description: Turns on rendering of "back faces"  If your model
     is an "open" model, like a skull or a mask, instead of one where
     you can't ever see the inside of it (like a solid sphere), turn
     this on.
     
     Default: FALSE
     
     
     [COLORS]
     The following are color properties available for MetaDesk.  These
     properties can be set like this:
     
       property(R G B)  - Note the spaces between R, G and B
       R : 0 - 255 red color value
       G : 0 - 255 green color value
       B : 0 - 255 blue color value
     
     BackgroundColor
     ```````````````
     Description: Sets the background color behind the model.
     
     Default: 0 0 0  (Black)
     
     
     [INTEGERS]
     The following properties are integer values.  These properties
     are set like this:
     
       property(<integer>)  - e.g.  property(20)
     
     RotationSpeed
     `````````````
     Description: Sets the rate at which the model rotates.  The value
     is the number of degrees the model rotates through every second.
     If this value is negative, the model rotates counter-clockwise.
     
     Default: 0
     
     
     YawLimit
     ````````
     Description: Sets the maximum number of degrees the model may
     rotate through in each direction.  This creates a "pendulum"
     effect where the model rotates to one side, then goes back to the
     other after a certain amount of degrees
     
     Default: 0  (no limit)
     
     
     AntiAlias
     `````````
     Description: Sets the level at which antialiasing should be done.
     Higher values yeild better looking results, but it gets really
     slow.  A value of 4 seems to get good results.
     
     Default: 0  (no antialiasing)
     
     
     MouseAlign
     ``````````
     Description: This sets the way in which the mouse interacts
     with the model.
     
       0 : No constraints in rotation
       1 : Align mouse rotation to axes
       2 : Align mouse rotation to platter axis only
     
     Default: 0
     
     
     Renderer
     ````````
     Description: Sets the renderer that is used to render the
     object.
     
       1 : OpenGL (MUST have an OpenGL accelerator - Voodoo, TNT, etc)
       2 : SreeD (MetaCreations renderer - *really* good for software)
       3 : D3D (Bah - Direct3D, what else can you say?)
     
     Default: SreeD
     
     
     RenderingMode
     `````````````
     Description: Sets how the model should be rendered.
     
       0 : Default Gouraud Shading
       1 : Flat Shading
       2 : Wireframe
     
     Default: 0
     
     
     [STRINGS]
     The following properties are all strings.  They can be set in
     the following ways:
     
       property(<string>)  - e.g.  property(c:\foo bar.baz)
       property("<string>")  - e.g. property("c:\foo bar.baz")
       
     NOTE: Both are the same - the quotes don't matter
     
     Source
     ``````
     Description: Points to the model to render.
     
     Default: ""  (no source model)
     
     
     Camera
     ``````
     Description: This sets the position and orientation of the
     camera initially.  The easiest way to set this is to do the
     following: Use the model without the camera property set;
     rotate and zoom and pan to the place you want to look at the
     model from initially; hold CTRL+ALT+SHIFT and click the right
     mouse button.  The proper camera coordinates have been copied
     to your clipboard.  Just paste the value as a property.
     
     Default: ""  (model sets initial camera coordinates)
     
     
     BackgroundImage
     ```````````````
     Description: Points to the background image to be used.  NOTE:
     the Metastream ActiveX control currently only supports JPEG
     format images.  Bitmaps and GIFs are not usable here.
     
     Default: ""  (no background - uses background color)
     
     
     LinkURL
     ```````
     Description: Command to launch when the user *DOUBLE* clicks
     on the model.
     
     Default: ""  (launches nothing)
     
     
     PlatterAxis
     ```````````
     Description: Sets the platter axis.  This value is stored like
     this:
     
       PlatterAxis(X Y Z)
     
     where X, Y and Z are slope values along that axis.  For instance,
     PlatterAxis(0 1 0) sets the model to rotate about the Y
     (vertical) axis.  PlatterAxis(1 1 0) sets the model to rotate
     about the line y=x.  The values can be between 0 and 1.
     
     Default: 0 1 0  (Y axis - vertical - rotation)
     
     
     Locks
     `````
     Description: Sets the axes in which the model is not allowed to
     move.  This can be any combination of the letters X, Y and Z
     (case does not matter).  For instance, Locks(xy) stops the
     model from rotating around the X or Y axis when the user attempts
     to rotate the model with the mouse.  If rotation speed and
     platter axis were set to make the model rotate about one of these
     axes, that would still occur.
     
     Default: ""  (no locks)
     
     
     [NON-INTEGERS]
     The following are non-integral (float) values.  That just means
     they can have decimals.
     
     Scale2D
     ```````
     Description: Scales the rendered image by a certain value.  You
     can shrink or magnify the image with this value.  Note that this
     isn't the same as zooming or paning - it's like resizing an image
     in Photoshop.
     
     Default: 0  (no scaling)


   II.2 RC Commands
   ----------------
   
     MetaDeskUseWinTempPath
     ``````````````````````
     Description: Instructs MetaDesk to use Windows' temporary
     path (the TEMP or TMP environment variables)
     
     
     MetaDeskFilePath
     ````````````````
     Description: Points to the directory in which MetaDesk will
     store its files.
     
     Example: c:\litestep


   II.3 !Bang Commands
   -------------------
     
     !MetaDeskHide
     `````````````
     Description: Hides a particular MetaDesk object.
     
     Example: !MetaDeskHide 2  ; Hides the second MetaDesk object


     !MetaDeskHideAll
     ````````````````
     Description: Hides all MetaDesk objects.


     !MetaDeskToggle
     ```````````````
     Description: Toggles the visibility of a particular MetaDesk
     object. See !MetaDeskHide for syntax.


     !MetaDeskShow
     `````````````
     Description: Shows a particular MetaDesk object.  See
     !MetaDeskHide for syntax.
     
     
     !MetaDeskShowAll
     ````````````````
     Description: Shows all MetaDesk objects.
     
     
   II.4 Obtaining Metastream Objects
   ---------------------------------
     Metastream is a 3D file format - just as DXF, 3DMF and LWO
     (which are AutoDesk, 3DMF, and LightWave Object formats
     respectively).  There are several applications that can output
     Metastream objects.  Obviously, most are MetaCreations products,
     but others exist.  The following is a list of the applications I
     know are able to output Metastream files.  Note that MetaDesk
     *only* accepts Metastream format files.

     Please excuse the "commercial" type descriptions.  I'm trying to
     give people ideas about what these products can do with respect
     to Metastream.  Sorry if it sounds like I'm one of those Info-
     mercial guys.
     
       MetaCreations Infini-D 4.5 & higher
       ```````````````````````````````````
       This was one of the first products to be able to output
       Metastream objects.  You can find it at:
       http://www.metacreations.com/products/infinid

       MetaCreations Ray Dream Studio / Ray Dream 3D
       `````````````````````````````````````````````
       Ray Dream Studio is a more industrial strength tool.  Ray
       Dream 3D is more for the casual user.  Both can export
       Metastream objects.
       http://www.metacreations.com/products/rds
       http://www.metacreations.com/products/rd3d
       
       MetaCreations Bryce 4
       `````````````````````
       Bryce, IMO, is just a really cool tool.  Plus, it can create
       Metastream objects...  You can find it here:
       http://www.metacreations.com/products/bryce4
       
       MetaCreations Poser 4
       `````````````````````
       With Poser 4, you can create humanoid shapes for your
       Metastream objects.. Very cool.
       http://www.metacreations.com/products/poser4
       
       MetaCreations Canoma
       ````````````````````
       Canoma enables you to create 3D objects out of photographs.
       For instance, you could create a model of your home and have
       MetaDesk link your rotating home to your homepage on the web!
       http://www.metacreations.com/products/canoma
       
       3D Studio MAX
       `````````````
       MetaCreations has created a *free* 3D Studio MAX exporter
       plugin that enables you to export any 3D Studio object as a
       Metastream object.
       http://www.metacreations.com/products/max250


     If you can't afford these products, there are a few galleries
     on the Internet to get a few Metastream objects.  However, many
     are of little use on the desktop.  I've provided a few for you
     in a separate package with this module, so see if those make any
     sense to use on your desktop. The package may be found at
     http://home.att.net/~gandhimail under the Litestep/MetaDesk
     sections.

     There seem to be a few graphic artists on the Litestep mailing
     list.  True, they are mostly 2D graphic artists, but with some
     luck, there probably are a few 3D artists out there.  I hope they
     see this as a good challenge to provide some really cool models
     to use with MetaDesk.  If you have a model idea, but not the
     skills or money to make an object, ask on the list and see what
     happens.
     
     
     II.5 Recommended *Metastream RC Commands
     ----------------------------------------
     The following are some standard commands that most people can
     start from.  Note that I didn't have enough space to put all of
     a single command on one line, so I've separated them somewhat.
     
       Top left corner of screen; 200 pixels wide & tall; launches
       notepad; Always rotate @ 1 rotation / 3 seconds; Flat shading;
       Rotate around vertical axis; The user can interact with the
       model (rotate/move it, etc.); Right-click menu available;
       Automatically adjust for performance - in that order
       ``````````````````````````````````````````````````````````````
       *Metastream x(0) y(0) width(200) height(200)
       source(c:\foo.mts) linkurl(notepad) rotationspeed(120)
       rotationmode(0) platteraxis(0 1 0) mouseres(1)
       mouseinteraction(1) enablemenu(1) autoresolution(1)


       Same size & place; launches notepad; Rotate only when mouse is
       over it @ same rate; wireframe; rotate back & forth 60 degrees
       each way; rotate around Y axis; user can not interact;
       antialiasing at level 4; background image
       ``````````````````````````````````````````````````````````````
       *Metastream x(0) y(0) width(200) height(200)
       source(c:\bar.mts) linkurl(notepad) rotationmode(1)
       rotationspeed(120) yawlimit(60) platteraxis(0 1 0)
       mouseinteraction(0) mouseres(0) antialias(4)
       backgroundimage(c:\biz.jpg)


III. Known Bugs / Limitations
=============================
   None that I know, but some will be bound to pop up...


IV. Comments/Questions/Flames/Bug Reports
=========================================
   All of these should be sent directly to me, Visigoth.  My e-mail
   address is:  gandhimail@worldnet.att.net

   Seriously, though, I really would like to know if people are using
   this thing.  It'll help me determine whether it's worth continuing
   the development of it.


V. Source Code
==============
   Yes, source code is available.  All you have to do is send me an
   e-mail for it.  My e-mail is gandhimail@worldnet.att.net
   However, if you are going to edit the code, *please* read the
   Source Code License below.  There are certain restrictions.


VI. Source Code License
=======================

   Article I. Sure, Have the Code!
   -------------------------------
   I don't want to stop progress on this module.  So, I'm going to
   let anyone who wants to edit the code, do so at his/her free will.
   However, there are restrictions, as noted by the rest of the
   license.

   Article II. Redistribution
   --------------------------
   This file *must* be redistributed with the source code, with duly
   noted changes to sections I, II, III, and IV.  However, I request
   that my name be left in Section I as the original author of the
   module.

   Article III. Leave Credit where It's Due!
   -----------------------------------------
   All I ask is that Section I still have my name in it as the
   original author.  Besides this file and the comments, there isn't
   much to say that I did anything... :)

   Article IV. Send Me Your Cool Stuff
   -----------------------------------
   I'd like to know about your ideas for MetaDesk!  If you are
   working on an idea, I would like to know what it is.  I'm not like
   Microsoft (ie. I'm going to steal your idea, throw my time at it,
   and come out with a shoddier version first).  I'd just like to
   know what people are doing with my original code base.  So, if you
   do edit code for a purpose, please drop me a line as to what you
   are doing.

   Article V. Have Fun
   -------------------
   Remember, I'm not going to stop progress on this module, so go
   ahead and do what you want to it.  Just don't take credit for
   what I've already done.