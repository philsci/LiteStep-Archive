#include <windows.h>
#include <stdio.h>
#include <process.h>
#include "LSMail.h"

#define QUIT		0
#define CHECKING	1
#define NEWMAIL		2
#define IDLE		3

/* ----------------------------------------------------------------- */
char szAppName[] = "LSMail"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK SettingsProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK StatusProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK HideChildProc(HWND hwnd,LPARAM lParam);
BOOL CALLBACK ShowChildProc(HWND hwnd,LPARAM lParam);
int LoadSetup();
int CheckMail();
int closeup(int);
int PlayMovie(char* file);
int EditSettings();
int GetSettings();
int SaveSettings();
void Say(char* what);
char* Crypt(char*);

HWND hMainWnd;                    // main window handle
HWND hStatusWnd, hStatusEditWnd;
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HINSTANCE Instance;

// Random stuff
int socketinit=0;
int wsainit;
SOCKET mysocket;
HANDLE thread=NULL;
HMENU Popup;
int error=0;
char ini[_MAX_PATH];
DWORD MB = MB_OK | MB_SETFOREGROUND;
int Timer=0;
int Timeout=5;

// Mail stuff
char PopServer[3][128] = {"","",""};
int PopPort[3] = {110,110,110};
char PopUser[3][128] = {"","",""};
char PopPass[3][128] = {"","",""};
char MailClient[MAX_PATH] = "";
char NewMailMovie[MAX_PATH] = "";
char CheckMailMovie[MAX_PATH] = "";
char NoMailMovie[MAX_PATH] = "";
int nMessages[3] = {0,0,0};
char Status[1024] = "> Idle...";
//int penX[3] = {0,0,0};
//int penY[3] = {0,0,0};
//DWORD pencolor[3] = {0x00FFFFFF, 0x00FFFFFF, 0x00FFFFFF};

// Settings Windows
HWND hEditWnd;
HWND hOptionsWnd, hVideosWnd, hServer1Wnd, hServer2Wnd, hServer3Wnd;
HWND hbOptionsWnd;
HWND hbVideosWnd;
HWND hbServer1Wnd;
HWND hbServer2Wnd;
HWND hbServer3Wnd;
HWND hbOkWnd, hbCancelWnd;
//HWND sIntervalWnd, sAlertWnd, sCheckWnd, sClientWnd;
//HWND hIntervalWnd, hAlertWnd, hCheckWnd, hClientWnd;
HWND sIntervalWnd, sClientWnd;
HWND hIntervalWnd, hClientWnd;
HWND sCheckMailWnd, sNewMailWnd, sNoMailWnd;
HWND hCheckMailWnd, hNewMailWnd, hNoMailWnd;
HWND sPopServer1Wnd, sPort1Wnd, sLogin1Wnd, sPass1Wnd;//, sPenX1Wnd, sPenY1Wnd;
HWND hPopServer1Wnd, hPort1Wnd, hLogin1Wnd, hPass1Wnd;//, hPenX1Wnd, hPenY1Wnd;
HWND sPopServer2Wnd, sPort2Wnd, sLogin2Wnd, sPass2Wnd;//, sPenX2Wnd, sPenY2Wnd;
HWND hPopServer2Wnd, hPort2Wnd, hLogin2Wnd, hPass2Wnd;//, hPenX2Wnd, hPenY2Wnd;
HWND sPopServer3Wnd, sPort3Wnd, sLogin3Wnd, sPass3Wnd;//, sPenX3Wnd, sPenY3Wnd;
HWND hPopServer3Wnd, hPort3Wnd, hLogin3Wnd, hPass3Wnd;//, hPenX3Wnd, hPenY3Wnd;


// FLAGS
int STATUS=IDLE;
BOOL CHECKMAIL=TRUE;
BOOL ALERT=TRUE;
BOOL QUITTING=FALSE;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    if (wharfData.borderSize < 0)
		wharfData.borderSize = 0;
	wndSize = 64-wharfData.borderSize*2;
	Instance = dllInst;
	
	sprintf(ini, "%smodules.ini", wharfData.lsPath);
	LoadSetup();

	Popup = CreatePopupMenu();
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Check Mail Now");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 101, "&Launch E-Mail Client");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "&Go Idle");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 103, "&Edit Settings");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 104, "&Show LSMail Status");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 105, "&About LSMail");
		AppendMenu(Popup, MF_SEPARATOR, 0, "");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, "Check &Mail");
		AppendMenu(Popup, MF_ENABLED | MF_STRING, 107, "Alert &Box");
	
	(CHECKMAIL)? CheckMenuItem(Popup, 106, MF_CHECKED) : 0;
	(ALERT)? CheckMenuItem(Popup, 107, MF_CHECKED) : 0;

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering LSMail window class",szAppName, MB_OK);
            return 1;
        }

		wc.lpfnWndProc = SettingsProc;
		wc.lpszClassName = "EditSettings";
		wc.style=0;
		if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering EditSettings window class",szAppName, MB_OK);
            return 1;
        }
		
		wc.lpfnWndProc = StatusProc;
		wc.lpszClassName = "StatusWindow";
		wc.style=0;
		if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering StatusWindow window class",szAppName, MB_OK);
            return 1;
        }
    }

    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

	if (CHECKMAIL) SetTimer(hMainWnd, 0, Timeout*60000, NULL);
	PlayMovie(NoMailMovie);

	return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	QUITTING=TRUE;
	if (STATUS==CHECKING) 
	{
		Sleep(5000);
		if (thread) TerminateThread(thread, (DWORD)0);
	}
	mciSendString("close movie", NULL, 0, NULL);
	KillTimer(hMainWnd, 0);
	DestroyWindow(hMainWnd);
	DestroyWindow(hEditWnd);
	DestroyWindow(hStatusWnd);
	DestroyWindow(hStatusEditWnd);
	hStatusEditWnd=NULL;
	UnregisterClass("EditSettings", dllInst);
	UnregisterClass("StatusWindow", dllInst);
	UnregisterClass(szAppName, dllInst);    // unregister window class
}

int LoadSetup()
{
	int a;
	char BaseName[256] = "";

	// Interval
	Timeout = GetPrivateProfileInt("LSMail", "Interval", -69, ini);
	if (Timeout == -69)
		Timeout=5;

	// Alert Box
	ALERT = GetPrivateProfileInt("LSMail", "AlertBox", -69, ini);
	if (ALERT == -69)
		ALERT=1;

	// Check Mail
	CHECKMAIL = GetPrivateProfileInt("LSMail", "CheckMail", -69, ini);
	if (CHECKMAIL == -69)
		CHECKMAIL=0;

	// Mail Client
	GetPrivateProfileString("LSMail", "MailClient", "c:\\full\\path\\to\\client.exe", MailClient, MAX_PATH, ini);

	// NoMailMovie
	GetPrivateProfileString("LSMail", "NoMailMovie", "NO", NoMailMovie, MAX_PATH, ini);
	if (!strcmp(NoMailMovie, "NO"))
		strcpy(NoMailMovie, "C:\\Litestep\\Images\\NoMail.avi");
	
	// NewMailMovie
	GetPrivateProfileString("LSMail", "NewMailMovie", "NO", NewMailMovie, MAX_PATH, ini);
	if (!strcmp(NewMailMovie, "NO"))
		strcpy(NewMailMovie, "C:\\Litestep\\Images\\NewMail.avi");

	// CheckMailMovie
	GetPrivateProfileString("LSMail", "CheckMailMovie", "NO", CheckMailMovie, MAX_PATH, ini);
	if (!strcmp(CheckMailMovie, "NO"))
		strcpy(CheckMailMovie, "C:\\Litestep\\Images\\CheckMail.avi");

	for (a=0;a<3;a++)
	{
		// Port
		sprintf(BaseName, "Pop_Port_%d", a+1);
		PopPort[a] = GetPrivateProfileInt("LSMail", BaseName, -1, ini);
		if (PopPort[a] == -1)
			PopPort[a] = 110;

		// Server
		sprintf(BaseName, "Pop_Server_%d", a+1);
		GetPrivateProfileString("LSMail", BaseName, "NO", PopServer[a], 127, ini);
		if (!strcmp(PopServer[a], "NO"))
			memset(&PopServer[a], 0, sizeof(PopServer[a]));

		// User
		sprintf(BaseName, "Pop_User_%d", a+1);
		GetPrivateProfileString("LSMail", BaseName, "NO", PopUser[a], 127, ini);
		if (!strcmp(PopUser[a], "NO"))
			memset(&PopUser[a], 0, sizeof(PopUser[a]));

		// Password
		sprintf(BaseName, "Pop_Password_%d", a+1);
		GetPrivateProfileString("LSMail", BaseName, "NO", PopPass[a], 127, ini);
		if (!strcmp(PopPass[a], "NO"))
			memset(&PopPass[a], 0, sizeof(PopPass[a]));
		else
			strcpy(PopPass[a], Crypt(PopPass[a]));

		/*
		// PenX
		sprintf(BaseName, "PenX_%d", a+1);
		penX[a] = GetPrivateProfileInt("LSMail", BaseName, -69, ini);
		if (penX[a] == -69)
			penX[a] = 10;

		// PenY
		sprintf(BaseName, "PenY_%d", a+1);
		penY[a] = GetPrivateProfileInt("LSMail", BaseName, -69, ini);
		if (penY[a] == -69)
			penY[a] = 50;

		// Pen Color
		sprintf(BaseName, "PenColor_%d", a+1);
		pencolor[a] = GetPrivateProfileInt("LSMail", BaseName, -69, ini);
		if (pencolor[a] == -69)
			pencolor[a] = 0x00FFFFFF;
		*/
	}
	return 0;
}

/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			EndPaint(hwnd, &ps);
		}
		return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	    case WM_RBUTTONUP:
		{
			RECT r;
			GetWindowRect(hwnd, &r);
			PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
		}
		return 0;
        case WM_LBUTTONDOWN:
			return 0;
		case WM_LBUTTONDBLCLK:
			if (!hStatusWnd)
			{
				hStatusWnd = CreateWindowEx(WS_EX_TOOLWINDOW,"StatusWindow","LSMail Status",WS_POPUPWINDOW | WS_DLGFRAME,
								10, 
								10, 
								400,200,parent,NULL,Instance,0);
				hStatusEditWnd = CreateWindowEx(0, "Edit", Status, WS_CHILD | WS_CLIPCHILDREN | WS_BORDER | ES_MULTILINE | ES_READONLY | ES_WANTRETURN | ES_AUTOVSCROLL, 5, 5, 385, 170, hStatusWnd, NULL, Instance, 0);
				ShowWindow(hStatusWnd, SW_SHOWNORMAL);
				ShowWindow(hStatusEditWnd, SW_SHOWNORMAL);
				ShowWindow(CreateWindowEx(0, "ScrollBar", "", WS_CHILD | SBS_VERT | SBS_RIGHTALIGN, 375, 0, 10, 170, hStatusEditWnd, NULL, Instance, 0), SW_SHOWNORMAL);
			}
			else
			{
				DestroyWindow(hStatusWnd);
				hStatusWnd = NULL;
				hStatusEditWnd = NULL;
			}
			return 0;
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
        case WM_RBUTTONDOWN:
			{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			return 0;
			}
		case WM_COMMAND:
			switch(wParam)
			{
				case 100:
				{
					if (STATUS != CHECKING)
						thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckMail, (LPVOID)NULL, 0, &(int)thread);
				}
				break;
				case 101:
				{
					if (strcmp(MailClient, "c:\\full\\path\\to\\client.exe"))
					{
						WinExec(MailClient, SW_SHOWNORMAL);
						if (STATUS == NEWMAIL)
						{
							STATUS=IDLE;
							PlayMovie(NoMailMovie);
							strcat(Status, "\r\nIdle...");
							if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
						}
					}
					else
						Say("You have not specified which e-mail client to launch. Please take a look in 'Edit Settings'.");
				}
				break;
				case 102:
				{
					if (STATUS == NEWMAIL)
					{
						mciSendString("close movie", NULL, 0, NULL);
						STATUS=IDLE;
						PlayMovie(NoMailMovie);
						strcat(Status, "\r\nIdle...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					}
				}
				break;
				case 103:
				{
					if (!hEditWnd) 
					{
						KillTimer(hMainWnd, 0);
						strcat(Status, "\r\n> Editing Settings...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
						EditSettings();
					}
				}
				break;
				case 104:
				{
					PostMessage(hMainWnd, WM_LBUTTONDBLCLK, (WPARAM)0, (LPARAM)0);
				}
				break;
				case 105:
				{
					MessageBox(hMainWnd, "LSMail V2.0\nBy: MrJukes\n\nE-mail me at mrjukes@purdue.edu.", "About LSMail V2.0", MB | MB_ICONINFORMATION);
				}
				break;
				case 106:
				{
					if (CHECKMAIL) 
					{
						CHECKMAIL=FALSE;
						CheckMenuItem(Popup, 106, MF_UNCHECKED);
						WritePrivateProfileString("LSMail", "CheckMail", "0", ini);
						KillTimer(hMainWnd, 0);
						strcat(Status, "\r\n> Stopping Timer...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					}
					else 
					{
						CHECKMAIL=TRUE;
						CheckMenuItem(Popup, 106, MF_CHECKED);
						WritePrivateProfileString("LSMail", "CheckMail", "1", ini);
						SetTimer(hMainWnd, 0, Timeout*60000, NULL);
						strcat(Status, "\r\n> Starting Timer...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					}
				}
				break;
				case 107:
				{
					if (ALERT)
					{
						ALERT=FALSE;
						CheckMenuItem(Popup, 107, MF_UNCHECKED);
						WritePrivateProfileString("LSMail", "AlertBox", "0", ini);
						strcat(Status, "\r\n> Disabling Alert Box...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					}
					else
					{
						ALERT=TRUE;
						CheckMenuItem(Popup, 107, MF_CHECKED);
						WritePrivateProfileString("LSMail", "AlertBox", "1", ini);
						strcat(Status, "\r\n> Enabling Alert Box...");
						if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					}
				}
				break;
			}
			return 0;
		case WM_TIMER:
			PostMessage(hMainWnd, WM_COMMAND, (WPARAM)100, (LPARAM)NULL);
		return 0;

    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

LRESULT CALLBACK StatusProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT r;
			HBRUSH hbr = CreateSolidBrush(0x00C0C0C0);
			HDC hdc = BeginPaint(hwnd, &ps);
			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, hbr);
			EndPaint(hwnd, &ps);
			DeleteObject(hbr);
		}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

/*********************************************************************/
/* Check Mail                                                        */
/*********************************************************************/
int CheckMail()
{
WORD wVersionRequested; 
WSADATA wsaData; 
struct in_addr addr;
struct sockaddr_in myaddr;
int err; 
int on = 1;
int loop = 0, reply = 0;
struct hostent *host;
char data[256];
char temp[256];
int oldnmsg[3]= {nMessages[0],nMessages[1],nMessages[2]};
int x=1;
int PREVSTATUS=STATUS;

// Start Mail Check Animation
STATUS=CHECKING;
PlayMovie(CheckMailMovie);
memset(&Status, 0, sizeof(Status));

for (loop=0; loop < 3; loop++)
{
	// Do all the socket stuff
	wVersionRequested = MAKEWORD(1, 1); 
	memset(&wsaData, 0, sizeof(wsaData));
	err = WSAStartup(wVersionRequested, &wsaData); 

	if (err != 0) 						 
		return closeup(1);

	wsainit=1;
 
	if ( LOBYTE( wsaData.wVersion ) != 1 || 
		    HIBYTE( wsaData.wVersion ) != 1 ) { 
		return closeup(1);
		}

	if (!*PopServer[loop] || QUITTING)
		return closeup(1);

	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	memset((void *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons((short)PopPort[loop]);

	socketinit=1;
      
	addr.s_addr = inet_addr (PopServer[loop]);
	if (addr.s_addr == INADDR_NONE)
	{
		host = gethostbyname (PopServer[loop]);
		if (host == NULL || QUITTING)
			return closeup(1);
		else
			memcpy((char *) &addr, host->h_addr, host->h_length);
	}
										
	myaddr.sin_addr = addr;

	sprintf(temp, "> Connecting to %s...", PopServer[loop]);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	if (connect(mysocket, (struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);
	// Receive data
	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);

	sprintf(temp, "\r\n> %s", data);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	// First three should be +OK
	if (strncmp(data, "+OK", 3) && !QUITTING)
		return closeup(1);
	
	// Send USER
	sprintf(data, "USER %s\r\n", PopUser[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);
	
	sprintf(temp, "> %s", data);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
	memset(&data, 0, sizeof(data));
	// Receive data
	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);
	
	sprintf(temp, "> %s", data);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	// First three should be +OK
	if (strncmp(data, "+OK", 3) && !QUITTING)
		return closeup(1);
	
	// Send the password
	sprintf(data, "PASS %s\r\n", PopPass[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);
	
	strcat(Status, "> PASS ********");
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
	memset(&data, 0, sizeof(data));

	// Receive data
	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);

	sprintf(temp, "\r\n> %s", data);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	// First three should be +OK
	if (strncmp(data, "+OK", 3) && !QUITTING)
		return closeup(1);
	memset(&data, 0, sizeof(data));
	// Send STAT
	sprintf(data, "STAT\r\n");
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);
	
	strcat(Status, "> STAT");
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
	memset(&data, 0, sizeof(data));
	// Receive data
	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);

	sprintf(temp, "\r\n> %s", data);
	strcat(Status, temp);
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	// First three should be +OK
	if (strncmp(data, "+OK", 3) && !QUITTING)
		return closeup(1);
	// Get the number of messages
	sscanf(data, "+OK %d", &nMessages[loop]);
	// Send quit
	sprintf(data, "QUIT\r\n");
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR && !QUITTING) 
		return closeup(1);

	strcat(Status, "> QUIT");
	if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);

	if (loop < 2 && *PopServer[loop+1] && !QUITTING) // replace 2 by number of alloc'd strings - 1 if you want to use unlimited accounts
		// close the socket since it's re-allocated at next loop
		closesocket(mysocket);

	if (!QUITTING)
	{
		if (oldnmsg[loop] < nMessages[loop])
		{
			STATUS=NEWMAIL;
			PlayMovie(NewMailMovie);
			strcat(Status, "\r\n> New Mail!!!");
			if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
			if (ALERT && !QUITTING) 
			{
				strcat(Status, "\r\nLaunching Alert Box...");
				if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
				sprintf(temp,"You have %d new messages on %s\nWould you like to launch your e-mail client?",nMessages[loop]-oldnmsg[loop],PopServer[loop]);
				reply = MessageBox(0,temp,"New Mail Has Arrived", MB_YESNO | MB_DEFBUTTON2 | MB_ICONQUESTION | MB_SETFOREGROUND);
				if (reply == IDYES && !QUITTING) 
				{
					strcat(Status, "\r\nLaunching E-mail Client...");
					if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
					SendMessage(hMainWnd, WM_COMMAND, 101, 0);
				}
			}
		}
		else
		{
			if (PREVSTATUS == IDLE)
			{
				STATUS=IDLE;
				PlayMovie(NoMailMovie);
				strcat(Status, "\r\n> No new mail...\r\n> Idle...");
				if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
			}
			else if (PREVSTATUS == NEWMAIL)
			{
				STATUS=NEWMAIL;
				PlayMovie(NewMailMovie);
			}
		}
	}
closeup(0);
}
return(0);
}

/*********************************************************************/
/* Close TCP connection                                              */
/*********************************************************************/
int closeup(int err)
{
	if (socketinit)
		closesocket(mysocket);

	WSACleanup();
	
	if (err == 1 && !QUITTING && STATUS == CHECKING)
	{
		STATUS=IDLE;
		PlayMovie(NoMailMovie);
		strcat(Status, "\r\n> Closing connection...\r\n> Idle...");
		if (hStatusEditWnd) SetWindowText(hStatusEditWnd, Status);
	}

	if (err != 2) thread=NULL;
	return 0;
}

void Say(char* what)
{
	MessageBox(NULL, what, szAppName, MB);
}

int PlayMovie(char* file)
{
	char temp[256] = "";
	if (file[0] != '\0')
	{
		mciSendString("close movie", NULL, 0, NULL);
		sprintf(temp, "open %s type avivideo alias movie", file);
		if (!mciSendString(temp, NULL, 0, NULL) && !QUITTING)
		{
			sprintf(temp, "window movie handle %d", hMainWnd);
			if (mciSendString(temp, NULL, 0, NULL))
				return 0;
			if (mciSendString("put movie destination at 0 0 64 64", NULL, 0, NULL))
				return 0;

			if (STATUS != IDLE)
				mciSendString("play movie from 0 repeat", NULL, 0, NULL);
			else
				mciSendString("play movie from 0", NULL, 0, NULL);
		}
	}
	return 1;
}

char* Crypt(char* Pass)
{
	int key = 0x5405;
	int i=0;
	char crypt[10] = "";

	for (i = 0; i < (int)strlen(Pass); i++) 
		Pass[i] = Pass[i] ^ key;

	return Pass;
}

int EditSettings()
{
	char temp[256] = "";

	hEditWnd = CreateWindowEx(0,"EditSettings","LSMail Settings",WS_POPUPWINDOW | WS_DLGFRAME,
								GetSystemMetrics(SM_CXSCREEN)/2 - 200, 
								GetSystemMetrics(SM_CYSCREEN)/2 - 150, 
								400,300,parent,NULL,Instance,0);
	if (!hEditWnd) return 0;

	hOptionsWnd = CreateWindowEx(0,"EditSettings","",WS_CHILD,0,40,400,200,hEditWnd,NULL,Instance,0);
	if (!hOptionsWnd) return 0;

	hVideosWnd = CreateWindowEx(0,"EditSettings","",WS_CHILD,0,40,400,200,hEditWnd,NULL,Instance,0);
	if (!hVideosWnd) return 0;

	hServer1Wnd = CreateWindowEx(0,"EditSettings","",WS_CHILD,0,40,400,200,hEditWnd,NULL,Instance,0);
	if (!hServer1Wnd) return 0;
	hServer2Wnd = CreateWindowEx(0,"EditSettings","",WS_CHILD,0,40,400,200,hEditWnd,NULL,Instance,0);
	if (!hServer2Wnd) return 0;
	hServer3Wnd = CreateWindowEx(0,"EditSettings","",WS_CHILD,0,40,400,200,hEditWnd,NULL,Instance,0);
	if (!hServer3Wnd) return 0;
	
	//
	// Buttons
	//
	hbOptionsWnd = CreateWindowEx(0,"Button","Options",WS_CHILD | BS_RADIOBUTTON | BS_PUSHLIKE,
								10,10,75,23,hEditWnd,NULL,Instance,0);
	if (!hbOptionsWnd) return 0;

	hbVideosWnd = CreateWindowEx(0,"Button","Videos",WS_CHILD | BS_RADIOBUTTON | BS_PUSHLIKE,
								85,10,75,23,hEditWnd,NULL,Instance,0);
	if (!hbVideosWnd) return 0;

	hbServer1Wnd = CreateWindowEx(0,"Button","Server 1",WS_CHILD | BS_RADIOBUTTON | BS_PUSHLIKE,
								160,10,75,23,hEditWnd,NULL,Instance,0);
	if (!hbServer1Wnd) return 0;

	hbServer2Wnd = CreateWindowEx(0,"Button","Server 2",WS_CHILD | BS_RADIOBUTTON | BS_PUSHLIKE,
								235,10,75,23,hEditWnd,NULL,Instance,0);
	if (!hbServer2Wnd) return 0;

	hbServer3Wnd = CreateWindowEx(0,"Button","Server 3",WS_CHILD | BS_RADIOBUTTON | BS_PUSHLIKE,
								310,10,75,23,hEditWnd,NULL,Instance,0);
	if (!hbServer3Wnd) return 0;

	hbOkWnd = CreateWindowEx(0,"Button","Ok",WS_CHILD | BS_PUSHBUTTON,
								125,240,50,23,hEditWnd,NULL,Instance,0);
	if (!hbOkWnd) return 0;

	hbCancelWnd = CreateWindowEx(0,"Button","Cancel",WS_CHILD | BS_PUSHBUTTON,
								225,240,50,23,hEditWnd,NULL,Instance,0);
	if (!hbCancelWnd) return 0;

	//
	// Options Windows
	//
	sIntervalWnd = CreateWindowEx(0,"Static","Interval:",WS_CHILD,
								10,10,100,20,hOptionsWnd,NULL,Instance,0);
	if (!sIntervalWnd) return 0;
	sprintf(temp, "%d", Timeout);
	hIntervalWnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								110,10,150,20,hOptionsWnd,NULL,Instance,0);
	if (!hIntervalWnd) return 0;

	/*
	sAlertWnd = CreateWindowEx(0,"Static","Alert Box:",WS_CHILD,
								10,40,100,20,hOptionsWnd,NULL,Instance,0);
	if (!sAlertWnd) return 0;
	sprintf(temp, "%d", ALERT);
	hAlertWnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								110,40,150,20,hOptionsWnd,NULL,Instance,0);
	if (!hAlertWnd) return 0;

	sCheckWnd = CreateWindowEx(0,"Static","Check Mail:",WS_CHILD,
								10,70,100,20,hOptionsWnd,NULL,Instance,0);
	if (!sCheckWnd) return 0;
	sprintf(temp, "%d", CHECKMAIL);
	hCheckWnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								110,70,150,20,hOptionsWnd,NULL,Instance,0);
	if (!hCheckWnd) return 0;
	*/
	sClientWnd = CreateWindowEx(0,"Static","Mail Client:",WS_CHILD,
								10,40,100,20,hOptionsWnd,NULL,Instance,0);
	if (!sClientWnd) return 0;
	hClientWnd = CreateWindowEx(0,"Edit",MailClient,WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								110,40,250,20,hOptionsWnd,NULL,Instance,0);
	if (!hClientWnd) return 0;

	//
	// Videos Windows
	//
	sCheckMailWnd = CreateWindowEx(0,"Static","CheckMail Video:",WS_CHILD,
								10,10,150,20,hVideosWnd,NULL,Instance,0);
	if (!sCheckMailWnd) return 0;
	hCheckMailWnd = CreateWindowEx(0,"Edit",CheckMailMovie,WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								150,10,225,20,hVideosWnd,NULL,Instance,0);
	if (!hCheckMailWnd) return 0;

	sNewMailWnd = CreateWindowEx(0,"Static","NewMail Video:",WS_CHILD,
								10,40,150,20,hVideosWnd,NULL,Instance,0);
	if (!sNewMailWnd) return 0;
	hNewMailWnd = CreateWindowEx(0,"Edit",NewMailMovie,WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								150,40,225,20,hVideosWnd,NULL,Instance,0);
	if (!hNewMailWnd) return 0;

	sNoMailWnd = CreateWindowEx(0,"Static","NoMail Video:",WS_CHILD,
								10,70,150,20,hVideosWnd,NULL,Instance,0);
	if (!sNoMailWnd) return 0;
	hNoMailWnd = CreateWindowEx(0,"Edit",NoMailMovie,WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								150,70,225,20,hVideosWnd,NULL,Instance,0);
	if (!hNoMailWnd) return 0;
	
	//
	// Server Windows
	//
	sPopServer1Wnd = CreateWindowEx(0,"Static","Pop3 Server:",WS_CHILD,
								10,10,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sPopServer1Wnd) return 0;
	hPopServer1Wnd = CreateWindowEx(0,"Edit",PopServer[0],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,10,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hServer1Wnd) return 0;

	sPort1Wnd = CreateWindowEx(0,"Static","Port:",WS_CHILD,
								10,40,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sPort1Wnd) return 0;
	sprintf(temp, "%d", PopPort[0]);
	hPort1Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,40,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hPort1Wnd) return 0;
	
	sLogin1Wnd = CreateWindowEx(0,"Static","Login:",WS_CHILD,
								10,70,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sLogin1Wnd) return 0;
	hLogin1Wnd = CreateWindowEx(0,"Edit",PopUser[0],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,70,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hLogin1Wnd) return 0;

	sPass1Wnd = CreateWindowEx(0,"Static","Password:",WS_CHILD,
								10,100,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sPass1Wnd) return 0;
	hPass1Wnd = CreateWindowEx(0,"Edit",PopPass[0],WS_CHILD | ES_AUTOHSCROLL | ES_PASSWORD | WS_BORDER | WS_TABSTOP,
								100,100,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hPass1Wnd) return 0;

	/*
	sPenX1Wnd = CreateWindowEx(0,"Static","Pen X:",WS_CHILD,
								10,130,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sPenX1Wnd) return 0;
	sprintf(temp, "%d", penX[0]);
	hPenX1Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,130,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hPenX1Wnd) return 0;

	sPenY1Wnd = CreateWindowEx(0,"Static","Pen Y:",WS_CHILD,
								10,160,100,20,hServer1Wnd,NULL,Instance,0);
	if (!sPenY1Wnd) return 0;
	sprintf(temp, "%d", penY[0]);
	hPenY1Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,160,250,20,hServer1Wnd,NULL,Instance,0);
	if (!hPenY1Wnd) return 0;
	*/

	// Server Two
	sPopServer2Wnd = CreateWindowEx(0,"Static","Pop3 Server:",WS_CHILD,
								10,10,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sPopServer2Wnd) return 0;
	hPopServer2Wnd = CreateWindowEx(0,"Edit",PopServer[1],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,10,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hServer2Wnd) return 0;

	sPort2Wnd = CreateWindowEx(0,"Static","Port:",WS_CHILD,
								10,40,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sPort2Wnd) return 0;
	sprintf(temp, "%d", PopPort[1]);
	hPort2Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,40,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hPort2Wnd) return 0;
	
	sLogin2Wnd = CreateWindowEx(0,"Static","Login:",WS_CHILD,
								10,70,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sLogin2Wnd) return 0;
	hLogin2Wnd = CreateWindowEx(0,"Edit",PopUser[1],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,70,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hLogin2Wnd) return 0;

	sPass2Wnd = CreateWindowEx(0,"Static","Password:",WS_CHILD,
								10,100,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sPass2Wnd) return 0;
	hPass2Wnd = CreateWindowEx(0,"Edit",PopPass[1],WS_CHILD | ES_AUTOHSCROLL | ES_PASSWORD | WS_BORDER | WS_TABSTOP,
								100,100,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hPass2Wnd) return 0;

	/*
	sPenX2Wnd = CreateWindowEx(0,"Static","Pen X:",WS_CHILD,
								10,130,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sPenX2Wnd) return 0;
	sprintf(temp, "%d", penX[1]);
	hPenX2Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,130,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hPenX2Wnd) return 0;

	sPenY2Wnd = CreateWindowEx(0,"Static","Pen Y:",WS_CHILD,
								10,160,100,20,hServer2Wnd,NULL,Instance,0);
	if (!sPenY2Wnd) return 0;
	sprintf(temp, "%d", penY[1]);
	hPenY2Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,160,250,20,hServer2Wnd,NULL,Instance,0);
	if (!hPenY2Wnd) return 0;
	*/

	// Server Three
	sPopServer3Wnd = CreateWindowEx(0,"Static","Pop3 Server:",WS_CHILD,
								10,10,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sPopServer3Wnd) return 0;
	hPopServer3Wnd = CreateWindowEx(0,"Edit",PopServer[2],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,10,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hServer3Wnd) return 0;

	sPort3Wnd = CreateWindowEx(0,"Static","Port:",WS_CHILD,
								10,40,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sPort3Wnd) return 0;
	sprintf(temp, "%d", PopPort[2]);
	hPort3Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,40,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hPort3Wnd) return 0;
	
	sLogin3Wnd = CreateWindowEx(0,"Static","Login:",WS_CHILD,
								10,70,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sLogin3Wnd) return 0;
	hLogin3Wnd = CreateWindowEx(0,"Edit",PopUser[2],WS_CHILD | ES_AUTOHSCROLL | WS_BORDER | WS_TABSTOP,
								100,70,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hLogin3Wnd) return 0;

	sPass3Wnd = CreateWindowEx(0,"Static","Password:",WS_CHILD,
								10,100,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sPass3Wnd) return 0;
	hPass3Wnd = CreateWindowEx(0,"Edit",PopPass[2],WS_CHILD | ES_AUTOHSCROLL | ES_PASSWORD | WS_BORDER | WS_TABSTOP,
								100,100,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hPass3Wnd) return 0;

	/*
	sPenX3Wnd = CreateWindowEx(0,"Static","Pen X:",WS_CHILD,
								10,130,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sPenX3Wnd) return 0;
	sprintf(temp, "%d", penX[2]);
	hPenX3Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,130,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hPenX3Wnd) return 0;

	sPenY3Wnd = CreateWindowEx(0,"Static","Pen Y:",WS_CHILD,
								10,160,100,20,hServer3Wnd,NULL,Instance,0);
	if (!sPenY3Wnd) return 0;
	sprintf(temp, "%d", penY[2]);
	hPenY3Wnd = CreateWindowEx(0,"Edit",temp,WS_CHILD | ES_NUMBER | WS_BORDER | WS_TABSTOP,
								100,160,250,20,hServer3Wnd,NULL,Instance,0);
	if (!hPenY3Wnd) return 0;
	*/

	ShowWindow(hEditWnd, SW_SHOWNORMAL);
	ShowWindow(hbOkWnd, SW_SHOWNORMAL);
	ShowWindow(hbCancelWnd, SW_SHOWNORMAL);
	ShowWindow(hbOptionsWnd, SW_SHOWNORMAL);
	ShowWindow(hbVideosWnd, SW_SHOWNORMAL);
	ShowWindow(hbServer1Wnd, SW_SHOWNORMAL);
	ShowWindow(hbServer2Wnd, SW_SHOWNORMAL);
	ShowWindow(hbServer3Wnd, SW_SHOWNORMAL);
	PostMessage(hEditWnd, WM_COMMAND, (WPARAM)NULL, (LPARAM)hbOptionsWnd);
	return 1;
}

LRESULT CALLBACK SettingsProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT r;
			HBRUSH hbr = CreateSolidBrush(0x00C0C0C0);
			HDC hdc = BeginPaint(hwnd, &ps);
			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, hbr);
			EndPaint(hwnd, &ps);
			DeleteObject(hbr);
		}
		return 0;
		case WM_COMMAND:
			if ((HWND)lParam == hbOptionsWnd)
			{
				SetWindowText(hEditWnd, "LSMail Settings - Options");
				EnumChildWindows(hEditWnd, HideChildProc, (LPARAM)NULL);
				ShowWindow(hOptionsWnd, SW_SHOWNORMAL);
				EnumChildWindows(hOptionsWnd, ShowChildProc, (LPARAM)NULL);
			}
			else if ((HWND)lParam == hbVideosWnd)
			{
				SetWindowText(hEditWnd, "LSMail Settings - Videos");
				EnumChildWindows(hEditWnd, HideChildProc, (LPARAM)NULL);
				ShowWindow(hVideosWnd, SW_SHOWNORMAL);
				EnumChildWindows(hVideosWnd, ShowChildProc, (LPARAM)NULL);
			}
			else if ((HWND)lParam == hbServer1Wnd)
			{
				SetWindowText(hEditWnd, "LSMail Settings - Server 1");
				EnumChildWindows(hEditWnd, HideChildProc, (LPARAM)NULL);
				ShowWindow(hServer1Wnd, SW_SHOWNORMAL);
				EnumChildWindows(hServer1Wnd, ShowChildProc, (LPARAM)NULL);
			}
			else if ((HWND)lParam == hbServer2Wnd)
			{
				SetWindowText(hEditWnd, "LSMail Settings - Server 2");
				EnumChildWindows(hEditWnd, HideChildProc, (LPARAM)NULL);
				ShowWindow(hServer2Wnd, SW_SHOWNORMAL);
				EnumChildWindows(hServer2Wnd, ShowChildProc, (LPARAM)NULL);
			}
			else if ((HWND)lParam == hbServer3Wnd)
			{
				SetWindowText(hEditWnd, "LSMail Settings - Server 3");
				EnumChildWindows(hEditWnd, HideChildProc, (LPARAM)NULL);
				ShowWindow(hServer3Wnd, SW_SHOWNORMAL);
				EnumChildWindows(hServer3Wnd, ShowChildProc, (LPARAM)NULL);
			}
			else if ((HWND)lParam == hbOkWnd)
			{
				GetSettings();
				SaveSettings();
				PostMessage(hEditWnd, WM_CLOSE, (WPARAM)NULL, (LPARAM)NULL);
				hEditWnd=NULL;
				if (CHECKMAIL) SetTimer(hMainWnd, 0, Timeout*60000, NULL);
			}
			else if ((HWND)lParam == hbCancelWnd)
			{
				PostMessage(hEditWnd, WM_CLOSE, (WPARAM)NULL, (LPARAM)NULL);
				hEditWnd=NULL;
				if (CHECKMAIL) SetTimer(hMainWnd, 0, Timeout*60000, NULL);
			}
		return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

BOOL CALLBACK HideChildProc(HWND hwnd,LPARAM lParam)
{
	if (hwnd != hbOkWnd &&
		hwnd != hbCancelWnd &&
		hwnd != hbOptionsWnd &&
		hwnd != hbVideosWnd &&
		hwnd != hbServer1Wnd &&
		hwnd != hbServer2Wnd &&
		hwnd != hbServer3Wnd)
		ShowWindow(hwnd, SW_HIDE);
	return TRUE;
}

BOOL CALLBACK ShowChildProc(HWND hwnd,LPARAM lParam)
{
	ShowWindow(hwnd, SW_SHOWNORMAL);
	return TRUE;
}

int GetSettings()
{
	char temp[256] = "";
	int x=0;

	GetWindowText(hIntervalWnd, temp, 256);
	Timeout = atoi(temp);
	
	//GetWindowText(hAlertWnd, temp, 256);
	//ALERT = atoi(temp);
	//if (ALERT != 1 && ALERT != 0) ALERT=1;
	
	//GetWindowText(hCheckWnd, temp, 256);
	//CHECKMAIL = atoi(temp);
	//if (CHECKMAIL != 1 && CHECKMAIL != 0) CHECKMAIL=1;
	
	GetWindowText(hClientWnd, MailClient, MAX_PATH);
	GetWindowText(hCheckMailWnd, CheckMailMovie, MAX_PATH);
	GetWindowText(hNewMailWnd, NewMailMovie, MAX_PATH);
	GetWindowText(hNoMailWnd, NoMailMovie, MAX_PATH);
	
	x=0;
	GetWindowText(hPopServer1Wnd, PopServer[x], 256);
	GetWindowText(hPort1Wnd, temp, 256);
	PopPort[x] = atoi(temp);
	GetWindowText(hLogin1Wnd, PopUser[x], 256);;
	GetWindowText(hPass1Wnd, PopPass[x], 256);
	//GetWindowText(hPenX1Wnd, temp, 256);
	//penX[x] = atoi(temp);
	//GetWindowText(temp, temp, 256);
	//penY[x] = atoi(temp);
	x=1;
	GetWindowText(hPopServer2Wnd, PopServer[x], 256);
	GetWindowText(hPort2Wnd, temp, 256);
	PopPort[x] = atoi(temp);
	GetWindowText(hLogin2Wnd, PopUser[x], 256);;
	GetWindowText(hPass2Wnd, PopPass[x], 256);
	//GetWindowText(hPenX2Wnd, temp, 256);
	//penX[x] = atoi(temp);
	//GetWindowText(temp, temp, 256);
	//penY[x] = atoi(temp);
	x=2;
	GetWindowText(hPopServer3Wnd, PopServer[x], 256);
	GetWindowText(hPort3Wnd, temp, 256);
	PopPort[x] = atoi(temp);
	GetWindowText(hLogin3Wnd, PopUser[x], 256);;
	GetWindowText(hPass3Wnd, PopPass[x], 256);
	//GetWindowText(hPenX3Wnd, temp, 256);
	//penX[x] = atoi(temp);
	//GetWindowText(temp, temp, 256);
	//penY[x] = atoi(temp);
	return 0;
}

int SaveSettings()
{
	int a;
	char BaseName[256] = "";
	char temp[256] = "";

	sprintf(temp, "%d", Timeout);
	WritePrivateProfileString("LSMail", "Interval", temp, ini);

	sprintf(temp, "%d", ALERT);
	WritePrivateProfileString("LSMail", "AlertBox", temp, ini);
	
	sprintf(temp, "%d", CHECKMAIL);
	WritePrivateProfileString("LSMail", "CheckMail", temp, ini);
	
	WritePrivateProfileString("LSMail", "MailClient", MailClient, ini);

	WritePrivateProfileString("LSMail", "NoMailMovie", NoMailMovie, ini);
	
	WritePrivateProfileString("LSMail", "NewMailMovie", NewMailMovie, ini);

	WritePrivateProfileString("LSMail", "CheckMailMovie", CheckMailMovie, ini);

	for (a=0;a<3;a++)
	{
		sprintf(BaseName, "Pop_Port_%d", a+1);
		sprintf(temp, "%d", PopPort[a]);
		WritePrivateProfileString("LSMail", BaseName, temp, ini);

		sprintf(BaseName, "Pop_Server_%d", a+1);
		WritePrivateProfileString("LSMail", BaseName, PopServer[a], ini);

		sprintf(BaseName, "Pop_User_%d", a+1);
		WritePrivateProfileString("LSMail", BaseName, PopUser[a], ini);

		sprintf(BaseName, "Pop_Password_%d", a+1);
		strcpy(temp, PopPass[a]);
		WritePrivateProfileString("LSMail", BaseName, Crypt(temp), ini);
		/*
		sprintf(BaseName, "PenX_%d", a+1);
		sprintf(temp, "%d", penX[a]);
		WritePrivateProfileString("LSMail", BaseName, temp, ini);
		
		sprintf(BaseName, "PenY_%d", a+1);
		sprintf(temp, "%d", penY[a]);
		WritePrivateProfileString("LSMail", BaseName, temp, ini);
		*/
	}
	return 0;
}
