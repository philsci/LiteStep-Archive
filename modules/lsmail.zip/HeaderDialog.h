// HeaderDialog.h: interface for the HeaderDialog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEADERDIALOG_H__26E04463_0639_11D2_9A42_00207810D8C3__INCLUDED_)
#define AFX_HEADERDIALOG_H__26E04463_0639_11D2_9A42_00207810D8C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class HeaderDialog  ()
{
public:
	HeaderDialog();
	virtual ~HeaderDialog();

};

#endif // !defined(AFX_HEADERDIALOG_H__26E04463_0639_11D2_9A42_00207810D8C3__INCLUDED_)
