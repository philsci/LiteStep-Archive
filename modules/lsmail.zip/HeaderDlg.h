// HeaderDlg.h: interface for the HeaderDlg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HEADERDLG_H__CF01C2A0_0638_11D2_9A42_00207810D8C3__INCLUDED_)
#define AFX_HEADERDLG_H__CF01C2A0_0638_11D2_9A42_00207810D8C3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class HeaderDlg  
{
public:
	HeaderDlg();
	virtual ~HeaderDlg();

};

#endif // !defined(AFX_HEADERDLG_H__CF01C2A0_0638_11D2_9A42_00207810D8C3__INCLUDED_)
