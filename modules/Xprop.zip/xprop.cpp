#include <windows.h>
#include <lsapi.h>
#include "exports.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
VOID CALLBACK TimerMouse(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime);
void LoadSetup();
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

int magnify=2;
int ScreenX, ScreenY;
char* szAppName = "xprop";
HWND hwndMain, hwndDesktop, hwndParent;
HBITMAP hbmpBG;
BITMAP bmpBG;
HFONT font;
HPEN pen;
POINT p, o;
COLORREF text_color, crosshair_color;
char format[256] = "";
int timer, offset_x, offset_y;
int x, y;
int mag_x, mag_y, mag_w, mag_h;
int text_x, text_y, text_w, text_h;
int crosshair_size;
BOOL FOLLOW=TRUE, LOCKED=FALSE, FROZEN=FALSE;

void BangZoomIn(HWND caller, const char* args)
{
	magnify*=2;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangZoomOut(HWND caller, const char* args)
{
	magnify/=2;
	if (magnify == 0) magnify=1;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangShow(HWND caller, const char* args) 
{
	SetTimer(hwndMain, 0, timer, (TIMERPROC)TimerMouse);
	ShowWindow(hwndMain, SW_SHOW); 
}

void BangHide(HWND caller, const char* args) 
{ 
	ShowWindow(hwndMain, SW_HIDE);
	KillTimer(hwndMain, 0);
}

void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangSetOrigin(HWND caller, const char* args) 
{ 
	o = p;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangResetOrigin(HWND caller, const char* args) 
{ 
	o.x = 0;
	o.y = 0;
	InvalidateRect(hwndMain, NULL, TRUE);
}

void BangLock(HWND caller, const char* args)
{
	if (LOCKED)
	{
		LOCKED=FALSE;
	}
	else
	{
		LOCKED=TRUE;
	}
}

void BangFreeze(HWND caller, const char* args)
{
	if (FROZEN)
	{
		FROZEN=FALSE;
	}
	else
	{
		FROZEN=TRUE;
	}
}

VOID CALLBACK TimerMouse(HWND hwnd, UINT uMsg, UINT_PTR idEvent, DWORD dwTime)
{
	POINT np;
	GetCursorPos(&np);

	if (p.x != np.x || p.y != np.y)
	{
		p = np;
		if (!LOCKED) SetWindowPos(hwndMain, HWND_TOPMOST, p.x+offset_x, p.y+offset_y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
	}

	if (!FROZEN) InvalidateRect(hwndMain, NULL, TRUE);
}

void LoadSetup()
{
	char temp[256] = "";
	int itemp;

	o.x = 0;
	o.y = 0;

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);
	hwndDesktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!hwndDesktop) hwndDesktop = GetDesktopWindow();
	if (!hwndDesktop)
	{
		MessageBox(NULL, "Error: Could not locate the desktop window", szAppName, MB_OK | MB_ICONERROR);
		return;
	}

	AddBangCommand("!XPropZoomIn", BangZoomIn);
	AddBangCommand("!XPropZoomOut", BangZoomOut);
	AddBangCommand("!XPropShow", BangShow);
	AddBangCommand("!XPropHide", BangHide);
	AddBangCommand("!XPropToggle", BangToggle);
	AddBangCommand("!XPropSetOrigin", BangSetOrigin);
	AddBangCommand("!XPropResetOrigin", BangResetOrigin);
	AddBangCommand("!XPropFreeze", BangFreeze);
	AddBangCommand("!XPropLock", BangLock);

	crosshair_size = GetRCInt("XPropCrosshairSize", 10);
	crosshair_color = GetRCColor("XPropCrosshairColor", 0x00000000);
	pen = CreatePen(PS_DOT, 0, crosshair_color);
	
	timer = GetRCInt("XPropTimer", 50);
	offset_x = GetRCInt("XPropOffsetX", 25);
	offset_y = GetRCInt("XPropOffsetY", 25);

	x = GetRCInt("XPropX", 0);
	y = GetRCInt("XPropY", 0);
	LOCKED = GetRCBool("XPropStartLocked", TRUE);

	mag_x = GetRCInt("XPropMagWindowX", 6);
	mag_y = GetRCInt("XPropMagWindowY", 6);
	mag_w = GetRCInt("XPropMagWindowW", 63);
	mag_h = GetRCInt("XPropMagWindowH", 63);

	text_x = GetRCInt("XPropTextWindowX", 7);
	text_y = GetRCInt("XPropTextWindowY", 71);
	text_w = GetRCInt("XPropTextWindowW", 61);
	text_h = GetRCInt("XPropTextWindowH", 31);

	itemp = GetRCInt("XPropFontSize", 11);
	GetRCString("XPropFontFace", temp, "Arial", 256);
	font = CreateFont(itemp, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	GetRCString("XPropFormat", format, "X: %d Y: %d\nR: %d G: %d\nB: %d - #%06lx", 256);
	char* c;
	while ((c = strstr(format, "\\n")) != NULL)
	{
		char* q;
		*c='\n';
		c++;
		for (q=c+1; *q; q++, c++)
		{
			*c = *q;
		}
		*c = '\0';
	}
	text_color = GetRCColor("XPropFontColor", 0x00000000);

	GetRCString("XPropBG", temp, "xprop.bmp", 256);
	hbmpBG = LoadLSImage(temp, temp);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	hwndParent = parent;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	if (hbmpBG)
	{
		int msgs[] = {LM_GETREVID, 0};

		GetObject(hbmpBG, sizeof(bmpBG), &bmpBG);

		hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
								  szAppName, szAppName, 
								  WS_POPUP, 
								  x, y, 
								  bmpBG.bmWidth, bmpBG.bmHeight, 
								  NULL, NULL, dllInst, NULL);
		
		if (!hwndMain) return 1;

		if (GetRCBool("XPropNotAlwaysOnTop", FALSE))
		{
			SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}

		SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

		SetWindowBitmapRgn(hwndMain, hbmpBG);

		if (GetRCBool("XPropStartHidden", FALSE))
		{
			SetTimer(hwndMain, 0, timer, (TIMERPROC)TimerMouse);
			ShowWindow(hwndMain, SW_SHOWNORMAL);
		}
	}
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	int msgs[] = {LM_GETREVID, 0};

	RemoveBangCommand("!XPropZoomIn");
	RemoveBangCommand("!XPropZoomOut");
	RemoveBangCommand("!XPropShow");
	RemoveBangCommand("!XPropHide");
	RemoveBangCommand("!XPropToggle");
	RemoveBangCommand("!XPropSetOrigin");
	RemoveBangCommand("!XPropResetOrigin");
	RemoveBangCommand("!XPropFreeze");
	RemoveBangCommand("!XPropLock");
	DeleteObject(hbmpBG);
	DeleteObject(font);
	DeleteObject(pen);
	KillTimer(hwndMain, 0);

	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	DestroyWindow(hwndMain);

	UnregisterClass(szAppName, dll);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == LM_GETREVID)
	{
		LPSTR buf = (LPSTR)(lParam);

		switch (wParam)
		{
			case 0:
				sprintf(buf, "XProp 1.1 (MrJukes)\0");
			break;
			case 1:
				sprintf(buf, "XProp 1.1 (MrJukes)\0");
			break;
			default:
				sprintf(buf, "XProp 1.1 (MrJukes)\0");
		}
		return strlen(buf);
	}

	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case WM_NCHITTEST: return HTCAPTION;

		case WM_NCPAINT:
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC ddc = GetWindowDC(hwndDesktop);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbuf, oldsrc;
			COLORREF pix;
			RECT r;
			char to[256] = "";
			
			bufbmp = CreateCompatibleBitmap(hdc, bmpBG.bmWidth, bmpBG.bmHeight);
			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrc = (HBITMAP)SelectObject(src, hbmpBG);
			BitBlt(buf, 0, 0, bmpBG.bmWidth, bmpBG.bmHeight, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrc);

			if (!FROZEN) 
			{
				StretchBlt(buf, mag_x, mag_y, mag_w, mag_h, ddc, p.x-mag_w/(magnify*2), p.y-mag_h/(magnify*2), mag_w/magnify, mag_h/magnify, SRCCOPY);

				SelectObject(buf, font);
				SetBkMode(buf, TRANSPARENT);
				SetTextColor(buf, text_color);
				pix = GetPixel(buf, mag_x+(mag_w/2), mag_y+(mag_h/2));
				sprintf(to, format, p.x-o.x, p.y-o.y, GetRValue(pix), GetGValue(pix), GetBValue(pix), RGB(GetBValue(pix), GetGValue(pix), GetRValue(pix)));
				SetRect(&r, text_x, text_y, text_x+text_w, text_y+text_h);
				DrawText(buf, to, strlen(to), &r, DT_EDITCONTROL | DT_WORDBREAK | DT_NOCLIP);
			}

			SelectObject(buf, pen);
			MoveToEx(buf, mag_x+(mag_w/2), mag_y+(mag_h/2)-crosshair_size, NULL);
			LineTo(buf, mag_x+(mag_w/2), mag_y+(mag_h/2)+crosshair_size);
			MoveToEx(buf, mag_x+(mag_w/2)-crosshair_size, mag_y+(mag_h/2), NULL);
			LineTo(buf, mag_x+(mag_w/2)+crosshair_size, mag_y+(mag_h/2));

			BitBlt(hdc, 0, 0, bmpBG.bmWidth, bmpBG.bmHeight, buf, 0, 0, SRCCOPY);

			DeleteDC(src);
			DeleteObject(oldsrc);
			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbuf);
			ReleaseDC(hwndDesktop, ddc);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;

			if (pos->x < 0) pos->x = 0;
			else if (pos->x + bmpBG.bmWidth > ScreenX) 
			{
				if (!LOCKED) pos->x = p.x - bmpBG.bmWidth - offset_x;
				else pos->x = ScreenX - bmpBG.bmWidth;
			}

			if (pos->y < 0) pos->y = 0;
			else if (pos->y + bmpBG.bmHeight > ScreenY) 
			{
				if (!LOCKED) pos->y = p.y - bmpBG.bmHeight - offset_y;
				else pos->y = ScreenY - bmpBG.bmHeight;
			}
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, TRUE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, TRUE);
	}
}