LSPower
limpid - limpid@w2s.com
http://www.v-active.com/litestep/
-----------------------------

LSPower is a wharf module that displays your current battery usage (for 
laptops). it is *very* customizable, allowing you to put anything, 
anwhere on the module and change all the colors and fonts and stuff.
this was the first module for ls that i wrote and i wrote it a long time 
ago (never released it until just recently though). because of this, it 
is probably coded poorly but it does work :)

this module is configured in modules.ini:
(all colors are rgb)

[LSPower]
iconX=10
iconY=7
percentX=34
percentY=7
percentSize=16
percentColor=255 255 255
percentFontFace=Arial
timeX=6
timeY=27
timeSize=13
timeColor=255 255 255
timeFontFace=Arial
meterX=5
meterY=45
meterWidth=55
meterHeight=10
meterBorderColor=255 255 255
meterBGColor=0 0 0
meterFGColor=128 128 128

play around it with... you can make it look pretty much however you want.
i havent used it in a *long* time... theres probably some features i dont even
know about.

if you find any bugs, too bad (sorry).
im doing anymore development on this mod.