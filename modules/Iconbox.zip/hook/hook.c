#include <windows.h>
#include <stdio.h>
#include "..\\iconbox.h"

__declspec( dllexport ) HHOOK SetWinHook(HINSTANCE);
__declspec( dllexport ) void Quit();

static LRESULT CALLBACK HookFunction(int code, WPARAM wParam, LPARAM lParam);

HWND MainWnd;
static HHOOK hook;

#pragma data_seg ("STATIC")
HHOOK hook=NULL;
#pragma data_seg ()

HHOOK SetWinHook(HINSTANCE hInstance)
{
	hook = SetWindowsHookEx(WH_CBT, (HOOKPROC)HookFunction, hInstance, 0);
	return hook;
}

void Quit()
{
	UnhookWindowsHookEx(hook);
}

static LRESULT CALLBACK HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	if (code < 0) return CallNextHookEx(hook, code, wParam, lParam);

	switch (code)
	{
		case HCBT_MINMAX:
		{
			if (LOWORD(lParam) == SW_MINIMIZE)
			{
				if (!MainWnd) MainWnd = FindWindowEx(FindWindow("DesktopBackgroundClass", "LSDesktop"), NULL, "LSIconBox", NULL);
				if (!MainWnd) MainWnd = FindWindow("LSIconBox", "LSIconBox");
				//MessageBox(MainWnd, "I am sending", "IconBox", MB_SYSTEMMODAL);
				SendMessage(MainWnd, IB_MIN, wParam, 0);
			}
		}
		break;

		case HCBT_SYSCOMMAND:
		{
			if (wParam == SC_RESTORE)
			{
				SendMessage(MainWnd, IB_RESTORE, 0, 0);
			}
		}
		return 0;
	}

	return 0;
}
