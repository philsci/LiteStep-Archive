/***********************************************************
*        Sample - Sample Litestep Module Code              *
* This single source file is the code to sample.           *
*                         *  *  *  *                       *
* Last Update:  September 27, 1999 10:00 PM                *
*                         *  *  *  *                       *
* Copyright (c) 1999 Shaheen Gandhi                        *
***********************************************************/

#include <windows.h>
#include <commctrl.h>
#include "exports.h"
#include "lsapi.h"
#include "IconBox.h"

char *szAppName = "LSIconBox";
int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

HINSTANCE HookDll;
HHOOK (FAR* HookSetWinHook)(HINSTANCE);
void (FAR* HookQuit)();

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL AddBitmap(HWND);

void BangFocus(HWND caller, char *args);
void BangToggle(HWND caller, char *args);
void BangHide(HWND caller, char *args);
void BangShow(HWND caller, char *args);

struct node
{
	HWND button;
	HWND hwnd;
	HBITMAP bmp;
	int num;
	int width, height;
	BOOL MAX;

	struct node* next;
};

struct stuff
{
	char szPath[MAX_PATH];
	HWND hMainWnd, desktop, parent;
	HINSTANCE hInstance;
	HHOOK hook;
	int ScreenX, ScreenY;
	
	BOOL HIDDEN;
	int current;

	POINT pos, placement;
	int width, height, areawidth, areaheight, iconwidth;
	
	int last;
	int offset;
	int padding;
	int sleeptime;

	HBITMAP left, right, top, bottom, bg, arrowleft, arrowright, scrollgrab, scrolltrack;
	int leftwidth, leftheight, rightwidth, rightheight;
	int topwidth, topheight, bottomwidth, bottomheight, bgwidth, bgheight;
	int arrowleftwidth, arrowleftheight, arrowrightwidth, arrowrightheight;
	int scrollgrabwidth, scrollgrabheight, scrolltrackwidth, scrolltrackheight;
	int scrolltrackx, scrolltracky, scrollgrabx;

	int totalvisible;

	struct node* start;
} settings;

void LoadSettings()
{
	char temp[MAX_PATH] = "";
	char hookpath[MAX_PATH] = "";

	//settings.NOTE_BGCOLOR_MENU = CreatePopupMenu();
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_RED, "&Red");
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_GREEN, "&Green");
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_BLUE, "&Blue");
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_YELLOW, "&Yellow");
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_WHITE, "&White");
	//AppendMenu(settings.NOTE_BGCOLOR_MENU, MF_ENABLED | MF_STRING, M_BG_BLACK, "&Black");

	settings.start = 0;
	settings.HIDDEN = FALSE;

	settings.offset = 0;
	settings.last = 0;
	settings.current = 0;

	settings.ScreenX = GetSystemMetrics(SM_CXSCREEN);
	settings.ScreenY = GetSystemMetrics(SM_CYSCREEN);
	
	settings.desktop = FindWindow("DesktopBackgroundClass", "LSDesktop");

	settings.sleeptime = GetRCInt("IconBoxDelay", 500);
	settings.pos.x = GetRCInt("IconBoxX", 100);
	settings.pos.y = GetRCInt("IconBoxY", 100);
	settings.width = GetRCInt("IconBoxWidth", 194);
	settings.height = GetRCInt("IconBoxHeight", 100);
	
	settings.padding = GetRCInt("IconBoxPadding", 7);
	settings.placement.x = GetRCInt("IconBoxPlacementX", 10);
	settings.placement.y = GetRCInt("IconBoxPlacementY", 24);
	settings.areawidth = GetRCInt("IconBoxAreaWidth", 188);
	settings.areaheight = GetRCInt("IconBoxAreaHeight", 53);
	settings.iconwidth = GetRCInt("IconBoxIconWidth", 53);
	settings.totalvisible = settings.areawidth / settings.iconwidth;

	GetRCString("IconBoxLeftBitmap", temp, "c:\\litestep\\iconbox\\ib_left.bmp", MAX_PATH);
	//settings.left = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.left = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.left, &settings.leftwidth, &settings.leftheight);

	GetRCString("IconBoxRightBitmap", temp, "c:\\litestep\\iconbox\\ib_right.bmp", MAX_PATH);
	//settings.right = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.right = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.right, &settings.rightwidth, &settings.rightheight);

	GetRCString("IconBoxTopBitmap", temp, "c:\\litestep\\iconbox\\ib_top.bmp", MAX_PATH);
	//settings.top = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.top = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.top, &settings.topwidth, &settings.topheight);

	GetRCString("IconBoxBottomBitmap", temp, "c:\\litestep\\iconbox\\ib_bottom.bmp", MAX_PATH);
	//settings.bottom = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.bottom = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.bottom, &settings.bottomwidth, &settings.bottomheight);

	GetRCString("IconBoxBackgroundBitmap", temp, "c:\\litestep\\iconbox\\ib_background.bmp", MAX_PATH);
	//settings.bg = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.bg = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.bg, &settings.bgwidth, &settings.bgheight);

	GetRCString("IconBoxArrowLeftBitmap", temp, "c:\\litestep\\iconbox\\ib_arrowleft.bmp", MAX_PATH);
	//settings.arrowleft = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.arrowleft = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.arrowleft, &settings.arrowleftwidth, &settings.arrowleftheight);
	
	GetRCString("IconBoxArrowRightBitmap", temp, "c:\\litestep\\iconbox\\ib_arrowright.bmp", MAX_PATH);
	//settings.arrowright = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.arrowright = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.arrowright, &settings.arrowrightwidth, &settings.arrowrightheight);

	GetRCString("IconBoxScrollGrabBitmap", temp, "c:\\litestep\\iconbox\\ib_scrollgrab.bmp", MAX_PATH);
	//settings.scrollgrab = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.scrollgrab = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.scrollgrab, &settings.scrollgrabwidth, &settings.scrollgrabheight);

	settings.scrolltrackx = GetRCInt("IconBoxScrollTrackX", 3);
	settings.scrolltracky = GetRCInt("IconBoxScrollTrackY", 80);
	GetRCString("IconBoxScrollTrackBitmap", temp, "c:\\litestep\\iconbox\\ib_scrolltrack.bmp", MAX_PATH);
	//settings.scrolltrack = (HBITMAP)LoadImage(settings.hInstance, temp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	settings.scrolltrack = LoadLSImage(temp, temp);
	GetLSBitmapSize(settings.scrolltrack, &settings.scrolltrackwidth, &settings.scrolltrackheight);

	settings.hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_POPUP | WS_VISIBLE | WS_CLIPCHILDREN, settings.pos.x, settings.pos.y, settings.width, settings.height, settings.desktop, NULL, settings.hInstance, 0);
	SetWindowLong(settings.hMainWnd, GWL_USERDATA, magicDWord);
	SendMessage(settings.parent, LM_REGISTERMESSAGE, (WPARAM)settings.hMainWnd, (LPARAM)msgs);

	GetRCString("IconBoxHookPath", hookpath, "", MAX_PATH);

	if (strlen(hookpath))
	{
		HookDll = LoadLibrary(hookpath);
	}
	else
	{
		sprintf(temp, "%s\\ibhook.dll", settings.szPath);
		HookDll = LoadLibrary(temp);
	}
	if (HookDll)
	{
		HookSetWinHook = (HHOOK (FAR*)(HINSTANCE))GetProcAddress(HookDll, "SetWinHook");
		HookQuit = (void (FAR*)())GetProcAddress(HookDll, "Quit");
		settings.hook = HookSetWinHook(HookDll);
		if (!settings.hook) MessageBox(settings.hMainWnd, "Unable to set windows hook!", szAppName, MB_SYSTEMMODAL);
	}
	else MessageBox(settings.hMainWnd, "Unable to load hook library!", szAppName, MB_SYSTEMMODAL);
}

void RedrawAllIcons()
{
	struct node* p = (struct node*)malloc(sizeof(struct node));

	for (p=settings.start; p; p=p->next)
	{
		InvalidateRect(p->button, NULL, TRUE);
	}

}

void Scroll()
{
	int start, count;

	for (count=0, start=settings.offset; count<settings.totalvisible; count++, start++)
	{
		struct node* p = (struct node*)malloc(sizeof(struct node));

		for (p = settings.start; p; p=p->next)
		{
			if (p->num - settings.offset < 0)
			{
				SetWindowPos(p->button, 0, settings.placement.x, settings.height + 50, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			}
			else if (p->num - settings.offset >= settings.totalvisible)
			{
				SetWindowPos(p->button, 0, (settings.totalvisible-1) * (settings.iconwidth+settings.padding) + settings.placement.x, settings.height + 50, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			}
			else
			{
				SetWindowPos(p->button, 0, (p->num - settings.offset) * (settings.iconwidth+settings.padding) + settings.placement.x, settings.placement.y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
			}
		}
	}

	RedrawAllIcons();
	InvalidateRect(settings.hMainWnd, NULL, TRUE);
}

void AddWindow(HWND hwnd, HBITMAP bmp, int width, int height)
{
	HWND button = CreateWindow("Button", szAppName, WS_VISIBLE | WS_CHILD | BS_OWNERDRAW, 
								((settings.last >= settings.totalvisible)? settings.totalvisible-1 : settings.last) * (settings.iconwidth+settings.padding) + settings.placement.x, 
								settings.height + 50, 
								width, 
								height, 
								settings.hMainWnd, NULL, settings.hInstance, 0);

	if (settings.start)
	{
		struct node* p = (struct node*)malloc(sizeof(struct node));
		p->button = button;
		p->hwnd = hwnd;
		p->bmp = bmp;
		p->num = settings.last;
		p->width = width;
		p->height = height;
		p->next = settings.start;
		if (IsZoomed(hwnd)) p->MAX = TRUE;
		else p->MAX=FALSE;
		settings.start = p;
	}
	else
	{
		settings.start = (struct node*)malloc(sizeof(struct node));
		settings.start->button = button;
		settings.start->hwnd = hwnd;
		settings.start->bmp = bmp;
		settings.start->num = settings.last;
		settings.start->width = width;
		settings.start->height = height;
		if (IsZoomed(hwnd)) settings.start->MAX = TRUE;
		else settings.start->MAX=FALSE;
		settings.start->next = 0;
	}

	settings.offset = settings.last - settings.totalvisible + 1;
	if (settings.offset < 0) settings.offset = 0;
	Scroll();
}

void CompactWindows(int num)
{
	struct node* p = (struct node*)malloc(sizeof(struct node));

	for (p=settings.start; p; p=p->next)
	{
		if (p->num > num)
		{
			p->num--;
			
			if (p->num - settings.offset < settings.totalvisible)
			{
				SetWindowPos(p->button, 0, (p->num-settings.offset) * (settings.iconwidth+settings.padding) + settings.placement.x, settings.placement.y, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
				InvalidateRect(p->button, NULL, TRUE);
			}
		}
	}
}

void DeleteWindow(HWND hwnd)
{
	if (settings.start)
	{
		struct node* p = (struct node*)malloc(sizeof(struct node));
		struct node* q = (struct node*)malloc(sizeof(struct node));

		for (p=settings.start; p; q=p, p=p->next)
		{
			if (p->hwnd == hwnd)
			{
				int temp = p->num;
				q->next = p->next;
				DestroyWindow(p->button);
				p->button = NULL;
				p->hwnd = NULL;
				DeleteObject(p->bmp);
				p->num = -1;
				free(p);
				p=NULL;

				CompactWindows(temp);
				settings.last--;
				break;
			}
		}
	}
}

BOOL IsAlreadyMinimized(HWND hwnd)
{
	struct node* p = (struct node*)malloc(sizeof(struct node));

	for (p=settings.start; p; p=p->next)
	{
		if (p->hwnd == hwnd) return TRUE;
	}

	return FALSE;
}

BOOL AddBitmap(HWND hwnd)
{
	HBITMAP bmp;
	RECT r, wr;

	if (!hwnd) return FALSE;
	if (IsAlreadyMinimized(hwnd)) return FALSE;

	GetWindowRect(hwnd, &wr);
	GetClientRect(hwnd, &r);
	
	if (wr.left < 0) SetWindowPos(hwnd, 0, 0, wr.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	else if (wr.left > settings.ScreenX) SetWindowPos(hwnd, 0, settings.ScreenX - wr.left, wr.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	if (wr.top < 0) SetWindowPos(hwnd, 0, r.left, 0, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	else if (wr.top > settings.ScreenY) SetWindowPos(hwnd, 0, wr.left, settings.ScreenY - r.bottom, 0, 0, SWP_NOSIZE | SWP_NOZORDER);

	SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	InvalidateRect(hwnd, NULL, TRUE);
	Sleep(settings.sleeptime);

	{
		HDC hdc = CreateCompatibleDC(NULL);
		HDC buf;
		int wratio = settings.iconwidth;
		int hratio = settings.iconwidth * r.bottom / r.right;
		int count=1;

		while (hratio > settings.areaheight)
		{
			wratio = settings.iconwidth - count;
			hratio = wratio * r.bottom / r.right;
			count++;
		}
		
		buf = GetWindowDC(hwnd);

		bmp = CreateCompatibleBitmap(buf, wratio, hratio);
		SelectObject(hdc, bmp);
		SetStretchBltMode(hdc, COLORONCOLOR);
		StretchBlt(hdc, 0, 0, wratio, hratio, buf, 0, 0, r.right, r.bottom, SRCCOPY);
		AddWindow(hwnd, bmp, wratio, hratio);

		ReleaseDC(hwnd, buf);
		DeleteDC(hdc);
	}
	
	SetWindowPos(hwnd,  HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	InvalidateRect(settings.desktop, NULL, TRUE);
	
	settings.last++;
	return TRUE;
}

struct node* GetNodeByWindow(HWND hwnd)
{
	struct node* p = (struct node*)malloc(sizeof(struct node));

	for (p=settings.start; p; p=p->next)
	{
		if (p->button == hwnd) return p;
	}

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);

			switch (wParam)
			{
				case 0:
					sprintf(buf, "IconBox 1.1 (MrJukes)\0");
				break;
				case 1:
					sprintf(buf, "IconBox 1.1 (MrJukes)\0");
				break;
				default:
					sprintf(buf, "IconBox 1.1 (MrJukes)\0");
			}

			return strlen(buf);
		}
		break;

		case IB_MIN:
		{
			//MessageBox(hwnd, "I am receiving", "IconBox", MB_SYSTEMMODAL);
			AddBitmap((HWND)wParam);
		}
		return 0;

		case WM_NCHITTEST:
		{
			RECT r;
			int y = HIWORD(lParam);

			GetWindowRect(hwnd, &r);
			
			if (y <= r.top + settings.topheight) return HTCAPTION;
			else return HTCLIENT;
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC img = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, settings.width, settings.height);
			RECT r;
			int width;

			SelectObject(buf, bufbmp);

			GetClientRect(hwnd, &r);
			FillRect(buf, &r, GetStockObject(WHITE_BRUSH));

			SelectObject(img, settings.bg);
			BitBlt(buf, settings.leftwidth, settings.topheight, settings.bgwidth, settings.bgheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.left);
			BitBlt(buf, 0, 0, settings.leftwidth, settings.leftheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.right);
			BitBlt(buf, settings.width - settings.rightwidth, 0, settings.rightwidth, settings.rightheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.top);
			BitBlt(buf, 0, 0, settings.topwidth, settings.topheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.bottom);
			BitBlt(buf, 0, settings.height - settings.bottomheight, settings.bottomwidth, settings.bottomheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.scrolltrack);
			BitBlt(buf, settings.scrolltrackx, settings.scrolltracky, settings.scrolltrackwidth, settings.scrolltrackheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.arrowleft);
			BitBlt(buf, settings.scrolltrackx, settings.scrolltracky, settings.arrowleftwidth, settings.arrowleftheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.arrowright);
			BitBlt(buf, settings.scrolltrackx + settings.scrolltrackwidth - settings.arrowrightwidth, settings.scrolltracky, settings.arrowrightwidth, settings.arrowrightheight, img, 0, 0, SRCCOPY);

			SelectObject(img, settings.scrollgrab);
			
			width = settings.scrolltrackwidth - settings.arrowleftwidth - settings.arrowrightwidth - settings.scrollgrabwidth;
			if (settings.last > 1) settings.scrollgrabx =  (width / (settings.last-1)) * settings.offset + settings.arrowleftwidth + 2;
			else settings.scrollgrabx = settings.arrowleftwidth + 2;

			if ((settings.scrolltrackwidth - settings.arrowrightwidth - settings.scrollgrabx - settings.scrollgrabwidth) < 5) settings.scrollgrabx = settings.scrolltrackx + settings.scrolltrackwidth - settings.arrowrightwidth - settings.scrollgrabwidth - 1;
			BitBlt(buf, settings.scrollgrabx, settings.scrolltracky, settings.scrollgrabwidth, settings.scrollgrabheight, img, 0, 0, SRCCOPY);

			BitBlt(hdc, 0, 0, settings.width, settings.height, buf, 0, 0, SRCCOPY);

			EndPaint(hwnd, &ps);
			
			DeleteDC(hdc);
			DeleteDC(buf);
			DeleteDC(img);
			DeleteObject(bufbmp);
		}
		return 0;

		case WM_DRAWITEM:
		{
			DRAWITEMSTRUCT* dis = (DRAWITEMSTRUCT*)lParam;
			struct node* p = GetNodeByWindow(dis->hwndItem);

			FillRect(dis->hDC, &dis->rcItem, GetStockObject(GRAY_BRUSH));

			if (p)
			{
				if (dis->itemAction == ODA_DRAWENTIRE)
				{
					HDC buf = CreateCompatibleDC(NULL);
					SelectObject(buf, p->bmp);
					BitBlt(dis->hDC, 0, 0, p->width, p->height, buf, 0, 0, SRCCOPY);
					DeleteDC(buf);
				}
				else
				{
					HDC buf = CreateCompatibleDC(NULL);
					SelectObject(buf, p->bmp);
					BitBlt(dis->hDC, 0, 0, p->width, p->height, buf, 0, 0, SRCAND);
					DeleteDC(buf);
				}
			}
		}
		break;

		/*case WM_KEYDOWN:
		{
			switch ((int)wParam)
			{
				case 13: // Enter
				{
				}
				break;

				case 37: // Left
				{
				}
				break;

				case 39: // Right
				{
					HWND next=NULL;
					int x;

					for (x=0; x<=settings.current; x++)
					{
						HWND temp = FindWindowEx(settings.hMainWnd, next, "Button", NULL);
						next = temp;
					}
					//SetFocus(next);
					SendMessage(next, BM_SETSTATE, (WPARAM)TRUE, 0);
					
					settings.current++;
					if (settings.current >= settings.last) settings.current=0;
				}
				break;
			}
		}
		break;*/

		case WM_LBUTTONDOWN:
		{
			int x = LOWORD(lParam);
			int y = HIWORD(lParam);

			if (settings.last >= settings.totalvisible || settings.offset != 0)
			{
				if (x >= settings.scrolltrackx && x <= settings.scrolltrackx + settings.scrolltrackwidth)
				{
					if (y >= settings.scrolltracky && y <= settings.scrolltracky + settings.scrolltrackheight)
					{
						// Left
						if (x <= settings.scrolltrackx + settings.arrowleftwidth) 
						{
							settings.offset--;

							if (settings.offset < 0) 
							{
								settings.offset=0;
								break;
							}
						}
						// Right
						else if (x >= settings.scrolltrackwidth - settings.arrowrightwidth) 
						{
							settings.offset++;

							if (settings.offset >= settings.last)
							{
								settings.offset = settings.last-1;
								break;
							}
						}
						else
						{
							// Left Fast
							if (x < settings.scrollgrabx)
							{
								settings.offset -= 3;
								
								if (settings.offset < 0) 
								{
									settings.offset=0;
								}

							}
							// Right Fast
							else if (x > settings.scrollgrabx + settings.scrollgrabwidth)
							{
								settings.offset += 3;

								if (settings.offset >= settings.last)
								{
									settings.offset = settings.last-1;
								}

							}
						}
						Scroll();
					}
				}
			}
		}
		break;

		case WM_COMMAND:
		{
			if (HIWORD(wParam) == BN_CLICKED)
			{
				struct node* p = GetNodeByWindow((HWND)lParam);

				if (p)
				{
					if (p->MAX) ShowWindow(p->hwnd, SW_MAXIMIZE);
					else ShowWindow(p->hwnd, SW_RESTORE);

					DeleteWindow(p->hwnd);
				}
			}
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* wp = (WINDOWPOS*)lParam;
			
			wp->flags |= SWP_NOZORDER;

			if (wp->x < 0) wp->x = 0;
			else if (wp->x+settings.width > settings.ScreenX) wp->x = settings.ScreenX - settings.width;

			if (wp->y < 0) wp->y = 0;
			else if (wp->y+settings.height > settings.ScreenY) wp->y = settings.ScreenY - settings.height;
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	settings.parent = parent;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
    
	AddBangCommand("!IconBoxFocus", BangFocus);
	AddBangCommand("!IconBoxToggle", BangToggle);
	AddBangCommand("!IconBoxShow", BangShow);
	AddBangCommand("!IconBoxHide", BangHide);

	strcpy(settings.szPath, szPath);
	settings.hInstance = dllInst;
	LoadSettings();

	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	struct node* p = (struct node*)malloc(sizeof(struct node));

	SendMessage(settings.parent, LM_UNREGISTERMESSAGE, (WPARAM)settings.hMainWnd, (LPARAM)msgs);

	RemoveBangCommand("!IconBoxFocus");
	RemoveBangCommand("!IconBoxToggle");
	RemoveBangCommand("!IconBoxShow");
	RemoveBangCommand("!IconBoxHide");
	
	//UnhookWindowsHookEx(settings.hook);
	HookQuit();
    FreeLibrary(HookDll);

	DeleteObject(settings.left);
	DeleteObject(settings.right);
	DeleteObject(settings.top);
	DeleteObject(settings.bottom);
	DeleteObject(settings.bg);
	DeleteObject(settings.arrowleft);
	DeleteObject(settings.arrowright);
	DeleteObject(settings.scrollgrab);
	DeleteObject(settings.scrolltrack);

	if (settings.start)
	{
		for (p=settings.start; p; p=settings.start->next)
		{
			settings.start->next = p->next;
			DestroyWindow(p->button);
			p->button = NULL;
			p->hwnd = NULL;
			DeleteObject(p->bmp);
			p->num = -1;
			free(p);
			p = NULL;
		}
	}

	DestroyWindow(settings.hMainWnd);
	UnregisterClass(szAppName, settings.hInstance);

	return 0;
}

void BangFocus(HWND caller, char *args)
{
	if (settings.HIDDEN == TRUE) BangShow(caller, args);

	SetForegroundWindow(settings.hMainWnd);
	SetFocus(settings.hMainWnd);
}

void BangToggle(HWND caller, char *args)
{
	if (settings.HIDDEN==TRUE)
	{
		BangShow(caller, args);
	}
	else
	{
		BangHide(caller, args);
	}
}

void BangHide(HWND caller, char *args)
{
	settings.HIDDEN = TRUE;
	ShowWindow(settings.hMainWnd, SW_HIDE);
}

void BangShow(HWND caller, char *args)
{
	settings.HIDDEN = FALSE;
	ShowWindow(settings.hMainWnd, SW_SHOWNORMAL);
}