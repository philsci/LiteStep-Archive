/////////////////////////////
// IconBox Prebeta 1
// Released 12/29/99
// Written By: MrJukes
// Graphics By: AznRomeo
/////////////////////////////

LoadModule c:\Litestep\IconBox.dll

;=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
;IconBox Options
;=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

; Delay after you hit the minimize button until the window gets minimized.
; This delays allows IconBox to take a snap shot of the current window contents.
; For slower computers, you may want to turn this value up.
; For faster computers, down may be the way for you.
IconBoxDelay 500 

; X position (in screen coordinates)
IconBoxX 0

; Y position (in screen coordinates)
IconBoxY 38

; Width
IconBoxWidth 194

; Height
IconBoxHeight 100

; The amount of pixels between each icon
IconBoxPadding 7

; The X position (in client coordinates) of where to start placing icons
IconBoxPlacementX 10

; The Y position (in client coordinates) of where to start placing icons
IconBoxPlacementY 24

; The width of the area where an icon can be placed
IconBoxAreaWidth 188

; The height of the area where an icon can be placed
; This also turns out to be the width of each icon (I might change this later if asked)
IconBoxAreaHeight 53

; The bitmap to use for the left side
IconBoxLeftBitmap "c:\litestep\iconbox\ib_left.bmp"

; The bitmap to use for the right side
IconBoxRightBitmap "c:\litestep\iconbox\ib_right.bmp"

; The bitmap to use for the top
IconBoxTopBitmap "c:\litestep\iconbox\ib_top.bmp"

; The bitmap to use for the bottom
IconBoxBottomBitmap "c:\litestep\iconbox\ib_bottom.bmp"

; The bitmap to use for the background
IconBoxBackgroundBitmap "c:\litestep\iconbox\ib_background.bmp"

; The bitmap to use for the left arrow on the scroll bar
IconBoxArrowLeftBitmap "c:\litestep\iconbox\ib_arrowleft.bmp"

; The bitmap to use for the right arrow on the scroll bar
IconBoxArrowRightBitmap "c:\litestep\iconbox\ib_arrowright.bmp"

; The bitmap to use for the scroll bar
IconBoxScrollTrackBitmap "c:\litestep\iconbox\ib_scrolltrack.bmp"

; The X position (in client coordinates) of where to put the scroll bar
IconBoxScrollTrackX 3

; The Y position (in client coordinates) of where to put the scroll bar
IconBoxScrollTrackY 80

; The bitmap to use for the scroll grab
; You can't actually grab the scroll grab right now. (Future addition)
IconBoxScrollGrabBitmap "c:\litestep\iconbox\ib_scrollgrab.bmp"

; Sets focus to IconBox (brings it to the top)
; This also unhides IconBox if it was previously hidden
*Hotkey Win I !IconBoxFocus

; Toggles between being hidden and visible
*Hotkey Win O !IconBoxToggle

; Hides IconBox
*Hotkey Win H !IconBoxHide

; Unhides IconBox
*Hotkey Win S !IconBoxShow