#define IB_MIN		0x8001
#define IB_RESTORE	0x8002
