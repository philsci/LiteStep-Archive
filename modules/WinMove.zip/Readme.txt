Window Mover 1.0

Window Mover is a small program that will allow you to regain visibility of windows that have been lost by a virtual window manager. To use, just launch Window Mover and select the lost window from the list and reset it's left and top coordinates to somewhere in your view space (like: 0,0). Then click the re-position button.

Window Mover came about after trying to explain to someone in #ls_help how to regain they're lost windows. But for newbies this isn't always easy to do, so i wrote this to simplify it.


Tom Crouson

(Two_toNe)

2tone@inreach.com

