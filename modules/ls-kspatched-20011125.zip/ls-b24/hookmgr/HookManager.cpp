/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
11/17/01 - Bobby G. Vinyard (Message)
  - Added support for RegisterShellHook, this will allow for cmd.exe windows
    to be properly handled under NT/2K
11/17/01 - Bobby G. Vinyard (Message)
  - Removed test code defines
11/25/00 - Bobby G. Vinyard (Message)
  - Readded code to hookmgr and hook to handle CallWndProc, evidently the cause
    for the lockups was the hooking of the debugger (in my case deb.exe), so code
    has been added to keep the deb.exe proccess from being hooked. Anyone using hooks
    should replace "deb.exe" in hook.cpp with the name of their debugger. (The code to
    enable CallWndProc is enabled by defining _TEST_CODE) 
06/03/00 - Bobby G. Vinyard (Message)
  - Swapped lParam and wParam for LM_REGISTERMESSAGE and LM_UNREGISTERMESSAGE
06/03/00 - Bobby G. Vinyard (Message)
  - Yet another rewrite
    - No longer uses lswinbase
    - HookMgr uses a sepereate thread now
    - Added HookCallback for modules to use when using HookMgr
    - Probably should be using WM_CALLWNDPROC or WM_CALLWNDPROCRET but these
     lock my _tsystem up everytime i try set one... =\ ( so the implementation
     is commented out for now)
05/18/00 - Bobby G. Vinyard (Message)
  - Rewrote hookmgr to handle only WM messages and to d2 format 
****************************************************************************/
#include "HookManager.h"
#include "resource.h"
#include "../lsapi/macros.h"

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
    hInst = dllInst;
    hShellHook = NULL;
    hMsgHook = NULL;
    hHookMgrThread = NULL;
    hwndHookMgr = NULL;
    RegisterShellHook = NULL;
    hwndLiteStep = NULL;
    hmodHook = LoadLibrary("hook");
    if (hmodHook) {
        processHooks = true;
        if(!createHookThread()) {
            RESOURCE_MSGBOX(hInst, IDS_HOOKMGR_ERROR1,
                "Could not create Hook Manager Thread", HOOKMGRWINDOWNAME)
                
                processHooks = false;
        }
    }
    else {
        RESOURCE_MSGBOX(hInst, IDS_HOOKMGR_ERROR2,
            "Could not load hook.dll", HOOKMGRWINDOWNAME)
            
            processHooks = false;
    }
    return 0;
}


void quitModule(HINSTANCE dllInst)
{
    SendMessage(hwndHookMgr, WM_CLOSE, 0, 0);
    WaitForSingleObject(hHookMgrThread, INFINITE);
    processHooks = false;
    UnregisterClass(HOOKMGRWINDOWCLASS, dllInst);
    FreeLibrary(hmodHook);
}


bool createHookThread() {
    WNDCLASS wc;
    DWORD Id;
    
    //
    // Register a class for the hook stuff to forward its messages to.
    //
    wc.hCursor        = NULL;    // this window never shown, so no
    wc.hIcon          = NULL;    // cursor or icon are necessary
    wc.lpszMenuName   = NULL;
    wc.lpszClassName  = HOOKMGRWINDOWCLASS;
    wc.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
    wc.hInstance      = hInst;
    wc.style          = 0;
    wc.lpfnWndProc    = HookMgrWndProc;
    wc.cbWndExtra     = sizeof(HWND) + sizeof(HWND);
    wc.cbClsExtra     = 0;
    
    if (!RegisterClass(&wc)) {
        return FALSE;
    }
    //
    // Now create another thread to handle the new queue
    //
    if (!(hHookMgrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)HookMgrMain,
        0L, STANDARD_RIGHTS_REQUIRED, &Id))) {
        return FALSE;
    }
    return TRUE;
    
}


DWORD HookMgrMain(LPVOID lpv) {
    MSG msg;
    
    hwndHookMgr = CreateWindow(HOOKMGRWINDOWCLASS, HOOKMGRWINDOWNAME,
        WS_OVERLAPPEDWINDOW,
        0, 0, 0, 0,
        NULL, NULL,
        hInst, NULL);
    
    if (!hwndHookMgr) {
        
        RESOURCE_MSGBOX(hInst, IDS_HOOKMGR_ERROR3,
            "Unable to create window.", HOOKMGRWINDOWNAME)
            
        ExitThread(0);
    }
    else
    {
        RegisterShellHook = (FARPROC (__stdcall *)(HWND, DWORD))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (LPCSTR)((long)0xB5));
        WM_ShellHook = RegisterWindowMessage("SHELLHOOK");
        if (RegisterShellHook)
        {
            RegisterShellHook(hwndHookMgr, 3);
        }
    }

    while (IsWindow(hwndHookMgr) && GetMessage(&msg, hwndHookMgr, 0, 0)) {
        if (processHooks) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }
    
    hwndHookMgr = NULL;
    
    return 0;
    
}


bool InstallMsgFilter(bool install) {
    _LSDEBUG1("Installing Hooks...")
    if (install && !hMsgHook && !hCallWndHook) {
        
        setCallWndHook(SetWindowsHookEx(WH_CALLWNDPROC,
            (HOOKPROC)GetProcAddress(hmodHook, "CallWndProc"), hmodHook, 0));
        _LSDEBUGLASTERR
            hCallWndHook = getCallWndHook();
        
        setMsgHook(SetWindowsHookEx(WH_GETMESSAGE,
            (HOOKPROC)GetProcAddress(hmodHook, "GetMsgProc"), hmodHook, 0));
        _LSDEBUGLASTERR
            hMsgHook = getMsgHook();
        
        if (hMsgHook && hCallWndHook) {
            _LSDEBUG1("Hooks Installed!")
                return true;
        }
    }
    else if (!install && hMsgHook && hCallWndHook) {
        setMsgHook(NULL);
        UnhookWindowsHookEx(hMsgHook);
        hMsgHook = NULL;
        
        setCallWndHook(NULL);
        UnhookWindowsHookEx(hCallWndHook);
        hCallWndHook = NULL;
    }
    _LSDEBUG1("Hooks Not Installed!")
    return false;
}

LRESULT CALLBACK HookMgrWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    sMsgHookList *psHwnds;
    sMsgHookList::reverse_iterator lrit;
    msg2hwnd::iterator m2hit;
    switch (msg) {
    case WM_COPYDATA:
        {
            if (numMessages == 0) break;
            if (((PCOPYDATASTRUCT)lParam)->cbData != sizeof(MSG)) break;
            msgd.message = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->message;
            msgd.hwnd = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->hwnd;
            msgd.wParam = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->wParam;
            msgd.lParam = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->lParam;
            m2hit = m2hmap.find(msgd.message);
            if (m2hit != m2hmap.end()) {
                _LSDEBUG2("WM_COPYDATA message found", (int)msgd.message)
                    psHwnds = (*m2hit).second;
                for(lrit=psHwnds->rbegin(); lrit != psHwnds->rend(); lrit++) {
                    (*lrit)(msgd.hwnd, msgd.message, msgd.wParam, msgd.lParam);
                }
            }
        }
        return TRUE;
        
    case LM_REGISTERMESSAGE:
        {
            if (numMessages == 0) { 
                if (InstallMsgFilter(true)) {
                    psHwnds = new sMsgHookList;
                    psHwnds->insert((HookCallback*)lParam);
                    m2hmap.insert(msg2hwnd::value_type((UINT)wParam,psHwnds));
                    numMessages++;
                }
            }
            else {
                m2hit = m2hmap.find((UINT)wParam);
                if (m2hit == m2hmap.end()) {
                    psHwnds = new sMsgHookList;
                    psHwnds->insert((HookCallback*)lParam);
                    m2hmap.insert(msg2hwnd::value_type((UINT)wParam,psHwnds));
                }
                else {
                    psHwnds = (*m2hit).second;
                    psHwnds->insert((HookCallback*)lParam);
                }
                numMessages++;
            }
        }
        return TRUE;
        
    case LM_UNREGISTERMESSAGE:
        {
            if (numMessages) {
                m2hit = m2hmap.find((UINT)wParam);
                if (m2hit != m2hmap.end()) {
                    sMsgHookList::iterator lit;
                    psHwnds = (*m2hit).second;
                    lit = psHwnds->find((HookCallback*)lParam);
                    if (lit != psHwnds->end()) {
                        psHwnds->erase(lit);
                        if (psHwnds->empty()) {
                            delete (*m2hit).second;
                            m2hmap.erase(m2hit);
                        }
                        numMessages--;
                        if (!numMessages) {
                            InstallMsgFilter(false);
                        }
                    }   
                }
            }
        }
        return TRUE;;
    case WM_CREATE:
        {
            setShellHook(SetWindowsHookEx(WH_SHELL, 
                (HOOKPROC)GetProcAddress(hmodHook, "ShellProc"), hmodHook, 0));
            hShellHook = getShellHook();
        }
        break;
        
    case WM_DESTROY:
        {
            if (hShellHook) {
                setShellHook(NULL);
                UnhookWindowsHookEx(hShellHook);
                hShellHook = NULL;
            }
            if (RegisterShellHook)
            {
                RegisterShellHook(hwndHookMgr, 0);
            }
            InstallMsgFilter(false);
            PostQuitMessage(0);
        }
        return 0;
        
    case WM_NCDESTROY:
        {
            processHooks = FALSE;
        }
        break;
    default:
        {
            if ((msg == WM_ShellHook) && ((wParam == HSHELL_WINDOWCREATED) || (wParam == HSHELL_WINDOWDESTROYED)))
            {
                if (hwndLiteStep == NULL)
                {
                    hwndLiteStep = FindWindow("TApplication", "LiteStep");
                }
                if (hwndLiteStep)
                {
                    PostMessage(hwndLiteStep, wParam + 9500, lParam, lParam );   
                }
            }
        }
        break;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}
