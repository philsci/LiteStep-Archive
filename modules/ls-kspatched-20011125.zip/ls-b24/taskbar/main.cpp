/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/

#include "common.h"
#include <commctrl.h>
#include "../lsapi/lsapi.h"
#include "taskbar.h"

// forward declarations
void hideBangCommand(HWND hCaller, const _TCHAR *args);
void toggleBangCommand(HWND hCaller, const _TCHAR *args);
void showBangCommand(HWND hCaller, const _TCHAR *args);

// undocumented SwitchToThisWindow API (maybe this should be in LSAPI?)
void (WINAPI *SwitchToThisWindow)(HWND, int);

Taskbar *taskbar;

int initModuleEx(HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath)
{
	InitCommonControls();

	SwitchToThisWindow = (void (WINAPI *)(HWND, int)) GetProcAddress(
		GetModuleHandle(TEXT("USER32.DLL")),
		TEXT("SwitchToThisWindow"));

	taskbar = new Taskbar;
	taskbar->OnLoad(hInstance);

	AddBangCommand("!TaskbarHide", hideBangCommand);
	AddBangCommand("!TaskbarToggle", toggleBangCommand);
	AddBangCommand("!TaskbarShow", showBangCommand);

	return 0;
}

void quitModule(HINSTANCE hInstance)
{
	RemoveBangCommand("!TaskbarHide");
	RemoveBangCommand("!TaskbarToggle");
	RemoveBangCommand("!TaskbarShow");

	taskbar->OnUnload();
	delete taskbar;
}

extern "C" int WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved)
{
	if(dwReason == DLL_PROCESS_ATTACH)
		DisableThreadLibraryCalls(hInstance);

	return 1;
}


// bang commands
//

void hideBangCommand(HWND hCaller, const _TCHAR *args)
{
	taskbar->hide();
}

void toggleBangCommand(HWND hCaller, const _TCHAR *args)
{
	if(taskbar->isVisible())
		taskbar->hide();
	else
		taskbar->show();
}

void showBangCommand(HWND hCaller, const _TCHAR *args)
{
	taskbar->show();
}


// utility functions
//

HFONT GetRCFont(const _TCHAR *name, const LOGFONT *lfDefault)
{
	LOGFONT lf;
	_TCHAR configName[32];

	if(GetRCBool(name, TRUE))
	{
		memset(&lf, 0, sizeof(LOGFONT));

		wsprintf(configName, "%s", name);
		GetRCString(configName, lf.lfFaceName, lfDefault->lfFaceName, LF_FACESIZE);

		wsprintf(configName, "%sHeight", name);
		lf.lfHeight = GetRCInt(configName, lfDefault->lfHeight);

		wsprintf(configName, "%sBold", name);
		lf.lfWeight = GetRCBool(configName, TRUE) ? FW_BOLD : FW_NORMAL;

		wsprintf(configName, "%sItalic", name);
		lf.lfItalic = GetRCBool(configName, TRUE);

		lf.lfCharSet = SHIFTJIS_CHARSET;	// 2001/11/25 Ks Added to Enable Japanese
	}
	else
	{
		memcpy(&lf, lfDefault, sizeof(LOGFONT));
	}

	return CreateFontIndirect(&lf);
}

BOOL IsAppWindow( HWND hWnd )
{
	if( !IsWindowVisible( hWnd ) )
		return FALSE;

	if( GetWindow( hWnd, GW_OWNER ) )
		return FALSE;

	LONG styleEx = GetWindowLong( hWnd, GWL_EXSTYLE );

	if( styleEx & WS_EX_APPWINDOW )
		return TRUE;

	if( styleEx & WS_EX_TOOLWINDOW )
		return FALSE;

	if( GetWindowLong( hWnd, GWL_USERDATA ) == 0x49474541 )
		return FALSE;

	return TRUE;
}

// from jugg's tasks.dll, based on code from Fahim and re5ource
HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon )
{
	HICON hIcon = NULL;

	if(hWnd)
	{
		if( bBigIcon )
		{
			SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
			if( !hIcon ) SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if( !hIcon ) SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			//if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
			if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
		}
		else
		{
			SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
			if( !hIcon ) SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			if( !hIcon ) SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
			//if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
			if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
		}
	}

	return hIcon;
}

BOOL WINAPIV PrintLog( LPCTSTR pszFormat, ... )
{
	TCHAR szText[1024];
	DWORD dwCount;
	va_list argList;
	HANDLE hFile;
	
	va_start( argList, pszFormat );
	wvsprintf( szText, pszFormat, argList );
	lstrcat( szText, TEXT("\r\n") );
	
	hFile = CreateFile( TEXT("C:\\LITESTEP\\TASKBAR.LOG"),
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL );
	
	SetFilePointer( hFile, 0, NULL, FILE_END );
	WriteFile( hFile, szText, lstrlen( szText ), &dwCount, 0 );
	
	CloseHandle( hFile );
	return TRUE;
}
