/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma warning(disable: 4786)
#if !defined(AFX_BangMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
#define AFX_BangMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "../core/ifcs.h"
#include "bangmgr.h"
#include <map>
#include <string>

using namespace std;

class StandardBangManager : public IBangManager  
{
public:
	StandardBangManager();
	virtual ~StandardBangManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	///////////////////////////////////////////////////////////////////////////
	// From IDispatch
	HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
		/* [out] */ UINT __RPC_FAR *pctinfo);

	HRESULT STDMETHODCALLTYPE GetTypeInfo( 
		/* [in] */ UINT iTInfo,
		/* [in] */ LCID lcid,
		/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

	HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
		/* [in] */ REFIID riid,
		/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
		/* [in] */ UINT cNames,
		/* [in] */ LCID lcid,
		/* [size_is][out] */ DISPID __RPC_FAR *rgDispId);

	HRESULT STDMETHODCALLTYPE Invoke( 
		/* [in] */ DISPID dispIdMember,
		/* [in] */ REFIID riid,
		/* [in] */ LCID lcid,
		/* [in] */ WORD wFlags,
		/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
		/* [out] */ VARIANT __RPC_FAR *pVarResult,
		/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
		/* [out] */ UINT __RPC_FAR *puArgErr);

	///////////////////////////////////////////////////////////////////////////
	// From IBangManager
    virtual BOOL STDMETHODCALLTYPE AddBangCommand( 
        /* [in] */ BSTR name,
        /* [in] */ IBangCommand __RPC_FAR *command);
    
    virtual BOOL STDMETHODCALLTYPE RemoveBangCommand( 
        /* [in] */ BSTR name);
    
    virtual IBangCommand __RPC_FAR *STDMETHODCALLTYPE GetBangCommand( 
        /* [in] */ BSTR name);
    
    virtual void STDMETHODCALLTYPE ClearBangCommands( void);
    
    virtual BOOL STDMETHODCALLTYPE ExecuteBangCommand( 
        /* [in] */ BSTR name,
        /* [in] */ OLE_HANDLE caller,
        /* [in] */ BSTR params);
    
    virtual long STDMETHODCALLTYPE ExecuteBangCommands( 
        /* [in] */ long count,
        /* [size_is][in] */ BSTR __RPC_FAR names[  ],
        /* [in] */ OLE_HANDLE caller,
        /* [size_is][in] */ BSTR __RPC_FAR params[  ]);
    
    virtual long STDMETHODCALLTYPE GetBangCommandNames( 
        /* [in] */ long count,
        /* [size_is][out] */ BSTR __RPC_FAR names[  ]);

	virtual long STDMETHODCALLTYPE GetBangCommandCount( void);

private:
	long refCount;
	typedef map<wstring, IBangCommand*> BangMap;
	BangMap bang_map;
	ITypeInfo *typeinfo;
    CRITICAL_SECTION cs;
};


// Locking class, should probably move to some utility files
class Lock
{
public:
    Lock(CRITICAL_SECTION &cs)
    :   _cs(cs)
    {
        EnterCriticalSection(&_cs);
    }

    ~Lock()
    {
        LeaveCriticalSection(&_cs);
    }
    
protected:
    CRITICAL_SECTION &_cs;
};

#endif // !defined(AFX_BangMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
