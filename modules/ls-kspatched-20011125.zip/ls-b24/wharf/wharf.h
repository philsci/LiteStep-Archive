/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __WHARF_H
#define __WHARF_H

#include "..\lsapi\common.h"

#include <vector>
#include "../litestep/wharfdata.h"

#define WHARF_UP                0
#define WHARF_DOWN              1
#define WHARF_LEFT              2
#define WHARF_RIGHT             3

// forward decl
class subwharfType;

typedef std::vector< subwharfType* > SubwharfVector;

class wharfType {
public:
	wharfType();

	virtual void Paint(HDC hdc, HDC src);
	virtual void PaintTitle(HDC hdc, HDC src);

  HINSTANCE hInst;
  HWND hWnd;
  HWND hsubwharfWnd;
  HBITMAP backImage;
  HBITMAP frontImage;
  _TCHAR szName[256];
  _TCHAR szCommand[MAX_PATH];
  _TCHAR szParameters[256];
  int numSubwharfs;
  int subwharfX;
  int subwharfY;
  BOOL subwharfOpen;
  BOOL moving;
  BOOL closing;
  BOOL showbg;
  BOOL bPressed;
  BOOL bTogglePressed;
  int movingPos;
  int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
  int (FAR *quitWharfModule)(HINSTANCE);
  HRGN (FAR *GetLSRegion)(int, int);
  HRGN subRgn;
  //subwharfType *subwharfs;
	SubwharfVector subwharfs;
};

class subwharfType : public wharfType {
	wharfType *parent;

public:
	subwharfType(wharfType *p);

	virtual void Paint(HDC hdc, HDC src);

  HWND taskWnd;
};

typedef std::vector< wharfType* > WharfVector;

extern "C" {
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCTSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif

