/* this ALWAYS GENERATED file contains the proxy stub code */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Nov 25 22:29:29 2001
 */
/* Compiler settings for E:\Download\ls-b24\core\ifcs.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 440
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "ifcs.h"

#define TYPE_FORMAT_STRING_SIZE   3                                 
#define PROC_FORMAT_STRING_SIZE   1                                 

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


/* Standard interface: __MIDL_itf_ifcs_0000, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IHookManager, ver. 0.0,
   GUID={0x7A7BDDA0,0xF668,0x4742,{0x9C,0xEA,0xAF,0x14,0x54,0x71,0x3B,0x2E}} */


/* Object interface: IWindowList, ver. 0.0,
   GUID={0x753B377F,0xA320,0x48ea,{0xBF,0x8E,0x2F,0x7F,0xBE,0xBE,0x08,0x2E}} */


/* Object interface: IBangCommand, ver. 0.0,
   GUID={0x93825A2B,0x4CEE,0x461e,{0xBA,0xBC,0x8D,0x3D,0x43,0xC2,0x0F,0x58}} */


/* Standard interface: __MIDL_itf_ifcs_0218, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: DBangManager, ver. 0.0,
   GUID={0xB7155DF6,0x1D37,0x4302,{0xB1,0xBD,0x8F,0x2D,0xDA,0xDB,0xEC,0x2E}} */


/* Object interface: IBangManager, ver. 0.0,
   GUID={0xCDC70A77,0x7F9B,0x4fe9,{0x8B,0xA0,0x65,0xC8,0xE9,0x98,0x79,0x33}} */


/* Object interface: IModuleManager, ver. 0.0,
   GUID={0xA1D512D1,0xF7CB,0x461c,{0xBA,0xF8,0x72,0x30,0x92,0xE5,0x44,0x37}} */


/* Object interface: IMessageManager, ver. 0.0,
   GUID={0x6DBB9F7E,0xEA30,0x11d3,{0x8E,0xBE,0x00,0x08,0xC7,0x5C,0xA3,0xDB}} */


/* Standard interface: __MIDL_itf_ifcs_0222, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}} */


/* Object interface: IStepIterator, ver. 0.0,
   GUID={0x1FBE20B7,0xCA75,0x4cd0,{0xBD,0x7A,0x47,0x03,0x51,0xDE,0x5A,0xCA}} */


/* Object interface: IStepSettings, ver. 0.0,
   GUID={0x1FBE20B7,0xCA75,0x4cd0,{0xBD,0x7A,0x47,0x03,0x51,0xDE,0x5A,0xC9}} */


/* Object interface: ILogHandler, ver. 0.0,
   GUID={0x20D221A5,0xF565,0x4372,{0x8D,0x15,0x19,0x15,0x9C,0x76,0x2D,0x22}} */


/* Object interface: ILogDispatch, ver. 0.0,
   GUID={0x3AC83BDA,0x867E,0x42ab,{0xA0,0x2C,0xBC,0x86,0x14,0xA9,0xD3,0x16}} */


/* Object interface: ILitestep, ver. 0.0,
   GUID={0x41A26254,0x50F9,0x4f02,{0xB4,0xC7,0x4A,0x53,0x53,0x92,0xE6,0xEA}} */


/* Object interface: DWindowList, ver. 0.0,
   GUID={0x19DCF471,0x33E9,0x4252,{0xB2,0x5A,0xF6,0xE0,0x47,0xF8,0xBB,0x77}} */


/* Object interface: DStepIterator, ver. 0.0,
   GUID={0x3D3B9190,0x4956,0x4da9,{0xA6,0xB1,0x9F,0xB9,0x42,0x10,0xE4,0xB4}} */


/* Object interface: DStepSettings, ver. 0.0,
   GUID={0x3D3B9190,0x4956,0x4da9,{0xA6,0xB1,0x9F,0xB9,0x42,0x10,0xE4,0xB3}} */


/* Object interface: DModuleManager, ver. 0.0,
   GUID={0xC2D0052F,0x98A1,0x47e6,{0xB0,0xB3,0x37,0x02,0x4F,0x45,0xB8,0xC8}} */


/* Object interface: DLitestep, ver. 0.0,
   GUID={0x83B9306F,0x9C64,0x4a17,{0xAA,0xCF,0x86,0x8E,0xD9,0x44,0xA2,0x23}} */


/* Object interface: IDataStore, ver. 0.0,
   GUID={0x6DBB9F7F,0xEA30,0x11d3,{0x8E,0xBE,0x00,0x08,0xC7,0x5C,0xA3,0xDB}} */

#pragma data_seg(".rdata")

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */

			0x0
        }
    };

const CInterfaceProxyVtbl * _ifcs_ProxyVtblList[] = 
{
    0
};

const CInterfaceStubVtbl * _ifcs_StubVtblList[] = 
{
    0
};

PCInterfaceName const _ifcs_InterfaceNamesList[] = 
{
    0
};


#define _ifcs_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _ifcs, pIID, n)

int __stdcall _ifcs_IID_Lookup( const IID * pIID, int * pIndex )
{
    return 0;
}

const ExtendedProxyFileInfo ifcs_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _ifcs_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _ifcs_StubVtblList,
    (const PCInterfaceName * ) & _ifcs_InterfaceNamesList,
    0, // no delegation
    & _ifcs_IID_Lookup, 
    0,
    1,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};
