LiteSTEP URL Watcher, LSUW [b1]
===============================

A wharf module that monitors web-pages, and tells you when they
change. It serves pretty much the same purpose as URLmon do.

This is actually a port of our of URLWatch that Viktor wrote a couple
of years ago. The algorithm for determining if pages has changed has 
improved and is now really brilliant :)

Terms of Use
------------

This software is provided "as is", without any guarantee made
as to its suitability or fitness for any particular use. It may
contain bugs, so use of this tool is at your own risk. We take
no responsibility for any damage that may unintentionally be caused
through its use.

You may distribute this program freely in its original unaltered
form. However, you may not distribute this program with or as
part of a commercial release without our express written consent.

Installation
------------

Copy the .app to a directory of your choice and then edit your step.rc
add a line like

;---LSUW
*Wharf "lsuw" default.bmp @c:\litestep\modules\lsuw.app

where you find it appropriate.

Configuration
-------------

All settings are defined in your modules.ini file, No GUI sorry.

The following keys are of interest for lsuw:

IdleImage       Path to the bmp file that is displayed when
                no new paged has been detected.

NewPageImage    Default image that indicate that there is a
                new page

Default         The default URL that will be surfed to when left
                clicking at lsuw

PollFrequency   How often (in hours) that the web pages are 
                updated. Default value is 5 hours. be careful not
                to poll busy sites too often since they have enough
                to do anyway.

There are also a set of values that are associated with each web-page
that you wish to watch. These values are numbered from 0 (naturally :)

URLX            URL to the page to be watched. NOTE lsuw does 
                only support the http protocol!

NameX           User friendly name of this page. Will be used in
                the tooltip. (may be ignored)

ImageX          image to display when this page changes (this value
                may be ignored, if so lsuw will use the NewPageImage)

SurfToX         The URL that you surf to when URLX has been updated. This
                is useful if the URL you want to minotor is a part of a
                frameset.

DataX           This is an internal value used by lsuw and you should
                keep you hands of it.

Example of how the lsuw keys in modules.ini may look:

[lsuw]
IdleImage=c:\litestep\images\default.bmp
NewPageImage=c:\litestep\images\netscape.bmp
Default=http://www.house5.se/
PollFrequency=20

URL0=http://www.dilbert.com/
Name0=Dilbert

URL1=http://www.mozillazine.org/home.html
Name1=Mozilla
SurfTo1=http://www.mozillazine.org/
Image1=c:\litestep\images\mozilla.bmp

URL2=http://floach.pimpin.net/

Data0=1 89017733   
Data1=0 0  4   
Data2=1 3206622  26 

Known Issues
------------

* Hmm, sometimes it says that a page has
  changed when it clearly has not and sometime
  it misses that a page has changed.. we are working
  on that ....

* We have not had the opportunity to test lsuw on any
  Windows 9x machine so there might be problems
  there. 

* pages containing some type of clocks are noted as
  changed when they have not.

* lsuw was designed for people with permanent and fast 
  connections to the internet. there may very well be
  lots of problems with modems and timeouts... we do not
  know .. 

* LSUW uses shellexecute to invoke an browser. The problem
  with this is that the browser does not _reload_ the page.
  if you happen to know how to invoke the default browser and
  make in reload a page .. send us a mail.

* LSUW can only study TEXT pages. bad things will happen if you
  try to poll jeypegg images.

Thanks
------

* All of you who are developing LiteSTEP!
* GreatAuk for the very handy lswtest

Authors
-------

We are the people who have devoted our free time to give you this 
fantastic app. 

Johan Redestig, johan@house5.se     [wharf module]
Viktor Martensson                   [Change check algorithm]
Anders Palsson                      [test]

The latest version should be available on:

http://www.house5.se/litestep