======================
ckDialog 0.1
======================

----------------------
Author: 	Chao-Kuo Lin 
Nick:		Chaku
E-mail:		chaokuo@iname.com
WWW:		http://cklin.cjb.net or http://chaku.ls2k.org
Released Date:	08/17/2001
----------------------



======================
E-mail me any bugs and how you use this module
======================
Before you begin reading this readme, I would like you ask you to
drop me an e-mail @ chaokuo@iname.com about any bugs in this module 
or how you are using this module.  If the e-mail address doesn't work, 
you can always reach me on IRC, efnet, dalnet, openprojects.net, 
undernet, you name it(thanks to Nexter) in channels #lshelp and #litestep.


======================
Introduction
======================
This module is aiming for people who want to make modules but don't have the knowledge about 
programming or module programmers who do not want to make a gui interface for their module.  
So basically what this module does is letting you specify window layout, buttons, listboxes, 
and etc. and you can have a fully working dialog box just as if you can do windows programming.  
The possibility for this module I believe is endless when used in conjunction with other modules.  
The first dialog I did to test was a dialog that let's you enter a line of text, 
and when you click on its button, it'll call the litespeak's bang "!Speak" and 
speak the text you entered.  I think if you use any timer module with this, 
you can create animated effect, make your own property sheet dialog, or make your own file manager, 
your vwm UI, your own text, your calendar. Other possibilities are....I dont know..you tell me.

Using this module combining with scripting modules, windows scripting host scripts
(JScript, VBScript, and others), and the new shell core Raptor, who needs a module coder anymore?


======================
Mistakes in this readme
======================
I know there are going to be plenty because I was rushing things out.
I hope I didn't omit any features, and typo corrections are always welcome.
I am planning to probably make a HTML version for this and for the 
reference.txt


======================
Features
======================
*You can make your own dialog window, and pretty much everything.
*Support callback event handling
*Support variables evaluation(no operations), and built-in variables.
*Support user specified font type, font color, background color
*Many others...


======================
Note about examples
======================
Hopefully I'll be able to make some really useful dialogs and put some
nice examples up on my site @ http://cklin.cjb.net or http://chaku.ls2k.org
with more complex litestep scripting and some windows scripting host scripting.
Of course, you are always welcome to send me what you have.


======================
Before you begin
======================
ALWAYS REMEMBER TO START SMALL, THEN BUILD ON TOP OF THAT!!!!!!
It'll save you time to find out what was wrong in your syntax.


======================
Example
======================
I think the best way to learn how to use or do something is by example, so here it
is.


The following is a very simple example on how I created the LiteSpeak Dialog:

======================================================================
*ckDialog	new
*ckDialog	id	LiteSpeakDialog
*ckDialog	title	"LiteSpeak Dialog"
*ckDialog	size	300	300	300	50
*ckDialog	style   "wsclipchildren | wsoverlappedwindow"
*ckDialog		edit
*ckDialog		id	speakTextEdit
*ckDialog		size	0	2	235	44
*ckDialog		xstyle	"wsxclientedge"
*ckDialog		~edit	
*ckDialog		button
*ckDialog		id	speakButton
*ckDialog		title	"Speak"
*ckDialog		size	240	0	52	23
*ckDialog		~button	
*ckDialog	~new

*onckDialogEvent	LiteSpeakDialog.speakButton.click	"!ckExecEvaluate !Speak %[LiteSpeakDialog.speakTextEdit.title]"

======================================================================

The syntax should be easy to follow and understand. Now I'll explain line by line
what they do.

*ckDialog	new
----------------------
*ckDialog is the config name you have to prefix it in everyline in step.rc.
The keyword, "new", tells ckDialog.dll to start a new dialog template.


*ckDialog	id	LiteSpeakDialog
----------------------
id is an attribute, and it is how this dialog will be referred in the future when
you create a dialog, you give ckdialog.dll this id.  It is recommended that you use
one word for the id that is the id name can't have any spaces.


*ckDialog	title	"LiteSpeak Dialog"
----------------------
Title is another attribute, and since it's for a dialog so in this case the title will
be the window title when you create a dialog from this template.  Remember to quote the
title like "LiteSpeak Dialog" if your title is more than one word.


*ckDialog	size	300	300	300	50
----------------------
This is the size attribute where you specify the size for your dialog.  The four numbers
represent left, top, width, and height.  Remember don't quote the four numbers or ckDialog.dll
won't recognize it.


*ckDialog	style   "wsclipchildren | wsoverlappedwindow"
----------------------
The style attribute allows you to specify window styles, that is, how they look. In this
example, we are creating a window with overlapped window style, and it will clip its
children windows when drawing.  It is important that you have all your style quoted if
there are any spaces in between them.  And to specify multilple styles, you just separate
differnt styles with "|".  So it's like: style "style1 | style2 | style3 | style4".

*ckDialog		edit
----------------------
Alright, this line is a little different.  In this line we are signaling ckDialog.dll
to create an edit control inside the dialog we are creating.  An edit control is like 
an edit box where you enter text.  It is similar to create other controls like dialog, 
button, listbox, combobox, and static.


*ckDialog		id	speakTextEdit
*ckDialog		size	0	2	235	44
*ckDialog		xstyle	"wsxclientedge"
----------------------
The next two lines are similar to what we did in the first few lines, however the
only difference is that we have an xstyle attribute.  What xstyle attribute does
is similar to style, but xstyle gives to some more options to specify to give your
controls' and dialogs' looks.  For example, you can put "wsxtoolwindow" and you'll
have a dialog that looks like a toolwindow similar to the photoshop ones.  The syntax
for xstyle is similar to style where you can use "|" to separate all the styles you want.

You can also specify a title for edit control, which will be the default text that'll appear
inside the edit box.


*ckDialog		~edit	
----------------------
The edit with a ~ in front tells ckDialog.dll that our edit definition is done and we
are about to do something else.  It is important that you close a definition like this 
or you'll have unexpected results.


*ckDialog		button
----------------------
Alright, similar to the edit control, right now we are going to make a button control
so we can click on it and speak the words.


*ckDialog		id	speakButton
----------------------
We assign the button with id "speakButton"


*ckDialog		title	"Speak"
----------------------
The button will have the work Speak on it.

*ckDialog		size	240	0	52	23
----------------------
This specify the button's size

*ckDialog		~button	
----------------------
We are closing the definition for button.



*ckDialog	~new
----------------------
We are closing the definition for our whole dialog template.
The template for this dialog is done, and we can create one whenever we want.




*onckDialogEvent	LiteSpeakDialog.speakButton.click	"!ckExecEvaluate !Speak %[LiteSpeakDialog.speakTextEdit.title]"
----------------------
This is not part of the dialog template.  It's actually an event handling config, 
for detailed explaination please check the event handling section below.  
Bascically it's placing the bang commang !ckExecEvalute as a handler to be called when the button
speakButton is clicked.




For all the styles you can use and different controls you can have, please
consult with ckDialog_reference.txt








======================
Dialog Template Data Types
======================
Before going to the dialog template syntax, I have to explain some basic data types
and their definition, though they don't seem to be really helpful.






boolean
======================
can be either "true" or "false", somtimes it is expanded beyond true and false to give
more options


text
======================
It has to be quoted if it is more than two words.
Example:
	thisistext
	"This is text"
	123456blah

If you want to include characters suchs as '%', '[', ']', '\', you have to use the escape sequence
similar to C/C++ and many other languages. 

Example:
	"c:\\litestep\\litestep.exe"
	"100\%"
	"1000\r\n"	<- this would have the same result as in C/C++, the result is 
				similar to typing 1000 then press "enter", for writing files,
				you would get to a new line.





string
======================
String is very much like text except it HAS to start with an alphabet or underscore '_'.
When it contains more than two words, it has to be quoted too, and immediately following the
quote will have to be an alphabet or underscore '_'.



single_word_string
======================
Can't have more than two words and has to start with an alphabet or underscore '_'



ored_string
======================
ored_string is like having several sing_word_string separated by "|", and the whole thing
has to be quoted if there are spaces in between.  This is mainly used with styles
Example:
	string1|string2|string3
	"string1 | string2 | string3"

	string1 | string 2 | string3 <- this is incorrect




int
======================
Represents an integer, which can be negative.



unsigned_int
======================
Similar to int, but this can only be positive


hex
======================
Use this for color mostly, and it would represent RGB
Example:
	001AFF		<- Red: 00	Green: 1A	Blue: FF

	FFFFFF		<- Red: FF	Green: FF	Blue: FF
	


control_symbol
======================
control_symbol's are what you use to specify a new control such as edit, button, and etc
in your dialog. You have to remember to close your definition with ~control_symbol.
valid control symbols so far are: 
	new, dialog, button, edit, listbox, combobox, static
The new cannot appear anywhere inside a dialog template, but has to be in the first and
the last place.


attribute 	value
======================
An attribute almost always contains a key, value pair where attribute name is the key such
as title, id, size, and the next thing specified is a value separated by space, newline or tab.  
Remember if you specify a key, it HAS to be a single_word_string, and you HAVE to have a value or 
ckDialog.dll will not be able to recognize what you are doing.  Therefore, when you define a variable,
it has to follow this rule










======================
Dialog Template Syntax
======================


The syntax for dialog template is very simple, basically it follows the the rule
below:

======================================================================
control_symbol
	attribute1 	value
	attribute2 	value
	attribute3 	value
	attribute4 	value
	userdataname	value
	control_symbol
		attribute5 	value
		attribute6 	value
		attribute7 	value
		attribute8 	value
	~control_symbol
~control_symbol
======================================================================



So for a new dialog template, obvious you'll have to have: new and ~new enclosing the dialog's
attributes, title, id, size, style, xstyle and etc. It would look like this:

======================================================================
*ckDialog	new
*ckDialog	title		"window title"
*ckDialog	id		myDialogID
*ckDialog	size		0	0	100	200
*ckDialog	style		"wsclipchildren | wsoverlappedwindow"
*ckDialog	xstyle		"wsxclientedge"
*ckDialog	font		"Comic Sans MS"
*ckDialog	fontcolor	0000FF
*ckDialog	bgcolor		000000
*ckDialog	control_symbol
*ckDialog	...
*ckDialog	~control_symbol
*ckDialog	control_symbol
*ckDialog	...
*ckDialog	~control_symbol
*ckDialog	~new
======================================================================


title	text
----------------------
The title will be the window title for the dialog, It has to be quoted if it's more than one
word.


id	single_word_string
----------------------
The id will be the identifier when you want to creat this dialog or perform action on it. The id
can be anything starting with an alphabet or underscore '_', anything else will not be recognized.


size	unsigned_int	unsigned_int	unsigned_int	unsigned_int
----------------------
(size	left	top	width	height)
The size would be the dimension for your dialog, in this example, it would be located at the
left top of your screen with width and height of 100, and 200 pixels.  Please don't quote the
four unsigned_int together or you'll get unexpected result.


style	ored_string
xstyle	ored_string
----------------------
You can combine differnt style with "|" but they have to be quoted if there are any
space between them


font	text
----------------------
obviously the text here has to be a valid font type on the user's machine.


fontcolor	hex
bgcolor		hex
----------------------
specify the font color to use with this control, i'm not to sure how much use it
would be for the dialog, but it's useful for edit, buttons, and etc.




For creating other types of control a button for example inside the dialog template we created
above, you would do something like this

======================================================================
*ckDialog	new
*ckDialog	title		"window title"
*ckDialog	id		myDialogID
*ckDialog	size		0	0	100	200
*ckDialog	style		"wsclipchildren | wsoverlappedwindow"
*ckDialog	xstyle		"wsxclientedge"
*ckDialog	font		"Comic Sans MS"
*ckDialog	fontcolor	0000FF
*ckDialog	bgcolor		000000
*ckDialog	button
*ckDialog	id		myButton
*ckDialog	title		"Text that appears on my title"
*ckDialog	size		10	10	50	30
*ckDialog	bgcolor		FFFF00
*ckDialog	
*ckDialog	~button
*ckDialog	~new
======================================================================

For all the things you can put, the attribute names, control names, styles, xstyles, and
colors please refer to the ckDialog_reference.txt





======================
Event Handler Syntax
======================
Event handling syntax is very easy, basically you just add a config with the following
format:

*onckDialogEvent	ID.event		"exe or bang command to be executed when the event occurs"

Where the ID has to be specified starting with your dialog template id.

Example ID.eveent:	
		myDialog.init
		myDialog.myButton.click
		myDialog.anotherDialogInsidemyDialog.myButton.dblclick
		myDialog.anotherdialogInsidemyDialog.yetanotherDialog.myButtoninside3LevelsofDialog.click

The 3rd example give above would have a dialog template similar to:

======================================================================
new
id	myDialog
dialog
	id	anotherdialogInsidemyDialog
	dialog
		id	yetanotherDialog
		button
			id	myButtoninside3LevelsofDialog
		~button
	~dialog
~dialog
~new
======================================================================











======================
Dialog Creating Bang
======================
!ckCreateDialog		dialog_template_id	dialog_id

the dialog_template_id would be your id specified in the template, and dialog_id
would be the new id you assigned for the active dialog.  

Take the following example:
======================================================================
new
id	myDialog
dialog
	id	anotherdialogInsidemyDialog
	dialog
		id	yetanotherDialog
		button
			id	myButtoninside3LevelsofDialog
		~button
	~dialog
~dialog
~new
======================================================================
you would use a creation bang:


!ckCreateDialog		myDialog	activeDialogID



so you would refer to the newly created dialog with id "activeDialogID".
It is ok that you specify the same id for your active dialog_id.


!ckCreateDialog		myDialog	myDialog


so the bang above should be legal.






======================
Action Bang
======================
!ckAction	ID.Action 	arguments

The way your refer to the id is similar to the way you refer the a particular ID
in the "Event Handler Syntax" section, exception that this time you'll have to specify
the new active dialog id you specified in !ckCreateDialog.  If the new active dialog id
is the same as the template id, then there wouldn't be any difference.

Example:
	activeDialogID.set	"my new title"
	activeDialogID.show	false
	activeDialogID.state	disable
	activeDialogID.move	10	10

This bang will be very useful when updating your dialog's state such as disabling
an edit box, disabling a button, or hiding or showing differnt child dialogs inside
the dialog to create property sheets effect.


*For all the actions you can do, please refer to the ckDialog_reference.txt



======================
Variables, User Defined Variables &
Variable Altering
Variables Evaluation Bang
======================

%[examplevariable.attribute]
!ckSetVariable		ID.attribute		value
!ckExecEvaluate 	Bang_you_want_or_exe_file 	arguments_for_that_bang_or_exe



Variables
----------------------
Syntax for variables: 	
	%[id.attribute]

Example:
	%[myDialog.myListBox.all]
	%[myDialog.myListBox.sel]
	%[myDialog.myListBox.all(3)]




!ckSetVariable	id.attribute
----------------------
The bang command !ckSetVariable allows you to set an attribute of a particular control, however, you
have to keep in mind that some attributes are read-only, such as title, state, size.  The only way to
alter those read-only variables would be using the !ckAction bang command.



!ckExecEvaluate		"bang command or exe files"	arguments
----------------------
Alright, another ability is that you can store user defined variables inside the template 
definition, and you can access the built-in variable such as title, and etc.

In the first example in the "Example" section, you saw there was a line specifying this

*onckDialogEvent	LiteSpeakDialog.speakButton.click	"!ckExecEvaluate !Speak %[LiteSpeakDialog.speakTextEdit.title]"

And by now you should know that it's an event handling config which you specify the button to execute
the bang command "!ckExecEvaluate !Speak %[LiteSpeakDialog.speakTextEdit.title]" when it's clicked.
This bang coammnd, !ckExecEvaluate, in fact will evaluate the the line that comes after it, and translate
any variables specified in it.  In this example, the variable %[LiteSpeakDialog.speakTextEdit.title] 
would represent the current text inside the edit box.  After translating the variable, 
!ckExecEvaluate would call the bang command !Speak and supply it with an argument which is the text from our
edit box.


*An important thing to remember is that the arguments you put after the bang command you want to execute.  
You'll have to leave them the same way to call the bang, that is you quote what you usually quote and 
don't worry about them. What this mean is, take a bang you usually specify in step.rc with its arguments, 
or you would type them in lsxcommand, and just add !ckExecEvalute in front of it, 
Just replace where you want to replace with the variables and boom you are done.  

Take ckHotspots for example, we want to dynamically add a hotspot:

This is what we usually do:
	!HotspotAdd 0 0 32 32 "!Bang its_arguments more_arguments" !none

as you see we have to quote the first bang because it contains arguments and ckHotspots will be confused if
it's not quoted and mistaken the arguments for the bang to call when your mouse leaves.  Ok, if we want add
a hotspot, but with a user specified bang name, we can just add !ckExeEvalute in front, like this:

!ckExecEvaluate 	!HotspotAdd 0 0 32 32 "!%[mydialog.txtMyDog.title] its_arguments more_arguments" !none



Easy isn't it?




User Defined Variables
----------------------
Now, if you have payed clsoe attention, you must noticed that you can specify attributes like:

userdataname	value

In the dialog template, this means you can specify your own variables stored.  The userdataname has
a datatype of single_word_string while value just has the datatype text. (If you can't remember what
they are please refer to the dialog datatype section)

This means that your own variables can be evaluated and set just like any other built-in variables.




*For a list of all the built-in variables please refer to the ckDialog_reference.txt

======================
Installation
======================
just add an entry in your step.rc with the line like this:

	LoadModule	"C:\LiteStep\ckDialog.dll"

Adjust to the appropriate path where the dll is located.

======================
Step.rc configs
======================
*ckDialog
*onckDialogEvent

please refer to the syntax section above and ckDialog_reference.txt for details.

======================
Bang Commands
======================
!ckAction	ID.Action		arguments
!ckExecEvaluate	!bang		arguments to that bang

again, please refer to the sections that discuss about the above bang commands
and ckDialog_reference.txt for details.


======================
Useful Building Tips
======================
Now that you shouhld be fairly familiar with the syntax, I will give you some tip on how
to build a successful dialog.

1.  Be clear on what you want to build, is it going to be very complex or simple.

2.  Always draw on the paper first what your dialog going to look like and where should
the controls be placed, and how they are going to interact with each other.

3.  After drawing, approximate the size and dimension of each control, then you should be
ready to build in your step.rc

4.  START SMALL, always start with just a dialog, that is just a new, ~new statement with necessary attributes
such as title and color in between.  Then you can add in bits and peices.

5.  Double check your template so that you don't have typos or anything, and it is also useful to check the Common
Mistakes section below.

======================
Common Mistakes
======================
*Always remember to close a control or a new statement with its coresponding closing statement
such as ~new and ~dialog.

*You are putting a style inside xstyle attribute or vice version. Or putting a style for button
in a dialog's style.

*When specifying filename, you use single backslash '\' instead of double backslash '\\'

*Some functions might not work if you don't have the appropriate styles or xstyles specified

*You commented out a portion of the template, but since the ;'s are too small that you didn' see them commented out.
This might cause parsing error when you are referring to a control's id that's non-existant.



======================
Error Messages
======================
I'm sorry that the error messages might not be very informative when it encounters parsing
error.  I will make sure that the error messages will be more helpful in the future versions.



======================
Useful References
======================

Microsoft Scripting Technology Homepage:

http://msdn.microsoft.com/scripting/default.htm?/scripting/start.htm

The JScript page:

http://msdn.microsoft.com/scripting/jscript/default.htm

The VBScript page:

http://msdn.microsoft.com/scripting/vbscript/default.htm

There are other scripting languages that supports wsh such as
perl, you can also check them out.

Of course any litestep modules especially scripting modules would be very
useful, too.

======================
Future Plans
======================
.I think I forgot to add something such as the ability to check a button's state
.Dynamic control template insertion, either from a line of text or from a file.
.Tab Stop support.
.Inherited attributes.
.Add in some other windows function such as the ability to capture mouse, set timer, and etc, 
so for example you can then make windows without title bar and still be able to move it by dragging.
.Icons and bitmaps for buttons, listboxes, comboboxes.
.Add new controls such as treeview, scrollbar, menues, and others.
.Add RevID support for all the active dialog you created through !ckCreateDialog
.Release exe version


======================
Known Bugs
======================
.The color for combo box works to some extent but might not yeild desired effect.
.No RevID in the aboutbox, and probably won't add it.




======================
History
======================

0.1	-	8/15/2001
	first release
