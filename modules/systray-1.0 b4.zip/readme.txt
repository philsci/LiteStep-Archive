system tray module for Litestep (systray.dll), 1.0 beta 4
--

Systray.dll is a system tray replacement module for Litestep which provides
greater control over appearance, placement, and icon layout.

Installation

  Systray.dll requires a recent development build of both desktop.dll
  and lsapi.dll. If you have a devbuild from May 26 or later, or you have
  the DLLs supplied with earlier betas of systray.dll, then you have the
  necessary updates already. If you want just desktop.dll and lsapi.dll
  without having to install the entire devbuild, you can download these
  from my page at: http://maduin.dasoft.org/systray/desktop.zip.
  
  Once you have the updated DLLs installed, add a LoadModule line
  for systray.dll to your step.rc (assuming you want systray.dll to run
  as a desktop module as opposed to a wharf module). Example:
  
  LoadModule C:\Litestep\systray.dll
  
  You will also need to add the line "NoSystray" to your step.rc in
  order to disable the default LS system tray.
  
  Included in the zip file is systray.rc, a sample configuration file for
  systray.dll. It contains only systray.dll configuration options and
  can be pasted directly into your step.rc (or theme.rc) to give you
  a template to work from when configuring systray.dll.
  
  As of beta 3, desktop.dll is no longer required to be loaded to load
  systray.dll. But if desktop.dll is loaded, it must be the May 26 build
  or later.
  
Dock to Wharf

  If you want the systray in a wharf tile instead of on the desktop
  then you can load systray.dll as wharf module instead of a load
  module. Instead of the LoadModule line, use something like:
  
  *Wharf "System Tray" .none @C:\Litestep\systray.dll
  
  Functions such as always on top, dragging, and dynamic sizing are
  not available while the tray is docked to the wharf.
  
Configuration

  SystrayAlwaysOnTop
  
    If this option is present, it causes the tray window to appear
    on top of all other windows. By default the tray is anchored
    to the desktop.
  
  SystrayAutoSize "<horizontal> <vertical>"
  
    Determines how the tray is automatically resized when icons are
    added or removed. Horizontal can be left or right and vertical
    can be up or down. Defaults are right and down. This option
    controls how the tray window is resized, where SystrayDirection
    controls how the icon are placed inside the tray.
    
  SystrayBitmap "<bitmap> <border-left> <border-top> <border-right> <border-bottom> <method>"
  
    Sets the bitmap file and border widths used for skins. See the
    discussion of skins below. By default the tray is transparent. If
    the method parameter has a value of "tiled" then the dynamic
    sections of the skin bitmap are tiled rather than stretched. It is
    recommended that for tiled skins you make the tile reasonably
    large in order to reduce flicker during painting.
  
  SystrayBorderDrag
  
    If this option is present, you will be able to drag the tray by
    pressing and holding the left mouse button over the border or
    any area not covered by an icon.
  
  SystrayBorderX <n>
  SystrayBorderY <n>
  
    Specifies the amount of space (in pixels) between the border
    and the icons, horizontal and vertical respectively. Default is 0.
  
  SystrayDirection "<direction> <wrap-direction>"
  
    Controls the icon layout. The direction can be one of: left, right,
    up, down. The wrap-direction can be up or down if direction is
    left or right (horizontal tray), or left or right if direction is up
    or down (vertical tray). The default direction is right and the
    default wrap-direction is up.
  
  SystrayHidden
  
    If this command is present the tray will be initially hidden. Use
    !SystrayShow or !SystrayToggle to show it.
    
  SystrayIconSize <n>
  
    Tray icons are stretched (if necessary) to be n x n pixels in
    size. The default is 16.
  
  SystrayMinWidth <n>
  SystrayMinHeight <n>
  
    Ensures that the tray will always be at least n pixels in width
    or height. The default is -1 (no minimum).
  
  SystrayMaxWidth <n>
  SystrayMaxHeight <n>
  
    Ensures that the tray will never exceed n pixels in width or
    height. The default is -1 (no maximum).
  
  SystrayX <n>
  SystrayY <n>
  
    Sets the x or y position (screen coordinates, pixels) of the
    tray. Negative values are interpreted relative to the bottom
    right corner of the screen. The default is -1 (screen width or
    height).
  
  SystraySnapDistance <n>
  
    While dragging, if the tray is moved to a position less than
    n pixels from a screen edge, it will be snapped to that edge.
    If n is 0 then snap to edge is disabled. Default is 4.
  
  SystraySpacingX <n>
  SystraySpacingY <n>
  
    Specifies the number of pixels of spacing between icons in
    the tray, horizontal and vertical respectively. Default is 2.
  
  SystrayWrapCount <n>
  
    Specifies the maximum number of icons on a row (horizontal)
    or column (vertical) before wrapping. The default is -1 (do not
    wrap).

Bang Commands

  !SystrayHide
  
    Hides the tray window.
  
  !SystrayMove <x> <y>
  
    Moves the tray to screen position x, y (in pixels).
  
  !SystrayShow
  
    Shows the tray window after having been hidden.
  
  !SystrayToggle
  
    Toggle the visible state (show/hide) of the tray window.

Skins

  Instead of a standard transparent system tray, systray.dll also
  supports skins (bitmapped background and borders). The systray
  uses 9 bitmaps: a bitmap for each corner, one for each side
  and one for the icon area. For efficiency, all these bitmaps are
  stored in a single .bmp file. The SystrayBitmap commands takes
  this .bmp file along with four border widths as its parameters.
  
  These border widths specify the widths (left and right borders)
  and heights (top and bottom borders) of the borders. Corner
  bitmaps are determined by the borders they join, ie, the top
  left corner's bitmap has the width of the left border and the
  height of the top border. The width of the top and bottom
  borders, the height of the left and right borders, and both
  the width and height of the center bitmap are calculated from
  the border widths and the size of the entire bitmap.
  
  As I found out, Enlightenment has a similar function called edge
  scaling (actually, it's a function of Imlib). If you're familiar
  with that, skins work the same way.
  
  Note: Not all the borders have to be present. If you don't
  want a border, use 0 as its width. It is also possible to have
  no borders, just a single bitmap.
  
  Pseudo-transparency is also available in skins. Areas which are
  to be transparent should be pink (RGB 255, 0, 255). Corner bitmaps
  always support transparency, and border and center bitmaps
  support it when the drawing method is set to "tiled".
  
  I've added a collection of sample configurations which take
  advantage of skins. Check out the samples dir in the zip.

--
Maduin <maduin@dasoft.org>
