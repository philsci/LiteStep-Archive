                                                                            |
                                   LITE
                                     STEP
               +----------------+       _   +----------------+
               |  EasyCuts V3.0 |   |  |_   |  EasyCuts V3.0 |
+----0-++-0----+----------------+   |_  _|  +----------------+--------------+
| README..FILE |                                             |   By Ender   |
+----0-++-0----+                     DLL                     +----0-++-0----+

+-------+
|Changes|
+-------+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
| v3.0 - Many, MANY, wonderful changes. So there. Released because Garg      |
|        was after a feature, and because I was in the wrong place, at the   |
|        wrong time :P  [N.b: Sounds probably don't work. Sorry]             |
|        Also has a few compatibility fixes for DarkStep                     |
|        Note the documentation below MAY be incorrect. You will probably    |
|        -not- need to press a key after right clicking, to drag             |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+


+------------+
|Installation|
+------------+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
| First, backup your step.rc just in case :)                                 |
| Next, replace the 'LoadModule Shortcut.dll' line in your step.rc with;     |
|                                                                            |
| LoadModule c:\Module Path\ECuts4.dll                                       |
|                                                                            |
| where 'C:\Module Path\' is the path to your Litestep modules.              |
|  (ie: LoadModule c:\litestep\Ecuts4.dll)                                   |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+                           


+---------+
|Shortcuts|
+---------+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
|                                                                            |
| A typical Shortcut entry in your step.rc will look like this;              |
|                                                                            |
| *Shortcut  "Title"  X  Y  picture.bmp  "command"                           |
|                                                                            |
| '*Shortcut' tells Litestep that this line is a Shorcut entry.              |
|                                                                            |
| "Title" is the name of the shortcut.                                       |
|  It can be more than one word, as long as you put quotes around the words. |
|                                                                            |
| 'X' is the X coordinate of where the Shortcut will be on the desktop.      |
| 'Y' is the Y coordinate of where the Shortcut will be on the desktop.      |
|                                                                            |
| 'picture.bmp' is the image you will use for the Shortcut.                  |
| This can either be the path to a bitmap, or an icon.                       |
| If you choose to use an icon, it can any icon from any file. For example;  |
| '.extract=c:\quake2\quake2.exe,0'                                          |
| The .extract= tells Litestep to extract icon 0 from c:\quake2\quake2.exe   |
| and use it as this Shortcut's image. Using '.winicon' will use the         |
| default icon for the program that the Shortcut executes.                   |
| If you don't want to specify an image, enter '.none' as the image.         |
|                                                                            |
| "Command" is the command the Shortcut executes when clicked on.            |
| This can be either a file or !Bang command.                                |
| If the command has spaces in it, put quotations marks around the entire    |                           | command.                                                                   |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+


+------------------+
|Advanced Shortcuts|
+------------------+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
|                                                                            |
| A more complex Shortcut entry in your step.rc will look like this;         |
|                                                                            |
| *Shortcut "Title" X Y picture.bmp mouseover.bmp clicked.bmp #OTHM "command"|
|                                                                            |
| 'mouseover.bmp' is the image that the Shortcut uses when you put the mouse |
| cursor over it.                                                            |
|                                                                            |
| 'clicked.bmp' is the image that the Shortcut uses when you click on it.    |
|                                                                            |
| '#0THM' are Shortcut flags, and are explained below.                       |
|                                                                            |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+


+----------------+
|Moving Shortcuts|
+----------------+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
|                                                                            |
| To reposition Shortcuts, right click on them. The mouse pointer should     |
| change to the 'move' pointer. If you made a mistake, you can press escape  |
| at any time. Now, press a key on the keyboard to confirm you want to move  |
| this shortcut, or escape to cancel.                                        |
| You can now use the mouse, or arrow keys, to move the shortcut around on   |
| screen. Press escape to abort, or (once you have it in final position)     |
| press the left mouse button, or return/enter, to keep it there.            |
|                                                                            |
| To move shortcut; right click on shortcut, press a keyboard key, move      |
|                   shortcut where you want it, press left mouse button.     |
|                                                                            |
| This only keeps the Shortcut where you moved it until you reboot/recycle.  |
| If you want to SAVE where you moved it, so that it'll be there from now on,|
| you need to use the '!SnapShot' bang.                                      |
| Once you use '!SnapShot', your step.rc will be backed up as 'step.org',    |
| and the new positions will be saved. If you start messing up, you can      |
| recycle without doing a '!SnapShot' and your Shortcuts will return to      |
| their original positions.                                                  |
|                                                                            |
| (Warning note: When you do a !Snapshot, only your shortcut lines are       |
|  changed. Any manual changes to shortcuts since the last recycle will be   |
|  overwritten.                                                              |
|                                                                            |
| Putting 'ShortcutDragMode' in your step.rc allows you to change the way    |
| you can move a shortcut.                                                   |
|                                                                            |
| ShortcutDragMode 0 - This uses the default "right click, press a key."     |
| ShortcutDragMode 1 - This makes Shortcuts act like explorer, where you can |
|                      simply click and drag.                                |
| ShortcutDragMode 2 - This disables the moving of Shortcuts.                |
|                                                                            |
|      (See the next section, Right Click Behavior, for related info)        |
|
|              --- Adding Shortcuts from Explorer windows ---                |
|                                                                            |
| To ADD a Shortcut onto the desktop, simply drag it onto the desktop from   |
| the Explorer window, or some other drag/drop compatible file manager.      |
| Note that you can only drag/drop one Shortcut at a time.                   |
|                                                                            |
| Note that when using '!SnapShot', Shortcuts will be written in the same    |
| place they were in the step.rc, and any new shortcuts (made by dragging &  |
| dropping from a window) will be placed at the end of the step.rc           |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+

+---+
|RMB|
+---+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
| There are also three new Step.Rc options which control the behavior of the |
| Right Mouse Button (rmb), when applied to Shortcuts:                       |
|                                                                            |
| ShortcutMenu 0   :  Move on RMB click                                      |
| ShortcutMenu 1   :  Open Litestep popup on RMB click                       |
| ShortcutMenu 2   :  Open config menu on RMB click (incomplete)             |
|                                                                            |
| The last two modes are best used with ShortcutDragMode 1                   |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+

+--------------+
|Shortcut Flags|
+--------------+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
| You can combine Shortcut flags with each other for multiple effects.       |
|                                                                            |
|                      --- Shortcut groups ---                               |
|                                                                            |
| Shortcut groups are used so that you can hide, show, and move multiple     |
| Shortcuts with only one command.                                           |
| You specify the Shortcut group by adding '#X' before the Shortcut's        |
| command, where 'X' is the Shortcut group number.                           |
|                                                                            |
| *Shortcut "Games" 50 10 games.bmp #1 "!toggleshortcutgroup 2"              |
|                                                                            |
| The '#1' tells you that this Shortcut is in Shortcut group 1.              |
| To hide or show all Shortcuts in Shortcut group 1, you would use one of    |
| one of the following commands;                                             |
|                                                                            |
| "!ToggleShortcutGroup 1" This switches between Shortcut group 1 being      |
|                          shown and hidden.                                 |
| "!HideShortcutGroup 1"   This hides Shortcut group 1.                      |
| "!ShowShortcutGroup 1"   This shows Shortcut group 1.                      |
|                                                                            |
| If you don't want a Shortcut to be a part of any Shortcut group, then you  |
| would use '#0' as its Shortcut group.                                      |
|                                                                            |
|                      --- Always on top ---                                 |
|                                                                            |
| To make Shorcuts always on top, add the following line to your step.rc;    |
|                                                                            | 
| ShortcutsAlwaysOnTop                                                       |
|                                                                            |
| This will make ALL Shortcuts always on top.                                |
| If you would rather specify which Shortcuts are always on top, and which   |
| are not, do not add this. Instead, put a 'T' in the Shortcut flags.        |
|                                                                            |
| *Shortcut "Quake" 100 15 quake.bmp #0T "c:\quake\quake.exe"                |
|                                                                            |
| This makes the Shortcut in NO group, and always on top.                    |
| The bang '!ToggleOnTopShortcutGroup X' will toggle all Shortcuts in a      |
| Shortcut group (where 'X' is the Shortcut group's number) between being    |
| always on top and not being always on top.                                 |
|                                                                            |
| If you add the line "ScDesktopFloat" in your step.rc, Shortcuts will ONLY  |
| sit on-top of your desktop, while by default they are ontop of all your    |
| windows, etc, too.                                                         |
|                      --- Hidden Shortcuts ---                              |
|                                                                            |
| Adding an 'H' to the Shortcut flags makes that Shortcut start out hidden.  |
|                                                                            |
| *Shortcut "ICQ' 200 100 icq.bmp #2H "c:\icq\icq.exe"                       |
|                                                                            |
| This makes the Shortcut in Shortcut group 2, and hidden when you           |
| start/recycle Litestep. To show it, use the '!ToggleShortcutGroup' or      |
| '!ShowShortcutGroup' bangs mentioned above.                                |
|                                                                            |
|              --- Moving multiple Shortcuts simultaneously ---              |
|                                                                            |
| Adding an 'M' to the Shortcut flags will allow you to move all Shortcuts   |
| in a group at the same time by moving that Shortcut.                       |
|                                                                            |
| *Shortcut "Internet' 25 500 internet.bmp #1M "!toggleshortcutgroup 2"      |
|                                                                            |
| When you move this Shortcut, all Shortcuts in group '1' will also move.    |
|                                                                            |
|              --- Making Shortcuts immoveable ---                           |
|                                                                            |
| Adding an 'S' to the Shortcut flags will make that Shortcut immoveable.    |
|                                                                            |
| *Shorcut "Internet' 25 500 internet.bmp #1S "!toggleshortcutgroup 2"       |
|                                                                            |
| You wouldn't be able to move this Shorcut, no matter how hard you clicked! |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+


+--------------------+
|Maudin's Systray.dll|
+--------------------+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
|                                                                            |
| From Easycuts 2.5 onwards, if you use Maduin's systray, you can 'dock' it  |
| to a Shortcut group. This means it will hide/show with the group, and move |
| with a Shortcut group if you use a the #0M flag above. To do so, put the   |
| following line in your step.rc;                                            |
|                                                                            |
| SystrayDockToShortcutGroup #                                               |
|                                                                            |
| Where '#' is the number of the Shortcut group you want the systray to be   |                                                                | in.                                                                        |
|                                                                            |
| SystrayDockToShortcutGroup 1                                               |
|                                                                            |
| This would make the systray become part of Shortcut group 1.               |
|                                                                            |
| Bugs in this should be reported to Ender, not Maduin :)                    |
| Check the documentation of your version of Systray to see if it supports   |
| this feature.                                                              |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+


+--------+
|Features| 
+--------+----------------------------------------------------+--------------+
| Description                                                 | Status       |
+-------------------------------------------------------------+--------------+
| Movable Shortcuts                                           | Finished     |
| Drag/Drop Shortcut Creation                                 | Finished     |
| .winicon icon extraction                                    | Finished     |
| Always on top icons                                         | Finished     |
| Explorer like Dragging                                      | Finished     |
| Drag disable toggle                                         | Finished     |
| Master Drag Support                                         | Finished     |
| Systraydocktoshortcutgroup for Maudins SysTray              | Finished     |
| MouseOver trigger                                           | Debugging    |
| Showing Explorer desktop icons                              | Debugging    |
| Context sensitive menu                                      | In progress  |
+----------------------------------------------------------------------------+


+----------------------------------------------------------------------------+
|EasyCuts programmed 1999 Ender.      E-mail comments to Ender@vision.net.au |
|Under GPL (V2+).       Some code (C) 1997-99 The LiteStep Development Team  |
+----------------------------------------------------------------------------+
   

+---------------+
|Quick Reference|
+---------------+-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=+
|                                                                            |
|                        --- Step.rc Commands ---                            |
|                                                                            |
| ;; ShortcutDragMode # ;;                                                   |
|                                                                            |
| ShortcutDragMode 0 - This uses the default "right click, press a key."     |
| ShortcutDragMode 1 - This makes Shortcuts act like explorer, where you can |
|                      simply click and drag.                                |
| ShortcutDragMode 2 - This disables the moving of Shortcuts.                |
|                                                                            |
| ;; ShortcutsAlwaysOnTop ;;                                                 |
|                                                                            |
| This makes ALL shortcuts "Always on Top."                                  |
|                                                                            |
| ;; SystrayDockToShortcutGroup # ;;                                         |
|                                                                            |
| This docks Maudin's systray.dll to a shortcut group, where '#' is the      |
| Shortcut group number.                                                     |
|                                                                            |
|                       --- Bang Commands ---                                |
|                                                                            |
| ;;; !SnapShot ;;;                                                          |
|                                                                            |
| This saves the position of all Shortcuts into the step.rc file.            |
|                                                                            |
| ;;; !ToggleShortcutGroup # ;;;                                             |
|                                                                            |
| This shows a Shortcut group when it's hidden, and hides it when it's       |
| visible, where '#' is the Shortcut group number.                           |
|                                                                            |
| ;;; !ShowShortcutGroup # ;;;                                               |
|                                                                            |
| This shows all Shortcuts in a Shortcut group, where '#' is the Shortcut    |
| group number.                                                              |
|                                                                            |
| ;;; !HideShortcutGroup # ;;;                                               |
|                                                                            |
| This hides all Shortcuts in a Shortcut group, where '#' is the Shortcut    |
| group number.                                                              |
|                                                                            |
| ;;; !ToggleOnTopShortcutGroup # ;;;                                        |
|                                                                            |
| This toggles all Shortcuts in a Shortcut group between being always on top |
| and not always on top, where '#' is the Shortcut group number.             |
|                                                                            |
|                         --- Shortcut Flags ---                             |
|                                                                            |
| You can combine Shortcut flags with each other for multiple effects.       |
|                                                                            |
| ;;; Shortcut Groups ;;;                                                    |
|                                                                            |
| A Shorcut flag of '#1' will make that Shortcut in Shortcut group 1.        |
| A Shorcut flag of '#300' will make that Shortcut in Shortcut group 300.    |
|                                                                            |
| ;;; Always on Top Shortcuts ;;;                                            |
|                                                                            |
| A Shortcut flag of '#0T' will make that Shortcut always on top.            |
|                                                                            |
| ;;; Hidden Shortcuts ;;;                                                   |
|                                                                            |
| A Shortcut flag of '#0H' will make that Shortcut hidden when you           |
| start/recycle Litestep.                                                    |
|                                                                            |
| ;;; Moving Multiple Shortcuts ;;;                                          |
|                                                                            |
| A Shortcut flag of '#1M' will make is so that, when you move this          |
| Shortcut, it will move ALL Shortcuts in Shortcut group 1.                  |
|                                                                            |
| ;;; Static Shortcuts ;;;                                                   |
|                                                                            |
| A Shortcut flag of '#0S' will make that Shortcut immoveable.               |
+=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-+
