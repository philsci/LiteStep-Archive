#ifndef LSSETI_H
#define LSSETI_H

#include "resource.h"

/* Data Structures */
struct lsSETISettings {
	char TextFontFace[256];
	int TextSize;
	int x;
	int y;
	int width;
	int height;
	BOOL AlwaysOnTop;
	BOOL HiddenOnStart;
	COLORREF BGColor;
	COLORREF TextColor;
	int Timer;
	char Path[256];
	BOOL DebugMode;
};

#endif //LSSETI_H