/***********************************************************
*        lsSETI - lsSETI Litestep Module Code              *
*       Lightstep module to report SETI Status             *
*                         *  *  *  *                       *
* Last Update: October 28th 2000                           *
*                         *  *  *  *                       *
* Copyright (x) Owen Cutajar 2000                          *
*     v0.2 - Initial Distrib                               *
*                         *  *  *  *                       *
* built on lsSETI/tutorial by Visigoth - thanks mate !!    *
***********************************************************/

#include <windows.h>
#include "resource.h"
#include "exports.h"
#include "lsSETI.h"
#include "lsapi.h"

char *szApp = "LSSeti";
BOOL visible = FALSE;
HINSTANCE hInst = NULL;
HWND hWnd = NULL, hText = NULL;
HFONT hFont = NULL;
HBRUSH hBGBrush = NULL, hHollowBrush = NULL;
WNDPROC wpOld, wpBG;
struct lsSETISettings *cs;
char inipath[80];
FILE *stream;

/***********************************************************
* struct lsSETISettings *ReadSettings()                    *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - LPCSTR szPath                                       *
*      Pointer to Litestep's path.                         *
*                         *  *  *  *                       *
* Retrieves settings in the RC file and stores it all in a *
* local structure. Returns a pointer to a new structure.   *
***********************************************************/

struct lsSETISettings *ReadSettings(LPCSTR szPath)
{
	RECT screen;
	struct lsSETISettings *settings = (struct lsSETISettings *)malloc(sizeof(struct lsSETISettings));
	
	strcpy((char *)&inipath,szPath);
	strcat((char *)&inipath,"\\modules.ini");
  
	settings->x = GetPrivateProfileInt("lsSETI", "X", 100, inipath);
	settings->y = GetPrivateProfileInt("lsSETI", "Y", 20, inipath);
	settings->width = GetPrivateProfileInt("lsSETI", "Width", 100, inipath);
	settings->height = GetPrivateProfileInt("lsSETI", "Height", 20, inipath);
	settings->BGColor = GetPrivateProfileInt("lsSETI", "BGColor",0x00FFFFFF, inipath);
	settings->TextColor = GetPrivateProfileInt("lsSETI", "TextColor",  0x00005000, inipath);
	settings->TextSize = GetPrivateProfileInt("lsSETI", "TextSize", 14, inipath);
	settings->AlwaysOnTop = GetPrivateProfileInt("lsSETI", "AlwaysOnTop", TRUE, inipath);
	settings->HiddenOnStart = GetPrivateProfileInt("lsSETI", "HiddenOnStart", FALSE, inipath);
	settings->Timer = GetPrivateProfileInt("lsSETI", "Timer", 5, inipath);
	GetPrivateProfileString("lsSETI","TextFontFace","Arial",settings->TextFontFace,256,inipath);
	GetPrivateProfileString("lsSETI","Path","C:\\Program Files\\Seti2\\",settings->Path,256,inipath);

	settings->DebugMode = GetPrivateProfileInt("lsSETI", "DebugMode", FALSE, inipath);
	
	strcat(settings->Path,"state.sah");

	if (settings->DebugMode) 
		MessageBox(hWnd,settings->Path,szApp,MB_OK);

  /* Special Cases */

  screen.left = 0;
  screen.right = GetSystemMetrics(SM_CXSCREEN);
  screen.top = 0;
  screen.bottom = GetSystemMetrics(SM_CYSCREEN);

  /* Offsets */
  if(settings->x < 0)
    settings->x = screen.right + settings->x;

  if(settings->y < 0)
    settings->y = screen.bottom + settings->y;

	return settings;


}



/***********************************************************
* BOOL CALLBACK EditProc()                                 *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND hText                                          *
*      A handle to a window which this function handles    *
*    - UINT msg                                            *
*      The message sent to the textbox                     *
*    - WPARAM wParam                                       *
*      The WPARAM of this message                          *
*    - LPARAM lParam                                       *
*      The LPARAM of this message                          *
*                         *  *  *  *                       *
* Handles the window procedure for the command textbox.    * 
***********************************************************/

BOOL CALLBACK EditProc(HWND hText,UINT msg,WPARAM wParam,LPARAM lParam)
{
	char buf[_MAX_PATH];
	switch(msg) {
	case WM_CHAR:
		if(wParam==VK_RETURN) {
      BOOL cleared = FALSE;
			GetWindowText(hText,buf,sizeof(buf));
		//	ExecCommand(buf, FALSE);
			return 0;
    }
		break;
	}
	return CallWindowProc(wpOld,hText,msg,wParam,lParam);
}


/***********************************************************
* BOOL CALLBACK WndProc()                                  *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND hWnd                                           *
*      A handle to a textbox which this function handles   *
*    - UINT msg                                            *
*      The message sent to the textbox                     *
*    - WPARAM wParam                                       *
*      The WPARAM of this message                          *
*    - LPARAM lParam                                       *
*      The LPARAM of this message                          *
*                         *  *  *  *                       *
* Handles the window procedure for the main window         * 
***********************************************************/

BOOL CALLBACK WndProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	char message[80];
	char buffy[1000];
	char seps[]   = "\t\n";
	char *token;
	//char token2[10];

	switch(msg) {
	case WM_CREATE:
		{
		hFont = CreateFont(cs->TextSize,0,0,0,0,0,0,0,0,0,0,0,0,cs->TextFontFace);
		hText = CreateWindowEx(0,"EDIT","",WS_CHILD|ES_AUTOHSCROLL,2,2,cs->width-4,cs->height-4,hWnd,0,hInst,0);
    hBGBrush = CreateSolidBrush(cs->BGColor);
    hHollowBrush = (HBRUSH)GetStockObject(HOLLOW_BRUSH);
		if(!hText)
			MessageBox(hWnd,"Error creating window",szApp,MB_OK);
		wpOld = (WNDPROC)SetWindowLong(hText,GWL_WNDPROC,(long)EditProc);
		SendMessage(hText,WM_SETFONT,(WPARAM)hFont,FALSE);
		ShowWindow(hText,SW_SHOW);
		return 0;
		}
	case WM_CTLCOLOREDIT:
    {
      SetBkColor((HDC)wParam, cs->BGColor);
      SetTextColor((HDC)wParam, cs->TextColor);
      return (int)hBGBrush;
    }
	case WM_TIMER:	
		{

			if (cs->DebugMode) 
				MessageBox(hWnd,"Timer Activated",szApp,MB_OK);

			// Establish What to print
			if( (stream  = fopen( cs->Path, "r" )) == NULL )
				strcpy (message, "File Error" );
			else
			{	
			
			fread( buffy, sizeof(char),1000,stream);			
			token = strtok( buffy, seps );
			while( token != NULL )
			{
				//strncpy( token2, token, 5 );
				//if memcmp(token2,"prog=",5) = 0  ??? this isn't working for some reason !!!
				if ((token[0] == 'p') && (token[1] == 'r') && (token[2] == 'o') && (token[3] == 'g'))
				{
					strcpy(message,"SETI: 00.00%");
					message[6] = token[7];
					message[7] = token[8];
					message[9] = token[9];
					message[10] = token[10];
				}
		
				/* Get next token: */
				token = strtok( NULL, seps );
				}
				fclose ( stream );
			}
			SetWindowText (hText, message);
		}

    break;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}




/***********************************************************
* void BangTogglelsSETI()                                 *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND caller                                         *
*      The HWND of the window that called this !Bang       *
*      lsSETI.                                            *
*    - char *args                                          *
*      Should be the arguments to the function...          *
*                         *  *  *  *                       *
* Handles the !Bang lsSETI to toggle the visibility of    *
* the command box.                                         *
***********************************************************/

void BangToggleLsSETI(HWND caller, char *args)
{
	if (cs->DebugMode) 
		MessageBox(hWnd,"Bang!!",szApp,MB_OK);

	if(visible) {
		ShowWindow(hWnd, SW_HIDE);
		visible = FALSE;
	}	else {
		ShowWindow(hWnd, SW_SHOWNORMAL);
		visible = TRUE;
	}
	return;
}


/***********************************************************
* int initModuleEx()                                       *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND parent                                         *
*      The HWND of the parent window to this module        *
*    - HINSTANCE dll                                       *
*      The HINSTANCE of this DLL.                          *
*    - LPCSTR szPath                                       *
*      A pointer to the path where litestep is stored.     *
*                         *  *  *  *                       *
* Handles all initialization of lsSETI.  Returns 0         *
***********************************************************/

int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	WNDCLASS wc;

  hInst = dll;
  cs = ReadSettings(szPath);

  memset(&wc,0,sizeof(wc));
	wc.hInstance = hInst;
	wc.lpfnWndProc = (WNDPROC)WndProc;
	wc.lpszClassName = szApp;
	wc.hbrBackground = NULL;
	wc.hCursor = LoadCursor(NULL,IDC_ARROW);
	RegisterClass(&wc);
    hWnd = CreateWindowEx(((cs->AlwaysOnTop)?WS_EX_TOPMOST:0)|WS_EX_TOOLWINDOW,szApp,"",WS_POPUP,cs->x,cs->y,cs->width,cs->height,GetDesktopWindow(),0,hInst,0);
	
	SetWindowLong(hWnd,GWL_USERDATA,magicDWord); /* IMPORTANT */

	SetTimer(hWnd, 0, (cs->Timer*1000), NULL);

	AddBangCommand("!ToggleLsSETI",BangToggleLsSETI);
	

  if(!cs->HiddenOnStart) {
		ShowWindow(hWnd,SW_SHOWNORMAL);
		visible = TRUE;
  } else {
    ShowWindow(hWnd, SW_HIDE);
    visible = FALSE;
  }

    //Initialize timer
	

	return 0;
}


/***********************************************************
* int initModule()                                         *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HWND parent                                         *
*      The HWND of the parent window to this module        *
*    - HINSTANCE dll                                       *
*      The HINSTANCE of this DLL.                          *
*    - wharfDataType *wd                                   *
*      A pointer to a structure of info about litestep     *
*                         *  *  *  *                       *
* Handles all initialization of lsSETI.  Returns 0         *
***********************************************************/

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}


/***********************************************************
* int quitModule()                                         *
*                         *  *  *  *                       *
*    Arguments:                                            *
*                                                          *
*    - HINSTANCE dll                                       *
*      The HINSTANCE of this DLL.                          *
*                         *  *  *  *                       *
* Handles all of the unloading of this DLL.                *
***********************************************************/

int quitModule(HINSTANCE dll)
{

	RemoveBangCommand("!ToggleLsSETI"); 

	KillTimer(hWnd, 0);

	free(cs);
	DestroyWindow(hWnd);
	UnregisterClass(szApp,hInst);
	DeleteObject(hText);
	DeleteObject(hFont);
	return 0;
}