lsSETI v0.2
===========

Written by Ugh!! - 28/10/2000

Synopsis
--------
Litestep module which lets you monitor the progress of your SETI@Home program. Module displays a small text window with percentage progress. Simple, but effective.


Installation & Configuration
----------------------------

step.rc: 
-=-=-=-=
Add lsSETI to LoadModule section of step.rc
Example: 
  LoadModule c:\litestep\lsSETI.dll


Modules.ini:
-=-=-=-=-=-=
lsSETI takes a number of configuration parameters from Modules.ini. Most of the parameters are self-explanatory. Most important is the (Path) parameter which specifies the path to the SETI@Home installation you want to monitor. The full list of parameters is listed below:

[lsSETI]
X=280				
Y=1				
Width=90
Height=20
BGColor=0x00005000
TextColor=0x00FF00FF
TextSize=14
TextFontFace=Arial
Timer=5
Path=c:\Program Files\Seti2\
AlwaysOnTop=1
HiddenOnStart=0


Bang Commands
-=-=-=-=-=-=-
lsSETI also has a !Bang command available to turn the module display on and off. The command is:
!ToggleLsSETI


Contact
-------
Please report any problems/requests to ugh@pobox.com. I look forward to hearing any comments