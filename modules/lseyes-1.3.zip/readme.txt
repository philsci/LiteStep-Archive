LSEyes 1.3     (c) 1998 Christoph Handel
========================================
    The famous X-Eyes for Litestep








What it does:

A Pair of Eyes watching your Mousearrow. 



Installation:

Just put the DLL in your LS-Directory, the BMP in your IMG-Dir
and this in your RC
*Wharf text LSEyes.bmp @c:\Litestep\lssdk.dll

To set Colors and Radius put this in your modules.ini. If not present the 
default values (as listed) will be used. 
[LSEyes]
BallColor=   0x000000
BallPenColor=0x000000
EllipseX=    7
EllipseY=   22
BallRadius=  5
LeftBallX=  16
LeftBallY=  32
RightBallX= 48
rightBallY= 32



BallColor:     The Color used for filling the Eyeball
BallPenColor:  The Color used for drawing the Line of the Eyeball
EllipseX:      The Horizontal ellipse-radius  for the ball-point
EllipseY:      The vertical ellispe-radius for the ball-point
BallRadius:    The Radius of the ball-point
LeftBallX:     The horizontal position of the left Eye Center
LeftBallY:     The vertical position of the left Eye Center
RightBallX:    Hey look at LeftBallX and take a guess.

The Ellipse is the bounding for the Eyeball-Center. You need to substract the Ball-Radius yourself. 

All colors are given in hex Values. blue-green-red. Wrong colors will
hopefully result in a normal black Eyeballs and no crash.

I only draw the two Eyeballs. For a complete eye, you need to use a 
background (like LSEyes.bmp). Transparency is supported.

To make a Cyklop set the BallCenters the same postition.

To use Cardman (by Erik Harris) use these values: 
[LSEyes]
BallColor=0x000000
BallPenColor=0x000000
EllipseX=   8
EllipseY=   10
BallRadius= 2
LeftBallX=  25
LeftBallY=  32
RightBallX= 42
RightBallY= 33

*Wharf text LSEyes_Cardman.bmp @c:\Litestep\lssdk.dll



Contact:

eMail to handel@hrzpub.tu-darmstadt.de
SEND comments, questions, bug-reports, and hints! And 
if you like the programm a PICTUREPOSTCARD to:

   christoph handel
   pallaswiesenstr.14
   d-64289 darmstadt
   germany




Known Bugs:

Eyes won't move when Arrow is in Titlebar or Scrollbar of a window 
(this IS a windows-bug, there's no MouseMessage sent, blame Microsoft)

Some conflicts with directInput and Intellimouse were reported. I don't
have this mice and do not play (at least not under NT ;-). Please let
me know if you have any problems.





Technical:

Made with Delphi 2.0. Tested under NT 4.0 SP1 and SP3.
This is not a port of the X-Eyes. I don't have the source for that...
I made it all by myself.
For the Sourcecode mail me. (Be warned it's a mess lightly commented 
in a mix of german and english)



Thanks:

Bryan Kilian for the port of the LSSDK and for explaining me the Bitmap
The LS-Developers for the great Shell
Erik Harris for the Graphics of Cardman.
(hey Erik i dropped your adress, please send me a message)




story:

14.10.98 1.3   Thinking for the future (and LS24) it now should work with 
         a movable Wharfbar. Now new Number for that.
02.10.98 added Eriks Cardman (well i don't know the cartoon, but its a nice skin).
01.10.98 1.3   Now position of eye-center can be chosen.
26.09.98 1.2   I won't draw the Eye's anymore (The white surrounding). Instead I
         will use the background bitmap. You need to specify such a bitmap. Or you
         will only see two black balls moving arround. A Standard is included.
16.09.98 1.1b  Ok, the code is reduced. Delphi is a bit silly. Now I use API-Calls
         for reading the Ini-File.
13.09.98 1.1   Colors read from Modules.ini (Who wanted this feature? DLL is 
         50k instead of 30k)
24.08.98 1.0   background is painted (thanks to Bryan)
19.08.98 �0.91 fixed the HookChain (what a silly misstake).
18.08.98 Ready with �0.9 First Public Release.
         Found an untrapped Exception.
17.08.98 Success in defining global DLL-Variables using memory-mapped files.
16.08.98 Started programming.
15.08.98 Got LS �23e. Found a LSSDK for delphi. Just missed the cdecl.
10.06.98 Trying to transport LSSDK to Delphi. Failed.

