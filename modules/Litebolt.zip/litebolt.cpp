#include <windows.h>
#include <time.h>
#include "exports.h"
#include "lsapi.h"

const long magicDWord = 0x49474541;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

char* szAppName = "LiteBolt";
char* szVersion = "LiteBolt v1.0 (MrJukes)";

HINSTANCE hInstance;
HWND hwndMain, hwndParent, hwndDesktop;
int ScreenX, ScreenY;
int x, y, w, h;
char lsdir[256] = "";
int msgs[] = {LM_GETREVID, 0};

HBRUSH bgbrush;
HBITMAP bgbmp;
BOOL USEBGCOLOR;

int STEP, LINESIZE, NUM_BOLTS, NUM_PENS, TIMER;
HPEN* pens;
POINT* points;
int numpoints=0;

void BangShow(HWND caller, const char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangHide(HWND caller, const char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void LoadSetup()
{
	char temp[256];

	hwndDesktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!hwndDesktop) hwndDesktop = GetDesktopWindow();

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!LiteBoltShow", BangShow);
	AddBangCommand("!LiteBoltHide", BangHide);
	AddBangCommand("!LiteBoltToggle", BangToggle);
	
	STEP = GetRCInt("LiteBoltStep", 5);
	LINESIZE = GetRCInt("LiteBoltSize", 10);
	NUM_BOLTS = GetRCInt("LiteBoltNumBolts", 4);
	NUM_PENS = GetRCInt("LiteBoltNumPens", 3);
	TIMER = GetRCInt("LiteBoltTimer", 100);

	x = GetRCInt("LiteBoltX", 0);
	if (x < 0) x = ScreenX+x;
	y = GetRCInt("LiteBoltY", 0);
	if (y < 0) y = ScreenY+y;
	w = GetRCInt("LiteBoltW", 400);
	h = GetRCInt("LiteBoltH", 25);

	numpoints = w/STEP;
	points = new POINT[numpoints];

	USEBGCOLOR = GetRCBool("LiteBoltBackColor", TRUE);
	if (USEBGCOLOR) 
	{
		COLORREF bgcolor = GetRCColor("LiteBoltBackColor", 000000);
		bgbrush = CreateSolidBrush(bgcolor);
	}

	GetRCString("LiteBoltBackBmp", temp, "", 256);
	bgbmp = LoadLSImage(temp, temp);

	srand(time(NULL));
	pens = new HPEN[NUM_PENS];
	for (int cp=0; cp<NUM_PENS; cp++)
	{
		int r = 255-(cp*(255/NUM_PENS));
		int g = 255-(cp*(255/NUM_PENS));
		int b = 255;
		pens[cp] = CreatePen(PS_SOLID, cp+1, RGB(r, g, b));
	}
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	strcpy(lsdir, szPath);
	hwndParent = parent;
	hInstance = dllInst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  szAppName, szAppName, 
							  WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
							  x, y, 
							  w, h, 
							  NULL, NULL, dllInst, NULL);
		
	if (!hwndMain) return 1;

	if (bgbmp && !USEBGCOLOR) SetWindowBitmapRgn(hwndMain, bgbmp);

	if (GetRCBool("LiteBoltStartHidden", FALSE)) ShowWindow(hwndMain, SW_SHOW);
	if (GetRCBool("LiteBoltAlwaysOnTop", TRUE)) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	SetTimer(hwndMain, 0, TIMER, NULL);
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!LiteBoltShow");
	RemoveBangCommand("!LiteBoltHide");
	RemoveBangCommand("!LiteBoltToggle");
	
	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	
	KillTimer(hwndMain, 0);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	for (int cp=0; cp<NUM_PENS; cp++) DeleteObject(pens[cp]);

	DeleteObject(bgbrush);
	DeleteObject(bgbmp);
	DeleteObject(points);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);
			strcpy(buf, szVersion);
			return strlen(buf);
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
			HBITMAP oldbuf, oldsrc;
			RECT r;

			GetClientRect(hwnd, &r);

			if (!bgbmp && !USEBGCOLOR)
			{
				bgbmp = CreateCompatibleBitmap(hdc, w, h);
				oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!USEBGCOLOR)
			{
				oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
			}
			else
			{
				FillRect(buf, &r, (HBRUSH)bgbrush);
			}

			for (int count=0; count < NUM_BOLTS; count++)
			{
				points[0].y = h/2;

				for (int xpos=0; xpos<numpoints; xpos++)
				{
					points[xpos].x = xpos*STEP;

					if (rand()%2) 
						points[xpos].y = points[xpos-(xpos)?1:0].y + 
										 rand() %
										 //abs(((w/2)-(xpos*STEP))) %
										 LINESIZE;
					else 
						points[xpos].y = points[xpos-(xpos)?1:0].y - 
										 rand() %
										 //abs(((w/2)-(xpos*STEP))) %
										 LINESIZE;
				}

				SelectObject(buf, pens[0]);
				Polyline(buf, points, numpoints);

				/*for (int xpos=0; xpos<w; xpos+=STEP)
				{
					int oldy = ypos;

					if (abs(w/2)-xpos)
					{
						if (rand()%2) ypos += rand()%abs(((w/2)-xpos))%LINESIZE;
						else ypos -= rand()%abs(((w/2)-xpos))%LINESIZE;
					}
					else
					{
						if (rand()%2) ypos += rand()%LINESIZE;
						else ypos -= rand()%LINESIZE;
					}

					for (int cp=NUM_PENS-1; cp>=0; cp--)
					{
						SelectObject(buf, pens[cp]);
						MoveToEx(buf, xpos, oldy, NULL);
						LineTo(buf, xpos+STEP, ypos);
					}
				}
				*/
			}

			BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

			SelectObject(src, oldsrc);
			DeleteDC(src);
			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_LBUTTONUP:
		case WM_TIMER: InvalidateRect(hwndMain, NULL, TRUE); return 0;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* wp = (WINDOWPOS*)lParam;
			wp->flags ^= SWP_NOZORDER;
			wp->hwndInsertAfter = hwndDesktop;
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}