/*
  RabidModuleBangs LiteStep Module

  Copyright (C) 2001-02 Joshua Seagoe
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// Remember to fix the include paths and link with lsapi.lib

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <oleauto.h>  // oleaut32.lib
#include "\litestep\ls-b24\lsapi\lsapi.h"
#include "\litestep\ls-b24\core\ifcs.h"

#define TITLE "RabidModuleBangs v1.1"

HWND hLiteStepWnd;

extern "C" {
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
}

struct bangcmddef {
	const char *Name;
	BangCommand *Command;
};

void BangExecIfLoaded(HWND caller, LPCSTR args);
void BangExecIfNotLoaded(HWND caller, LPCSTR args);
void BangUpdate(HWND caller, LPCSTR args);

#define BANGPREFIX "!MODULE"
#define BANGPREFIXLEN 7 
bangcmddef Bangs[] = {
	{ "EXECIFLOADED",			&BangExecIfLoaded			},
	{ "EXECIFNOTLOADED",	&BangExecIfNotLoaded	},
	{ "UPDATE",						&BangUpdate						},
	{ NULL,								NULL									}
};

void RegisterBangs(void)
{
	bangcmddef *pBang;
	char BangString[64] = BANGPREFIX;

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+BANGPREFIXLEN,pBang->Name);
		AddBangCommand(BangString, pBang->Command);
		pBang++;
	}
}

void RemoveBangs(void)
{
	bangcmddef *pBang;
	char BangString[64] = BANGPREFIX;

	pBang = Bangs;
	while (pBang->Name != NULL) {
		lstrcpy(BangString+BANGPREFIXLEN,pBang->Name);
		RemoveBangCommand(BangString);
		pBang++;
	}
}
int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	hLiteStepWnd = GetLitestepWnd();
	if (hLiteStepWnd==NULL)
		MessageBox(NULL,"Couldn't get litestep window",TITLE,MB_OK);
	RegisterBangs();
	return 0;
}

int quitModule(HINSTANCE dllInst)
{
	RemoveBangs();
	return 0;
}



bool GetModuleManager(IModuleManager **pman)
{
	ILitestep *globalLitestep = NULL;
	// get the litestep object
	globalLitestep = (ILitestep *)
		SendMessage(hLiteStepWnd,LM_GETLSOBJECT,NULL,NULL);
	if (globalLitestep==NULL) {
		MessageBox(NULL,"Couldn't get litestep object",TITLE,MB_OK);
		return false;
	}
	// get the default module manager from it
	globalLitestep->GetModuleManager(pman);
	if (pman==NULL) {
		MessageBox(NULL,"Couldn't get module manager",TITLE,MB_OK);
		return false;
	}
	return true;
}

typedef bool FEM_Callback(LPSTR name,LPARAM lParam);

bool ForEachModule(FEM_Callback *cb,LPARAM lParam)
{
	bool res=true;
	IModuleManager *globalModuleManager;
	int icount;
	long dcount; 
	SAFEARRAYBOUND sab[1];
	SAFEARRAY *mods;
	BSTR *names;
	char name[MAX_PATH_LENGTH]={0};

	if (!GetModuleManager(&globalModuleManager)) return false;

	// create array to hold module names
	globalModuleManager->GetModuleCount(&icount);
	sab[0].lLbound = 0;
	sab[0].cElements = icount;
	mods = SafeArrayCreate(VT_BSTR,1,sab);

	if (mods==NULL) {
		MessageBox(NULL,"Couldn't create array for module list",TITLE,MB_OK);
		return false;
	}

	// get module names
	globalModuleManager->GetModuleList(mods,&icount);
	dcount = icount;
	if ((unsigned long)dcount==sab[0].cElements) {
		SafeArrayAccessData(mods, (void**)&names);
		while (dcount--) {
			WideCharToMultiByte(CP_ACP,0,names[dcount],-1,name,MAX_PATH_LENGTH,NULL,NULL);
			if (!cb(name,lParam)) break;
		}
		SafeArrayUnaccessData(mods);
	} else {
		MessageBox(NULL,"Count mismatch",TITLE,MB_OK);
		res = false;
	}

	// destroy the list of names
	SafeArrayDestroy(mods);

	return res;
}

struct EIL {
	char *pattern;
	char *buffer;
	bool loaded;
};

bool FindModule_FEM_Callback(LPSTR name,LPARAM lParam)
{
	EIL *p = (EIL *)lParam;

	if (match(p->pattern,name)) {
		if (p->buffer) lstrcpy(p->buffer,name);
		p->loaded = true;
		return false; // stop processing
	}
	return true;
}

// <-- actual bang commands start here --------------------------------------------------

void BangExecIfLoaded(HWND caller, LPCSTR args)
{
	char one[MAX_LINE_LENGTH],two[MAX_LINE_LENGTH];
	char *tokens[] = { one };
	EIL a;

	if (!args) return;

	LCTokenize(args, tokens, 1, two);

	a.pattern = one;
	a.loaded = false;
	ForEachModule(&FindModule_FEM_Callback,(LPARAM)&a);

	if (a.loaded) LSExecute(caller, two, SW_SHOWNORMAL);
}

void BangExecIfNotLoaded(HWND caller, LPCSTR args)
{
	char one[MAX_LINE_LENGTH],two[MAX_LINE_LENGTH];
	char *tokens[] = { one };
	EIL a;

	if (!args) return;

	LCTokenize(args, tokens, 1, two);

	a.pattern = one;
	a.loaded = false;
	ForEachModule(&FindModule_FEM_Callback,(LPARAM)&a);

	if (!a.loaded) LSExecute(caller, two, SW_SHOWNORMAL);
}

void BangUpdate(HWND caller, LPCSTR args)
{
	char pattern[MAX_LINE_LENGTH];
	const char *fs,*bs;
	EIL a;
	WIN32_FILE_ATTRIBUTE_DATA srcdat,destdat;

	// fail if source file does not exist
	if (GetFileAttributesEx(args,GetFileExInfoStandard,&srcdat)) {

		// find running module with the same filename, but any path
		bs = strrchr(args,'\\');
		fs = strrchr(args,'/');
		if (bs != NULL && bs<fs) fs = bs;
		if (fs == NULL) fs = args;
		pattern[0] = '*';
		lstrcpy(pattern+1,bs);

		a.pattern = pattern;
		a.buffer = pattern;
		a.loaded = false;
		ForEachModule(&FindModule_FEM_Callback, (LPARAM)&a);

		if (a.loaded && GetFileAttributesEx(pattern,GetFileExInfoStandard,&destdat)) {
			// pattern = full path to running module
			// only copy if it's newer
			if (CompareFileTime(&srcdat.ftLastWriteTime,&destdat.ftLastWriteTime)>0) {
				// unload module (probly shouldn't load this module threaded)
				SendMessage(hLiteStepWnd, LM_UNLOADMODULE, (WPARAM)pattern, 0);
				// copy, with overwrite
				CopyFile(args,pattern,FALSE);
				// reload module
				SendMessage(hLiteStepWnd, LM_RELOADMODULE, (WPARAM)pattern, 0);
			} else {
				MessageBox(NULL,"No update necessary.",TITLE,MB_OK);
			}
		} else {
			MessageBox(NULL,"Module not loaded.",TITLE,MB_OK);
		}
	} else {
		MessageBox(NULL,"Source file does not exist.",TITLE,MB_OK);
	}
}


