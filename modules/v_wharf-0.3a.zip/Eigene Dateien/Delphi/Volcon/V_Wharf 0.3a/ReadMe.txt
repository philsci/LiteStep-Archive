IMPORTANT!
-----------------------------------------
This and all following Versions are declared
alpha versions until I have found a way to make 
all volumechannels work for all the soundcards 
out there (Maybe not all but most). If either 
all or non of the sliders work on your system
MAIL me with your system/souncard brand/info 
whatever.
  
DESCRIPTION
-----------------------------------------
V_wharf let you control the volumes of your 
sound card from the Wharf bar instead from 
the Systray.


INs AND OUTs
-----------------------------------------
Current Version 0.3a (Bulid 070299)

Ins:
  *Volume Control of the AUX, WAVE, MIDI 
   and MAIN Channels.
  *Changeable Background
  *Popupmenu 
     -Edit Modules.ini
     -Save/NoSave volume settings on Exit
  *Customizable arrangement of AUX, WAVE, 
   MIDI and MAIN channel slider bars

Outs(Until future versions):
  *Transparent Background
  *Separate left/right channel control
  *Systray Icon capability


INSTALLATION
-----------------------------------------
Just copy the .dll and the .bmp in your 
Litestep and your Images Directory. 
Then add the following line to your 
Step.rc:
   
 *Wharf "Apps" .none @c:\Litestep\v_wharf.dll
   

OPTIONS
----------------------------------------
The only options so far you can change are 
the Background of the Wharf and the Layout
(means: arrangement of the sliderbars).
To change the Background  of the Module add 
The Value "Backbmp" to the [V_Wharf] section 
of your modules.ini.

Note: The Picture *must* be in your Images dir.

Example:
.
..
..
[V_wharf]
Backbmp=any.bmp
..
.

To Change the arrangement of the V_Wharf Sliderbars 
you must add a Value called "Layout" to your Modules.Ini
in the [V_Wharf] section. The Value must be a 3-char 
String of numbers between 1 and 4 with no doubles 
(123, 231, 432 ,...).

'1' : MainVolume 
'2' : WaveVolume
'3' : MidiVolume
'4' : Aux/CDVolume

So if you want the Wavebar be first and the Auxbar be 
the second with the Mainbar the last you must use:
( Layout=241 )
Should be pretty easy ;)

DISCLAIMER
----------------------------------------
I AM NOT IN ANYWAY RESPONSIBLE FOR THE CHAOS 
THIS MODULE COULD DO TO YOUR COMPUTER, THE 
WORLD OR MICROSOFT. DON'T USE THIS MODULE 
UNDER WATER.
[....]

SUPPORT
----------------------------------------
If you have a suggestion, found a little 
bug or just want send me a grammatical 
correct version of this text mail me at:

     blkhawk49@geocities.com


     
----------------------------------------
(C)1999 by No More Bytes (07.2.1999)