#include <windows.h>
#include <stdio.h>
#include "..\TitlePaint.h"

LRESULT CALLBACK WndProc(HWND hwnd, int msg, WPARAM wParam, LPARAM lParam);

__declspec( dllexport ) HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam);
__declspec( dllexport ) void Quit();

HWND list[1000];
WNDPROC listproc[1000];
BOOL FIRST=TRUE;

// Trap keyboard messages
HOOKPROC HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
	//if (code < 0) return (HOOKPROC)CallNextHookEx(0, code, wParam, lParam);

	switch (code)
	{
		/*
		case HCBT_CREATEWND:
		{
			int x;

			if (FIRST)
			{
				FIRST=FALSE;
				for (x=0; x<1000; x++) { list[x] = NULL; listproc[x] = NULL; }
			}

			for (x=0; (list[x] != NULL) && (x<1000); x++)
			{
				if (list[x] == (HWND)wParam) return 0;
			}

			if (x==1000) return 0;
			else 
			{
				DWORD style = GetWindowLong(list[x], GWL_STYLE);
				int y = style | WS_CAPTION;
				int z = style | WS_CHILD;
				if (y && !z)
				{
					list[x] = (HWND)wParam;
					listproc[x] = (WNDPROC)SetWindowLong(list[x], GWL_WNDPROC, (LONG)WndProc);
				}
			}
		}
		return 0;*/

		case HCBT_MINMAX:
		{
			if (LOWORD(lParam) == SW_MINIMIZE)
			{
				char temp[256] = "";
				GetWindowText((HWND)wParam, temp, 256);
				MessageBox(NULL, temp, "Minimizing", MB_SYSTEMMODAL);
			}
		}
		return 0;
	}

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, int msg, WPARAM wParam, LPARAM lParam)
{
	int x;
	for (x=0; (list[x] != NULL) && (x<1000); x++)
	{
		if (list[x] == hwnd) break;
	}
	if (list[x] == NULL || x==1000) return 0;

	switch (msg)
	{
		case WM_NCPAINT:
		{
			HDC hdc;
			hdc = GetWindowDC(hwnd);
			SelectObject(hdc, GetStockObject(BLACK_PEN));
			SetBkMode(hdc, TRANSPARENT);

			TextOut(hdc, 5, 5, "I like cheese", strlen("I like cheese"));

			ReleaseDC(hwnd, hdc);
		}
		return 0;
	}

	return CallWindowProc(listproc[x], hwnd, msg, wParam, lParam);
}

void Quit()
{
  int x;
 // for (x=0; list[x] && x<1000; x++)
  //{
	//  if (IsWindow(list[x])) SetWindowLong(list[x], GWL_WNDPROC, (LONG)listproc[x]);
  //}
}