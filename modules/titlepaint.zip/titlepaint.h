#include <windows.h>
#include "resource.h"

#define ST_SET 9040