//#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <commctrl.h>
#include <commdlg.h>
#include "TitlePaint.h"


HINSTANCE hinst = NULL; 
HWND hMainWnd = NULL; 
char* AppName = "TitalPaint";

BOOL CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

void Status(char*);

HWND victim;

///////////////////////////////
// MAIN!!!!!
///////////////////////////////

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{ 
    MSG msg;
	char temp[256] = "";
	HINSTANCE hHookDll;
	HOOKPROC (FAR* hHookProc)(int, WPARAM, LPARAM);
	void (FAR* hQuit)();
	HHOOK hSystemHook;

    UNREFERENCED_PARAMETER(lpszCmdLine);

	hinst = hInstance;  // save instance handle 

	hMainWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, WndProc);

	if (!hMainWnd) return FALSE;

	hHookDll = LoadLibrary("c:\\temp\\titlepaint\\map\\debug\\map.dll");
    hHookProc = (HOOKPROC (FAR*)(int, WPARAM, LPARAM))GetProcAddress(hHookDll, "HookFunction");
	hQuit = (void (FAR*)())GetProcAddress(hHookDll, "Quit");
    hSystemHook =  SetWindowsHookEx(WH_CBT,(HOOKPROC)hHookProc,hHookDll,0);

	while (GetMessage(&msg, (HWND) NULL, 0, 0))
    { 
        TranslateMessage(&msg); 
        DispatchMessage(&msg); 
    }

    UnhookWindowsHookEx(hSystemHook);
	hQuit();
    FreeLibrary(hHookDll);

	if (hMainWnd) DestroyWindow(hMainWnd);

	return msg.wParam; 
}

BOOL CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_CLOSE:
					DestroyWindow(hMainWnd);
					PostQuitMessage(0);
					return TRUE;
			}
		}
		break;
		case WM_COMMAND:
		{
			switch (HIWORD(wParam))
			{
				case BN_CLICKED:
				{
					switch (LOWORD(wParam))
					{
					}
				}
				break;
			}
		}
		break;
	}

	return FALSE;
}

void Status(char* temp)
{
	if (temp)
	{
		char buffer[10000] = "";
		int sb, st;
		GetDlgItemText(hMainWnd, IDC_EDIT, buffer, 10000);

		sb = strlen(buffer);
		st = strlen(temp);

		if ((sb + st) < 10000 && st) strcat(buffer, temp);
		else { memset(&buffer, '\0', sizeof(buffer)); strcpy(buffer, temp); }
		SetDlgItemText(hMainWnd, IDC_EDIT, buffer);
	}
}
