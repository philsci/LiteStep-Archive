#include <windows.h>
#include <stdio.h>

#include <dsound.h>
#include <initguid.h>
#include <spchwrap.h>

#include "lsapi.h"
#include "LiteSpeak.h"

/* ----------------------------------------------------------------- */
char szAppName[] = "LiteSpeak"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Function Prototypes
void BangConfig(HWND caller, char* args);
void BangCorrect(HWND caller, char* args);
void BangSpeak(HWND caller, char* args);
void BangPitchUp(HWND caller, char* args);
void BangPitchDown(HWND caller, char* args);
void BangSpeedUp(HWND caller, char* args);
void BangSpeedDown(HWND caller, char* args);

int LoadSettings();
void Say(const char *format, ...);
int InitializeSpeech();
void DestroySpeech(void);

HWND hMainWnd;                    // main window handle

// Voice Globals
char Greeting[256] = "My God, it's full of stars.";
char Testing[256] = "Testing";
//CVoiceText *SpeakObject;
PCTTSMode SpeakObject;

int SPEED=0, SPEED_STEP=0;
WORD PITCH, PITCH_STEP;

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name

	if (!RegisterClass(&wc)) 
	{
		MessageBox(NULL,"Error registering window class",szAppName, MB_OK);
		return 1;
	}

    hMainWnd = CreateWindowEx(0, szAppName, szAppName, WS_POPUP, 0, 0, 0, 0, 0, NULL, dllInst, 0);

    if (!hMainWnd) 
    {						   
        MessageBox(NULL,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    if (!InitializeSpeech()) { MessageBox(NULL, "Error Initializng Speech", szAppName, MB_OK); return 0; }

	LoadSettings();

	Say("%s", Greeting);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!Speak");
	RemoveBangCommand("!LiteSpeakConfig");
	RemoveBangCommand("!LiteSpeakCorrect");
	RemoveBangCommand("!LiteSpeakPitchUp");
	RemoveBangCommand("!LiteSpeakPitchDown");
	RemoveBangCommand("!LiteSpeakSpeedUp");
	RemoveBangCommand("!LiteSpeakSpeedDown");

	DestroySpeech();
    DestroyWindow(hMainWnd);
    UnregisterClass(szAppName, dllInst);
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    return DefWindowProc(hwnd,message,wParam,lParam);
}

int LoadSettings()
{
	AddBangCommand("!Speak", BangSpeak);
	AddBangCommand("!LiteSpeakConfig", BangConfig);
	AddBangCommand("!LiteSpeakCorrect", BangCorrect);
	AddBangCommand("!LiteSpeakPitchUp", BangPitchUp);
	AddBangCommand("!LiteSpeakPitchDown", BangPitchDown);
	AddBangCommand("!LiteSpeakSpeedUp", BangSpeedUp);
	AddBangCommand("!LiteSpeakSpeedDown", BangSpeedDown);

	GetRCString("LiteSpeakGreeting", Greeting, "My God, it's full of stars.", 256);
	GetRCString("LiteSpeakTesting", Testing, "Testing", 256);

	PITCH_STEP = (WORD)GetRCInt("LiteSpeakPitchStep", 1);
	SPEED_STEP = GetRCInt("LiteSpeakSpeedStep", 1);

	PITCH = (WORD)GetRCInt("LiteSpeakPitch", 32767);
	if (PITCH >= 0) SpeakObject->PitchSet(PITCH);

	SPEED = GetRCInt("LiteSpeakSpeed", 50);
	if (SPEED >= 0)
	{
		DWORD r = TTSATTR_MAXSPEED - TTSATTR_MINSPEED;
		DWORD p = (unsigned long)(TTSATTR_MINSPEED + (r/(100.00/SPEED)));
		SpeakObject->SpeedSet(p);
	}

	return 0;
}

void BangSpeak(HWND caller, char* args)
{
	Say("%s", args);	
}

void BangCorrect(HWND caller, char* args)
{
	if (SpeakObject) SpeakObject->LexiconDlg(hMainWnd, NULL);
}

void BangConfig(HWND caller, char* args)
{
	//if (SpeakObject) SpeakObject->GeneralDlg(hMainWnd, NULL);
}

void BangPitchUp(HWND caller, char* args)
{
	PITCH += PITCH_STEP;
	SpeakObject->PitchSet(PITCH);
	Say("%s", Testing);
}

void BangPitchDown(HWND caller, char* args)
{
	DWORD r = TTSATTR_MAXPITCH - TTSATTR_MINPITCH;
	DWORD p;
	DWORD cp;
	
	SpeakObject->PitchGet((unsigned short*)&cp);
	p = (unsigned long)(cp - (r/(100.00/PITCH_STEP)));

	SpeakObject->PitchSet((unsigned short)p);
	Say("%s", Testing);
}

void BangSpeedUp(HWND caller, char* args)
{
	DWORD r = TTSATTR_MAXSPEED - TTSATTR_MINSPEED;
	DWORD p;
	DWORD cp;
	
	SpeakObject->SpeedGet(&cp);
	p = (unsigned long)(cp + (r/(100.00/SPEED_STEP)));

	SpeakObject->PitchSet((unsigned short)p);
	Say("%s", Testing);
}

void BangSpeedDown(HWND caller, char* args)
{
	DWORD r = TTSATTR_MAXSPEED - TTSATTR_MINSPEED;
	DWORD p;
	DWORD cp;
	
	SpeakObject->SpeedGet(&cp);
	p = (unsigned long)(cp + (r/(100.00/SPEED_STEP)));

	SpeakObject->PitchSet((unsigned short)p);
	Say("%s", Testing);
}

int InitializeSpeech(void)
{
	CoInitialize(NULL);

	SpeakObject = new CTTSMode;
    if (!SpeakObject) return -1;

    HRESULT hRes;
    hRes = SpeakObject->Init();
    if (hRes) return -1;

	return 1;
}

void Say(const char *format, ...)
{
	va_list args;
	char buf[8192];
	WCHAR wbuf[8192] = L"";

	va_start(args, format);
	_vsnprintf(buf, sizeof(buf), format, args);
	va_end(args);
	MultiByteToWideChar(CP_ACP, 0, buf, -1, wbuf, lstrlen(buf));
	SpeakObject->Speak(wbuf, TRUE);
}

void DestroySpeech(void)
{
	SpeakObject->AudioReset();
	if (SpeakObject) delete SpeakObject;
	CoUninitialize();
}