//////////////////////////
// Module: xVWMx v1.0
// Written By: MrJukes
// Released: 9/13/00
//////////////////////////

LoadModule c:\litestep\xvwmx.dll

step.rc
==========
XVWMXUpdateInterval 1000	; How often it updates

; Format
; *WM X Y W H default.bmp #Flags
*WM 0 25 100 100 xvwmx1.bmp #AT
*WM 924 25 100 100 xvwmx2.bmp #AT
*WM 0 638 100 100 xvwmx3.bmp #AT
*WM 924 638 100 100 xvwmx4.bmp #AT

*Hotkey Win Right !XVWMXNext
*Hotkey Win Left  !XVWMXPrev
*Hotkey Win 1     !XVWMXGoto 1
*Hotkey Win 2     !XVWMXGoto 2
*Hotkey Win 3     !XVWMXGoto 3
*Hotkey Win 4     !XVWMXGoto 4

Flag Format
=============
#A = On All Desktops
#T = Always On Top
#AT = Always On Top On All Desktops

Have fun,
	MrJukes