LiteStep Module Pack: 2002.01.03
-------------------------------------
This module pack includes all old core LS modules that will need
to run a basic Litestep installation. Most themes assume that you
already have these modules in your Litestep's root directory. This
package includes the most up-to-date modules as of the date given
at the top of this file.

Modules Included:
command.dll
desktop2.dll
hotkey.dll
lstime2.dll
lsvwm.dll
popup2.dll
shortcut2.dll
systray2.dll
sysvwm.dll
taskbar.dll
vwm2.dll
wharf.dll


==========
lsdev@shellfront :: http://www.shellfront.org/lsdev/
source is available under the GPL license from the address above.

This package Copyright � 2002 Joel D. Parker