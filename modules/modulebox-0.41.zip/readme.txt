===================================================
===================================================
== modulebox.dll - a simple Module Un/Loader ======
===================================================
===================================================
====== Written by: ================================
================== Chris Rempel (jugg) ============
===================================================
================== http://jugg.logicpd.com/ =======
===================================================
===================================================
= Version: 0.41 = Release Date: 00.05.03 ==========
===================================================
===================================================

-=ToC=-
I. Introduction
 A} Overview
 B} Usage
II. Installation
III. Information
 A} Commands
 B} Changes
 C} Notes
IV. Disclaimer


=====================
== I. Introduction ==
=====================
===================================================
= A} Overview =
===============

Welcome, and thank you for deciding to try out this
simple LiteStep module Loader/ Unloader.  Its full
useful functionality consists of loading and
unloading LiteStep modules by dragging and dropping
them on the "box" which this Module creates.

===================================================
= B} Usage =
============

To Load a module with ModuleBox, drag the module
(filename.dll) onto ModuleBox. To Unload a module
with ModuleBox, drag the module (filename.dll) onto
ModuleBox while holding down the SHIFT key on your
keyboard.


======================
== II. Installation ==
======================
===================================================

Extract "modulebox.dll" to your LiteStep directory
(c:\litestep\). Open up your step.rc (LiteStep
configuration file) and find the section where all
of your "LoadModule" lines are located. Add a new
line that looks like this:

LoadModule c:\litestep\modulebox.dll

Of course, adjust the path as necessary. Save your
step.rc and issue the LiteStep Recycle command
(!Recycle).


======================
== III. Information ==
======================
===================================================
= A} Commands =
===============

ModBoxX 0
  - Sets the horizontal (x coordinate) value to
    place the ModuleBox at.
  - accepts any negative or positive integer.
  - defaults to: 0

ModBoxY 0
  - Sets the vertical (y coordinate) value to
    place the ModuleBox at.
  - accepts any negative or positive integer.
  - defaults to: 0

ModBoxHeight 32
  - Sets the vertical size (height) value.
  - accepts any positive integer greater then 1.
  - defaults to: 32

ModBoxWidth 32
  - Sets the horizontal size (width) value.
  - accepts any positive integer greater then 1.
  - defaults to: 32

ModBoxBorderSize 2
  - Sets the width (thickness) of the border that
    is drawn around the ModuleBox.
  - accepts any positive integer greater then 0 or
    use 0 to disable the border.
  - defaults to: 2

ModBoxBgImage ".none"
  - Sets the background Image of the ModuleBox.
    Use 0xFF00FF (RBG 255,0,255) for transparency
    in the image.
  - accepts any valid Bitmap file.
  - defaults to: ".none"

ModBoxBgColor FFFFFF
  - Sets the background color of the ModuleBox.
    Use FF00FF to paint the desktop background on
    the ModuleBox background (psuedo transparency).
  - accepts any valid Color supported by LiteStep.
  - defaults to: FFFFFF

ModBoxBorderColor 000000
  - Sets the border color of the ModuleBox. (see
    ModBoxBorderSize).
  - accepts any valid Color supported by LiteStep.
  - defaults to: 000000

ModBoxzOrder 1
  - Sets the window to be "always on top" or
    "always on bottom" or "floating".
  - accepts 0, 1, 2
    - 0 == "always on bottom"
        NOTE: "0" is only available if using a
              valid LiteStep Desktop Window.
    - 1 == "floating"
    - 2 == "always on top" 

ModBoxHidden
  - If set, ModuleBox will be hidden on start/
    recycle of LiteStep (the shell).
  - boolean value: true if set, otherwise false.


  =====!Bang Commands==============================
  =================================================
   !ModBoxHide
     - parameters: none
     - Issuing this command will hide all ModBox.

   !ModBoxMove
     - parameters: x,y
       'x' is any positive or negative integer
       representing the horizontal (x coordinate)
       value to position the tiles at.
       'y' is any positive or negative integer
       representing the vertical (y coordinate)
       value to position the tiles at.
     - Issuing this command will position ModuleBox
       at x,y values passed, or if no values were
       specified, it will position ModuleBox at
       the current mouse coordinates.

   !ModBoxShow
     - parameters: none
     - Issuing this command will show ModuleBox.

   !ModBoxToggle
     - parameters: none
     - Issuing this command toggles the visibility
       state of ModuleBox, by either hiding or
       showing it, opposite of its current visible
       state.

   !ModBoxzOrder
     - parameters: n
       'n' is either 0, 1, or 2. (See command
       "ModBoxzOrder" for explanation of values).
     - Issuing this command sets the zOrder of
       ModuleBox (ontop/floating/onbottom).


===================================================
= B} Changes =
==============

- 0.41 -
--------

  ! Fixed problem with !ModBoxzOrder


- 0.40 -
--------
  + Added this Readme File and Webpage
  + Added psuedo transparency if the BGColor is set
    to FF00FF (Great Pink (tm)).

  ! Fixed zOrder functionality.
  ! Fixed ModuleBox from crashing when itself
    (modulebox.dll) was dragged ontop itself to be
    unloaded. It now unloads correctly.

  ^ Cleaned up some code.


- 0.30 -
--------
  + Initial release. Loading and Unloading of
    LiteStep modules, with some basic configuration
    options.

===================================================
= C} NOTES =
============

  You must have a Valid Desktop Window to use the
  "always on bottom" zOrder functionality. If not
  you can only use "floating" and "always on top".


==================
= IV. Disclaimer =
==================
===================================================

Copyright (C) 1999, Chris Rempel

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT  WARRANTY
OF ANY KIND, EXPRESS OR  IMPLIED, INCLUDING BUT NOT
LIMITED  TO  THE   WARRANTIES  OF  MERCHANTABILITY,
FITNESS  FOR   A   PARTICULAR   PURPOSE   AND  NON-
INFRINGEMENT.  IN  NO  EVENT  SHALL THE  AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,  DAMAGES
OR  OTHER  LIABILITY,   WHETHER  IN  AN  ACTION  OF
CONTRACT,  TORT OR OTHERWISE,  ARISING FROM, OUT OF
OR IN CONNECTION  WITH  THE  SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
