#include <iostream.h>

extern "C"
{
#include "context_base.h"
OP_STATUS Parse_POS(const char *TOK, int M, int *RET);
}

int lsLib_parsePos(char *TOK, int M)
{
	int RES = 0;

	if(OP_FAILED(Parse_POS(TOK, M, &RES)))
	{
		cerr << "failed" << endl;
		return -1;
	}

	return RES;
}

int main()
{
	cout << "expected\tactual" << endl;

	cout << "-76\t\t" << lsLib_parsePos("-76",		800) << '\t' << endl;
	cout << "375\t\t" << lsLib_parsePos("/50",		800) << '\t' << endl;
	cout <<  "75\t\t" << lsLib_parsePos("/50,/4",	800) << '\t' << endl;
	cout << "275\t\t" << lsLib_parsePos("/50,3/4",	800) << '\t' << endl;
	cout <<  "85\t\t" << lsLib_parsePos("/50,/4+10",800) << '\t' << endl;
//	cout << "175\t\t" << lsLib_parsePos("/50,2/4",	800) << '\t' << endl;
	cout << "ERR\t\t" << lsLib_parsePos("-",		800) << '\t' << endl;

	return 0;
}

