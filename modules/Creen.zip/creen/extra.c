#include <stdlib.h>
/*#include <memory.h>*/

typedef AgxSize int;

guint32 box = 0;

void AgxBreak()
{
	static int WANT_BREAK = 1;

	if( WANT_BREAK)
	{
#if defined(DEBUG) || defined(_DEBUG)
#ifdef _MSC_VER
	_asm int 3;
#else 

#endif
#endif
	}
}

void AgxOutOfMemoryHandler()
{
	AgxBreak();
	exit(-1);
}

/* will NOT return NULL!!! */
void *AgxAlloc(AgxSize len)
/*$ ... Aug20 */
{
	void *ret = calloc(1, len);
	if(!ret) AgxOutOfMemoryHandler();
	box++;
	return ret;
}

void *AgxReAlloc(void *ptr, AgxSize len)
{
	return realloc(ptr, len);
}

void AgxFree(void *ptr)
{
	free(ptr);
	box--;
}

/*
// End of $Id$
*/
