#ifndef creen__context_base_h__
#define creen__context_base_h__

/*#include <stdio.h>*/
/*#include <AgxLib/AgxLib.h>*/ /*AgxNew, AgxBool, OP_STATUS*/

/*OP_FAIL*/
typedef enum { OP_PASS, OP_FAIL, OP_NIL, OP_EXECPT } OP_STATUS;
#define OP_FAILED(x) ((x) == OP_FAIL)
#define OP_PASSED(x) ((x) == OP_PASS)

/* -------------------------------------------------------------
// ///// enums /////////////////////////////////////////////////
// -----------------------------------------------------------*/

typedef enum {
	_Context_NoSource, 
	_Context_FileSource, 
	_Context_StringSource
} _Context_SourceType;

/* -------------------------------------------------------------
// ///// structs ///////////////////////////////////////////////
// -----------------------------------------------------------*/

typedef struct __Context _Context;

struct __Context
{
/*	FILE *fp;*/
	char *base;
	char *ptr;

	_Context_SourceType source;
/*
	char last_char;
	int  last_int;
	char *last_str;
*/
};

/* -------------------------------------------------------------
// ///// context functions /////////////////////////////////////
// -----------------------------------------------------------*/

_Context *_Context_Alloc();

void _Context_SetCStr(_Context *ctx, const char *TOK);

OP_STATUS _Context_PeekFirst(_Context *ctx, char *c);
OP_STATUS _Context_PeekNext(_Context *ctx, char *c);
OP_STATUS _Context_GetFirst(_Context *ctx, char *c);
OP_STATUS _Context_GetNext(_Context *ctx, char *c);

OP_STATUS _Context_File_PeekFirst(_Context *ctx, char *c);
OP_STATUS _Context_File_PeekNext(_Context *ctx, char *c);
OP_STATUS _Context_File_Inc(_Context *ctx);

OP_STATUS _Context_Str_PeekNext(_Context *ctx, char *c);
OP_STATUS _Context_Str_PeekFirst(_Context *ctx, char *c);
OP_STATUS _Context_Str_Inc(_Context *ctx);

OP_STATUS _Context_ParseChar(_Context *ctx, char *c);

OP_STATUS _Context_ExpectChar(_Context *ctx, char c);
OP_STATUS _Context_ExpectChar_Complain(_Context *ctx, char c);
OP_STATUS _Context_ExpectChar_ComplainStr(_Context *ctx, char c, char *s);

OP_STATUS _Context_ParseInt(_Context *ctx, int *i);
OP_STATUS _Context_ParseInt_Complain(_Context *ctx, int *i);
OP_STATUS _Context_ParseInt_ComplainStr(_Context *ctx, int *i, char *s);

#endif

/*
// End of $Id$
*/
