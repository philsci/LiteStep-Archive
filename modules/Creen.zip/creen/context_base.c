#include <stdio.h>
#include <ctype.h>
#include "context_base.h"

#define _Context_OutputLn(output) printf(output)

#define SNPRINTF_1(fp, len, fmt, x1)\
sprintf(fp, fmt, x1)
/*snprintf(fp, len, fmt, x1)*/
#define SNPRINTF_2(fp, len, fmt, x1, x2)\
sprintf(fp, fmt, x1, x2)
/*snprintf(fp, len, fmt, x1, x2)*/

/*
*/
char *C1 = "Expecting char `%c', got `%c'";
char *C2 = "Expecting int sequence";/*, got `%c";*/
char *C3 = "Expecting %s";

/* _Context_Alloc {% ... allocret}
// -------------------------------------------------------------
// guaranteed to return a valid _Context */
_Context *_Context_Alloc()
{
	_Context *ret = AgxNew(_Context);

	return ret;
}

void _Context_SetCStr(_Context *ctx, const char *TOK)
{
	ctx->base   = TOK;
	ctx->ptr    = TOK;
	ctx->source = _Context_StringSource;
}

OP_STATUS _Context_PeekNext(_Context *ctx, char *c)
{
	if(ctx->source == _Context_FileSource)
		return _Context_File_PeekNext(ctx,c);
	if(ctx->source == _Context_StringSource)
		return _Context_Str_PeekNext(ctx,c);
	return OP_FAIL;
}

OP_STATUS _Context_PeekFirst(_Context *ctx, char *c)
{
	if(ctx->source == _Context_FileSource)
		return _Context_File_PeekFirst(ctx,c);
	if(ctx->source == _Context_StringSource)
		return _Context_Str_PeekFirst(ctx,c);
	return OP_FAIL;
}

OP_STATUS _Context_Inc(_Context *ctx)
{
	if(ctx->source == _Context_FileSource)
		return _Context_File_Inc(ctx);
	if(ctx->source == _Context_StringSource)
		return _Context_Str_Inc(ctx);
	return OP_FAIL;
}

OP_STATUS _Context_GetFirst(_Context *ctx, char *c)
{
	if(OP_FAILED(_Context_PeekFirst(ctx, c)))
		return OP_FAIL;
	if(OP_FAILED(_Context_Inc(ctx)))
		return OP_FAIL;
	return OP_PASS;
}

OP_STATUS _Context_GetNext(_Context *ctx, char *c)
{
	if(OP_FAILED(_Context_PeekNext(ctx, c)))
		return OP_FAIL;
	if(OP_FAILED(_Context_Inc(ctx)))
		return OP_FAIL;
	return OP_PASS;
}

/*
*/
OP_STATUS _Context_ParseChar(_Context *ctx, char *c)
{
	if(OP_FAILED(_Context_GetFirst(ctx, c))) 
		return OP_FAIL;

	if(!isprint(*c))
		return OP_FAIL;
	else
		return OP_PASS;
}

/*
*/
OP_STATUS _Context_ExpectChar(_Context *ctx, char exp)
{
	char actual;
	if(OP_FAILED(_Context_GetFirst(ctx, &actual))) 
		return OP_FAIL;

	if(actual != exp)
		return OP_FAIL;
	else
		return OP_PASS;
}

OP_STATUS _Context_ExpectChar_Complain(_Context *ctx, char exp)
{
	char actual;
	if(OP_FAILED(_Context_GetFirst(ctx, &actual))) 
		return OP_FAIL;

	if(actual != exp)
	{
		char out[1024];
		SNPRINTF_2(out, 1024, C1, exp, actual);
		_Context_OutputLn(out);
		return OP_FAIL;
	}
	else
		return OP_PASS;
}

OP_STATUS _Context_ExpectChar_ComplainStr(_Context *ctx, char exp, char *s)
{
	char actual;
	if(OP_FAILED(_Context_GetNext(ctx, &actual))) 
		return OP_FAIL;

	if(actual != exp)
	{
		char out[1024];
		SNPRINTF_1(out, 1024, C3, s);
		_Context_OutputLn(out);
		return OP_FAIL;
	}
	else
		return OP_PASS;
}

OP_STATUS _Context_ParseInt(_Context *ctx, int *i)
{
	char chr;
	if(OP_PASSED(_Context_PeekFirst(ctx, &chr))) 
	{
		AgxBool    neg = false;
/*		Agxstring *num;*/
		char       buf[2] = {0,0};
		char       num[20] = {0};
		byte       len = 0;

		if(chr == '-') {neg = true;_Context_Inc(ctx);}
		else if(chr == '+') _Context_Inc(ctx);
		else if(!isdigit(chr)) return OP_FAIL;

/*		num = AgxStringAlloc();*/
		for(;;)
		{
			if(OP_PASSED(_Context_PeekFirst(ctx, &chr)) && isdigit(chr))
			{
/*				AgxStringAppendChar(num, chr);*/
				buf[0] = chr;
				strcat(num, buf);
				if(++len==20) break;
				_Context_Inc(ctx);
				continue;
			}
			break;
		}

		if(*num)
		{
			*i = atoi(num);
/*			*i = AgxStrToInt(AgxStringRaw(num));*/
			if(neg == true) *i = -(*i);
/*			AgxStringRelease(num);*/
			return OP_PASS;
		}
		
/*		AgxStringRelease(num);*/
		return OP_FAIL;
	}
}

OP_STATUS _Context_ParseInt_Complain(_Context *ctx, int *i)
{
	if(OP_FAILED(_Context_ParseInt(ctx, i)))
	{
		_Context_OutputLn(C2);
		return OP_FAIL;
	}

	return OP_PASS;
}

OP_STATUS _Context_ParseInt_ComplainStr(_Context *ctx, int *i, char *s)
{
	if(OP_FAILED(_Context_ParseInt(ctx, i)))
	{
		char out[1024];
		SNPRINTF_1(out, 1024, C3, s);
		_Context_OutputLn(out);
		return OP_FAIL;
	}

	return OP_PASS;
}

/*
// End of $Id$
*/
