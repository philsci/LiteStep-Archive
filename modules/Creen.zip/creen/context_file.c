#include "context_base.h"

OP_STATUS _Context_File_PeekFirst(_Context *ctx, char *c)
{
	return OP_FAIL;
}

OP_STATUS _Context_File_PeekNext(_Context *ctx, char *c)
{
	return OP_FAIL;
}

OP_STATUS _Context_File_Inc(_Context *ctx)
{
	return OP_FAIL;
}


