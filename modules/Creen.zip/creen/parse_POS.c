#include "context_base.h"

int Finish(int SCDIM, double RES, int OFFSET, int M);
OP_STATUS _Parse_POS(const char *TOK, int M, int *RET, _Context *ctx);

OP_STATUS Parse_POS(const char *TOK, int M, int *RET)
{
	_Context *ctx = _Context_Alloc();
	OP_STATUS RES =	_Parse_POS(TOK, M, RET, ctx);
/*	AgxStdRelease(ctx);*/
	AgxFree(ctx);
	return RES;
}

OP_STATUS _Parse_POS(const char *TOK, int M, int *RET, _Context *ctx)
{
	int i, SCDIM;
	char c;
	double RES = 1.;

	/*POS=number*/
	_Context_SetCStr(ctx, TOK);
	if(OP_PASSED(_Context_ParseInt(ctx, RET)))
		return OP_PASS;

	/*|('/'*/
	if(OP_FAILED(_Context_ExpectChar_Complain(ctx, '/')))
		return OP_FAIL;

	/*number~(scdim)*/
	if(OP_FAILED(_Context_ParseInt_Complain(ctx, &SCDIM))) 
		return OP_FAIL;

	/*[','*/
	if(OP_PASSED(_Context_ExpectChar(ctx, ',')))
	{
		int SUPER = 1, SUB = 1;
		
		/*[number~(super:1)]*/
		if(OP_PASSED(_Context_ParseInt(ctx, &SUPER)))
			/*DO NOTHING*/;

		/*'/'*/
		if(OP_FAILED(_Context_ExpectChar_Complain(ctx, '/')))
			return OP_FAIL;

		/*number~(sub:1)*/
		if(OP_FAILED(_Context_ParseInt_Complain(ctx, &SUB)))
			return OP_FAIL;

		RES = (double)SUPER/SUB;
	}
	else {*RET=Finish(SCDIM,RES,0,M);return OP_PASS;}

	i = 0;
	/*[('+'|'-') number~(offset:1)*/
	if(OP_PASSED( _Context_ParseChar(ctx, &c) ) && ( c == '+' || c == '-' ))
	{
		/*number~(offset)*/
		if(OP_FAILED(_Context_ParseInt_ComplainStr(ctx, &i, "offset")))
			return OP_FAIL;
		if(c=='-') i = -i;
	}

	*RET = Finish(SCDIM, RES, i, M);
	return OP_PASS;
}

int Finish(int SCDIM, double RES, int OFFSET, int M)
{
	return (int) ( (M/2)*RES )-( SCDIM/2 )+OFFSET;
}

/*
// End of $Id$
*/
