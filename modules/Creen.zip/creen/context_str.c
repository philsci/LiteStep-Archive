#include "context_base.h"

OP_STATUS _Context_Str_PeekFirst(_Context *ctx, char *c)
{
	if(*ctx->ptr)
	{
		*c = *ctx->ptr;
		return OP_PASS;
	}

	return OP_FAIL;
}

OP_STATUS _Context_Str_PeekNext(_Context *ctx, char *c)
{
	if(*ctx->ptr)
	{
		*c = ctx->ptr[1];
		return OP_PASS;
	}

	return OP_FAIL;
}

OP_STATUS _Context_Str_Inc(_Context *ctx)
{
	if(*ctx->ptr)
	{
		ctx->ptr++;
		return OP_PASS;
	}

	return OP_FAIL;
}

/*
// End of $Id$
*/
