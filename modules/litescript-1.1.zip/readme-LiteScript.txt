/////////////////////////////
// Module: LiteScript 1.1
// Written By: MrJukes
// Released: 9/18/00
/////////////////////////////

// New to 1.1
- Fixed hanging during recycle
- Added if statement
//

LoadModule c:\litestep\litescript.dll

step.rc
==========
; You can have as many of these as you would like
*LiteScript c:\litestep\litescript.scr

bangs
=======
!LiteScriptReport ; This bang will pop up a messagebox containing the class
		  ; and caption of the window the cursor is currently over
		  ; This bang is useful for making litescript scripts

*NOTE*
Anything in []'s is required.
Anything in ()'s is optional.
Do not actually put the []'s and ()'s in your script.

scripts
=========
The general format to create a bang is as follows:

  Create Bang !BangName
    Capture "Window Class" "Window Caption"  (You can obtain these using !LiteScriptReport)
      <Insert commands from below here>
    End Capture
  End Bang

  Create Bang !BangName2
  ...

commands
==========
These are the commands you can put in the capture section from above.

  ; Move the currently captured window
  ; A = Absolute = Moves the windows to X,Y on the screen
  ; R = Relative = Moves the window X,Y pixels from the current location
  Move [A|R] (-)X (-)Y

  ; Resize the currently captured window
  ; A = Absolute = Resizes the window so that it is WxH
  ; RR = Relative Right = The right border is fixed and the left border is resized
  ; RL = Relative Left = The left border is fixed and the right border is resized
  ; RT = Relative Top = The top border is fixed and the bottom border is resized
  ; RB = Relative Bottom = The bottom border is fixed and the top border is resized
  Size [A|RR|RL|RT|RB] (-)W (-)H

  ; Hide the currently captured window
  Hide

  ; Show the currently captured window
  Show

  ; Repeat the next command X times
  ; Example:
  ;  Repeat 11
  ;    Move R 5 0
  ; This would move the currently captured window relatively to the right 5 pixels 11 times
  Repeat X

  ; Set the delay between commands
  ; Once set, it stays set until the next call to SetDelay
  SetDelay X

  ; Execute a bang command or an executable
  Exec !Bang
  Exec notepad.exe

  ; A basic if statement
  ; You cannot nest if statements
  ; Only 2 things may directly follow "if".  They are "Visible" or "Hidden".
  if Visible
    Exec !Bang
    Show
  else
    Hide
  end if

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes