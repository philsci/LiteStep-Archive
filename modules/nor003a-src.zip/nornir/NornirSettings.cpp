//% $Id: NornirSettings.cpp,v 1.6 2001/04/23 13:14:54 Yoshi Exp $
#include "NornirSettings.h"
#include "lsapi.h"
#include <stdlib.h>
#include <time.h>
#include <locale.h>
#include <tchar.h>

#if defined _A2UNVLIB
#include <a2unvlib.h>
#endif



/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^�Őݒ��ǂݍ���
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
NornirSettings::NornirSettings(HWND owner)
{
  LPSTR lpszbuf = new char[1024];
  int i;
  TCHAR *tcPtr;

  //sssssssssssssssssssssssssssssssss�p�����[�^������
  m_hWnd = owner;
  m_hbmBack = NULL;
  m_hbmSkin = NULL;

  m_nFormatNum=0;
  //sssssssssssssssssssssssssssssssss��{�ݒ�
  GetRCString("NornirFormat", m_lpszTimeFormat, "%#c", 128);

  tcPtr = m_lpszTimeFormat;

  for(i=0; i <= 3; i++){
    m_pTimeFormat[i] = tcPtr;
    m_pTimeFormat[i+1] = NULL;

    tcPtr = _tcschr(tcPtr, ';');
    if(tcPtr != NULL)
      *tcPtr++ = NULL;
    else{
      break;
    }
  }

  GetRCString("NornirFont", m_TextLogFont.lfFaceName, "MS UI Gothic", LF_FACESIZE);

  m_TextLogFont.lfHeight = GetRCInt("NornirFontSize", 16);
  m_FontColor = GetRCColor("NornirFontColor", 0x00FFFFFF);
  m_BGColor = GetRCColor("NornirBGColor", 0x00000000);

  m_PosX = GetRCInt("NornirX", 0);
  m_PosY = GetRCInt("NornirY", 0);
  m_Width= GetRCInt("NornirWidth", 160);
  m_Height=GetRCInt("NornirHeight", 20);

  //bitmap
  GetRCString("NornirBitmap", lpszbuf, "", MAX_PATH);

  m_bTranspBack = (m_BGColor == 0xFF00FF) ? TRUE : FALSE;

  if(*lpszbuf){
    m_hbmSkin = LoadLSImage(lpszbuf, NULL);

    if(m_hbmSkin){
      GetLSBitmapSize(m_hbmSkin, &m_Width, &m_Height);
      m_bTranspBack = FALSE;
    }
  }

  //locale
  GetRCString("NornirLocale", lpszbuf, "C", 64);
  setlocale(LC_TIME, lpszbuf);

  //sssssssssssssssssssssssssssssssss�g���ݒ�
  m_TextLogFont.lfItalic = GetRCBool("NornirFontItalic", TRUE);

  if(TRUE == GetRCBool("NornirFontBold", TRUE))
    m_TextLogFont.lfWeight = 700;
  else
    m_TextLogFont.lfWeight = 400;

  m_bAlwaysOnTop = GetRCBool("NornirAlwaysOnTop", TRUE);

  m_bVisible = GetRCBool("NornirHidden", FALSE);

  //ssssssssssssssssssssssssssssssssTextLogFont
//m_TextLogFont.lfHeight;
  m_TextLogFont.lfWidth = 0;
  m_TextLogFont.lfEscapement = 0;
  m_TextLogFont.lfOrientation = 0;
//m_TextLogFont.lfWeight;
//m_TextLogFont.lfItalic;
  m_TextLogFont.lfUnderline = FALSE;
  m_TextLogFont.lfStrikeOut = FALSE;
  m_TextLogFont.lfCharSet = DEFAULT_CHARSET;
  m_TextLogFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
  m_TextLogFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
  m_TextLogFont.lfQuality = PROOF_QUALITY;
  m_TextLogFont.lfPitchAndFamily = DEFAULT_PITCH|FF_DONTCARE;
//m_TextLogFont.lfFaceName[LF_FACESIZE];

  //sssssssssssssssssssssssssssssssss�ꎞ�o�b�t�@�̔j��
  delete lpszbuf;
}


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
NornirSettings::~NornirSettings()
{
  if(m_hbmBack)
    DeleteObject(m_hbmBack);

  if(m_hbmSkin)
    DeleteObject(m_hbmSkin);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̏o��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void NornirSettings::PaintBG(HDC hdcDst)
{
  HDC hdc;
  HBITMAP hbmOld;

  //sssssssssssssssssssssssssssssssss�w�i�̍쐬�͂܂��H
  if( !m_hbmBack )
    CreateBG();

  //sssssssssssssssssssssssssssssssss�w�i���R�s�[
  hdc = CreateCompatibleDC(hdcDst);
  hbmOld = (HBITMAP)SelectObject(hdc, m_hbmBack);

  BitBlt(hdcDst, 0, 0, m_Width, m_Height, hdc, 0, 0, SRCCOPY);

  SelectObject(hdc, hbmOld);
  DeleteDC(hdc);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�w�i�̍쐬
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void NornirSettings::CreateBG()
{
  HDC	hdcScreen,hdcBack;
  HBITMAP hbmBackOld;

  //sssssssssssssssssssssssssssssssss�E�C���h�E�R���p�`��DC,BMP
  hdcScreen = GetDC(m_hWnd);
  hdcBack = CreateCompatibleDC(hdcScreen);
  m_hbmBack = CreateCompatibleBitmap(hdcScreen, m_Width, m_Height);

  hbmBackOld = (HBITMAP)SelectObject(hdcBack, m_hbmBack);

  ReleaseDC(m_hWnd, hdcScreen);

  if(m_hbmSkin){
    //�X�L��������ꍇ
    HDC hdcSkin;
    HBITMAP hbmSkinOld;

    hdcSkin = CreateCompatibleDC(hdcBack);
    hbmSkinOld = (HBITMAP)SelectObject(hdcSkin, m_hbmSkin);

    BitBlt(hdcBack , 0, 0, m_Width, m_Height, hdcSkin, 0, 0, SRCCOPY);

    SelectObject(hdcSkin, hbmSkinOld);
    DeleteDC(hdcSkin);
  }else{
    //�X�L���������ꍇ
    RECT rect;
    HBRUSH hbrush;

    hbrush = CreateSolidBrush(m_BGColor);

    rect.left = 0;
    rect.top = 0;
    rect.right = m_Width;
    rect.bottom = m_Height;

    FillRect(hdcBack, &rect, hbrush);
    DeleteObject(hbrush);
  }

  //sssssssssssssssssssssssssssssssss�㏈��
  SelectObject(hdcBack, hbmBackOld);
  DeleteDC(hdcBack);
}



/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���ԕ\���p�̕���������
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void NornirSettings::FormatTimeString(LPSTR FormatedBuffer, size_t buflen)
{
  struct tm *ttm;
  time_t st;
  LPSTR	tmplptr,lptr = m_pTimeFormat[m_nFormatNum];

  _tzset();
  time(&st);

  if(!strncmp(lptr, "%TZ(", 4)){
    lptr+=4;
    if(!strncmp(lptr, "UTC)", 4)){
      lptr+=4;
      ttm = gmtime(&st);
    }else{
#if defined __BORLANDC__
      // I wander why they work incorrectly that functions "atof" and "strtod" compiled with bcc.
      // Please tell me some hint if you have.
      long tzofs = strtol(lptr, &tmplptr, 10)*3600;

      if(!strncmp(tmplptr, ".5", 2)){
        tzofs = (abs(tzofs)/tzofs)*(abs(tzofs)+1800);
        tmplptr+=2;
      }

      st += tzofs;
#else
      st += (time_t)(strtod(lptr, &tmplptr)*3600.0);
#endif
      if(tmplptr)
        lptr = 1+tmplptr;

      ttm=localtime(&st);
    }
  }else
    ttm = localtime(&st);

  strftime(FormatedBuffer, buflen, lptr, ttm);
}



/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�������\��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void NornirSettings::PaintText(HDC hdcDst, LPSTR lpszTextString)
{
  HDC hdcTemp;
  HBITMAP hbmTemp,hbmOld;
  HFONT fontTemp,fontOld;
  RECT rect;

  rect.left = 0;
  rect.top = 0;
  rect.right = m_Width;
  rect.bottom = m_Height;

  //sssssssssssssssssssssssssssssssss�e��n���h���̍쐬
  hdcTemp = CreateCompatibleDC(hdcDst);

#if defined _A2UNVLIB
  fontTemp = CreateFontIndirectC(&m_TextLogFont);
#else
  fontTemp = CreateFontIndirect(&m_TextLogFont);
#endif
  fontOld = (HFONT)SelectObject(hdcTemp, fontTemp);

  hbmTemp = CreateCompatibleBitmap(hdcDst, m_Width, m_Height);
  hbmOld = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

  //ssssssssssssssssssssssssssssssssss�w�i�𓧉ߐF�œh��Ԃ�
  COLORREF TranspColor;

#if defined _DEBUG
  if(m_FontColor == m_BGColor){
    TranspColor = (m_FontColor >> 1) & 0x7F7F7F;
  }else
#endif
    TranspColor = m_BGColor;
  
  HBRUSH brush = CreateSolidBrush(TranspColor);
  FillRect(hdcTemp, &rect, brush);
  DeleteObject(brush);

  //ssssssssssssssssssssssssssssssssss��������r�b�g�}�b�v�ɕϊ�
  SetTextColor(hdcTemp, m_FontColor);
  SetBkColor(hdcTemp, TranspColor);
  DrawText(hdcTemp, lpszTextString, -1, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

  //sssssssssssssssssssssssssssssssss�`�悵����������d�ˍ��킹��
  TransparentBltLS(hdcDst, 0, 0, m_Width, m_Height, hdcTemp, 0, 0, TranspColor);

  //sssssssssssssssssssssssssssssssss�I�u�W�F�N�g�A�c�b��j��
  SelectObject(hdcTemp, fontOld);
  SelectObject(hdcTemp, hbmOld);

  DeleteObject(fontTemp);
  DeleteObject(hbmTemp);

  DeleteDC(hdcTemp);
}