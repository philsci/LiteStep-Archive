//% $Id: exports.cpp,v 1.4 2001/04/22 09:44:42 Yoshi Exp $
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include "lsapi.h"
#include "exports.h"
#include "Nornir.h"

cNornir* pNornir = NULL;

int initModuleEx( HWND lswnd, HINSTANCE lsinstance, LPCSTR lspath )
{
  pNornir = new cNornir(lswnd, lsinstance);

  if(pNornir)
    return 1;

  return 0;
}


int quitModule( HINSTANCE lsinstance )
{
  if(pNornir)
    delete pNornir;

  return 0;
}
