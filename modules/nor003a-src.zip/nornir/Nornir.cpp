//% $Id: Nornir.cpp,v 1.7 2001/04/23 13:14:54 Yoshi Exp $
#include "lsapi.h"
#include "Nornir.h"

#ifdef _A2UNVLIB
#include "a2unvlib.h"
#endif

#define BUILD_NAME		TEXT("Nornir.dll")
#define BUILD_VERSION	TEXT("v0.03a")
#define BUILD_DATE		TEXT("2001/--/--")
#define BUILD_AUTHOR	TEXT("Yoshi")

#define MAGICDWORD         0x49474541

#define TIMERID_REFRESH 1

UINT nMessages[] = { LM_GETREVID, 0};


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�R���X�g���N�^
		�E�B���h�E�̃Z�b�g�A�b�v
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
cNornir::cNornir( HWND parent, HINSTANCE lsinstance )
{
  //sssssssssssssssssssssssssssssssss�V�X�e�����̏�����
  m_hLitestep = GetLitestepWnd();
  m_hInstance = lsinstance;

  m_hDesktop = FindWindow(WC_LSDESKTOP, NULL);

  if(!m_hDesktop)
    m_hDesktop = GetDesktopWindow();

  m_hWnd = NULL;

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�N���X
  WNDCLASSEX wc;

  wc.cbSize = sizeof(WNDCLASSEX);
  wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
  wc.lpfnWndProc = (WNDPROC) cNornir::WndProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 4;
  wc.hInstance = m_hInstance;
  wc.hCursor = LoadCursor( NULL, IDC_ARROW );
  wc.hIcon = NULL;
  wc.hIconSm = NULL;
  wc.hbrBackground = NULL;
  wc.lpszMenuName = NULL;
  wc.lpszClassName = WC_NORNIR;

  if (!RegisterClassEx( &wc ) ) {

    MessageBox(0,TEXT("Failed to register window class."),WC_NORNIR,MB_OK);
    return;

  }

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�̍쐬
  m_hWnd = CreateWindowEx( WS_EX_TOOLWINDOW,
                         WC_NORNIR,
                         NULL,
                         WS_POPUP,
                         0, 0, 0, 0,
                         m_hDesktop,
                         NULL,
                         m_hInstance,
                         (LPVOID)this);

  if ( m_hWnd == NULL ) {

    MessageBox(0,TEXT("Failed to create window"),WC_NORNIR,MB_OK);
    return;

  }
  //ssssssssssssssssssssssssssssssssssLITESTEP �Ƀ��W���[���o�^
  SendMessage( m_hLitestep, LM_REGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );
  SetWindowLong( m_hWnd, GWL_USERDATA, (LONG)MAGICDWORD );

  //ssssssssssssssssssssssssssssssssss�ݒ�̓ǂݍ��݂Ɣ��f
  m_Settings = new NornirSettings(m_hWnd);

  if(!m_Settings){
    ::MessageBox(m_hWnd, TEXT("Failed to load settings."), WC_NORNIR, MB_OK);
    return;
  }
  
  SetWindowPos(m_hWnd,
               (m_Settings->m_bAlwaysOnTop) ? HWND_TOPMOST : HWND_TOP,
               0,
               0,
               m_Settings->m_Width,
               m_Settings->m_Height,
               SWP_NOMOVE|SWP_NOACTIVATE);

  SetWndPos();

  //ssssssssssssssssssssssssssssssssss�E�B���h�E�̕\��
  ShowWindow( m_hWnd,  !m_Settings->m_bVisible ? SW_HIDE : SW_SHOWNOACTIVATE );

  //ssssssssssssssssssssssssssssssssss�^�C�}�[
  m_idRefreshTimer = SetTimer(m_hWnd, TIMERID_REFRESH, 1000, NULL);

  //sssssssssssssssssssssssssssssssss�I�a�`�m�f�̓o�^
  AddBangCommand("!NornirToggle", bangToggleVisible);
  AddBangCommand("!NornirHide", bangHide);
  AddBangCommand("!NornirShow", bangShow);

  return;
}



/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�f�X�g���N�^
		�E�C���h�E�̔j��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
cNornir::~cNornir()
{
  //ssssssssssssssssssssssssssssssssss�I�a�`�m�f�̃A�����[�h
  RemoveBangCommand("NornirTobble");
  RemoveBangCommand("NornirHide");
  RemoveBangCommand("NornirShow");

  //ssssssssssssssssssssssssssssssssss�^�C�}�[�̍폜
  if(NULL == m_idRefreshTimer)
    KillTimer(m_hWnd, TIMERID_REFRESH);

  //ssssssssssssssssssssssssssssssssss���W���[���o�^�̔j��
  SendMessage( m_hLitestep, LM_UNREGISTERMESSAGE, (WPARAM) m_hWnd, (LPARAM) nMessages );

  //ssssssssssssssssssssssssssssssssss�E�C���h�E�i�N���X�j�̔j��
  DestroyWindow( m_hWnd );
  UnregisterClass( WC_NORNIR, m_hInstance );

  m_hWnd = NULL;

  //ssssssssssssssssssssssssssssssssss�e�N���X�̍폜
  if ( m_Settings )
    delete m_Settings;
  m_Settings = NULL;

  return;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̈ړ�
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void cNornir::SetWndPos()
{
  int x=m_Settings->m_PosX, y=m_Settings->m_PosY;

  if(x < 0)
    x = GetSystemMetrics(SM_CXSCREEN)+x;

  if(y < 0)
    y = GetSystemMetrics(SM_CYSCREEN)+y;

  SetWindowPos(m_hWnd, HWND_TOPMOST, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
}


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�v���V�[�W��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
LRESULT CALLBACK cNornir::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  LRESULT lResult = 0;
  cNornir* pNornir = (cNornir *)GetWindowLong(hwnd, 0);

  //sssssssssssssssssssssssssssssssss�E�C���h�E�쐬�O��
  if(message == WM_NCCREATE){
    LPCREATESTRUCT lpcs = (LPCREATESTRUCT)lParam;
    pNornir = (cNornir *)lpcs->lpCreateParams;

    SetWindowLong(hwnd, 0, (long)pNornir);
  }

  //sssssssssssssssssssssssssssssssss���C���̃|�C���^�����߂Ȃ��ꍇ
  if(!pNornir)
    return DefWindowProc(hwnd, message, wParam, lParam);

  //sssssssssssssssssssssssssssssssss���b�Z�[�W�̏���

  switch(message)
    {
    case LM_GETREVID:
      pNornir->lsyOnGetRevId((int) wParam, (char *)lParam, (LPINT)&lResult);
      break;

    case WM_PAINT:
      pNornir->lsyOnPaint((HDC)wParam);
      break;

    case WM_TIMER:
      InvalidateRect(pNornir->m_hWnd, NULL, TRUE);
      break;

    case WM_DISPLAYCHANGE:
      pNornir->SetWndPos();
      break;

    case WM_LBUTTONDOWN:
      if(pNornir->m_Settings->m_pTimeFormat[++pNornir->m_Settings->m_nFormatNum] == NULL)
        pNornir->m_Settings->m_nFormatNum=0;

      InvalidateRect(pNornir->m_hWnd, NULL, TRUE);
      break;

    case WM_RBUTTONDBLCLK:
      ShellExecute(pNornir->m_hWnd, NULL, "timedate.cpl", NULL, NULL, SW_SHOWNORMAL);
      break;

    case WM_USER:
      pNornir->onUser(wParam, lParam);

    default:
      lResult = DefWindowProc( hwnd, message, wParam, lParam );
      break;
    }

  return lResult;
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	���W���[���̃o�[�W������n��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void cNornir::lsyOnGetRevId(int mode, char* buffer, LPINT result)
{
  char *tmpbuf = new char[64];
  memset(tmpbuf, 0, 64);

  //ssssssssssssssssssss�}���ʎq�̐ݒ�
#if defined _A2UNVLIB
  strcpy(tmpbuf, "(u)");
#endif

  switch(mode)
    {
#if defined _DEBUG
    case 0:
      sprintf(buffer, "%s:debug%s %s %s", BUILD_NAME,tmpbuf, __DATE__, __TIME__);
      break;
#else
    case 0:
      sprintf(buffer, "%s:%s%s", BUILD_NAME, tmpbuf, BUILD_VERSION);
      break;
#endif
    case 1:
      sprintf(buffer, "Id: %s, %s%s %s %s", BUILD_NAME, BUILD_VERSION,tmpbuf, BUILD_DATE, BUILD_AUTHOR);
      break;
    default:
      strcpy(buffer, "");
      break;
    }

  delete tmpbuf;

  *result = strlen(buffer);
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̕\������\��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void cNornir::onUser(WPARAM wp, LPARAM lp)
{
  switch(wp)
    {
    case USERBM_SHOW: //!nornirshow
      ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
      break;
    case USERBM_HIDE: //!nornirhide
      ShowWindow(m_hWnd, SW_HIDE);
      break;
    case USERBM_TOGGLE: //!nornirtoggle
      if(IsWindowVisible(m_hWnd))
        ShowWindow(m_hWnd, SW_HIDE);
      else
        ShowWindow(m_hWnd, SW_SHOWNOACTIVATE);
    }
}




/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	�E�C���h�E�̕`��
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void cNornir::lsyOnPaint(HDC hdcScreen)
{
  HDC hdcTemp;
  HBITMAP hbmTemp,hbmOld;
  char buffer[256];

  //ssssssssssssssssssssssssssssssssss�`����J�n����
  PAINTSTRUCT ps;
  hdcScreen = BeginPaint(m_hWnd, &ps);

  //sssssssssssssssssssssssssssssssss�e�n���h���̍쐬
  hdcTemp = CreateCompatibleDC(hdcScreen);
  hbmTemp = CreateCompatibleBitmap(hdcScreen, m_Settings->m_Width, m_Settings->m_Height);

  //sssssssssssssssssssssssssssssssss�r�b�g�}�b�v�̓K�p�ƃo�b�N�A�b�v
  hbmOld = (HBITMAP)SelectObject(hdcTemp, hbmTemp);

  //sssssssssssssssssssssssssssssssss�w�i�̕`��
  m_Settings->PaintBG(hdcTemp);

  //sssssssssssssssssssssssssssssssss�e�L�X�g���d�ˍ��킹��
  m_Settings->FormatTimeString(buffer, 256);
  m_Settings->PaintText(hdcTemp, buffer);

  //sssssssssssssssssssssssssssssssss�w�i���߂���H

  //sssssssssssssssssssssssssssssssss�E�B���h�E�ɓ]��
  BitBlt(hdcScreen, 0, 0, m_Settings->m_Width, m_Settings->m_Height, hdcTemp, 0, 0, SRCCOPY);

  //sssssssssssssssssssssssssssssssss�e��n���h���̔j��
  EndPaint(m_hWnd, &ps);

  SelectObject(hdcTemp, hbmOld);

  DeleteObject(hbmTemp);
  DeleteDC(hdcTemp);
}


/*ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
	!bang �R�}���h
ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ*/
void cNornir::bangToggleVisible(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WC_NORNIR, NULL);

  if(hwnd)
    PostMessage(hwnd, WM_USER, USERBM_TOGGLE, 0);
}

void cNornir::bangHide(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WC_NORNIR, NULL);

  if(hwnd)
    PostMessage(hwnd, WM_USER, USERBM_HIDE, 0);
}

void cNornir::bangShow(HWND caller, char* args)
{
  HWND hwnd = FindWindow(WC_NORNIR, NULL);

  if(hwnd)
    PostMessage(hwnd, WM_USER, USERBM_SHOW, 0);
}