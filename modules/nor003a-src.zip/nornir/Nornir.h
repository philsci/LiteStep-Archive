//% $Id: Nornir.h,v 1.6 2001/04/23 13:14:54 Yoshi Exp $
#ifndef _H_CNORNIR
#define _H_CNORNIR

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "NornirSettings.h"

#define WC_NORNIR		"NornirClass"
#define WC_LSDESKTOP	"DesktopBackgroundClass"

#define USERBM_TOGGLE	0
#define USERBM_SHOW 	1
#define USERBM_HIDE 	2

class cNornir{

public:
  cNornir( HWND parent, HINSTANCE lsinstance );
  ~cNornir();

  static void cNornir::bangToggleVisible(HWND caller, char* args);
  static void cNornir::bangHide(HWND caller, char* args);
  static void cNornir::bangShow(HWND caller, char* args);

  void onUser(WPARAM,LPARAM);

private:
  void lsyOnGetRevId(int mode, char *buffer, LPINT result);
  void lsyOnPaint(HDC hdcScreen);

  void SetWndPos();

  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  NornirSettings* m_Settings;

  UINT	m_idRefreshTimer;

  HINSTANCE	m_hInstance;
  HWND	m_hLitestep;
  HWND	m_hDesktop;
  HWND	m_hWnd;
};

#endif _H_CNORNIR
