//% $Id: NornirSettings.h,v 1.4 2001/04/23 13:14:54 Yoshi Exp $
#ifndef _H_NORNIR_SETTINGS
#define _H_NORNIR_SETTINGS

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

class NornirSettings
{
public:
  NornirSettings(HWND owner);
  ~NornirSettings();
  //�V�X�e���p�����[�^

  HWND m_hWnd;

  BOOL m_bTranspBack;

  HBITMAP m_hbmBack;
  HBITMAP m_hbmSkin;

  //��{�ݒ�
  LOGFONT	m_TextLogFont;
  
  char	m_lpszTimeFormat[256];
  char* m_pTimeFormat[5];
  int	m_nFormatNum;
  COLORREF	m_FontColor;
  COLORREF	m_BGColor;

  //�g���ݒ�
  BOOL	m_bAlwaysOnTop;
  BOOL	m_bVisible;

  int m_PosX,m_PosY,m_Width,m_Height;

  //
  void CreateBG();
  void PaintBG(HDC hdc);
  void PaintText(HDC hdc, LPSTR lpszTextString);
  void FormatTimeString(LPSTR buffer, size_t buflen);
};

#endif _H_NORNIR_SETTINGS
