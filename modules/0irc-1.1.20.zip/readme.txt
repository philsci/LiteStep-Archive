0irc v1.0�
~~~~~~~~~~
version:    v1.1.20 exe & dll
release:    5
date:       2001/12/14
programmer: Torsten Stelling
state:      freeware :-)
email:      murphy@dev0.de
homepage:   http://www.dev0.de/

(c)opyright 2000-2001 by Torsten Stelling

this program is based on Aurore Irc/Open Irc source code.

what is 0irc
~~~~~~~~~~~~
0irc is a small irc-client for the global chat network.
what? you say, no not another irc-client! ok, delete 0irc and forget it!
otherwise read on and use it.

0irc is complete commandline based, except the dialog for the configuration
of the defaults. the configuration dialog is only availble in the exe-file.

why the name 0irc?
~~~~~~~~~~~~~~~~~~
i thought the name 0irc (say zero-irc) was good for a small irc-client.
this irc-client is as small as zero bytes. *grin*

use of 0irc (exe-file)
~~~~~~~~~~~~~~~~~~~~~~
start 0irc.exe. enter in the commandline '/CONFIG' and press enter/return.
configure it for your needs and press ok. enter in the commandline '/CONNECT'
and press enter/return. use it like any other irc-client.

use of 0irc (litestep module)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
open 0irc.rc in your favourite editor and copy the commands to the clipboard.
open your step.rc and insert them at the end. add the LoadModule 0irc.dll to
your LoadModule-block and edit the configuration of 0irc. Save step.rc and
recycle litestep.

what files are delievered?
~~~~~~~~~~~~~~~~~~~~~~~~~~
0irc.exe          - the main executable of 0irc
0irc.exe.manifest - the windows-xp manifest file for 0irc
0irc.dll          - the dll for litestep. load this with LoadModule <pathtodll>\0irc.dll
0irc.rc           - example steprc-commands for showing the skinning of 0irc
0ircFrame.png     - a frame for showing the skinning of 0irc. use with litestep
channel.bmp       - an example for 0irc.dll channel bitmap
channel.ico       - an example for 0irc.dll channel icon
channel2.ico      - an example for 0irc.dll channel icon
readme.txt        - you are reading this
whatsnew.txt      - the history of 0irc
commands.txt      - an overview of availble commands
gpl.txt           - gnu public license

authors
~~~~~~~
here is a complete list who helped to develop 0irc to current state.
the project was originally named openirc which was developed by damian
hodgkiss. then the project evolved to aurore-irc which is a modified
version of openirc. after this the development stopped for 9 months.
i picked up the last version of auroreirc and modified it to 0irc.

year:        1998
name:        Damian Hodgkiss
email:       mian@thirty4.com
description: Wrote OpenIRC

year:        1999
name:        Omar Kilani
email:       omar@aurore.net
description: Bug fixes
             some new features
             continued OpenIRC development
name:        Henry Zektser
email:       GregoryZ@erols.com
name:        Ryan Davis
email:       shroomie@erols.com

year:        2000-2001
name:        Torsten Stelling
email:       murphy@dev0.de
description: revamped inteface for minimalistic use
             bug fixes
             continued AuroraIRC development
             added new features

thank you all for helping me to make it a good product.
