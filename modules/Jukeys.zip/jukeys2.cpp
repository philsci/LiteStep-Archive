#include <windows.h>
#include "exports.h"
#include "lsapi.h"

const long magicDWord = 0x49474541;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();
BOOL GroupExists(const char* group);
void SwitchTo(const char* group);
void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp);

char* szAppName = "jukeys";
char* szVersion = "jukeys v1.0 (MrJukes)";

HINSTANCE hInstance;
HWND hwndMain, hwndParent;
int ScreenX, ScreenY;
int x, y, w, h;
char lsdir[256] = "";
int msgs[] = {LM_GETREVID, 0};

HMENU popup=NULL;
HFONT font;
COLORREF color;
HBRUSH bgbrush;
HBITMAP bgbmp;
BOOL USEBGCOLOR;
char CURRENT_GROUP[256] = "";
char DEFAULT_GROUP[256] = "Main";

class Group
{
public:
	Group() { menu=NULL; next=NULL; }

	char* name;
	HMENU menu;

	Group* next;
} *groups;

class JK
{
public:
	JK() { memset(&cmd, 0, sizeof(cmd)); next=NULL; }

	int ID;
	char* group;
	char* cmd;
	char* args;
	DWORD mods;
	char key;

	JK* next;
} *head;

void BangShow(HWND caller, const char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangHide(HWND caller, const char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangToggle(HWND caller, const char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangSwitchTo(HWND caller, const char* args)
{
	SwitchTo(args);
}

void SwitchTo(const char* group)
{
	JK* p;

	// Unregister everything first to make sure we have a clean start
	for (p=head; p; p=p->next)
	{
		if (!_strcmpi(p->group, CURRENT_GROUP)) UnregisterHotKey(hwndMain, p->ID);
	}

	// Now register the current group
	for (p=head; p; p=p->next)
	{
		if (!_strcmpi(p->group, group) || !_strcmpi(p->group, "All")) 
			RegisterHotKey(hwndMain, p->ID, p->mods, (int)p->key);
	}

	strcpy(CURRENT_GROUP, group);
	InvalidateRect(hwndMain, NULL, TRUE);
}

void LoadSetup()
{
	int size;
	char temp[256];

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	AddBangCommand("!jukeysShow", BangShow);
	AddBangCommand("!jukeysHide", BangHide);
	AddBangCommand("!jukeysToggle", BangToggle);
	AddBangCommand("!jkSwitchTo", BangSwitchTo);
	
	x = GetRCInt("jukeysX", 0);
	if (x < 0) x = ScreenX+x;
	y = GetRCInt("jukeysY", 0);
	if (y < 0) y = ScreenY+y;
	w = GetRCInt("jukeysW", 400);
	h = GetRCInt("jukeysH", 25);

	size = GetRCInt("jukeysFontSize", 12);
	GetRCString("jukeysFont", temp, "Arial", 256);
	font = CreateFont(size, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH, temp);
	color = GetRCColor("jukeysFontColor", 0x00FFFFFF);

	USEBGCOLOR = GetRCBool("jukeysBackColor", TRUE);
	if (USEBGCOLOR) 
	{
		COLORREF bgcolor = GetRCColor("jukeysBackColor", 000000);
		bgbrush = CreateSolidBrush(bgcolor);
	}

	GetRCString("jukeysBackBmp", temp, "", 256);
	bgbmp = LoadLSImage(temp, temp);

	GetRCString("jukeysDefaultGroup", DEFAULT_GROUP, "Main", 256);

	popup = CreatePopupMenu();

	// Register the hotkeys und shtuffen
	// *jukey Main Win I "!jkSwitchTo Internet"
	// *jukey Internet Win I iexplore.exe

	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], extra_text[4096];
	char*	tokens[5];

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	int id=0;
	while (LCReadNextConfig(step, "*jukey", temp, 256)) 
	{ 
		int count;

		token1[0] = token2[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 5, extra_text);

		if (count == 5)
		{
			JK* jk = new JK;
			char atomname[256] = "";
			
			sprintf(atomname, "jukey%d", id++);
			jk->ID = GlobalAddAtom(atomname);
			jk->group = _strdup(token2);
			jk->mods = 0;
			
			if (strlen(token4) == 1) jk->key = token4[0];
			else if (!_strcmpi(token4, "left")) jk->key = VK_LEFT;
			else if (!_strcmpi(token4, "right")) jk->key = VK_RIGHT;
			else if (!_strcmpi(token4, "down")) jk->key = VK_DOWN;
			else if (!_strcmpi(token4, "up")) jk->key = VK_UP;
			else if (!_strcmpi(token4, "F1")) jk->key = VK_F1;
			else if (!_strcmpi(token4, "F2")) jk->key = VK_F2;
			else if (!_strcmpi(token4, "F3")) jk->key = VK_F3;
			else if (!_strcmpi(token4, "F4")) jk->key = VK_F4;
			else if (!_strcmpi(token4, "F5")) jk->key = VK_F5;
			else if (!_strcmpi(token4, "F6")) jk->key = VK_F6;
			else if (!_strcmpi(token4, "F7")) jk->key = VK_F7;
			else if (!_strcmpi(token4, "F8")) jk->key = VK_F8;
			else if (!_strcmpi(token4, "F9")) jk->key = VK_F9;
			else if (!_strcmpi(token4, "F10")) jk->key = VK_F10;
			else if (!_strcmpi(token4, "F11")) jk->key = VK_F11;
			else if (!_strcmpi(token4, "F12")) jk->key = VK_F12;
			else { delete jk; continue; } // FIX THIS!

			jk->cmd = _strdup(token5);
			jk->args = _strdup(extra_text);

			char* p = strtok(token3, "+");
			while (p)
			{
				if (!_strcmpi(p, "Win")) jk->mods |= MOD_WIN;
				if (!_strcmpi(p, "Alt")) jk->mods |= MOD_ALT;
				if (!_strcmpi(p, "Ctrl")) jk->mods |= MOD_CONTROL;
				if (!_strcmpi(p, "Shift"))	jk->mods |= MOD_SHIFT;
				
			p = strtok(NULL, "+");
			}
		
			BOOL FOUND=FALSE;
			if (groups)
			{
				for (Group* g = groups; g; g=g->next)
				{
					if (!_strcmpi(jk->group, g->name))
					{
						FOUND=TRUE;
						sprintf(temp, "%s %s %s %s", token3, token4, token5, extra_text);
						AppendMenu(g->menu, MF_ENABLED | MF_STRING, jk->ID, temp);
					}
				}
			}

			if (!FOUND) 
			{
				Group* g = new Group;
				
				g->menu = CreatePopupMenu();
				g->name = _strdup(jk->group);

				if (groups) g->next = groups;
				groups = g;

				AppendMenu(popup, MF_ENABLED | MF_STRING | MF_POPUP, (int)g->menu, jk->group);
				sprintf(temp, "%s %s %s %s", token3, token4, token5, extra_text);
				AppendMenu(g->menu, MF_ENABLED | MF_STRING, jk->ID, temp);
			}

			if (head) jk->next = head;
			head = jk;
		}
	}
	LCClose(step);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	strcpy(lsdir, szPath);
	hwndParent = parent;
	hInstance = dllInst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, 
							  szAppName, szAppName, 
							  WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
							  x, y, 
							  w, h, 
							  NULL, NULL, dllInst, NULL);
		
	if (!hwndMain) return 1;
	
	if (bgbmp && !USEBGCOLOR) SetWindowBitmapRgn(hwndMain, bgbmp);

	if (GetRCBool("jukeysStartHidden", FALSE)) ShowWindow(hwndMain, SW_SHOW);
	if (GetRCBool("jukeysAlwaysOnTop", TRUE)) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	
	SwitchTo(DEFAULT_GROUP);

	return 0;
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!jukeysShow");
	RemoveBangCommand("!jukeysHide");
	RemoveBangCommand("!jukeysToggle");
	RemoveBangCommand("!jkSwitchTo");
	
	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	
	DestroyMenu(popup);

	while (groups)
	{
		Group* g = groups;
		groups=groups->next;
		DestroyMenu(g->menu);
		delete g;
	}

	// Free linked-list
	while (head)
	{
		JK* p = head;
		head=head->next;
		UnregisterHotKey(hwndMain, p->ID);
		GlobalDeleteAtom(p->ID);
		delete p;
	}

	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	DeleteObject(bgbrush);
	DeleteObject(bgbmp);
	DeleteObject(font);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_ERASEBKGND: return 0;

		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);
			strcpy(buf, szVersion);
			return strlen(buf);
		}
		break;

		case WM_RBUTTONDOWN:
		{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
		}
		return 0;

		case WM_COMMAND:
		case WM_HOTKEY:
		{
			for (JK* p=head; p; p=p->next)
			{
				if ((int)wParam == p->ID)
				{
					if (p->cmd[0] == '!')
					{
						ParseBangCommand(hwndMain, p->cmd, p->args);
					}
					else
					{
						ShellExecute(NULL, "open", p->cmd, p->args, lsdir, SW_SHOWNORMAL);
					}
					break;
				}
			}
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, w, h);
			HBITMAP oldbuf, oldsrc;
			RECT r;

			GetClientRect(hwnd, &r);

			if (!bgbmp && !USEBGCOLOR)
			{
				bgbmp = CreateCompatibleBitmap(hdc, w, h);
				oldbuf = (HBITMAP)SelectObject(buf, bgbmp);
				BitBlt(buf, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
				SelectObject(buf, oldbuf);
			}

			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			
			if (!USEBGCOLOR)
			{
				oldsrc = (HBITMAP)SelectObject(src, bgbmp);
				BitBlt(buf, 0, 0, w, h, src, 0, 0, SRCCOPY);
			}
			else
			{
				FillRect(buf, &r, (HBRUSH)bgbrush);
			}

			SelectObject(buf, font);
			SetBkMode(buf, TRANSPARENT);
			SetTextColor(buf, color);
			DrawText(buf, CURRENT_GROUP, strlen(CURRENT_GROUP), &r, DT_LEFT | DT_VCENTER);

			BitBlt(hdc, 0, 0, w, h, buf, 0, 0, SRCCOPY);

			SelectObject(src, oldsrc);
			DeleteDC(src);
			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
		}
		break;

		case WM_RBUTTONUP:
		{
			
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

BOOL GroupExists(const char* group)
{
	for (JK* p=head; p; p=p->next)
	{
		if (!_strcmpi(p->group, group)) return TRUE;
	}

	return FALSE;
}

void SetWindowBitmapRgn(HWND hwnd, HBITMAP bmp)
{
	if (hwnd && bmp)
	{
		int x=0, y=0;
		HDC hdc = CreateCompatibleDC(NULL);
		HRGN hTransRgn=NULL;
		HRGN hMainRgn=NULL;
		BITMAP bitmap;

		GetObject(bmp, sizeof(bitmap), &bitmap);
		SelectObject(hdc, bmp);
		hMainRgn = CreateRectRgn(0, 0, bitmap.bmWidth, bitmap.bmHeight);

		for (y=0; y < bitmap.bmHeight; x=0, y++)
		{
			for (x=0; x < bitmap.bmWidth; x++)
			{
				COLORREF c = GetPixel(hdc, x, y);
				if (c == 0x00FF00FF)
				{
					HRGN hTempRgn = CreateRectRgn(x, y, x+1, y+1);
					if (!hTransRgn) hTransRgn = CreateRectRgn(x, y, x+1, y+1);
					CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
					DeleteObject(hTempRgn);
				}
			}
		}
		
		CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);
		SetWindowRgn(hwnd, hMainRgn, FALSE);

		DeleteDC(hdc);
		DeleteObject(hTransRgn);
		DeleteObject(hMainRgn);
	}
	else
	{
		RECT r;
		HRGN rgn;
		GetClientRect(hwnd, &r);
		rgn = CreateRectRgn(r.left, r.top, r.right, r.bottom);
		SetWindowRgn(hwnd, rgn, FALSE);
	}
}