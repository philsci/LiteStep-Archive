#include <windows.h>
#include <stdlib.h>
#include "lsapi.h"
#include "exports.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();

char* szVersion = "LiteRunner 1.0 (MrJukes - mrjukes@purdue.edu)";

char* szAppName = "LiteRunner";
char lsdir[MAX_PATH] = "";
HINSTANCE hInstance;
HWND hwndMain, hwndParent;
int msgs[] = {LM_GETREVID, 0};
BOOL ACTIVE=TRUE;

class OnRun
{
public:
	OnRun() { next=NULL; RUNNING=FALSE; }

	HWND hwnd;
	char *classname;
	char *caption;
	char *cmd1, *cmd2;
	BOOL RUNNING;

	OnRun* next;
} *list;

void BangOn(HWND caller, const char* args)
{
	ACTIVE=TRUE;
	SetTimer(hwndMain, 0, 500, NULL);
}

void BangOff(HWND caller, const char* args)
{
	ACTIVE=FALSE;
	KillTimer(hwndMain, 0);
}

void BangToggle(HWND caller, const char* args)
{
	if (ACTIVE) BangOff(caller, args);
	else BangOn(caller, args);
}

void BangIdentify(HWND caller, const char* args)
{
	HWND hwnd;
	POINT p;
	char classname[256] = "";
	char caption[256] = "";
	char temp[550] = "";

	GetCursorPos(&p);
	hwnd = WindowFromPoint(p);
	if (hwnd)
	{
		GetClassName(hwnd, classname, 256);
		GetWindowText(hwnd, caption, 256);

		sprintf(temp, "Class = %s\nCaption = %s", classname, caption);
		MessageBox(NULL, temp, szAppName, MB_SYSTEMMODAL | MB_ICONINFORMATION);
	}
}

void LoadSetup()
{
	FILE* step;
	char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], extra_text[4096];
	char*	tokens[5];
	char temp[256] = "";

	AddBangCommand("!LiteRunnerOn", BangOn);
	AddBangCommand("!LiteRunnerOff", BangOff);
	AddBangCommand("!LiteRunnerToggle", BangToggle);
	AddBangCommand("!LiteRunnerIdentify", BangIdentify);

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	
	while (LCReadNextConfig(step, "*OnRun", temp, 256)) 
	{ 
		// *OnRun "Class" "Caption" !Bang !Bang
		int count;
		OnRun* n = new OnRun;

		token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 5, extra_text);

		if (!_strnicmp(token2, ".none", 5) || !token2) continue;
		n->classname = _strdup(token2);

		if (!_strnicmp(token3, ".none", 5) || !token3) n->caption=NULL;
		else n->caption = _strdup(token3);
		
		if (!_strnicmp(token4, ".none", 5) || !token4) n->cmd1=NULL;
		else n->cmd1 = _strdup(token4);
		
		if (!_strnicmp(token5, ".none", 5) || !token5) n->cmd2=NULL;
		else n->cmd2 = _strdup(token5);

		if (list) n->next = list;
		list = n;
	}

	LCClose(step);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;

	hwndParent = parent;
	hInstance = dllInst;
	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error: Could not register window class", szAppName, MB_OK | MB_ICONERROR);
		return 1;
	}
 
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, WS_POPUP, 0, 0, 0, 0, NULL, NULL, dllInst, NULL);
	if (!hwndMain) return 1;
	
	SendMessage(hwndParent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	BangOn(NULL, NULL);
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!LiteRunnerOn");
	RemoveBangCommand("!LiteRunnerOff");
	RemoveBangCommand("!LiteRunnerToggle");
	RemoveBangCommand("!LiteRunnerIdentify");

	SendMessage(hwndParent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);
	KillTimer(hwndMain, 0);

	while (list)
	{
		OnRun* p = list;
		list=list->next;
		delete p;
	}
	
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);

			switch (wParam)
			{
				case 0: sprintf(buf, "%s", szVersion); break;
				case 1:	sprintf(buf, "%s", szVersion); break;
				default: sprintf(buf, "%s", szVersion); break;
			}
			return strlen(buf);
		}
		break;

		case WM_TIMER:
		{
			for (OnRun* p=list; p; p=p->next)
			{
				if (p->RUNNING) // Application is currently active
				{
					if (!IsWindow(p->hwnd))
					{
						p->RUNNING=FALSE;
						LSExecute(NULL, p->cmd2, SW_SHOWNORMAL);
						p->hwnd = NULL;
					}
				}
				else // Application is not running
				{
					if (!p->caption) p->hwnd = FindWindow(p->classname, NULL);
					else p->hwnd = FindWindow(p->classname, p->caption);

					if (p->hwnd)
					{
						// Application has been started since last check
						p->RUNNING=TRUE;
						LSExecute(NULL, p->cmd1, SW_SHOWNORMAL);
					}
				}
			}
		}
		return 0;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}
