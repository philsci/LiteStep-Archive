/* $Id: CreateFontIndirectC.cpp,v 1.2 2001/05/18 11:21:24 Yoshi Exp $

  CreateFontIndirectC(LOGFONT).
    (in a2unvlib package)

  Copyright (C) 2001,HOSHINO Yoshifumi (Yoshi)

  This program is free software. You can hack/redistribute under the terms of
  GNU GPL version 2 or later one.

*/

#include <windows.h>
#include "a2unvlib.h"

HFONT CreateFontIndirectC(LOGFONT *lplf)
{
  //BYTE nCharSet = (BYTE)GetTextCharset(hTargetDC);
  CHARSETINFO csi;
  TranslateCharsetInfo((LPDWORD)GetACP(), &csi, TCI_SRCCODEPAGE);

  lplf->lfCharSet = csi.ciCharset;

  return CreateFontIndirect(lplf);
}
