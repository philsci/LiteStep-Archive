/* $Id: CreateFontC.cpp,v 1.3 2001/05/18 11:21:24 Yoshi Exp $

  CreateFontC(...)
    (in a2unvlib package)

  Copyright (C) 2001,HOSHINO Yoshifumi (Yoshi)

  This program is free software. You can hack/redistribute under the terms of
  GNU GPL version 2 or later one.

*/

#include <windows.h>
#include "a2unvlib.h"

HFONT CreateFontC(
  int nHeight, // logical height of font
  int nWidth, // logical average character width
  int nEscapement, // angle of escapement
  int nOrientation, // base-line orientation angle
  int fnWeight, // font weight
  DWORD fdwItalic, // italic attribute flag
  DWORD fdwUnderline, // underline attribute flag
  DWORD fdwStrikeOut, // strikeout attribute flag
  DWORD fdwCharSet, // character set identifier
  DWORD fdwOutputPrecision, // output precision
  DWORD fdwClipPrecision, // clipping precision
  DWORD fdwQuality, // output quality
  DWORD fdwPitchAndFamily, // pitch and family
  LPCTSTR lpszFace // pointer to typeface name string
)
{
  //BYTE nCharSet = (BYTE)GetTextCharset(hTargetDC);
  CHARSETINFO csi;
  TranslateCharsetInfo((LPDWORD)GetACP(), &csi, TCI_SRCCODEPAGE);

  fdwCharSet = csi.ciCharset;

  return CreateFont(nHeight,nWidth,nEscapement,nOrientation,fnWeight,fdwItalic,fdwUnderline,fdwStrikeOut,
                    fdwCharSet,fdwOutputPrecision,fdwClipPrecision,fdwQuality,fdwPitchAndFamily,lpszFace);
}
