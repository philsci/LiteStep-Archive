/* $Id: a2unvlib.h,v 1.5 2001/05/18 11:21:23 Yoshi Exp $

  a2unvlib Header.
    (in a2unvlib package)

  Copyright (C) 2001,HOSHINO Yoshifumi (Yoshi)

  This program is free software. You can hack/redistribute under the terms of
  GNU GPL version 2 or later one.

*/

int CALLBACK EnumFontFamExProc(
			ENUMLOGFONTEX *lpelfe,
 			NEWTEXTMETRICEX *lpntme,
 			int FontType,
 			LPARAM lParam);

DWORD GetCorrectCharset(HDC hTargetDC, LPCTSTR lpszFace);

HFONT CreateFontC(
  int nHeight, // logical height of font
  int nWidth, // logical average character width
  int nEscapement, // angle of escapement
  int nOrientation, // base-line orientation angle
  int fnWeight, // font weight
  DWORD fdwItalic, // italic attribute flag
  DWORD fdwUnderline, // underline attribute flag
  DWORD fdwStrikeOut, // strikeout attribute flag
  DWORD fdwCharSet, // character set identifier
  DWORD fdwOutputPrecision, // output precision
  DWORD fdwClipPrecision, // clipping precision
  DWORD fdwQuality, // output quality
  DWORD fdwPitchAndFamily, // pitch and family
  LPCTSTR lpszFace // pointer to typeface name string
);

HFONT CreateFontIndirectC(LOGFONT *lplf);

