//$Id: winampFunc.cpp,v 1.8 2001/06/12 10:48:54 Yoshi Exp $
/*============================================================================

  Winamp control class
		copyright (C) 2000,2001 Yoshifumi Hoshino,(Yoshi)   all right reserved.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


% $Log: winampFunc.cpp,v $
% Revision 1.8  2001/06/12 10:48:54  Yoshi
% (none)
%
% Revision 1.7  2001/05/18 09:36:15  Yoshi
% fixed some bags in init.
%
% Revision 1.6  2001/05/15 11:12:50  Yoshi
% added GetPlaybackTime.
% added GetPlaybackStatus.
% changed renamed some functions.
%
% Revision 1.5  2001/04/29 09:18:07  Yoshi
% merge "testver".
%
% Revision 1.4.2.2  2001/04/23 12:54:34  Yoshi
% changed own coding rules.
%
% Revision 1.4.2.1  2001/04/27 11:19:01  Yoshi
% changed a little 
%

2001-04-12
  added DisplayMainMenu()

2001-03-31
  added ampcmd.h for adding winamp commands easily.

2001-03-19
  added compile option. If you need no winamp3 functions, you can delete or commentout
  _WINAMP3_ALPHA is defined.

2001-03-11
  changed FindWinamp(), It searches winamp3 window first.

2001-02-22
  add #define _WINAMP3_ALPHA only.

2001-02-16(2)
  added definition _WINAMP3_ALPHA for selectable to use wa3 or not.
  deleted member lpszWinampPath. Function gets it whenever ExecuteWinamp() is called.

2001-02-16
  changed functions for Winamp3 algha4.(It's changed that window class name of wa3 alpha)
  changed str(r)chr to _tcs(r)chr for multibyte/doublebyte env.

2001-02-06
  added functions for Winamp3 alpha. We can use this to get window handle and
  window title about it. These will be enabled you set member bSenceWinamp3=TRUE.
  (It will be default in the future)

2000-10-06�iuncompatible with previous version�j
  changed class constructer to be able to change default string.

2000/09/21
  gathered functions for winamp.

============================================================================*/

#include <tchar.h>
#include <windows.h>
#include "winampFunc.h"

/*=========================================================
  class init & destroy
=========================================================*/
CWinampFunction::CWinampFunction(LPSTR DefaultStr)
{
  m_lpszWinampTitle = new char[WINAMP_TITLESIZE];
  m_lpszDefaultTitle = new char[WINAMP_TITLESIZE];

  //
  ZeroMemory(m_lpszWinampTitle, WINAMP_TITLESIZE);
  ZeroMemory(m_lpszDefaultTitle, WINAMP_TITLESIZE);

  //default string for missing winamp.
  if(DefaultStr)
    strcpy(m_lpszDefaultTitle, DefaultStr);

#ifdef _WINAMP3_ALPHA
  m_bSenceWA3 = FALSE;
#endif
}


CWinampFunction::~CWinampFunction()
{
  delete m_lpszDefaultTitle;
  delete m_lpszWinampTitle;
}


/*=========================================================
  GetTitle(LPSTR, BOOL)
    This function gets winamp title as song info.

  function
	LPSTR pointer to a buffer that will receive the title. 
	BOOL  get title with refreshing cache.�irefresh to TRUE)
			#define GWT_REFRESH  TRUE
			#define GWT_COPYONLY FALSE
	To refresh only, you can set NULL for LPSTR.

  return BOOL
    If Title have been changed(compare it with cached one),
    returns TRUE. You've set GWT_COPYONLY, return must be
    FALSE, you know.

=========================================================*/
BOOL CWinampFunction::GetTitle(LPSTR TitleBuffer, BOOL refresh)
{
  //use cache
  if(!refresh && TitleBuffer){
    strcpy(TitleBuffer, m_lpszWinampTitle);
    return FALSE;
  }

  LPSTR buffer = new char[WINAMP_TITLESIZE];
  BOOL result;
  HWND hWinamp;

  if(NULL == ( hWinamp = FindWindow()))
    strcpy(buffer, m_lpszDefaultTitle);
  else
    GetWindowText(hWinamp , buffer, WINAMP_TITLESIZE);

  if(!strcmp(buffer, m_lpszWinampTitle))
    result = FALSE;
  else
    result = TRUE;

  strcpy(m_lpszWinampTitle, buffer);
  if(TitleBuffer)
    strcpy(TitleBuffer, buffer);

  delete buffer;
  return result;
}




/*=========================================================
  GetPlaybackStatus()
    This function gets playback status playing, pausing and so on.

  return unsigned int
    GPS_PLAYING    (1)  Winamp is playing.
    GPS_PAUSED     (3)  Winamp is paused.
    GPS_STOPPED    (0)  Winamp is stopped.
    GPS_MISSING    (9)  Winamp is not running.
=========================================================*/
UINT CWinampFunction::GetPlaybackStatus()
{
  ULONG result;
  HWND hwnd = FindWindow();

  if(!hwnd)
    return GPS_MISSING;

  result = SendMessage(hwnd, WM_USER, 0, 104);

  switch(result){
  case GPS_PLAYING:
  case GPS_PAUSED:
    return result;
  default:
    return GPS_STOPPED;
  }
}




/*=========================================================
  GetPlaybackTime(DWORD)
    This function gets some kinds of winamp time.

  function
    DWORD some modes.

  return long
    mode GPT_ELAPSED (0)
      returns elapsed time in seconds.
    mode GPT_REMAIN (1)
      returns remains time in seconds.
    mode GPT_TOTAL (10)
      returns current track length in seconds.
    mode GPT_ELAPSED_MILLISEC (20)
      returns elapsed time in milliseconds.

    if returns -1, It's error.
=========================================================*/
long CWinampFunction::GetPlaybackTime(DWORD mode)
{
  long ms_now, s_total,result;
  HWND hwinamp=FindWindow();

  if(!hwinamp)
    return -1;

  ms_now = SendMessage(hwinamp, WM_USER, 0, IPC_GETOUTPUTTIME);
  s_total = SendMessage(hwinamp, WM_USER, 1, IPC_GETOUTPUTTIME);

  if(ms_now==-1 || s_total== -1)
    return -1;

  switch(mode){
  case GPT_ELAPSED:
    result = ms_now/1000;
    break;
  case GPT_REMAIN:
    result = s_total - ms_now/1000;
    break;
  case GPT_TOTAL:
    result = s_total;
    break;
  case GPT_ELAPSED_MILLISEC:
    result = ms_now;
    break;
  default:
    result = -1;
  }

  return result;
}




/*=========================================================
  SetFormat(char*, BOOL, BOOL)
    This function formats winamp title you got.

  function
	char* Pointer to a buffer that set the title and will
            receive the formated title.
	BOOL  If It's TRUE, prefix will be deleted.
	BOOL  If It's TRUE, suffix will be deleted.

  return void

=========================================================*/
void CWinampFunction::SetFormat(char *TitleBuffer, BOOL Prefix, BOOL Suffix)
{
  if(!strnicmp(TitleBuffer, "winamp", 6) || !strcmp(TitleBuffer , m_lpszDefaultTitle))
    return;

  TCHAR *tmpPtr;

#ifdef _WINAMP3_ALPHA
  if(m_bSenceWA3){
    tmpPtr = _tcsrchr((_TCHAR *)TitleBuffer, '(');
    if(Suffix && tmpPtr)
      *(tmpPtr -1) = NULL;

    return;
  }
#endif
  tmpPtr = _tcschr((_TCHAR *)TitleBuffer, '.');
  if(Prefix && tmpPtr)
    memmove(TitleBuffer, tmpPtr+2, strlen(tmpPtr));

  tmpPtr = _tcsrchr((_TCHAR *)TitleBuffer, '-');
  if(Suffix && tmpPtr){
    if(!strncmp(tmpPtr, DEFAULT_WINAMP_SUFFIX, sizeof(DEFAULT_WINAMP_SUFFIX)-1 ))
      *(tmpPtr -1) = NULL;
  }
}



/*=========================================================
  PostCommand(DWORD)
    This function posts message as command to winamp.

  function
	DWORD command for winamp�isee NSDN http://www.winamp.com/nsdn�j

  return 
	BOOL If success, returns TRUE.

===========================================================*/
BOOL CWinampFunction::PostCommand(DWORD command)
{
  HWND hWinamp=FindWindow();

  if(!hWinamp)
    return FALSE;

#ifdef _WINAMP3_ALPHA
  /*no idea about messages of winamp3.*/
  if(m_bSenceWA3 == TRUE)
    return FALSE;
#endif

  return PostMessage(hWinamp, WM_COMMAND, (WPARAM)command, NULL);
}


/*=========================================================
  GetWinampPath(LPSTR) **private**
    This function gets path to winamp.exe from registory.

  function
	LPSTR Pointer to a buffer that you'll receive the path.

  return 
	BOOL If success, returns TRUE.

=========================================================*/
BOOL CWinampFunction::GetWinampPath(LPSTR AmpPath)
{
  HKEY hkey;
  DWORD dwType = REG_SZ,bufsize=MAX_PATH+1;
  char buffer[MAX_PATH+1];

  if(ERROR_SUCCESS != RegOpenKeyEx(HKEY_CLASSES_ROOT, "Winamp.File\\shell\\open\\command", 0, KEY_READ, &hkey)){
    strcpy(AmpPath, "");
    return FALSE;
  }

  if(ERROR_SUCCESS != RegQueryValueEx(hkey, NULL, NULL, &dwType, (LPBYTE)buffer, &bufsize)){
    strcpy(AmpPath, "");
    RegCloseKey(hkey);
    return FALSE;
  }

  RegCloseKey(hkey);

  //delete " (0x22)
  *(char *)_tcschr((_TCHAR *)(buffer+1), 0x22) = NULL;
  strcpy(AmpPath, buffer+1);

  return TRUE;
}


/*=========================================================
  Execute(HWND)

=========================================================*/
/*inlined*/

/*========================================================
  ExecuteEx(HWND, BOOL)
    This function executes Winamp with visible option.

  HWND Parent window of Winamp (Should be NULL?)
  BOOL If It has been FALSE, Winamp will be Hidden on booting it.

  return: BOOL
    If this function success, TRUE is returned.
========================================================*/
BOOL CWinampFunction::ExecuteEx(HWND owner, BOOL bShown)
{
  char winamp_path[MAX_PATH+1];

  if(TRUE == GetWinampPath(winamp_path)){
    ShellExecute(owner, "open", winamp_path,NULL, NULL, (bShown)?SW_SHOW:SW_MINIMIZE);
    return TRUE;
  }

  return FALSE;
}


/*========================================================
  Close()
    This function closes winamp window.

========================================================*/
/* inlined */

/*========================================================
  FindWindow()
    This function wraps ::FindWindow(...) for winamp.

========================================================*/
HWND CWinampFunction::FindWindow()
{
#ifdef _WINAMP3_ALPHA
  HWND hwnd;

  hwnd = ::FindWindow(WC_WINAMP3, NULL);
  if(hwnd){
    m_bSenceWA3 = TRUE;
    return hwnd;
  }

  hwnd = ::FindWindow(WC_WINAMP, NULL);
  if(hwnd){
    m_bSenceWA3 = FALSE;
    return hwnd;
  }
  return NULL;

#else
  return ::FindWindow(WC_WINAMP, NULL);

#endif
}


/*=========================================================
  DisplayMainMenu()
    This function posts message to winamp to display main
    menu.

=========================================================*/
void CWinampFunction::DisplayMainMenu()
{
  HWND hwnd = FindWindow();

  if(hwnd){
    SetForegroundWindow(hwnd);
    PostMessage(hwnd, WM_RBUTTONUP, 0, 0);
  }
}
