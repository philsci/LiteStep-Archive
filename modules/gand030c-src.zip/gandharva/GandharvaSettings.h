// $Id: GandharvaSettings.h,v 1.12 2001/06/12 10:48:55 Yoshi Exp $
// Copyright (C) 2000,2001 HOSHINO Yoshifumi
// �{�v���O�����̓t���[�E�\�t�g�E�F�A�ł��B���ρE�Ĕz�z������ GNU GPL �o�[�W�����Q
// �i�������͂���ȍ~�j���Q�Ƃ��Ă��������B

#ifndef _H_GANDHARVA_SETTINGS
#define _H_GANDHARVA_SETTINGS

#define WIN32_LEAN_AND_MEAN

#include <windows.h>

//!bang command mode
#define CMDMODE_NONE	0
#define CMDMODE_BASIC	1
#define CMDMODE_DEBUG	2

//textalign
#define ALIGN_RIGHT		0
#define ALIGN_LEFT		1
#define ALIGN_CENTER	2

//timer id
#define TIMERID_RECYCLE_DISPLAY		0x00000001
#define TIMERID_SCROLL_INTERVAL		0x00000002

//macros
#define SWITCH DWORD

#define LAYOUT_MOUSE_MAP(__RCSTR, __VAR) \
  if(GetRCLine(__RCSTR, lpszbuf, 1024, "")){ \
    __VAR = new char[1+strlen(lpszbuf)]; \
    strcpy(__VAR, lpszbuf); \
  }


class GandharvaSettings
{
public:
  GandharvaSettings(HWND owner);
  ~GandharvaSettings();

  //functions
  void CreateBG();
  HBITMAP CreateTextBitmap(LPSTR, LOGFONT, COLORREF);
  void PaintBG(HDC);
  void PaintText(HDC);
  void PaintTextNoScroll(HDC);
  void PaintTime(HDC);

  //window param
  HWND		m_hWnd;
  HBITMAP	m_hbmBack;
  HBITMAP	m_hbmSkin;
  HBITMAP	m_hbmTitle;
  HBITMAP	m_hbmTime;

  //font and color
  LOGFONT m_TextLogFont;

  COLORREF m_FontColor;
  COLORREF m_BGColor;
  COLORREF m_BorderColor;
  COLORREF m_TranspColor;

  //display
  char m_lpszTitleDefault[130];

  int m_PosX,m_PosY,m_Width,m_Height;
  BOOL m_bXFromCenter,m_bYFromCenter;
  int m_nBorderLeft, m_nBorderRight, m_nBorderTop, m_nBorderBottom;
  int m_nPaddingLeft, m_nPaddingRight, m_nPaddingTop, m_nPaddingBottom;
  BOOL	m_bTitleScroll;
  BOOL	m_bAlwaysOnTop;
  BOOL	m_bVisible;
  BOOL	m_bVisibleAmp;
  SWITCH	m_swTextAlignH;

  //amp
  BOOL	m_bKeepPrefix;
  BOOL	m_bKeepSuffix;
  SWITCH	m_swCmdMode;

  //scroll
  int m_nScrollInterval;
  int m_nScrollStep;

  int	m_nScrollOffset;

  //amptime
  BOOL		m_bTimeEnable;
  BOOL		m_bTimeRemain;
  LOGFONT	m_TimeLogFont;
  COLORREF	m_TimeFontColor;
  int m_nATPaddingLeft, m_nATPaddingRight, m_nATPaddingTop, m_nATPaddingBottom;

  //custom click
  BOOL m_bMouseRemap;
  LPSTR m_lpszMouseALLC;
  LPSTR m_lpszMouseALRC;
  LPSTR m_lpszMouseALLD;
  LPSTR m_lpszMouseALRD;

  LPSTR m_lpszMouseTTLC;
  LPSTR m_lpszMouseTTRC;
  LPSTR m_lpszMouseTTLD;
  LPSTR m_lpszMouseTTRD;

  LPSTR m_lpszMouseTMLC;
  LPSTR m_lpszMouseTMRC;
  LPSTR m_lpszMouseTMLD;
  LPSTR m_lpszMouseTMRD;
};

#endif //_H_GAHDHARVA_SETTINGS
