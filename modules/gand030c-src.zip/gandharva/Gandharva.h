// $Id: Gandharva.h,v 1.10 2001/05/21 10:42:01 Yoshi Exp $
// Copyright (C) 2000,2001 HOSHINO Yoshifumi
// �{�v���O�����̓t���[�E�\�t�g�E�F�A�ł��B���ρE�Ĕz�z������ GNU GPL �o�[�W�����Q
// �i�������͂���ȍ~�j���Q�Ƃ��Ă��������B

#ifndef _H_GANDHARVA
#define _H_GANDHARVA

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "GandharvaSettings.h"
#include "winampfunc.h"
#include "ampcmd.h"

#define WC_LSDESKTOP		"DesktopBackgroundClass"
#define WINDOWCLASS_DLL		"GandharvaClass"

#define MAGICDWORD         0x49474541

#define TIMERID		DWORD

#define USERBM_TOGGLE		0
#define USERBM_SHOW			1
#define USERBM_HIDE			2
#define USERBM_TOGGLE_TIME	3
#define USERBM_DISPMENU		4
#define USERBM_SNDVOL		5

#define USERBM_AMP_POWER 10000
#define USERBM_AMP_COMMANDEX 10001

#define PCM_TIME	0x0001
#define PCM_TITLE	0x0002
#define PCM_OTHER	0x0000

//macros
#define REDIRECT_BANG(__OWNER,__HANDLER,__COMMAND) \
void __OWNER::__HANDLER(HWND caller, char* args){\
  HWND hwnd=FindWindow(WINDOWCLASS_DLL, 0);\
  if(hwnd)PostMessage(hwnd, WM_USER, __COMMAND, (LPARAM)atol(args));\
}

#define BEGIN_MESSAGE_PROC(__OWNER)\
  LRESULT __OWNER::WindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam){\
    LRESULT lresult=0;\
    switch(message){

#define MESSAGEFUNC(__HANDLER, __MESSAGE)\
    case __MESSAGE: __HANDLER(message, wparam, lparam, &lresult);break

#define END_MESSAGE_PROC\
    default: lresult=DefWindowProc(hwnd, message, wparam, lparam);\
    break;\
    }\
  return lresult;}


class Gandharva
{
public:
  Gandharva( HWND parent, HINSTANCE lsinstance );
  ~Gandharva();

  static void bangToggleVisible(HWND, char *);
  static void bangToggleTime(HWND, char *);
  static void bangShow(HWND, char *);
  static void bangHide(HWND, char *);
  static void bangDispMenu(HWND, char *);
  static void bangRunSndvol(HWND, char *);

  static void bangAmpPrev(HWND, char *);
  static void bangAmpPlay(HWND, char *);
  static void bangAmpPause(HWND, char *);
  static void bangAmpStop(HWND, char *);
  static void bangAmpNext(HWND, char *);
  static void bangAmpPLEdit(HWND, char *);
  static void bangAmpOpenFile(HWND, char *);
  static void bangAmpPower(HWND, char *);

  static void bangAmpCommand(HWND hwnd, char *);

  //void on(UINT, WPARAM, LPARAM, LRESULT *);
  void onUser(UINT, WPARAM, LPARAM, LRESULT *);
  void onPaint(UINT, WPARAM, LPARAM, LRESULT *);
  void onTimer(UINT, WPARAM, LPARAM, LRESULT *);
  void onLmGetRevid(UINT, WPARAM, LPARAM, LRESULT *);
  void onDisplayChange(UINT, WPARAM, LPARAM, LRESULT *);
  //  void onLButtonUp(UINT, WPARAM, LPARAM, LRESULT *);
  //  void onRButtonUp(UINT, WPARAM, LPARAM, LRESULT *);
  //  void onLButtonDblclk(UINT, WPARAM, LPARAM, LRESULT *);
  //  void onRButtonDblclk(UINT, WPARAM, LPARAM, LRESULT *);
  void onMouse(UINT, WPARAM, LPARAM, LRESULT *);

private:
  DWORD ParseClickMap(int x, int y);
  BOOL MyParseBangCommand(char *);

  CWinampFunction* m_pWinampFunc;
  GandharvaSettings* m_pSettings;

  void SetWndPos();
  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
  LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  LRESULT ParseAmpCommand(DWORD command);

  //timer id
  UINT m_rtimer,m_stimer;

  //system var
  HINSTANCE	m_hInstance;
  HWND	m_hLitestep;
  HWND	m_hDesktop;
  HWND	m_hWnd;
};

#endif //_H_GANDHARVA
