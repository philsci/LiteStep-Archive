/************************************************

  laptop.dll v1.1

  by: Jeb Crouson (TrOgI)
  crouson@inreach.com
  http://lssource.cjb.net

************************************************/

#include <windows.h>
#include <stdio.h>
#include "shortcut.h"
#include "lsapi.h"

void Standby(HWND caller, char* arg);
void Hibernate(HWND caller, char* arg);
void Shutdown(HWND caller, char* arg);
void Restart(HWND caller, char* arg);
void Power(HWND caller, char* arg);
void PCCard(HWND caller, char* arg);

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	AddBangCommand("!Standby", Standby);
	AddBangCommand("!Hibernate", Hibernate);
	AddBangCommand("!Shutdown2", Shutdown);
	AddBangCommand("!Restart", Restart);
	AddBangCommand("!Power", Power);
	AddBangCommand("!PCCard", PCCard);
	return 0;
}

void quitModule(HINSTANCE dllInst)
{
}

void Standby(HWND caller, char* arg)
{
	SetSystemPowerState(TRUE, FALSE);
}

void Hibernate(HWND caller, char* arg)
{
	SetSystemPowerState(FALSE, FALSE);
}

void Shutdown(HWND caller, char* arg)
{
	ExitWindowsEx(EWX_SHUTDOWN, 0);
}

void Restart(HWND caller, char* arg)
{
	ExitWindowsEx(EWX_REBOOT, 0);
}

void Power(HWND caller, char* arg)
{
	char winDir[128];
	GetSystemDirectory(winDir, 128);
	ShellExecute(caller, "open", "rundll32.exe", "shell32.dll,Control_RunDLL powercfg.cpl", winDir, SW_SHOWNORMAL);
}

void PCCard(HWND caller, char* arg)
{
	char winDir[128];
	GetSystemDirectory(winDir, 128);
	ShellExecute(caller, "open", "rundll32.exe", "shell32.dll,Control_RunDLL main.cpl PC Card (PCMCIA)", winDir, SW_SHOWNORMAL);
}