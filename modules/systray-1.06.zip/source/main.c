
////
/// system tray module interface implementation
//

//#define WIN32_LEAN_AND_MEAN
//#define STRICT

#include <windows.h>
#include <commctrl.h>
#include "lsapi.h"
#include "wharfdata.h"

#include "systray.h"
#include "registry.h"
// #include "debug.h"


HWND hLitestep;
HWND hSystray;

#ifdef OLDSYSTRAY
HWND hShellTrayWnd;
#endif

BOOL fDocked = FALSE;
HWND hWharfParent = NULL;

BOOL fAlwaysOnTop;
BOOL fBorderDrag;
int nBorderX;
int nBorderY;
BOOL fColorize;
BOOL fHidden;
int nIconSize;
int nX;
int nY;
int nSnapDistance;
int nSpacingX;
int nSpacingY;
int nWrapCount;
int nShortcutGroup;
BOOL fHidden;
BOOL fNoTransparency;
BOOL fHideIfEmpty;
BOOL fVisible;

int nMinWidth;
int nMinHeight;
int nMaxWidth;
int nMaxHeight;

BYTE bFromR, bToR;
BYTE bFromG, bToG;
BYTE bFromB, bToB;

HBITMAP hbmSkin = NULL;
BOOL fSkinTiled;
int nBitmapX;
int nBitmapY;
int nBorderLeft;
int nBorderTop;
int nBorderRight;
int nBorderBottom;

BOOL fHorizontal;
int nDeltaX;
int nDeltaY;
int nResizeH;
int nResizeV;

int nScreenX;
int nScreenY;

BOOL fWinNT;

UINT nMessages[] = {
	LM_GETREVID,
	LM_RESTORESYSTRAY,
	LM_SAVESYSTRAY,
	LM_SENDSYSTRAY,
	LM_SYSTRAY,
	0
};

//
// GetShellDesktop
//

HWND GetShellDesktop()
{
	HWND hDesktop = FindWindow( WC_SHELLDESKTOP, NULL );
	
	if( !hDesktop )
		hDesktop = GetDesktopWindow();
	
	return hDesktop;
}

//
// initModuleEx
//

EXTERN_C EXPORT int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	WNDCLASSEX wc;
	OSVERSIONINFO osvi;
	pszPath=pszPath;
	
	hLitestep = GetLitestepWnd();

	hSystray = NULL;
#ifdef OLDSYSTRAY
	hShellTrayWnd = NULL;
#endif
	nScreenX = GetSystemMetrics( SM_CXSCREEN );
	nScreenY = GetSystemMetrics( SM_CYSCREEN );
	
	InitCommonControls();
	
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx( &osvi );
	fWinNT = (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT) ? TRUE : FALSE;
	
	ReadConfig();
	
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_DBLCLKS | CS_GLOBALCLASS;
	wc.lpfnWndProc = SystrayProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.hIcon = NULL;
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WC_SYSTRAY;
	wc.hIconSm = NULL;
	
	RegisterClassEx( &wc );
	
	hSystray = CreateWindowEx( WS_EX_TOOLWINDOW,
		WC_SYSTRAY,
		NULL,
		fDocked ? WS_CHILD : WS_POPUP,
		nX,
		nY,
		0,
		0,
		fDocked ? hParent : hLitestep,
		NULL,
		hInstance,
		NULL );
	
	if( fAlwaysOnTop )
	{
		SetWindowPos( hSystray,
			HWND_TOPMOST,
			0, 0, 0, 0,
			SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );
	}
	else if( !fDocked )
	{
		SetParent( hSystray, GetShellDesktop() );
	}
	
	fVisible = !fHidden;
	AdjustLayout();
	
	SetWindowLong( hSystray, GWL_USERDATA, 0x49474541 );
	ShowWindow( hSystray, (fVisible && !fHideIfEmpty) ? SW_SHOWNOACTIVATE : SW_HIDE );
	
	SendMessage( hLitestep, LM_REGISTERMESSAGE, (WPARAM) hSystray, (LPARAM) nMessages );

	if( nShortcutGroup >= 0 )
		SendMessage( hLitestep, LM_DOCKTRAY, (WPARAM) hSystray, (LPARAM) nShortcutGroup );
	
	AddBangCommand( TEXT("!SystrayHide"), SystrayHide );
	AddBangCommand( TEXT("!SystrayMove"), SystrayMove );
	AddBangCommand( TEXT("!SystrayShow"), SystrayShow );
	AddBangCommand( TEXT("!SystrayToggle"), SystrayToggle );

	PostMessage( hLitestep, LM_SYSTRAYREADY, 0, 0 );

#ifdef OLDSYSTRAY
	if( !FindWindow( WC_SHELLTRAYWND, NULL ) )
	{
		wc.cbSize = sizeof(WNDCLASSEX);
		wc.style = CS_GLOBALCLASS;
		wc.lpfnWndProc = ShellTrayWndProc;
		wc.cbClsExtra = 0;
		wc.cbWndExtra = 0;
		wc.hInstance = hInstance;
		wc.hCursor = NULL;
		wc.hIcon = NULL;
		wc.hbrBackground = NULL;
		wc.lpszMenuName = NULL;
		wc.lpszClassName = WC_SHELLTRAYWND;
		wc.hIconSm = NULL;
		
		RegisterClassEx( &wc );
		
		hShellTrayWnd = CreateWindowEx( WS_EX_TOOLWINDOW,
			WC_SHELLTRAYWND,
			NULL,
			WS_POPUP,
			0,
			0,
			0,
			0,
			NULL,
			NULL,
			hInstance,
			NULL );
	}
#endif
	return 0;
}

//
// initModule
//

EXTERN_C EXPORT int initModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	return initModuleEx( hParent, hInstance, wd ? wd->lsPath:NULL );
}

//
// quitModule
//

EXTERN_C EXPORT void quitModule( HINSTANCE hInstance )
{
	BOOL (*pRemoveBangCommand)( LPCSTR );
	pRemoveBangCommand = (BOOL (*)( LPCSTR )) GetProcAddress( GetModuleHandle( TEXT("LSAPI.DLL") ), TEXT("RemoveBangCommand") );
	
	if( pRemoveBangCommand )
	{
		(*pRemoveBangCommand)( TEXT("!SystrayHide") );
		(*pRemoveBangCommand)( TEXT("!SystrayMove") );
		(*pRemoveBangCommand)( TEXT("!SystrayShow") );
		(*pRemoveBangCommand)( TEXT("!SystrayToggle") );
	}
#ifdef OLDSYSTRAY
	if( hShellTrayWnd )
	{
		DestroyWindow( hShellTrayWnd );
		UnregisterClass( WC_SHELLTRAYWND, hInstance );
	}
#endif
	SendMessage( hLitestep, LM_UNREGISTERMESSAGE, (WPARAM) hSystray, (LPARAM) nMessages );

	DestroyWindow( hSystray );
	UnregisterClass( WC_SYSTRAY, hInstance );
	
	hSystray = NULL;
}

//
// initWharfModule
//

EXTERN_C EXPORT int initWharfModule( HWND hParent, HINSTANCE hInstance, wharfDataType *wd )
{
	hWharfParent = hParent;
	fDocked = TRUE;
	
	return initModuleEx( hParent, hInstance, wd ? wd->lsPath:NULL );
}

//
// quitWharfModule
//

EXTERN_C EXPORT void quitWharfModule( HINSTANCE hInstance )
{
	quitModule( hInstance );
}

//
// Recycle
//

void Recycle()
{
	DeleteObject( hbmSkin );
	hbmSkin = NULL;
	
	ReadConfig();
	
	if( fAlwaysOnTop || fDocked )
		SetParent( hSystray, NULL );
	else
		SetParent( hSystray, GetShellDesktop() );
	
	SetWindowPos( hSystray, fAlwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
		nX, nY, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE );
	
	ShowWindow( hSystray, fHidden ? SW_HIDE : SW_SHOWNOACTIVATE );
	fVisible = !fHidden;
	
	AdjustLayout();
}

#ifndef _DEBUG
BOOL WINAPI _DllMainCRTStartup(HANDLE hDllHandle, DWORD dwReason, LPVOID lpResereved)
{
    switch( dwReason ) 
    { 
        case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls(hDllHandle);
            break;
	}

	return TRUE;
	UNREFERENCED_PARAMETER(lpResereved);
}
#endif