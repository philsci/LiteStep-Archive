 LSWeather Readme File                                           October 19th, 1999
+----------------------------------+-----------------------------------------------+
|  Coded By:                       |  MrJukes (mrjukes@purdue.edu)                 |
|  Themes, Testing, And Docs:      |  Tritian (tritian@planetquake.com)            |
|  Version:                        |  B4 (10/19/99)                                |
+----------------------------------+-----------------------------------------------+

=================
Table of Contents
=================

- Instructions
  - Wharf Module
  - Load Module
- Whats New
- LSWeather Usage
- Popups Menu
- Bangs Commands
- Example Modules.ini
- Closing Statements

==========
**NOTICE**
==========
In order for LSWeather B4 to function properly you will have to update to one of the
more recent Litestep builds.  I have found that the 10-9-99 build works quite nicely.
Anything before that build will probably result in LSWeather crashing or improper
functioning of the dialog boxes.

===========================
Instructions - Wharf Module
===========================

1) Unzip LSWeather to a directory off your LiteStep dir.
	example: c:\LiteStep\LSWeather\
2) Edit your step.rc file and add the following line:
	*Wharf LSWeather .none @C:\LiteStep\LSWeather\lsweather.app
3) Recycle LiteStep
4) Enter the Settings dialog and load "c:\LiteStep\LSWeather\lsweather-wm.thm"
5) If you need help with the Settings dialog hit F1 or click on the "?" button and
   then click on an edit box or button.

==========================
Instructions - Load Module
==========================

1) Unzip LSWeather to a directory off your LiteStep dir.
	example: c:\LiteStep\LSWeather\
2) Edit your step.rc file and add the following line:
	LoadModule C:\LiteStep\LSWeather\lsweather.app
3) Recycle LiteStep
4) Enter the Settings dialog and load "c:\LiteStep\LSWeather\lsweather-lm.thm"
5) If you need help with the Settings dialog hit F1 or click on the "?" button and
   then click on an edit box or button.

=================
What's New in B4?
=================

- Changed weather source, now www.wunderground.com
- LSWeather now is able to display:
	- Temperature, Humidity, Dewpoint
	- Pressure, Visibility, Wind
	- Sunrise, Sunset, Moonrise, Moonset
	- Weather Conditions in text or bitmap
- New configuration dialog controls:
	- All theme options
	- Saving and loading of new themes
- New bang commands:
	- !LSWHide, !LSWShow, !LSWToggle
	- !LSWUpdate, !LSWChangeSettings
	- !LSWLaunchWebpage, !LSWReport
	- !LSWAlwaysOntop (Toggle)
- Customizable double-click action
- Text display formatting added for all fields.
- All loadmodule display bugs fixed (for now)
- New incredible wharf and loadmodule themes created by Tritian! :P

=================
What's New in B3?
=================

- Added a favorites menu
- Fixed some bugs
- Moved weather conditions into the modules.ini instead of being hardcoded

=================
What's New in B2?
=================

- Can be loaded as a LoadModule
- Got rid of messagebox warning that it could not connect to weather.com
- Images can be in any directory

===============
LSWeather Usage
===============

LSWeather can get weather conditions from almost anywhere on the globe, providing
that you supply it with a proper Zip Code for US residence, or a global station code for 
international users.

To find out your Global Station Code goto www.wunderground.com and under the "International" 
section choose the continent you live in, then on the map choose your city.  Now in 
the URL box of your browser it should say a number followed by an .html extension.  
This is your Global Station Code.

Some Global Station Codes:

	- London, England   = 03772
	- Paris, France     = 07150
	- Jerusalem, Isreal = 40184
        - Sydney, Australia = 94767
	- Tokyo, Japan      = 47662
	- Hong Kong, China  = 45007
	- Toronto, Canada   = 71265

=================
String Formatting
=================
Temperature:
 + Valid Variables: %T[fck] %d
 - Example) Temp: %Tf %dF		==> Temp: 80 �F
 - Example) T: %Tc%dC			==> T: 27�C
 - Example) %Tk%dK			==> 278�K

Pressure:
 + Valid Variables: %P[ih]
 - Example) Pres: %Pi inches		==> Pres: 8 inches
 - Example) P: %Ph hPa			==> P: 270 hPa

Humidity:
 + Valid Variables: %H
 - Example) Hum: %H%			==> Hum: 38%

Dew Point:
 + Valid Variabes: %D[fck] %d
 - Example) Dew: %Df %dF		==> Dew: 80 �F
 - Example) D: %Dc%dC			==> D: 27�C
 - Example) %Dk%dK			==> 278�K

Visibility:
 + Valid Variables: %V[mk]
 - Example) Vis: %Vm miles		==> Vis: 10 miles
 - Example) Vis: %Vk km			==> Vis: 17 km

Wind:
 + Valid Variables: %W[dmk]
 - Example) Wind: %Wd at %Wm mph	==> Wind: NNW at 8mph
 - Example) Wind: %Wk kph		==> Wind: 12 kph

Sunrise:
 + Valid Variables: %SR[hmwz]
 - Example) Sunrise: %SRh:%SRm%SRw %SRz	==> Sunrise: 6:15AM EDT
 - Example) SR: %SRh:%SRm %SRw		==> SR: 7:25 AM

Sunset:
 + Valid Variables: %SS[hmwz]
 - Example) Sunset: %SSh:%SSm%SSw %SSz	==> Sunset: 6:15PM EDT
 - Example) SS: %SSh:%SSm %SSw		==> SS: 7:25 PM

Moonrise:
 + Valid Variables: %MR[hmwz]
 - Example) Moonrise: %MRh:%MRm%MRw %MRz	==> Moonrise: 6:15AM EDT
 - Example) MR: %MRh:%MRm %MRw			==> MR: 7:25 AM

Moonset:
 + Valid Variables: %MS[hmwz]
 - Example) Moonset: %MSh:%MSm%MSw %MSz	==> Moonset: 6:15AM EDT
 - Example) MS: %MSh:%MSm %MSw		==> MS: 7:25 AM

Weather Conditions:
 + Valid Variables: %C
 - Example) %C				==> Partly Cloudy
 - Example) Cond: %C			==> Cond: Sunny

==========
Popup Menu
==========

Update               - Update weather conditions for selected area.
Active               - Toggles automatic update of the weather
Report Conditions    - Brings up a dialog with all your weather conditions
Change Settings      - Changes your settings
Launch Webpage       - Launches www.wunderground.com to your current location
About LSWeather      - The about box
  -----
Favorites            - Stores your favorites, add up to 10 favorites through settings.
  -----
Use Zip Code         - Uses the specified zip code
Use City             - Uses the specified city file
Use Global Station   - Uses the global station code for your area.

=============
Bang Commands
=============

Load/Wharf Bang Commands:
  !LSWUpdate         - Updates weather conditions
  !LSWChangeSettings - Enters the settings dialog
  !LSWLaunchWebpage  - Launches www.wunderground.com
  !LSWReport         - Brings up a dialog with the current conditions.

LoadModule Specific Bang Commands:
  !LSWHide           - Hides LSWeather
  !LSWShow           - Shows LSWeather
  !LSWToggle         - Toggles Hide/Show of LSWeather
  !LSWAlwaysOntop    - Toggles LSWeather's always ontop status

============================
Example Modules.ini Settings
============================

	[LSWeather]
	ThemeFile=c:\litestep\LSWeather\lsweather-wm.thm
	DesktopX=192        // Module Leftmost Position
	DesktopY=0          // Module Topmost Position
	Timer=30            // Update Timer (in minutes)
	ZipCode=33322
	City=Sunrise
	State=FL
	GlobalStation=      // US Resident, None Needed.

        // Begin Favorites, up to 10 can be specified

	Favorite0=Sunrise, Florida
	FavoriteZip0=33322
	FavoriteCity0=Sunrise
	FavoriteState0=FL
	Favorite1=Lafayette
	FavoriteZip1=47906
	FavoriteFile1=us_in_lafayette.html
	FavoriteState0=IN
	Favorite2=Northbrook
	FavoriteZip2=60062
	FavoriteFile2=us_il_northbrook.html
	FavoriteState0=IL
	Favorite3=Lake Bluff
	FavoriteZip3=60044
	FavoriteFile3=us_il_lake_bluff.html
	FavoriteState0=IL

==================
Closing Statements
==================

Thank you for trying LSWeather, and i hope you enjoy it.

Send Module feedback to mrjukes@purdue.edu
Send Theme feedback to tritian@planetquake.com

*PS* Remember. If it crashes...don't do that =P