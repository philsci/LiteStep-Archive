A little module for the wharfbar.
It's a SKINABLE frontend for winamp.
You can make skins for it if you want.

Author       : MooG
mail         : alexandre.oudin@wanadoo.fr
installation : as any other wharf module (see the help file).
source code  : yes, if you want them, mail me (it's a delphi plugin).
	       (I can send them to the site, just tell me).
comment      : I use it everyday... Seems to work. Works for
               any winamp version (up to 2.5e).
