File Editor (change.dll) version 0.2
This file was updated on 10-23-2001 by Two_toNe
This file was originally created on 2000-00-18 by Asperon
**************************************************************
1. Introduction

   This modules' purpose is to write changes directly to the 
   step.rc or any given file. It writes the change and saves it 
   "behind the scenes". The changes are put into effect when 
   the user recycles litestep.

**************************************************************
2. Installation

   Unzip the change.dll into your litestep dir. Add the line:

   loadmodule c:\litestep\change.dll   

   to your step.rc (change c:\litestep to point at your 
   litestep dir)
 

**************************************************************
3. Usage
	
   The syntax for this module is very simple. Each change you 
   wish to make becomes a bang command. The bang command that 
   you create can be activated by any of the common ways. 
   Ie: shortcut, popup, wharf, hotkey, or command line 
   (lsxcommand).
   The bang command looks like this:
   !changeline [original line] [new line] [mode] {file to edit}
   note: anything enclosed in [] is required, anything enclosed in {} is optional.
   
   Parameters can be enclosed in nothing or any of the following: [], "", {}, ''.
   All parameters are currently case sensitive, working on a fix for this.
   
   The mode parameter determines how the changes are made.
   currently there are 3 modes:
   [normal]    - find the line in param1, replace with param2
   [substring] - is param1 a substring of the current line,  if so, replace
   [force]     - just like normal mode, but if the line isn't found then append param2 to the end of file
   note: comments at the end of a line are ignored and left intact (tab characters are changed to spaces)
           	    
   an example of this might be: 
   !changeline [SystrayHidden][;SystrayHidden][normal]
   This would look for 'SystrayHidden' in the step.rc and changed it to 
   ';SystrayHidden' if it is found. Nothing would happen if it was not found.
   But if we change the bang to:
   !changeline [SystrayHidden][;SystrayHidden][force]
   If 'SystrayHidden' was not found, it would add ';SystrayHidden' to the end of 
   the step.rc.
   
   Now say we have an entry in a file called command.rc in the theme path 
   (variables are reconized) like this:
   CommandTextColor	000000	;color of the text
   By calling this bang:
   !changeline [CommandTextColor][CommandTextColor 404040][normal][$dirTheme$command.rc]
   The line would be changed to:
   CommandTextColor 404040		;color of the text
   note: tab characters are changed to spaces, working on this fix too.
   
   Now lets try the substring mode:
   Again say we have an entry in a file called command.rc in the theme path 
   (variables are reconized) like this:
   BarTopImage			$BarColor$bar_top.bmp|$TrimColor$bar_top.bmp|$ButtonColor$bar_top.bmp	;top bar image
   By calling this bang:
   !changeline [bar_top][bar_bottom][substring][$dirTheme$test.rc]
   The line would be changed to:
   BarTopImage			$BarColor$bar_bottom.bmp|$TrimColor$bar_bottom.bmp|$ButtonColor$bar_bottom.bmp	;top bar image
   
   But be careful when using substrings, because odd things can happen.
   For example, by calling this:
   !changeline "is" "isn't" "substring"
   would change this:
   This is a Test
   to this:
   Thisn't isn't a Test
   The correct way to call this bang would be:
   !changeline " is " " isn't " "substring"
   With a result of:
   This isn't a Test
   
   

**************************************************************
4. Updates
   0.2 update by Two_toNe
   	[fix] - recompiled to work with new builds
   	[fix] - 'force' mode now works correctly
   	[fix] - 'substring' now only changes the word(s) specified, not the whole line
   	[new] - ability to specify a file to edit
   	[new] - now saves comments at the end of a line
   
   0.1 first release by Asperon

**************************************************************
5. Contact
	
   Any desired features, bug reports or just to show your 
   gratitude, get in contact with me. 

   You can contact me at:
	2tone@inreach.com

   The lastest updates for this program can be found at:
   	http://shellfront.org

**************************************************************
6. Thnx to

   Message - for some small issues with my coding
   pika` - for testing
   

**************************************************************
7. Known problems

   - Parameters are case sensitive, working on a fix for this
   - extra blank lines are sometimes added to the file, not a problem, but may try to fix soon
   - in lines edited, tab characters are changed to spaces, also not a problem, but may try to fix soon
