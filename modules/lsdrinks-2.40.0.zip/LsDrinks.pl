# /usr/bin/perl -w
#############################################################################
# lsDrinks 2.40.0                                                            
# Hacked up by : nf0 <nf0@10500bc.org>                                       
#                                                                           
# Thanks to Charlie <ishamael@orodruin.ddns.org> for making asDrinks        
# Thanks to Flip for making flipsthing.
# Thanks to Spawn@desktopz.org for helping out and making suggestions
# Thanks to Tin_Omin <desktopian.org> for the best site on the net and
# helping the community with with some backends.                           
# Thanks to MrJukes and geekMASTR for provinding community backends.
# Thanks to Aemergin for submitting some code to help under Win2k and IE 5.
# Thanks to Twyst <twyst@twysted.net> for makeing folder change suggestions.                                                                                                               
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to:
#   the Free Software Foundation, Inc.
#   59 Temple Place - Suite 330
#   Boston, MA  02111-1307, USA.
###############################################################################

require 5.004;
use strict;
use Socket;
use Time::localtime;


my $rcfile   = "lsdrinks.rc";
my %drinkvals;
my $drinkvals = "$rcfile";
open(DRINKVALS, $drinkvals);
  while (<DRINKVALS>) {
    chomp;
    next if /^\s*\#/;
    next unless /=/;
    my ($key, $value) = split(/=/, $_, 2);
    $value =~ s/(\$(\w+))/$drinkvals{$2}/g;
    $drinkvals{$key} = $value;
  }
close(DRINKVALS);

my $startdir    = $drinkvals{maindir};
my $folderdir   = $drinkvals{folderdir};
my $style       = $drinkvals{style};
my $feedback    = $drinkvals{feedback};
my $folderval   = $drinkvals{folderval};
my $foldernumval= $drinkvals{foldernumval};
my $pageval     = $drinkvals{pageval};
my $pagename    = $drinkvals{pagename};
my $pagetitle   = $drinkvals{pagetitle};
my $slashdir 	= $drinkvals{slashdot_dir};my $fmdir 	= $drinkvals{freshmeat_dir};my $segdir 	= $drinkvals{segfault_dir};
my $ltdir 	= $drinkvals{linuxtoday_dir};my $dtdir 	= $drinkvals{desktopian_dir};my $ttdir 	= $drinkvals{technotronic_dir};
my $bndir 	= $drinkvals{betanews_dir};my $atdir 	= $drinkvals{arstechnica_dir};my $fldir 	= $drinkvals{floach_dir};
my $bendir 	= $drinkvals{benews_dir};my $thodir 	= $drinkvals{themesorg_dir};my $scdir 	= $drinkvals{solariscentral_dir};
my $lgdir 	= $drinkvals{linuxgames_dir};my $ladir 	= $drinkvals{linuxapps_dir};my $asdir 	= $drinkvals{atstake_dir};
my $hpndir 	= $drinkvals{happypenguinnews_dir};my $hpudir 	= $drinkvals{happypenguinupdates_dir};my $hpadir 	= $drinkvals{happypenguinadd_dir};
my $lqdir 	= $drinkvals{linuxquake_dir};my $agdir  	= $drinkvals{absolutegamers_dir};my $l3ddir 	= $drinkvals{linux3d_dir};
my $blndir      = $drinkvals{bluesnews_dir};my $vedir	= $drinkvals{voodooextreme_dir};my $podir 	= $drinkvals{python_dir};
my $ufdir       = $drinkvals{uf_dir};my $apoddir     = $drinkvals{apod_dir};my $fileforumdir= $drinkvals{fileforum_dir};
my $dilbertdir  = $drinkvals{dilbert_dir};my $shellcitydir= $drinkvals{shellcity_dir};my $aftery2kdir = $drinkvals{aftery2k_dir};
my $litestepnetdir   = $drinkvals{litestepnet_dir};my $litestepnetssdir = $drinkvals{litestepnetss_dir};my $litestepnettdir  = $drinkvals{litestepnett_dir};
my $pvponlinedir     = $drinkvals{pvponline_dir};my $scifiwiredir = $drinkvals{scifiwire_dir};my $techreportdir = $drinkvals{techreport_dir};
my $shellscapedir = $drinkvals{shellscape_dir};my $fileclicksdir = $drinkvals{fileclicks_dir};my $pennyarcadedir = $drinkvals{pennyarcade_dir};
my $geeknikdir = $drinkvals{geeknik_dir};my $newscomdir = $drinkvals{newscom_dir};my $wirednewsdir = $drinkvals{wirednews_dir};
my $pmsnippetsdir=$drinkvals{pmsnippets_dir};my $pmcoolusesdir=$drinkvals{pmcooluses_dir};my $pmpoetrydir=$drinkvals{pmpoetry_dir};
my $pmobfusdir=$drinkvals{pmobfus_dir};my $pmcraftdir=$drinkvals{pmcraft_dir};my $pmmeddir=$drinkvals{pmmed_dir};
my $mjnewsdir=$drinkvals{mjnews_dir};my $mjideasdir=$drinkvals{mjideas_dir};
my $mjsnipsdir=$drinkvals{mjsnips_dir};my $tekreviewdir=$drinkvals{tekreview_dir};
my $ebgdir=$drinkvals{ebg_dir};my $aicndir=$drinkvals{aicn_dir};
my $epocnewsdir=$drinkvals{epocnews_dir};my $sinfestdir=$drinkvals{sinfest_dir};
my $joeaveragedir=$drinkvals{joeaverage_dir};my $avalonhighdir=$drinkvals{avalonhigh_dir};
my $houndsdir=$drinkvals{hounds_dir};my $goatsdir=$drinkvals{goats_dir};
my $funnyfarmdir=$drinkvals{funnyfarm_dir};my $brunodir=$drinkvals{bruno_dir};
my $newshoundsdir=$drinkvals{newshounds_dir};my $gpfdir=$drinkvals{gpf_dir};
my $elflifedir=$drinkvals{elflife_dir};my $cmptrdir=$drinkvals{cmptr_dir};
my $palmstationdir=$drinkvals{palmstation_dir};my $pdabuzzdir=$drinkvals{pdabuzz_dir};
my $palminfocenterdir=$drinkvals{palminfocenter_dir};my $daemonnewsdir=$drinkvals{daemonnews_dir};
my $icewalkersdir=$drinkvals{icewalkers_dir};my $wonkoslicedir=$drinkvals{wonkoslice_dir};
my $neofluxdir=$drinkvals{neoflux_dir};my $digitaltheatredir=$drinkvals{digitaltheatre_dir};
my $castersrealmdir=$drinkvals{castersrealm_dir};my $everloredir=$drinkvals{everlore_dir};
my $eqcornerdir=$drinkvals{eqcorner_dir};my $eqstraticsdir=$drinkvals{eqstratics_dir};
my $dvdanimaniadir=$drinkvals{dvdanimania_dir};my $modulodir=$drinkvals{modulo_dir};
my $purelsdir=$drinkvals{purels_dir};my $nonagsdir=$drinkvals{nonags_dir};
my $desktopsourcedir=$drinkvals{desktopsource_dir};my $acehardwaredir=$drinkvals{acehardware_dir};
my $pcstatsdir=$drinkvals{pcstats_dir};my $animenewsservicedir=$drinkvals{animenewsservice_dir};
my $eqlizerdir=$drinkvals{eqlizer_dir};my $shugashackdir=$drinkvals{shugashack_dir};
my $filewatcherdir=$drinkvals{filewatcher_dir};my $coredir=$drinkvals{core_dir};
my $webmonkeydir=$drinkvals{webmonkey_dir};my $infoworlddir=$drinkvals{infoworld_dir};
my $linuxpowerdir=$drinkvals{linuxpower_dir};my $lwndir=$drinkvals{lwn_dir};
my $mklinuxdir=$drinkvals{mklinux_dir};my $monkeyfistdir=$drinkvals{monkeyfist_dir};
my $newsforgedir=$drinkvals{newsforge_dir};my $packetstorm_newdir=$drinkvals{packetstorm_new_dir};my $packetstorm_advdir=$drinkvals{packetstorm_adv_dir};my $packetstorm_tooldir=$drinkvals{packetstorm_tool_dir};
my $packetstorm_expldir=$drinkvals{packetstorm_expl_dir};my $packetstorm_miscdir=$drinkvals{packetstorm_misc_dir};
my $thinkgeekdir=$drinkvals{thinkgeek_dir};my $screamingpenguindir=$drinkvals{screamingpenguin_dir};
my $sdndir=$drinkvals{sdn_dir};my $freaktechdir=$drinkvals{freaktech_dir};
my $lsdevdir=$drinkvals{lsdev_dir};my $lsd4pdir=$drinkvals{lsd4p_dir};
my $dejddir=$drinkvals{dejd_dir};my $dnewsdir=$drinkvals{dnews_dir};
my $anandtechdir=$drinkvals{anandtech_dir};my $coladir=$drinkvals{cola_dir};
my $dailyradardir=$drinkvals{dailyradar_dir};my $dotcommadir=$drinkvals{dotcomma_dir};
my $eetdir=$drinkvals{eet_dir};my $emuviewsdir=$drinkvals{emuviews_dir};
my $skinzdir=$drinkvals{skinz_dir};my $streamingdir=$drinkvals{streaming_dir};
my $freeosdir=$drinkvals{freeos_dir};my $freexmldir=$drinkvals{freexml_dir};
my $advogatodir=$drinkvals{advogato_dir};my $bbspotdir=$drinkvals{bbspot_dir};
my $endeffectdir=$drinkvals{endeffect_dir};my $joytechdir=$drinkvals{joytech_dir};
my $spacedir=$drinkvals{space_dir};my $cryptomedir=$drinkvals{cryptome_dir};
my $virtualplasticdir=$drinkvals{virtualplastic_dir};my $betabitesdir=$drinkvals{betabites_dir};
my $kuro5hindir=$drinkvals{kuro5hin_dir};my $shouldexistdir=$drinkvals{shouldexist_dir};
my $xentertainmentdir=$drinkvals{xentertainment_dir};my $arstechnica2dir=$drinkvals{arstechnica2_dir};my $yoginewsdir=$drinkvals{yoginews_dir};my $ellicitdir=$drinkvals{ellicit_dir};my $geeknewsnetdir=$drinkvals{geeknewsnet_dir};
my $kdenewsdir=$drinkvals{kdenews_dir};my $linuxcomdir=$drinkvals{linuxcom_dir};my $linuxcomjobsdir=$drinkvals{linuxcomjobs_dir};
my $linuxcomgramdir=$drinkvals{linuxcomgram_dir};my $linuxnewbiedir=$drinkvals{linuxnewbie_dir};
my $linuxprogrammingdir=$drinkvals{linuxprogramming_dir};my $linuxtelephonydir=$drinkvals{linuxtelephony_dir};
my $mercdir=$drinkvals{merc_dir};my $mrtechdir=$drinkvals{mrtech_dir};my $mtodir=$drinkvals{mto_dir};
my $nanodotdir=$drinkvals{nanodot_dir};my $perlnewsdir=$drinkvals{perlnews_dir};
my $phpbuildergendir=$drinkvals{perlnews_dir};my $phpbuildergendir=$drinkvals{phpbuildergen_dir};
my $phpbuildercodedir=$drinkvals{phpbuildercode_dir};my $phpbuilderinstalldir=$drinkvals{phpbuilderinstall_dir};
my $phpbuilderwindir=$drinkvals{phpbuilderwin_dir};my $phpbuilderdbdir=$drinkvals{phpbuilderdb_dir};
my $phpbuilderartdir=$drinkvals{phpbuilderart_dir};my $q3arenadir=$drinkvals{q3arena_dir};
my $rootpromptdir=$drinkvals{rootprompt_dir};my $techdirtdir=$drinkvals{techdirt_dir};
my $thekultdir=$drinkvals{thekult_dir};my $tomsdir=$drinkvals{toms_dir};
my $tweak3ddir=$drinkvals{tweak3d_dir};my $tweaktowndir=$drinkvals{tweaktown_dir};
my $tweakfilesdir=$drinkvals{tweakfiles_dir};my $twomobiledir=$drinkvals{twomobile_dir};
my $infoletsdir=$drinkvals{infolets_dir};my $fileflashdir=$drinkvals{fileflash_dir};

my @which       = ($drinkvals{slashdot},$drinkvals{freshmeat},$drinkvals{segfault},$drinkvals{linuxtoday},
                   $drinkvals{desktopian},$drinkvals{technotronic},$drinkvals{betanews},$drinkvals{arstechnica},
                   $drinkvals{floach},$drinkvals{benews},$drinkvals{themesorg},$drinkvals{solariscentral},
                   $drinkvals{linuxgames},$drinkvals{linuxapps},$drinkvals{atstake},$drinkvals{happypenguinnews},
                   $drinkvals{happypenguinupdates},$drinkvals{happypenguinadd},$drinkvals{linuxquake},$drinkvals{absolutegamers},
                   $drinkvals{linux3d},$drinkvals{bluesnews},$drinkvals{voodooextreme},
                   $drinkvals{python},$drinkvals{userfriendly},$drinkvals{apod},$drinkvals{fileforum},
                   $drinkvals{dilbert},$drinkvals{shellcity},$drinkvals{aftery2k},$drinkvals{litestepnet},
                   $drinkvals{litestepnetss},$drinkvals{litestepnett},$drinkvals{pvponline},$drinkvals{scifiwire},$drinkvals{techreport},
                   $drinkvals{shellscape},$drinkvals{fileclicks},$drinkvals{pennyarcade},$drinkvals{geeknik},$drinkvals{newscom},$drinkvals{wirednews},
                   $drinkvals{pmsnippets},$drinkvals{pmcooluses},$drinkvals{pmpoetry},$drinkvals{pmobfus},
                   $drinkvals{pmcraft},$drinkvals{pmmed},$drinkvals{mjnews},$drinkvals{mjideas},$drinkvals{mjsnips},
                   $drinkvals{tekreview},$drinkvals{ebg},$drinkvals{aicn},$drinkvals{epocnews},$drinkvals{sinfest},
                   $drinkvals{joeaverage},$drinkvals{avalonhigh},$drinkvals{hounds},$drinkvals{goats},
                   $drinkvals{funnyfarm},$drinkvals{bruno},$drinkvals{newshounds},$drinkvals{gpf},
                   $drinkvals{elflife},$drinkvals{cmptr},$drinkvals{palmstation},$drinkvals{pdabuzz},
                   $drinkvals{palminfocenter},$drinkvals{daemonnews},$drinkvals{icewalkers},
                   $drinkvals{wonkoslice},$drinkvals{neoflux},$drinkvals{digitaltheatre},
                   $drinkvals{castersrealm},$drinkvals{everlore},$drinkvals{eqcorner},$drinkvals{eqstratics},
                   $drinkvals{dvdanimania},$drinkvals{modulo},$drinkvals{purels},
                   $drinkvals{nonags},$drinkvals{desktopsource},$drinkvals{acehardware},$drinkvals{pcstats},
                   $drinkvals{animenewsservice},$drinkvals{eqlizer},$drinkvals{shugashack},$drinkvals{filewatcher},$drinkvals{core},
                   $drinkvals{webmonkey},$drinkvals{infoworld},$drinkvals{linuxpower},$drinkvals{lwn},
                   $drinkvals{mklinux},$drinkvals{monkeyfist},$drinkvals{newsforge},
                   $drinkvals{packetstorm_new},$drinkvals{packetstorm_adv},$drinkvals{packetstorm_tool},$drinkvals{packetstorm_expl},$drinkvals{packetstorm_misc},
                   $drinkvals{thinkgeek},$drinkvals{screamingpenguin},
                   $drinkvals{sdn},$drinkvals{freaktech},$drinkvals{lsdev},$drinkvals{lsd4p},$drinkvals{dejd},$drinkvals{dnews},
                   $drinkvals{anandtech},$drinkvals{cola},$drinkvals{dailyradar},$drinkvals{dotcomma},$drinkvals{eet},
                   $drinkvals{emuviews},$drinkvals{skinz},$drinkvals{streaming},$drinkvals{freeos},
                   $drinkvals{freexml},$drinkvals{advogato},$drinkvals{bbspot},$drinkvals{endeffect},$drinkvals{joytech},
                   $drinkvals{space},$drinkvals{cryptome},$drinkvals{virtualplastic},$drinkvals{betabites},
                   $drinkvals{kuro5hin},$drinkvals{shouldexist},$drinkvals{xentertainment},
                   $drinkvals{arstechnica2},$drinkvals{yoginews},$drinkvals{ellicit},$drinkvals{geeknewsnet},$drinkvals{kdenews},
                   $drinkvals{linuxcom},$drinkvals{linuxcomjobs},$drinkvals{linuxcomgram},$drinkvals{linuxnewbie},$drinkvals{linuxprogramming},
                   $drinkvals{linuxtelephony},$drinkvals{merc},$drinkvals{mrtech},$drinkvals{mto},$drinkvals{nanodot},
                   $drinkvals{perlnews},$drinkvals{phpbuildergen},$drinkvals{phpbuildercode},$drinkvals{phpbuilderinstall},$drinkvals{phpbuilderwin},$drinkvals{phpbuilderdb},$drinkvals{phpbuilderart},
                   $drinkvals{q3arena},$drinkvals{rootprompt},$drinkvals{techdirt},$drinkvals{thekult},$drinkvals{toms},
                   $drinkvals{tweak3d},$drinkvals{tweaktown},$drinkvals{tweakfiles},$drinkvals{twomobile},$drinkvals{infolets},
                   $drinkvals{fileflash});
my $border	= $drinkvals{border};
my $back	= $drinkvals{back};
my $entryback	= $drinkvals{entryback};
my $bodyback	= $drinkvals{bodyback};
my $bodytext	= $drinkvals{bodytext};
my $bodylink	= $drinkvals{bodylink};
my $bodyvlink	= $drinkvals{bodyvlink};
my $bodyalink   = $drinkvals{bodyalink};
my $limit       = $drinkvals{limit};
my @order       = ($drinkvals{1},$drinkvals{2},$drinkvals{3},$drinkvals{4},$drinkvals{5},
                   $drinkvals{6},$drinkvals{7},$drinkvals{8},$drinkvals{9},$drinkvals{10},
                   $drinkvals{11},$drinkvals{12},$drinkvals{13},$drinkvals{14},$drinkvals{15},
                   $drinkvals{16},$drinkvals{17},$drinkvals{18},$drinkvals{19},$drinkvals{20},
                   $drinkvals{21},$drinkvals{22},$drinkvals{23},$drinkvals{24},$drinkvals{25},
                   $drinkvals{26},$drinkvals{27},$drinkvals{28},$drinkvals{29},$drinkvals{30},
                   $drinkvals{31},$drinkvals{32},$drinkvals{33},$drinkvals{34},$drinkvals{35},
                   $drinkvals{36},$drinkvals{37},$drinkvals{38},$drinkvals{39},$drinkvals{40},
                   $drinkvals{41},$drinkvals{42},$drinkvals{43},$drinkvals{44},$drinkvals{45},
                   $drinkvals{46},$drinkvals{47},$drinkvals{48},$drinkvals{49},$drinkvals{50},
                   $drinkvals{51},$drinkvals{52},$drinkvals{53},$drinkvals{54},$drinkvals{55},
                   $drinkvals{56},$drinkvals{57},$drinkvals{58},$drinkvals{59},$drinkvals{60},
                   $drinkvals{61},$drinkvals{62},$drinkvals{63},$drinkvals{64},$drinkvals{65},
                   $drinkvals{66},$drinkvals{67},$drinkvals{68},$drinkvals{69},$drinkvals{70},
                   $drinkvals{71},$drinkvals{72},$drinkvals{73},$drinkvals{74},$drinkvals{75},
                   $drinkvals{76},$drinkvals{77},$drinkvals{78},$drinkvals{79},$drinkvals{80},
                   $drinkvals{81},$drinkvals{82},$drinkvals{83},$drinkvals{84},$drinkvals{85},
                   $drinkvals{86},$drinkvals{87},$drinkvals{88},$drinkvals{89},$drinkvals{90},
                   $drinkvals{91},$drinkvals{92},$drinkvals{93},$drinkvals{94},$drinkvals{95},
                   $drinkvals{96},$drinkvals{97},$drinkvals{98},$drinkvals{99},$drinkvals{100},
                   $drinkvals{101},$drinkvals{102},$drinkvals{103},$drinkvals{104},$drinkvals{105},
                   $drinkvals{106},$drinkvals{107},$drinkvals{108},$drinkvals{109},$drinkvals{110},
                   $drinkvals{111},$drinkvals{112},$drinkvals{113},$drinkvals{114},$drinkvals{115},
                   $drinkvals{116},$drinkvals{117},$drinkvals{118},$drinkvals{119},$drinkvals{120},
                   $drinkvals{121},$drinkvals{122},$drinkvals{123},$drinkvals{124},$drinkvals{125},
                   $drinkvals{126},$drinkvals{127},$drinkvals{128},$drinkvals{129},$drinkvals{130},
                   $drinkvals{131},$drinkvals{132},$drinkvals{133},$drinkvals{134},$drinkvals{135},
                   $drinkvals{136},$drinkvals{137},$drinkvals{138},$drinkvals{139},$drinkvals{140},
                   $drinkvals{141},$drinkvals{142},$drinkvals{143},$drinkvals{144},$drinkvals{145},
                   $drinkvals{146},$drinkvals{147},$drinkvals{148},$drinkvals{149},$drinkvals{150},
                   $drinkvals{151},$drinkvals{152},$drinkvals{153},$drinkvals{154},$drinkvals{155},
                   $drinkvals{156},$drinkvals{156},$drinkvals{157},$drinkvals{158},$drinkvals{159},
                   $drinkvals{160},$drinkvals{161},$drinkvals{162},$drinkvals{163},$drinkvals{164});
                   
my $tm = localtime;
my $t_hour = $tm->hour;  
my $t_min  = $tm->min;
my $t_sec  = $tm->sec;                   
my $t_year = $tm->year+1900;
my $t_mon  = $tm->mon+1;
my $t_mday = $tm->mday;               

my ($remote,$file,$backend,$port,$iaddr,$paddr,$proto);
my ($line,$first,$second,$third,$fourth,$fifth,$sixth,$seventh,$eighth,$ninth,$tenth,$pattern,$pattern1,$pattern2,$pattern3,$pattern4,$flag);
my ($linecount,$linenumber,$topic,$blocklength,$num,$fromtop,$topicline,$linkline,$dir,$x,$y);
my ($header1,$header2,$i,$a,$topiccount,$tc);

# Get the news.

if($pageval == 1){
  createpage();
  header();
}

if($folderval ==1){
  if (-e "$folderdir") {
  }else{
  mkdir("$folderdir",0777) || die "Cannot mkdir $folderdir: $!";
  }
}

if ($style == 0){
  for($i = 0; $i < @which; $i++){
    if($which[$i] == 1){
	      if($i == 0){
	        lsVodka();
	      }elsif($i == 1){
	        lsWhiskey();
	      }elsif($i == 2){
	        lsRum();  
	      }elsif($i == 3){
	        lsGin();  
	      }elsif($i == 4){
	        lsHotDamn();  
	      }elsif($i == 5){
	        lsBeer();
	      }elsif($i == 6){
	        lsAfterShock();  
	      }elsif($i == 7){
	        lsButterScotch();  
	      }elsif($i == 8){
	        lsScotch();  
	      }elsif($i == 9){
	        lsMartini();
	      }elsif($i == 10){
	        lsMalibu();
	      }elsif($i == 11){
	        lsSouthernComfort();
	      }elsif($i == 12){
	        lsLG();
	      }elsif($i == 13){
	        lsLA();
	      }elsif($i == 14){
	        lsAS();
	      }elsif($i == 15){
	        lsHPN();
	      }elsif($i == 16){
	        lsHPU();
	      }elsif($i == 17){
	        lsHPA();
	      }elsif($i == 18){
	        lsLQ();
	      }elsif($i == 19){
	        lsAGF();
	      }elsif($i == 20){
	        lsL3D();
	      }elsif($i == 21){
	        lsBLN();
	      }elsif($i == 22){
	        lsVE();
	      }elsif($i == 23){
	        lsPO();
	      }elsif($i == 24){
	        lsUF();
	      }elsif($i == 25){
	        lsAPOD();
	      }elsif($i == 26){
	        lsff();
	      }elsif($i == 27){
	        lsDil();
	      }elsif($i == 28){
	        lsSCity();
	      }elsif($i == 29){
	        lsAY2k();
	      }elsif($i == 30){
	        lsLSnet();
	      }elsif($i == 31){
	        lsLSnetss();
	      }elsif($i == 32){
	        lsLSnett();
	      }elsif($i == 33){
	      	lsPVPonline();
	      }elsif($i == 34){
	        lsSciFiWire();
	      }elsif($i == 35){
	        lsTechReport();
	      }elsif($i == 36){
	        lsShellScape();
	      }elsif($i == 37){
	        lsFileClicks();
	      }elsif($i == 38){
	        lsPennyArcade();
	      }elsif($i == 39){
	        lsGeekNik();
	      }elsif($i == 40){
	        lsNewsCom();
	      }elsif($i == 41){
	        lsWiredNews();
	      }elsif($i == 42){
	        lsPMSnippets();
	      }elsif($i == 43){
	        lsPMCoolUses();
	      }elsif($i == 44){
	        lsPMPoetry();
	      }elsif($i == 45){
	        lsPMObfus();
	      }elsif($i == 46){
	        lsPMCraft();
	      }elsif($i == 47){
	        lsPMMed();
	      }elsif($i == 48){
	        lsMJnews();
	      }elsif($i == 49){
	        lsMJideas();
	      }elsif($i == 50){
	        lsMJsnips();
	      }elsif($i == 51){
	        lsTekReview();
	      }elsif($i == 52){
	        lsEBG();
	      }elsif($i == 53){
	        lsAICN();
	      }elsif($i == 54){
	        lsEPOCnews();
	      }elsif($i == 55){
	        lsSinFest();
	      }elsif($i == 56){
	        lsJoeAverage();
	      }elsif($i == 57){
	        lsAvalonHigh();
	      }elsif($i == 58){
	        lsHounds();
	      }elsif($i == 59){
	        lsGoats();
	      }elsif($i == 60){
	        lsFunnyFarm();
	      }elsif($i == 61){
	        lsBruno();
	      }elsif($i == 62){
	        lsNewsHounds();
	      }elsif($i == 63){
	        lsGPF();
	      }elsif($i == 64){
	        lsElfLife();
	      }elsif($i == 65){
	        lsCMPTR();
	      }elsif($i == 66){
	        lsPalmStation();
	      }elsif($i == 67){
	        lsPDABuzz();
	      }elsif($i == 68){
	        lsPalmInfoCenter();
	      }elsif($i == 69){
	        lsDaemonNews();
	      }elsif($i == 70){
	        lsIceWalkers();
	      }elsif($i == 71){
	        lsWonkoSlice();
	      }elsif($i == 72){
	        lsNeoFlux();
	      }elsif($i == 73){
	        lsDigitalTheatre();
	      }elsif($i == 74){
	        lsCastersRealm();
	      }elsif($i == 75){
	        lsEverLore();
	      }elsif($i == 76){
	        lsEQCorner();
	      }elsif($i == 77){
	        lsEQStratics();
	      }elsif($i == 78){
	        lsDVDAnimania();
	      }elsif($i == 79){
	        lsModulo();
	      }elsif($i == 80){
	        lsPureLS();
	      }elsif($i == 81){
	        lsNoNags();
	      }elsif($i == 82){
	        lsDesktopSource();
	      }elsif($i == 83){
	        lsAceHardware();
	      }elsif($i == 84){
	        lsPCStats();
	      }elsif($i == 85){
	        lsAnimeNewsService();
	      }elsif($i == 86){
	        lsEQlizer();
	      }elsif($i == 87){
	        lsShugaShack();
	      }elsif($i == 88){
	        lsFileWatcher();
	      }elsif($i == 89){
	        lsCore();
	      }elsif($i == 90){
	        lsWebMonkey();
	      }elsif($i == 91){
	        lsInfoWorld();
	      }elsif($i == 92){
	        lsLinuxPower();
	      }elsif($i == 93){
	        lsLWN();
	      }elsif($i == 94){
	        lsmkLinux();
	      }elsif($i == 95){
	        lsMonkeyFist();
	      }elsif($i == 96){
	        lsNewsForge();
	      }elsif($i == 97){
	        lsPacketStorm_New();
	      }elsif($i == 98){
	        lsPacketStorm_Adv();
	      }elsif($i == 99){
	        lsPacketStorm_Tool();
	      }elsif($i == 100){
	        lsPacketStorm_Expl();
	      }elsif($i == 101){
	        lsPacketStorm_Misc();
	      }elsif($i == 102){
	        lsThinkGeek();
	      }elsif($i == 103){
	        lsScreamingPenguin();
	      }elsif($i == 104){
	        lsSDN();
	      }elsif($i == 105){
	        lsFreakTech();
	      }elsif($i == 106){
	        lsLSDEV();
	      }elsif($i == 107){
	        lsLSD4P();
	      }elsif($i == 108){
	        lsDEJD();
	      }elsif($i == 109){
	        ls3DNEWS();
	      }elsif($i == 110){
	        lsAnandtech();
	      }elsif($i == 111){
	        lsCOLA();
	      }elsif($i == 112){
	        lsDailyRadar();
	      }elsif($i == 113){
	        lsDotComma();
	      }elsif($i == 114){
	        lsEET();
	      }elsif($i == 115){
	        lsEmuViews();
	      }elsif($i == 116){
	        lsSkinz();
	      }elsif($i == 117){
	        lsStreaming();
	      }elsif($i == 118){
	        lsFreeOS();
	      }elsif($i == 119){
	        lsFreeXML();
	      }elsif($i == 120){
	        lsAdvogato();
	      }elsif($i == 121){
	        lsBBSpot();
	      }elsif($i == 122){
	        lsEndEffect();
	      }elsif($i == 123){
	        lsJoyTech();
	      }elsif($i == 124){
	        lsSpace();
	      }elsif($i == 125){
	        lsCryptome();
	      }elsif($i == 126){
	        lsVirtualPlastic();
	      }elsif($i == 127){
	        lsBetaBites();
	      }elsif($i == 128){
	        lsKuro5hin();
	      }elsif($i == 129){
	        lsShouldExist();
	      }elsif($i == 130){
	        lsXentertainment();
	      }elsif($i == 131){
	        lsArsTechnica2();
	      }elsif($i == 132){
	        lsYogiNews();
	      }elsif($i == 133){
	        lsEllicit();
	      }elsif($i == 134){
	        lsGeekNewsNet();
	      }elsif($i == 135){
	        lsKDENews();
	      }elsif($i == 136){
	        lsLinuxCom();
	      }elsif($i == 137){
	        lsLinuxComJobs();
	      }elsif($i == 138){
	        lsLinuxComGram();
	      }elsif($i == 139){
	        lsLinuxNewbie();
	      }elsif($i == 140){
	        lsLinuxProgramming();
	      }elsif($i == 141){
	        lsLinuxTelephony();
	      }elsif($i == 142){
	        lsMerc();
	      }elsif($i == 143){
	        lsMrTech();
	      }elsif($i == 144){
	        lsMTO();
	      }elsif($i == 145){
	        lsNanoDot();
	      }elsif($i == 146){
	        lsPerlNews();
	      }elsif($i == 147){
	        lsPHPBuilderGen();
	      }elsif($i == 148){
	        lsPHPBuilderCode();
	      }elsif($i == 149){
	        lsPHPBuilderInstall();
	      }elsif($i == 150){
	        lsPHPBuilderWin();
	      }elsif($i == 151){
	        lsPHPBuilderDB();
	      }elsif($i == 152){
	        lsPHPBuilderArt();
	      }elsif($i == 153){
	        lsQ3Arena();
	      }elsif($i == 154){
	        lsRootPrompt();
	      }elsif($i == 155){
	        lsTechDirt();
	      }elsif($i == 156){
	        lsTheKult();
	      }elsif($i == 157){
	        lsToms();
	      }elsif($i == 158){
	        lsTweak3D();
	      }elsif($i == 159){
	        lsTweakTown();
	      }elsif($i == 160){
	        lsTweakFiles();
	      }elsif($i == 161){
	        lsTwoMobile();
	      }elsif($i == 162){
	        lsInfolets();
	      }elsif($i == 163){
	        lsFileFlash();
	      }
     }	      
  }
}elsif($style == 1){
  for($a = 0; $a < (@order); $a++){
    $x = $order[$a];
    if($x eq "slashdot"){lsVodka();}
    if($x eq "freshmeat"){lsWhiskey();}
    if($x eq "segfault"){lsRum();}
    if($x eq " linuxtoday"){lsGin();}  
    if($x eq "desktopian"){lsHotDamn();}  
    if($x eq "technotronic"){lsBeer();}
    if($x eq "betanews"){lsAfterShock();}  
    if($x eq "arstechnica"){lsButterScotch();}  
    if($x eq "floach"){lsScotch();}  
    if($x eq "benews"){lsMartini();}
    if($x eq "themesorg"){lsMalibu();}
    if($x eq "solariscentral"){lsSouthernComfort();}
    if($x eq "linuxgames"){lsLG();}
    if($x eq "linuxapps"){lsLA();}
    if($x eq "atstake"){lsAS();}
    if($x eq "happypenguinnews"){lsHPN();}
    if($x eq "happypenguinupdates"){lsHPU();}
    if($x eq "happypenguinadd"){lsHPA();}
    if($x eq "linuxquake"){lsLQ();}
    if($x eq "absolutegamers"){lsAGF();}
    if($x eq "linux3d"){lsL3D();}
    if($x eq "bluesnews"){lsBLN();}
    if($x eq "voodooextreme"){lsVE();}
    if($x eq "python"){lsPO();}
    if($x eq "userfriendly"){lsUF();}
    if($x eq "apod"){lsAPOD();}
    if($x eq "fileforum"){lsff();}
    if($x eq "dilbert"){lsDil();}
    if($x eq "shellcity"){lsSCity();}
    if($x eq "aftery2k"){lsAY2k();}
    if($x eq "litestepnet"){lsLSnet();}
    if($x eq "litestepnetss"){lsLSnetss();}
    if($x eq "litestepnett"){lsLSnett();}
    if($x eq "pvponline"){lsPVPonline();}
    if($x eq "scifiwire"){lsSciFiWire();}
    if($x eq "techreport"){lsTechReport();}
    if($x eq "shellscape"){lsShellScape();}
    if($x eq "fileclicks"){lsFileClicks();}
    if($x eq "pennyarcade"){lsPennyArcade();}
    if($x eq "geeknik"){lsGeekNik();}
    if($x eq "newscom"){lsNewsCom();}
    if($x eq "wirednews"){lsWiredNews();}
    if($x eq "pmsnippets"){lsPMSnippets();}
    if($x eq "pmcooluses"){lsPMCoolUses();}
    if($x eq "pmpoetry"){lsPMPoetry();}
    if($x eq "pmobfus"){lsPMObfus();}
    if($x eq "pmcraft"){lsPMCraft();}
    if($x eq "pmmed"){lsPMMed();}
    if($x eq "mjnews"){lsMJnews();}
    if($x eq "mjideas"){lsMJideas();}
    if($x eq "mjsnips"){lsMJsnips();}
    if($x eq "tekreview"){lsTekReview();}
    if($x eq "ebg"){lsEBG();}
    if($x eq "aicn"){lsAICN();}
    if($x eq "epocnews"){lsEPOCnews();}
    if($x eq "sinfest"){lsSinFest();}
    if($x eq "joeaverage"){lsJoeAverage();}
    if($x eq "avalonhigh"){lsAvalonHigh();}
    if($x eq "hounds"){lsHounds();}
    if($x eq "goats"){lsGoats();}
    if($x eq "funnyfarm"){lsFunnyFarm();}
    if($x eq "bruno"){lsBruno();}
    if($x eq "newshounds"){lsNewsHounds();}
    if($x eq "gpf"){lsGPF();}
    if($x eq "elflife"){lsElfLife();}
    if($x eq "cmptr"){lsCMPTR();}
    if($x eq "palmstation"){lsPalmStation();}
    if($x eq "pdabuzz"){lsPDABuzz();}
    if($x eq "palminfocenter"){lsPalmInfoCenter();}
    if($x eq "daemonnews"){lsDaemonNews();}
    if($x eq "icewalkers"){lsIceWalkers();}
    if($x eq "wonkoslice"){lsWonkoSlice();}
    if($x eq "neoflux"){lsNeoFlux();}
    if($x eq "digitaltheatre"){lsDigitalTheatre();}
    if($x eq "castersrealm"){lsCastersRealm();}
    if($x eq "everlore"){lsEverLore();}
    if($x eq "eqcorner"){lsEQCorner();}
    if($x eq "eqstratics"){lsEQStratics();}
    if($x eq "dvdanimania"){lsDVDAnimania();}
    if($x eq "modulo"){lsModulo();}
    if($x eq "purels"){lsPureLS();}
    if($x eq "nonags"){lsNoNags();}
    if($x eq "desktopdource"){lsDesktopSource();}
    if($x eq "acehardware"){lsAceHardware();}
    if($x eq "pcstats"){lsPCStats();}
    if($x eq "animenewsservice"){lsAnimeNewsService();}
    if($x eq "eqlizer"){lsEQlizer();}
    if($x eq "shugashack"){lsShugaShack();}
    if($x eq "filewatcher"){lsFileWatcher();}
    if($x eq "core"){lsCore();}
    if($x eq "webmonkey"){lsWebMonkey();}
    if($x eq "infoworld"){lsInfoWorld();}
    if($x eq "linuxpower"){lsLinuxPower();}
    if($x eq "lwn"){lsLWN();}
    if($x eq "mklinux"){lsmkLinux();}
    if($x eq "monkeyfist"){lsMonkeyFist();}    
    if($x eq "newsforge"){lsNewsForge();}    
    if($x eq "packetstorm_new"){lsPacketStorm_New();}    
    if($x eq "packetstorm_adv"){lsPacketStorm_Adv();}
    if($x eq "packetstorm_tool"){lsPacketStorm_Tool();}
    if($x eq "packetstorm_expl"){lsPacketStorm_Expl();}
    if($x eq "packetstorm_misc"){lsPacketStorm_Misc();}
    if($x eq "thinkgeek"){lsThinkGeek();}
    if($x eq "screamingpenguin"){lsScreamingPenguin();}
    if($x eq "sdn"){lsSDN();}    
    if($x eq "freaktech"){lsFreakTech();}    
    if($x eq "lsdev"){lsLSDEV();}
    if($x eq "lsd4p"){lsLSD4P();}
    if($x eq "dejd"){lsDEJD();}
    if($x eq "dnews"){ls3DNEWS();}
    if($x eq "anandtech"){lsAnandtech();}
    if($x eq "cola"){lsCOLA();}       
    if($x eq "dailyradar"){lsDailyRadar();}       
    if($x eq "dotcomma"){lsDotComma();}       
    if($x eq "eet"){lsEET();}
    if($x eq "emuviews"){lsEmuViews();}
    if($x eq "skinz"){lsSkinz();}
    if($x eq "streaming"){lsStreaming();}
    if($x eq "freeos"){lsFreeOS();}
    if($x eq "gasource"){lsGASource();}
    if($x eq "freexml"){lsFreeXML();}
    if($x eq "advogato"){lsAdvogato();}
    if($x eq "bbspot"){lsBBSpot();}
    if($x eq "endeffect"){lsEndEffect();}
    if($x eq "joytech"){lsJoyTech();}
    if($x eq "space"){lsSpace();}
    if($x eq "cryptome"){lsCryptome();}
    if($x eq "virtualplastic"){lsVirtualPlastic();}
    if($x eq "betabites"){lsBetaBites();}
    if($x eq "kuro5hin"){lsKuro5hin();}
    if($x eq "shouldexist"){lsShouldExist();}
    if($x eq "xentertainment"){lsXentertainment();}    
    if($x eq "arstechnica2"){lsArsTechnica2();}    
    if($x eq "yoginews"){lsYogiNews();}    
    if($x eq "ellicit"){lsEllicit();}
    if($x eq "geeknewsnet"){lsGeekNewsNet();}
    if($x eq "kdenews"){lsKDENews();}
    if($x eq "linuxcom"){lsLinuxCom();}
    if($x eq "linuxcomjobs"){lsLinuxComJobs();}
    if($x eq "linuxcomgram"){lsLinuxComGram();}
    if($x eq "linuxnewbie"){lsLinuxNewbie();}
    if($x eq "linuxprogramming"){lsLinuxProgramming();}
    if($x eq "linuxtelephony"){lsLinuxTelephony();}
    if($x eq "merc"){lsMerc();}
    if($x eq "mrtech"){lsMrTech();}
    if($x eq "mto"){lsMTO();}
    if($x eq "nanodot"){lsNanoDot();}
    if($x eq "perlnews"){lsPerlNews();}
    if($x eq "phpbuildergen"){lsPHPBuilderGen();}
    if($x eq "phpbuildercode"){lsPHPBuilderCode();}
    if($x eq "phpbuilderinstall"){lsPHPBuilderInstall();}
    if($x eq "phpbuilderwin"){lsPHPBuilderWin();}
    if($x eq "phpbuilderdb"){lsPHPBuilderDB();}
    if($x eq "phpbuilderart"){lsPHPBuilderArt();}
    if($x eq "q3arena"){lsQ3Arena();}
    if($x eq "rootprompt"){lsRootPrompt();}
    if($x eq "techdirt"){lsTechdirt();}
    if($x eq "thekult"){lsTheKult();}
    if($x eq "toms"){lsToms();}
    if($x eq "tweak3d"){lsTweak3D();}
    if($x eq "tweaktown"){lsTweakTown();}
    if($x eq "tweakfiles"){lsTweakFiles();}
    if($x eq "twomobile"){lsTwoMobile();}
    if($x eq "infolets"){lsInfolets();}
    if($x eq "fileflash"){lsFileFlash();}
  }
}
         

if ($pageval == 1){
	footer();
}

#############################################################################
# lsVodka section Slashdot
sub lsVodka {	
  if($feedback == 1) {	
    print "Getting Slashdot headlines.\n";
  }
  $header1 = "Slashdot";
  $header2 = "slashdot.org";
  $remote = "Slashdot.org";
  $file   = "slashdot.rdf";
  $backend= "backend.slashdot";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $slashdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;    	
}
#
#############################################################################

#############################################################################
# lsWhiskey section freshmeat
sub lsWhiskey {
  if($feedback == 1) {	
    print "Getting Freshmeat headlines.\n";
  }
  $header1 = "Freshmeat";
  $header2 = "freshmeat.net";
  $remote = "Freshmeat.net";
  $file   = "backend/fm.rdf";
  $backend= "backend.freshmeat";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsRum section Segfault
sub lsRum {
  if($feedback == 1) {	
    print "Getting Segfault news.\n";
  }
  $header1 = "Segfault";
  $header2 = "segfault.org";
  $remote = "segfault.org";
  $file   = "stories.txt HTTP/1.1\nHost: segfault.org:80";
  $backend= "backend.segfault";
  getbackend();
  $fromtop = 20;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 7;
  $dir = $segdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsGin section LinuxToday
sub lsGin {
  if($feedback == 1) {	
    print "Getting Linux Today headlines.\n";
  }
  $header1 = "LinuxToday";
  $header2 = "linuxtoday.com";
  $remote = "63.236.72.248";
  $file   = "lthead.txt   HTTP/1.1\nHost: linuxtoday.com:80";
  $backend= "backend.linuxtoday";
  getbackend();
  $fromtop = 13;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $ltdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsHotDamn section Desktopian
sub lsHotDamn {
  if($feedback == 1) {	
    print "Getting Desktopian News.\n";
  }      
  $header1 = "Desktopian";
  $header2 = "www.desktopian.org";
  $remote = "www.desktopian.org";
  $file   = "/includes/recentnews.txt";
  $backend= "backend.desktopian";
  getbackend();
  $fromtop = 1;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $dtdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsBeer section Technotronic
sub lsBeer {
  if($feedback == 1) {	
    print "Getting Technotronic News.\n";
  }	      
  $header1 = "Technotronic";
  $header2 = "www.technotronic.com";
  $remote = "www.technotronic.com";
  $file   = "backend/headlines.txt HTTP/1.1\nHost: www.technotronic.com:80";
  $backend= "backend.technotronic";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $ttdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsAfterShock section betanewsnews
sub lsAfterShock {
  if($feedback == 1) {
    print "Getting BetaNews.\n";
  }	
  $header1 = "Betanews";
  $header2 = "www.betanews.com";
  $remote = "www.betanews.com";
  $file   = "backend.php3 HTTP/1.1\nHost: www.betanews.com:80";
  $backend= "backend.betanews";
  getbackend();
  $fromtop = 9;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $bndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsButterScotch section arsTechnica
sub lsButterScotch {
  if($feedback == 1) {	
    print "Getting Ars Technica headlines.\n";
  }
  $header1 = "arsTechnica";
  $header2 = "arstechnica.com";
  $remote = "arstechnica.com";
  $file   = "heads.txt";
  $backend= "backend.ars";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $atdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsScotch Floach
sub lsScotch {
  if($feedback == 1) {	
    print "Getting Floach headlines. \n";
  }	
  $header1 = "Floach";
  $header2 = "floach.pimpin.net";
  $remote = "floach.pimpin.net";
  $file = " HTTP/1.1\nHost: floach.pimpin.net:80";
  $backend= "backend.floach";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsMartini BeNews
sub lsMartini {
  if($feedback == 1) {	
    print "Getting BeNews. \n";
  }	
  $header1 = "BeNews";
  $header2 = "www.benews.com";
  $remote = "www.benews.com";
  $file   = "/story/headlines/10 HTTP/1.1\nHost: www.benews.com:80\n";
  $backend= "backend.ben";
  getbackend();
  $fromtop = 9;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $bendir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsMalibu Themes.Org
sub lsMalibu {
  if($feedback == 1) {	
    print "Getting Themes.Org. \n";
  }
  $header1 = "Themes.org";
  $header2 = "www.themes.org";
  $remote = "www.themes.org";
  $file   = "news.rdf.phtml HTTP/1.1\nHost: www.themes.org:80";
  $backend= "backend.tho";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 9;
  $dir = $thodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsSouthernComfort  Solaris Central
sub lsSouthernComfort {
  if($feedback == 1) {	
    print "Getting Solaris Central News. \n";
  }
  $header1 = "Solaris Central";
  $header2 = "www.solariscentral.org";
  $remote = "www.solariscentral.org";
  $file   = "news/ultramode.txt HTTP/1.1\nHost: www.solariscentral.org:80";
  $backend= "backend.sc";
  getbackend();
  $fromtop = 15;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $scdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux Games
sub lsLG {
  if($feedback == 1) {
    print "Getting LinuxGames.com News. \n";
  }
  $remote = "www.linuxgames.com";
  $header1 = "Linux Games";
  $header2 = "www.linuxgames.com";
  $file   = "index.php3  HTTP/1.1\nHost: www.linuxgames.com:80";
  $backend= "backend.lg";
  $pattern = "<A NAME=\"AUTONUMBER\"><\/A>";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $lgdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsLA section Linux Apps
sub lsLA {
  if($feedback == 1) {	
    print "Getting LinuxApps.com.  \n";
  }
  $header1 = "Linux Apps";
  $header2 = "www.linuxapps.com";
  $remote = "www.linuxapps.com";
  $file   = "backend/detailed.txt HTTP/1.1\nHost: www.linuxapps.com:80";
  $backend= "backend.la";
  getbackend();
  $fromtop = 9;
  $topicline = 2;
  $linkline = 8;
  $blocklength = 9;
  $dir = $ladir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# lsAS section At Stake
sub lsAS {
  if($feedback == 1) {	
    print "Getting \@Stake News.  \n";
  }
  $header1 = "\@Stake";
  $header2 = "www.atstake.com/security_news/index.html";
  $remote = "www.atstake.com";
  $file   = "security_news/index.html";
  $backend= "backend.stake";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength =3;
  $dir = $asdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happypenguin Org News
sub lsHPN {
  if($feedback == 1) {	
    print "Getting Happy Penguin News. \n";
  }
  $header1 = "Happy Penguin News";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/news.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpn";
  $pattern = "Content-Type: text/plain";
  $x = 0;
  getbackend();
  fixbackend();
  $fromtop = 8;
  $topicline = 2;
  $linkline = 4;
  $blocklength = 4;
  $dir = $hpndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happy Penguin Updates
sub lsHPU {
  if($feedback == 1) {	
    print "Getting Happy Penguin Updates. \n";
  }      
  $header1 = "Happy Penquin Updates";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/updates.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpu";
  getbackend();
  fixbackend();
  $fromtop = 36;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 4;
  $dir = $hpudir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Happy Penguin Adds
sub lsHPA {
  if($feedback == 1) {	
    print "Getting Happy Penguin Additions. \n";
  }
  $header1 = "Happy Penguin Adds";
  $header2 = "happypenguin.org";
  $remote = "happypenguin.org";
  $file   = "html/additions.txt HTTP/1.1\nHost: happypenguin.org:80";
  $backend= "backend.hpa";
  getbackend();
  fixbackend();
  $fromtop = 36;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 4;
  $dir = $hpadir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux Quake
sub lsLQ {
  if($feedback == 1) {	
    print "Getting Linux Quake News. \n";
   }
   $remote = "linuxquake.com";
   $header1 = "LinuxQuake";
   $header2 = "linuxquake.com";
   $file   = "";
   $backend= "backend.lq";
   getbackend();
   fixbackend();
   $fromtop = 0;
   $topicline = 2;
   $linkline = 3;
   $blocklength = 3;
   $dir = $lqdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# Absolute Gamers
sub lsAGF {
  if($feedback == 1) {	 
    print "Getting Absolute Gamers Files. \n";
  }
  $header1 = "Absolute Gamers";
  $header2 = "files.gameaholic.com";
  $remote = "files.gameaholic.com";
  $file   = "agfa.rdf HTTP/1.1\nHost: files.gameaholic.com:80";
  $backend= "backend.ag";
  getbackend();
  fixbackend();
  $fromtop = 4;
  $topicline = 1;
  $linkline = 2;
  $blocklength = 2;
  $dir = $agdir;
  addfolder();
  if($pageval == 1){
     tabletitle();
     tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# Linux 3d
sub lsL3D {
  if($feedback == 1) {	
    print "Getting Linux3D News. \n";
  }
  $header1 = "Linux 3d";
  $header2 = "www.linux3d.net";
  $remote = "www.linux3d.net";
  $file   = "index.shtml";
  $backend= "backend.l3d";
  $pattern = "<p><strong><font face=\"Arial,Helvetica\" size=\"3\" color=\"#003399\"><a name=\".*?\">";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $l3ddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsBLN {
  if($feedback == 1) {	
    print "Getting BluesNews. \n";
  }
  $header1 = "BluesNews";
  $header2 = "www.bluesnews.com";
  $remote = "www.bluesnews.com";
  $file = "/cgi-bin/blammo.pl?mode=headlines";
  $backend= "backend.bln";
  $pattern = "HREF=\"http:\/\/www.bluesnews.com\/cgi-bin\/blammo.pl?display=";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $blndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsVE {
  if($feedback == 1) {	
    print "Getting VodooExtreme. \n";
  }
  $header1 = "VooDoo Extreme";
  $header2 = "www.voodooextreme.com";
  $remote = "www.voodooextreme.com";
  $file   = " HTTP/1.1\nHost: www.voodooextreme.com:80";
  $backend= "backend.ve";
  $pattern = "<p><span class=\"headline\"><A NAME=\".*?\">";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $vedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsPO {
  if($feedback == 1) {	
    print "Getting Python.org. \n";
  }
  $header1 = "Python";
  $header2 = "www.python.org";
  $remote = "www.python.org";
  $file   = "channews.rdf";
  $backend= "backend.po";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $podir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsUF {
   if($feedback == 1) {	
     print "Getting Userfriendly. \n";
   }
   $header1 = "UserFriendly";
   $header2 = "www.userfriendly.org";
   $remote = "www.userfriendly.org";
   $file   = "static/index.html";
   $backend= "backend.uf";
   getbackend();
   fixbackend();
   $dir = $ufdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsAPOD {
  if($feedback == 1) {	
    print "Getting Astronomy Picture of the Day. \n";
  }
  $header1 = "Astronomy Picture of the Day";
  $header2 = "antwrp.gsfc.nasa.gov/apod/ap.html";
  $remote = "antwrp.gsfc.nasa.gov";
  $file   = "apod/ap.html";
  $backend= "backend.apod";
  getbackend();
  fixbackend();
  $dir = $apoddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsff {
  if($feedback == 1) {	
    print "Getting FileForum. \n";
   }
   $header1 = "File Forum";
   $header2 = "fileforum.efront.com";
   $remote = "fileforum.efront.com";
   $file   = "backend.php3 HTTP/1.1\nHost: fileforum.efront.com:80";
   $backend= "backend.fileforum";
   getbackend();
   $fromtop = 9;
   $topicline = 1;
   $linkline = 5;
   $blocklength = 5;
   $dir = $fileforumdir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsDil {
  if($feedback == 1) {	
    print "Getting Dilbert. \n";
  }
  $header1 = "Dilbert";
  $header2 = "www.unitedmedia.com/comics/dilbert/index.html";
  $remote = "www.unitedmedia.com";
  $file   = "comics/dilbert/index.html";
  $backend= "backend.dilbert";
  getbackend();
  fixbackend();
  $dir = $dilbertdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSCity {
  if($feedback == 1) {	
    print "Getting ShellCity. \n";
  }
  $header1 = "Shell City";
  $header2 = "www.shellcity.net";
  $remote = "www.shellcity.net";
  $file   = "citynews.xml HTTP/1.1\nHost: www.shellcity.net:80";
  $backend= "backend.shellcity";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $podir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAY2k {
  if($feedback == 1){
    print "Getting After Y2k. \n";
  }
  $header1 = "After Y2K";
  $header2 = "www.geekculture.com/geekycomics/Aftery2k/aftery2kmain.html";
  $remote = "www.geekculture.com";
  $file   = "geekycomics/Aftery2k/aftery2kmain.html";
  $backend= "backend.ay2k";
  getbackend();
  fixbackend();
  $dir = $aftery2kdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLSnet {
  if($feedback == 1){
    print "Getting Litestep.Net. \n";
  }
  $header1 = "LiteStep.Net News";
  $header2 = "www.litestep.net";
  $remote = "www.litestep.net";
  $file   = "index.php3?ls_session=f6c817a19f349dd4a711f8210a297b1f HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnet";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnetdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsLSnetss {
  if($feedback == 1){
    print "Getting Litestep.Net Screen Shots. \n";
  }
  $header1 = "LiteStep.Net Screen Shots";
  $header2 = "www.litestep.net/sshots.php3";
  $remote = "www.litestep.net";
  $file   = "sshots.php3?ls_session=ee8dc49ae942a7127d6a65bd3d2bfd91 HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnetss";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnetssdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsLSnett {
  if($feedback == 1){
    print "Getting Litestep.Net Themes. \n";
  }
  $header1 = "LiteStep.Net Themes";
  $header2 = "www.litestep.net/themes.php3";
  $remote = "www.litestep.net";
  $file   = "themes.php3?ls_session=ee8dc49ae942a7127d6a65bd3d2bfd91 HTTP/1.1\nHost: www.litestep.net:80";
  $backend= "backend.lsLSnett";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $litestepnettdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPVPonline {
   if($feedback == 1) {	
     print "Getting PVPonline. \n";
   }
   $header1 = "PVPonline";
   $header2 = "www.pvponline.com";
   $remote = "www.pvponline.com";
   $file   = "index.php3 HTTP/1.1\nHost: www.pvponline.com:80";
   $backend= "backend.pvponline";
   getbackend();
   fixbackend();
   $dir = $pvponlinedir;
   addfolder();
   if($pageval == 1){
     tabletitle();
     tablerow();
   }
   return;
}
#
#############################################################################

#############################################################################
# 
sub lsSciFiWire {
  if($feedback == 1){
    print "Getting SciFi Wire. \n";
  }
  $header1 = "SciFi Wire";
  $header2 = "www.scifi.com/scifiwire";
  $remote = "www.scifi.com";
  $file   = "scifiwire/index.html HTTP/1.1\nHost: www.scifi.com:80";
  $backend= "backend.scifiwire";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $scifiwiredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTechReport {
  if($feedback == 1){
    print "Getting Tech Report News. \n";
  }
  $header1 = "Tech Report";
  $header2 = "www.tech-report.com";
  $remote = "www.tech-report.com";
  $file   = "";
  $backend= "backend.techreport";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $techreportdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsShellScape {
  if($feedback == 1){
    print "Getting ShellScape news. \n";
  }
  $header1 = "ShellScape News";
  $header2 = "www.shellscape.org";
  $remote = "www.shellscape.org";
  $file   = "dariusX/index.php3";
  $backend= "backend.shellscape";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $shellscapedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsFileClicks {
  if($feedback == 1){
    print "Getting FileClicks. \n";
  }
  $header1 = "FileClicks";
  $header2 = "www.fileclicks.com";
  $remote = "www.fileclicks.com";
  $file   = "index2.phtml HTTP/1.1\nHost: www.fileclicks.com:80";
  $backend= "backend.fileclicks";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $fileclicksdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPennyArcade {
  if($feedback == 1){
    print "Getting PennyArcade. \n";
  }
  $header1 = "PennyArcade";
  $header2 = "www.penny-arcade.com";
  $remote = "www.penny-arcade.com";
  $file   = "view.php3 HTTP/1.1\nHost: www.penny-arcade.com:80";
  $backend= "backend.pennyarcade";
  getbackend();
  fixbackend();
  $dir = $pennyarcadedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGeekNik {
  if($feedback == 1){
    print "Getting GeekNik. \n";
  }
  $header1 = "Geeknik";
  $header2 = "www.geeknik.net";
  $remote = "www.geeknik.net";
  $file   = " HTTP/1.1\nHost: www.geeknik.net:80";
  $backend= "backend.geeknik";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $geeknikdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#

#############################################################################

#############################################################################
# 
sub lsNewsCom {
  if($feedback == 1){
    print "Getting News.Com. \n";
  }
  $header1 = "News.Com";
  $header2 = "news.cnet.com";
  $remote = "news.cnet.com";
  $file   = " HTTP/1.1\nHost: news.cnet.com:80";
  $backend= "backend.newscom";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $newscomdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsWiredNews {
  if($feedback == 1){
    print "Getting Wired News. \n";
  }
  $header1 = "Wired";
  $header2 = "www.wired.com";
  $remote = "www.wired.com";
  $file   = "news_drop/palmpilot/topstories/0,1326,,00.html HTTP/1.1\nHost: www.wired.com:80";
  $backend= "backend.wired";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $newscomdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMSnippets {
  if($feedback == 1){
    print "Getting Perl Monks Snippets. \n";
  }
  $header1 = "Perl Monks Snippets";
  $header2 = "www.perlmonks.org/index.pl?node=Snippets%20Section";
  #$remote = "www.perlmonks.org";
  $remote = "206.170.14.76";
  $file   = "index.pl?node=Snippets%20Section HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmsnippets";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmsnippetsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMCoolUses {
  if($feedback == 1){
    print "Getting Perl Monks Cool Uses. \n";
  }
  $header1 = "Perl Monks Cool Uses of Perl";
  $header2 = "www.perlmonks.org/index.pl?node=Cool%20Uses%20for%20Perl";
  #$remote = "www.perlmonks.org";
  $remote = "206.170.14.76";
  $file   = "index.pl?node=Cool%20Uses%20for%20Perl HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmcooluses";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmcoolusesdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMPoetry {
  if($feedback == 1){
    print "Getting Perl Monks Poetry. \n";
  }
  $header1 = "Perl Monks Poetry";
  $header2 = "www.perlmonks.org/index.pl?node=Perl%20Poetry";
  #$remote = "www.perlmonks.org";
  $remote = "206.170.14.76";
  $file   = "index.pl?node=Perl%20Poetry HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmpoetry";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmpoetrydir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMObfus {
  if($feedback == 1){
    print "Getting Perl Monks Obfuscation. \n";
  }
  $header1 = "Perl Monks Obfuscation";
  $header2 = "www.perlmonks.org/index.pl?node=Obfuscated%20Code";
  #$remote = "www.perlmonks.org";
  $remote = "206.170.14.76";
  $file   = "index.pl?node=Obfuscated%20Code HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmobfus";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmobfusdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMCraft {
  if($feedback == 1){
    print "Getting Perl Monks Craft. \n";
  }
  $header1 = "Perl Monks Craft";
  $header2 = "www.perlmonks.org/index.pl?node=Craft";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Craft HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmcraft";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmcraftdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPMMed {
  if($feedback == 1){
    print "Getting Perl Monks Meditations. \n";
  }
  $header1 = "Perl Monks Meditations";
  $header2 = "www.perlmonks.org/index.pl?node=Meditations";
  $remote = "www.perlmonks.org";
  $file   = "index.pl?node=Meditations HTTP/1.1\nHost: www.perlmonks.org:80";
  $backend= "backend.pmmed";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pmmeddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJnews {
  if($feedback == 1){
    print "Getting Mind Junction News. \n";
  }
  $header1 = "Mind Junction News";
  $header2 = "www.mindjunction.com";
  $remote = "www.mindjunction.com";
  $file   = " HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJideas {
  if($feedback == 1){
    print "Getting Mind Junction Ideas. \n";
  }
  $header1 = "Mind Junction Ideas";
  $header2 = "www.mindjunction.com\/ideas.php3";
  $remote = "www.mindjunction.com";
  $file   = " HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjideas";
  $pattern1 = "index";
  $pattern2 = "ideas";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjideasdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMJsnips {
  if($feedback == 1){
    print "Getting Mind CodeSnips. \n";
  }
  $header1 = "Mind Junction Code Snips";
  $header2 = "www.mindjunction.com\/snips.php3";
  $remote = "www.mindjunction.com";
  $file   = "snips.php3 HTTP/1.1\nHost: www.mindjunction.com:80";
  $backend= "backend.mjsnip";
  $pattern1 = "snips";
  $pattern2 = "Snip";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mjsnipsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsTekReview {
  if($feedback == 1){
    print "Getting TekReview. \n";
  }
  $header1 = "TekReview";
  $header2 = "www.tekreview.com";
  $remote = "www.tekreview.com";
  $file   = "main.shtml HTTP/1.1\nHost: www.tekreview.com:80";
  $backend= "backend.tekreview";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tekreviewdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsEBG {
  if($feedback == 1){
    print "Getting Everything But Gaming. \n";
  }
  $header1 = "Everything But Gaming";
  $header2 = "www.shlonglor.com";
  $remote = "www.shlonglor.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.shlonglor.com:80";
  $backend= "backend.ebg";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $ebgdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAICN {
  if($feedback == 1){
    print "Getting Aint It Cool News. \n";
  }
  $header1 = "Aint It Cool News";
  $header2 = "www.aint-it-cool-news.com";
  $remote = "www.aint-it-cool-news.com";
  $file   = "index.html";
  $backend= "backend.aicn";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $aicndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEPOCnews {
  if($feedback == 1){
    print "Getting EPOC News. \n";
  }
  $header1 = "EPOC News";
  $header2 = "www.epocnews.com";
  $remote = "www.epocnews.com";
  $file   = "index.php3?days=  HTTP/1.1\nHost: www.epocnews.com:80";
  $backend= "backend.epocnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $epocnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSinFest {
  if($feedback == 1){
    print "Getting Sinfest Comic. \n";
  }
  $header1 = "Sinfest Daily Comic";
  $header2 = "sinfest.net";
  $remote = "sinfest.net";
  $file   = " HTTP/1.1\nHost: sinfest.net:80";
  $backend= "backend.sinfest";
  getbackend();
  fixbackend();
  $dir = $sinfestdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsJoeAverage {
  if($feedback == 1){
    print "Getting Joe Average Comic. \n";
  }
  $header1 = "Joe Average Daily Comic";
  $header2 = "www.joeaverage.org";
  $remote = "www.joeaverage.org";
  $file   = "index.html HTTP/1.1\nHost: www.joeaverage.org:80";
  $backend= "backend.joeaverage";
  getbackend();
  fixbackend();
  $dir = $joeaveragedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAvalonHigh {
  if($feedback == 1){
    print "Getting Avalon High Comic. \n";
  }
  $header1 = "Avalon High Daily Comic";
  $header2 = "www.avalonhigh.com";
  $remote = "www.avalonhigh.com";
  $file   = "index.html HTTP/1.1\nHost: www.avalonhigh.com:80";
  $backend= "backend.avalonhigh";
  getbackend();
  fixbackend();
  $dir = $avalonhighdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsHounds {
  if($feedback == 1){
    print "Getting Hounds Home Comic. \n";
  }
  $header1 = "Hounds Home Daily Comic";
  $header2 = "www.houndshome.com";
  $remote = "www.houndshome.com";
  $file   = "index.html HTTP/1.1\nHost: www.houndshome.com:80";
  $backend= "backend.hounds";
  getbackend();
  fixbackend();
  $dir = $houndsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGoats {
  if($feedback == 1){
    print "Getting Goats Comic. \n";
  }
  $header1 = "Goats Daily Comic";
  $header2 = "www.goats.com";
  $remote = "www.goats.com";
  $file   = "index.html";
  $backend= "backend.goats";
  getbackend();
  fixbackend();
  $dir = $goatsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsFunnyFarm {
  if($feedback == 1){
    print "Getting Funny Farm Comic. \n";
  }
  $header1 = "Funny Farm Daily Comic";
  $header2 = "www.funnyfarmcomics.com";
  $remote = "www.funnyfarmcomics.com";
  $file   = "index.html HTTP/1.1\nHost: www.funnyfarmcomics.com:80";
  $backend= "backend.funnyfarm";
  getbackend();
  fixbackend();
  $dir = $funnyfarmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsBruno {
  if($feedback == 1){
    print "Getting Bruno The Bandit Comic. \n";
  }
  $header1 = "Bruno The Bandit Daily Comic";
  $header2 = "www.brunothebandit.com";
  $remote = "www.brunothebandit.com";
  $file   = "index.html HTTP/1.1\nHost: www.brunothebandit.com:80";
  $backend= "backend.bruno";
  getbackend();
  fixbackend();
  $dir = $brunodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNewsHounds {
  if($feedback == 1){
    print "Getting News Hounds Comic. \n";
  }
  $header1 = "News Hounds Daily Comic";
  $header2 = "www.newshounds.com";
  $remote = "www.newshounds.com";
  $file   = "index.html HTTP/1.1\nHost: www.newshounds.com:80";
  $backend= "backend.newshounds";
  getbackend();
  fixbackend();
  $dir = $newshoundsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsGPF {
  if($feedback == 1){
    print "Getting GPF Comic. \n";
  }
  $header1 = "GPF Daily Comic";
  $header2 = "www.gpf-comics.com";
  $remote = "www.gpf-comics.com";
  $file   = "index.html HTTP/1.1\nHost: www.gpf-comics.com:80";
  $backend= "backend.gpf";
  getbackend();
  fixbackend();
  $dir = $gpfdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsElfLife {
  if($feedback == 1){
    print "Getting Elf Life Comic. \n";
  }
  $header1 = "Elf Life Daily Comic";
  $header2 = "www.elflife.com";
  $remote = "www.elflife.com";
  $file   = "index.html HTTP/1.1\nHost: www.elflife.com:80";
  $backend= "backend.elflife";
  getbackend();
  fixbackend();
  $dir = $elflifedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCMPTR {
  if($feedback == 1){
    print "Getting CMPTR News. \n";
  }
  $header1 = "CMPTR News";
  $header2 = "www.cmptr.com";
  $remote = "www.cmptr.com";
  $file   = "dump/fontframe.txt";
  $backend= "backend.cmptr";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $cmptrdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPalmStation {
  if($feedback == 1){
    print "Getting PalmStation News. \n";
  }
  $header1 = "PalmStation News";
  $header2 = "www.palmstation.com";
  $remote = "www.palmstation.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.palmstation.com:80";
  $backend= "backend.palmstation";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $palmstationdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPDABuzz {
  if($feedback == 1){
    print "Getting PDABuzz News. \n";
  }
  $header1 = "PDABuzz News";
  $header2 = "www.pdabuzz.com";
  $remote = "www.pdabuzz.com";
  $file   = "index.html";
  $backend= "backend.pdabuzz";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pdabuzzdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPalmInfoCenter {
  if($feedback == 1){
    print "Getting Palm Infocenter News. \n";
  }
  $header1 = "Palm Infocenter News";
  $header2 = "www.palminfocenter.com";
  $remote = "www.palminfocenter.com";
  $file   = "index.asp";
  $backend= "backend.palminfocenter";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $palminfocenterdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsDaemonNews {
  if($feedback == 1){
    print "Getting Daemon News. \n";
  }
  $header1 = "Deamon News";
  $header2 = "daily.daemonnews.org";
  $remote = "daily.daemonnews.org";
  $file   = "index.php3 HTTP/1.1\nHost: daily.daemonnews.org:80";
  $backend= "backend.daemonnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $daemonnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsIceWalkers {
  if($feedback == 1){
    print "Getting IceWalkers Files. \n";
  }
  $header1 = "IceWalkers";
  $header2 = "www.icewalkers.com";
  $remote = "www.icewalkers.com";
  $file   = "backend/lastheaders.txt";
  $backend= "backend.icewalkers";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $daemonnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsWonkoSlice {
  if($feedback == 1){
    print "Getting WonkoSlice News. \n";
  }
  $header1 = "WonkoSlice News";
  $header2 = "wonko.com";
  $remote = "wonko.com";
  $file   = "backend.php";
  $backend= "backend.wonkoslice";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $wonkoslicedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNeoFlux {
  if($feedback == 1){
    print "Getting Neoflux News. \n";
  }
  $header1 = "NeoFlux News";
  $header2 = "www.neoflux.com";
  $remote = "www.neoflux.com";
  $file   = "index.shtml HTTP/1.1\nHost: www.neoflux.com:80";
  $backend= "backend.neoflux";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $neofluxdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDigitalTheatre {
  if($feedback == 1){
    print "Getting Digital Theatre. \n";
  }
  $header1 = "Digital Theatre";
  $header2 = "www.dtheatre.com";
  $remote = "www.dtheatre.com";
  $file   = "backend.php3";
  $backend= "backend.digitaltheatre";
  getbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 3;
  $dir = $digitaltheatredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCastersRealm {
  if($feedback == 1){
    print "Getting Casters Realm. \n";
  }
  $header1 = "Casters Realm";
  $header2 = "eq.castersrealm.com";
  $remote = "eq.castersrealm.com";
  $file   = "";
  $backend= "backend.castersrealm";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $castersrealmdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEverLore {
  if($feedback == 1){
    print "Getting EverLore. \n";
  }
  $header1 = "Ever Lore";
  $header2 = "www.everlore.com";
  $remote = "www.everlore.com";
  $file   = "default.asp HTTP/1.1\nHost: www.everlore.com:80";
  $backend= "backend.everlore";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $everloredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEQCorner {
  if($feedback == 1){
    print "Getting EQ Corner. \n";
  }
  $header1 = "EQ Corner";
  $header2 = "www.eqcorner.com";
  $remote = "www.planeteverquest.com";
  $file   = " HTTP/1.1\nHost: www.planeteverquest.com:80";
  $backend= "backend.eqcorner";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $eqcornerdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEQStratics {
  if($feedback == 1){
    print "Getting EQ Stratics. \n";
  }
  $header1 = "EQ Stratics";
  $header2 = "eq.stratics.com";
  $remote = "eq.stratics.com";
  $file   = " HTTP/1.1\nHost: eq.stratics.com:80";
  $backend= "backend.eqstratics";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $eqstraticsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDVDAnimania {
  if($feedback == 1){
    print "Getting DVD Animania. \n";
  }
  $header1 = "DVD Animania";
  $header2 = "www.wildcoast.org/dvd/";
  $remote = "www.wildcoast.org";
  $file   = "dvd/index.html HTTP/1.1\nHost: www.wildcoast.org:80";
  $backend= "backend.dvdanimania";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dvdanimaniadir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsModulo {
  if($feedback == 1){
    print "Getting Modulo News. \n";
  }
  $header1 = "Modulo";
  $header2 = "modulo.litestep.org";
  $remote = "modulo.litestep.org";
  $file   = "index.php3 HTTP/1.1\nHost: modulo.litestep.org:80";
  $backend= "backend.modulo";
  getbackend();
  #fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $modulodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPureLS {
  if($feedback == 1){
    print "Getting PureLS News. \n";
  }
  $header1 = "PureLS";
  $header2 = "www.purels.org";
  $remote = "www.purels.org";
  $file   = "index.html HTTP/1.1\nHost: www.purels.org:80";
  $backend= "backend.purels";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $purelsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNoNags {
  if($feedback == 1){
    print "Getting NoNags Newest. \n";
  }
  $header1 = "NoNags";
  $header2 = "www.nonags.com";
  $remote = "www.nonags.com";
  $file   = "nonags/z-wnf.html";
  $backend= "backend.nonags";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $nonagsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsDesktopSource {
  if($feedback == 1){
    print "Getting DesktopSource Latest. \n";
  }
  $header1 = "DesktopSource";
  $header2 = "desktopsource.mindjunction.com";
  $remote = "desktopsource.mindjunction.com";
  $file   = "index.php3 HTTP/1.1\nHost: desktopsource.mindjunction.com:80";
  $backend= "backend.desktopsource";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $desktopsourcedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAceHardware {
  if($feedback == 1){
    print "Getting Ace's Hardware News. \n";
  }
  $header1 = "Ace's Hardware News";
  $header2 = "www.aceshardware.com";
  $remote = "www.aceshardware.com";
  $file   = "index.php";
  $backend= "backend.acehardware";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $acehardwaredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPCStats {
  if($feedback == 1){
    print "Getting PC Stats News. \n";
  }
  $header1 = "PC StatsNews";
  $header2 = "www.pcstats.com";
  $remote = "www.pcstats.com";
  $file   = "news.cfm HTTP/1.1\nHost: www.pcstats.com:80";
  $backend= "backend.pcstats";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $pcstatsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAnimeNewsService {
  if($feedback == 1){
    print "Getting Anime News Service News. \n";
  }
  $header1 = "Anime News Service";
  $header2 = "www.animenewsservice.com";
  $remote = "www.animenewsservice.com";
  $file   = " HTTP/1.1\nHost: www.animenewsservice.com:80";
  $backend= "backend.animenewsservice";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $animenewsservicedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsEQlizer {
  if($feedback == 1){
    print "Getting EQ'Lizer News. \n";
  }
  $header1 = "EQ'Lizer";
  $header2 = "www.gameznet.com/eq/cgi-bin/viewnews.cgi?profileClassic";
  $remote = "www.gameznet.com";
  $file   = "eq/cgi-bin/viewnews.cgi?profileClassic";
  $backend= "backend.eqlizer";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $eqlizerdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsShugaShack {
  if($feedback == 1){
    print "Getting ShugaShack News. \n";
  }
  $header1 = "ShugaShack";
  $header2 = "www.shacknews.com";
  $remote = "www.shacknews.com";
  $file   = "";
  $backend= "backend.shugashack";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $shugashackdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsFileWatcher {
  if($feedback == 1){
    print "Getting FileWatcher News. \n";
  }
  $header1 = "FileWatcher News";
  $header2 = "filewatcher.org/news.html";
  $remote = "filewatcher.org";
  $file   = "news.html HTTP/1.1\nHost: filewatcher.org:80";
  $backend= "backend.filewatcher";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $shugashackdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCore {
  if($feedback == 1){
    print "Getting Core News. \n";
  }
  $header1 = "Core News";
  $header2 = "home.student.uu.se/c/cace4851/";
  $remote = "home.student.uu.se";
  $file   = "c/cace4851/ HTTP/1.1\nHost: home.student.uu.se:80";
  $backend= "backend.core";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $coredir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#

#############################################################################
# 
sub lsWebMonkey {
  if($feedback == 1){
    print "Getting WebMonkey. \n";
  }
  $header1 = "WebMonkey";
  $header2 = "hotwired.lycos.com/webmonkey/";
  $remote = "hotwired.lycos.com";
  $file   = "webmonkey/";
  $backend= "backend.webmonkey";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $webmonkeydir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#

#############################################################################
# 
sub lsInfoWorld {
  if($feedback == 1){
    print "Getting InfoWorld News. \n";
  }
  $header1 = "InfoWorld";
  $header2 = "www.infoworld.com";
  $remote = "www.infoworld.com";
  $file   = "index.html";
  $backend= "backend.infoworld";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $infoworlddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLinuxPower {
  if($feedback == 1){
    print "Getting LinuxPower News. \n";
  }
  $header1 = "LinuxPower";
  $header2 = "linuxpower.org";
  $remote = "linuxpower.org";
  $file   = "";
  $backend= "backend.linuxpower";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxpowerdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLWN {
  if($feedback == 1){
    print "Getting Linux Weekly News. \n";
  }
  $header1 = "Linux Weekly News";
  $header2 = "lwn.net";
  $remote = "lwn.net";
  $file   = "headlines/text";
  $backend= "backend.lwn";
  getbackend();
  $fromtop = 1;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 4;
  $dir = $lwndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsmkLinux {
  if($feedback == 1){
    print "Getting mkLinux News. \n";
  }
  $header1 = "mkLinux News";
  $header2 = "mklinux.org/info/";
  $remote = "mklinux.org";
  $file   = "info/news.html";
  $backend= "backend.mklinux";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mklinuxdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsMonkeyFist {
  if($feedback == 1){
    print "Getting Monkeyfist News. \n";
  }
  $header1 = "MonkeyFist News";
  $header2 = "monkeyfist.com";
  $remote = "monkeyfist.com";
  $file   = " HTTP/1.1\nHost: monkeyfist.com:80";
  $backend= "backend.monkeyfist";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $monkeyfistdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsNewsForge {
  if($feedback == 1){
    print "Getting NewsForge News. \n";
  }
  $header1 = "NewsForge News";
  $header2 = "www.newsforge.com";
  $remote = "www.newsforge.com";
  $file   = "newsforge.xml";
  $backend= "backend.newsforge";
  getbackend();
  fixbackend();
  $fromtop = 13;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 12;
  $dir = $newsforgedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPacketStorm_New {
  if($feedback == 1){
    print "Getting PacketStorm Newest. \n";
  }
  $header1 = "PacketStorm Newest";
  $header2 = "www.packetstormsecurity.org";
  $remote = "www.packetstormsecurity.org";
  $file   = "whatsnew20.txt";
  $backend= "backend.ps_new";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $packetstorm_newdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPacketStorm_Adv {
  if($feedback == 1){
    print "Getting PacketStorm Advisories. \n";
  }
  $header1 = "PacketStorm Advisories";
  $header2 = "www.packetstormsecurity.org";
  $remote = "www.packetstormsecurity.org";
  $file   = "advisories20.shtml";
  $backend= "backend.ps_adv";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 5;
  $dir = $packetstorm_advdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsPacketStorm_Tool {
  if($feedback == 1){
    print "Getting PacketStorm Advisories. \n";
  }
  $header1 = "PacketStorm Tools";
  $header2 = "www.packetstormsecurity.org";
  $remote = "www.packetstormsecurity.org";
  $file   = "tools20.shtml";
  $backend= "backend.ps_tool";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 5;
  $dir = $packetstorm_tooldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPacketStorm_Expl {
  if($feedback == 1){
    print "Getting PacketStorm Exploits. \n";
  }
  $header1 = "PacketStorm Exploits";
  $header2 = "www.packetstormsecurity.org";
  $remote = "www.packetstormsecurity.org";
  $file   = "exploits20.shtml";
  $backend= "backend.ps_expl";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 5;
  $dir = $packetstorm_expldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsPacketStorm_Misc {
  if($feedback == 1){
    print "Getting PacketStorm Misc. \n";
  }
  $header1 = "PacketStorm Misc";
  $header2 = "www.packetstormsecurity.org";
  $remote = "www.packetstormsecurity.org";
  $file   = "miscellaneous_files20.shtml";
  $backend= "backend.ps_misc";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 5;
  $dir = $packetstorm_miscdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsThinkGeek {
  if($feedback == 1){
    print "Getting Thinkgeek Latest News. \n";
  }
  $header1 = "ThinkGeek";
  $header2 = "www.thinkgeek.com";
  $remote = "www.thinkgeek.com";
  $file   = "thinkgeek.rdf";
  $backend= "backend.thinkgeek";
  getbackend();
  fixbackend();
  $fromtop = 4;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $thinkgeekdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsScreamingPenguin {
  if($feedback == 1){
    print "Getting Screaming Penguin News. \n";
  }
  $header1 = "Screaming Penguin";
  $header2 = "screaming-penguin.com";
  $remote = "screaming-penguin.com";
  $file   = "main.php?viewclass=1 HTTP/1.1\nHost: screaming-penguin.com:80";
  $backend= "backend.screamingpenguin";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $screamingpenguindir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSDN {
  if($feedback == 1){
    print "Getting Savage Daily News. \n";
  }
  $header1 = "Savage Daily News";
  $header2 = "sdn.fgn.com";
  $remote = "sdn.fgn.com";
  $file   = " HTTP/1.1\nHost: sdn.fgn.com:80";
  $backend= "backend.sdn";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $sdndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsFreakTech {
  if($feedback == 1){
    print "Getting Freaktech News. \n";
  }
  $header1 = "Freaktech";
  $header2 = "sunsite.auc.dk/FreakTech/";
  $remote = "sunsite.auc.dk";
  $file   = "FreakTech/";
  $backend= "backend.freaktech";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $freaktechdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsLSDEV {
  if($feedback == 1){
    print "Getting Litestep Dev News. \n";
  }
  $header1 = "LS DEV News";
  $header2 = "www.lsdev.org";
  $remote = "www.lsdev.org";
  $file   = "index.php3?LSDev_Session=11b2c04e68a4f3ec9d61e088168eac8f HTTP/1.1\nHost: www.lsdev.org:80";
  $backend= "backend.lsdev";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $lsdevdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsLSD4P {
  if($feedback == 1){
    print "Getting LSD4P News. \n";
  }
  $header1 = "Litestep Distribution For People News";
  $header2 = "why.litestep.com";
  $remote = "why.litestep.com";
  $file   = "index.php3 HTTP/1.1\nHost: why.litestep.com:80";
  $backend= "backend.lsd4p";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $lsd4pdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################


#############################################################################
# 
sub lsDEJD {
  if($feedback == 1){
    print "Getting Desktop Engineer Junk Drawer News. \n";
  }
  $header1 = "Desktop Engineer Junk Drawer News";
  $header2 = "desktopengineer.com";
  $remote = "desktopengineer.com";
  #$file   = "jdbeta2/public_html/";
  $file = "";
  $backend= "backend.dejd";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dejddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub ls3DNEWS {
  if($feedback == 1){
    print "Getting 3dnews News. \n";
  }
  $header1 = "3dnews News";
  $header2 = "www.3dnews.net";
  $remote = "www.3dnews.net";
  $file   = "";
  $backend= "backend.3dnews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAnandtech {
  if($feedback == 1){
    print "Getting Anandtech News. \n";
  }
  $header1 = "Anandtech Web News";
  $header2 = "www.anandtech.com";
  $remote = "www.anandtech.com";
  $file   = "news/index.html";
  $backend= "backend.anandtech";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $anandtechdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCOLA {
  if($feedback == 1){
    print "Getting COLA. \n";
  }
  $header1 = "comp.os.linux.announce";
  $header2 = "www.cs.helsinki.fi";
  $remote = "www.cs.helsinki.fi";
  $file   = "u/mjrauhal/linux/cola.archive/cola-last-50.html";
  $backend= "backend.cola";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $coladir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDailyRadar {
  if($feedback == 1){
    print "Getting Daily Radar. \n";
  }
  $header1 = "Daily Radar";
  $header2 = "www.dailyradar.com";
  $remote = "www.dailyradar.com";
  $file   = "news/index_all.html HTTP/1.1\nHost: www.dailyradar.com:80";
  $backend= "backend.dailyradar";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dailyradardir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsDotComma {
  if($feedback == 1){
    print "Getting DotComma. \n";
  }
  $header1 = "DotComma";
  $header2 = "www.dotcomma.org";
  $remote = "www.dotcomma.org";
  $file   = "dotcomma.rdf HTTP/1.1\nHost: www.dotcomma.org:80";
  $backend= "backend.dotcomma";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $dotcommadir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEET {
  if($feedback == 1){
    print "Getting EETimes. \n";
  }
  $header1 = "EETimes";
  $header2 = "www.eetimes.com";
  $remote = "www.eet.com";
  $file   = " HTTP/1.1\nHost: www.eet.com:80";
  $backend= "backend.eet";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $eetdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEmuViews {
  if($feedback == 1){
    print "Getting EmuViews. \n";
  }
  $header1 = "EmuViews";
  $header2 = "EmuViews";
  $remote = "www.emuviews.com";
  $file   = "cgi-local/home.cgi?INDEX=0&LANG=en_US  HTTP/1.1\nHost: www.emuviews.com:80";
  $backend= "backend.emuviews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $emuviewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSkinz {
  if($feedback == 1){
    print "Getting Skinz. \n";
  }
  $header1 = "Skinz.org";
  $header2 = "www.skinz.org";
  $remote = "www.skinz.org";
  $file   = " HTTP/1.1\nHost: www.skinz.org:80";
  $backend= "backend.skinz";
  getbackend();
  fixbackend();
  $fromtop = 9;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $skinzdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsStreaming {
  if($feedback == 1){
    print "Getting Streamingmedia.com. \n";
  }
  $header1 = "Streamingmedia.com";
  $header2 = "streamingmedia.com";
  $remote = "streamingmedia.com";
  $file   = "latestnews.asp";
  $backend= "backend.streaming";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $streamingdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsFreeOS {
  if($feedback == 1){
    print "Getting FreeOS News\n";
  }
  $header1 = "FreeOS";
  $header2 = "www.freeos.com";
  $remote = "www.freeos.com";
  $file   = "";
  $backend= "backend.freeos";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $freeosdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsFreeXML {
  if($feedback == 1){
    print "Getting Free XML Tools Latest\n";
  }
  $header1 = "Free XML Tools";
  $header2 = "www.garshol.priv.no/download/xmltools/";
  $remote = "www.garshol.priv.no";
  $file   = "download/xmltools/tools-rss.rdf";
  $backend= "backend.freexml";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $freexmldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsAdvogato {
  if($feedback == 1){
    print "Getting Advogato News\n";
  }
  $header1 = "Advogato";
  $header2 = "www.advogato.net";
  $remote = "www.advogato.org";
  $file   = "rss/articles.xml HTTP/1.1\nHost: www.advogato.org:80";
  $backend= "backend.advogato";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $advogatodir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsBBSpot {
  if($feedback == 1){
    print "Getting BBSpot News\n";
  }
  $header1 = "BBSpot News";
  $header2 = "bbspot.com";
  $remote = "bbspot.com";
  $file   = "bbspot.rdf";
  $backend= "backend.bbspot";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $bbspotdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsEndEffect {
  if($feedback == 1){
    print "Getting EndEffect News\n";
  }
  $header1 = "End Effect";
  $header2 = "www.endeffect.com";
  $remote = "www.endeffect.com";
  $file   = " HTTP/1.1\nHost: www.endeffect.com:80";
  $backend= "backend.endeffect";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $endeffectdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsJoyTech {
  if($feedback == 1){
    print "Getting Joy Tech\n";
  }
  $header1 = "Joy Tech";
  $header2 = "www.geekculture.com/joyoftech/index.html";
  $remote = "www.geekculture.com";
  $file   = "joyoftech/index.html";
  $backend= "backend.joytech";
  getbackend();
  fixbackend();
  $dir = $joytechdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsSpace {
  if($feedback == 1){
    print "Getting Space.com News\n";
  }
  $header1 = "Space.com";
  $header2 = "www.space.com";
  $remote = "www.space.com";
  $file   = "news/index.html";
  $backend= "backend.space";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $spacedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsCryptome {
  if($feedback == 1){
    print "Getting Cryptome News\n";
  }
  $header1 = "Cryptome";
  $header2 = "cryptome.org";
  $remote = "cryptome.org";
  $file   = "index.html HTTP/1.1\nHost: cryptome.org:80";
  $backend= "backend.cryptome";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $spacedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsVirtualPlastic {
  if($feedback == 1){
    print "Getting Virtual Plastic News\n";
  }
  $header1 = "Virtual Plastic";
  $header2 = "www.virtualplastic.net";
  $remote = "www.virtualplastic.net";
  $file   = "vp_news.xml  HTTP/1.1\nHost: www.virtualplastic.net:80";
  $backend= "backend.virtualplastic";
  getbackend();
  #fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $spacedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsBetaBites {
  if($feedback == 1){
    print "Getting Beta Bites\n";
  }
  $header1 = "Beta Bites";
  $header2 = "www.betabites.com";
  $remote = "www.betabites.com";
  $file   = "";
  $backend= "backend.betabites";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $betabitesdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsKuro5hin {
  if($feedback == 1){
    print "Getting Kuro5hin\n";
  }
  $header1 = "Kuro5hin";
  $header2 = "www.kuro5hin.org";
  $remote = "www.kuro5hin.org";
  $file   = " HTTP/1.1\nHost: www.kuro5hin.org:80";
  $backend= "backend.kuro5hin";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $kuro5hindir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsShouldExist {
  if($feedback == 1){
    print "Getting ShouldExist\n";
  }
  $header1 = "Shouldexist";
  $header2 = "www.shouldexist.org";
  $remote = "shouldexist.org";
  $file   = "backend.rdf HTTP/1.1\nHost: www.infoanarchy.org:80";
  $backend= "backend.shouldexist";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $shouldexistdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub lsXentertainment {
  if($feedback == 1){
    print "Getting X-Entertainment\n";
  }
  $header1 = "X-Entertainment";
  $header2 = "www.x-entertainment.com";
  $remote = "www.x-entertainment.com";
  $file   = "";
  $backend= "backend.xentertainment";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $xentertainmentdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# arsTechnica
sub lsArsTechnica2 {
  if($feedback == 1) {	
    print "Getting Ars Technica Front Page headlines.\n";
  }
  $header1 = "arsTechnica Front Page";
  $header2 = "arstechnica.com";
  $remote = "arstechnica.com";
  $file   = "";
  $backend= "backend.arstechnica2";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $arstechnica2dir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Yoginews
sub lsYogiNews {
  if($feedback == 1) {	
    print "Getting Yoginews.\n";
  }
  $header1 = "Yogi News";
  $header2 = "yoginews.ls2k.org";
  $remote = "yoginews.ls2k.org";
  $file   = " HTTP/1.1\nHost: yoginews.ls2k.org:80";
  $backend= "backend.yoginews";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $yoginewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Ellicit
sub lsEllicit {
  if($feedback == 1) {	
    print "Getting Ellicit News.\n";
  }
  $header1 = "Ellicit";
  $header2 = "www.ellicit.org";
  $remote = "www.ellicit.org";
  $file   = "E.shtml";
  $backend= "backend.ellicit";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $ellicitdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Geeknews
sub lsGeekNewsNet {
  if($feedback == 1) {	
    print "Getting Geeknews.\n";
  }
  $header1 = "Geeknews";
  $header2 = "www.geeknews.net";
  $remote = "www.geeknews.net";
  $file   = "ultramode.txt HTTP/1.1\nHost: www.geeknews.net:80";
  $backend= "backend.geeknewsnet";
  getbackend();
  fixbackend();
  $fromtop = 10;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 8;
  $dir = $ellicitdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# KDE News
sub lsKDENews {
  if($feedback == 1) {	
    print "Getting KDE News.\n";
  }
  $header1 = "KDE News";
  $header2 = "dot.kde.org";
  $remote = "dot.kde.org";
  $file   = "rdf HTTP/1.1\nHost: dot.kde.org:80";
  $backend= "backend.kdenews";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $kdenewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux.com News
sub lsLinuxCom {
  if($feedback == 1) {	
    print "Getting Linux.com News.\n";
  }
  $header1 = "Linux.com News";
  $header2 = "www.linux.com";
  $remote = "www.linux.com";
  $file   = "mrn/front_page.rss HTTP/1.1\nHost: www.linux.com:80";
  $backend= "backend.linuxcom";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxcomdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux.com Jobs
sub lsLinuxComJobs {
  if($feedback == 1) {	
    print "Getting Linux.com Jobs.\n";
  }
  $header1 = "Linux.com Jobs";
  $header2 = "www.linux.com";
  $remote = "www.linux.com";
  $file   = "/mrn/jobs/latest_jobs.rss HTTP/1.1\nHost: www.linux.com:80";
  $backend= "backend.linuxcomjobs";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxcomjobsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Linux.com LinuxGram
sub lsLinuxComGram {
  if($feedback == 1) {	
    print "Getting Linux.com LinuxGram.\n";
  }
  $header1 = "Linux.com LinuxGram";
  $header2 = "www.linux.com";
  $remote = "www.linux.com";
  $file   = "mrn/linuxgram_all.rss HTTP/1.1\nHost: www.linux.com:80";
  $backend= "backend.linuxcomgram";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxcomgramdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# LinuxNewbie
sub lsLinuxNewbie {
  if($feedback == 1) {	
    print "Getting Linux Newbie.\n";
  }
  $header1 = "Linux Newbie";
  $header2 = "www.linuxnewbie.org";
  $remote = "www.linuxnewbie.org";
  $file   = " HTTP/1.1\nHost: www.linuxnewbie.org:80";
  $backend= "backend.linuxnewbie";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxnewbiedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# LinuxProgramming
sub lsLinuxProgramming {
  if($feedback == 1) {	
    print "Getting Linux Programming.\n";
  }
  $header1 = "Linux Programming";
  $header2 = "www.linuxprogramming.com";
  $remote = "www.linuxprogramming.com";
  $file   = " ";
  $backend= "backend.linuxprogramming";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxprogrammingdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# LinuxTelephony
sub lsLinuxTelephony {
  if($feedback == 1) {	
    print "Getting Linux Telephony.\n";
  }
  $header1 = "Linux Telephony";
  $header2 = "www.linuxtelephony.org";
  $remote = "www.linuxtelephony.org";
  $file   = " HTTP/1.1\nHost: www.linuxtelephony.org:80";
  $backend= "backend.linuxtelephony";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $linuxtelephonydir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Mercury Center Breaking News
sub lsMerc {
  if($feedback == 1) {	
    print "Getting Mercury Center Breaking News.\n";
  }
  $header1 = "Mercury Center Breaking News";
  $header2 = "www0.mercurycenter.com";
  $remote = "www0.mercurycenter.com";
  $file   = "breaking/";
  $backend= "backend.merc";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mercdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Mr Tech News
sub lsMrTech {
  if($feedback == 1) {	
    print "Getting Mr. Tech News.\n";
  }
  $header1 = "Mr. Tech News";
  $header2 = "www.mrtech.com";
  $remote = "www.mrtech.com";
  $file   = "news/index.html";
  $backend= "backend.mrtech";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mercdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Magic Torch Overclocking News
sub lsMTO {
  if($feedback == 1) {	
    print "Getting Magic Torch Overclocking News.\n";
  }
  $header1 = "Magic Torch Overclocking News";
  $header2 = "www.mtoverclocking.co.uk";
  $remote = "server39.hypermart.net";
  $file   = "mtoverclocking/index.shtml";
  $backend= "backend.mto";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $mercdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# NanoDot News
sub lsNanoDot {
  if($feedback == 1) {	
    print "Getting NanoDot News.\n";
  }
  $header1 = "NanoDot News";
  $header2 = "www.nanodot.org";
  $remote = "www.nanodot.org";
  $file   = "ultramode.txt";
  $backend= "backend.nanodot";
  getbackend();
  $fromtop = 1;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 10;
  $dir = $nanodotdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Perl News
sub lsPerlNews {
  if($feedback == 1) {	
    print "Getting Perl News.\n";
  }
  $header1 = "Perl News";
  $header2 = "use.perl.org";
  $remote = "use.perl.org";
  $file   = "useperl.rdf HTTP/1.1\nHost: use.perl.org:80";
  $backend= "backend.perlnews";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $perlnewsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder General Forum
sub lsPHPBuilderGen {
  if($feedback == 1) {	
    print "Getting PHPBuilder General Forum.\n";
  }
  $header1 = "PHPBuilder General Forum";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=general&limit=20";
  $backend= "backend.phpbuildergen";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuildergendir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder Code Forum
sub lsPHPBuilderCode {
  if($feedback == 1) {	
    print "Getting PHPBuilder Code Forum.\n";
  }
  $header1 = "PHPBuilder General Forum";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=coding&limit=20";
  $backend= "backend.phpbuildercode";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuildercodedir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder Install Forum
sub lsPHPBuilderInstall {
  if($feedback == 1) {	
    print "Getting PHPBuilder Install Forum.\n";
  }
  $header1 = "PHPBuilder Install Forum";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=install&limit=20";
  $backend= "backend.phpbuilderinstall";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuilderinstalldir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder Windows Forum
sub lsPHPBuilderWin {
  if($feedback == 1) {	
    print "Getting PHPBuilder Windows Forum.\n";
  }
  $header1 = "PHPBuilder Windows Forum";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=windows-forum&limit=20";
  $backend= "backend.phpbuilderwin";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuilderwindir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder DB Forum
sub lsPHPBuilderDB {
  if($feedback == 1) {	
    print "Getting PHPBuilder DB Forum.\n";
  }
  $header1 = "PHPBuilder DB Forum";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=database-forum&limit=20";
  $backend= "backend.phpbuilderdb";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuilderdbdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# PHPBuilder Articles
sub lsPHPBuilderArt {
  if($feedback == 1) {	
    print "Getting PHPBuilder Articles.\n";
  }
  $header1 = "PHPBuilder Articles";
  $header2 = "www.phpbuilder.com";
  $remote = "www.phpbuilder.com";
  $file   = "rss_feed.php?type=articles&limit=20";
  $backend= "backend.phpbuilderart";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $phpbuilderartdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Q3Arena
sub lsQ3Arena {
  if($feedback == 1) {	
    print "Getting Q3Arena News.\n";
  }
  $header1 = "Q3Arena";
  $header2 = "www.q3arena.com";
  $remote = "www.q3arena.com";
  $file   = " ";
  $backend= "backend.q3arena";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $q3arenadir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Root Prompt
sub lsRootPrompt {
  if($feedback == 1) {	
    print "Getting Root Prompt News.\n";
  }
  $header1 = "Root Prompt";
  $header2 = "www.rootprompt.org";
  $remote = "www.rootprompt.org";
  $file   = "rss/";
  $backend= "backend.rootprompt";
  getbackend();
  fixbackend();
  $fromtop = 3;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $rootpromptdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# techdirt
sub lsTechDirt {
  if($feedback == 1) {	
    print "Getting TechDirt News.\n";
  }
  $header1 = "TechDirt";
  $header2 = "www.techdirt.com";
  $remote = "www.techdirt.com";
  $file   = "ultramode.txt HTTP/1.1\nHost: www.techdirt.com:80";
  $backend= "backend.techdirt";
  getbackend();
  $fromtop = 11;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 8;
  $dir = $techdirtdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# The Kult
sub lsTheKult {
  if($feedback == 1) {	
    print "Getting The Kult News.\n";
  }
  $header1 = "The Kult";
  $header2 = "www.thekult.org";
  $remote = "www.thekult.org";
  $file   = "index.php3 HTTP/1.1\nHost: www.thekult.org:80";
  $backend= "backend.thekult";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $thekultdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Toms
sub lsToms {
  if($feedback == 1) {	
    print "Getting Tom's Hardware News.\n";
  }
  $header1 = "Tom's Hardware";
  $header2 = "www.tomshardware.com/technews/index.html";
  $remote = "www.tomshardware.com";
  $file   = "technews/index.html HTTP/1.1\nHost: www.tomshardware.com:80";
  $backend= "backend.toms";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tomsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Tweak3D
sub lsTweak3D {
  if($feedback == 1) {	
    print "Getting Tweak3D News.\n";
  }
  $header1 = "Tweak3D";
  $header2 = "www.tweak3d.net";
  $remote = "www.tweak3d.net";
  $file   = " ";
  $backend= "backend.tweak3d";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tweak3ddir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# TweakTown
sub lsTweakTown {
  if($feedback == 1) {	
    print "Getting TweakTown News.\n";
  }
  $header1 = "TweakTown";
  $header2 = "www.tweaktown.com";
  $remote = "www.tweaktown.com";
  $file   = " HTTP/1.1\nHost: www.tweaktown.com:80";
  $backend= "backend.tweaktown";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tweaktowndir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# TweakFiles
sub lsTweakFiles {
  if($feedback == 1) {	
    print "Getting Tweak Files.\n";
  }
  $header1 = "Tweak Files";
  $header2 = "www.tweakfiles.com";
  $remote = "www.tweakfiles.com";
  $file   = " ";
  $backend= "backend.tweakfiles";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $tweakfilesdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Two Mobile
sub lsTwoMobile {
  if($feedback == 1) {	
    print "Getting Two Mobile News.\n";
  }
  $header1 = "TwoMobile";
  $header2 = "www.twomobile.com";
  $remote = "www.twomobile.com";
  $file   = " ";
  $backend= "backend.twomobile";
  getbackend();
  fixbackend();
  $fromtop = 0;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $twomobiledir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# Infolets
sub lsInfolets {
  if($feedback == 1) {	
    print "Getting Infolets News.\n";
  }
  $header1 = "Infolets";
  $header2 = "infolets.com";
  $remote = "infolets.com";
  $file   = "infolets.rss HTTP/1.1\nHost: infolets.com:80";
  $backend= "backend.infolets";
  getbackend();
  fixbackend();
  $fromtop = 6;
  $topicline = 2;
  $linkline = 3;
  $blocklength = 3;
  $dir = $infoletsdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# File Flash
sub lsFileFlash {
  if($feedback == 1) {	
    print "Getting File Flash Latest.\n";
  }
  $header1 = "File Flash";
  $header2 = "www.fileflash.com";
  $remote = "www.fileflash.com";
  $file   = "backend.php";
  $backend= "backend.fileflash";
  getbackend();
  #fixbackend();
  $fromtop = 0;
  $topicline = 1;
  $linkline = 3;
  $blocklength = 6;
  $dir = $fileflashdir;
  addfolder();
  if($pageval == 1){
    tabletitle();
    tablerow();
  }
  return;
}
#
#############################################################################

#############################################################################
# 
sub getbackend{
  if($remote ne "m45.ryd.student.liu.se"){
    $port = 80;
  }else{
    $port = 8080;
  }
  $iaddr = inet_aton($remote) ||  "no host: $remote"; #return;
  $paddr = sockaddr_in($port, $iaddr);
  $proto = getprotobyname('tcp');
  socket(SOCK, PF_INET, SOCK_STREAM, $proto) ||  "socket: $!"; #return;
  connect(SOCK, $paddr) || "couldn't connect: $remote";#die "connect: $!";
  select(SOCK); $| = 1; select(STDOUT);
  if($remote ne "www.desktopian.org"){
    print SOCK "GET /$file\n\n";
  }else{
    print SOCK "GET http://$remote$file\n\n";
  }
  unlink($backend);
  open(BACKEND,">>$backend");
    while(<SOCK>){
      print BACKEND "$_";
    }
  close(BACKEND);
  close(SOCK);# || die "$!";
  return;
  
}
#
############################################################################# 

sub fixbackend{
  open(BACKEND,"<$backend") || "Can't open $backend\n"; 
     while(<BACKEND>) {  
      $line = $_;
      #$line=~ s/\]|\[//gi;
      my $i;
      $i = 0;
      if("$backend" eq "backend.technotronic"){
        $line =~ s/<b>/x&&/;
        $line =~ s/<\/b>/&&/;
        ($first,$second,$third) = split(/&&/ , $line);
        chomp($second);
        if($second ne ""){
          open(TEMP,">>temp");
            print TEMP "$second\n";
            print TEMP "http://$remote\n";
          close(TEMP);  
        }
      }
      elsif("$backend" eq "backend.lg"){
        if($line =~ /$pattern/) {
          $line =~ s/.*<\/A>//gi;
          $line =~ s/<\/FONT>.*//gi;
          open(TEMP, ">>temp");
            print TEMP "&&\n";
            print TEMP "$line";
            print TEMP "http://$remote/index.shtml\n";
          close(TEMP);
        }        
      }elsif("$backend" eq "backend.stake"){
      	if($line =~ /<div class=\"title_snn\"><b>/){
           $line =~ s/.*<div class=\"title_snn\"><b>//gi;
           $line =~ s/<\/b><\/div>.*//gi;
           
           open(TEMP, ">>temp");
             print TEMP "&&\n";
             print TEMP $line;
             print TEMP "http:\/\/$remote\/$file\n";
           close(TEMP);
          }
        
          
      }elsif("$backend" eq "backend.hnn"){
        if($line =~ /^$pattern/)  { 
	         $x = 1;
	      }
        if($line =~ /^$pattern2/) {
          $x = 0;
        }
        if($x == 1){
          open(TEMP, ">>temp");
            $line =~ s/<item>/&&/;
            $line =~ s/<\/item>//;
            $line =~ s/<link>//;
            $line =~ s/<\/link>//;
            $line =~ s/<title>//;
            $line =~ s/<\/title>//;
            if($line ne "\n"){
              print TEMP $line;
            }
          close(TEMP);
         }
       }elsif("$backend" eq "backend.hpn"){
         if($line =~ /^$pattern/)  { 
           $line =~ s/^$pattern//;
	   $x = 1;
	 }
	 if($x == 1){
           $line =~ s/\n//;
           ($first, $second, $third) = split(/~@~#~/,$line);
           open(TEMP, ">>temp");
             $first =~ s/\n//;
             print TEMP "&&\n$first\n";
             print TEMP "$second\n";
             print TEMP "http://$remote\n";
           close(TEMP);
         }
       }elsif(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
         ($first, $second, $third) = split(/~@~#~/,$line);
         open(TEMP, ">>temp");
           print TEMP "$first\n";
           print TEMP "$second\n";
           print TEMP "$third\n";
         close(TEMP);
       }elsif("$backend" eq "backend.lq"){
       	if($line =~ /<!---- Begin article \"/){
       	   $line =~ s/.*?<!---- Begin article \"//gi;
       	   $line =~ s/\" ---->.*?//gi;
       	   open(TEMP, ">>temp");
             print TEMP "&&\n$line";
             print TEMP "http:\/\/$remote\n";
           close(TEMP);
       	}
       }elsif("$backend" eq "backend.ag"){
         if($line =~ /<title>|<link>/){
           $line =~ s/<link>//gi; $line =~ s/<\/link>//;
	   $line =~ s/<title>//;  $line =~ s/<\/title>//;
	   $line =~ s/\s//;
           open(TEMP, ">>temp");
             print TEMP $line;
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.l3d"){
         if($line =~ /$pattern/){
           $line =~ s/$pattern//;
           $line =~ s/<\/a>.*//;
           open(TEMP, ">>temp");
             print TEMP "&&\n";
             print TEMP "$line";
             print TEMP "http://$remote\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.g3d"){
         if($line =~ /$pattern/){
           $line =~ s/\">/xx&/;
           $line =~ s/<\/font>/&/;
           ($first, $second, $third) = split(/&/,$line);
           chomp($second);
           open(TEMP, ">>temp");
             print TEMP "$second\n";
             print TEMP "http://$remote$file\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.x11"){
         if($line =~ /^$pattern/)  {
           $line =~ s/<strong>\[Messages\]<br>//;
           $line =~ s/<strong>\[Screenshots\]<br>//;
           $flag = 1;
           $line =~ s/\">/xx&/;
           $line =~ s/<\/font>/&/;
           $line =~ s/\//_/;
           $line =~ s/\//_/;
           $line =~ s/\(//;
           $line =~ s/\)//;
           $line =~ s/://;
           $line =~ s/\s//;
           ($first, $second, $third) = split(/&/,$line);
           chomp($second);
           if("$second" ne ""){
             open(TEMP, ">>temp");
         	print TEMP "$second\n";
         	print TEMP "http://$remote$file\n";
             close(TEMP);
           }
         }  
       }elsif("$backend" eq "backend.mdt"){
         if($line =~ /$pattern/){
           $line =~ s/"><B>/&&/;
           $line =~ s/<\/B>/&&/;
           ($first, $third, $second) = split(/&&/,$line,3);
           chomp($third);
           if("$second" ne ""){
             open(TEMP, ">>temp");
               print TEMP "$third\n";
               print TEMP "http://$remote/$file\n";
             close(TEMP);
           }
         }  
       }elsif("$backend" eq "backend.bln"){
         if($line =~ /<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1\">/){
           $line =~ s/<\/font><\/p>//;
           $line =~ s/<\/strong><\/font><font face=\"Arial, Helvetica\" size=\"1\"><A HREF=\"//;
           $line =~ s/<A HREF=\"//g;
           $line =~ s/\">/&&/g;
           $line =~ s/<\/A><BR>/\n/g;
           
           $line =~ s/<A*.?\">/"\n"/gi;
           open(TEMP, ">>temp");
             print  TEMP $line;
           close(TEMP);
         }
       }elsif("$backend" eq "backend.ve"){
         if($line =~ /$pattern/){
           $line =~ s/<\/a>.*//gi;
           $line =~ s/.*$pattern//;
           $line =~ s/&amp;/&/gi;
           open(TEMP, ">>temp");
             print  TEMP "&&\n$line";
             print  TEMP "http:\/\/$remote\n";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.po"){
         if($line =~ /<link>/){
           $line =~ s/    <link>//gi; $line =~ s/<\/link>//gi;
           $second = $line;
         }
         if($line =~ /<title>/){
           $line =~ s/    <title>//gi; $line =~ s/<\/title>//gi;
           $first = $line;
           chomp $first; chomp $second;
           open(TEMP, ">>temp");
             print  TEMP "&&\n";
             print  TEMP "$first\n";
             print  TEMP "$second\n";
           close(TEMP);
         }
       }elsif("$backend" eq "backend.tho"){
          $line =~ s/<.*?title>//gi;
	  $line =~ s/<.*?link>//gi;
	  $line =~ s/		//gi;
	  open(TEMP, ">>temp");
          if($line =~ /<item>/ .. /<\/item>/){
            print  TEMP "$line";
          }
          close(TEMP);
       }elsif("$backend" eq "backend.uf"){
         if ($line =~ /<IMG ALT=\"Latest Strip\".*?/){
           chomp $line;
           open(TEMP, ">>temp");
             print  TEMP "$line";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.apod"){
         if($line =~ /<IMG SRC=\"image/){
           $line=~ s/<IMG SRC=\"//;
           $line=~ s/\"><\/a>//;
           chomp $line;
           $line= "<IMG ALT=\"Latest Image\"  BORDER=0 SRC=\"http:\/\/$remote\/apod\/$line\"></A>";
           chomp $line;
           open(TEMP, ">>temp");
             print  TEMP "$line";
           close(TEMP);
         }  
       }elsif("$backend" eq "backend.dilbert"){
          if($line =~ /<a href=\"\/comics\/dilbert\/archive\/images\/dilbert2.*?.gif/){
            $line =~ s/.*images\/dilbert/dilbert/gi;
            $line =~ s/.gif" BORDER=0 ALT.*/.gif/;
            open(TEMP, ">>temp");
              print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote\/comics\/dilbert\/archive\/images\/$line\"></A>";
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.floach"){
           if($line =~ /.*?<\/font><\/strong><\/font><\/td>/){
              $line =~ s/<.*//;
              $line =~ s/  //gi;
           open(TEMP, ">>temp");
             print TEMP "&&\n";
             print TEMP $line;
             print TEMP "http:\/\/$remote\n";
           close(TEMP);
           }
         }elsif("$backend" eq "backend.ay2k"){
           if($line =~ /			<img .*?src=\"y2Kimages\/.*?.gif\"|			<img .*?src=\"y2Kimages\/.*?.jpg\"/){
           
             $line=~ s/<\/font>.*//;
             $line=~ s/.*<img/<img/;
             $line = "<A href=\"http:\/\/www.geekculture.com\/geekycomics\/Aftery2k\/aftery2kmain.html\">$line";
             $line=~ s/y2Kimages/http:\/\/www.geekculture.com\/geekycomics\/Aftery2k\/y2Kimages/;
             
             #chomp $line;
             #$line = "<A href=\"http:\/\/www.geekculture.com\/geekycomics\/Aftery2k\/\"><IMG ALT=\"Latest After Y2K Image\"  BORDER=0 SRC=\"http://www.geekculture.com/geekycomics/Aftery2k/y2Kimages/$line\"></A>";
             #chomp $line;
             open(TEMP, ">>temp");
               print  TEMP "$line";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnet"){
           if($line =~ /<td align=left valign=middle><font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             $line =~ s/<td align=left valign=middle><font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
             $line =~ s/<\/b><\/font><\/td>/&&&/;
             ($first,$second,$third) = split(/&&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnetss"){
           if($line =~ /		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             $line =~ s/		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
             $line =~ s/<\/b><\/font>/&&&/;
             ($first,$second,$third) = split(/&&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote/sshots.php3\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.lsLSnett"){
           if($line =~ /		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/){
             if($line =~ /        				<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>Showing Themes 0-5<\/b><\/font>/){
             }else{    
               $line =~ s/		<font size=2 color=\"#FFFFFF\" face=\"Verdana,Helvetica,Sans-Serif\"><b>/xx&&&/;
               $line =~ s/<\/b><\/font>/&&&/;
               ($first,$second,$third) = split(/&&&/,$line);
               chomp($second);
               open(TEMP, ">>temp");
         	 print  TEMP "&&\n";
         	 print  TEMP "$second\n";
         	 print  TEMP "http://$remote/themes.php3\n";
               close(TEMP);
              }
           }
         }elsif("$backend" eq "backend.pvponline"){
           if ($line =~ /<CENTER><IMG SRC=\"archive\/2001\//){
             $line =~ s/<CENTER>//gi;$line =~ s/<\/CENTER>//gi;  
             $line =~ s/   <IMG SRC=\"//gi;$line =~ s/<\/td>//gi;
             $line =~ s/               //gi;
             chomp $line;
             open(TEMP, ">>temp");
               print  TEMP "<IMG ALT=\"Latest Strip\" width=576 BORDER=0 SRC=\"http:\/\/$remote\/$line\</A>";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.scifiwire"){
           if($line =~ /<!-- HEADLINE:/){
             $line =~ s/<!-- HEADLINE://;
             $line =~ s/ -->//;
             chomp($line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line\n";
               print  TEMP "http://$remote/scifiwire/index.html\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.techreport"){
           if($line =~ /<a name=\"article_.*?\" href=\"\/onearticle.x\/.*?\"/){
             $line =~ s/<a name="article_.*?" href="/http:\/\/$remote/gi;
             $line =~ s/<\/a>.*//gi;
             ($first,$second) = split(/\" class=\"headline\">/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "$first\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.shellscape"){
           if($line =~ /<font face=\"arial,helvetica\" size=4 color=\"#008F44\"><b>/){
             $line =~ s/<font face=\"arial,helvetica\" size=4 color=\"#008F44\"><b>/xx&&/;
             $line =~ s/<\/b><\/font><br>/&&xx/;
             ($first,$second,$third) = split(/&&/,$line);
             chomp($second);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$second\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.fileclicks"){
           if($line =~ /software.phtml\?id=/){
             $line =~ s/software.phtml\?id=/&&/;
             $line =~ s/<\/a><\/b><font size=\"-2\" color=\"#999999\"><br>/&&xx/;
             $line =~ s/\">/&&/gi;
             ($first,$second,$third,$fourth,$fifth) = split(/&&/,$line);
             chomp($fourth);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$fourth\n";
               print  TEMP "http://$remote/software.phtml?id=$third\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.pennyarcade"){
          if($line =~ /<img src=\"images\/2001\/.*?..*?\">/){
            $line =~ s/<img src=\"images\/2001\///gi;
            $line =~ s/\">//;
            $line =~ s/<.*?>//gi;
            $line =~ s/			//gi;
            chomp($line);
            open(TEMP, ">>temp");
              print  TEMP "<IMG ALT=\"Latest Strip\" BORDER=0 SRC=\"http:\/\/$remote\/images\/2001\/$line\"></A>";
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.geeknik"){
           if($line =~ /^<font class=\"date\">.*?<\/font><br>/){
             $line =~ s/.*<font class=\"date\">//gi; 
             $line =~ s/<\/font><br>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line";
               print  TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.newscom"){
           if($line =~ /<span class=\"f3\"><b><a href=\"\/news\/.*/){
              $line =~ s/.*<span class="f3"><b><a href="/http:\/\/$remote/;
              $line =~ s/<\/a><\/b>.*//gi;
              #$line =~ s/<a href=\"/http:\/\/$remote/gi;
              #$line =~ s/<.*?b>|<\/a>.*//gi;
              $line =~ s/\">/&&/gi;
              open(TEMP, ">>temp");
                 print  TEMP $line;
              close(TEMP);
           }  
         }elsif("$backend" eq "backend.wired"){
           if($line =~ /<a href=\"\/news_drop\/palmpilot\/story\/.*?.html\">/){
             $line =~ s/<a href=\"\/news_drop\/palmpilot\/story\/.*?.html\">//;
             $line =~ s/<\/a><br>//;
             chomp($line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP "$line\n";
               print  TEMP "http://$remote\n";
             close(TEMP);
           }  
         }elsif("$backend" eq "backend.pmsnippets"){
           if($line =~ /<li><A HREF=\"/){
             $line =~ s/<UL><li>//;
             $line =~ s/<li>/\n/gi;
             $line =~ s/<\/a>.*//gi;
             $line =~ s/<A HREF=\"\///gi;
             $line =~ s/\">/&&/gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }  
         }elsif("$backend" eq "backend.pmcooluses" or "$backend" eq "backend.pmpoetry" or "$backend" eq "backend.pmobfus" or "$backend" eq "backend.pmmed" or "$backend" eq "backend.pmcraft"){
           if($line =~ /<TR BGCOLOR=\"cccccc\">/){
             $line =~ s/.*<A HREF=\"\///gi;
             $line =~ s/\">/&&/gi;
             $line =~ s/<\/a>//gi;
            open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }elsif("$backend" eq "backend.mjsnip"){
           if($line =~ /.*?$pattern1.php3\?item=.*?&main=$pattern2>.*?/){
             $line =~ s/.*?<font face=verdana size=1/<font face=verdana size=1/;
             $line =~ s/.*?item=//gi;
             $line =~ s/&.*?1>/&&/gi;
             $line =~ s/<\/font><\/a><\/font><br>//gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }elsif("$backend" eq "backend.mjideas"){
           #<font face=verdana size=1 color=081951>&nbsp;&#149;&nbsp;<a href=/ideas.php3?item=17><font face=verdana size=1 color=081951>Words...</font></a></font><br>
           if($line =~ /.*?ideas.php3\?item=.*?>.*?/){
             $line =~ s/.*?<font face=verdana size=1/<font face=verdana size=1/;
             $line =~ s/.*?item=//gi;
             $line =~ s/>.*?081951>/&&/gi;
             $line =~ s/<\/font>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP $line;
             close(TEMP);
             
           }
         }
         elsif("$backend" eq "backend.mjnews"){
           if($line =~ /color=FFFFFF><b>::/){
              $line =~ s/.*color=FFFFFF><b>:: //gi;
              $line =~ s/<\/b><\/font>.*//gi;
              open(TEMP, ">>temp");
                print TEMP "&&\n";
                print TEMP $line;
                print TEMP "http://$remote\n";
              close(TEMP);
           }
         }elsif("$backend" eq "backend.tekreview"){
           if($line =~ /<font face=verdana size=3><font color=\"blue\"><b>/){
             $line =~ s/.*<b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $line;
               print  TEMP "http://$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.ebg"){
           if($line =~ /<font face=\"arial,helvetica\" size=3 color=00cc66><b>/ .. /<\/b><\/font>/){
             $line =~ s/<font face=\"arial,helvetica\" size=3 color=00cc66><b>/&&/;
             $line =~ s/<\/b><\/font>/http:\/\/$remote/;
             open(TEMP, ">>temp");
              # print  TEMP "&&\n";
               print  TEMP $line;
              # print  TEMP "http://$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.aicn"){
           if($line =~ /<TD CLASS=\"hlist\"><B><FONT SIZE=2><A HREF=\"display.cgi\?id=/){
             $line =~ s/<TD CLASS=\"hlist\"><B><FONT SIZE=2><A HREF=\"display.cgi\?id=//gi;
             $line =~ s/<\/.*?>//gi;
             ($first,$second) = split(/\"><.*?>/,$line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $second;
               print  TEMP "http://$remote/display.cgi?id=$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.epocnews"){
           if($line =~ /<P><A HREF=\"http:\/\/www.epoczone.com\/details.php3\?id=.*?">.*?<\/A>.*?<BR>/){
             $line =~ s/<P><A HREF=\"http:\/\/www.epoczone.com\/details.php3\?id=//gi;
             $line =~ s/<\/A>//gi;
             $line =~ s/<BR>//gi;
             $line =~ s/\">/&&/gi;
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
               print  TEMP "&&\n";
               print  TEMP $second;
               print  TEMP "http://www.epoczone.com/details.php3?id=$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.sinfest"|"$backend" eq "backend.joeaverage"|"$backend" eq "backend.avalonhigh"|"$backend" eq "backend.hounds"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.funnyfarm"|"$backend" eq "backend.elflife"){
          if($line =~ /<IMG ALT=\".*?\" BORDER=0 SRC=\"\/comics\//){
            $line =~ s/.*\"#000000\">//;
            $line =~ s/<\/font>.*//;
            $line =~ s/SRC=\"\//SRC=\"http:\/\/$remote\//gi;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.goats"){
          if($line =~ /<IMG SRC=\"\/comix\//){
            $line =~ s/.*<IMG/<IMG ALT="Today's Comic"/;
            $line =~ s/SRC=\"\//SRC=\"http:\/\/$remote\//;
            chop($line);
            open(TEMP, ">>temp");
              print  TEMP $line;
            close(TEMP);
           }  
         }elsif("$backend" eq "backend.cmptr"){
           if($line =~ /<li>/){
             $line =~ s/<\/li>/\n/gi;
             $line =~ s/<li><a href=\"//gi;
             $line =~ s/<\/a>//gi;
             $line =~ s/\">/&&/gi;
             open(TEMP, ">>temp");
              print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.palmstation"){
           if($line =~ /<\/b><\/font><\/td>/){
             $line =~ s/<\/b><\/font><\/td>//gi;
             $line =~ s/          //gis;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.pdabuzz"){
           if($line =~ /<a href=\"#newsitem/){
             $line =~ s/.*<a href=\"//gi;
             $line =~ s/<\/A>.*//gi;
             $line =~ s/\" class=\"c\">/&&/gi;
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $second;
              print TEMP "http:\/\/$remote/$file$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.palminfocenter"){
           if($line =~ /.*?<font face=\"Tahoma, Lucida, Helvetica\" size=\"\+1\"><b>/){
             $line =~ s/.*<b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote/$file\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.daemonnews"){
           if($line =~ /<STRONG><FONT COLOR=\"#ffffff\" CLASS=\"normal\">/){
             $line =~ s/<.*?>//gis;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote/\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.neoflux"){
           if($line =~ /<span class=\"headlines\">/){
             $line =~ s/.*<span class=\"headlines\">//gi;
             $line =~ s/<\/span>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.castersrealm"){
           if($line =~ /<p class='boldheader'>/){
             $line =~ s/.*<p class='boldheader'>//gi;
             $line =~ s/<\/p>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.everlore"){
           if($line =~ /<a href=\"#.*?\">/){
             $line =~ s/.*<a href=\"#.*?\">//gi;
             $line =~ s/<\/a>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.eqcorner"){
           if($line =~ /<span class=\"headline\">/){
             $line =~ s/.*<span class=\"headline\">//gi;
             $line =~ s/<\/span>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.eqstratics"){
           if($line =~ /    <td><font color=\"050056\" face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><b>/){
             $line =~ s/.*<b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
              print TEMP "&&\n";
              print TEMP $line;
              print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.dvdanimania"){
           if($line =~ /<p><font face=\"Arial\" color=\"#57AAFD\"><big><a name=\"/){
              $line =~ s/.*<p><font face=\"Arial\" color=\"#57AAFD\"><big><a name=\"//gi;
              $line =~ s/\">.*//gi;
              open(TEMP, ">>temp");
                if($line ne ""){
                   print TEMP "&&\n";
                   print TEMP $line;
                   print TEMP "http:\/\/$remote/dvd/\n";
                }
             close(TEMP);
           }
         }elsif("$backend" eq "backend.modulo"){
           if($line =~ /<font class="title">/){
             if($line =~ /NEW RELEASES/){
             }else{
               $line =~ s/<.*?>//gi;
               open(TEMP, ">>temp");
                 print TEMP "&&\n";
                 print TEMP $line;
                 print TEMP "http:\/\/$remote\n";
               close(TEMP);
             }
           }
         }elsif("$backend" eq "backend.purels"){
           if($line =~ /<\/strong>: <i>/){
             $line =~ s/.*<i>//gi;
             $line =~ s/<\/i>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.nonags"){
           if($line =~ /<TR BGCOLOR=#.*?><TD>.*? <\/TD><TD><B> /){
              $line =~ s/.*<B> //gi;
              $line =~ s/<\/B>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.desktopsource"){
           if($line =~ /item=.*?&main=Source>/){
             $line =~ s/.*&main=Source>//gi;
             $line =~ s/<\/a>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.acehardware"){
           if($line =~ /<br><a href="#.*?"><font color=lightblue>/){
             $line =~ s/.*<br><a href="//gi;
             $line =~ s/\"><font color=lightblue>/&&/gi;
             $line =~ s/<\/font>.*//gi;
             ($first,$second) = split(/&&/,$line);
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $second;
               print TEMP "http:\/\/$remote$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.pcstats"){
           if($line =~ /&nbsp;<font size=3 color=black face=arial><b>/){
             $line =~ s/.*&nbsp;<font size=3 color=black face=arial><b>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote/news.cfm\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.animenewsservice"){
           if($line =~ /<h4>|<H4>/){
             $line =~ s/.*<h4>.*?---- //gi;
             $line =~ s/<\/h4>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.eqlizer"){
           if($line =~ /<p><strong><font color=\"#f0f0f0\">/){
             $line =~ s/.*<p><strong><font color=\"#f0f0f0\">//gi;
             $line =~ s/<\/font>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote/$file\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.shugashack"){
           if($line =~ /class=\"noline\" target=\"_self\" href=\"\/onearticle.x\/.*?\">/){
             $line =~ s/.*class=\"noline\" target=\"_self\" href=\"\/onearticle.x\/.*?\">//gi;
             $line =~ s/<\/a>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.filewatcher"){
           if($line =~ /<A NAME=\".*?\"><\/A><u><B>/){
             $line =~ s/.*<A NAME=\".*?\"><\/A><u><B>//gi;
             $line =~ s/<\/B>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.core"){
           if($line =~ /<td bgColor=#000000 align=left>&nbsp;<b><font color=#ffffff face=\"Verdana, Arial\" size=1>/){
             $line =~ s/.*<td bgColor=#000000 align=left>&nbsp;<b><font color=#ffffff face=\"Verdana, Arial\" size=1>//gi;
             $line =~ s/<\/b>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.webmonkey"){
           if($line =~ /<a href="\/webmonkey\/.*?html\"><b>.*?<\/b><\/a><br>/){
             $line =~ s/.*<a href=\"/http:\/\/$remote/gi;
             $line =~ s/<\/b>.*//gi;
             ($first,$second) = split(/\"><b>/,$line);
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $second;
               print TEMP "$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.infoworld"){
           if($line =~ /<A HREF=\"\/articles.*?.xml\"><FONT CLASS=\"header\">/){
             $line =~ s/.*<A HREF=\"/http:\/\/$remote/gi;
             $line =~ s/<\/FONT><\/A>.*//gi;
             ($first,$second) = split(/\"><FONT CLASS=\"header\">/,$line);
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP "$second";
               print TEMP "$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.linuxpower"){
           if($line =~ /<b>.*?<\/b> <a href=\"\/index.php.*?\" class=\"update\">/){
             $line =~ s/.*\"update\">//gi;
             $line =~ s/<\/a>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.mklinux"){
           if($line =~ /<b><a name=\".*?>/){
             $line =~ s/.*\">//gi;
             $line =~ s/<\/A>.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\/main.html\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.monkeyfist"){
           if($line =~ /<h2 class=\"title\">/){
             $line =~ s/.*<h2 class=\"title\">//gi;
             $line =~ s/.*\"self.status=''\">//gi;
             $line =~ s/<\/h2>.*|<\/a>.*|&n.*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\/\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.ps_new"){
           if($line =~ /.*?\]/){
             $line =~ s/.*\[//gi;
             $line =~ s/\].*//gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
               print TEMP "http:\/\/$remote\/\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.ps_adv"|"$backend" eq "backend.ps_tool"|"$backend" eq "backend.ps_expl"|"$backend" eq "backend.ps_misc"){
           if($line =~ /bgcolor=#333366><a name=/){
             $line =~ s/.*bgcolor=#333366><a name=//gi;
             $line =~ s/><\/a><a href=/@@/gi;
             $line =~ s/>.*?#444477>/@@/gi;
             $line =~ s/<\/td>.*?#000033>/@@/gi;
             $line =~ s/<\/td><\/tr>//gi;
             ($first,$second,$third,$fourth) = split(/@@/,$line);
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP "$first\n";
               print TEMP "http:\/\/$remote$second\n";
               print TEMP "$third\n";
               print TEMP "$fourth";
               #print TEMP "http:\/\/$remote\/\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.thinkgeek"|"$backend" eq "backend.shouldexist"|"$backend" eq "backend.kdenews"|"$backend" eq "backend.linuxcom"|"$backend" eq "backend.linuxcomjobs"|"$backend" eq "backend.linuxcomgram"|"$backend" eq "backend.perlnews"|"$backend" eq "backend.phpbuildergen"|"$backend" eq "backend.phpbuildercode"|"$backend" eq "backend.phpbuilderinstall"|"$backend" eq "backend.phpbuilderwin"|"$backend" eq "backend.phpbuilderdb"|"$backend" eq "backend.phpbuilderart"|"$backend" eq "backend.rootprompt"|"$backend" eq "backend.infolets"|"$backend" eq "backend.freshmeat"|"$backend" eq "backend.virtualplastic"|"$backend" eq "backend.shellcity"){
           if ($line =~ /<title>|<link>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/<\/title>.*//gi;
               $line =~ s/.*<link>//gi;
               $line =~ s/<\/link>.*//gi;
               open(TEMP, ">>temp");
                 print TEMP $line;
               close(TEMP);
           }
         }elsif("$backend" eq "backend.wonkoslice"){
           if ($line =~ /<title>|<url>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/<\/title>.*//gi;
               $line =~ s/.*<url>//gi;
               $line =~ s/<\/url>.*//gi;
               open(TEMP, ">>temp");
                 print TEMP $line;
               close(TEMP);
           }
         }elsif("$backend" eq "backend.screamingpenguin"){
           if ($line =~ /<td class=\"news-title-1\">/ .. /<td align=\"right\"  class=\"news-title-1\">/){
               $line =~ s/.*<td class=\"news-title-1\">/&&/gi;
               $line =~ s/<\/td>.*//gi;
               $line =~ s/<td align=\"right\"  class=\"news-title-1\">.*/http:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.sdn"){
           if ($line =~ /<font size=\"3\" face=\"arial\" color=\"003366\"><b>/){
               $line =~ s/.*<font size=\"3\" face=\"arial\" color=\"003366\"><b>/&&\n/gi;
               $line =~ s/<\/b>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.freaktech"){
           if ($line =~ /   <font size=\"\+1\" color=\"#FFFFFF\"><b> /){
               $line =~ s/.*<b> /&&\n/gi;
               $line =~ s/<\/b>.*/\nhttp:\/\/$remote\/$file/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.lsdev"){
           if ($line =~ / <font size=3 face=\"Verdana,Helvetica,Sans-Serif\" color=\"#CEB62B\"><b>/){
               $line =~ s/.*<b>/&&\n/gi;
               $line =~ s/<\/b>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.lsd4p"){
           if ($line =~ /<FONT FACE=\"Arial\" SIZE=\"2\" COLOR=\"BLACK\"><B>/){
               $line =~ s/.*<b>/&&\n/gi;
               $line =~ s/<\/FONT>.*/\nhttp:\/\/$header2/gi;
               open(TEMP, ">>temp");
                 print TEMP $line;
               close(TEMP);
           }
         }elsif("$backend" eq "backend.dejd"){
           if ($line =~ /<TR><TD class=storytitle>/){
               $line =~ s/.*<TR><TD class=storytitle>/&&\n/gi;
               $line =~ s/<\/TD>.*/\nhttp:\/\/$remote\/$file/gi;
               $line =~ s/<.*?>//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.3dnews"){
           if ($line =~ /class=\"fp_headline\">/){
               $line =~ s/.*class=\"fp_headline\">/&&\n/gi;
               $line =~ s/<\/a>.*/\nhttp:\/\/$remote/gi;
               $line =~ s/<.*?>//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.anandtech"){
           if ($line =~ /class=\"smallnewsHeadline\">/){
               $line =~ s/.*<a href=\"/http:\/\/$remote\/news\//;
               $line =~ s/<\/a>.*|<\/font>.*//;
               ($first,$second) = split (/\".*?\">/,$line);
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $second;
               print TEMP "$first\n";
             close(TEMP);
           }
         }elsif("$backend" eq "backend.cola"){
           if ($line =~ /<br>/){
               #$line =~ s/.*class=\"navmenulink\">/&&\n/gi;
               #$line =~ s/<\/a>.*/\nhttp:\/\/$remote/gi;
               #$line =~ s/<.*?>//gi;
               $line =~ s/<br>/\n/gi;
               $line =~ s/<\/a>.*//gi;
               $line =~ s/.*=\"//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.dailyradar"){
           if ($line =~ /<FONT FACE=\"Arial,Helvetica\" SIZE=2><B>/){
               $line =~ s/.*<FONT FACE=\"Arial,Helvetica\" SIZE=2><B>/&&\n/gi;
               $line =~ s/<\/B>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.dotcomma"){
           if ($line =~ /<title>|<link>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/.*<link>//gi;
               $line =~ s/<\/title>.*|<\/link>.*//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.eet"){
           if ($line =~ /<a href=\"\/story\/.*?\"><B>/){
               $line =~ s/.*<B>/&&\n/gi;
               $line =~ s/<\/B>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.emuviews"){
           if ($line =~ /<TR HEIGHT=2><TD HEIGHT=1 BGCOLOR=#2288CC><\/TD><\/TR><TR><TD><B><FONT FACE=ARIAL COLOR=#00FF00>� <FONT COLOR=#FFFF00><A HREF=\"http:\/\/www.emuviews.com\/cgi-local\/show.cgi\?SERIAL=.*?&LANG=en_US\" TARGET=_top>|E=ARIAL COLOR=#00FF00>� <FONT COLOR=#FFFF00><A HREF=\"http:\/\/www.emuviews.com\/cgi-local\/show.cgi\?SERIAL=.*?&LANG=en_US\" TARGET=_top>|<TR HEIGHT=2><TD HEIGHT=1 BGCOLOR=#2288CC><\/TD><\/TR><TR><TD><B><FONT FACE=ARIAL COLOR=#00FF00>� <FONT COLOR=#FFFF00>/){
               $line =~ s/.*TARGET=_top>|.*FFFF00>/&&\n/gi;
               $line =~ s/<\/A>.*|<FONT SIZE=1>.*/\nhttp:\/\/$remote/gi;
               open(TEMP, ">>temp");
                 print TEMP $line;
               close(TEMP);
           }
         }elsif("$backend" eq "backend.skinz"){
           if ($line =~ /<font face=\"arial,helvetica\" size=\"2\" color=\"#332a29\"><center><b>/){
               $line =~ s/.*<font face=\"arial,helvetica\" size=\"2\" color=\"#332a29\"><center><b>/&&\n/gi;
               $line =~ s/<\/b>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.streaming"){
           if ($line =~ /<\/b><\/a><br>/){
               $line =~ s/<\/b>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP "&&\n";
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.freeos"){
           if ($line =~ /<\/A><br><\/b>/){
               $line =~ s/.*\">/&&\n/gi;
               $line =~ s/<\/A>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.freexml" or "$backend" eq "backend.slashdot"){
           if ($line =~ /<link>|<title>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/.*<link>//gi;
               $line =~ s/<\/link>|<\/title>//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.advogato"){
           if ($line =~ /<link>|<title>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/.*<link>//gi;
               $line =~ s/<\/link>|<\/title>//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.bbspot"){
           if ($line =~ /<link>|<title>/){
               $line =~ s/.*<title>/&&\n/gi;
               $line =~ s/.*<link>//gi;
               $line =~ s/<\/link>|<\/title>//gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.endeffect"){
           if ($line =~ /text-decoration:none;\">/){
               $line =~ s/.*text-decoration:none;\">/&&\n/gi;
               $line =~ s/<\/a>.*/\nhttp:\/\/$remote/gi;
             open(TEMP, ">>temp");
               print TEMP $line;
             close(TEMP);
           }
         }elsif("$backend" eq "backend.joytech"){
           if($line =~ /src=\"joyimages\/.*?..*?\" border=\"0\" align=\"right\"/){
              $line=~ s/joyimages/http:\/\/$remote\/joyoftech\/joyimages/;
              $line=~ s/\.\./http:\/\/www.geekculture.com/;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }  
         }elsif("$backend" eq "backend.newsforge"){
             $line=~ s/.*<title>|.*<url>//gi;
             $line=~ s/<\/title>.*|<\/url>.*//gi;
             open(TEMP, ">>temp");
               print  TEMP "$line";
             close(TEMP);
        }elsif("$backend" eq "backend.space"){
           if($line =~ /class=\"mlink.*?\">/){
              $line=~ s/.*<a href=\"/http:\/\/$remote/gi;
              $line=~ s/<\/a>.*|<b>//gi;
              $line=~ s/\" class=\"mlink.*?\">/&&/gi;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.cryptome"){
           if($line =~ /<\/A>.*?\+/){
              $line=~ s/.*A HREF=\"//gi;
              $line=~ s/\">.*?<\/A>.*?\+ /&&/gi;
              $line=~ s/   .*?<\/B>|<\/B>//gi;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "bbackend.virtualplastic"){
           if($line =~ /<a href=\"index.html#.*?\"><font face=\"verdana,arial\" size=\"1\"><img src=\"images\/link.gif\" border=\"0\">.*?/){
              $line=~ s/<a href=\"/http:\/\/$remote\//gi;
              $line=~ s/\"><font .*?border=\"0\">/&&/gi;
              $line=~ s/<br>.*|<\/font>.*//gi;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.betabites"){
           if($line =~ /<span class=\"articleheader\"><b>/){
              $line=~ s/.*<span class=\"articleheader\"><b>//gi;
              $line=~ s/<\/b>.*//gi;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.kuro5hin"){
           if($line =~ /<FONT FACE=\"verdana, arial, helvetica, sans-serif\"><B>/){
              $line=~ s/.*\"><B>//gi;
              $line=~ s/\(<A.*//gi;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.xentertainment"){
           if($line =~ /<\/a><\/b><\/font><\/td>/){
              $line=~ s/.*<font face=Verdana size=-2><b>|.*.html\">|                        //gi;
              $line=~ s/<\/a>.*//gi;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.arstechnica2"){
           if($line =~ /<h2>/){
              $line=~ s/.*<h2>//gi;
              $line=~ s/<\/h2>.*//gi;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.yoginews"){
          if($line =~ /<table BORDER=\"0\"/ .. /::/){
              $line=~ s/.*BGCOLOR="#006699">//;
              $line=~ s/&nbsp.*?  ::.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.ellicit"){
           if($line =~ /<\/A> \|/){
              $line=~ s/.*sans-serif\">//;
              $line=~ s/<\/FONT>.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.geeknewsnet"){
           if($line =~ /sid/){
              open(TEMP, ">>temp");
                print  TEMP "http:\/\/$remote$line";
              close(TEMP);
           }else{
             open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.linuxnewbie"){
           if($line =~ /<b><font color=\"#000000\" face=\"Arial, Verdana, sans-serif\" size=\"3\">/){
              $line=~ s/.*size=\"3\">//;
              $line=~ s/<\/font>.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.linuxprogramming"){
           if($line =~ /<A HREF=\"http:\/\/news.linuxprogramming.com\/news_story.php3\?/){
              $line=~ s/.*\">//;
              $line=~ s/<\/A>.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.linuxtelephony"){
           if($line =~ /<font class='tab'>/){
              $line=~ s/.*<font class='tab'>//;
              $line=~ s/<\/font>.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.merc"){
           if($line =~ /<KR_DIGEST_HEADLINE>/){
              $line=~ s/.*<A HREF=\"/http:\/\/$remote/;
              $line=~ s/\"><KR_DIGEST_HEADLINE>/&&/;
              $line=~ s/<\/KR_DIGEST_HEADLINE>.*//;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.mrtech"){
           if($line =~ /<td><span class=myList><b>.*?<\/b>/){
              $line=~ s/.*href=\"//;
              $line=~ s/\"><b>/&&/;
              $line=~ s/<\/b>.*//;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.mto"){
           if($line =~ /\#newsitem/){
              $line=~ s/.*<p><a href=\"//;
              $line=~ s/\"><font size=\"1\" face=\"Arial\">/&&/;
              $line=~ s/<\/font>.*//;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.q3arena"){
           if($line =~ /<span class=\"Topic\"><B>/){
              $line=~ s/.*<span class=\"Topic\"><B>//;
              $line=~ s/\<\/B>.*//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.thekult"){
           if($line =~ /<span class="headnews">/){
              $line=~ s/.*<span class=\"headnews\">/&&\n/;
              $line=~ s/<\/span>.*/\nhttp:\/\/$remote/;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.toms"){
           if($line =~ /<BR><B><A HREF.*?TARGET=\"_top\">/ .. /<\/A><\/B>/){
              $line =~ s/<BR><B><A HREF=\"\/technews\/index.html\" TARGET=\"_top\">/&&\n/;
              $line=~ s/<BR><B><A HREF=.*?\>/&&/;
              $line=~ s/.*<\/A><\/B>.*/http:\/\/$remote/;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.tweak3d"){
           if($line =~ /<a href=\"http:\/\/www.tweak3d.net\/.*?\"><font face=\"Arial\">/){
              $line =~ s///gi;
              $line =~ s/<a href=\"//gi;
              $line=~ s/\"><font face=\"Arial\">/&&/;
              $line=~ s/<\/FONT>.*//;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.tweaktown"){
           if($line =~ /WIDTH=15 HEIGHT=15 ALIGN=bottom><b><font color=\"#FFFFFF\" size=\"2\" face=\"Verdana\">/){
              $line =~ s/<\/font>.*//;
              $line=~ s/.*face=\"Verdana\">//;
              open(TEMP, ">>temp");
                print  TEMP "&&\n";
                print  TEMP "$line";
                print  TEMP "http:\/\/$remote\n";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.tweakfiles"){
           if($line =~ /<img src=\"\/images\/yeldot.jpg\" align=middle>/){
              $line =~ s/.*<a href=\"|.*<font color=\"#cc9900\">/http:\/\/$remote/;
              $line=~ s/<\/b>.*//;
              $line=~ s/\"><b>/&&/;
              $line=~ s/<b>/&&/;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.twomobile"){
           if($line =~ /<td valign=\"top\"><font size=\"2\" face=\"Verdana\"><b><\/b><\/font><font size=\"2\" face=\"verdana,arial,helvetica\"><b><\/b><\/font><font color=\"black\" face=\"Verdana,Helvetica,Arial\" size=\"1\"><i><\/i><\/font><font color=\"black\" face=\"Verdana,Helvetica,Arial\" size=\"1\"><i><\/i><\/font><b><font size=\"2\" face=\"verdana,arial,helvetica\"><\/font><\/b><b><font size=\"2\" face=\"verdana,arial,helvetica\"><a href=\"\/content\/.*?.php\">/){
              $line =~ s/<\/a> <\/font>.*//;
              $line=~ s/.*<a href=\"/http:\/\/$remote/;
              $line=~ s/\">/&&/;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }elsif("$backend" eq "backend.fileflash"){
           if($line =~ /<a href=\"index.aspx\?action=info&program=.*?\"><b>/){
              $line =~ s/.*<a href="/http:\/\/$remote/;
              $line=~ s/\"><b>/&&/;
              $line=~ s/<\/b>.*//;
              open(TEMP, ">>temp");
                print  TEMP "$line";
              close(TEMP);
           }
        }

  }
  
  if("$backend" eq "backend.pmsnippets" or "$backend" eq "backend.pmcooluses" or "$backend" eq "backend.pmpoetry" or "$backend" eq "backend.pmobfus" or "$backend" eq "backend.pmmed" or "$backend" eq "backend.pmcraft"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http://$remote\/$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
  if( "$backend" eq "backend.mjnewss"){
    open(TEMP, "<temp");
      while(<TEMP>){
        $line = $_;
        $line =~ s/.*&nbsp.*//s;
        chomp $line;
        chop $line;
        open(TEMP2, ">>temp2");
          if ( length($line) > 1 ){
            print TEMP2 "&&\n";
            print TEMP2 "$line\n";
            print TEMP2 "http://$remote\n";
          }
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  if("$backend" eq "backend.mjsnip"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http://$remote\/$pattern1.php3\?item=$first&main=$pattern2\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  if( "$backend" eq "backend.mjideas"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http://$remote\/ideas.php3\?item=$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }     
  if("$backend" eq "backend.cmptr"|"$backend" eq "backend.space"|"$backend" eq "backend.cryptome"|"$backend" eq "backend.bln"|"$backend" eq "backend.mrtech"|"$backend" eq "backend.mto"|"$backend" eq "backend.tweak3d"|"$backend" eq "backend.tweakfiles"|"$backend" eq "backend.twomobile"|"$backend" eq "backend.fileflash"|"$backend" eq "backend.newscom"|"$backend" eq "backend.gasource"|"$backend" eq "backend.merc"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
  if("$backend" eq "backend.cola"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/\">/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "http:\/\/$remote/u\/mjrauhal\/linux\/cola.archive\/$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
  if("$backend" eq "backend.f3d"){
    open(TEMP, "<temp");
      while(<TEMP>){
        ($first,$second) = split(/&&/,$_);
        open(TEMP2, ">>temp2");
          print TEMP2 "&&\n";
          print TEMP2 "$second";
          print TEMP2 "$first\n";
        close(TEMP2);
      }
    close(TEMP);
    unlink("temp");
    rename("temp2","temp");
  }
       
  close(BACKEND);
  unlink($backend);
  rename("temp",$backend);
  unlink("temp");
  return;
}

sub addfolder{
  unlink <*.url>;
  if($folderval == 1){
    checkdir();
    chdir ("$folderdir$dir");
    unlink <*.url>;
    chdir ("$startdir");
    $linecount = 0;
    $linenumber = 0;
    $topiccount = 00;
    open(BACKEND,"<$backend") || "Can't open $backend\n"; #return;
      while(<BACKEND>) {  
        ++$linecount;
        if($backend eq "backend.uf"|$backend eq "backend.apod"|$backend eq "backend.dilbert"|$backend eq "backend.ay2k"|$backend eq "backend.pvponline"|$backend eq "backend.pennyarcade"|$backend eq "backend.sinfest"|$backend eq "backend.joeaverage"|$backend eq "backend.avalonhigh"|$backend eq "backend.hounds"|"$backend" eq "backend.goats"|"$backend" eq "backend.funnyfarm"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.elflife"|"$backend" eq "backend.joytech"){
          $_=~ s/.*http/http/;
          $_=~ s/gif.*/gif/;
          $_=~ s/jpg.*/jpg/;
          $topic = $header1;
          Format_SC($topic,$dir,$_)
        }else{
          if($linecount>$fromtop){
	    ++$linenumber;
	  }
	  if($linenumber == $topicline){
	    ++$topiccount;
	    if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
	    }
	    else{
	      chop;
	    }
	    $topic="$_";$topic=~ s/\"|:|>|<|\/|\|*|\?|\||\=|\)|\(//gi;$topic=~ s/\+/"plus"/gi;#$topic=~ s/\s//;
	    $topic=~ s/\*\*\*\*\*\*h3//gi;
	    $topic =~ s/\]|\[//gi;
	    $topic=~ s/(.*?\/.*?)//gi;
	    if("$backend" eq "backend.ag"){
	    }
	    else{
	      $topic=~ s/$topic/$topic /;
	    }
	  }  
	  elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
	    Format_SC($topic,$dir,$_,$topiccount)	    
	  }  
	  if($linenumber == $blocklength) {
	    $linenumber=0;
	  }
        }	        
      }
    close(BACKEND);
    chdir ($startdir);
  }
  return;
}
sub Format_SC {
  if($foldernumval == 0){
   $tc = "";
  }else{
   $tc = $topiccount;
   if($tc < 10){$tc = "0$tc "}else{$tc = "$tc ";}
  }
  open(NUMFILE, ">$folderdir$dir/$tc$topic.url");
    print  NUMFILE <<SHORT;
[DEFAULT]
BASEURL=$_
[InternetShortcut]
URL=$_

SHORT
  close(NUMFILE);
  
}

#############################################################################
# Checkdir

sub checkdir {

 if (-e "$folderdir$dir") {
  return;
 }
 mkdir("$folderdir$dir",0777) || die "Cannot mkdir $folderdir$dir: $!";
 return;
}

#############################################################################

sub createpage {
    open(FILE,">$pagename");
    close(FILE);
    return;
}

sub header{
  open(FILE,">>$pagename");
  print FILE <<HEADER;
<html>

<head>
<title>$pagetitle</title>
<base TARGET="_self">
</head>
<body BGCOLOR="#$back" TEXT="#$bodytext" LINK="#$bodylink" LEFTMARGIN="0" VLINK="#$bodyvlink" ALINK="#$bodyalink">
HEADER
print_time();
  print FILE <<HEADER_2;
<table BORDER="0" WIDTH="100%">
  <tr>
    <td WIDTH="8%"></td>
    <td WIDTH="83%">
HEADER_2
  close(FILE);
  return;
}



sub footer{
  open(FILE,">>$pagename");
  print FILE <<FOOTER;

    </td>
    <td WIDTH="9%"></td>
  </tr>
</table>

<p>&nbsp;</p>
</body>
</html>


FOOTER
close(FILE);
return;
}



sub tabletitle{
  open(FILE,">>$pagename");
  print FILE <<TITLE;
   <div align="center">
            <center>
               <table BORDER="1" WIDTH="536"
                      BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border"
                      BGCOLOR="#$entryback">
                      <tr>
                         <td WIDTH="100%">
                            
                              <big>
                                 <strong><A href=http:\/\/$header2>$header1</a></strong>
                             </big>
                         </td>
                      </tr>
               </table>
            </center>
        </div>

TITLE
  close(FILE);
return;
}

sub tablerow{
  open(FILE,">>$pagename");
  print FILE<<TROWT;
<div align="center">
             <center>
                <table BORDER="1" WIDTH="536"
                       BGCOLOR="#$bodyback" BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border">
                       <tr>
                          <td>
TROWT

  $linecount = 0;
  $num = 0;
  $linenumber = 0;
  
  my $topiccount = 0;
  
  open(BACKEND,"<$backend") || print "Can't open $backend\n"; 
       while(<BACKEND>) {  
             ++$linecount;
             ++$num;
             if($backend eq "backend.uf"|$backend eq "backend.apod" | $backend eq "backend.dilbert" | $backend eq "backend.ay2k" | $backend eq "backend.pvponline" | $backend eq "backend.pennyarcade" |$backend eq "backend.sinfest"|$backend eq "backend.roadwaffles"|$backend eq "backend.joeaverage"|$backend eq "backend.avalonhigh"|$backend eq "backend.hounds"|"$backend" eq "backend.goats"|"$backend" eq "backend.funnyfarm"|"$backend" eq "backend.bruno"|"$backend" eq "backend.newshounds"|"$backend" eq "backend.gpf"|"$backend" eq "backend.elflife"|"$backend" eq "backend.joytech"){
                print FILE "                            $_";
             }else{
	             if($linecount>$fromtop){
		              ++$linenumber;
	             }
	             if($linenumber == $topicline){
	     	          ++$topiccount;
	     	          if(("$backend" eq "backend.hpa") or ("$backend" eq "backend.hpu")){
                  }
		              else{
		                chop;
		              }
		              $topic="$_";
		              linecheck($topic);
                          if("$backend" eq "backend.ag"){
		              }
	                else{
	                  $topic=~ s/$topic/$topic /;
	                }
	            }
	     
	            elsif($linenumber == $linkline && $topic ne "" && $topiccount <= $limit){
		            chop;
		            print  FILE "                            <li><A href='$_'>$topic</a></li>\n";
              }  
	            if($linenumber == $blocklength){
	               $linenumber=0;
	            }
	          }  
       }
  close(BACKEND);

print FILE <<TROWB;  
                        </td>
                      </tr>
               </table>
             </center>
       </div><p>&nbsp;

TROWB
close(FILE);
return;
}

sub linecheck{
  $topic =~ s/\?/'?'/gi;
  $topic =~ s/\*\*\*\*\*\*<\/h3>//gi;
  #$topic=~ s/:|>|<|\/|\|*|\?|\||\=|\(|\)//gi;
	$topic=~ s/\/||\(|\)//gi;
	$topic=~ s/\+/\+ /gi;
	$topic=~ s/\*/'*'/gi;
	$topic =~ s/\]|\[//gi;
	$topic =~ s/&amp;/&/gi;
	#$topic=~ s/\s//;
}

sub print_time{
   
  print FILE <<UPDATETIME_1;
<div align="center">
            <center>
               <table BORDER="1" WIDTH="536"
                      BORDERCOLOR="#$border" CELLSPACING="0" BORDERCOLORLIGHT="#$border" BORDERCOLORDARK="#$border"
                      BGCOLOR="#$entryback">
                      <tr>
                         <td WIDTH="100%">
                            
                              <big>
UPDATETIME_1
printf FILE ("<center><strong> Last Updated at : %02d:%02d:%02d on %02d-%02d-%04d </strong></center>\n",$t_hour,$t_min,$t_sec,$t_mon,$t_mday,$t_year);
print FILE <<UPDATETIME_2;                                 
                             </big>
                         </td>
                      </tr>
               </table>
            </center>
        </div>    
  
  
UPDATETIME_2
}

# 2.40.0 Fixed:   Betanews
#        Fixed:   @Stake News
#        Fixed:   Voodoo Extreme
#        Fixed:   Dilbert
#        Note:    LiteStep.Net News   - Still Down
#        Note:    LiteStep.Net Screen Shots  - Still Down
#        Note:    LiteStep.Net Themes - Still Down
#        Fixed:   PVPonline 
#        Fixed:   Tech Report
#        Fixed:   FileClicks
#        Fixed:   Geeknik
#        Fixed:   Wired
#        Fixed:   Sinfest Daily Comic
#        Fixed:   Joe Average Daily Comic
#        Fixed:   Avalon High Daily Comic 
#        Fixed:   Hounds Home Daily Comic 
#        Fixed:   Funny Farm Daily Comic
#        Fixed:   Bruno The Bandit Daily Comic
#        Fixed:   News Hounds Daily Comic 
#        Fixed:   GPF Daily Comic 
#        Fixed:   Elf Life Daily Comic
#        Fixed:   Anime News Service
#        Fixed:   WebMonkey
#        Fixed:   InfoWorld 
#        Fixed:   PacketStorm Newest  
#        Fixed:   PacketStorm Advisories  
#        Fixed:   PacketStorm Tools  
#        Fixed:   PacketStorm Exploits  
#        Fixed:   PacketStorm Misc 
#        Fixed:   Anandtech News
#        Fixed:   Joy Tech 
#        Fixed:   Ellicit
#        Fixed:   Geeknews.net
#        Fixed:   KDE News
#        Fixed:   Perl News
#        Fixed:   TweakTown 
#        Fixed:   FileFlash
#        Fixed:   Floach
#        Fixed:   Shell city
#        Fixed:   Penny Arcade
#        Removed: Geeknews  - dead
#        Removed: 32BitsOnline  - dead?
#        Removed: BeOS Central  - dead?
#        Removed: Fullon 3d - gone
#        Removed: GeekNews.Org  - dead?
#        Removed: Graphite News  - gone
#        Removed: Road Waffles Daily Comic - gone
#        Removed: Linux 2000 News - gone
#        Removed: Dr. Twisters EQ Alert
#        Removed: Brell Serilis News
#        Removed: NerdPerfect News
#        Removed: WinFiles
#        Removed: Cold-Ice News
#        Removed: LiteGnomer
#        Removed: Planet GeForce - gone
#        Removed: Pyxidis - gone?
#        Removed: DeskMod
#        Removed: EmuSphere
#        Removed: GA-Source - dead
#        Removed: Fark
#        Removed: GU Comics
#        Removed: Low Pass Industries
#        Removed: DotCult
#        Removed: linuxworld
#        Removed: riva3d
#        Note:    PacketStorm Advisories  Currently Offline
#        Note:    PacketStorm Tools   Currently Offline
#        Note:    PacketStorm Exploits   Currently Offline
#        Note:    PacketStorm Misc  Currently Offline