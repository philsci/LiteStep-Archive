Popup2 + Multipopup

Author
----------------------------------------------------------------
Chao-Kuo Lin(Chaku)
e-mail: chaokuo@iname.com
url:	http://cklin.cjb.net

Basic Features
----------------------------------------------------------------
popup2 plus multipopup, so if you have any questions about Popup2 
syntax, get a popup2 readme. For multipopup syntax, please consult 
the bottom of this file.  You can also find information on how
to get popup2 to show tasks on differnt desktops with ckVWM.


Version history:
-----------------------------------------------------------------
version 2.12ck	(11/11/2000)
			Fixed scrolling problem. If your !Popup won't start
			with a portion out of the desktop while clicking at the edge
			of the screen, and thus no scrolling, try using the bang 
			name you assigned for that popup.

			Added support for bang command 
			to specify popup position:	!Popup[BangName] x y
			ex. !PopupMain 100 300, negative numbers work too.

version 2.11ck
			Fixed some syntax handling code.

version 2.1ck
			Added multipopup support.

-----------------------------------------------------------------
Multiple popup support:
=======================

1.) *Popup "Popup Name" !New !Popup[BangName]

    ...
    ...

2.) *Popup ~New

*if "Popup Name" arg is absent, the HotListName will be used
for the popup


1.) Specifies the begining of a new popup. [BangName] should
    be replaced by whatever you want the popup to be called:
    eg. *Popup !New !PopupSecond
    Executing !PopupSecond will then call the popup.
    The bang name HAS TO START WITH !Popup

2.) Specifies the end of the new popup.


RULES:
  1. You CANNOT mix new and old popups.
  2. The first popup to be defined will be the main popup, so you can use
     the name you assigned or !Popup to call up the specific popup
  3. Should !New not be found in the first *Popup line in
     the step.rc then the popup will assume old mode
     for compatibility purposes
  4. Besides the first popup, the rest of the popups cannot be named !Popup
     or they will not show up.

-------------------------------------------------------------------
ckVWM support:

The step.rc config for these added popup feature is:
	PopupckVWMPath "path"
where path equals to the path to your ckvwm.dll, the one you load module with.

When you don't use ckvwm, you can simply comment out the PopupckVWMPath, and everything
will be the same as before.

The syntax to see windows on other desktop is the same as !PopupTasks,
just replace !PopupTasks with !PopupTasks1, !PopupTasks2, !PopupTasks3.....depending on your
vwm configuration.  !PopupTasksAll Allows you to tasks from all desktops.

*Note: 
	>if a warning dialog popups up from your shell saying that the module ckvwm is already
	loaded, simply change the order you load ckvwm and popup in step.rc  Load ckvwm before popup
	>so far this feature only works when ckVWM's hidetaskonswitch is specified.  Expect it to work
	without the config in future release of ckVWM.
