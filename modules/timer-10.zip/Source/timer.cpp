/*
This is a part of the Timer LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

Based upon structure of hotkey.dll by LiteStep Development Team
Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "timer.h"

const char rcsRevision[] = "$Revision: 1.0.0.0 $"; // Our Version
const char rcsId[] = "$Id: timer.cpp,v 1.0.0.0 2001/05/06 23:40:00 message Exp $"; // The Full RCS ID.
const char szAppName[] = "TimerWindow";

Timer *timer; // The module

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code = 0;

	AddBangCommand("!TimerStart", bangStart);
	AddBangCommand("!TimerReset", bangReset);
	AddBangCommand("!TimerStop", bangStop);
	AddBangCommand("!TimerKill", bangKill);

	Window::init(dllInst);
	timer = new Timer(parentWnd, code);

	return code;
}

void quitModule(HINSTANCE dllInst)
{
	RemoveBangCommand("!TimerStart");
	RemoveBangCommand("!TimerReset");
	RemoveBangCommand("!TimerStop");
	RemoveBangCommand("!TimerKill");

	delete timer;
}

void bangStart(HWND caller, LPCSTR args)
{
	timer->bangStart(args);
}

void bangReset(HWND caller, LPCSTR args)
{
	timer->bangReset(args);
}

void bangStop(HWND caller, LPCSTR args)
{
	timer->bangStop(args);
}

void bangKill(HWND caller, LPCSTR args)
{
	timer->bangKill(args);
}

Timer::Timer(HWND parentWnd, int& code):
Window(szAppName)
{
	if (!createWindow(WS_EX_TOOLWINDOW, "Timer", WS_CHILD, 0, 0, 0, 0, parentWnd))
	{
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);

		code = 1;
		return;
	}
	code = 0;
}

Timer::~Timer()
{
	destroyWindow();
}

void Timer::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
		MESSAGE(onCreate, WM_CREATE)
		MESSAGE(onDestroy, WM_DESTROY)
		MESSAGE(onEndSession, WM_ENDSESSION)
		MESSAGE(onEndSession, WM_QUERYENDSESSION)
		REJECT_MESSAGE(WM_ERASEBKGND)
		REJECT_MESSAGE(WM_PAINT)
		MESSAGE(onGetRevId, LM_GETREVID)
		MESSAGE(onSysCommand, WM_SYSCOMMAND)
		MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}

void Timer::onCreate(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	loadTimers();
}

void Timer::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	removeTimers();
}

void Timer::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Timer::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
	case 0:
		sprintf(buf, "timer.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
	case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
	default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void Timer::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Timer::onTimer(Message& message)
{
	int i = timerFromId((long)message.wParam);
	if (i == -1) return;
	if (timers[i].running == true) KillTimer(hWnd, timers[i].id);
	timers[i].running = false;
	LSExecute(hWnd, timers[i].command, NULL);
}

void Timer::bangStart(LPCSTR name)
{
	//MessageBox(hWnd, name, "bangStart", MB_OK);
	int i = timerFromName(name);

	/*
	char msg[4096];
	char buffer[128];

	strcpy(msg, "");
	itoa(i, buffer, 10);
	strcat(msg, buffer); strcat(msg, "\t");
	itoa(timers[i].id, buffer, 10);
	strcat(msg, buffer); strcat(msg, "\t");
	strcat(msg, timers[i].name); strcat(msg, "\t");
	itoa(timers[i].timeout, buffer, 10);
	strcat(msg, buffer); strcat(msg, "\t");
	strcat(msg, timers[i].command); strcat(msg, "\t");
	if(timers[i].running == true) strcat(msg, "runing");
	strcat(msg, "\n");
	MessageBox(hWnd, msg, "Timer report", MB_OK);
	*/
	if (i == -1)
		return;
	if (timers[i].running == true)
		return;
	SetTimer(hWnd, timers[i].id, timers[i].timeout, NULL);
	timers[i].running = true;
}

void Timer::bangReset(LPCSTR name)
{
	//MessageBox(hWnd, name, "bangReset", MB_OK);
	int i = timerFromName(name);
	if (i == -1)
		return;
	if (timers[i].running == true)
	{
		KillTimer(hWnd, timers[i].id);
		SetTimer(hWnd, timers[i].id, timers[i].timeout, NULL);
		timers[i].running = true;
	}
}

void Timer::bangStop(LPCSTR name)
{
	int i = timerFromName(name);
	if (i == -1)
		return;
	if (timers[i].running == true)
	{
		KillTimer(hWnd, timers[i].id);
		timers[i].running = false;
		LSExecute(hWnd, timers[i].command, NULL);
	}
}

void Timer::bangKill(LPCSTR name)
{
	int i = timerFromName(name);
	if (i == -1)
		return;
	if (timers[i].running == true)
	{
		KillTimer(hWnd, timers[i].id);
		timers[i].running = false;
	}
}

void Timer::loadTimers()
{
	FILE *f;
	timercount = 0;
	f = LCOpen (NULL);
	if (f)
	{
		char buffer[4096];
		char token1[4096], token2[4096], token3[4096], extra_text[4096];
		char* tokens[3];

		tokens[0] = token1;
		tokens[1] = token2;
		tokens[2] = token3;

		buffer[0] = 0;
		while (LCReadNextConfig (f, "*Timer", buffer, sizeof (buffer)))
		{
			int count;

			token1[0] = token2[0] = token3[0] = extra_text[0] = 0;

			count = LCTokenize (buffer, tokens, 3, extra_text);
			
			strcpy(timers[timercount].name, token2);
			strcpy(timers[timercount].command, extra_text);
			timers[timercount].timeout = atol(token3);
			timers[timercount].id = timercount;
			timers[timercount].running = false;
			
			timercount++;
			
		}
		LCClose(f);
	}
}

int Timer::timerFromName(LPCSTR name)
{
	int i;

	for(i=0; i<timercount; i++)
	{
		if(strcmpi(timers[i].name, name) == 0)
			return i;
	}
	return -1;
}

int Timer::timerFromId(long id)
{
	int i;

	for(i=0; i<timercount; i++)
	{
		if(timers[i].id == id)
			return i;
	}
	return -1;
}

void Timer::removeTimers()
{
	int i;

	for(i=0; i<timercount; i++)
		if (timers[i].running == true)
			KillTimer(hWnd, timers[i].id);
}
