/*
This is a part of the Timer LiteStep module source code.
Copyright (C) 2001 Erik Christiansson, aka Sci
http://www.alfafish.com/
erik@alfafish.com

Based upon structure of hotkey.dll by LiteStep Development Team
Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __TIMER_H
#define __TIMER_H

#define WIN32_LEAN_AND_MEAN

#pragma	warning(disable: 4786) // STL naming warnings

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"

typedef struct TimerStruct
{
	char name[32];
	char command[4096];
	long timeout;
	long id;
	bool running;
} timerItem;

class Timer : public Window
{
private:
	timerItem timers[100];
	int timercount;

public:
	Timer(HWND parentWnd, int& code);
	~Timer();
	void bangStart(LPCSTR name);
	void bangReset(LPCSTR name);
	void bangStop(LPCSTR name);
	void bangKill(LPCSTR name);

private:
	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onSysCommand(Message& message);
	void onDestroy(Message& message);
	void onTimer(Message& message);

	void loadTimers();
	void removeTimers();
	int timerFromId(long id);
	int timerFromName(LPCSTR name);
};

extern "C" {
	void bangStart(HWND caller, LPCSTR args);
	void bangReset(HWND caller, LPCSTR args);
	void bangStop(HWND caller, LPCSTR args);
	void bangKill(HWND caller, LPCSTR args);
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif //__TIMER_H
