/*setup includes*/
#include <tchar.h>
#include <windows.h>
#include "modulebox.h"
#include "../../litestep/lsapi/lsapi.h"

/*setup constants*/
const char szAppName[] = _T("");
const char szAppClass[] = _T("ModuleBoxClass");
const char rcsRevision[] = _T("$Revision: 0.40 $");
const char rcsId[] = _T("$Id: modulebox.cpp,v 0.41 2000/05/02 00:22:00 jugg $");

/*setup variables*/
HWND hParentWnd, hMainWnd, hDesktopWnd;
int screenHeight, screenWidth, WndX, WndY;
ModBoxSettings mbs;

/*function declarations*/
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
void ModBoxHide(void);
void ModBoxMove(HWND,char*);
void ModBoxShow(void);
void ModBoxToggle(void);
void ModBoxzOrder(HWND,char*);


ModBoxSettings ReadSettings(void)
{
	ModBoxSettings settings;
	TCHAR tmp[MAX_PATH];

	settings.Hidden = GetRCBool(_T("ModBoxHidden"), TRUE);

	settings.BgColor = GetRCColor(_T("ModBoxBgColor"), 0xFFFFFF);
	settings.BorderColor = GetRCColor(_T("ModBoxBorderColor"), 0x000000);

	settings.Height = GetRCInt(_T("ModBoxHeight"), 32);
		if (settings.Height < 2) settings.Height = 32;
	settings.Width = GetRCInt(_T("ModBoxWidth"), 32);
		if (settings.Width < 2) settings.Width = 32;

	settings.X = GetRCInt(_T("ModBoxX"), 0);
		if (settings.X < 0)
			WndX = screenWidth + settings.X;
		else
			WndX = settings.X;
	settings.Y = GetRCInt(_T("ModBoxY"), 0);
		if (settings.Y < 0)
			WndY = screenHeight + settings.Y;
		else
			WndY = settings.Y;

	settings.BorderSize = GetRCInt(_T("ModBoxBorderSize"), 2);
		if (settings.BorderSize < 0) settings.BorderSize = 2;

	GetRCString(_T("ModBoxBgImage"), tmp, _T(".none"), MAX_PATH);
		settings.BgImage = LoadLSImage(tmp, NULL);

	settings.zOrder = GetRCInt(_T("ModBoxzOrder"), 1);
		if (settings.zOrder < 0 || settings.zOrder > 2 || (settings.zOrder == 0 && hDesktopWnd == NULL)) settings.zOrder = 1;

	return settings;
}


int initModuleEx(HWND parent, HINSTANCE hInst, const char* szPath)
{
	UINT Msgs[2];
	szPath=szPath;
	hParentWnd = parent;

	screenHeight = GetSystemMetrics(SM_CYSCREEN);
	screenWidth = GetSystemMetrics(SM_CXSCREEN);

	hDesktopWnd = NULL;
	hDesktopWnd = FindWindow(_T("DesktopBackgroundClass"), NULL);
	if (hDesktopWnd != NULL && !IsWindow(hDesktopWnd))
		hDesktopWnd = NULL;

	{
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		wc.cbClsExtra = NULL;
		wc.cbWndExtra = NULL;
		wc.hbrBackground = NULL;
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.hIcon = NULL;
		wc.hInstance = hInst;
		wc.lpfnWndProc = WndProc;
		wc.lpszClassName = szAppClass;
		wc.lpszMenuName = NULL;
		wc.style = NULL;
		if (!RegisterClass(&wc)){
			MessageBox(hParentWnd,_T("Error registering window class"),_T("ModuleBox"),MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			return 1;
		}
	}

	mbs = ReadSettings();

	hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW|WS_EX_ACCEPTFILES|(mbs.zOrder==2 ? WS_EX_TOPMOST:0), szAppClass, szAppName, !mbs.zOrder ? WS_CHILD:WS_POPUP, WndX,WndY,mbs.Width,mbs.Height, !mbs.zOrder ? hDesktopWnd:NULL, NULL, hInst, NULL);
	if (!hMainWnd){
		MessageBox(hParentWnd,_T("Error creating window"),_T("ModuleBox"),MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		UnregisterClass(szAppClass,hInst);
		return 1;
	}
	if(!mbs.zOrder)
		SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
	SetWindowLong(hMainWnd, GWL_USERDATA, 0x49474541);

	{// register with LiteStep to receive Version request, so we display in the !about box.
		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(hParentWnd, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	}

	AddBangCommand(_T("!MODBOXHIDE"), ModBoxHide);
	AddBangCommand(_T("!MODBOXMOVE"), ModBoxMove);
	AddBangCommand(_T("!MODBOXSHOW"), ModBoxShow);
	AddBangCommand(_T("!MODBOXTOGGLE"), ModBoxToggle);
	AddBangCommand(_T("!MODBOXZORDER"), ModBoxzOrder);

	if (mbs.Hidden)
		ShowWindow(hMainWnd, SW_HIDE);
	else
		ShowWindow(hMainWnd, SW_SHOWNOACTIVATE);

	return 0;
}

void quitModule(HINSTANCE hInst)
{
	UINT Msgs[2];
	{// unregister the litestep version info message.
		Msgs[0] = LM_GETREVID;
		Msgs[1] = 0;
		SendMessage(hParentWnd, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	}
	RemoveBangCommand(_T("!MODBOXHIDE"));
	RemoveBangCommand(_T("!MODBOXMOVE"));
	RemoveBangCommand(_T("!MODBOXSHOW"));
	RemoveBangCommand(_T("!MODBOXTOGGLE"));
	RemoveBangCommand(_T("!MODBOXZORDER"));

	DestroyWindow(hMainWnd);
	UnregisterClass(szAppClass,hInst);
	return;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)lParam;
			if (!wParam){
				strcpy(buf, _T("modulebox.dll: "));
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = _T('\0');
			}
			else if (wParam == 1){
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = _T('\0');
			}else
				strcpy(buf, _T(""));
			return strlen(buf);
		}
		case WM_DROPFILES:
		{
			static TCHAR szFileName[MAX_PATH]; // must make static, otherwise, when posting message, we leave this memory area, it is destroyed.
			int numFiles;
			UINT keyState = GetAsyncKeyState(VK_SHIFT) & 0x8000;
			numFiles = DragQueryFile((HDROP)wParam, 0xFFFFFFFF, NULL, NULL);
			for (int i=0;i<numFiles;i++){
				DragQueryFile((HDROP)wParam, i, szFileName, sizeof(szFileName));
				if (GetFileAttributes(szFileName) != 0xFFFFFFFF)
					PostMessage(hParentWnd, keyState ? LM_UNLOADMODULE:LM_RELOADMODULE, (WPARAM)(szFileName), 0);
			}
			DragFinish((HDROP)wParam);
			return 0;
		}
		case WM_PAINT:
		{
			HDC hdc;
			PAINTSTRUCT ps;
			HBRUSH hBG, hOldBg;

			RECT r;
			GetClientRect(hwnd, &r);

			hdc = BeginPaint(hwnd,&ps);

			if (mbs.BgColor != 0x00FF00FF){
				hBG = CreateSolidBrush(mbs.BgColor);
				hOldBg = (HBRUSH) SelectObject(hdc, hBG);
				FillRect(hdc, &r, hBG);
				SelectObject(hdc, hOldBg);
				DeleteObject(hBG);
			}else
				PaintDesktop(hdc);

			if (mbs.BgImage){
				BITMAP bmInfo;
				GetObject(mbs.BgImage, sizeof(bmInfo), &bmInfo);
				HDC src = CreateCompatibleDC(hdc);
				HBITMAP oldBmp = (HBITMAP) SelectObject(src, mbs.BgImage);
				TransparentBltLS(hdc, (mbs.Width/2 - bmInfo.bmWidth/2), (mbs.Height/2 - bmInfo.bmHeight/2), bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255, 0, 255));
				SelectObject(src, oldBmp);
				DeleteDC(src);
			}

			if (mbs.BorderSize > 0){
				HPEN pen, oldpen;
				pen = CreatePen(PS_SOLID|PS_INSIDEFRAME, mbs.BorderSize*2, mbs.BorderColor);
				oldpen = (HPEN) SelectObject(hdc, pen);
				MoveToEx(hdc, r.left, r.bottom, NULL);
				LineTo(hdc, r.left, r.top);
				LineTo(hdc, r.right, r.top);
				LineTo(hdc, r.right, r.bottom);
				LineTo(hdc, r.left, r.bottom);
				SelectObject(hdc, oldpen);
				DeleteObject(pen);
			}

			EndPaint(hwnd,&ps);
			return 0;
		}
		case WM_DISPLAYCHANGE:
		{
			screenHeight = HIWORD(lParam);
			screenWidth = LOWORD(lParam);
			WndX = (mbs.X < 0 ? screenWidth:0) + mbs.X;
			WndY = (mbs.Y < 0 ? screenHeight:0) + mbs.Y;
			SetWindowPos(hwnd,0,WndX,WndY,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOSENDCHANGING|SWP_NOACTIVATE);
			break;
		}
		case WM_CLOSE:
		case WM_SYSCOMMAND:
			return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void ModBoxHide(void)
{
	if (!mbs.Hidden){
		mbs.Hidden = TRUE;
		ShowWindow(hMainWnd, SW_HIDE);
	}
	return;
}

void ModBoxMove(HWND hwnd, char* args)
{
	hwnd = hwnd;
	POINT ps;
	GetCursorPos(&ps);
	WndX = ps.x;
	WndY = ps.y;
	if (args != NULL && *args && strlen(args)){
		if (!lstrcmpi(_T("home"), args)){
			WndX = (mbs.X < 0 ? screenWidth:0) + mbs.X;
			WndY = (mbs.Y < 0 ? screenHeight:0) + mbs.Y;
		}else{
			args = strtok(args, "\"\t ,");
				if (args != NULL){
					WndX = atoi(args);
					if (WndX < 0) WndX = screenWidth + WndX;

					args = strtok(NULL, "\"\t ,");
						if (args != NULL){
							WndY = atoi(args);
							if (WndY < 0) WndY = screenHeight + WndY;
						}
				}
		}
	}
	SetWindowPos(hMainWnd,0,WndX,WndY,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOSENDCHANGING|SWP_NOACTIVATE);
	return;
}

void ModBoxShow(void)
{
	if (mbs.Hidden){
		mbs.Hidden = FALSE;
		ShowWindow(hMainWnd, SW_SHOWNOACTIVATE);
	}
	return;
}

void ModBoxToggle(void)
{
	if (mbs.Hidden)
		ShowWindow(hMainWnd, SW_SHOWNOACTIVATE);
	else
		ShowWindow(hMainWnd, SW_HIDE);
	mbs.Hidden = !mbs.Hidden;
	return;
}

void ModBoxzOrder(HWND hwnd, char* args)
{
	hwnd=hwnd;
	if (args != NULL && *args && strlen(args)){
		if (atoi(args) == 0 && hDesktopWnd != NULL){
			mbs.zOrder = 0;
			SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
			SetWindowPos(hMainWnd,HWND_BOTTOM,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
			SetParent(hMainWnd, hDesktopWnd);
			SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
		}
		else if (atoi(args) == 2){
			if (!mbs.zOrder && hDesktopWnd != NULL)
				SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
			SetWindowPos(hMainWnd,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
			SetParent(hMainWnd, NULL);
			if (!mbs.zOrder && hDesktopWnd != NULL)
				SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
			mbs.zOrder = 2;
		}else{
			if (!mbs.zOrder && hDesktopWnd != NULL)
				SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
			SetWindowPos(hMainWnd,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOSENDCHANGING);
			SetParent(hMainWnd, NULL);
			if (!mbs.zOrder && hDesktopWnd != NULL)
				SetWindowLong(hMainWnd, GWL_STYLE, (GetWindowLong(hMainWnd, GWL_STYLE) &~ WS_CHILD)|WS_POPUP);
			mbs.zOrder = 1;
		}
	}
	return;
}
