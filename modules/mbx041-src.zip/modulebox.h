#ifndef __MODULEBOX_H_
	#define __MODULEBOX_H_

	struct ModBoxSettings
	{
		COLORREF BgColor, BorderColor;

		int Height, Width, X, Y, BorderSize, zOrder;

		BOOL Hidden;

		HBITMAP BgImage;
	};

	#ifdef __cplusplus
		extern "C" {
	#endif

		__declspec( dllexport ) int initModuleEx(HWND,HINSTANCE,const char *);
		__declspec( dllexport ) void quitModule(HINSTANCE);

	#ifdef __cplusplus
		}
	#endif
#endif