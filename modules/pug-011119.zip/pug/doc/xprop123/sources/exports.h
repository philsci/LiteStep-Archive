#ifndef EXPORTS_H
#define EXPORTS_H

#ifdef __cplusplus
extern "C" {
#endif

/* LOAD MODULE Functions */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

#ifdef __cplusplus
}
#endif

#endif 
