#include <windows.h>

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, int nCmdShow) 
{
    MSG msg; 

	HINSTANCE dllInst = LoadLibrary("lsplaylist.dll");
	if (dllInst)
	{
		int (FAR* InitModule)(HWND, HINSTANCE, LPCSTR);
		int (FAR* QuitModule)(HINSTANCE);
		void (FAR* NoLitestep)();

		InitModule = (int (FAR*)(HWND, HINSTANCE, LPCSTR))GetProcAddress(dllInst, "initModuleEx");
		QuitModule = (int (FAR*)(HINSTANCE))GetProcAddress(dllInst, "quitModule");
		NoLitestep = (void (FAR*)())GetProcAddress(dllInst, "NoLitestep");

		NoLitestep();
		InitModule(NULL, dllInst, ".");

		while (GetMessage(&msg, (HWND) NULL, 0, 0))
		{ 
			TranslateMessage(&msg); 
			DispatchMessage(&msg); 
		}

		QuitModule(dllInst);
	}

	return 0;
}
