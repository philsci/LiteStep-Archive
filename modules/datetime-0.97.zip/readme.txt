"jugg's Date & Time version 0.97"
This is a program in Beta developement. Report bugs to the email address listed at the end of this file.

I'll keep this short and sweet.  I wrote this little program (jugg's date & time) cause I have never been able to find a small simple date and time program that is completely customizable.

Well, so I made one.  The only drawback I can come up with is, that I wrote it in VisualBasic, and it needs the VB6 RunTime files. You can get them at: ftp://ftp.microsoft.com/Softlib/MSLFILES/VBRUN60.EXE 

Other then that, there really isn't much to say.  Oh, you will notice that if you have 'autosize' enabled, that you can not use a skinable background.

Hrm one more thing. To return the Date & Time settings back to the defaults, open up the 'Clock Settings' dialog and click 'Defaults' then leave the dialog, close the program, and restart it.

Also, make sure you set your BMT setting under Settings correctly, otherwise your iTime/Date will not display the right stuff.

The interface is easy enough: left mouse click toggles date/time, left mouse drag moves clock around (if enabled under Settings), right click brings up the popup menu. The rest is basically self explanitory.

My favorite Font to use with this is called "OCR A Extended" at a 12point size  and the file name is "OCRAExt.ttf". I'm not including it at this point, because I'm not sure about the legal stuff with that...

Well as for some legal type of things.

Do what ever the heck you want with this program. Its completely free.

However, you may NOT destribute this program on any media type, floppy, cdrom, or any other form that is being sold at any price.

If you want to include it on a cdrom or some such, please contact me first.

Feel free to give it to your friends, distribute it over the internet, bbs, etc.

However, this readme.txt file must be included intact, as is.


author - (jugg) chris rempel  jugg@earthling.net
http://aster.omega2.com/jugg/