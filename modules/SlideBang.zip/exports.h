#ifndef EXPORTS_H
#define EXPORTS_H

/* LOAD MODULE Functions */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

#endif