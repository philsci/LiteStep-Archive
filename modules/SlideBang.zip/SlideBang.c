#include <windows.h>
#include <commctrl.h>
#include "exports.h"
#include "lsapi.h"

const long magicDWord = 0x49474541;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK SliderProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();

//void BangPulse(HWND caller, char* args);

HWND hwndMain, hwndSlider, parent;
int ScreenX, ScreenY;
char* szAppName = "SlideBang";
char lsdir[MAX_PATH] = "";
int X, Y, W, H;
char** BANGS;
int VALID_BANGS=0;
HBITMAP bgbmp, handlebmp;
int hy, hwidth, hheight;
BOOL VERT=FALSE;
int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

LONG OldSliderProc;

int initModuleEx(HWND hparent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	DWORD dwStyle;

	parent = hparent;
	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
    
	LoadSetup();

	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	X = GetRCInt("SlideBangX", 0);
	if (X < 0) X = ScreenX + X;
	Y = GetRCInt("SlideBangY", 0);
	if (Y < 0) Y = ScreenY + Y;
	W = GetRCInt("SlideBangWidth", 100);
	if (W < 0) W = ScreenX;
	H = GetRCInt("SlideBangHeight", 25);
	if (H < 0) H = ScreenY;
	
	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, 
								WS_POPUP, 
								X, Y, W, H, NULL, NULL, dllInst, 0);
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

	dwStyle = WS_VISIBLE | WS_CHILD | TBS_AUTOTICKS;
	if (GetRCBool("SlideBangVertical", TRUE)) 
	{
		VERT=TRUE;
		dwStyle |= TBS_VERT;
	}
	hwndSlider = CreateWindow("msctls_trackbar32", "Slider", dwStyle, 0, 0, W, H, hwndMain, NULL, dllInst, 0);
	SendMessage(hwndSlider, TBM_SETRANGE, (WPARAM)TRUE, (LPARAM)MAKELONG(0, VALID_BANGS-1));
	OldSliderProc = GetWindowLong(hwndSlider, GWL_WNDPROC);
	SetWindowLong(hwndSlider, GWL_WNDPROC, (LONG)SliderProc);

	if (GetRCBool("SlideBangStartHidden", FALSE))
	{
		ShowWindow(hwndMain, SW_SHOW);
	}

	return 0;
}

int quitModule(HINSTANCE dll)
{
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM)hwndMain, (LPARAM)msgs);

	DestroyWindow(hwndSlider);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, dll);

	free(BANGS);
	DeleteObject(bgbmp);
	DeleteObject(handlebmp);

	//RemoveBangCommand("!AuroraPulse");
	
	return 0;
}

LRESULT CALLBACK SliderProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_LBUTTONUP:
		{
			int ticpos = SendMessage(hwnd, TBM_GETPOS, 0, 0);
			LSExecute(hwnd, BANGS[ticpos], SW_SHOWNORMAL);
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, W, H), oldbufbmp, oldsrcbmp;
			int ticpos = SendMessage(hwnd, TBM_GETPOS, 0, 0);
			int pos = SendMessage(hwnd, TBM_GETTICPOS, (WPARAM)ticpos-1, 0);
			if (pos == -1) 
			{
				if (VERT) pos = H-hheight;
				else pos = W-hwidth;
			}
			
			oldbufbmp = (HBITMAP)SelectObject(buf, bufbmp);

			oldsrcbmp = (HBITMAP)SelectObject(src, bgbmp);
			BitBlt(buf, 0, 0, W, H, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrcbmp);

			oldsrcbmp = (HBITMAP)SelectObject(src, handlebmp);
			if (VERT)
				BitBlt(buf, hy, pos-(hheight/2), hwidth, hheight, src, 0, 0, SRCCOPY);
			else
				BitBlt(buf, pos-(hwidth/2), hy, hwidth, hheight, src, 0, 0, SRCCOPY);
			SelectObject(src, oldsrcbmp);

			BitBlt(hdc, 0, 0, W, H, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbufbmp);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteDC(src);
			EndPaint(hwnd, &ps);
		}
		return 0;
	}

	return CallWindowProc((WNDPROC)OldSliderProc, hwnd, msg, wParam, lParam);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			RECT r;
			GetClientRect(hwnd, &r);
			FillRect(hdc, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));
			EndPaint(hwnd, &ps);
		}
		break;

		case LM_GETREVID:
		{
			LPSTR buf = (LPSTR)(lParam);

			switch (wParam)
			{
				case 0:
					sprintf(buf, "SlideBang 1.0 (MrJukes)\0");
				break;
				case 1:
					sprintf(buf, "SlideBang 1.0 (MrJukes)\0");
				break;
				default:
					sprintf(buf, "SlideBang 1.0 (MrJukes)\0");
			}

			return strlen(buf);
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void LoadSetup()
{
	//AddBangCommand("!AuroraPulse", BangPulse);
	char temp[256] = "";
	FILE* step;
	int x;
	char	token1[4096], token2[4096], extra_text[4096];
	char*	tokens[2];
			
	tokens[0] = token1;
	tokens[1] = token2;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	while (LCReadNextConfig(step, "*SlideBang", temp, 256)) { VALID_BANGS++; }
	LCClose(step);

	BANGS = (char**)malloc(sizeof(char*) * VALID_BANGS);
	for (x=0; x < VALID_BANGS; x++)
	{
		BANGS[x] = (char*)malloc(sizeof(char) * 256);
	}

	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);
	x=0;

	while (LCReadNextConfig(step, "*SlideBang", temp, 256)) 
	{ 
		int count;
		token1[0] = extra_text[0] = '\0';
		count = LCTokenize (temp, tokens, 2, extra_text);

		if (count > 1)
		{
			strcpy(BANGS[x++], token2);
		}
	}
	LCClose(step);

	GetRCString("SlideBangBgBmp", temp, "", 256);
	if (strlen(temp))
		bgbmp = LoadLSImage(temp, temp);
	GetRCString("SlideBangHandleBmp", temp, "", 256);
	if (strlen(temp))
		handlebmp = LoadLSImage(temp, temp);

	if (handlebmp)
	{
		BITMAP bmp;
		GetObject(handlebmp, sizeof(bmp), &bmp);
		hwidth = bmp.bmWidth;
		hheight = bmp.bmHeight;
	}

	hy = GetRCInt("SlideBangHandleY", 5);
}
