#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "exports.h"
#include "lsapi.h"

HINSTANCE hInstance;
HWND hwndMain, hwndDesk;
HMENU popup;
char lsdir[MAX_PATH] = "";

int ScreenX, ScreenY;

BOOL HOS=FALSE, AOT=FALSE;
HBITMAP bg;

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
//void BangHide(HWND caller, char* args);
//void BangShow(HWND caller, char* args);
//void BangToggle(HWND caller, char* args);
void HorkWindows();


int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	WNDCLASS wc;

	hInstance=dll;
	strcpy(lsdir, szPath);

	memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc = WndProc;
    wc.hInstance = dll;
	wc.lpszClassName = "ModHork";
	RegisterClass(&wc);

	//AddBangCommand("!ModHorkHide", BangHide);
	//AddBangCommand("!ModHorkShow", BangShow);
	//AddBangCommand("!ModHorkToggle", BangToggle);
	
	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, 100, "&About ModHork");

	hwndDesk = FindWindow("DesktopBackgroundClass", NULL);
	if (!hwndDesk) hwndDesk = GetDesktopWindow();
	
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	HorkWindows();
	
	return 0;
}

int quitModule(HINSTANCE dll)
{
	HWND hwnd;

	DestroyMenu(popup);
	
	//RemoveBangCommand("!ModHorkHide");
	//RemoveBangCommand("!ModHorkShow");
	//RemoveBangCommand("!ModHorkToggle");

	while ((hwnd = FindWindow("ModHork", NULL)))
	{
		RemoveProp(hwnd, "BG");
		DestroyWindow(hwnd);
	}
	
	UnregisterClass("ModHork", dll);

	return 0;
}

/*void BangHide(HWND caller, char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangShow(HWND caller, char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangToggle(HWND caller, char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}*/

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCHITTEST: return HTCAPTION;

		case WM_NCPAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HDC src = CreateCompatibleDC(NULL);
			HBITMAP bufbmp, oldbuf;
			HBITMAP bg = (HBITMAP)GetProp(hwnd, "BG"), oldsrc;
			RECT r;
			
			GetClientRect(hwnd, &r);
			bufbmp = CreateCompatibleBitmap(hdc, r.right, r.bottom);
			oldbuf = (HBITMAP)SelectObject(buf, bufbmp);

			FillRect(buf, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));
			oldsrc = (HBITMAP)SelectObject(src, bg);
			BitBlt(buf, 0, 0, r.right, r.bottom, src, 0, 0, SRCCOPY);

			BitBlt(hdc, 0, 0, r.right, r.bottom, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteObject(bufbmp);
			DeleteDC(buf);
			DeleteObject(oldbuf);
			SelectObject(src, oldsrc);
			DeleteDC(src);
			DeleteObject(oldsrc);
			EndPaint(hwnd, &ps);
		}
		break;
	}

	return DefWindowProc(hwnd, msg, wParam, lParam);
}

void HorkWindows()
{
	FILE* step;
	char temp[256] = "";
	char    token1[4096], token2[4096], token3[4096], extra_text[4096];
	char    token4[4096], token5[4096], token6[4096];
	char    token7[4096], token8[4096];
	char*   tokens[8];
	int X, Y, W, H;

	tokens[0] = token1;
	tokens[1] = token2;
	tokens[2] = token3;
	tokens[3] = token4;
	tokens[4] = token5;
	tokens[5] = token6;
	tokens[6] = token7;
	tokens[7] = token8;
	
	sprintf(temp, "%s\\step.rc", lsdir);
	step = LCOpen(temp);

	while (LCReadNextConfig(step, "*ModHork", temp, 256))
	{
		int count = LCTokenize (temp, tokens, 8, extra_text);
		HWND hwnd;
		HBITMAP bg=NULL;

		hwndMain=NULL;
		AOT=FALSE;
		HOS=FALSE;

		if (count >= 5)
		{
			X = atoi(token2);
			if (X < 0) X = ScreenX + X;
			else if (!X && token2[0] == '-') X = ScreenX;
			Y = atoi(token3);
			if (Y < 0) Y = ScreenY + Y;
			else if (!Y && token3[0] == '-') Y = ScreenY;
			W = atoi(token4);
			H = atoi(token5);

			if (count >= 6) // Got Background
			{
				bg = LoadLSImage(token6, token6);

				if (count >= 7) // AlwaysOnTop
				{
					if (token7[0] == '1') AOT=TRUE;

					if (count >= 8) // StartHidden
					{
						if (token8[0] == '1') HOS=TRUE;
					}
				}
			}

			hwndMain = CreateWindow("ModHork", "ModHork", WS_POPUP, X, Y, W, H, hwndDesk, NULL, hInstance, 0);
			if (hwndMain)
			{
				if (AOT) SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
				SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
				if (bg) SetProp(hwndMain, "BG", (HANDLE)bg);
				if (!HOS) ShowWindow(hwndMain, SW_SHOW);
			}

			while (1 && !feof(step))
			{
				LCReadNextLine(step, temp, 256);
				if (!_strnicmp(temp, "~ModHork", 8)) break;

				count = LCTokenize (temp, tokens, 7, extra_text);
				if (count >= 2) // Need class
				{
					if (count >= 3) // Got text
					{
						if (strlen(token3))
							hwnd = FindWindow(token2, token3);
						else
							hwnd = FindWindow(token2, NULL);
					}
					else
					{
						hwnd = FindWindow(token2, NULL);
					}

					if (hwnd)
					{
						int MW=0, MH=0;
						RECT r;

						X=0;
						Y=0;

						GetWindowRect(hwnd, &r);
						MW=r.right-r.left;
						MH=r.bottom-r.top;

						if (count >= 4) // X
						{
							X = atoi(token4);
							if (X < 0) X = W + X;
							else if (!X && token4[0] == '-') X = W;

							if (count >= 5) // Y
							{
								Y = atoi(token5);
								if (Y < 0) Y = H + Y;
								else if (!Y && token5[0] == '-') Y = H;

								if (count >= 6) // W
								{
									MW = atoi(token6);
									if (count >= 7) MH = atoi(token7);
								}
							}
						}

						SetParent(hwnd, hwndMain);
						SetWindowPos(hwnd, 0, X, Y, MW, MH, SWP_NOZORDER);
					}
				}
			}
		}
	}

	LCClose(step);
}