#include <windows.h>
#include <time.h>
#include "exports.h"
#include "lsapi.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void LoadSetup();
void MoveSnake();
void ResetGridArray();
void ResetRockArray();
void ResetStayArray();
void UpdateGridArray();
void UpdateRockArray();
void UpdateStayArray();

void BangHide(HWND caller, char* args);
void BangShow(HWND caller, char* args);
void BangToggle(HWND caller, char* args);
void BangFocus(HWND caller, char* args);

enum DIR { UP=1, DOWN, LEFT, RIGHT } DIRECTION;

HINSTANCE hInstance;
HWND hwndMain;
char* szAppName = "LSSnake";
int X, Y, W, H, NumX, NumY;
int SCORE=0, LENGTH=1, FOOD_POINTS=0, HIGHSCORE=0, SPEED=500, BLOCKSIZE=4;
int ScreenX, ScreenY;

int** GRID;
int** STAY;
int** ROCK;
int FoodX=-1, FoodY=-1;
int hx=5, hy=5;

BOOL ADD=FALSE, GAMEON=FALSE, LOSE=FALSE, START_HIDDEN=FALSE, ENABLE_ROCKS=TRUE;
HBRUSH SNAKE_BRUSH=NULL, BG_BRUSH=NULL, FOOD_BRUSH=NULL, ROCK_BRUSH=NULL;
COLORREF TEXT_COLOR=0;

int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
	return initModuleEx(parent, dll, wd->lsPath);
}

int initModule(HWND parent, HINSTANCE dll, wharfDataType *wd)
{
  return initModuleEx(parent, dll, wd->lsPath);
}

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASS wc;
	hInstance = dllInst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;       // our window procedure
	wc.hInstance = dllInst;         // hInstance of DLL
	wc.lpszClassName = szAppName;   // our window class name
	
	if (!RegisterClass(&wc)) 
	{
		MessageBox(parent, "Error registering window class", szAppName, MB_OK);
		return 1;
	}
	
	LoadSetup();

	hwndMain = CreateWindowEx(WS_EX_TOOLWINDOW, szAppName, szAppName, (START_HIDDEN)? 0 : WS_VISIBLE | WS_POPUP, X, Y, W, H, NULL, NULL, dllInst, 0);
	SetWindowLong(hwndMain, GWL_USERDATA, magicDWord);
	
	return 0;
}

int quitWharfModule(HINSTANCE dll)
{
	return quitModule(dll);
}

int quitModule(HINSTANCE dll)
{
	RemoveBangCommand("!LSSnakeHide");
	RemoveBangCommand("!LSSnakeShow");
	RemoveBangCommand("!LSSnakeToggle");
	RemoveBangCommand("!LSSnakeFocus");
	
	KillTimer(hwndMain, 0);
	DestroyWindow(hwndMain);
	UnregisterClass(szAppName, hInstance);
	DeleteObject(SNAKE_BRUSH);
	DeleteObject(BG_BRUSH);
	DeleteObject(FOOD_BRUSH);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_NCHITTEST: return HTCAPTION;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, W, H);
			RECT cr;
			int x, y;
			char temp[100] = "";
			
			SelectObject(buf, bufbmp);
			GetClientRect(hwnd, &cr);
			FillRect(buf, &cr, BG_BRUSH);

			// Draw the score
			SetBkMode(buf, TRANSPARENT);
			SetTextColor(buf, TEXT_COLOR);
			SetRect(&cr, 0, H-15, W, H);
			sprintf(temp, "Score: %d", SCORE);
			DrawText(buf, temp, strlen(temp), &cr, DT_LEFT);

			// Draw the snake
			for (y=0; y < NumY; y++)
			{
				for (x=0; x < NumX; x++)
				{
					if (GRID[x][y] || (x == hx && y == hy))
					{
						SetRect(&cr, x*BLOCKSIZE, y*BLOCKSIZE, (x*BLOCKSIZE)+BLOCKSIZE, (y*BLOCKSIZE)+BLOCKSIZE);
						FillRect(buf, &cr, SNAKE_BRUSH);
					}
					else if (ROCK[x][y])
					{
						SetRect(&cr, x*BLOCKSIZE, y*BLOCKSIZE, (x*BLOCKSIZE)+BLOCKSIZE, (y*BLOCKSIZE)+BLOCKSIZE);
						FillRect(buf, &cr, ROCK_BRUSH);
					}
				}
			}

			// Draw the food
			SetRect(&cr, FoodX*BLOCKSIZE, FoodY*BLOCKSIZE, (FoodX*BLOCKSIZE)+BLOCKSIZE, (FoodY*BLOCKSIZE)+BLOCKSIZE);
			FillRect(buf, &cr, FOOD_BRUSH);

			if (LOSE) 
			{
				GetClientRect(hwnd, &cr);
				HIGHSCORE = GetProfileInt("LSSnake", "HighScore", 0);
				if (SCORE > HIGHSCORE)
				{
					sprintf(temp, "%d", SCORE);
					WriteProfileString("LSSnake", "HighScore", temp);
					HIGHSCORE=SCORE;
				}
				sprintf(temp, "LSSnake v1.3\r\n\r\nLength:\r\n%d\r\nScore:\r\n%d\r\nHigh Score:\r\n%d", LENGTH, SCORE, HIGHSCORE);
				DrawText(buf, temp, strlen(temp), &cr, DT_CENTER);
			}

			BitBlt(hdc, 0, 0, W, H, buf, 0, 0, SRCCOPY);

			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hwnd, &ps);
			DeleteDC(hdc);
		}
		break;

		case WM_WINDOWPOSCHANGING:
		{
			WINDOWPOS* pos = (WINDOWPOS*)lParam;
				
			if (!(pos->flags & SWP_NOMOVE))
			{
				if (pos->x+W >= ScreenX-5) pos->x = ScreenX - W;
				else if (pos->x <= 5) pos->x = 0;
				if (pos->y+H >= ScreenY-5) pos->y = ScreenY - H;
				else if (pos->y <= 5) pos->y = 0;
			}
		}
		break;

		case WM_KEYDOWN:
		{
			switch ((int)wParam)
			{
				case VK_UP:
				{
					DIRECTION=UP;
				}
				break;

				case VK_DOWN:
				{
					DIRECTION=DOWN;
				}
				break;

				case VK_LEFT:
				{
					DIRECTION=LEFT;
				}
				break;

				case VK_RIGHT:
				{
					DIRECTION=RIGHT;
				}
				break;

				case VK_RETURN:
				{
					if (GAMEON)
					{
						GAMEON=FALSE;
						KillTimer(hwnd, 0);
					}
					else
					{
						GAMEON=TRUE;
						if (LOSE)
						{
							ResetGridArray();
							if (ENABLE_ROCKS)
							{
								ResetRockArray();
								UpdateRockArray();
							}
							hx = rand() % NumX;
							hy = rand() % NumY;
							DIRECTION = (rand()%4) + 1;
							GRID[hx][hy] = DIRECTION;
							LOSE=FALSE;
							SCORE=0;
							LENGTH=1;
							FOOD_POINTS = NumX * LENGTH;
						}
						SetTimer(hwnd, 0, SPEED, NULL);
					}
				}
				break;
			}
		}
		break;

		case WM_TIMER:
		{
			MoveSnake();
			FOOD_POINTS--;
			if (FOOD_POINTS < 1) FOOD_POINTS=1;
			InvalidateRect(hwndMain, NULL, TRUE);
		}
		break;

		case WM_KILLFOCUS:
		{
			GAMEON=FALSE;
			KillTimer(hwnd, 0);
		}
		break;
	}

	return DefWindowProc(hwnd,msg, wParam,lParam);
}

void LoadSetup()
{
	int c;
	COLORREF tempcolor=0;
	
	ScreenX = GetSystemMetrics(SM_CXSCREEN);
	ScreenY = GetSystemMetrics(SM_CYSCREEN);

	X = GetRCInt("LSSnakeX", 0);
	Y = GetRCInt("LSSnakeY", 0);
	W = GetRCInt("LSSnakeWidth", 100);
	H = GetRCInt("LSSnakeHeight", 100);
	SPEED = GetRCInt("LSSnakeSpeed", 500);
	BLOCKSIZE = GetRCInt("LSSnakeBlockSize", 4);

	START_HIDDEN = GetRCBool("LSSnakeStartHidden", TRUE);
	ENABLE_ROCKS = GetRCBool("LSSnakeEnableRocks", TRUE);

	AddBangCommand("!LSSnakeHide", BangHide);
	AddBangCommand("!LSSnakeShow", BangShow);
	AddBangCommand("!LSSnakeToggle", BangToggle);
	AddBangCommand("!LSSnakeFocus", BangFocus);
	
	NumX = W / BLOCKSIZE;
	NumY = H / BLOCKSIZE;

	GRID = (int**)malloc(sizeof(int*) * NumX);
	STAY = (int**)malloc(sizeof(int*) * NumX);
	ROCK = (int**)malloc(sizeof(int*) * NumX);
	for (c=0; c < NumX; c++)
	{
		GRID[c] = (int*)malloc(sizeof(int) * NumY);
		STAY[c] = (int*)malloc(sizeof(int) * NumY);
		ROCK[c] = (int*)malloc(sizeof(int) * NumY);
	}

	ResetGridArray();
	ResetStayArray();
	
	if (ENABLE_ROCKS)
	{
		ResetRockArray();
		UpdateRockArray();
	}

	hx = rand() % NumX;
	hy = rand() % NumY;
	DIRECTION = (rand()%4) + 1;
	GRID[hx][hy] = DIRECTION;

	srand(time(NULL));
	FoodX = rand() % NumX;
	FoodY = rand() % NumY;
	FOOD_POINTS = NumX * LENGTH;

	tempcolor = GetRCColor("LSSnakeSnakeColor", 0x00000000);
	SNAKE_BRUSH = CreateSolidBrush(tempcolor);
	tempcolor = GetRCColor("LSSnakeBgColor", 0x00FFFFFF);
	BG_BRUSH = CreateSolidBrush(tempcolor);
	tempcolor = GetRCColor("LSSnakeFoodColor", 0x00C0C0C0);
	FOOD_BRUSH = CreateSolidBrush(tempcolor);
	tempcolor = GetRCColor("LSSnakeRockColor", 0x00404040);
	ROCK_BRUSH = CreateSolidBrush(tempcolor);
	TEXT_COLOR = GetRCColor("LSSnakeTextColor", 0x00FFFFFF);
}

void MoveSnake()
{
	UpdateStayArray();
	UpdateGridArray();
}

void ResetGridArray()
{
	int x, y;
	for (y=0; y < NumY; y++)
	{
		for (x=0; x < NumX; x++)
		{
			GRID[x][y] = 0;
		}
	}
}

void ResetRockArray()
{
	int x, y;
	for (y=0; y < NumY; y++)
	{
		for (x=0; x < NumX; x++)
		{
			ROCK[x][y] = 0;
		}
	}
}

void ResetStayArray()
{
	int x, y;
	for (y=0; y < NumY; y++)
	{
		for (x=0; x < NumX; x++)
		{
			STAY[x][y] = 0;
		}
	}
}

void UpdateStayArray()
{
	int x, y;
	for (y=0; y < NumY; y++)
	{
		for (x=0; x < NumX; x++)
		{
			if (GRID[x][y])
			{
				if ((x-1) < 0)
				{
					if (GRID[x+1][y] == LEFT ||
					GRID[x][y-1] == DOWN ||
					GRID[x][y+1] == UP) STAY[x][y] = 1;
					else if (ADD)
					{
						ADD=FALSE;
						STAY[x][y] = 1;
					}
				}
				else if ((x+1) >= NumX)
				{
					if (GRID[x-1][y] == RIGHT ||
					GRID[x][y-1] == DOWN ||
					GRID[x][y+1] == UP) STAY[x][y] = 1;
					else if (ADD)
					{
						ADD=FALSE;
						STAY[x][y] = 1;
					}
				}
				else if ((y-1) < 0)
				{
					if (GRID[x-1][y] == RIGHT ||
					GRID[x+1][y] == LEFT ||
					GRID[x][y+1] == UP) STAY[x][y] = 1;
					else if (ADD)
					{
						ADD=FALSE;
						STAY[x][y] = 1;
					}
				}
				else if ((y+1) >= NumY)
				{
					if (GRID[x-1][y] == RIGHT ||
					GRID[x+1][y] == LEFT ||
					GRID[x][y-1] == DOWN ) STAY[x][y] = 1;
					else if (ADD)
					{
						ADD=FALSE;
						STAY[x][y] = 1;
					}
				}
				else
				{
					if (GRID[x-1][y] == RIGHT ||
					GRID[x+1][y] == LEFT ||
					GRID[x][y-1] == DOWN ||
					GRID[x][y+1] == UP) STAY[x][y] = 1;
					else if (ADD)
					{
						ADD=FALSE;
						STAY[x][y] = 1;
					}
				}
			}
		}
	}
}

void UpdateRockArray()
{
	int total = rand() % NumX;
	int count;

	for (count=0; count < total; count++)
	{
		ROCK[rand() % NumX][rand() % NumY] = 1;
	}
}

void UpdateGridArray()
{
	int x, y;
	for (y=0; y < NumY; y++)
	{
		for (x=0; x < NumX; x++)
		{
			if (!STAY[x][y])
			{
				GRID[x][y] = 0;
			}
			STAY[x][y]=0;
		}
	}

	GRID[hx][hy] = DIRECTION;

	switch (DIRECTION)
	{
		case UP: hy--; break;
		case DOWN: hy++; break;
		case LEFT: hx--; break;
		case RIGHT: hx++; break;
	}

	if (hx < 0 || hx >= NumX || hy < 0 || hy >= NumY
		|| GRID[hx][hy] || ROCK[hx][hy])
	{
		GAMEON=FALSE;
		KillTimer(hwndMain, 0);
		LOSE=TRUE;
		return;
	}
	
	if (hx == FoodX && hy == FoodY) 
	{
		ADD=TRUE;
		SCORE += FOOD_POINTS;
		LENGTH++;
		FOOD_POINTS = NumX * LENGTH;

		do
		{
			FoodX = rand() % NumX;
			FoodY = rand() % NumY;
		} while (GRID[FoodX][FoodY] || ROCK[FoodX][FoodY]);
	}
}

void BangHide(HWND caller, char* args) { ShowWindow(hwndMain, SW_HIDE); }
void BangShow(HWND caller, char* args) { ShowWindow(hwndMain, SW_SHOW); }
void BangToggle(HWND caller, char* args)
{
	if (IsWindowVisible(hwndMain)) BangHide(caller, args);
	else BangShow(caller, args);
}

void BangFocus(HWND caller, char* args) 
{ 
	SetForegroundWindow(hwndMain);
	SetActiveWindow(hwndMain);
	SetFocus(hwndMain); 
}
