#ifndef __WHARF_H
#define __WHARF_H

#include <vector>
#include "../litestep/wharfdata.h"

#define WHARF_UP                0
#define WHARF_DOWN              1
#define WHARF_LEFT              2
#define WHARF_RIGHT             3

#define WHARF_CLOSEFOLDERS		10

// forward decl
class wharfTileType;
class wharfType;

typedef std::vector< wharfTileType* > WharfTileVector;

class wharfFolderType
{
	wharfTileType *parent;

public:
	wharfFolderType(wharfTileType *p, int TileWidth, int TileHeight, int Direction);
	~wharfFolderType();

	BOOL Create(FILE *file);
	void ParseData(FILE *file);
	void Execute();
	void CloseAllFolders();
	BOOL PartOfWharf(HWND myWnd);
	void OnActivate(Message &message);
	void OnTimer(Message &message);

	HWND hMainWnd;
	HRGN hMainRgn;
	int width;
	int height;
	int tileWidth;
	int tileHeight;
	int numWharfs;
	int direction;
	BOOL open;
	BOOL moving;
	BOOL closing;
	int movingPos;

	WharfTileVector wharfs;
};

class wharfTileType
{
public:
	wharfTileType(HWND pWnd, HRGN pRgn, LPCSTR name, LPCSTR command, LPCSTR params, LPCSTR image, LPCSTR imageParams, BOOL showBack, BOOL noTrans, int Width, int Height, int xPos, int yPos, int Direction, BOOL InFolder);
	~wharfTileType();

	BOOL Create(FILE *file, LPCSTR szWindowName);
	void Execute();
	HBITMAP AddImage(HDC dst, HDC src, HBITMAP image);
	void TogglePressOffset(BOOL bToggle);
	void AnimateOpen();
	void AnimateClose();
	void PaintTitle(HDC hdc, HDC src);
	void OnActivate(Message &message);
	void OnMouseMove(Message &message);
	void OnPaint(Message &message);
	void OnLButtonDown(Message &message);
	void OnLButtonUp(Message &message);
	void OnTimer(Message &message);

	HINSTANCE hInst;
	HWND hWnd;
	HWND taskWnd;
	HWND parentWnd;
	HBITMAP backImage;
	HBITMAP frontImage;
	LPSTR szName;
	LPSTR szCommand;
	LPSTR szParameters;
	int width;
	int height;
	int inWharfX;
	int inWharfY;
	int direction;
	BOOL showbg;
	BOOL isOpaque;
	BOOL bPressed;
	BOOL bTogglePressed;
	BOOL inFolder;
	int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
	int (FAR *quitWharfModule)(HINSTANCE);
	HRGN (FAR *GetLSRegion)(int, int);
	HRGN parentRgn;

	wharfFolderType *folder;
};

class wharfHiddenType
{
	wharfType *parent;

public:
	wharfHiddenType(wharfType *p);
	~wharfHiddenType();

	BOOL Create();
	void OnDisplayChange(Message &message);
	void OnPaint(Message &message);
	void OnTimer(Message &message);

	HWND HiddenWnd;
	BOOL hideTimerActive;
	BOOL showTimerActive;
};

class wharfType
{
public:
	wharfType(HWND parent, LPCSTR name, int xPos, int yPos, int TileWidth, int TileHeight, int Direction);
	~wharfType();

	BOOL Create(FILE *file);
	void ParseData(FILE *file);
	void Show();
	void Hide();
	void Move(LPCSTR arg1, LPCSTR arg2, BOOL moveTo);
	void AnimateOpen();
	void AnimateClose();
	void CloseAllFolders();
	BOOL PartOfWharf(HWND myWnd);
	void OnActivate(Message &message);
	void OnDisplayChange(Message &message);
	void OnMove(Message &message);
	void OnShadeToggle(Message &message);
	void OnNCHitTest(Message &message);
	void OnNCLButtonDblClick(Message &message);
	void OnPaint(Message &message);
	void OnPosChanging(Message &message);
	void OnTimer(Message &message);

	HWND hMainWnd;
	HWND parentWnd;
	HRGN hMainRgn;
	int x;
	int y;
	int width;
	int height;
	int tileWidth;
	int tileHeight;
	LPSTR szName;
	int direction;
	int docked;
	int numWharfs;
	int movingPos;
	BOOL open;
	BOOL moving;
	BOOL closing;
	BOOL visible;

	wharfHiddenType *HiddenWharf;
	WharfTileVector wharfs;
};

typedef std::vector< wharfType* > WharfVector;

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif