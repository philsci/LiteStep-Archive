#ifdef __cplusplus
extern "C" {
#endif

  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif
