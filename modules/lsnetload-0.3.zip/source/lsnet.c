/**
 * Litestep Net Load Meter
 * LsNetLoad.dll
 * 
 * Relies heavily on the code for lscpu...
 * 
 * Peter Grimm
 * pmg23@columbia.edu
 **/

#ifdef UNICODE
#ifndef _UNICODE
#define _UNICODE
#endif
#define tmain wmain
#else
#define tmain main
#endif

#define WIN32_LEAN_AND_MEAN 1

#include <windows.h>
#include <winperf.h>
#include <malloc.h>
#include <stdio.h>
#include <tchar.h>
#include <pdh.h>
#include <string.h>

#include "D:\LiteStep\source\litestep\lsapi\lsapi.h"
#include "C:\Program Files\Microsoft Visual Studio\MyProjects\LsNetLoad\blah.h"

char szAppName[] = "LsNetLoad"; // Name of Application, Window class...

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client

//DWORD Reserved,dataType,dataLen=8192;
//char dataUp[8192]; // Buffer to communicate with registry. (way bigger than neeeded)
//char dataDown[8192];

HKEY perfKey;		// Registry key to get cpu usage
HKEY startPerfKey;	// Registry key to start cpu usage moinitoring

char upHistory[64];	// history of last n seconds
char downHistory[64];

BOOL init=FALSE;	// Monitor started ?
int width=0;		// Width of monitor (= size of history)

int pointer=0;		// pointer on the rotating history

// Triple buffering
HDC hdcBuffer1 = NULL;
HBITMAP bitmapBuffer1 = NULL;
HDC hdcBuffer2 = NULL;
HBITMAP bitmapBuffer2 = NULL;

// Performance Data Helper Variables
PDH_STATUS pdhStatus = ERROR_SUCCESS;
LPTSTR szCounterListBuffer = NULL;
DWORD dwCounterListBuffer = 0;
LPSTR szInstanceListBuffer = NULL;
DWORD dwInstanceListBuffer = 0;
LPSTR szThisInstance = NULL;

// Performance Variables for the Download Speed
HQUERY netLoadDownQuery;
HCOUNTER netLoadDownCounter;
PDH_FMT_COUNTERVALUE netLoadDown;

// Performance Variables for the Upload Speed
HQUERY netLoadUpQuery;
HCOUNTER netLoadUpCounter;
PDH_FMT_COUNTERVALUE netLoadUp;

// Font Information
HFONT font;
int fontSize;
CHAR fontName[256];
CHAR outText[40];
CHAR inText[40];
CHAR inTextLabel[40];
CHAR outTextLabel[40];
BOOL dontDrawText;
int leftTextXOffset;
int rightTextXOffset;
int inTextYOffset;
int outTextYOffset;
COLORREF textColor;
COLORREF inTextLabelColor;
COLORREF outTextLabelColor;
COLORREF inTextColor;
COLORREF outTextColor;

// Customizable Colors
COLORREF gridColor;
COLORREF backColor;
COLORREF upForeColor;
COLORREF downForeColor;
COLORREF northWestBevelColor;
COLORREF southEastBevelColor;

// Geometry Data Variables
int verticalGridLines;
int horizontalGridLines;
int maxNetSpeed;
int refreshDelay;
int borderSize;
int moduleXOffset;
int moduleYOffset;
BOOL scrollingGrid;
BOOL isModem;
BOOL isTransparent;
BOOL dontDrawGrid;
BOOL dontDrawBevel;

long currentUpValue=0;
long currentDownValue=0;
CHAR networkAdapterCurrent1[512];
CHAR networkAdapterCurrent2[512];
CHAR networkAdapter[256];

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	memset(networkAdapterCurrent1, 0, 512);
	memset(networkAdapterCurrent2, 0, 512);
	memset(networkAdapter, 0, 256);
	memset(fontName,0,256);
	memset(inTextLabel,0,40);
	memset(outTextLabel,0,40);
	
	dontDrawText      = GetRCBool("LSNetLoadNoText", TRUE);
	GetRCString("LSNetLoadInLabel", inTextLabel,"i:",40);
	GetRCString("LSNetLoadOutLabel", outTextLabel,"o:",40);
	leftTextXOffset   = GetRCInt("LSNetLoadLeftTextXOffset",3);
	rightTextXOffset  = GetRCInt("LSNetLoadRightTextXOffset",3);
	inTextYOffset     = GetRCInt("LSNetLoadInTextYOffset",1);
	outTextYOffset    = GetRCInt("LSNetLoadOutTextYOffset",15);
	textColor         = GetRCColor("LSNetLoadTextColor", 0xFFAA80);
	inTextLabelColor  = GetRCColor("LSNetLoadInTextLabelColor",textColor);
	outTextLabelColor = GetRCColor("LSNetLoadOutTextLabelColor",textColor);
	inTextColor       = GetRCColor("LSNetLoadInTextColor",textColor);
	outTextColor      = GetRCColor("LSNetLoadOutTextColor",textColor);
	fontSize          = GetRCInt("LSNetLoadFontSize", 10);
	GetRCString("LSNetLoadFont",fontName, "Comic Sans MS", 256);
	font = CreateFont(fontSize,0,0,0,0,0,0,0,0,0,0,0,0,fontName);

	isModem             = GetRCBool("LSNetLoadModem", TRUE);
	isTransparent       = GetRCBool("LSNetLoadTransparent", TRUE);
	dontDrawGrid        = GetRCBool("LSNetLoadNoGrid", TRUE);
	dontDrawBevel       = GetRCBool("LSNetLoadNoBevel", TRUE);
	gridColor           = GetRCColor("LSNetLoadGridColor", 0x900000);
	backColor           = GetRCColor("LSNetLoadBackColor", 0x500000);
	upForeColor         = GetRCColor("LSNetLoadUpColor", 0x00FF00);
	downForeColor       = GetRCColor("LSNetLoadDownColor", 0xFF0000);
	northWestBevelColor = GetRCColor("LSNetLoadNWBevelColor", 0x000000);
	southEastBevelColor = GetRCColor("LSNetLoadSEBevelColor", 0xFFFFFF);
	scrollingGrid       = GetRCBool("LSNetLoadScrollingGrid", TRUE);
	
	maxNetSpeed = GetRCInt("LSNetLoadMaxSpeed",10000);
	if(maxNetSpeed<1) maxNetSpeed = 10000;
	
	refreshDelay = GetRCInt("LSNetLoadRefreshDelay",1000);
	if(refreshDelay<10) refreshDelay = 10;
	
	verticalGridLines = GetRCInt("LSNetLoadVerticalGridLines",4);
	if(verticalGridLines<0)verticalGridLines=0;
	horizontalGridLines = GetRCInt("LSNetLoadHorizontalGridLines",4);
	if(horizontalGridLines<0)horizontalGridLines=0;
	
	borderSize = GetRCInt("LSNetLoadBorderSize",4);
	if(borderSize<-1) borderSize=-1;
    
	moduleXOffset = GetRCInt("LSNetLoadXOffset",borderSize);
	moduleYOffset = GetRCInt("LSNetLoadYOffset",borderSize);
	
	networkAdapterCurrent1[0] = '\\';
	networkAdapterCurrent2[0] = '\\';
	if(!isModem){
		GetRCString("LSNetLoadInterface",networkAdapter, "PCI Bus Master Adapter", 256);
		strcat(networkAdapterCurrent1,"Network Interface(");
		strcat(networkAdapterCurrent2,"Network Interface(");
		strcat(networkAdapterCurrent1,networkAdapter);
		strcat(networkAdapterCurrent2,networkAdapter);
		strcat(networkAdapterCurrent1,")\\Bytes Sent/sec");
		strcat(networkAdapterCurrent2,")\\Bytes Received/sec");
		}
	else{
		GetRCString("LSNetLoadInterface",networkAdapter, "COM2", 256);
		strcat(networkAdapterCurrent1,"RAS Port(");
		strcat(networkAdapterCurrent2,"RAS Port(");
		strcat(networkAdapterCurrent1,networkAdapter);
		strcat(networkAdapterCurrent2,networkAdapter);
		strcat(networkAdapterCurrent1,")\\Bytes Transmitted/Sec");
		strcat(networkAdapterCurrent2,")\\Bytes Received/Sec");
		}

	//pdhStatus = PdhAddCounter(netLoadUpQuery,"\\Processor(0)\\% Processor Time",0,&netLoadUpCounter);
	pdhStatus = PdhOpenQuery(NULL,0,&netLoadUpQuery);
	pdhStatus = PdhAddCounter(netLoadUpQuery,networkAdapterCurrent1,0,&netLoadUpCounter);

	//pdhStatus = PdhAddCounter(netLoadDownQuery,"\\Processor(1)\\% Processor Time",1,&netLoadDownCounter);
	pdhStatus = PdhOpenQuery(NULL,1,&netLoadDownQuery);
	pdhStatus = PdhAddCounter(netLoadDownQuery,networkAdapterCurrent2,1,&netLoadDownCounter);

	if(pdhStatus!=ERROR_SUCCESS){
		MessageBox(parent,"Please specify the network interface to capture data from.", szAppName,MB_OK);
		return 1;
	}
	

    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;

	memset(upHistory, 0, 64); // initialize history to 0
	memset(downHistory, 0, 64);

    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }


    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

	SetTimer(hMainWnd, 0, refreshDelay, NULL); // Set a timer for cpu monitor
	
	//Find the appropriate 

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
	KillTimer(hMainWnd, 0);
	DestroyWindow(hMainWnd);                // delete our window
	
	pdhStatus = PdhCloseQuery(&netLoadUpQuery); // close queries
	pdhStatus = PdhCloseQuery(&netLoadDownQuery);
    
	//delete buffers...

	UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{
				
                PAINTSTRUCT ps;
                RECT r;
                //HDC hdc = BeginPaint(hwnd,&ps);
				HDC hdc =NULL;
				HBRUSH brush;
				HPEN pen, oldpen;
				int i, j;

				hdc = BeginPaint(hwnd,&ps);
                
				if(!init){//store contents beneath us in buffer1
					//hbrBackground =NULL;
					bitmapBuffer1=CreateCompatibleBitmap(hdc,64-2*borderSize,64-2*borderSize);
					hdcBuffer1=CreateCompatibleDC(hdc);
					SelectObject(hdcBuffer1,bitmapBuffer1);
					BitBlt(hdcBuffer1,0,0,64-2*borderSize,64-2*borderSize,hdc,borderSize,borderSize,SRCCOPY);
					
					bitmapBuffer2=CreateCompatibleBitmap(hdc,64-2*borderSize,64-2*borderSize);
					hdcBuffer2=CreateCompatibleDC(hdc);
					SelectObject(hdcBuffer2,font);
					}
				SelectObject(hdcBuffer2,bitmapBuffer2);
				SelectObject(hdcBuffer1,bitmapBuffer1);
				BitBlt(hdcBuffer2,0,0,64-2*borderSize,64-2*borderSize,hdcBuffer1,0,0,SRCCOPY);
				
                
				//  ********* network module drawing ********


                // Get client rect of our window
				GetClientRect(hwnd,&r);

				// contract rect used by 4 pixels
				r.top += (borderSize+1);
				r.bottom -= (borderSize+1);
				r.left += (borderSize+1);
				r.right -= (borderSize+1);

				width = 64-2*borderSize; // Width of monitor

				

				// Paint monitor background
				if(!isTransparent){
					int top,bottom,right,left;
					top=r.top;r.top=1;
					bottom=r.bottom;r.bottom=width-2;
					left=r.left;r.left=1;
					right=r.right;r.right=width-2;
					
					brush = CreateSolidBrush(backColor);
					FillRect(hdcBuffer2, &r, brush);
					DeleteObject(brush);

					r.top=top;
					r.bottom=bottom;
					r.left=left;
					r.right=right;
					}

				// Draw grid
				if(!dontDrawGrid){
					pen = CreatePen(PS_SOLID, 1, gridColor);
					oldpen = SelectObject(hdcBuffer2, pen);
					
					for (i=1;i<horizontalGridLines;i++)//horizontal grid lines
						{
						MoveToEx(hdcBuffer2, 1      , 1 + i*(width-2)/(horizontalGridLines), NULL);
						LineTo  (hdcBuffer2, width-2, 1 + i*(width-2)/(horizontalGridLines));
						}

					if(scrollingGrid){//vertical grid lines
							for (i=0;i<verticalGridLines;i++){
								int column = ((i*(width-2)/(verticalGridLines))-pointer+width-2)%(width-2);
								//if(column<0) column+=width-2-column;
								MoveToEx(hdcBuffer2, 1 + column, 1, NULL);
								LineTo  (hdcBuffer2, 1 + column, width-2);
								}
						}

					else{
						for (i=0;i<verticalGridLines;i++)
							{
							MoveToEx(hdcBuffer2, 1+ ((i*(width-2)/(verticalGridLines))), 1, NULL);
							LineTo  (hdcBuffer2, 1+ ((i*(width-2)/(verticalGridLines))), width-2);
							}
						}
					
					SelectObject(hdcBuffer2, oldpen);
					DeleteObject(pen);
					}

				
                // ---------------------------------------------

				// Draw network monitor history curve

				//upload speed line
				pen = CreatePen(PS_SOLID, 1, upForeColor);
				oldpen = SelectObject(hdcBuffer2, pen);

				j = (pointer + width-3) % (width-2);
				MoveToEx(hdcBuffer2, 1, width-2- ((width-3) * upHistory[(j+1)%(width-2)]/100), NULL);
				for (i=0;i<width-2;i++)
					{
					j++;
					j %= (width-2);
					LineTo(hdcBuffer2, 1+i, width-2-((width-3) * upHistory[j]/100));
					}

				SelectObject(hdcBuffer2, oldpen);
				DeleteObject(pen);
				
				//download speed line
				pen = CreatePen(PS_SOLID, 1, downForeColor);
				oldpen = SelectObject(hdcBuffer2, pen);

				j = (pointer + width-3) % (width-2);
				MoveToEx(hdcBuffer2, 1, width-2- ((width-2) * downHistory[(j+1)%(width-2)]/100), NULL);
				for (i=0;i<width-2;i++)
					{
					j++;
					j %= width-2;
					LineTo(hdcBuffer2, 1+i, width-2- ((width-3) * downHistory[j]/100));
					}

				SelectObject(hdcBuffer2, oldpen);
				DeleteObject(pen);
				
				// Draw Text
				if(!dontDrawText){
					memset(outText,0,40);
					memset(inText,0,40);
					
					SetBkMode(hdcBuffer2,TRANSPARENT);
					SetTextAlign(hdcBuffer2,TA_LEFT);
					SetTextColor(hdcBuffer2,inTextLabelColor);
					TextOut(hdcBuffer2,leftTextXOffset,inTextYOffset,inTextLabel,strlen(inTextLabel));
					SetTextColor(hdcBuffer2,outTextLabelColor);
					TextOut(hdcBuffer2,leftTextXOffset,outTextYOffset,outTextLabel,strlen(outTextLabel));
					if(currentDownValue>1000){
						ltoa((currentDownValue+500)/1000,inText,10);
						strcat(inText,"k");
						}
					else if(currentDownValue>1000000){
						ltoa((currentDownValue+500000)/1000000,inText,10);
						strcat(inText,"m");
						}
					else
						ltoa(currentDownValue,inText,10);
					if(currentUpValue>1000){
						ltoa((currentUpValue+500)/1000,outText,10);
						strcat(outText,"k");
						}
					else if(currentUpValue>1000000){
						ltoa((currentUpValue+500000)/1000000,outText,10);
						strcat(outText,"m");
						}
					else
						ltoa(currentUpValue,outText,10);
					
					SetTextAlign(hdcBuffer2,TA_RIGHT);
					SetTextColor(hdcBuffer2,inTextColor);
					TextOut(hdcBuffer2,width-1-rightTextXOffset,inTextYOffset,inText,strlen(inText));
					SetTextColor(hdcBuffer2,outTextColor);
					TextOut(hdcBuffer2,width-1-rightTextXOffset,outTextYOffset,outText,strlen(outText));
					}

				// Draw border
				r.top -= 1;//expand rect by 1 pixel
				r.bottom += 1;
				r.left -= 1;
				r.right += 1;
				
				if(!dontDrawBevel){
					pen = CreatePen(PS_SOLID, 1, northWestBevelColor);
					oldpen = SelectObject(hdcBuffer2, pen);
					
					MoveToEx(hdcBuffer2, 0, width-1, NULL);
					LineTo(hdcBuffer2, 0, 0);
					LineTo(hdcBuffer2, width-1, 0);
					
					SelectObject(hdcBuffer2, oldpen);
					DeleteObject(pen);
					
					pen = CreatePen(PS_SOLID, 1, southEastBevelColor);
					oldpen = SelectObject(hdcBuffer2, pen);
					
					LineTo(hdcBuffer2, width-1, width-1);
					LineTo(hdcBuffer2, 0, width-1);
					
					SelectObject(hdcBuffer2, oldpen);
					DeleteObject(pen);
					}	
					
				init=TRUE;
				
				BitBlt(hdc,moduleXOffset,moduleYOffset,64-2*borderSize,64-2*borderSize,hdcBuffer2,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);
				
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
		case WM_LBUTTONUP:
				{
				RECT r;
				if(dontDrawText) dontDrawText=FALSE;
				else dontDrawText=TRUE;
				GetClientRect(hMainWnd, &r);
				InvalidateRect(hMainWnd, &r, TRUE);
				}
			return 0;
        case WM_RBUTTONDOWN:
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_TIMER: // Update network monitor
				{
				RECT r;
				if (!init) return 0;
				// Get last network usage value
				pdhStatus=PdhCollectQueryData(netLoadUpQuery);
				pdhStatus=PdhGetFormattedCounterValue(netLoadUpCounter,PDH_FMT_LONG,NULL,&netLoadUp);
				pdhStatus=PdhCollectQueryData(netLoadDownQuery);
				pdhStatus=PdhGetFormattedCounterValue(netLoadDownCounter,PDH_FMT_LONG,NULL,&netLoadDown);
				
				// Insert it in the rotating buffer
				currentUpValue = netLoadUp.longValue;
				if(currentUpValue>maxNetSpeed || currentUpValue<0) upHistory[pointer] = 100;
				else upHistory[pointer] = 100 * currentUpValue/maxNetSpeed;
				
				
				
				currentDownValue = netLoadDown.longValue;
				if(currentDownValue>maxNetSpeed || currentDownValue<0) downHistory[pointer] = 100;
				else downHistory[pointer] = 100 * currentDownValue/maxNetSpeed;
				pointer++;
				pointer %= width-2;
				
				// Invalidate client. This causes a WM_PAINT message to be sent to our window
				GetClientRect(hMainWnd, &r);
				InvalidateRect(hMainWnd, &r, TRUE);
				}
			return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}

