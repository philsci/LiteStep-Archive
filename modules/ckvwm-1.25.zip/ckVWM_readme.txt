//============================================================
//ckVWM.dll v1.25 - a vwm based on sysvwm
//------------------------------------------------------------
//Filename	: 	ckVWM.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This module adds some new functions to the sysvwm
//------------------------------------------------------------

---------------
I: Installation
---------------
Put ckVWM.dll in any directory you like, for example c:\litestep\, then add this line to step.rc

LoadModule c:\litestep\ckVWM.dll

or you can load it inside wharf as a wharf module by adding this entry:

*Wharf "ckVWM" .none @c:\litestep\ckVWM.dll

---------------
II: Settings
---------------
This Section contains both the features from the sysvwm and ckVWM to save you from having
to look at two readmes for one module.

*Note: all functions that use desktop number as an argument are fixed so that the first desk starts with
1 instead of 0.


The following is copied straight from sysvwm's readme
---------------
Mouse functions
---------------

VWMMouseRight #
---------------
Allows you to define which functions your right mouse button do. Defaults to 1.

VWMMouseLeft #
--------------
Allows you to define which functions your left mouse button do. Defaults to 2.

VWMMouseMiddle #
----------------
Allows you to define which functions your middle mouse button do. Defaults to 0.

Valid entries for the above are: 0 - disables mouse button, 1 - button will switch to the vwm that you click on, 2 - button will drag the miniwindows and the vwm.

Drag and drop is also supported. You can drop a file on sysVWM, and the file will open inside the virtual desktop that you drop it on.

----------------------------
commands (step.rc and !bang)
----------------------------

In addition to the normal "undocked" mode, sysVWM can be loaded as a wharf module, allowing you to use the more advanced options even while docked inside the wharf. Some options are disabled when on the wharf, like the ability to specify your own height, width, and x,y positioning. Generally, if an option doesn't make sense to be available to a wharf module, then it has probably been disabled. Rollup is disabled, Reset does nothing, etc. 

	*Wharf "sysVWM" .none @sysvwm.dll

The module does not load anything out of the bitmap parameter, but it is still needed so that wharf.dll will load sysVWM. sysVWM will use its regular method for displaying bitmaps. 

VWMNoSwitchOnFocus
------------------
Prevents automatic virtual desktop switching when the system focus changes to a window that is outside the current desktop.

VWMFocusCenter
--------------
Sets your system focus to whatever window is in the center of the screen when you switch desktops.

VWMNoShow
---------
Sets initial mode for !VWMRollup to hidden. In other words, the vwm will be hidden when this option is used. !VWMRollup would be used to display the vwm.

VWMNoGathering
--------------
Prevents automatic "gathering" of all windows to the first virtual desktop upon a recycle of litestep.

VWMNoMove
------------
Disables the ability to drag the vwm around.

VWMShowIcons
------------
sysVWM will paint an icon inside each miniwindow. The icon associated with the task that the miniwindow represents will be used.

VWMIconSize #
-------------
Specifies the size that you prefer each icon to be drawn at. Default value is 16.

VWMAutohide
-----------
Enables autohide features. Autohide will work only when the vwm is docked against one of the sides of the screen. If you drag the vwm away from the side it is docked on, autohide will be turned off until the vwm is returned to the side of the screen again.

VWMAutohideDistance #
---------------------
When autohide features are enabled, this value is used to determine how close to the edge of the screen you must be to show the vwm. This value will default to 3 if not used.

VWMAutoSwitch
-------------
This feature will allow sysVWM to automatically switch desktops when your mouse cursor reaches the edge of the screen. For example, if you move your mouse to the right edge of your screen, then sysVWM will switch to the next desktop to the right.

VWMAutoSwitchDistance #
-----------------------
This value determines how far from the edges of the screen your cursor needs to be before VWMAutoSwitch kicks in and changes your desktop. This setting defaults to 1.

VWMAutoSwitchDelay #
--------------------
When VWMAutoSwitch is enabled, this value determines the approximate number of milliseconds to wait before switching vwm's when the mouse reaches the edge of the screen. Default is 50. 

VWMTitlebars
------------
Enables the titlebars on the windows in the miniview.

VWMTitlebarMod #
----------------
sysVWM will use this modifier when calculating the height of the titlebars. sysVWM will divide the height of the desktop by this modifier, then display a titlebar at that ratio. So if you specified VWMTitlebarMod 2, then your titlebars would be half the height of each virtual window. This setting defaults to 16.

VWMBevel
--------
Enables the bevel on windows in the miniview. The bevel highlight will use the color specified in VWMForeColor, and the shadow will use VWMBorderColor. The windows will then be filled with the color specified in VWMWinColor.

VWMSnapWidth #
--------------
When dragging the vwm window around, it will snap to the edge of the screen when it comes within the number of pixels specified in #.

VWMAlwaysOnTop
--------------
Keeps the vwm window above all other windows. If this is not specified, sysVWM will be below all other windows.

*VWMSticky <text>
-----------------
Enables and defines sticky settings. When you switch desks, sysVWM will match the <text> against the window titles and classes in your current virtual desktop, and any windows that match will be carried to the new desktop.

VWMForeColor ######
-------------------
Sets the color of the "mini-windows" that represent an open window. Uses default litestep color format.

VWMBackColor ######
-------------------
Sets the color of the background for sysVWM. Uses default litestep color format.

VWMSelBackColor ######
----------------------
Sets the color of the shading that is applied to a selected desktop. Uses default litestep color format.

VWMBorderColor ######
---------------------
Used for the border of the "mini-windows", and the dividing lines between each desktop window. Uses default litestep color format.

VWMWinColor ######
-------------------
Sets the color of the background of the windows when VWMBevel is specified. Uses default litestep color format.

VWMUseInitialDesk
-----------------
Allows usage of VWMInitialDesk.

VWMInitialDesk #
----------------
Starts the VWM on the specified desktop, the # will start from 1 representing the first desktop instead of 0.

VWMDesksX #
-----------
Number of desktops you want to have on the X axis.

VWMDesksY #
-----------
Number of desktops you want to have on the Y axis.

VWMx #
------
Tells sysVWM how many pixels down from the top of the screen you want the vwm to be placed at. Negative numbers are also valid, and will make sysVWM use the bottom of the screen.
 
VWMy #
------
Tells sysVWM how many pixels across from the left side of the screen you want the vwm to be placed at. Negative numbers are also valid, and will make sysVWM use the right side of the screen.

VWMwidth #
----------
The width of the entire vwm.

VWMheight #
-----------
The height of the entire vwm.

VWMBackBmp <bitmap>
-------------------
sysVWM will use this bitmap instead of the color specified in VWMBackColor. VWMBackBmp .snapshot will take a snapshot of the desktop to use as the background here.

VWMSelBmp <bitmap>
------------------
Makes sysVWM ignore the VWMSelBackColor and use this bitmap to paint on the background of the selected virtual window.

VWMTitlebarBmp <bitmap>
-----------------------
Uses a bitmap for the titlebar representations in the miniviews. If a bitmap is not specified here, then VWMBorderColor will be used to fill the titlebars.

VWMWinBmp <bitmap>
------------------
This bitmap will be used for the tiny windows in the miniviews. VWMForeColor will be used if no bitmap is specified here.


; Additional settings from ckVWM
VWMHideTaskOnSwitch	<bool>
-----------------------------------
This will set the vwm to hide windows that are currently not in this desktop which is the 
original purpose of ckVWM.

default: false

VWMWrapScreen		<bool>
-----------------------------------
This will make the the vwm's like a circular loop which for instance when you move right when you
are in the right most desktop, you will switch to the left most desktop.  If you move right at the bottom 
right desktop, you'll move to the left top desktop.

default: false

VWMReturnToFirstScreen	<bool>
-----------------------------------
This is for people whose Litestep doesn't support data storing, such as PureLS.  Specify this setting
will force you to return to the first desktop when recycling so you won't lose some windows.

default: false

VWMRestoreX 		<int>
-----------------------------------
This will specify the left x position of your window when they are restored using the restore window
bang in the next section.

default: 10

VWMRestoreY 		<int>
-----------------------------------
This will specify the top y position of your window when they are restored using the restore window
bang in the next section.

default: 10

VWMRestoreWidth 	<int>
-----------------------------------
This will specify the width of your window when they are restored using the restore window
bang in the next section.

defualt: -400

*If this is negative, then the window's width and heigh are not changed during restoring


VWMRestoreHeight 	<int>
-----------------------------------
This will specify the height of your window when they are restored using the restore window
bang in the next section.

default: -300

*If this is negative, then the window's width and heigh are not changed during restoring

VWMMaximizeThreshold 	<int>
-----------------------------------
The number is between 0 and 100.  It will effect how vwm consider whether a window is inside this
desktop or outside.  It basically a percentage where the greater the number is, the better chance
the vwm will do the right thing.  I recomment you not to play with this setting unless you know what 
you are doing

default: 10

VWMDisableVerticalAutoSwitch	<bool>
-----------------------------------
This setting is handy when your vwm is vertical or horizontal and you have the VWMAutoSwitch
and VWMWrapScreen settings on.  It will prevent you from autoswitch vertically when you have
a one line horizontal vwms.

default: false

VWMDisableHorizontalAutoSwitch	<bool>
-----------------------------------
This setting is handy when your vwm is vertical or horizontal and you have the VWMAutoSwitch
and VWMWrapScreen settings on.  It will prevent you from autoswitch horizontally when you have
a one line horizontal vwms.


*VWMStartWindowsOnDesktop	<text>	<int>
-----------------------------------
This is another neat feature of ckVWM.  You can specify what windows, by specifying its window name
or class name, will start on the specified desktop number.  The number of the desktop starts from 1.

default:	no default

VWMSnapWindowOnDrag 		<bool>
-----------------------------------
This setting will allow you to retain a window's relative position to its desktop while dragging.

default: false

VWMFocusLast			<bool>
-----------------------------------
This setting allows the vwm to remember your last window that was active when you left that desktop.
So the correct active window will be re-activated when you move back to the desktop

default: false


---------------
III: Bang Commands
---------------

!VWMUp, !VWMDown, !VWMLeft, !VWMRight
-------------------------------------
Using these bang commands will change the active desktop, moving one desktop over in the direction specified.

!VWMDesk #
-------------------------------------
Changes the active desktop, moving your focus to the desktop specified with #.

!VWMRollup
----------
You can hide sysVWM by using the bang command !VWMRollup. This command will hide and show the vwm, acting as a toggle.

!VWMReset
---------
This will reload the step.rc settings for the vwm. Useful for when you drag the vwm to a place where you can't get at it anymore. Just hit !VWMReset, and it reloads the vwm at the coordinates you set in the step.rc.

!VWMGather
----------
Brings all open windows to your current desktop. This command functions independently of VWMNoGathering.

!VWMOpen <desk> <command> <parameters>
--------------------------------------
Opens the file or program specified in <command> with the given <parameters> within the virtual desktop specified in <desk>. For example, the command !VWMOpen 0 notepad will open notepad in the top left vwm.
*the desk is fixed so that it starts with 1 instead of 0

!VWMMoveApp <argument>
-----------------------
This command will move the active window one virtual desktop over in the direction you specify for <argument> where valid directions are Up, Down, Left, and Right. 
In addition, with ckVWM now you can specify a number for the argument representing the target desktop number to move to.

!VWMTOGGLEHIDETASKONSWITCH
-----------------------------------
This bang command will toggle your vwm to whether hide tasks that are not in the current desktops or display all of them in taskbar.

!VWMTOGGLEWRAPSCREEN
-----------------------------------
This bang command will toggle your setting for VWMWrapScreen

!VWMRESTOREWINDOW <text>
-----------------------------------
This will restore one window whose title or classname matches the pattern specified in text.


!VWMRESTOREALLWINDOWS <text> <method>
-----------------------------------
This will restore all windows whose title or classname matches the pattern specified in text.
The method so far can be either, overlap or cascade, in which overlap is the default if nothing is specified.

*for detail on how the windows are restored please check the VWMRestoreXXX settings in the previous section

------------------------------
IV: History
------------------------------
/****************** v1.25		11/22/2000************///
//	This release is mainly a bug fix version.
//	First i want to say sorry about the the future plan, and the features people have been asking, cause I've 
//	been very busy lately.  Just in case you didn't know, I joined the ls dev team recently which will make me busier.
//	Some of the features i'm still considering whether i should add it or not.  If you 
//	really want any feature, just e-mail me, and then i'll if those features are worth adding or not.
//
//	Anyway, this is kind of my Thanksgiving present for you LS users, and all you CK users ;-) Have Fun!
//
//	Chagnes:
//		-added config VWMFocusLast, so that the window that has the last focus will be focussed when switch back
//		to that desktop.  This config can coexist with config VWMFocusCenter, but the focus last code will run first before 
//		the focus center code.
//
//		-now !VWMMOVEAPP can accept number that specifies which desktop to move to instead of just
//		moving to the neighboring desktop.  syntax: !VWMMOVEAPP #, where # is the desktop number starting from 1
//
//	Bug fixed:
//		-now compatible with dwarf and lsbox(no 64^2 size limit), and almost all other wharf loading modules
//		-photoshop tools
//		-fixed !VWMMoveApp bang, so that it won't move always on top stuff.
//		-fixed a rendering problem when the width of each vwm is shorter than the height
//
//	*Just in case you didn't know, I've added the version resource, so you can check your ckVWM version by checking
//	the file properties.
/****************** v1.2		10/28/2000************///
// Changes:
//	Bang commands:
//		changed:
//		-!VWMRESTOREALLWINDOWS
//			>changed to !VWMRESTOREALLWINDOWS "window title or class name" "method"
//		  	where method could be blank(default to overlap), overlap, or cascade
//		-!VWMRESTOREWINDOW and !VWMRESTOREALLWINDOWS
//			>changed the window title or class name matching scheme to use the match() function.
//			The syntax for matching a specific word such as MIRC would be:  *MIRC*
//			The matching is not case sensitive
//		added:
//		-!VWMMove x y
//			>change the position of the VWM to x, y (x and y can be negative)
//			>if nothing is supplied, the VWM will move back it's old position specified in step.rc
//
//
//	Step.rc configs:
//		-Added configs to disable the vertical or horizontal autoswitch
//			>VWMDisableVerticalAutoSwitch
//			>VWMDisableHorizontalAutoSwitch
//
//		-Changed the RestoreWidth, and RestoreHeight so that if you don't specify them or
//		one of them is negative, then when restoring windows using !VWMRESTOREWINDOW or
//		!VWMRESTOREALLWINDOWS the windows' original width and heigh will not be changed.
//
//		-Added config *VWMStartWindowsOnDesktop "Window title or class name" "Desktop Number"
//		so that windows that match will always start on the desktop number you specify
//		(doesn't work with PureLS at this time)
//
//		-Added config VWMSnapWindowOnDrag so that window will retain its relative coordinate to
//		the desktop when dragging the miniwindows
//
//	Misc:
//		In this release, i added a two modified popup modules, popup r9.3 and popup2, that will work with ckvwm.
//		They will allow you to have popup tasks for hidden windows on differnt desktops when you have the 
//		config VWMHideTaskOnSwitch.  
//		The step.rc config for these added popup feature is:
//			PopupckVWMPath "path"
//		where path equals to the path to your ckvwm.dll, the one you load module with.
//		
//		When you dont use ckvwm, you can simply comment out the PopupckVWMPath, and everything
//		will be the same as before.
//
//		The syntax to see windows on other desktop is the same as !PopupTasks,
//		just replace !PopupTasks with !PopupTasks1, !PopupTasks2, !PopupTasks3.....depending on your
//		vwm configuration.  !PopupTasksAll Allows you to tasks from all desktops.
//
//		*Note: if a warning dialog popups up from your shell saying that the module ckvwm is already
//		loaded, simply change the order you load ckvwm and popup in step.rc  Load ckvwm before popup
//
//	Bug Fix:
//		-Fix the problem that !VWMTOGGLEHIDETASKONSWITCH will make windows disappear
//		-Fix !MoveApp bang so that it will work with VWMWrapScreen
//		-Fix !MoveApp bang so that for examle you click on a shortcut which calls this bang, the program will
//		look for the topmost visible window to move.
//		-Fix the bug that when clicking on task, the wrong desktop will be shown.
//		-Fix the config VWMDeskWallpaper# so that it can use e-vars, and save the time to allocate unnecessary memory spaces
//
//	Future Plan:
//		-Add a lock feature so that you can't switch to other desktop or control other desktop
//		unless you enter the right password
//		-The ability to double click on a miniwindow to maximize or restore the window.
//		-When dragging miniwindows, vwm will automatically switch to the desktop that the window is in.
//		-Add bang commands to control group of windows
//
//
//	Note:
//		Special thanks to [steve] in helping me to diagnose a bug, and a lot of people who contributed their
//		ideas, or told me their problems.  If there is a bug that isn't fixed, or any ideas that you have either
//		new or i forgot to implement it and it's not in the Future Plan list, please send an e-mail to me (even
//		if you did already and it's still not fixed) to chaokuo@iname.com or 
//		go to irc channel @ EFnet, in #ls_help and tell me.  My nick is Chaku, thanks.
//
/****************** v1.0		9/30/2000************/
//
// Finally found the bug that was causing my v0.81(internal version) to be unstable.
// First, I want to thank those who had contributed to any part of this code
// and those who helped spreading it.  Also, thanks for those who sent me e-mail  
// with suggestions and bug reports.  This version should be stable and....
// Anyway, here we go...
//
// Changes:
//	Added Bang commands:
//			!VWMRESTOREWINDOW <text>
//				This command will help you retrieve hidden window that's lost in your desktop.
//				The text specify any word or sentence in the window's title that you want to restore.
//			!VWMRESTOREALLWINDOWS <text>
//				Same as the bang above, except this one will restore all the window that contains text
//				in its title.
//					
//	Added Step.rc configs:
//		The following 4 fonfigs will determine where the window will show when you
//		use the restore bangs above:
//			VWMRestoreX # (default 10)
//			VWMRestoreY # (default 10)
//			VWMRestoreWidth # (default 400)
//			VWMRestoreHeight # (default 300)
//
//		The following config will allow you to change how VWM will determine whether the maximized
//		window is out of the current desktop.  The # represents portion of the area where 10
//		means 10%, and 20 means 20%.  Unless you really know what you are doing, it is not
//		recommend that you change this config.  It's default to 10( which means 10%)
//
//			VWMMaximizeThreshold #
//
//
// Bug Fix:
//	-Fix the problem that VWMWrapScreen doesn't work when AutoSwitching
//	-Fix the bang commands, VWMOpen and VWMInitialDesk, so that the first desktop will be 1 instead of 0
//	-Fix the bang command, VWMReset.
//	-Fix the problem that maximized or full screen stuff will disappear. (sorry guys)
//	-Fix the problem that it will occasionally lock up.
//	-Others that i can't think of right now.....
//
// *Note:
//		-VWMReturnToFirstScreen i think is for users of Litestep families(such as PureLS)that don't
//		support the message LM_SAVEDATA, so your windows won't disappear after recycle.
//		-Source code is availabe at my site.
//
//
/****************** v0.8b		9/24/2000************/
//Changes:
//	Added Step.rc Config:
//		VWMHideTaskOnSwitch
//			-This will cause the sysvwm hide the tasks from task bar if
//			 its window is not on the current screen.  It will not hide the minimized window
//			from task bar, and it'll carry it to differnt desktop.  So when restored, the window
//			will be in the current desktop, and not in the old
//			
//		VWMWrapScreen
//			-This will alow your desktops to be kind of circular.  Let's say the you are in the 
//			first desktop. When you use !VWMLeft, this config will allow you to move to the last
//			desktop.
//		VWMReturnToFirstScreen
//			-For those whose sysvwm will behave weird when not recycling in the first desktop,
//			this config will force the sysvwm to go back to the first desktop.
//			(I don't know about most of the people, but i guess you won't experience this kind of problem)
//
//	Added Bang Commands:
//		!VWMTOGGLEHIDETASKONSWITCH
//			-This is for toggling the VWMHideTaskOnSwitch config
//		!VWMTOGGLEWRAPSCREEN
//			-This is for toggling the VWMWrapScreen config
//	
//	*Note: 
//		-In this version of !VWMDesk #, the # will start from 1 and not 0
//		-This is just a beta version.  I welcome any suggestions, and if you found a bug
//		please please report to me @ chaokuo@iname.com  Thanks.
//------------------------------------------------------------
//Example Step.rc config:
//	LoadModule "C:\Litestep\ckVWM.dll"
//	VWMHideTaskOnSwitch
//	VWMReturnToFirstScreen
//	VWMWrapScreen
//	
