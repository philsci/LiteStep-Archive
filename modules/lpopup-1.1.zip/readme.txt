*** LPopup v 1.1
** by _TAG_ <dream.king@iol.it>
Looking around on the mailing list I found someone (me included) felt the need for a left-click popup which, at least, would show the active tasks. So I made this.
NOTE: for transparencies to work you need a fixed width popup!!!!!!!


*** installation
You need a dektop module in which you can assign bang commands to mouse clicks (like jdesk)
- unzip lpopup.dll in your LS direectory (e.g. c:\litestep\)
- add this line to your step.rc
	LoadModule C:\LITESTEP\lpopup.dll
where (of course) C:\litestep\ is the directory in which lpopup.dll is.
- configure your desktop module as to assign the left click to the !LPOPUP bang command e.g. (in jdesk.dll 0.6)
	jDeskMButton1 ["!None"]["!LPOPUP"]


*** settings (those lines you write in your step.rc)
NOTE: the value in brackets following each setting is the default value.
The setting are pretty much borrowed from the standard LS popup (which means that LPopup will look and feel the same). The only new command is:
	LpopupTasksName	 	['Tasks']
which, of course, is the string which will appear as the title of the LPopup window.

Other setting are (for a description of each look into LS popup documentation) those of popup.dll:
	PopupUseDeskImage
	PopupBackImage
	PopupTitlePix
	PopupEntryPix
	PopupSelEntryPix
	PopupBottomPix
	PopupFontFace
	NoPopupFolderIcon
	NoPopupTransparent
	NoPopupBevel
	PopupFontHeight		[16]
	PopupTitleColor		[0xffffff]
	PopupTitleColor		[0xffffff]
	PopupEntryColor		[0x000000]
	PopupSelEntryColor 	[0x000000]
	PopupMenuDelay		[10]
	MinPopupWidth		[100]
	PopupSubmenuHeight	[20]
	PopupFixedWidth		[0]
	PopupTextOffset		[5]
	ShowPopupIcons
	PopupIconSize		[20]
	PopupDefaultIcon	[default.ico]
	PopupTaskDefaultIcon	[task.ico]
	PopupEmptyDefaultIcon	[empty.ico]
	PopupUseDesktopIni
	ShrinkPopupBar
	PopupTitleBack		[0x000000]
	PopupTitleBack		[0x000000]
	PopupNormalBack		[0xa4a0a0]
	PopupSelBack		[0xffffff]


*** usage
It's pretty obvious:
left clicking on the desktop opens my popup, while right clicking opens the normal popup.
Right now, since no desktop module seems to care whether a popup is already open, if the right click popup is already open, left clicking on the desktop will open LPopup and close the LS popup, not just close the latter (this is how jdesk works).


*** hardcore tech infos (for LSDevs and whoever is curious enough)
To make it work well, I:
- added a new bang command '!LPOPUP'


*** sources
The sources are all hacked from the LS sources for the 24/10/99 build.


*** known bugs
- to have transparency enabled, you need a fixed width popup, so if yours is not big enough, many window titles will be cut (actually this is a 'bug' of the LS popup (still it's pretty hard to kill it, since, for a stretched popup, you'd need to recalculate the window region every time the popup is opened, but this would be a resource hog!)


*** thanks
AnTI_MTtr, cbjcyber and GeekMASTER on #ls_help and #litestep (EFNet)
Fahim for his popup and everyone in the LS Dev Team!
Everybody out there who did some LS module and did release the source!


*** contacts
write me (comments, bugs, ideas, money, girls):  dream.king@iol.it [ flames > /dev/null ]
- the 'official' site should be
	http://aula6.cjb.net/
	http://users.iol.it/dream.king
- ICQ UIN #1584291


*** other
- future: may add some XWindows like commands (kill, move, etc)
- a new version will (hopefully) come out which will be much smaller! (I'll be getting rid of some overhead of the original popup.dll)
There's a lot of things in the sources which could be eliminated, yet I have to do it!!!

*** history
v 1.1 28/10/99
- changed the code base another time (based on 24/10/99 now)
- now transparency works (you need a fixed width popup)
- dropped the modifications to desktop.dll and to popup.dll
- using a bang command now ('!LPOPUP')
- the window list is gotten using a EnumProcWindows(), not by sending a LM_WINLIST message to LS (NOTE: I really think LS.exe should keep an internal window list, as it did before hook.dll was added to desktop.dll... I did submit changes that made LS.exe handle the hook.dll, but they weren't accepted... maybe with time)

v 1.0	24/03/99
- changed the code base so it uses the new popup code by Fahim (from LS build 180399)
- fixed the bug which caused the bottom picture and some tasks not to show; did this by changing the window properties (height and width) every time the popup is opened (using SetWindowPos())

v 0.1	01/03/99
- first release with many bugs
