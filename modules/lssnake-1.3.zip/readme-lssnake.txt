////////////////////////
// LSSnake 1.3
// By: MrJukes
// Released: 4/26/00
////////////////////////

step.rc entries:
LoadModule h:\litestep\lssnake.dll

LSSnakeStartHidden
LSSnakeX 100
LSSnakeY 100
LSSnakeWidth 150
LSSnakeHeight 150
; The speed is in milliseconds.  100 is pretty quick.
LSSnakeSpeed 100
LSSnakeSnakeColor FFFFFF
LSSnakeBGColor 000000
LSSnakeFoodColor FF0000
LSSnakeRockColor C0C0C0
LSSnakeTextColor 0000FF
LSSnakeBlockSize 5
LSSnakeEnableRocks

Bang Commands:
!LSSnakeHide
!LSSnakeShow
!LSSnakeToggle
!LSSnakeFocus

Game Play:
To start play hit Enter.
To pause the game hit Enter.
Use the Left, Right, Up, and Down arrows to move the snake around.
Do not touch the walls or rocks and do not run into yourself, this will result in you losing.

Have fun,
	MrJukes (mrjukes@purdue.edu)