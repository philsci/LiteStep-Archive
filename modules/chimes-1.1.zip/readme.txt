--------------------------------------------------------------------
  Chimes.dll v1.1					  09/06/99
--------------------------------------------------------------------

Chimes is Litestep loadmodule. It plays specified WAV file every
15 minutes. You can specify different WAV for hour, half-hour, and
quarter-hour intervals. This module was written in Delphi 3, using
LSDevKit by Murphy.


--------------------------------------------------------------------
  Installation
--------------------------------------------------------------------

Simply load at startup as:

  LoadModule "c:\litestep\chimes.dll"


--------------------------------------------------------------------
  Setup
  Sample step.rc commands:
--------------------------------------------------------------------

; Uncomment this to disable chimes at startup
; (default: enabled)
; ChimesStartDisabled

; Chime multiple times each hour (i.e. 3x at 3:00, 4x at 16:00, etc.)
; (default: disabled)
ChimesMultiple

; Specify which WAV file to play every hour
ChimeHour "path_to\filename.wav"

; Specify which WAV file to play at half-hour
ChimeHalf "path_to\filename.wav"

; Specify which WAV file to play at quarter-hour
ChimeQuarter "path_to\filename.wav"

; Bang commands:
;
; Play WAV
;   !Chime "path_to\filename.wav"
; Enable chimes
;   !ChimesEnable
; Disable chimes
;   !ChimesDisable
; Toggle chimes
;   !ChimesToggle


--------------------------------------------------------------------
  History
--------------------------------------------------------------------

v1.1	09/06/99
  * Lower memory requirements
  * Minor bugfixes
  + Added 'Multiple chimes' feature (on request)

v1.0
  Initial version

Known bugs:
  In rare cases, if your audio device is busy, the chime won't play
at all. In multiple mode, when Chimes doesn't succeed playing
the first chime at exact hour interval, it will abort remaining
chimes.

====================================================================
author: Pavel Vitis
mailto: pavel.vitis@seznam.cz
www:	http://come.to/pavel.vitis/

LSDevKit by Murphy:
http://www.dev0.de/
