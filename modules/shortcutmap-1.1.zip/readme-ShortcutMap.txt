/////////////////////////////
// Module: ShortcutMap v1.1
// Written By: MrJukes
// Released: 12/8/2000
/////////////////////////////

// What's new in 1.1
- Fixed middle mouse click bug
- Fixed the memory leak

LoadModule c:\litestep\ShortcutMap.dll

step.rc
==========
*ShortcutMap Name #TH X Y image.bmp
*Region "Bang Command" [x,y:x,y:x,y:x,y] !bang
*Region Executable [x,y:x,y:x,y:x,y:x,y] exec.exe
~ShortcutMap Name

; You can specify up to 32 vertices in the region ;
; #T = Always on top
; #H = Start Hidden

!bang
===========
!ShortcutMapShow Name
!ShortcutMapHide Name
!ShortcutMapToggle Name

example
===========
*ShortcutMap Map 100 100 shortcutmap.bmp
*Region "Amp Next" [0,0:10,0:10,10:0,10:0,0] !amp_next
*Region Calc [100,100:110,100:110,110:100,110:100,100] calc.exe
~ShortcutMap MyMap

==================================================================
E-mail me at mrjukes@purdue.edu with comments/suggestions/bugs.

Have fun,
	MrJukes