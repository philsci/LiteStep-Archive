//============================================================
//ckShotIt.dll v1.0
//------------------------------------------------------------
//Filename	: 	ckShotIt.dll
//Author	:	Chao-Kuo Lin
//E-mail	:	chaokuo@iname.com
//Webpage	:	http://cklin.cjb.net
//Purpose	:
//	This is something that I coded that I feel I need to work w/ my trillian buddylist.  if you
// find it useful then great, but no feature requests or anything.  It's just here as it is ;-)
//------------------------------------------------------------
/****************** v1.0		2001/07/01************/
//
// Settings
//	There is no setting but only one bang:
//		!ckShowit [window's class name]
//	It has to be complete class name or it won't work.  Here's how i use it to show my
//	Trillian BuddyList(i'm not running IRC or the main window
//
//	I binded a hotkey to execute it
//	*Hotkey Alt+Shift T !ckShowit Buddies : Trillian
//
//
//