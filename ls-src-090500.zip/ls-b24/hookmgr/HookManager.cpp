#include "HookManager.h"

HookManager::HookManager(HWND hLoader) { 
    _numMessages = 0;
    _hTasks = NULL;
    AttachHookDll(hLoader); // hLoader is the hwnd of the process to recieve messages
}

HookManager::~HookManager() {
    msg2hwnd::iterator m2hit;
    while (!_m2hmap.empty()) { //while there is objects in the map
        m2hit = _m2hmap.begin(); // get the first one
        delete m2hit->second; //  delete the set
        _m2hmap.erase(m2hit); // delete the object from the map
    }
    AttachHookDll(NULL); // Dettach hook.dll
}

bool HookManager::AddMsgHook(UINT message, HWND client) {
    sMsgHookList* psHwnds;
//REMOVE ME    bool bMsgFilterInstalled;
    msg2hwnd::iterator m2hit;
    // No messages currently being monitored
    if (_numMessages == 0) { 
        // Install the message filter
//REMOVE ME        bMsgFilterInstalled = InstallMsgFilter(true);
        if (!InstallMsgFilter(true)) return false; // Filter installation was not successful
        psHwnds = new sMsgHookList; // Create the new list
        psHwnds->insert(client);  // Add the Hwnd 
        _m2hmap.insert(msg2hwnd::value_type(message,psHwnds)); //Map the hwnd to a message
    }
    else {
        m2hit = _m2hmap.find(message); // Attempt to find the message
        if (m2hit == _m2hmap.end()) { // Message not found
            psHwnds = new sMsgHookList; // Create the new list
            psHwnds->insert(client);  // Add the Hwnd 
            _m2hmap.insert(msg2hwnd::value_type(message,psHwnds)); //Map the hwnd to a message
        }
        else { // Message found
            psHwnds = (*m2hit).second; // Get point to list
            psHwnds->insert(client); // Add the Hwnd
        }
    }
    _numMessages++;
    return true;
}

bool HookManager::RemoveMsgHook(UINT message, HWND client) {
    sMsgHookList *psHwnds;
    sMsgHookList::iterator lit;
    msg2hwnd::iterator m2hit;
    if (_numMessages) { // Monitoring any messages?
        m2hit = _m2hmap.find(message); // Find the message in the map
        if (m2hit == _m2hmap.end()) { // not found 
            return true; // we weren't monitoring that message anyway
        }
        else { // The message was found in the map
            psHwnds = (*m2hit).second; // Get a pointer to the list
            lit = psHwnds->find(client); //Find the hwnd
            if (lit == psHwnds->end()) { // Find the hwnd
                psHwnds->erase(lit); // Remove it
                if (psHwnds->empty()) { // Any more items left in the list?
                    delete (*m2hit).second;
                    _m2hmap.erase(m2hit); // Nope, remove the entry from map
                }
                _numMessages--; // Decrease message count
                if (!_numMessages) { // no messages being monitored?
                    InstallMsgFilter(false); // unload message hook
                }
            }
        }
    }
    return true;            
}

bool HookManager::AddShellHook(HWND hTasks) {
    if (_sHookList.empty()) { // Any HWNDs in the list?
        if (!InstallShellFilter(true)) return false; // Nope, install the hook, return false
    }                                                // if the hook didn't install
    sShellHookList::iterator lit;
    lit = _sHookList.find(hTasks);
    if (lit != _sHookList.end()) return true; // The HWND was already so re will jsut return
                                              // true and let them think they are registered
    _sHookList.insert(hTasks); // Add the HWND
    return true;
}

bool HookManager::RemoveShellHook(HWND hTasks) {
    if (_sHookList.empty()) return false; // List was empty
    sShellHookList::iterator lit;
    lit = _sHookList.find(hTasks);
    if (lit == _sHookList.end()) return false; // HWND wasn't in the list
    _sHookList.erase(lit); // erase the HWND from the list
    if (_sHookList.empty()) InstallShellFilter(false); // No more items in the list, 
                                                     // uninstall the shell hook
    return true;
}

void HookManager::ProcessMsgMessage(HWND hOriginal, HOOKMSGDATA* pMsgData) {
    sMsgHookList *psHwnds;
    sMsgHookList::reverse_iterator lrit;
    msg2hwnd::iterator m2hit;
    m2hit = _m2hmap.find(pMsgData->dwData); //Find the message
    if (m2hit != _m2hmap.end()) { // Message found
        psHwnds = (*m2hit).second; // Get the set
        for(lrit=psHwnds->rbegin(); lrit != psHwnds->rend(); lrit++) { // Iterate through the set
            PostMessage(*lrit, WM_COPYDATA, (WPARAM)hOriginal, (LPARAM)pMsgData); // Pass on the message
        }
    }
}

void HookManager::ProcessShellMessage(HWND hTasks, UINT message) {
    if (!_sHookList.empty()) {
        sShellHookList::iterator it;
        for(it = _sHookList.begin(); it != _sHookList.end(); it++) { // Iterate through the set
            PostMessage(*it, message, (WPARAM)hTasks, 0); // Pass on the message
        }
    }
}
