#define STRICT
#include <windows.h>
#include <io.h>
#include <stdio.h>
#include "resource.h"
#include "unrar.h"

const char szAboutText[] =
"Francis Gastellu - LoneRunnr - lone@aegis-corp.org \r\n"
"The original creator of LiteStep. Thank you for releasing the source which helped made LiteStep evolve so much since. \r\n"
"\r\n"
"Brandon Williams - Floach - branwil@rage.gac.peachnet.edu \r\n"
"Co-Project leader and coordinator, documentation writer. \r\n"
"\r\n"
"Bryan Kilian - MHolmesIV - bryan@rucus.ru.ac.za \r\n"
"Co-Project leader and coordinator, CVS tree maintainer, core coding. \r\n"
"\r\n"
"Damian Hodgkiss - Mian - mian@mindless.com \r\n"
"Core coding, wharf coding. Now retired; thanks so much for all your very hard work, man. \r\n"
"\r\n"
"Jonathan Vaughn - Sehnsucht - silverh@mindspring.com \r\n"
"LSVWM development. \r\n"
"\r\n"
"Aaron Putnam - Azerov - azerov@yahoo.com \r\n"
"\r\n"
"Edwin Man - TheMAN - theman@utopia2.com \r\n"
"Documentation writer, NT consulting. \r\n"
"\r\n"
"Scott Nance - Cyric^ - snance@seeingthedesign.com \r\n"
"Documentation writer. \r\n"
"\r\n"
"Josh Devens - cael - caelur@innocent.com \r\n"
"Theme format development, consulting. \r\n"
"\r\n"
"Tim Lloyd - Apollo18 - omaha@tmbg.org \r\n"
"FAQ writer on http://www.litestep.net/faq/. \r\n"

"\r\n------------------------------------------------------------------------------------------------------------------------\r\n\r\n"

"This is the LiteStep Shell for Windows.\r\n"
"\r\n"
"Copyright (C) 1998 LiteStep Development Team\r\n"
"\r\n"
"This program is free software; you can redistribute it and/or\r\n"
"modify it under the terms of the GNU General Public License\r\n"
"as published by the Free Software Foundation; either version 2\r\n"
"of the License, or (at your option) any later version.\r\n"
"\r\n"
"This program is distributed in the hope that it will be useful,\r\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\r\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\r\n"
"GNU General Public License for more details.\r\n"
"\r\n"
"You should have received a copy of the GNU General Public License\r\n"
"along with this program; if not, write to the Free Software\r\n"
"Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.\r\n"

// the end
"\r\n------------------------------------------------------------------------------------------------------------------------\r\n";

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
BOOL CALLBACK BrowseDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

const LPCTSTR szMainWindowClass = "LiteStepInstaller";

// themes defined here.. should be fine to have 4 (because no scrolling support)
char *szThemes[] = { "v0.24 default by tin omen" };
char *szThemeFiles[] = { "24THEME.DAT" };
int maxThemes = 1;

HINSTANCE g_hInst;
HWND hMainWnd;
TCHAR installPath[256];
HICON vers;
HBITMAP bkgnd;
int mouseX, mouseY, currTheme = 0; 

BOOL ExtractArchive(char *dest, char *archive)
{
		char CmtBuf[16384];
    HANDLE hArchive;
    int rCode, pCode;
    struct RARHeaderData HeaderData;
    struct RAROpenArchiveData OpenArchive;
    char szArchive[256];
    
    strcpy(szArchive, archive);
    OpenArchive.ArcName = szArchive;
    OpenArchive.CmtBuf = CmtBuf;
    OpenArchive.CmtBufSize = sizeof(CmtBuf);
    OpenArchive.OpenMode = RAR_OM_EXTRACT;
    hArchive = RAROpenArchive(&OpenArchive);
    
    if (OpenArchive.OpenResult != 0)
    {
      return FALSE;
    }
    
    HeaderData.CmtBuf = NULL;
    
    while ((rCode = RARReadHeader(hArchive, &HeaderData)) == 0)
    {
      pCode = RARProcessFile(hArchive, RAR_EXTRACT, dest, NULL);
      if (pCode != 0)
      {
        RARCloseArchive(hArchive);
        return FALSE;
      }
    }
    
    if (rCode == ERAR_END_ARCHIVE)
    {
      RARCloseArchive(hArchive);
      return TRUE;        
    }
    
    RARCloseArchive(hArchive);
    return FALSE;
}

void StartInstall(void)
{
  char szDest[MAX_PATH], szHelp[MAX_PATH];
  char szArchive[256];
  BOOL rCode;
  int theme = currTheme;
		OSVERSIONINFO osInfo;
    SHELLEXECUTEINFO si;
    
    strcpy(szDest, installPath);
    strcat(szDest, "\0");
    
    strcpy(szArchive, "CORE.DAT");
    rCode = ExtractArchive(szDest, szArchive);
    if (rCode == FALSE)
    {
      MessageBox(NULL, "Error occured during installation\r\nMissing core components", "LiteStep Installation", MB_OK);
      return;
    }
    
    strcpy(szArchive, szThemeFiles[theme]);
    rCode = ExtractArchive(szDest, szArchive);
    if (rCode == FALSE)
    {
      MessageBox(NULL, "Error occured during installation\r\nMissing core components", "LiteStep Installation", MB_OK);
      return;
    }
    
    ZeroMemory(&osInfo, sizeof(osInfo));
    osInfo.dwOSVersionInfoSize = sizeof(osInfo);
    GetVersionEx(&osInfo);
    if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
    {
      if (MessageBox(NULL, "Would you like me to update your Registry with the Shell path?", "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES)
      {
        char szLs[MAX_PATH], szInf[1024];
        HKEY key;
        DWORD result;
        
        wsprintf(szLs, "%sLitestep.exe\0\0", szDest);
        
        wsprintf(szInf, "Install %s for All Users? No will install for Current User (yourself) only", szLs);
        if (MessageBox(NULL, szInf, "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES)
        {
          // setup reg key for all users
          if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS)
          {
            RegSetValueEx(key, "Shell\0", 0, REG_SZ, szLs, lstrlen(szLs)+1);
            RegCloseKey(key);
          }
          
          
        } else {
          // setup reg key for current user only
          if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS)
          {
            RegSetValueEx(key, "Shell\0", 0, REG_SZ, szLs, lstrlen(szLs)+1);
            RegCloseKey(key);
          }
        }
      }
    } else	{
      char szWinDir[MAX_PATH], szInf[1024], szLs[MAX_PATH];
      
      GetWindowsDirectory(szWinDir, sizeof(szWinDir));
      strcat(szWinDir, "\\");
      strcat(szWinDir, "SYSTEM.INI");
      wsprintf(szLs, "%sLitestep.exe", szDest);
      
      wsprintf(szInf, "Would you like me to update %s with the following\r\n\r\nShell=%s", szWinDir, szLs);
      if (MessageBox(NULL, szInf, "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES)
      {
        WritePrivateProfileString("Boot", "Shell", szLs, szWinDir);
      } else {
        wsprintf(szInf, "You will need to manually add %s to %s", szLs, szWinDir);
        MessageBox(NULL, szInf, "LiteStep Installation", MB_OK);
      }
    }
    
    MessageBox(NULL, "Installation successful!", "LiteStep Installation", MB_OK);
    memset(&si, 0, sizeof(si));
    si.cbSize = sizeof(SHELLEXECUTEINFO);
    si.lpDirectory = NULL;
    si.lpVerb = NULL;
    si.nShow = 1;
    si.fMask = SEE_MASK_DOENVSUBST;
    si.lpParameters = NULL;
    wsprintf(szHelp, "%sdoc\\manual.html", szDest);
    si.lpFile = szHelp;
    ShellExecuteEx(&si);
}

BOOL CALLBACK AboutDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  switch(msg)
  {
		case WM_INITDIALOG:
      SetDlgItemText(hwnd, IDC_ABOUT_EDIT, szAboutText);
      break;
      
    case WM_COMMAND:
      switch(wparam)
      {
      case IDOK:
        EndDialog(hwnd, 0);
        break;
      }
      break;
  }
  return DefWindowProc(hwnd, msg, wparam, lparam);        
}

BOOL CALLBACK BrowseDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  static char currPath[MAX_PATH];
  
  switch(msg)
  {
		case WM_USER+666:
      {
        struct _finddata_t finddata;
        long handle;
        char tempPath[MAX_PATH];
        int i;
        char *t;
        
        SendDlgItemMessage(hwnd, IDC_BROWSE_LIST, LB_RESETCONTENT, 0, 0);
        
        // add all the dirs in our current browsing path
        strcpy(tempPath, currPath);
        strcat(tempPath, "*.*");
        handle = _findfirst(tempPath, &finddata);
        while (handle != -1)
        {
          if (strcmp(finddata.name, ".")&&(finddata.attrib & _A_SUBDIR))
          {
            SendDlgItemMessage(hwnd, IDC_BROWSE_LIST, LB_INSERTSTRING, -1, (LPARAM)finddata.name);
          }
          if (_findnext(handle, &finddata) == -1)
          {
            _findclose(handle);
            handle = -1;
          }
        }
        
        // add all the drives on the system
        GetLogicalDriveStrings(sizeof(tempPath), tempPath);
        t = tempPath;
        
        while (t && *t)
        {
          char temp[10];
          
          strcpy(temp, t);
          SendDlgItemMessage(hwnd, IDC_BROWSE_LIST, LB_INSERTSTRING, -1, (LPARAM)temp);
          t += (strlen(t)+1);
        }
        
        
      }
      break;
      
    case WM_INITDIALOG:
      strcpy(currPath, installPath);
      if (currPath[lstrlen(currPath)-1] != '\\')
        strcat(currPath, "\\");
      SetDlgItemText(hwnd, IDC_BROWSE_DEST, currPath);
      SendMessage(hwnd, WM_USER+666, 0, 0);
      break;
      
    case WM_COMMAND:
      if (HIWORD(wparam) == LBN_DBLCLK)
      {
        int currSel = SendDlgItemMessage(hwnd, IDC_BROWSE_LIST, LB_GETCURSEL, 0, 0);
        
        if (currSel != LB_ERR)
        {
          char szText[MAX_PATH];
          
          SendDlgItemMessage(hwnd, IDC_BROWSE_LIST, LB_GETTEXT, currSel, (LPARAM) szText);
          if (!strcmp(szText, ".."))
          {
            int len = lstrlen(currPath);
            
            
            // strip back currpath to last backslash
            while (currPath[len-2] && currPath[len-2] != '\\')
            {
              currPath[len-1] = 0;
              len--;
            }
            currPath[len-1] = 0;
            len--;
            
            if (currPath[lstrlen(currPath)-1] != '\\')
              strcat(currPath, "\\");
          } else 
            if (strchr(szText, ':'))
            {
              strcpy(currPath, szText);
            }
            else
            {
              if (szText[lstrlen(szText)] != '\\')
                strcat(szText, "\\");
              strcat(currPath, szText);
            }
            SendMessage(hwnd, WM_USER+666, 0, 0);
            SetDlgItemText(hwnd, IDC_BROWSE_DEST, currPath);
        }
      }
      
      switch(wparam)
      {
      case IDOK:
        GetDlgItemText(hwnd, IDC_BROWSE_DEST, currPath, sizeof(currPath));
        if (currPath[lstrlen(currPath)-1] != '\\')
          strcat(currPath, "\\");
        strcpy(installPath, currPath);
        EndDialog(hwnd, 0);
        break;
        
      case IDCANCEL:
        EndDialog(hwnd, 0);
        break;
      }
      break;
  }
  return DefWindowProc(hwnd, msg, wparam, lparam);        
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
  switch(msg)
  {
  case WM_CREATE:
    SetWindowText(hwnd, "LiteStep Installation");
    return 0;
    
  case WM_PAINT:
    {
      PAINTSTRUCT ps;
      HDC hdc = BeginPaint(hwnd, &ps);
      HDC dst = CreateCompatibleDC(NULL);
      HDC src = CreateCompatibleDC(NULL);
      HBITMAP hBuf = CreateCompatibleBitmap(hdc, 372, 252);
      HFONT hFont, oldFont;
						RECT r;
            
            hFont = CreateFont (
              12,
              8,
              0,
              0,
              0,
              FALSE,
              FALSE,
              FALSE,
              ANSI_CHARSET,
              OUT_DEFAULT_PRECIS,
              CLIP_DEFAULT_PRECIS,
              DEFAULT_QUALITY,
              DEFAULT_PITCH,
              0);
            
            SelectObject(dst, hBuf);
            SelectObject(src, bkgnd);
            BitBlt(dst, 0, 0, 372, 252, src, 0, 0, SRCCOPY);
            DrawIcon(dst, 330, 25, vers);
            
            oldFont = SelectObject(dst, hFont);
            
            SetBkMode(dst, TRANSPARENT);
            SetTextColor(dst, RGB(175,175,175));
            r.left = 25;
            r.right = 250;
            r.top = 87;
            r.bottom = 97;
            DrawText(dst, installPath, lstrlen(installPath), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
            
            {
              int y = 135, i;
              
              for (i = 0; i < maxThemes; i++)
              {
                if (i == currTheme)
                  SetTextColor(dst, RGB(255,255,255));
                else
                  SetTextColor(dst, RGB(175,175,175));
                TextOut(dst, 25, y, szThemes[i], strlen(szThemes[i]));
                y += 14;
              }
            }
            
            BitBlt(hdc, 0, 0, 372, 252, dst, 0, 0, SRCCOPY);
            
            DeleteDC(src);
            DeleteDC(dst);
            SelectObject(hdc, oldFont);
            DeleteObject(hFont);
            DeleteObject(hBuf);
            EndPaint(hwnd, &ps);
    }
    return 0;
    
  case WM_DESTROY:
    PostQuitMessage(0);
    return 0;
    
  case WM_MOUSEMOVE:
    mouseX = LOWORD(lparam);
    mouseY = HIWORD(lparam);
    return 0;
    
  case WM_LBUTTONDOWN:
    {
      if ((mouseX >= 47)&&(mouseX <= 127)&&(mouseY >= 203)&&(mouseY <= 236))
      {
        StartInstall();
        return 0;
      }
      if ((mouseX >= 150)&&(mouseX <= 225)&&(mouseY >= 203)&&(mouseY <= 236))
      {
        PostQuitMessage(0);
      }
      if ((mouseX >= 246)&&(mouseX <= 314)&&(mouseY >= 203)&&(mouseY <= 236))
      {
								DialogBox(g_hInst, MAKEINTRESOURCE(IDD_ABOUT), hwnd, AboutDlgProc);
      }
      if ((mouseX >= 273)&&(mouseX <= 353)&&(mouseY >= 78)&&(mouseY <= 110))
      {
        RECT r;
        
        DialogBox(g_hInst, MAKEINTRESOURCE(IDD_BROWSE), hwnd, BrowseDlgProc);
        // update install path text
        GetClientRect(hwnd, &r);
        InvalidateRect(hwnd, &r, TRUE);
      }
      if ((mouseX >= 300)&&(mouseX <= 355)&&(mouseY >= 124)&&(mouseY <= 156))
      {
        // View
      }
      if ((mouseX >= 25)&&(mouseX <= 272)&&(mouseY >= 135)&&(mouseY <= 182))
      {
        int i;
        
        i = ((mouseY-135)/14);
        if (i < maxThemes)
        {
          RECT r;
          
          currTheme = i;
          GetClientRect(hwnd, &r);
          InvalidateRect(hwnd, &r, TRUE);
        }
      }
    }
    return 0;
        }
        return DefWindowProc(hwnd, msg, wparam, lparam);        
}

int WINAPI WinMain
(
	HINSTANCE	hInstance,
  HINSTANCE	hPrevInstance,
  LPSTR		lpCmdLine,
  int			nCmdShow
  )
{
  WNDCLASS wc;
  MSG msg;
  RECT r;
  
  if (hPrevInstance)
    return 0;
  
  g_hInst = hInstance;
  
  memset(&wc, 0, sizeof(wc));
  wc.lpfnWndProc = MainWndProc;
  wc.hInstance = hInstance;
  wc.lpszClassName = szMainWindowClass;
  if (!RegisterClass(&wc))
  {
    MessageBox(NULL, "Error registering window class", "Error", MB_OK);
    return 0;
  }
  
  GetClientRect(GetDesktopWindow(),&r);
  
  hMainWnd = CreateWindowEx(
    0,
    szMainWindowClass,
    szMainWindowClass,
    WS_POPUP,
    (r.right/2)-(372/2),
    (r.bottom/2)-(252/2),
    372,
    252,
    NULL,
    NULL,
    hInstance,
    NULL);
  
  if (!hMainWnd)
  {
    MessageBox(NULL, "Error creating window", "Error", MB_OK);
    return 0;
  }
  
  strcpy(installPath, "C:\\LITESTEP\\");
  bkgnd = LoadImage(hInstance, MAKEINTRESOURCE(IDB_BKGND), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR);
  vers = LoadImage(hInstance, MAKEINTRESOURCE(IDI_VERSION), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
  
  SetCursor(LoadCursor(NULL, IDI_APPLICATION));
  ShowWindow(hMainWnd, SW_SHOWNORMAL);
  
  while (GetMessage(&msg, 0, 0, 0))
  {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  
  DeleteObject(bkgnd);
  DeleteObject(vers);
  
  return 0;
}
