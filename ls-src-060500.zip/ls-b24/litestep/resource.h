//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by litestep.rc
//
#define IDI_ICON1                       101
#define IDI_LS                          101
#define IDD_ABOUT                       102
#define IDI_VER                         103
#define IDI_LOGO                        1002
#define IDC_VERSION                     1004
#define IDC_VINFO                       1008
#define IDC_LS                          1009
#define IDC_VER                         1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
