#ifndef LSMODULE
#define LSMODULE

class LSModule {
public:
	virtual int initModule(HWND, HINSTANCE, LPCSTR) = 0;
	virtual void quitModule(HINSTANCE) = 0;
};

#endif //!defined LSMODULE