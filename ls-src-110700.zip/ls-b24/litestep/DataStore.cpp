// DataStore.cpp: implementation of the DataStore class.
//
//////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4786)
#include "DataStore.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DataStore::DataStore()
{

}

DataStore::~DataStore()
{
	Clear();
}

BOOL DataStore::StoreData(WORD id, void *data, WORD len)
{
	dataHolderMap::iterator iter;
	DataHolder *holder;

	iter = dataMap.find(id);

	if (iter != dataMap.end()) {
		return FALSE;
	}

	holder = new DataHolder(data, len);

	dataMap[id] = holder;

	return TRUE;
}

BOOL DataStore::ReleaseData(WORD id, void *data, WORD len)
{
	dataHolderMap::iterator iter;
	DataHolder *holder;

	iter = dataMap.find(id);

	if (iter == dataMap.end()) {
		return FALSE;
	}

	holder = iter->second;
	holder->GetData(data, len);

	delete holder;
	dataMap.erase( iter );

	return TRUE;
}

DataHolder::DataHolder() {
	len = 0;
	data = NULL;
}

DataHolder::DataHolder(void *theData, WORD length) {
	if (theData == NULL || length == 0) {
		len = 0;
		data = NULL;
		return;
	}

	data = new BYTE[length];
	len = length;

	memcpy(data, theData, length);
}

DataHolder::~DataHolder() {
	if (data) {
		delete data;
	}
}

int DataHolder::GetData(void *target, WORD length) {
	if (data == NULL || target == NULL ||
		len == 0 || length == 0) {
		return 0;
	}

	if (length > len) {
		length = len;
	}

	memcpy(target, data, length);

	return length;
}

int DataHolder::SetData(void *source, WORD length) {
	if (source == NULL || length == 0) {
		if (data) {
			delete data;
			data = NULL;
			len = 0;
		}
		return 0;
	}

	if (data == NULL) {
		data = new BYTE[length];
	}

	memcpy(data, source, length);

	len = length;

	return length;
}

void DataStore::Clear()
{
	dataHolderMap::iterator iter;

	iter = dataMap.begin();

	while (iter != dataMap.end()) {
		delete iter->second;
		iter++;
	}

	dataMap.clear();
}
