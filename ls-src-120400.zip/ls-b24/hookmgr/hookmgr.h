#ifndef __HOOKMGR_H
#define __HOOKMGR_H

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include "exports.h"
#include "HookManager.h"
#include "../lsapi/lsapi.h"

#define WC_MAIN TEXT("Hook Manager Window")

#endif __HOOKMGR_H