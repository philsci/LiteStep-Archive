/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
// StepSettings.cpp: implementation of the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#include <windows.h>
#include <comdef.h>
#include "StepSettings.h"
//#include "lsapi.h"
#include "../lsapi/safestr.h"
#include <time.h>
#include <stdio.h>
#include "parser.h"

#define VALUE_NOT_FOUND_STRING L("\0x01")

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
StepSettings::StepSettings()
{
	refCount = 0;
	parser = new Parser(this);
	defaultFile = L"";
}

StepSettings::~StepSettings()
{
	delete parser;
}

FILE* StepSettings::Open(LPCWSTR szPath)
{
  FILE *f;
  char mbcsPath[MAX_PATH];

  WideCharToMultiByte(CP_ACP, 0, szPath, -1, mbcsPath, MAX_PATH, NULL, NULL);
  f = fopen(mbcsPath, "r");

  if (f)
  {
    fseek (f, 0, SEEK_SET);
  }

  return f;
}


BOOL StepSettings::Close (FILE *f)
{
  if (f)
  {
    fclose (f);
  }

  return TRUE;
}

BOOL StepSettings::ReadNextLine (FILE *f, LPWSTR szBuffer, DWORD dwLength)
{
  wchar_t szTempBuffer[MAX_LINE_LENGTH];

  while (f && !feof (f))
  {
    StrCopyW(szBuffer, L"");

    if (!fgetws (szTempBuffer, dwLength, f))
      break;

    StripComment(szTempBuffer);
    CleanString(szTempBuffer);

    if (szTempBuffer[0] && szTempBuffer[0] != ';')
    {
      // Because of caching, we can't do var expansion at this point
      //VarExpansion(szBuffer, szTempBuffer);
      StrCopyW(szBuffer, szTempBuffer);
      return TRUE;
    }
  }

  return FALSE;
}

//---------------------------------------------------------
// Cleans leading & trailing blanks from the passed string
//---------------------------------------------------------
LPWSTR StepSettings::CleanString(LPWSTR szString)
{
  if (!szString)
    return NULL;

  LPWSTR temp = new wchar_t[StrLenW(szString) + 1];
  LPWSTR current = szString;

  current += wcsspn(current, WHITESPACE);

  StrCopyW(temp, current);

  current = &temp[StrLenW(temp) - 1];

  while (_istspace(*current))
    current--;

  current[1] = 0;
  StrCopyW(szString, temp);

  delete[] temp;
  return szString;
}


//---------------------------------------------------------
// Strips any comments from the string
//---------------------------------------------------------
LPWSTR StepSettings::StripComment(LPWSTR szString)
{
  if (!szString)
    return NULL;

  int quoteLevel = 0;
  wchar_t lastQuote = 0;
  LPWSTR current = szString;

  for (; *current; current++)
  {
    switch (*current)
    {
      case '[':
        quoteLevel++;
        break;

      case ']':
        quoteLevel--;
        break;

      case '")':
      case '\'':
        if (lastQuote == *current)
        {
          quoteLevel--;
          lastQuote = 0;
        }
        else if (!lastQuote)
        {
          quoteLevel++;
          lastQuote = *current;
        }
        break;

      case ';':
        if (!quoteLevel)
        {
          *current = 0;
          return szString;
        }
    }
  }
  return szString;
}

// reads, parses, and caches the file specified, returns as 'string' the path the file's cache was stored under
wstring StepSettings::CacheRCFile(LPCWSTR szPath) {
  //char  buffer[MAX_LINE_LENGTH];
	wchar_t long_file[MAX_PATH_LENGTH];
	char *char_ptr;
	wstring rcFile;
	FILE *rc;
	
	// GetFullPathName is not available for UNICODE on Win9X and marks a limitation of this component
	char cPath[MAX_PATH_LENGTH];
	char clong_file[MAX_PATH_LENGTH];
	size_t length = wcslen(szPath);
	WideCharToMultiByte(CP_ACP, 0, szPath, length + 1, cPath, length + 1, NULL, NULL);
	GetFullPathName(cPath, MAX_PATH_LENGTH, clong_file, &char_ptr);
	MultiByteToWideChar(CP_ACP, 0, clong_file, length + 1, long_file, length + 1);
	
	wcslwr(long_file);
	rcFile = long_file;
	
	rc = Open(rcFile.c_str());
	
	if (!rc) {
		// could not open file, return blank file path
		return L"";
	}
	
	if (defaultFile == L"") {
		defaultFile = rcFile;
	}
	
	if (FileToNameToLines.find(rcFile) != FileToNameToLines.end()) {
		// Re-parse, re-cache the file
		FileToNameToLines.erase(rcFile);
	}
	
	// put a vector in the map for _tmain rc file
	FileToNameToLines[rcFile] = CacheMap();
	
	wchar_t name[MAX_RCCOMMAND];
	wchar_t value[MAX_LINE_LENGTH];
	
	while( ReadLine( rc, name, value ) ) {
		ProcessLine( rc, rcFile.c_str(), name, value );
	}
	
	Close(rc);
	
	return rcFile;
}

wstring StepSettings::ProcessInclude(LPCWSTR szPath, LPCWSTR szRCPath) {
	wchar_t long_file[MAX_PATH_LENGTH];
	char *char_ptr;
	wstring rcFile;
	FILE *rc;
	
	GetToken(szPath, long_file, NULL, false);
	
	
	BSTR path;
	path = VarExpansion(long_file);
	
	// GetFullPathName is not available in UNICODE on Win9X and marks a limitation of this component
	{
		char cPath[MAX_PATH_LENGTH];
		char clong_file[MAX_PATH_LENGTH];
		size_t length = wcslen(path);
		WideCharToMultiByte(CP_ACP, 0, path, length + 1, cPath, length + 1, NULL, NULL);
		GetFullPathName(cPath, MAX_PATH_LENGTH, clong_file, &char_ptr);
		MultiByteToWideChar(CP_ACP, 0, clong_file, length + 1, long_file, length + 1);
	}
	
	SysFreeString(path);
	
	wcslwr(long_file);
	rcFile = long_file;
	rc = Open(long_file);
	
	if (!rc) {
		// could not open file, return blank file path
		return L"";
	}
	
	wchar_t name[MAX_RCCOMMAND];
	wchar_t value[MAX_LINE_LENGTH];
	
	while( ReadLine( rc, name, value ) )
		ProcessLine( rc, szRCPath, name, value );
	
	Close(rc);
	
	return rcFile;
}

bool StepSettings::ReadLine( FILE *f, LPWSTR name, LPWSTR value )
{
	wchar_t buffer[MAX_LINE_LENGTH];

	if( !ReadNextLine( f, buffer, MAX_LINE_LENGTH ) )
		return false;


	wchar_t buffer2[MAX_LINE_LENGTH];
	int endConfig = wcscspn(buffer, WHITESPACE);
	wcsncpy(buffer2, buffer, endConfig);
	buffer2[endConfig] = '\0';

	wcslwr(buffer2);

	wchar_t *begin;

	if (endConfig < wcslen(buffer)) {
		begin = buffer + endConfig + 1;
	} else {
		begin = buffer + endConfig;
	}
		
	CleanString(begin);

	wcsncpy( name, buffer2, MAX_RCCOMMAND );
	wcsncpy( value, begin, MAX_LINE_LENGTH );

	return true;
}

bool StepSettings::ProcessLine(FILE *f, LPCWSTR filename, LPCWSTR name, LPCWSTR value)
{
	if(wcscmp(name, L"if") == 0)
		return ProcessIf(f, filename, value);

	if(wcscmp(name, L"include") == 0)
		ProcessInclude(value, filename);

	AddFileLine(filename, name, value);
	AddLine(filename, name, value);

	return true;
}

bool StepSettings::ProcessIf(FILE *f, LPCWSTR filename, LPCWSTR expression)
{
	wchar_t name[MAX_RCCOMMAND];
	wchar_t value[MAX_LINE_LENGTH];
	BOOL result;

	if(!parser->evaluate(expression, &result))
	{
		wchar_t error[MAX_LINE_LENGTH];

		swprintf(error,
			L"Syntax error in If expression:\n%s",
			expression);

		MessageBoxW(NULL, error, L"LiteStep", MB_SETFOREGROUND);
		return false;
	}

	if(result)
	{
		// when the If condition evaluates true we read and process
		// all lines until we reach ElseIf, Else, or EndIf
		while(ReadLine(f, name, value))
		{
			if(wcscmp(name, L"else") == 0 || wcscmp(name, L"elseif") == 0)
			{
				// if we find an ElseIf or Else then we read and ignore
				// all lines until we find EndIf
				SkipIf(f);
				break;
			}
			else if(wcscmp(name, L"endif") == 0)
			{
				// we're done
				break;
			}
			else
			{
				// just a normal line, process it
				ProcessLine(f, filename, name, value);
			}
		}
	}
	else
	{
		// when the If expression evaluates false we read and ignore
		// all lines until we find an ElseIf, Else, or EndIf
		while(ReadLine(f, name, value))
		{
			if(wcscmp(name, L"if") == 0)
			{
				// nested Ifs are a special case
				SkipIf(f);
			}
			else if(wcscmp(name, L"elseif") == 0)
			{
				// we handle ElseIfs by recursively calling ProcessIf
				ProcessIf(f, filename, value);
				break;
			}
			else if(wcscmp(name, L"else") == 0)
			{
				// since the If expression was false, when we see Else
				// we start process lines until EndIf
				while(ReadLine(f, name, value))
				{
					// we should probably check that there are no ElseIfs
					// after the Else, but for now we silently ignore
					// such an error

					// break on EndIf
					if(wcscmp(name, L"endif") == 0)
						break;

					// otherwise process the line
					ProcessLine(f, filename, name, value);
				}

				// we're done
				break;
			}
			else if(wcscmp(name, L"endif") == 0)
			{
				// we're done
				break;
			}
		}
	}

	return true;
}

bool StepSettings::SkipIf(FILE *f)
{
	// read and skip lines until an EndIf, making sure to handle
	// nested Ifs correctly

	wchar_t name[MAX_RCCOMMAND];
	wchar_t value[MAX_LINE_LENGTH];

	while(ReadLine(f, name, value))
	{
		if(wcscmp(name, L"if") == 0)
			SkipIf(f);
		else if(wcscmp(name, L"endif") == 0)
			return true;
	}

	// _TEOF before EndIf
	return false;
}

// Returns the first instance of a line in the cache
LPCWSTR StepSettings::FindLine(LPCWSTR szKeyName)
{
  wchar_t szCommand[256];
  StringAndStringVectorMap::iterator iter;

	wcsncpy(szCommand, szKeyName, 255);
	wcslwr(szCommand);
	iter = NameToFileAndLines.find(szCommand);
	if (iter != NameToFileAndLines.end()) {
		// line exists in the line cache, so it must have an entry
		// only one file per name, so just get the first string in it
		return (*iter).second.second.begin()->c_str();
	}

  return NULL;
}

BOOL StepSettings::RCLineExists( LPCWSTR szKeyName )
{
	return (BOOL) FindLine( szKeyName ) || VariableExists( szKeyName );
}

bool StepSettings::AddVariable(LPCWSTR name, LPCWSTR value)
{
  LPWSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLenW(name))
    return false;

  lowerName = new wchar_t[StrLenW(name) + 1];
  wcslwr(StrCopyW(lowerName, name));

  VarMap::iterator it = stepVariables.find(lowerName);
  if (it == stepVariables.end())
  {
    stepVariables[lowerName] = value;
    result = true;
  }
  else 
  {
	// replace existing value
	stepVariables[lowerName] = value;
	result = false;
  }
  delete[] lowerName;
  return result;
}

void StepSettings::RemoveVariable(LPCWSTR name)
{
  LPWSTR lowerName;
  VarMap::iterator iter;

  if (!StrLenW(name))
    return;

  lowerName = new wchar_t[StrLenW(name) + 1];
  wcslwr(StrCopyW(lowerName, name));

  VarMap::iterator it = stepVariables.find(lowerName);
  if (it != stepVariables.end()) {
	  stepVariables.erase(it);
  }

  delete [] lowerName;
}

bool StepSettings::GetVariable(LPCWSTR name, wstring& value)
{
  LPWSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLenW(name))
    return false;

  lowerName = new wchar_t[StrLenW(name) + 1];
  wcslwr(StrCopyW(lowerName, name));

  iter = stepVariables.find(lowerName);
  if (iter != stepVariables.end())
  {
    value = (*iter).second;
    result = true;
  }
  delete[] lowerName;
  return result;
}

bool StepSettings::VariableExists( LPCWSTR name )
{
	wchar_t *lowerName = new wchar_t[StrLenW(name) + 1];
	StrCopyW( lowerName, name );
	wcslwr( lowerName );

	VarMap::iterator iter = stepVariables.find( lowerName );
	bool exists = iter != stepVariables.end();

	delete[] lowerName;
	return exists;
}

// Add a line with the specified name and value to the cache
bool StepSettings::AddLine(LPCWSTR filename, LPCWSTR name, LPCWSTR value)
{
  LPWSTR lowerName;
  bool result = false;
  StringAndStringVectorMap::iterator iter;

  if (!StrLenW(name))
    return false;

  lowerName = new wchar_t[StrLenW(name) + 1];
  wcslwr(StrCopyW(lowerName, name));

  StringAndStringVectorMap::iterator it = NameToFileAndLines.find(lowerName);
  if (it == NameToFileAndLines.end())
  {
		// nothing in cache yet, or a new file is overwriting previous settings,
		// create a StringAndStringVector to hold lines from this file
    NameToFileAndLines[lowerName] = StringAndStringVector(filename, StringVector());
	}

	// push the line into the cache
	NameToFileAndLines[lowerName].second.push_back(value);
  result = true;

  delete[] lowerName;
  return result;
}

//---------------------------------------------------------
// Extracts the first token and returns a pointer to the
// next. Doesn't care about string lengths
//---------------------------------------------------------
BOOL StepSettings::GetToken(LPCWSTR szString, LPWSTR szToken, LPCWSTR* szNextToken, BOOL useBrackets)
{
  LPCWSTR current = szString;
  LPCWSTR startMarker = NULL;
  int bracketLevel = 0;
  wchar_t quoteChar = '\0';
  bool isToken = false;
	bool appendNextToken = false;

  if (szToken)
    szToken[0] = '\0';
  if (szNextToken)
    *szNextToken = NULL;

  if (!(szString && szString[0]))
    return FALSE;

  current += wcsspn(current, WHITESPACE);

  for (; *current; current++)
  {
    if (_istspace(*current) && !quoteChar)
      break;

    if (useBrackets && CharInStrW(*current, L"[]") && !CharInStrW(quoteChar, L"\'\""))
    {
      if (*current == '[')
      {
        if (isToken && !quoteChar)
          break;
        bracketLevel++;
        quoteChar = '[';
        continue;
      }
      else
      {
        bracketLevel--;
        if (bracketLevel <= 0)
          break;
      }
    }

    if (CharInStrW(*current, L"\'\"") && (quoteChar != '['))
    {
      if (!quoteChar)
      {
        if (isToken)
        {
					appendNextToken = true;
          break;
        }
        quoteChar = *current;
        continue;
      }
      else if (*current == quoteChar)
        break;
    }

    if (!isToken)
    {
      isToken = true;
      startMarker = current;
    }
  }

  if (startMarker && szToken)
    StrLCopyW(szToken, startMarker, current - startMarker);

  if (!appendNextToken && *current)
    current++;

  current += wcsspn(current, WHITESPACE);

  if (*current && szNextToken)
    *szNextToken = current;

	if (appendNextToken && *current)
    GetToken(current, szToken + wcslen(szToken), szNextToken, useBrackets);

  return startMarker != NULL;
}

void StepSettings::ClearAll()
{
	if (stepVariables.size()) {
		stepVariables.clear();
	}
	
	// Clear the caches
	if (NameToFileAndLines.size()) {
		NameToFileAndLines.clear();
	}
	
	if (FileToNameToLines.size())
	{
		FileToNameToLines.clear();
	}
}

CacheMapMap &StepSettings::GetFileToNameToLines() {
  return FileToNameToLines;
}

StringAndStringVectorMap &StepSettings::GetNameToFileAndLines() {
  return NameToFileAndLines;
}

void StepSettings::AddFileLine(LPCWSTR filename, LPCWSTR name, LPCWSTR value)
{
	// Add string vector if one doesn't exist
	CacheMap::iterator iter = FileToNameToLines[filename].find(name);
	if (iter == FileToNameToLines[filename].end()) {
		FileToNameToLines[filename][name] = StringVector();
	}
		
	// Add to list of lines for a given name in this file
	FileToNameToLines[filename][name].push_back(value);
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StepSettings::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IStepSettings) {
		*ppv = static_cast<IStepSettings*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StepSettings::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StepSettings::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

//////////////////////////////////////////////////////////////////////////
// From IStepSettings
BSTR STDMETHODCALLTYPE StepSettings::VarExpansion( 
	/* [in] */ const BSTR value) {
		
	wchar_t buffer[MAX_LINE_LENGTH];
	
	int i, j;
	wchar_t * startDollar, * endDollar;
	wchar_t * string1;
	wchar_t buf[MAX_LINE_LENGTH];
	wchar_t buf2[MAX_LINE_LENGTH];
	wchar_t bvalue[MAX_LINE_LENGTH];
	int StillVars = 1;
	wchar_t *envvar;
	VarMap::iterator it;

	if (value)
	{
		StrCopyW(bvalue, value);
		CleanString(bvalue);
		StrCopyW(buffer, bvalue);
	}
	else
	{
		if (buffer && !value)
			buffer[0] = '\0';
		return SysAllocString(buffer);
	}

	while (StillVars)
	{
		startDollar = wcschr(bvalue, '$');
		if (startDollar)
		{
			endDollar = wcschr(&startDollar[1], '$');
			if (endDollar)
			{
				i = StrLenW(startDollar) - StrLenW(endDollar) - 1;
				j = StrLenW(bvalue) - StrLenW(startDollar);
				string1 = startDollar;
				string1++;
				StrLCopyW(buf, _wcslwr(string1), i);
				buf[i]='\0';
				
				envvar=NULL;
				
				wstring var_value;
				
				if (!GetVariable(buf, var_value))
				{
					BSTR buf3 = GetString(buf, buf);
					if (!buf3)
					{
						envvar = _wgetenv(buf);
						if (envvar != NULL)
						{
							// caching environment variables
							SetVariable(buf, envvar);
						}
						else
						{
							// caching blank, prevent future lookups, errors
							wchar_t warning[MAX_LINE_LENGTH];              
							SetVariable(buf, buf2);
							swprintf(warning, L"Uninitialized variable: %s \n at line: %s", buf, value);
							MessageBoxW(NULL, warning, L"Uninitialized Variable", MB_OK | MB_ICONWARNING | MB_TOPMOST);
						}
					} else {
						StrLCopyW(buf2, buf3, 255);
						SysFreeString(buf3);
					}
				}
				else
				{
					StrCopyW(buf2,var_value.c_str());
				}
				if (bvalue != startDollar)
				{
					StrLCopyW(buffer, bvalue, j);
					buffer[j] = '\0';
				}
				else
				{
					StrCopyW(buffer, L"");
				}
				
				if (envvar)
				{
					wcscat(buffer,envvar);
				}
				else
				{
					wcscat(buffer, buf2);
				}
				wcscat(buffer, ++endDollar);
				StrCopyW(bvalue, buffer);
			}
			else
			{
				StillVars = 0;
			}
		}
		else
		{
			StillVars = 0;
		}
	}

	return SysAllocString(buffer);
}

void STDMETHODCALLTYPE StepSettings::Clear( void) {
	ClearAll();
}

void STDMETHODCALLTYPE StepSettings::SetVariable( 
    /* [in] */ const BSTR name,
    /* [in] */ const BSTR value) {

	AddVariable(name, value);
}

void STDMETHODCALLTYPE StepSettings::ClearVariable( 
    /* [in] */ const BSTR name) {

	RemoveVariable(name);
}

BSTR STDMETHODCALLTYPE StepSettings::ParseFile( 
    /* [in] */ const BSTR stepfile) {

	wstring file = CacheRCFile(stepfile);

	return SysAllocString(file.c_str());
}

int STDMETHODCALLTYPE StepSettings::GetInt( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ int nDefault) {

	int val = nDefault;
	LPCWSTR line;
	wchar_t token[MAX_LINE_LENGTH];

	// Couldn't find it, look in theme.rc/step.rc
	line = FindLine(szKeyName);
	if (line)
	{
		// use first token now...FindLine returns remainder of line now
		if (GetToken(line, token, NULL, false))
			val = wcstol(token, NULL, 0);
		
		return val;
	} else {
		// Try to find the variable in the pre-defined set
		wstring value;
		
		if (GetVariable(szKeyName, value)) {
			return wcstol(value.c_str(), NULL, 0);
		}
	}

	// nothing found, return default
	return nDefault;
}

BOOL STDMETHODCALLTYPE StepSettings::GetBool( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL ifFound) {

	BOOL val = !ifFound;
	BOOL cache_val = FALSE;
	wchar_t token[MAX_LINE_LENGTH];
	LPCWSTR line;  

	line = FindLine(szKeyName);
	if (line)
	{
		// use first token now...FindLine returns remainder of line now
		if (GetToken(line, token, NULL, false))
		{
			if (wcsicmp(token, L"off") && wcsicmp(token, L"false") && wcsicmp(token, L"no"))
			{
				cache_val = TRUE;
				val = ifFound;
			}
		}
		else
		{
			cache_val = TRUE;
			val = ifFound;
		}
		if (cache_val)
			val = ifFound;
		else
			val = !ifFound;
		
		return val;
	}

	// nothing found, return !ifFound
	return !ifFound;
}

BOOL STDMETHODCALLTYPE StepSettings::GetBoolDef( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL bDefault) {

	BOOL result = bDefault;
	wchar_t token[MAX_LINE_LENGTH];
	LPCWSTR line;
	wstring value;

	line = FindLine(szKeyName);
	if (line)
	{
		result = TRUE;
		if (GetToken(line, token, &line, false))
		{
			if (!(wcsicmp(token, L"off") && wcsicmp(token, L"false") && wcsicmp(token, L"no")))
				result = FALSE;
		}
	} else {
		if (GetVariable(szKeyName, value))
		{
			return !wcsicmp(value.c_str(), L"true");
		}
	}

	return result;
}

BSTR STDMETHODCALLTYPE StepSettings::GetString( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR defStr) {

	wchar_t token[MAX_LINE_LENGTH];
	LPCWSTR line;
	BOOL result = FALSE;

	line = FindLine(szKeyName);
	if (line)
	{
		// use first token now...FindLine returns remainder of line now
		GetToken(line, token, NULL, false);
		
		return VarExpansion(token);
	} else {
		// check for predefined value
		wstring value;
		
		if (GetVariable(szKeyName, value))
		{
			return SysAllocString(value.c_str());
		}
	}

	return SysAllocString(defStr);
}

COLORREF STDMETHODCALLTYPE StepSettings::GetColor( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ COLORREF colDef) {

	wchar_t token[MAX_LINE_LENGTH];
	LPCWSTR line;

	line = FindLine(szKeyName);
	if (line)
	{
		int count = Tokenize(_bstr_t(line), 0, NULL, NULL, FALSE);
		
		if(count >= 3)
		{
			int r, g, b;
			
			GetToken(line, token, &line, false);
			r = wcstol(token, NULL, 10);
			GetToken(line, token, &line, false);
			g = wcstol(token, NULL, 10);
			GetToken(line, token, NULL, false);
			b = wcstol(token, NULL, 10);
			
			return RGB(r, g, b);
		}
		else if(count >= 1)
		{
			GetToken(line, token, NULL, false);
			COLORREF val = wcstol(token, NULL, 16);
			
			if(!GetBool(L"LSColorBGR", TRUE))
				val = RGB(GetBValue(val), GetGValue(val), GetRValue(val));
			return val;
		}
	}
	return colDef;
}

BSTR STDMETHODCALLTYPE StepSettings::GetLine( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR szDefault) {

	wchar_t buffer[MAX_LINE_LENGTH] = L"";

	LPCWSTR line = L"";

	if (!szKeyName) {
		return NULL;
	}

	// find it
	line = FindLine(szKeyName);

	if (line)
	{
		// copy complete line as is
		return SysAllocString(line);
	}
	else {
		// check for predefined value
		wstring value;
		
		if (GetVariable(szKeyName, value))
		{
			return SysAllocString(value.c_str());
		}
	}

	if (szDefault) {
		return SysAllocString(szDefault);
	} else {
		return NULL;
	}
}

BOOL STDMETHODCALLTYPE StepSettings::Token( 
    /* [in] */ const BSTR szString,
    /* [out] */ BSTR __RPC_FAR *szToken,
    /* [out] */ int __RPC_FAR *iNextToken,
    /* [in] */ BOOL useBrackets) {

	wchar_t token[MAX_LINE_LENGTH];
	const wchar_t *newStr;
	BOOL result;

	if (iNextToken) {
		*iNextToken = 0;
	}

	result = GetToken(szString, token, &newStr, useBrackets);

	*szToken = SysAllocString(token);
	if (newStr != 0) {
		*iNextToken = newStr - szString; // difference in pointers is index
	}

	return result;
}

int STDMETHODCALLTYPE StepSettings::Tokenize( 
    /* [in] */ const BSTR szString,
    /* [in] */ int dwNumBuffers,
    /* [size_is][out] */ BSTR __RPC_FAR outTokens[  ],
    /* [out] */ BSTR __RPC_FAR *remainder,
    /* [in] */ BOOL useBrackets) {

	wchar_t szExtraParameters[MAX_LINE_LENGTH];
	wchar_t lpszBuffer[MAX_LINE_LENGTH];
	BSTR buffer;
	LPCWSTR nextToken;
	DWORD tokens = 0;

	lpszBuffer[0] = '\0';
	szExtraParameters[0] = '\0';

	buffer = VarExpansion(szString);
	nextToken = buffer;

	if (outTokens || remainder)
	{
		for (tokens = 0; nextToken && (tokens < dwNumBuffers); tokens++)
		{
			GetToken(nextToken, lpszBuffer, &nextToken, useBrackets);

			if (outTokens) {
				outTokens[tokens] = SysAllocString(lpszBuffer);
			}
		}
		
		if (szExtraParameters && nextToken) {
			StrCopyW(szExtraParameters, nextToken);
		}
	} else {
		while (GetToken(nextToken, NULL, &nextToken, useBrackets)) {
			tokens++;
		}
	}

	if (remainder != NULL) {
		*remainder = SysAllocString(szExtraParameters);
	}

	SysFreeString(buffer);

	return tokens;
}

IStepIterator *STDMETHODCALLTYPE StepSettings::GetIterator( 
    /* [in] */ const BSTR szPath) {
	IStepIterator *istep = new StepIterator(szPath, this);
	istep->AddRef();

	return istep;
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StepIterator::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IStepIterator) {
		*ppv = static_cast<IStepIterator*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StepIterator::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StepIterator::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

//////////////////////////////////////////////////////////////////////////
// From IStepIterator
StepIterator::StepIterator(BSTR szPath, StepSettings *stepsets) {
	wchar_t full_path[MAX_PATH_LENGTH];
	char *char_ptr;

	ss = stepsets;

	if (szPath && wcslen(szPath) > 0) {
		// GetFullPathName is not available for UNICODE on Win9X and marks a limitation of this component
		char cPath[MAX_PATH_LENGTH];
		char clong_file[MAX_PATH_LENGTH];
		size_t length = wcslen(szPath);
		WideCharToMultiByte(CP_ACP, 0, szPath, length + 1, cPath, length + 1, NULL, NULL);
		GetFullPathName(cPath, MAX_PATH_LENGTH, clong_file, &char_ptr);
		MultiByteToWideChar(CP_ACP, 0, clong_file, length + 1, full_path, length + 1);

		wcslwr(full_path);
	} else {
		wcscpy(full_path, ss->defaultFile.c_str());
		wcslwr(full_path);
	}

	if (ss->GetFileToNameToLines().find(full_path) == ss->GetFileToNameToLines().end()) {
		// Have not read the file yet...read and cache
		if (ss->CacheRCFile(full_path) == L"") {
			MessageBoxW(NULL, L"File not found", full_path, MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);

			filename = L"";

			// setting both to true will cause all IStepIterator methods to fail
			command_iter_valid = true;
			line_iter_valid = true;

			return;
		}
	}

	filename = full_path;
	command_iter_valid = false;
	line_iter_valid = false;

	refCount = 0;
}

StepIterator::~StepIterator() {
}

BSTR STDMETHODCALLTYPE StepIterator::NextConfig( 
    /* [in] */ const BSTR szPrefix) {
	
	if (line_iter_valid) {
		// !!! We should not have line iter valid, error out !!!
		return NULL;
	}

	// lowcasify
	wchar_t low_prefix[MAX_LINE_LENGTH];
	wcscpy(low_prefix, szPrefix);
	wcslwr(low_prefix);

	// first time through, get command iter
	if (!command_iter_valid) {
		command_iter = ss->GetFileToNameToLines()[filename].find(low_prefix);

		if (command_iter == ss->GetFileToNameToLines()[filename].end()) {
			// Command not found, clear and return
			command_iter_valid = false;

			return NULL;
		}

		// command found, get line iter
		line_iter = (*command_iter).second.begin();
		command_iter_valid = true;
	}

	if (line_iter == (*command_iter).second.end()) {
		// end of this command, clear and return
		//state->command_iter_valid = false;

		// WE DO NOT clear here, since failure indicates that we have reached the end of this
		// cached file. Clearing the above variable causes the loop over the file contents to
		// restart. EOF should continue to fail for subsequent reads.

		return NULL;
	}

	// At this point we should have an acceptable config line, build and return it
	wchar_t buffer[MAX_LINE_LENGTH];

	buffer[0] = 0; // blank
	wcscat(buffer, (*command_iter).first.c_str()); // command name
	wcscat(buffer, L" "); // space
	wcscat(buffer, (*line_iter).c_str()); // configuration line

	// just increment the config iter, leave it to the next loop to determine if it's valid
	line_iter++;

	return ss->VarExpansion(buffer);
}


BSTR STDMETHODCALLTYPE StepIterator::NextLine() {
	
	wchar_t szBuffer[MAX_LINE_LENGTH] = L"";

	if (command_iter_valid) {
		// !!! We should not have line iter valid, error out !!!
		return NULL;
	}

	// first time through, get command iter
	if (!line_iter_valid) {
		line_map_iter = ss->GetNameToFileAndLines().begin();

		if (line_map_iter == ss->GetNameToFileAndLines().end()) {
			// Command not found, clear and return
			//state->command_iter_valid = false;

			// WE DO NOT clear here, since failure indicates that we have reached the end of the
			// cached lines. Clearing the above variable causes the loop over the lines to
			// restart. EOF should continue to fail for subsequent reads.

			return NULL;
		}

		// command found, get line iter
		line_iter = (*line_map_iter).second.second.begin();
		line_iter_valid = true;
	}

	if (line_iter == (*line_map_iter).second.second.end()) {
		// end of lines for this prefix, move to next
		line_map_iter++;

		if (line_map_iter == ss->GetNameToFileAndLines().end()) {
			// end of lines, clear and return
			line_iter_valid = false;

			return NULL;
		}

		line_iter = (*line_map_iter).second.second.begin();
	}

	// At this point we should have an acceptable config line, build and return it
	wchar_t buffer[MAX_LINE_LENGTH];

	buffer[0] = 0; // blank
	wcscat(buffer, (*line_map_iter).first.c_str()); // command name
	wcscat(buffer, L" "); // space
	wcscat(buffer, (*line_iter).c_str()); // configuration line

	// just increment the config iter, leave it to the next loop to determine if it's valid
	line_iter++;

	return ss->VarExpansion(buffer);
}
