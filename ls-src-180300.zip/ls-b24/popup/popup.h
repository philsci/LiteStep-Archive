#ifndef __POPUP_H
#define __POPUP_H

#include "../litestep/wharfdata.h"
#include "../lsapi/lsapi.h"

const MAX_TEXT = 256;
const MAX_TOKEN = 2048;
const MENU_TIMER = 701;
const SCROLL_TIMER = 702;
const SCROLL_DELAY = 10;

//pre-decl
class Popup;

//---------------------------------------------------------
// the list class
//---------------------------------------------------------
template<class T> class list {
public:
  T *data;
protected:
  size_t count;
  size_t increment;
  size_t allocated;
public:
  list(int alloc = 16, int inc = 8);
  virtual ~list();
  T& operator[](size_t i);
  const T& operator[](size_t i) const;
  size_t add(const T& t);
  size_t size() const;
  void copy( const list<T>& l);
  void clear();
  void sort(int (__cdecl *compare )(const void *elem1, const void *elem2));
  bool validIndex(size_t indx) const;
protected:
  void reallocate(size_t num = 0);
};

//---------------------------------------------------------
// simple bitmap class
//---------------------------------------------------------
class BitMP {
public:
  HBITMAP bitmap;
  HRGN region;
  char name[MAX_TEXT];
  int x;
  int y;
  COLORREF backColor;
  COLORREF foreColor;

  BitMP();
  ~BitMP() {destroy();}
protected:
  void destroy();
};

//---------------------------------------------------------
// menuItem class
//---------------------------------------------------------
class menuItem {
public:
  enum itemType {mi_basic, mi_folder, mi_static, mi_dynamic, mi_tasks};
  Popup *owner;
  char name[MAX_TEXT];
  char command[MAX_TEXT];
  char params[MAX_TEXT];
  Popup *sub;
  HICON hIcon;
  itemType type;

  menuItem();
  menuItem(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams = NULL, Popup* pop = NULL);
  ~menuItem();
protected:
  void init();
};

//---------------------------------------------------------
// the menu item list
//---------------------------------------------------------
class itemList : public list<menuItem> {
public:
  int add(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams = NULL, Popup *lp = NULL);
};

class timer {
  int id;
  bool timerSet;
  Popup *tmPop;
  int tmNdx;   // item in this popup
public:
  timer(int i) {id=i, timerSet=false, tmPop=NULL, tmNdx=-1;}
  void setTimer(Popup *p, int indx, int interval = 0);
  void killTimer();
  bool sameItem(Popup *p, int indx) const;
  void resetIndex() {tmNdx = -1;}
};

//---------------------------------------------------------
// the popup list container
//---------------------------------------------------------
class Popup {
public:
  Popup *parent;
  char title[MAX_TEXT];
  size_t current;
  size_t first;
  size_t last;
  size_t numVisible;
  bool onLeft;  // For drawing menus on the left
  bool autoMenu;
  HWND hwnd;
  itemList list;
  static BOOL init;
  HRGN region;
public:
  Popup(Popup *parent = NULL);
  ~Popup();
  friend LRESULT CALLBACK wndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  menuItem* safeItem(int indx) const;
  size_t firstVisible();
  size_t lastVisible();
  void firstVisible(size_t n);
  void lastVisible(size_t n);
  void scroll(bool downd);
  bool createWindow();
  void destroyWindow();
  void showWindow(bool show = true);
  void openSubMenu(int num);
  void display(int x, int y);
  void display(POINT pt) {display(pt.x, pt.y);}
  void paint();
  void paintBMP(HDC dest, HDC src, BitMP &bmp, RECT r);
  void paintBMP2(HDC src, BitMP bmp, RECT r);
  void drawItem(const menuItem& mi, HDC hdc, HDC mem, BitMP &bmp, RECT r);
  bool itemRect(size_t indx, RECT *lpRect) const;
  int calcSize(SIZE& s) const;
  int  itemAt(POINT pt) const;
  bool highlight(int indx, bool snapCursor = false);
  int  hittest(POINT pt, int *pindx = NULL) const; // HTCAPTION/HTCLIENT/HTNOWHERE
  void moveMenu(Popup *p, int indx);
  void closeSubmenus(Popup *p = NULL);
  bool execute(int indx = -1); // -1 means execute 'current'
  bool isPopupWnd(HWND hwnd);
  enum {
    gi_clsid = 0x01,   //lookup among predefined CLSIDs
    gi_shell = 0x02    //ask shell to provide icon info
  };
  void getIcon(menuItem& mi, BYTE flags = gi_clsid|gi_shell);
  void registryLookup(char* subKey, char *value);
  void openDynamic(int indx, bool dynamic = true);
  void showTasks(int indx);
  void loadValues();
  void loadMenus();
  void selectItem(BOOL selected);
  void GetRegion();
  int AlphaNav(char chSearchChar, int nStartPoint);
};

#ifdef  __cplusplus
extern "C" {
#endif  /* __cplusplus */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef  __cplusplus
};
#endif  /* __cplusplus */

#endif  /* __LSAPI_H */
