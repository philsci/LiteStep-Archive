#ifndef __VWM_H
#define __VWM_H

#include <windows.h>
#include "../lsapi/lsapi.h"

typedef struct {
	HWND hwnd;
	HICON hicon;
	RECT r;
	char valid;
	} winDataType;

typedef struct {
	HWND hwnd;
	char screen;
	} winFixType;

typedef struct {
	char match[80];
} ConfigInfoT;

#define WIN_KEY 0
#define ALT_KEY 1
#define CTRL_KEY 2

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);

__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int quitWharfModule(HINSTANCE dll);

#ifdef __cplusplus
}
#endif

#endif
