#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#include "../core/ifcs.h"

class DStepIteratorImpl: public DStepIterator {
	IStepIterator *stepiter;
	long refCount;

public:
	DStepIteratorImpl(IStepIterator *i);
	~DStepIteratorImpl();

	///////////////////////////////////////////////////////////////////////
	// From IUnknown
    virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
    
    virtual ULONG STDMETHODCALLTYPE AddRef( void);
    
    virtual ULONG STDMETHODCALLTYPE Release( void);

	/////////////////////////////////////////////////////////////////////
	// From IDispatch
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo);
    
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( 
        /* [in] */ UINT iTInfo,
        /* [in] */ LCID lcid,
        /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
    
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
        /* [in] */ REFIID riid,
        /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
        /* [in] */ UINT cNames,
        /* [in] */ LCID lcid,
        /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
    
    virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
        /* [in] */ DISPID dispIdMember,
        /* [in] */ REFIID riid,
        /* [in] */ LCID lcid,
        /* [in] */ WORD wFlags,
        /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
        /* [out] */ VARIANT __RPC_FAR *pVarResult,
        /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
        /* [out] */ UINT __RPC_FAR *puArgErr);

	///////////////////////////////////////////////////////////////////
	// From DStepIterator
    virtual HRESULT STDMETHODCALLTYPE NextConfig( 
        /* [in] */ const BSTR szPrefix,
        /* [retval][out] */ BSTR *szBuffer);
    
    virtual HRESULT STDMETHODCALLTYPE NextLine( 
        /* [retval][out] */ BSTR *szBuffer);
};

class DStepSettingsImpl: public DStepSettings {
private:
	IStepSettings *stepSettings;
	long refCount;

public:

	DStepSettingsImpl(IStepSettings* ss);
	~DStepSettingsImpl();

	///////////////////////////////////////////////////////////////////////
	// From IUnknown
    virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
    
    virtual ULONG STDMETHODCALLTYPE AddRef( void);
    
    virtual ULONG STDMETHODCALLTYPE Release( void);

	/////////////////////////////////////////////////////////////////////
	// From IDispatch
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo);
    
    virtual HRESULT STDMETHODCALLTYPE GetTypeInfo( 
        /* [in] */ UINT iTInfo,
        /* [in] */ LCID lcid,
        /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
    
    virtual HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
        /* [in] */ REFIID riid,
        /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
        /* [in] */ UINT cNames,
        /* [in] */ LCID lcid,
        /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
    
    virtual /* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
        /* [in] */ DISPID dispIdMember,
        /* [in] */ REFIID riid,
        /* [in] */ LCID lcid,
        /* [in] */ WORD wFlags,
        /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
        /* [out] */ VARIANT __RPC_FAR *pVarResult,
        /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
        /* [out] */ UINT __RPC_FAR *puArgErr);

	/////////////////////////////////////////////////////
	// From DStepSettings
    virtual HRESULT STDMETHODCALLTYPE VarExpansion( 
        /* [in] */ const BSTR value,
        /* [retval][out] */ BSTR __RPC_FAR *buffer);
    
    virtual HRESULT STDMETHODCALLTYPE ParseFile( 
        /* [in] */ const BSTR stepfile,
        /* [retval][out] */ BSTR __RPC_FAR *fullpath);
        
    virtual HRESULT STDMETHODCALLTYPE GetInt( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ int nDefault,
        /* [retval][out] */ int __RPC_FAR *value);
    
    virtual HRESULT STDMETHODCALLTYPE GetBool( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ BOOL ifFound,
        /* [retval][out] */ BOOL __RPC_FAR *value);
    
    virtual HRESULT STDMETHODCALLTYPE GetBoolDef( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ BOOL bDefault,
        /* [retval][out] */ BOOL __RPC_FAR *value);
    
    virtual HRESULT STDMETHODCALLTYPE GetString( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ const BSTR defStr,
        /* [retval][out] */ BSTR __RPC_FAR *szValue);
    
    virtual HRESULT STDMETHODCALLTYPE GetColor( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ COLORREF colDef,
        /* [retval][out] */ COLORREF __RPC_FAR *value);
    
    virtual HRESULT STDMETHODCALLTYPE GetLine( 
        /* [in] */ const BSTR szKeyName,
        /* [in] */ const BSTR szDefault,
        /* [retval][out] */ BSTR __RPC_FAR *szBuffer);
    
    virtual HRESULT STDMETHODCALLTYPE Tokenize( 
        /* [in] */ const BSTR szString,
        /* [in] */ BOOL useBrackets,
        /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *lpszBuffers);
    
    virtual HRESULT STDMETHODCALLTYPE GetIterator( 
        /* [in] */ const BSTR szPath,
        /* [retval][out] */ DStepIterator __RPC_FAR *hState);
};
