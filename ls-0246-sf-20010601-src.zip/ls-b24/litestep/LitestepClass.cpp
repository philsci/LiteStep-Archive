/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
// Litestep.cpp: implementation of the Litestep class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)
#include <windows.h>
#include <comdef.h>
#include "LitestepClass.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Litestep::Litestep()
{
	refCount = 0;

	myLogDispatch = NULL;
}

Litestep::~Litestep()
{
	if (myLogDispatch) {
		myLogDispatch->Release();
	}
}

void Litestep::SetLogDispatch(ILogDispatch *log) {
	myLogDispatch = log;
	myLogDispatch->AddRef();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE Litestep::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_ILitestep) {
		*ppv = static_cast<ILitestep*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE Litestep::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE Litestep::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

////////////////////////////////////////////////////////////////////////
// From ILitestep
HRESULT STDMETHODCALLTYPE Litestep::GetWindowList( 
    /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist) {

	*winlist = (IWindowList*)WindowListMap[L"default"];

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::FindWindowList( 
    /* [in] */ BSTR name,
    /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = WindowListMap.find(name_str);
	if (iter == WindowListMap.end()) {
		*winlist = NULL;
		return E_FAIL;
	}

	*winlist = (IWindowList*)iter->second;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::RegisterWindowList( 
    /* [in] */ BSTR name,
    /* [in] */ IWindowList __RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = WindowListMap.find(name_str);
	if (iter != WindowListMap.end()) {
		return E_FAIL;
	}

	WindowListMap[name_str] = (void*)winlist;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::UnregisterWindowList( 
    /* [in] */ BSTR name) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = WindowListMap.find(name_str);
	if (iter == WindowListMap.end()) {
		return E_FAIL;
	}

	WindowListMap.erase(name_str);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::GetMessageManager( 
    /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist) {

	*winlist = (IMessageManager*)MessageManagerMap[L"default"];

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::FindMessageManager( 
    /* [in] */ BSTR name,
    /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = MessageManagerMap.find(name_str);
	if (iter == MessageManagerMap.end()) {
		*winlist = NULL;
		return E_FAIL;
	}

	*winlist = (IMessageManager*)iter->second;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::RegisterMessageManager( 
    /* [in] */ BSTR name,
    /* [in] */ IMessageManager __RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = MessageManagerMap.find(name_str);
	if (iter != MessageManagerMap.end()) {
		return E_FAIL;
	}

	MessageManagerMap[name_str] = (void*)winlist;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::UnregisterMessageManager( 
    /* [in] */ BSTR name) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = MessageManagerMap.find(name_str);
	if (iter == MessageManagerMap.end()) {
		return E_FAIL;
	}

	MessageManagerMap.erase(name_str);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::GetModuleManager( 
    /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist) {

	*winlist = (IModuleManager*)ModuleManagerMap[L"default"];

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::FindModuleManager( 
    /* [in] */ BSTR name,
    /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = ModuleManagerMap.find(name_str);
	if (iter == ModuleManagerMap.end()) {
		*winlist = NULL;
		return E_FAIL;
	}

	*winlist = (IModuleManager*)iter->second;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::RegisterModuleManager( 
    /* [in] */ BSTR name,
    /* [in] */ IModuleManager __RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = ModuleManagerMap.find(name_str);
	if (iter != ModuleManagerMap.end()) {
		return E_FAIL;
	}

	ModuleManagerMap[name_str] = (void*)winlist;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::UnregisterModuleManager( 
    /* [in] */ BSTR name) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = ModuleManagerMap.find(name_str);
	if (iter == ModuleManagerMap.end()) {
		return E_FAIL;
	}

	ModuleManagerMap.erase(name_str);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::GetBangManager( 
    /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist) {

	*winlist = (IBangManager*)BangManagerMap[L"default"];

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::FindBangManager( 
    /* [in] */ BSTR name,
    /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = BangManagerMap.find(name_str);
	if (iter == BangManagerMap.end()) {
		*winlist = NULL;
		return E_FAIL;
	}

	*winlist = (IBangManager*)iter->second;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::RegisterBangManager( 
    /* [in] */ BSTR name,
    /* [in] */ IBangManager __RPC_FAR *winlist) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = BangManagerMap.find(name_str);
	if (iter != BangManagerMap.end()) {
		return E_FAIL;
	}

	BangManagerMap[name_str] = (void*)winlist;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::UnregisterBangManager( 
    /* [in] */ BSTR name) {

	wchar_t *name_str = _bstr_t(name);

	IFCMap::iterator iter = BangManagerMap.find(name_str);
	if (iter == BangManagerMap.end()) {
		return E_FAIL;
	}

	BangManagerMap.erase(name_str);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE Litestep::GetLogDispatch( 
	/* [retval][out] */ ILogDispatch __RPC_FAR *__RPC_FAR *log_dispatch) {

	if (!myLogDispatch || !log_dispatch) {
		return E_FAIL;
	}

	*log_dispatch = myLogDispatch;

	return S_OK;
}

