/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
10/02/00 - Joachim Calvert (NeXTer)
  - Enter, Mul, Div, Add, Sub and Dec (decimal key) are now supported
08/30/00 - Joachim Calvert (NeXTer)
  - Shouldn't reserve unused hotkeys anymore (specifically ctrl-esc), let me
    know if it doesn't work
08/17/00 - Joachim Calvert (NeXTer)
  - Now responds to the !Refresh command
04/25/00 - Bobby G. Vinyard (Message)
  - Ugh forgot to clear the hotkey maps when hotkeys were unloaded
04/20/00 - Joachim Calvert (NeXTer)
  - Now uses the LSWinBase library
04/18/00 - Bobby G. Vinyard (Message)
  - Rewrite based on the Desktop2 code
****************************************************************************/

#include "hotkey.h"
#include "resource.h"

const _TCHAR rcsRevision[] = _TEXT("$Revision: 1.2 $"); // Our Version
const _TCHAR rcsId[] = _TEXT("$Id: hotkey.cpp,v 1.2 2001/06/01 09:23:44 message Exp $"); // The Full RCS ID.

static const VKTable vkTable[] = {
  {_TEXT("ESCAPE"), VK_ESCAPE},
  {_TEXT("F1"), VK_F1},
  {_TEXT("F2"), VK_F2},
  {_TEXT("F3"), VK_F3},
  {_TEXT("F4"), VK_F4},
  {_TEXT("F5"), VK_F5},
  {_TEXT("F6"), VK_F6},
  {_TEXT("F7"), VK_F7},
  {_TEXT("F8"), VK_F8},
  {_TEXT("F9"), VK_F9},
  {_TEXT("F10"), VK_F10},
  {_TEXT("F11"), VK_F11},
  {_TEXT("F12"), VK_F12},
  {_TEXT("PAUSE"), VK_PAUSE},
  {_TEXT("INSERT"), VK_INSERT},
  {_TEXT("DELETE"), VK_DELETE},
  {_TEXT("HOME"), VK_HOME},
  {_TEXT("END"), VK_END},
  {_TEXT("PAGEUP"), VK_PRIOR},
  {_TEXT("PAGEDOWN"), VK_NEXT},
  {_TEXT("LEFT"), VK_LEFT},
  {_TEXT("RIGHT"), VK_RIGHT},
  {_TEXT("UP"), VK_UP},
  {_TEXT("DOWN"), VK_DOWN},
  {_TEXT("TAB"), VK_TAB},
  {_TEXT("BACKSPACE"), VK_BACK},
  {_TEXT("SPACEBAR"), VK_SPACE},
  {_TEXT("APPS"), VK_APPS},
  {_TEXT("ENTER"), VK_RETURN},
  {_TEXT("NUM0"), VK_NUMPAD0},
  {_TEXT("NUM1"), VK_NUMPAD1},
  {_TEXT("NUM2"), VK_NUMPAD2},
  {_TEXT("NUM3"), VK_NUMPAD3},
  {_TEXT("NUM4"), VK_NUMPAD4},
  {_TEXT("NUM5"), VK_NUMPAD5},
  {_TEXT("NUM6"), VK_NUMPAD6},
  {_TEXT("NUM7"), VK_NUMPAD7},
  {_TEXT("NUM8"), VK_NUMPAD8},
  {_TEXT("NUM9"), VK_NUMPAD9},
  {_TEXT("MUL"), VK_MULTIPLY},
  {_TEXT("DIV"), VK_DIVIDE},
  {_TEXT("ADD"), VK_ADD},
  {_TEXT("SUB"), VK_SUBTRACT},
  {_TEXT("DEC"), VK_DECIMAL},
};

#define MAX_VKEYS (sizeof(vkTable) / sizeof(VKTable))

const _TCHAR szAppName[] = _TEXT("HotkeyWindow");

Hotkey *hotkey; // The module


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
  int code = 0;

  Window::init(dllInst);
  hotkey = new Hotkey(parentWnd, code);

  return code;
}


void quitModule(HINSTANCE dllInst)
{
  delete hotkey;
}


//=========================================================
// Module code
//=========================================================
//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Hotkey::Hotkey(HWND parentWnd, int& code):
Window(szAppName)
{
  if (!createWindow(WS_EX_TOOLWINDOW, _TEXT("LSHotkey"), WS_CHILD,
                    0, 0, 0, 0, parentWnd))
  {
    RESOURCE_MSGBOX(GetModuleHandle(NULL), IDS_HOTKEY_ERROR1,
      _TEXT("Error creating window"), szAppName);

    code = 1;
    return;
  }
  code = 0;
}


Hotkey::~Hotkey()
{
  destroyWindow();
}


void Hotkey::loadHotkeys()
{
  FILE* f;

  loadExplorerKeys = GetRCBool(_TEXT("HotkeyLoadExplorerKeys"), TRUE) != FALSE;
  noWinKeyPopup = GetRCBool(_TEXT("HotkeyNoWinKeyPopup"),TRUE) != FALSE;
  noShellWarning = GetRCBool(_TEXT("LSNoShellWarning"), TRUE) != FALSE;
  explorerNoWarn = GetRCBool(_TEXT("ExplorerNoWarn"), TRUE) != FALSE;

  f = LCOpen(NULL);
  if (f)
  {
    _TCHAR	buffer[4096];
    _TCHAR	token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
    LPTSTR	tokens[4];

    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;
    tokens[3] = token4;

    buffer[0] = 0;

    while (LCReadNextConfig (f, _TEXT("*Hotkey"), buffer, sizeof (buffer)))
    {
      int count, i;

      token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';

      count = LCTokenize (buffer, tokens, 4, extra_text);

      if (count == 4)
      {
        _TCHAR *tmp;
        HotkeyType tempHotkey;

        tempHotkey.sub = 0;
        tmp = _tcstok(token2, _TEXT("+"));

        while (tmp)
        {
          if (!strcmpi(tmp, _TEXT("Win")))
            tempHotkey.sub |= MOD_WIN;
          if (!strcmpi(tmp, _TEXT("Alt")))
            tempHotkey.sub |= MOD_ALT;
          if (!strcmpi(tmp, _TEXT("Ctrl")))
            tempHotkey.sub |= MOD_CONTROL;
          if (!strcmpi(tmp, _TEXT("Shift")))
            tempHotkey.sub |= MOD_SHIFT;
          tmp = _tcstok(NULL, _TEXT("+"));
        }

        if (lstrlen(token3) == 1)
          tempHotkey.ch = strupr(token3)[0];
        else {
          for (i = 0; i < MAX_VKEYS; i++)
          {
            if (!strcmpi(vkTable[i].key, token3))
            {
              tempHotkey.ch = vkTable[i].vKey;
              break;
            }
          }
        }

        tempHotkey.szCommand = token4;
        tempHotkey.szParameters = extra_text;
        hotKeys.push_back(tempHotkey);
        RegisterHotKey(hWnd, hotKeys.size(), tempHotkey.sub, tempHotkey.ch);
      }
    }
  }
  LCClose(f);
  // Load Explorer Hotkeys
  if (loadExplorerKeys)
  {
    loadExplorerHotkeys();
  }

	if (!noWinKeyPopup)
  {
		if ((!RegisterHotKey(hWnd, GlobalAddAtom(_TEXT("LWIN_KEY")),MOD_WIN, VK_LWIN)) ||
      (!RegisterHotKey(hWnd, GlobalAddAtom(_TEXT("RWIN_KEY")),MOD_WIN, VK_RWIN)))
    {
      RESOURCE_MSGBOX(GetModuleHandle(NULL), IDS_HOTKEY_ERROR2,
      _TEXT("Error registering Win Key"), szAppName)
		}
	  if (!(noShellWarning || explorerNoWarn))
    {
		  if (!RegisterHotKey(hWnd, GlobalAddAtom(_TEXT("CTL_ESC")),MOD_CONTROL,VK_ESCAPE))
      {
        RESOURCE_MSGBOX(GetModuleHandle(NULL), IDS_HOTKEY_ERROR3,
          _TEXT("Error registering Ctrl+Esc"), szAppName)
      }
	  }
	}
}


void Hotkey::loadExplorerHotkeys()
{
	HKEY shellFoldersKey;
	DWORD dataType, dataLength = 1024;

	_TCHAR szAllStartMenu[1024];	// WinNT
	_TCHAR szAllDesktop[1024];	// WinNT
	_TCHAR szUserStartMenu[1024];
	_TCHAR szUserDesktop[1024];

	// Hotkey Code
	RegisterHotKey(hWnd, GlobalAddAtom(_TEXT("REINIT")), MOD_CONTROL | MOD_ALT | MOD_SHIFT, 'R');

	RegOpenKey(HKEY_CURRENT_USER, _TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders"), &shellFoldersKey);
	dataLength = sizeof (szUserStartMenu);
	if (RegQueryValueEx(shellFoldersKey, _TEXT("Start Menu"), NULL, &dataType, (LPBYTE) szUserStartMenu, &dataLength) != ERROR_SUCCESS)
		_tcscpy(szUserStartMenu, _TEXT(""));
	dataLength = sizeof (szUserDesktop);
	if (RegQueryValueEx(shellFoldersKey, _TEXT("Desktop"), NULL, &dataType, (LPBYTE) szUserDesktop, &dataLength) != ERROR_SUCCESS)
		_tcscpy(szUserDesktop, _TEXT(""));
	RegCloseKey(shellFoldersKey);

	RegOpenKeyEx(HKEY_LOCAL_MACHINE, _TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders"), 0, KEY_READ, &shellFoldersKey);
	dataLength = sizeof (szAllStartMenu);
	if (RegQueryValueEx(shellFoldersKey, _TEXT("Common Start Menu"), NULL, &dataType, (LPBYTE) szAllStartMenu, &dataLength) != ERROR_SUCCESS)
		_tcscpy(szAllStartMenu, _TEXT(""));
	dataLength = sizeof (szAllDesktop);
	if (RegQueryValueEx(shellFoldersKey, _TEXT("Common Desktop"), NULL, &dataType, (LPBYTE) szAllDesktop, &dataLength) != ERROR_SUCCESS)
		_tcscpy(szAllDesktop, _TEXT(""));
	RegCloseKey(shellFoldersKey);

	if (_tcscmp(szUserStartMenu, _TEXT(""))) 
  {
		SetCurrentDirectory(szUserStartMenu);
		findLnks(szUserStartMenu);
	}
	if (_tcscmp(szUserDesktop, _TEXT(""))) 
  {
		SetCurrentDirectory(szUserDesktop);
		findLnks(szUserDesktop);
	}
	if (_tcscmp(szAllStartMenu, _TEXT(""))) 
  {
		SetCurrentDirectory(szAllStartMenu);
		findLnks(szAllStartMenu);
	}
	if (_tcscmp(szAllDesktop, _TEXT(""))) 
  {
		SetCurrentDirectory(szAllDesktop);
		findLnks(szAllDesktop);
	}
}


void Hotkey::findLnks(LPCTSTR szBaseSearchDir) 
{
	WIN32_FIND_DATA findDirData;
	WIN32_FIND_DATA findLnkData;
	HANDLE hDirFind;
	HANDLE hLnkFind;
	_TCHAR szSearchDir[1024];

	SetCurrentDirectory(szBaseSearchDir);
	hLnkFind = FindFirstFile(_TEXT("*.lnk"), &findLnkData);
	if (hLnkFind != INVALID_HANDLE_VALUE) 
  {
		if (findLnkData.dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY) 
    {
			addExplorerHotkey(szBaseSearchDir, findLnkData.cFileName);
		}
		while (FindNextFile(hLnkFind, &findLnkData)) 
    {
			if (findLnkData.dwFileAttributes ^ FILE_ATTRIBUTE_DIRECTORY) 
      {
				addExplorerHotkey(szBaseSearchDir, findLnkData.cFileName);
			}
		}
	}
	FindClose(hLnkFind);

	hDirFind = FindFirstFile(_TEXT("*.*"), &findDirData);
	if (hDirFind != INVALID_HANDLE_VALUE) 
  {
		if (findDirData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) 
    {
			if ((_tcscmp(findDirData.cFileName, _TEXT(".")) != 0) && (_tcscmp(findDirData.cFileName, _TEXT("..")) != 0)) 
      {
				_tcscpy(szSearchDir, szBaseSearchDir);
				_tcscat(szSearchDir, _TEXT("\\"));
				_tcscat(szSearchDir, findDirData.cFileName);
				findLnks(szSearchDir);
				SetCurrentDirectory(szBaseSearchDir);
			}
		}

		while (FindNextFile(hDirFind, &findDirData)) 
    {
			if (findDirData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) 
      {
				if (_tcscmp(findDirData.cFileName, _TEXT(".")) != 0 && _tcscmp(findDirData.cFileName, _TEXT("..")) != 0) 
        {
					_tcscpy(szSearchDir, szBaseSearchDir);
					_tcscat(szSearchDir, _TEXT("\\"));
					_tcscat(szSearchDir, findDirData.cFileName);
					findLnks(szSearchDir);
					SetCurrentDirectory(szBaseSearchDir);
				}
			}
		}
	}
	FindClose(hDirFind);
}


void Hotkey::addExplorerHotkey(LPCTSTR szBaseFileDir, LPCTSTR szFileName)
{
  HANDLE hFile;
  BYTE btHotKey;
  BYTE btModifier;
  LONG lHotKeyOffset = 64;
  DWORD dwRead;
  _TCHAR szLnkFile[1024];
  ATOM aHotKey;

  _tcscpy(szLnkFile, szBaseFileDir);
  _tcscat(szLnkFile, _TEXT("\\"));
  _tcscat(szLnkFile, szFileName);

  hFile = CreateFile(szLnkFile,
				GENERIC_READ,
        0,
        NULL,
        OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
        NULL);

  if (hFile != INVALID_HANDLE_VALUE) 
  {
    SetFilePointer(hFile, lHotKeyOffset, NULL, FILE_BEGIN);
    ReadFile(hFile, &btHotKey, 1, &dwRead, NULL);
    ReadFile(hFile, &btModifier, 1, &dwRead, NULL);

    aHotKey = GlobalAddAtom(szLnkFile);
    if (aHotKey) 
    {
      atomHotkeys.push_back(aHotKey);
      if (btHotKey && btModifier) 
      {

        switch(btModifier) 
        {
          case 0x03:
            RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_SHIFT, btHotKey);
            break;
          case 0x05:
            RegisterHotKey(hWnd, aHotKey, MOD_SHIFT | MOD_ALT, btHotKey);
            break;
          case 0x06:
            RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_ALT, btHotKey);
            break;
          case 0x07:
            RegisterHotKey(hWnd, aHotKey, MOD_CONTROL | MOD_SHIFT | MOD_ALT, btHotKey);
            break;
          default:
            break;
        }
      }
      CloseHandle(hFile);
    }
  }
}


void Hotkey::freeHotkeys()
{
  UnregisterHotKey(hWnd, GlobalFindAtom(_TEXT("LWIN_KEY")));
  UnregisterHotKey(hWnd, GlobalFindAtom(_TEXT("RWIN_KEY")));
  UnregisterHotKey(hWnd, GlobalFindAtom(_TEXT("CTL_ESC")));
  GlobalDeleteAtom(GlobalFindAtom(_TEXT("LWIN_EY")));
  GlobalDeleteAtom(GlobalFindAtom(_TEXT("RWIN_KEY")));
  GlobalDeleteAtom(GlobalFindAtom(_TEXT("CTL_ESC")));

  for (size_t i = 0; i < hotKeys.size(); i++)
  {
    UnregisterHotKey(hWnd,i);
  }
  hotKeys.clear();

  if (loadExplorerKeys)
  {
    freeExplorerHotkeys();
  }
}


void Hotkey::freeExplorerHotkeys()
{
	ATOM aHotKey;

	aHotKey = GlobalFindAtom(_TEXT("REINIT"));
	UnregisterHotKey(hWnd, aHotKey);
	GlobalDeleteAtom (aHotKey);

	for (size_t j = 0; j < atomHotkeys.size(); j++) 
  {
		aHotKey = atomHotkeys[j];
		if (aHotKey != 0) 
    {
			UnregisterHotKey(hWnd, aHotKey);
			GlobalDeleteAtom(aHotKey);
		}
	}
  atomHotkeys.clear();
}


//=========================================================
// Message handling
//=========================================================

void Hotkey::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onEndSession, WM_ENDSESSION)
    MESSAGE(onEndSession, WM_QUERYENDSESSION)
    REJECT_MESSAGE(WM_ERASEBKGND)
    REJECT_MESSAGE(WM_PAINT)
    MESSAGE(onGetRevId, LM_GETREVID)
    MESSAGE(onRefresh, LM_REFRESH)
    MESSAGE(onHotkey, WM_HOTKEY)
    MESSAGE(onSysCommand, WM_SYSCOMMAND)
    MESSAGE(onTimer, WM_TIMER)
  END_MESSAGEPROC
}


void Hotkey::onCreate(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  loadHotkeys();
}


void Hotkey::onDestroy(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  freeHotkeys();
}


void Hotkey::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onGetRevId(Message& message)
{
  LPTSTR buf = (LPTSTR)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      _stprintf(buf, _TEXT("hotkey.dll: %s"), &rcsRevision[11]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    case 1:
      _tcscpy(buf, &rcsId[1]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    default:
      _tcscpy(buf, _TEXT(""));
  }
  message.lResult = _tcsclen(buf);
}


void Hotkey::onRefresh(Message& message)
{
  freeHotkeys();
  loadHotkeys();
}


void Hotkey::onHotkey(Message& message)
{
  size_t num = message.wParam - 1;
  if (num < hotKeys.size())
  {
    if (hotKeys[num].szCommand.length())
    {
      if (hotKeys[num].szCommand[0] == '!')
      {
        KillTimer(hWnd, 1);
        ParseBangCommand(hWnd, hotKeys[num].szCommand.c_str(), hotKeys[num].szParameters.c_str());
      }
      else
      {
        _TCHAR workDirectory[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR];

        _tsplitpath(hotKeys[num].szCommand.c_str(), drive, dir, NULL, NULL);
        _tcscpy(workDirectory, drive);
        _tcscat(workDirectory, dir);

        LSExecuteEx(GetDesktopWindow(), NULL, hotKeys[num].szCommand.c_str(), hotKeys[num].szParameters.c_str(), workDirectory, SW_SHOWNORMAL);

        KillTimer(hWnd, 1);
      }
    }
  }
  else 
  {
		_TCHAR szCommand[1024];

		if (GlobalGetAtomName((ATOM)message.wParam, szCommand, 1024) > 0)
		{
			if (!_tcscmp(szCommand, _TEXT("CTL_ESC")))
				SendMessage(hParent, LM_POPUP, 0, 0);
			else if (!_tcscmp(szCommand, _TEXT("REINIT")) && loadExplorerKeys)
      {
				freeExplorerHotkeys();
				loadExplorerHotkeys();
			}
      else if (!_tcscmp(szCommand, _TEXT("LWIN_KEY")))
      {
				SetTimer(hWnd, 1, 750, NULL);
			}
      else if (!_tcscmp(szCommand, _TEXT("RWIN_KEY")))
      {
				SetTimer(hWnd, 1, 750, NULL);
			}
      else
      {
				KillTimer(hWnd, 1);
				if (loadExplorerKeys)
        {
					_TCHAR workDirectory[_MAX_PATH];
          _TCHAR drive[_MAX_DRIVE];
          _TCHAR dir2[_MAX_DIR];

          _tsplitpath(szCommand, drive, dir2, NULL, NULL);
          _tcscpy(workDirectory, drive);
          _tcscat(workDirectory, dir2);

          LSExecuteEx(hWnd, NULL, szCommand, NULL, workDirectory, SW_SHOWNORMAL);
				}
			}
		}
	}
}

void Hotkey::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Hotkey::onTimer(Message& message)
{
	if (message.wParam == 1)
  {
		ParseBangCommand(hWnd, _TEXT("!Popup"), NULL);
		KillTimer(hWnd, 1);
	}
}

