/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// Standard system module header

#ifndef __HOTKEY_H
#define __HOTKEY_H

#define WIN32_LEAN_AND_MEAN

#pragma	warning(disable: 4786) // STL naming warnings

#include <windows.h>
#include <vector>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"

using namespace std;

struct VKTable
{
	char* key;
	int vKey;
};

struct HotkeyType
{
  string szCommand;
  string szParameters;
  int sub;
  char ch;
};

class Hotkey : public Window
{
private:
  typedef vector<HotkeyType> HotkeyVec;
  typedef vector<ATOM> AtomVec;

  bool loadExplorerKeys;
  bool noWinKeyPopup;
  bool noShellWarning;
  bool explorerNoWarn;
  AtomVec atomHotkeys;
  HotkeyVec hotKeys;

public:
  Hotkey(HWND parentWnd, int& code);
  ~Hotkey();

private:
  void loadHotkeys();
  void loadExplorerHotkeys();
  void findLnks(const char*);
  void addExplorerHotkey(const char*, const char*);
  void freeHotkeys();
  void freeExplorerHotkeys();

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);
  void onDestroy(Message& message);
  void onHotkey(Message& message);
  void onTimer(Message& message);
};

extern "C" {
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
