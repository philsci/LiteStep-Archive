#define WIN32_LEAN_AND_MEAN
#define STRICT
#define LS_NEXTDLG 9500
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
//#include <string.h>
#include <io.h>
#include <sys/stat.h>
#include <shlobj.h>
#include <shellapi.h>
#include "resource.h"
#include "fdi.h"
#include "registry.h"

BOOL IsWin9x;
BOOL IsAdmin;
BOOL UnInstall;
BOOL Config;
TCHAR szConfigArg[MAX_PATH];
const int NUMFILES = 4;

char currentDir[MAX_PATH];
char * installFile[NUMFILES];
char installPath[MAX_PATH] = "C:\\LiteStep\\"; //common string to pass to decompressor
char installBasePath[MAX_PATH] = "C:\\LiteStep\\"; //litestep main files path
char installWharfModPath[MAX_PATH] = "C:\\LiteStep\\Modules\\"; //litestep Wharf Modules path
char installLoadModPath[MAX_PATH] = "C:\\LiteStep\\"; //litestep Load Modules path
char windowsDir[MAX_PATH] = "C:\\Windows\\";
char startMenuDir[MAX_PATH] = "C:\\Windows\\Start Menu\\Programs\\";

char win9xVersion[] = "Windows 95/98/98se";
char winNTVersion[] = "Windows NT/2000";

char sysIniFile[MAX_PATH];
char newIniSetting[MAX_PATH];
char oldIniSetting[MAX_PATH];
char newRegSettingHKLM[MAX_PATH];
char newRegSettingHKLM2[MAX_PATH];
char newRegSettingHKCU[MAX_PATH];
char newRegSettingHKCU2[MAX_PATH];
char oldTmpRegSetting[MAX_PATH];

const char szLicenseAgreeText[] =
	"Thank you for choosing to install LiteStep 0.24.5\r\n"
	"           as your Win32 Shell replacement.\r\n"
	"\r\n"
	"                 ------------------------------\r\n"
	"If you agree to the following terms click 'I Agree' otherwise "
	"click 'Exit' and remove all portions of this software from your computer\r\n"
	"                 ------------------------------\r\n"
	"\r\n"
	"Copyright (C) 1999 LiteStep Development Team\r\n"
	"\r\n"
	"This program is free software; you can redistribute it and/or "
	"modify it under the terms of the GNU General Public License "
	"as published by the Free Software Foundation; either version 2"
	"of the License, or (at your option) any later version.\r\n"
	"\r\n"
	"This program is distributed in the hope that it will be useful, "
	"but WITHOUT ANY WARRANTY; without even the implied warranty of "
	"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the "
	"GNU General Public License for more details.\r\n"
	"\r\n"
	"You should have received a copy of the GNU General Public License"
	"along with this program; if not, write to the Free Software"
	"Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.";

const char szAboutConfigText[] =
	"To configure your system to run LiteStep as your Shell click 'Next'. To exit the installation without configuring your system, click 'Exit'. \r\n"
	"\r\n"
	"You will have complete control over the following configuration. No values will be set without you first accepting them.\r\n"
	"\r\n"
	"You will still have one more chance to exit the configuration, without applying the system changes, after clicking 'Next'.";

const char szInstallTypeText[] =
	"Full Install -\r\n"
	"==============\r\n"
	"This is the recommended Installation Type for all new users, as well as those that want the new default theme.  However, if you do already have LiteStep installed, "
	"and you choose this option, you should install to a new directory, to avoid overwriting your current setup, as well as to avoid sharing violation conflicts when "
	"overwriting your current LiteStep components.\r\n"
	"\r\n"
	"A full installation consists of copying all of the LiteStep files including a default Theme into the installation directory of your choice.\r\n"
	"\r\n"
	"It also allows you to setup and configure your system to load LiteStep as your shell, or any Shell swapper you may want to use. However that part is optional, and fully customizable.\r\n"
	"\r\n"
	"\r\n"
	"Upgrade Install -\r\n"
	"=================\r\n"
	"This is the recommended Installation Type for all current users of LiteStep.\r\n"
	"\r\n"
	"An upgrade installation will allow you to specify a directory to install the core LiteStep files, as well as a directory to install the LiteStep module (dll) files.\r\n"
	"\r\n"
	"This installation will also prompt you issue the LiteStep !Quit command to close the running instance of LiteStep, before installing the files, and when finished will prompt you again whether or not you want to run the newly installed LiteStep Shell.\r\n"
	"\r\n"
	"\r\n"
	"For more installation information please refer to the online documentation located at:\r\nhttp://www.litestep.org/help/ls-024_5/\r\nhttp://www.litestep.org/files/readmes/ls-024_5.txt";

const char szAllDoneText[]=
	"We have finished installing and configuring LiteStep to run on your system. You may now choose to either reboot your computer, or return to Windows.\r\n"
	"\r\n"
	"Please read the documentation located in the \"Docs\" folder in your LiteStep directory. Thank you, and enjoy LiteStep!";

const char szAdminOrNotText[]=
	"Click \"Not Admin\" to configure your NT account to run LiteStep for a single user without Administrative access. (note: You will not be able to run Explorer.exe as a File Manager. If you do so, it will reload Explorer as the Shell and disable LiteStep.)\r\n"
	"\r\n"
	"Click \"Admin\" to configure your NT machine to run LiteStep either as your global shell, or for the current user account only. (note: if you have Administrative access and you only want to run LiteStep as the Shell for the current account you will need to configure all other accounts to run a specific shell; either LiteStep, Explorer, or another shell of choice.)";

const char szInsertStepRCTextA[]=
	";=====================================================\n"
	";===========(Begin) LiteStep Core Setup===============\n"
	"; Path to Windows Directory\n";

char szInsertStepRCTextB[256]=
	"WinDir ";

const char szInsertStepRCTextC[]=
	"\n"
	"; Path to Windows Start Menu Program's Directory\n";

char szInsertStepRCTextD[256]=
	"StartMenuDir ";
	
const char szInsertStepRCTextE[]=
	"\n"
	"; Path to LiteStep Directory\n";

char szInsertStepRCTextF[256]=
	"LiteStepDir ";


HINSTANCE exeInst;
HWND mainWnd;
const char szTitle[] = "LiteStep 0.24.5 Installation";
const char szUnTitle[] = "LiteStep 0.24.5 UnInstall";
const char szWindowClass[] = "LiteStepInstaller";
//const char szLSVersion[] = "0.24.5";
//const char szLSName[] = "LiteStep";
int screenHeight, screenWidth;

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK AgreeDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK InstTypeDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SettingsDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK HelpDlgProc(HWND, UINT, WPARAM, LPARAM);
//LRESULT CALLBACK ProgressDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK InstCompleteDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SysSettingsDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK UpgradeSettingsDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK AllDoneDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK AdminOrNotDlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SysSettingsNT1DlgProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK SysSettingsNT2DlgProc(HWND, UINT, WPARAM, LPARAM);

void BrowseForFolder(char *tmp, char *szBrowseTitle, HWND callerWnd);
void WriteStepRC(void);

/*
 * Memory allocation function
 */
FNALLOC(mem_alloc)
{
	return malloc(cb);
}
/*
 * Memory free function
 */
FNFREE(mem_free)
{
	free(pv);
}
FNOPEN(file_open)
{
	return _open(pszFile, oflag, pmode);
}
FNREAD(file_read)
{
	return _read(hf, pv, cb);
}
FNWRITE(file_write)
{
	return _write(hf, pv, cb);
}
FNCLOSE(file_close)
{
	return _close(hf);
}
FNSEEK(file_seek)
{
	return _lseek(hf, dist, seektype);
}
FNFDINOTIFY(notification_function)
{
	switch (fdint)
	{
		case fdintCOPY_FILE:	// file to be copied
		{
			int		handle;
			char	destination[256];

				sprintf(
					destination, 
					"%s%s",
					installPath,
					pfdin->psz1
				);

				handle = file_open(
				destination,
				_O_BINARY | _O_CREAT | _O_WRONLY | _O_SEQUENTIAL,
				_S_IREAD | _S_IWRITE 
			);

			return handle;
		}

		case fdintCLOSE_FILE_INFO:	// close the file, set relevant info
        {
            HANDLE  handle;
            DWORD   attrs;
            char    destination[256];

            sprintf(
                destination, 
                "%s%s",
                installPath,
                pfdin->psz1
            );

			file_close(pfdin->hf);


            /*
             * Set date/time
             *
             * Need Win32 type handle for to set date/time
             */
            handle = CreateFile(
                destination,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                NULL
            );

            if (handle != INVALID_HANDLE_VALUE)
            {
                FILETIME    datetime;

                if (TRUE == DosDateTimeToFileTime(
                    pfdin->date,
                    pfdin->time,
                    &datetime))
                {
                    FILETIME    local_filetime;

                    if (TRUE == LocalFileTimeToFileTime(
                        &datetime,
                        &local_filetime))
                    {
                        (void) SetFileTime(
                            handle,
                            &local_filetime,
                            NULL,
                            &local_filetime
                        );
                     }
                }

                CloseHandle(handle);
            }

            /*
             * Mask out attribute bits other than readonly,
             * hidden, system, and archive, since the other
             * attribute bits are reserved for use by
             * the cabinet format.
             */
            attrs = pfdin->attribs;

            attrs &= (_A_RDONLY | _A_HIDDEN | _A_SYSTEM | _A_ARCH);

            (void) SetFileAttributes(
                destination,
                attrs
            );

			return TRUE;
        }
			return 0;
	}

	return 0;
}
BOOL test_fdi(char *cabinet_fullpath)
{
	HFDI			hfdi;
	ERF				erf;
	FDICABINETINFO	fdici;
	int				hf;
	char			*p;
	char			cabinet_name[256];
	char			cabinet_path[256];

	hfdi = FDICreate(
		mem_alloc,
		mem_free,
		file_open,
		file_read,
		file_write,
		file_close,
		file_seek,
		cpu80386,
		&erf
	);

	if (hfdi == NULL)
	{

		return FALSE;
	}


	/*
	 * Is this file really a cabinet?
	 */
	hf = file_open(
		cabinet_fullpath,
		_O_BINARY | _O_RDONLY | _O_SEQUENTIAL,
		0
	);

	if (hf == -1)
	{
		(void) FDIDestroy(hfdi);

		return FALSE;
	}

	if (FALSE == FDIIsCabinet(
			hfdi,
			hf,
			&fdici))
	{
		/*
		 * No, it's not a cabinet!
		 */
		_close(hf);

		(void) FDIDestroy(hfdi);
		return FALSE;
	}
	else
	{
		_close(hf);

	}

	p = strrchr(cabinet_fullpath, '\\');

	if (p == NULL)
	{
		strcpy(cabinet_name, cabinet_fullpath);
		strcpy(cabinet_path, "");
	}
	else
	{
		strcpy(cabinet_name, p+1);

		strncpy(cabinet_path, cabinet_fullpath, (int) (p-cabinet_fullpath)+1);
		cabinet_path[ (int) (p-cabinet_fullpath)+1 ] = 0;
	}

	if (TRUE != FDICopy(
		hfdi,
		cabinet_name,
		cabinet_path,
		0,
		notification_function,
		NULL,
		NULL))
	{

		(void) FDIDestroy(hfdi);
		return FALSE;
	}

	if (FDIDestroy(hfdi) != TRUE)
	{

		return FALSE;
	}

	return TRUE;
}
char *return_fdi_error_string(FDIERROR err)
{
	switch (err)
	{
		case FDIERROR_NONE:
			return "No error";

		case FDIERROR_CABINET_NOT_FOUND:
			return "Cabinet not found";
			
		case FDIERROR_NOT_A_CABINET:
			return "Not a cabinet";
			
		case FDIERROR_UNKNOWN_CABINET_VERSION:
			return "Unknown cabinet version";
			
		case FDIERROR_CORRUPT_CABINET:
			return "Corrupt cabinet";
			
		case FDIERROR_ALLOC_FAIL:
			return "Memory allocation failed";
			
		case FDIERROR_BAD_COMPR_TYPE:
			return "Unknown compression type";
			
		case FDIERROR_MDI_FAIL:
			return "Failure decompressing data";
			
		case FDIERROR_TARGET_FILE:
			return "Failure writing to target file";
			
		case FDIERROR_RESERVE_MISMATCH:
			return "Cabinets in set have different RESERVE sizes";
			
		case FDIERROR_WRONG_CABINET:
			return "Cabinet returned on fdintNEXT_CABINET is incorrect";
			
		case FDIERROR_USER_ABORT:
			return "User aborted";
			
		default:
			return "Unknown error";
	}
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	nCmdShow = nCmdShow;
	MSG msg;
	WNDCLASSEX wcex;
	exeInst = hInstance;
	char			*ptr;

	if (!hPrevInstance)
	{/*Set up the window class*/
		wcex.cbClsExtra = 0;
		wcex.cbSize = sizeof(WNDCLASSEX); 
		wcex.cbWndExtra = 0;
		wcex.hbrBackground = NULL;
		wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
		wcex.hIcon = NULL;
		wcex.hIconSm = NULL;
		wcex.hInstance = hInstance;
		wcex.lpfnWndProc = (WNDPROC)WndProc;
		wcex.lpszClassName = szWindowClass;
		wcex.lpszMenuName = NULL;
		wcex.style = NULL;
		if (!RegisterClassEx(&wcex)) 
			return FALSE;
	}

	screenWidth = GetSystemMetrics(SM_CXSCREEN);
	screenHeight = GetSystemMetrics(SM_CYSCREEN);

	ptr = lpCmdLine;
	UnInstall = FALSE;
	Config = FALSE;
	szConfigArg[0] = 0;
	// parse command line switches
	while(1)
	{
		TCHAR szSwitch[32];
		int n;

		while( *ptr && (*ptr == ' ' || *ptr == '\t') )
			ptr++;

		if( *ptr && (*ptr == '/' || *ptr == '-') )
		{
			n = 0;
			ptr++;

			while( *ptr && *ptr != ' ' && *ptr != '\t' )
			{
				if( n < 32 )
					szSwitch[n++] = *ptr;

				ptr++;
			}

			szSwitch[n] = 0;

			if( !lstrcmpi( szSwitch, TEXT("uninstall") ) )
				UnInstall = TRUE;
			else if( !lstrcmpi( szSwitch, TEXT("config") ) )
			{
				Config = TRUE;
				n = 0;
				
				while( *ptr && (*ptr == ' ' || *ptr == '\t') )
					ptr++;
				
				if( *ptr == '\"' )
				{
					ptr++;
					
					while( *ptr && *ptr != '\"' )
					{
						if( n < MAX_PATH )
							szConfigArg[n++] = *ptr;
						
						ptr++;
					}
					
					if( *ptr )
						ptr++;
				}
				else
				{
					while( *ptr && *ptr != ' ' && *ptr != '\t' )
					{
						if( n < MAX_PATH )
							szConfigArg[n++] = *ptr;
						
						ptr++;
					}
				}
				
				szConfigArg[n] = 0;
				strlwr(szConfigArg);
				if (szConfigArg[0] == 0)
				{
					strcpy(szConfigArg, installBasePath);
					strcat(szConfigArg, "litestep.exe");
				}
				else if (strstr( szConfigArg, TEXT(".exe") ) != NULL && szConfigArg[strlen(szConfigArg)-1] != '\\')
				{/*do nothing*/}
				else
				{
					if (szConfigArg[strlen(szConfigArg)-1] != '\\')
						strcat(szConfigArg, "\\");
					strcat(szConfigArg, "litestep.exe");
				}
			}
		}
		else break;
	}

	{/*Create the main window*/
		mainWnd = CreateWindowEx(WS_EX_DLGMODALFRAME|WS_EX_CLIENTEDGE, szWindowClass, (UnInstall ? szUnTitle:szTitle), WS_CAPTION|WS_VISIBLE, (screenWidth-550)/2, (screenHeight-450)/2, 550, 450, NULL, NULL, hInstance, NULL);
		if (!mainWnd)
			return FALSE;
	}

	//retrieve current directory, to use with data files for absolute path
	GetCurrentDirectory(sizeof(currentDir), currentDir);
	strcat(currentDir, "\\");

	if (!UnInstall)
	{
		//setup the different data files to extract
		for (int i = 0; i < NUMFILES; i++)
			installFile[i] = new char[MAX_PATH];
		installFile[0] = "lsdata.000";
		installFile[1] = "lsdata.001";
		installFile[2] = "lsdata.002";
		installFile[3] = "lsdata.003";

		LPITEMIDLIST pidl; // works under NT - by Maudin.
		HRESULT hr;
		IMalloc *pMalloc;

		hr = SHGetSpecialFolderLocation( NULL, CSIDL_PROGRAMS, &pidl );
		
		if( FAILED(hr) )
		{
			// dunno why this would ever fail...
			MessageBox(mainWnd, "Can not find Start Menu folder!", "Error!", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
			return FALSE;
		}

		SHGetPathFromIDList( pidl, startMenuDir );
		strcat(startMenuDir, "\\");
		SHGetMalloc( &pMalloc );
		pMalloc->Free( pidl );
		pMalloc->Release();
	}

	//windows directory
	GetWindowsDirectory(windowsDir, sizeof(windowsDir));
	strcat(windowsDir, "\\");

	//Operating System version
	OSVERSIONINFO osInfo;
	ZeroMemory(&osInfo, sizeof(osInfo));
	osInfo.dwOSVersionInfoSize = sizeof(osInfo);
	GetVersionEx(&osInfo);
	if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
		IsWin9x = false;
	else if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
		IsWin9x = true;

//	SendMessage(FindWindow("TApplication", "LiteStep"), WM_SYSCOMMAND, (WPARAM)SC_CLOSE,0);

	//start installation process

	if (UnInstall)
	{
		if (!IsWin9x)
			PostMessage(mainWnd, LS_NEXTDLG,23,0);
		else
			PostMessage(mainWnd, LS_NEXTDLG,22,0);
	}
	else if (Config)
	{
		if (!IsWin9x)
			PostMessage(mainWnd, LS_NEXTDLG,23,0);
		else
			PostMessage(mainWnd, LS_NEXTDLG,22,0);
	}
	else
		PostMessage(mainWnd, LS_NEXTDLG,0,0);

	while (GetMessage(&msg, NULL, 0, 0)) 
	{/*Main message loop*/
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
		case LS_NEXTDLG:
			{
				switch (wParam)
				{/* 0-19 common boxes, 20-39 full install, 40+ custom install, 99 quits*/
					case 0://license agreement
						DialogBox(exeInst, (LPCTSTR)IDD_AGREE, mainWnd, (DLGPROC)AgreeDlgProc);
						break;
					case 1://choose your installtion type
						DialogBox(exeInst, (LPCTSTR)IDD_INSTALL_TYPE, mainWnd, (DLGPROC)InstTypeDlgProc);
						break;
					case 2:

					case 3://common help box
						DialogBox(exeInst, (LPCTSTR)IDD_HELP, mainWnd, (DLGPROC)HelpDlgProc);
						break;
					case 4:

					case 5://Progress installation metter
//skipping this for now... not really needed, as install is so fast.
						//DialogBox(exeInst, (LPCTSTR)IDD_PROGRESSBAR, mainWnd, (DLGPROC)ProgressDlgProc);
						//break;
					case 6:

					case 7:

					case 8:

					case 9:

					case 10:
						DialogBox(exeInst, (LPCTSTR)IDD_ALLDONE, mainWnd, (DLGPROC)AllDoneDlgProc);
						break;
					case 20://Confirm installation setup and install <-First Full install only dialog
						DialogBox(exeInst, (LPCTSTR)IDD_INSTALL_SETTINGS, mainWnd, (DLGPROC)SettingsDlgProc);
						break;
					case 21://Installation complete, prompt for setup system.
						DialogBox(exeInst, (LPCTSTR)IDD_INSTALL_COMPLETE, mainWnd, (DLGPROC)InstCompleteDlgProc);
						break;
					case 22://Windows 9x system config dialog
						DialogBox(exeInst, (LPCTSTR)IDD_SYSTEM_SETTINGS, mainWnd, (DLGPROC)SysSettingsDlgProc);
						break;
					case 23://Windows NT system is user an Administrator?
						DialogBox(exeInst, (LPCTSTR)IDD_NT_ADMINORNOT, mainWnd, (DLGPROC)AdminOrNotDlgProc);
						break;
					case 24:
						DialogBox(exeInst, (LPCTSTR)IDD_SYSTEM_SETTINGS_NT_1, mainWnd, (DLGPROC)SysSettingsNT1DlgProc);
						break;
					case 25:
						DialogBox(exeInst, (LPCTSTR)IDD_SYSTEM_SETTINGS_NT_2, mainWnd, (DLGPROC)SysSettingsNT2DlgProc);
						break;
					case 26:

					case 40:
						DialogBox(exeInst, (LPCTSTR)IDD_UPGRADE_SETTINGS, mainWnd, (DLGPROC)UpgradeSettingsDlgProc);
						break;
					case 41:

					case 42:

					case 43:

					case 99:
						PostQuitMessage(0);
						break;
				}
				break;
			}
		case WM_DESTROY:
			{
				PostQuitMessage(0);
				return 0;
			}
		case WM_ERASEBKGND:
			{
				PaintDesktop((HDC)wParam);
				return 1;
			}
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
   }
   return 0;
}

LRESULT CALLBACK AgreeDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
				SetDlgItemText(hDlg, IDC_EDIT_AGREE, szLicenseAgreeText);
				return TRUE;
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDYES)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,1,0);
				}
				else if(LOWORD(wParam) == IDNO)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK InstTypeDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDFULL)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,20,0);
				}
				else if(LOWORD(wParam) == IDUPGRADE)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,40,0);
				}
				else if(LOWORD(wParam) == IDHELP)
					PostMessage(mainWnd, LS_NEXTDLG,3,0);
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK HelpDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				SetDlgItemText(hDlg, IDC_EDIT_HELP, szInstallTypeText);
				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDOK)
					EndDialog(hDlg, LOWORD(wParam));
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK SettingsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				SetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath);
				SetDlgItemText(hDlg, IDC_EDIT_WINDIR, windowsDir);
				SetDlgItemText(hDlg, IDC_EDIT_STARTDIR, startMenuDir);
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_WINVER), CB_ADDSTRING, 0, (LPARAM)(LPCTSTR)win9xVersion);
				SendMessage(GetDlgItem(hDlg, IDC_COMBO_WINVER), CB_ADDSTRING, 0, (LPARAM)(LPCTSTR)winNTVersion);
				if (!IsWin9x)
					SendMessage(GetDlgItem(hDlg, IDC_COMBO_WINVER), CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCTSTR)winNTVersion);
				else
					SendMessage(GetDlgItem(hDlg, IDC_COMBO_WINVER), CB_SELECTSTRING, (WPARAM)-1, (LPARAM)(LPCTSTR)win9xVersion);
				return TRUE;
			}
		case WM_COMMAND:
			{
				switch (wParam)
				{
					case IDC_CHANGE_LSDIR:
						GetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath, sizeof(installBasePath));
						BrowseForFolder(installBasePath, "LiteStep Installation Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath);
						break;
					case IDC_CHANGE_WINDIR:
						GetDlgItemText(hDlg, IDC_EDIT_WINDIR, windowsDir, sizeof(windowsDir));
						BrowseForFolder(windowsDir, "Windows Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_WINDIR, windowsDir);
						break;
					case IDC_CHANGE_STARTDIR:
						GetDlgItemText(hDlg, IDC_EDIT_STARTDIR, startMenuDir, sizeof(startMenuDir));
						BrowseForFolder(startMenuDir, "Start Menu Programs Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_STARTDIR, startMenuDir);
						break;
					case IDINSTALL:
						{
							GetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath, sizeof(installBasePath));
								if (installBasePath[strlen(installBasePath)-1] != '\\')
									strcat(installBasePath, "\\");
								CreateDirectory(installBasePath, NULL); //just in case user manually typed in a path, and it doesn't exist.

							GetDlgItemText(hDlg, IDC_EDIT_WINDIR, windowsDir, sizeof(windowsDir));
								if (windowsDir[strlen(windowsDir)-1] != '\\')
									strcat(windowsDir, "\\");

							GetDlgItemText(hDlg, IDC_EDIT_STARTDIR, startMenuDir, sizeof(startMenuDir));
								if (startMenuDir[strlen(startMenuDir)-1] != '\\')
									strcat(startMenuDir, "\\");

							char temp[256];
							GetDlgItemText(hDlg, IDC_COMBO_WINVER, temp, sizeof(temp));
								if (strcmp(temp, winNTVersion) == 0)
									IsWin9x = false;
								else
									IsWin9x = true;

							EndDialog(hDlg, LOWORD(wParam));
//Temporarily must manually create folders for this installation :(
//The stupid cab SDK, doesn't address what to do about creating subfolders.
							char tmp[MAX_PATH];
							strcpy(tmp, installBasePath);
							strcat(tmp, "images\\");
							CreateDirectory(tmp, NULL);
							strcpy(tmp, installBasePath);
							strcat(tmp, "images\\template\\");
							CreateDirectory(tmp, NULL);
							strcpy(tmp, installBasePath);
							strcat(tmp, "docs\\");
							CreateDirectory(tmp, NULL);
							strcpy(tmp, installBasePath);
							strcat(tmp, "modules\\");
							CreateDirectory(tmp, NULL);
							strcpy(installWharfModPath, tmp);
							// add in a few blank directories to give users an idea on how to organize things..
							strcpy(tmp, installBasePath);
							strcat(tmp, "themes\\");
							CreateDirectory(tmp, NULL);
							strcpy(tmp, installBasePath);
							strcat(tmp, "sounds\\");
							CreateDirectory(tmp, NULL);
							strcpy(tmp, installBasePath);
							strcat(tmp, "shortcuts\\");
							CreateDirectory(tmp, NULL);
//Now do the actually install of files and setup of the step.rc
							for (int i = 0; i < NUMFILES; i++)
							{
								switch (i)
								{
									case 2:
											strcpy(installPath, installWharfModPath);
											break;
									default:
											strcpy(installPath, installBasePath);
											break;
								}
								strcpy(tmp, currentDir);
								strcat(tmp, installFile[i]);
								if (GetFileAttributes(tmp) == 0xFFFFFFFF)
								{
									MessageBox(mainWnd, "Missing installation files!", "Error!", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
									PostQuitMessage(0);
									break;
								}
								test_fdi(tmp);
							}
							WriteStepRC();
							PostMessage(mainWnd, LS_NEXTDLG,21,0);
							break;
						}
					case IDEXIT:
						{
							EndDialog(hDlg, LOWORD(wParam));
							PostMessage(mainWnd, LS_NEXTDLG,99,0);
							break;
						}
				}
				return 0;
			}
	}
  return FALSE;
}
/*
LRESULT CALLBACK ProgressDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				PostMessage(hDlg,9999,0,0);
				return FALSE;
			}
		case 9999:
			{
				test_fdi(installFile);
				EndDialog(hDlg, LOWORD(wParam));
				PostMessage(mainWnd, LS_NEXTDLG,21,0);
				break;
			}
	}
  return FALSE;
}*/

LRESULT CALLBACK InstCompleteDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
				SetDlgItemText(hDlg, IDC_EDIT_CONFIGINFO, szAboutConfigText);
				return TRUE;
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDNEXT)
				{
					EndDialog(hDlg, LOWORD(wParam));
					if (!IsWin9x)
						PostMessage(mainWnd, LS_NEXTDLG,23,0);//NT
					else
						PostMessage(mainWnd, LS_NEXTDLG,22,0);//9x
				}
				else if(LOWORD(wParam) == IDEXIT)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK SysSettingsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				strcpy(sysIniFile, windowsDir);
				strcat(sysIniFile, "system.ini");
				SetDlgItemText(hDlg, IDC_STATIC_INILOCATION, sysIniFile);
				SetDlgItemText(hDlg, IDC_STATIC_HEADER, "[boot]");
				SetDlgItemText(hDlg, IDC_STATIC_KEYNAME, "shell=");
				GetPrivateProfileString("boot", "shell", "", oldIniSetting, sizeof(oldIniSetting), sysIniFile);
				SetDlgItemText(hDlg, IDC_EDIT_INI_OLDSETTING, oldIniSetting);
				if (UnInstall)
				{
					GetPrivateProfileString("boot", ";oldshell", "explorer.exe", newIniSetting, sizeof(newIniSetting), sysIniFile);
					SetDlgItemText(hDlg, IDC_EDIT_INI_NEWSETTING, newIniSetting);
				}
				else if (Config)
				{
					strcpy(newIniSetting, szConfigArg);
					SetDlgItemText(hDlg, IDC_EDIT_INI_NEWSETTING, newIniSetting);
				}
				else
				{
					strcpy(newIniSetting, installBasePath);
					strcat(newIniSetting, "litestep.exe");
					SetDlgItemText(hDlg, IDC_EDIT_INI_NEWSETTING, newIniSetting);
				}
				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDOK)
				{
					EndDialog(hDlg, LOWORD(wParam));
					GetDlgItemText(hDlg, IDC_EDIT_INI_NEWSETTING, newIniSetting, sizeof(newIniSetting));
					WritePrivateProfileString("boot", ";oldshell", oldIniSetting, sysIniFile);
					WritePrivateProfileString("boot", "shell", newIniSetting, sysIniFile);
					PostMessage(mainWnd, LS_NEXTDLG,10,0);
				}
				else if(LOWORD(wParam) == IDCANCEL)
				{
					EndDialog(hDlg, LOWORD(wParam));
					if (UnInstall)
						MessageBox(mainWnd, "You have chosen not to remove LiteStep as your Shell!\r\nYou have made an excellent decision.", "Important!", MB_OK|MB_ICONINFORMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
					else
						MessageBox(mainWnd, "You have chosen not to load LiteStep as your Shell on system boot up,\r\nplease consult the documentation for any needed information.", "Important!", MB_OK|MB_ICONINFORMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK UpgradeSettingsDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				SetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath);
				SetDlgItemText(hDlg, IDC_EDIT_LMDIR, installLoadModPath);
				SetDlgItemText(hDlg, IDC_EDIT_WMDIR, installWharfModPath);
				return TRUE;
			}
		case WM_COMMAND:
			{
				switch (wParam)
				{
					case IDC_CHANGE_LSDIR:
						GetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath, sizeof(installBasePath));
						BrowseForFolder(installBasePath, "LiteStep Installation Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath);
						break;
					case IDC_CHANGE_LMDIR:
						GetDlgItemText(hDlg, IDC_EDIT_LMDIR, installLoadModPath, sizeof(installLoadModPath));
						BrowseForFolder(installLoadModPath, "Load Modules Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_LMDIR, installLoadModPath);
						break;
					case IDC_CHANGE_WMDIR:
						GetDlgItemText(hDlg, IDC_EDIT_WMDIR, installWharfModPath, sizeof(installWharfModPath));
						BrowseForFolder(installWharfModPath, "Wharf Modules Directory", hDlg);
						SetDlgItemText(hDlg, IDC_EDIT_WMDIR, installWharfModPath);
						break;
					case IDINSTALL:
						{
							GetDlgItemText(hDlg, IDC_EDIT_LSDIR, installBasePath, sizeof(installBasePath));
								if (installBasePath[strlen(installBasePath)-1] != '\\')
									strcat(installBasePath, "\\");
								CreateDirectory(installBasePath, NULL); //just in case user manually typed in a path, and it doesn't exist.

							GetDlgItemText(hDlg, IDC_EDIT_LMDIR, installLoadModPath, sizeof(installLoadModPath));
								if (installLoadModPath[strlen(installLoadModPath)-1] != '\\')
									strcat(installLoadModPath, "\\");
								CreateDirectory(installLoadModPath, NULL); //just in case user manually typed in a path, and it doesn't exist.

							GetDlgItemText(hDlg, IDC_EDIT_WMDIR, installWharfModPath, sizeof(installWharfModPath));
								if (installWharfModPath[strlen(installWharfModPath)-1] != '\\')
									strcat(installWharfModPath, "\\");
								CreateDirectory(installWharfModPath, NULL); //just in case user manually typed in a path, and it doesn't exist.
							if (FindWindow("TApplication", "LiteStep") != NULL)
							{
								//SendMessage(FindWindow("TApplication", "LiteStep"), 
// Need to implement shutting down LiteStep automatically
								MessageBox(hDlg, "Please shutdown LiteStep now!\r\n\r\nIf you don't, you may get errors and/ or fail to\r\ninstall the updated files.\r\n\r\nPress the Ok button when you're ready.\r\n\r\nYou can shutdown your current instance of\r\nLiteStep by issuing the !Quit command.", "Shutdown LiteStep!", MB_OK|MB_ICONEXCLAMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
							}
							EndDialog(hDlg, LOWORD(wParam));
//Now do the actuall install of files
							char tmp[MAX_PATH];
							for (int i = 0; i < NUMFILES-1; i++) //don't do the last file with the theme in it!
							{
								switch (i)
								{
									case 0:
											strcpy(installPath, installBasePath);
											break;
									case 1:
											strcpy(installPath, installLoadModPath);
											break;
									case 2:
											strcpy(installPath, installWharfModPath);
											break;
								}
								strcpy(tmp, currentDir);
								strcat(tmp, installFile[i]);
								if (GetFileAttributes(tmp) == 0xFFFFFFFF)
								{
									MessageBox(mainWnd, "Missing installation files!", "Error!", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
									PostQuitMessage(0);
									break;
								}
								test_fdi(tmp);
							}
							if (FindWindow("TApplication", "LiteStep") != NULL)
								MessageBox(hDlg, "The upgrade was successful, however an instance of LiteStep is already running!\r\n\r\nThe upgraded version of LiteStep cannot be started automatically.", "Attention!", MB_OK|MB_ICONEXCLAMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
							else if (MessageBox(mainWnd, "Your current LiteStep installation has been upgraded.\r\n\r\nWould you like to restart LiteStep now?", "Restart LiteStep", MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON1|MB_SYSTEMMODAL) == IDYES)
							{
								char lsexe[MAX_PATH];
								strcpy(lsexe, installBasePath);
								strcat(lsexe, "litestep.exe");
								//ShellExecute(mainWnd, "open", lsexe, "-nostartup", installBasePath, SW_SHOWNORMAL);
								
								SHELLEXECUTEINFO si;
								memset(&si, 0, sizeof(si));
								si.cbSize = sizeof(SHELLEXECUTEINFO);
								si.lpDirectory = installBasePath;
								si.lpVerb = NULL;
								si.nShow = 1;
								si.fMask = SEE_MASK_DOENVSUBST;
								si.lpParameters = "-nostartup";
								si.lpFile = lsexe;
								si.hIcon = mainWnd;
								ShellExecuteEx(&si);
							}
							
							PostMessage(mainWnd, LS_NEXTDLG,99,0);
							break;
						}
					case IDEXIT:
						{
							EndDialog(hDlg, LOWORD(wParam));
							PostMessage(mainWnd, LS_NEXTDLG,99,0);
							break;
						}
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK AdminOrNotDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				if (UnInstall)
					SetDlgItemText(hDlg, IDC_EDIT_NTINFO, "You are about to UnInstall LiteStep as your Win32 Shell!\r\n\r\nIf you installed LiteStep with Administrative access choose \"Admin\" Otherwise if you installed LiteStep without administrative access on your account choose\"Not Admin\".");
				else
					SetDlgItemText(hDlg, IDC_EDIT_NTINFO, szAdminOrNotText);

				if (UnInstall)
				{
					strcpy(newRegSettingHKLM, "explorer.exe");
					strcpy(newRegSettingHKCU, "explorer.exe");
				}
				else if (Config)
				{
					strcpy(newRegSettingHKLM, szConfigArg);
					strcpy(newRegSettingHKCU, szConfigArg);
				}
				else
				{
					strcpy(newRegSettingHKLM, installBasePath);
					strcat(newRegSettingHKLM, "litestep.exe");
					strcpy(newRegSettingHKCU, installBasePath);
					strcat(newRegSettingHKCU, "litestep.exe");
				}
				strcpy(newRegSettingHKLM2, "YES");
				strcpy(newRegSettingHKCU2, "YES");
				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDADMIN)
				{
					IsAdmin = true;
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,24,0);
				}
				else if(LOWORD(wParam) == IDNOTADMIN)
				{
					IsAdmin = false;
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,25,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK AllDoneDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				if (UnInstall)
					SetDlgItemText(hDlg, IDC_EDIT_ALLDONE, "You have succesfully removed LiteStep as your Win32 Shell. After rebooting, you may safely delete your LiteStep directory.");
				else
					SetDlgItemText(hDlg, IDC_EDIT_ALLDONE, szAllDoneText);
				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDOK)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
					ExitWindowsEx(EWX_REBOOT,0); //would rather have a soft reboot, but this works.
				}
				else if(LOWORD(wParam) == IDCANCEL)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK SysSettingsNT1DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				SetDlgItemText(hDlg, IDC_STATIC_HKLM_ITEM, "Shell");
				RegQueryStringValue( HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon"), TEXT("Shell"), oldTmpRegSetting, MAX_PATH, TEXT("") );
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKLMOLD, oldTmpRegSetting);
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKLMNEW, newRegSettingHKLM);

				SetDlgItemText(hDlg, IDC_STATIC_HKLM_ITEM2, "BrowseNewProcess");
				RegQueryStringValue( HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\BrowseNewProcess"), TEXT("BrowseNewProcess"), oldTmpRegSetting, MAX_PATH, TEXT("") );
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKLMOLD2, oldTmpRegSetting);
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKLMNEW2, newRegSettingHKLM2);

				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDOK)
				{
					EndDialog(hDlg, LOWORD(wParam));
					GetDlgItemText(hDlg, IDC_EDIT_REG_HKLMNEW, newRegSettingHKLM, sizeof(newRegSettingHKLM));
					GetDlgItemText(hDlg, IDC_EDIT_REG_HKLMNEW2, newRegSettingHKLM2, sizeof(newRegSettingHKLM2));
					PostMessage(mainWnd, LS_NEXTDLG,25,0);
				}
				else if(LOWORD(wParam) == IDBACK)
				{
					EndDialog(hDlg, LOWORD(wParam));
					PostMessage(mainWnd, LS_NEXTDLG,23,0);
				}
				return 0;
			}
	}
  return FALSE;
}

LRESULT CALLBACK SysSettingsNT2DlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	lParam = lParam;
	switch (message)
	{
		case WM_INITDIALOG:
			{
				SetDlgItemText(hDlg, IDC_STATIC_HKCU_ITEM, "Shell");
				RegQueryStringValue( HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon"), TEXT("Shell"), oldTmpRegSetting, MAX_PATH, TEXT("") );
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKCUOLD, oldTmpRegSetting);
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW, newRegSettingHKCU);

				SetDlgItemText(hDlg, IDC_STATIC_HKLM_ITEM2, "BrowseNewProcess");
				RegQueryStringValue( HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\BrowseNewProcess"), TEXT("BrowseNewProcess"), oldTmpRegSetting, MAX_PATH, TEXT("") );
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKCUOLD2, oldTmpRegSetting);
				SetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW2, newRegSettingHKCU2);

				return TRUE;
			}
		case WM_COMMAND:
			{
				if (LOWORD(wParam) == IDYES)
				{
					EndDialog(hDlg, LOWORD(wParam));
					GetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW, newRegSettingHKCU, sizeof(newRegSettingHKCU));
					GetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW2, newRegSettingHKCU2, sizeof(newRegSettingHKCU2));
					RegSetStringValue( HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon"), TEXT("Shell"), newRegSettingHKLM );
					RegSetStringValue( HKEY_LOCAL_MACHINE, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\BrowseNewProcess"), TEXT("BrowseNewProcess"), newRegSettingHKLM2 );
					RegSetStringValue( HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon"), TEXT("Shell"), newRegSettingHKCU );
					RegSetStringValue( HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\BrowseNewProcess"), TEXT("BrowseNewProcess"), newRegSettingHKCU2 );
					PostMessage(mainWnd, LS_NEXTDLG,10,0);
				}
				if (LOWORD(wParam) == IDBACK)
				{
					EndDialog(hDlg, LOWORD(wParam));
					if (IsAdmin)
					{
						GetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW, newRegSettingHKCU, sizeof(newRegSettingHKCU));
						GetDlgItemText(hDlg, IDC_EDIT_REG_HKCUNEW2, newRegSettingHKCU2, sizeof(newRegSettingHKCU2));
						PostMessage(mainWnd, LS_NEXTDLG,24,0);
					}
					else
						PostMessage(mainWnd, LS_NEXTDLG,23,0);
				}
				else if(LOWORD(wParam) == IDCANCEL)
				{
					EndDialog(hDlg, LOWORD(wParam));
					if (UnInstall)
						MessageBox(mainWnd, "You have chosen not to remove LiteStep as your Shell!\r\nYou have made an excellent decision.", "Important!", MB_OK|MB_ICONINFORMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
					else
						MessageBox(mainWnd, "You have chosen not to load LiteStep as your Shell on system boot up,\r\nplease consult the documentation for any needed information.", "Important!", MB_OK|MB_ICONINFORMATION|MB_DEFBUTTON1|MB_SYSTEMMODAL);
					PostMessage(mainWnd, LS_NEXTDLG,99,0);
				}
				return 0;
			}
	}
  return FALSE;
}

void BrowseForFolder(char *tmp, char *szBrowseTitle, HWND callerWnd)
{
	LPMALLOC pMalloc;
	SHGetMalloc(&pMalloc);

	// buffer - holds the file system pathname
	char buffer[MAX_PATH];

	LPITEMIDLIST pidlRoot;

	// This struct holds the various options for the dialog
	BROWSEINFO bi;
	bi.hwndOwner = callerWnd;
	bi.pidlRoot = NULL;
	bi.pszDisplayName = buffer;
	bi.lpszTitle = szBrowseTitle;
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	bi.lpfn = NULL;

	// Now cause the dialog to appear.
	if((pidlRoot = SHBrowseForFolder(&bi)) == NULL)
	{
		// User hit cancel - do whatever
		pMalloc->Free(pidlRoot);
		return;
	}

	//
	// Again, almost undocumented.  How to get a ASCII pathname
	// from the LPITEMIDLIST struct.  I guess you just have to
	// "know" this stuff *sigh*.
	//
	if(SHGetPathFromIDList(pidlRoot, buffer))
	{
		// Do something with the converted string.
		strcpy(tmp, buffer);
		if (tmp[strlen(tmp)-1] != '\\')
			strcat(tmp, "\\");
	}

	// Free the returned item identifier list using the
	// shell's task allocator!
	pMalloc->Free(pidlRoot);
	return;
}

void WriteStepRC(void)
{
	FILE *f, *sr;
	char line[256];
	char tmpsrc[MAX_PATH];
	if (!IsWin9x)
	{
		strcpy(tmpsrc, currentDir);
		strcat(tmpsrc, "stepnt.tmp");
	}
	else
	{
		strcpy(tmpsrc, currentDir);
		strcat(tmpsrc, "step9x.tmp");
	}
	char tmpdest[MAX_PATH];
	strcpy(tmpdest, installBasePath);
	strcat(tmpdest, "step.rc");

	if (GetFileAttributes(tmpsrc) == 0xFFFFFFFF)
	{
		MessageBox(mainWnd, "Missing configuration files!", "Error!", MB_OK|MB_ICONERROR|MB_DEFBUTTON1|MB_SYSTEMMODAL);
		PostQuitMessage(0);
		return;
	}

	{
		strcat(szInsertStepRCTextB, "\"");
		strcat(szInsertStepRCTextB, windowsDir);
		strcat(szInsertStepRCTextB, "\"\n");
	}
	{
		strcat(szInsertStepRCTextD, "\"");
		strcat(szInsertStepRCTextD, startMenuDir);
		strcat(szInsertStepRCTextD, "\"\n");
	}
	{
		strcat(szInsertStepRCTextF, "\"");
		strcat(szInsertStepRCTextF, installBasePath);
		strcat(szInsertStepRCTextF, "\"\n");
	}

	f = fopen(tmpdest, "w");
	fprintf(f, "%s", szInsertStepRCTextA);
	fprintf(f, "%s", szInsertStepRCTextB);
	fprintf(f, "%s", szInsertStepRCTextC);
	fprintf(f, "%s", szInsertStepRCTextD);
	fprintf(f, "%s", szInsertStepRCTextE);
	fprintf(f, "%s", szInsertStepRCTextF);
	fclose(f);

	sr = fopen(tmpsrc, "r");
	f = fopen(tmpdest, "a");
	while (sr && !feof(sr))
	{
		fgets(line, 256, sr);
		fprintf(f,"%s", line);
	}
	fclose(f);
	fclose(sr);
	return;
}




















