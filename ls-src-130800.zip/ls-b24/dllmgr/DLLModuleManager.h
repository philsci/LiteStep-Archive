// DLLModuleManager.h: interface for the DLLModuleManager class.
//
//////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4786)
#if !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
#define AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "../core/ifcs.h"
#include <map>
#include <string>

#define BAD_MODULE 0
#define BAD_INIT 1
#define BAD_QUIT 2

#define MODULE_THREADED 1
#define MODULE_NOTPUMPED 2

using namespace std;

typedef int (*ModuleInitExFunc) (HWND, HINSTANCE, LPCSTR);
typedef int (*ModuleQuitFunc) (HINSTANCE);

class DLLModule {
	HINSTANCE hInstance;
	HANDLE hThread;
	wstring location;

	wstring appPath;
	HWND mainWindow;

	ModuleInitExFunc pInitEx;
	ModuleQuitFunc pQuit;

	BOOL threaded;
	BOOL pumped;

public:
	DLLModule(BSTR loc, BOOL = false, BOOL = false);
	virtual ~DLLModule();
	void Init(HWND hMainWindow, wstring appPath);
	void Quit();
	static ULONG __stdcall ThreadProc(void* dllModPtr);
	HINSTANCE GetInstance();
	HANDLE GetThread();
	wstring GetLocation();
	ModuleQuitFunc GetQuit();
	ModuleInitExFunc GetInitEx();
	static HRESULT WINAPI ThreadWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	HWND hThreadWnd;

private:
	ULONG CallInit();
};

class DLLModuleManager : public IModuleManager  
{
public:
	DLLModuleManager(HWND, LPCTSTR);
	virtual ~DLLModuleManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	////////////////////////////////////////////////////////////////////////////
	// From IModuleManager
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModules( 
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModule( 
        /* [in] */ BSTR location,
        /* [in] */ int flags);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModules( void);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModule( 
        /* [in] */ BSTR location);
        
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleList( 
        /* [in] */ SAFEARRAY __RPC_FAR * strlist,
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleCount( 
        /* [retval][out] */ int __RPC_FAR *count);
private:
	typedef std::map<std::wstring, DLLModule*> wstring2module;

	wstring2module dllModuleMap;
	HWND hMainWindow;
	wstring appPath;
	long refCount;
};

#endif // !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
