//   _     _ _           _
//  | |   (_) |_ ___ ___| |_ ___ _ __
//  | |   | | __/ _ Y __| __/ _ \ '_ \
//  | |___| | ||  __|__ \ ||  __/ |_) |
//  |_____|_|\__\___|___/\__\___| .__/
//                              |_|
//
//       module | taskbar
//      version | 1.0
//  description | display and manipulate running tasks
//       author | maduin <maduin@dasoft.org>
//      created | 21 feb 2000
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <commctrl.h>
#include "../lsapi/lsapi.h"
#include "taskbar.h"

// undocumented SwitchToThisWindow API (maybe this should be in LSAPI?)
void (WINAPI *SwitchToThisWindow)( HWND, int );

Taskbar *taskbar;

int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	InitCommonControls();

	SwitchToThisWindow = (void (WINAPI *)( HWND, int )) GetProcAddress(
		GetModuleHandle( TEXT("USER32.DLL") ),
		TEXT("SwitchToThisWindow") );

	taskbar = new Taskbar;
	taskbar->OnLoad( hInstance );

	return 0;
}

void quitModule( HINSTANCE hInstance )
{
	taskbar->OnUnload();
	delete taskbar;
}

extern "C" int WINAPI DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )
		DisableThreadLibraryCalls( hInstance );

	return 1;
}

BOOL IsAppWindow( HWND hWnd )
{
	if( !IsWindowVisible( hWnd ) )
		return FALSE;

	if( GetWindow( hWnd, GW_OWNER ) )
		return FALSE;

	LONG styleEx = GetWindowLong( hWnd, GWL_EXSTYLE );

	if( styleEx & WS_EX_APPWINDOW )
		return TRUE;

	if( styleEx & WS_EX_TOOLWINDOW )
		return FALSE;

	if( GetWindowLong( hWnd, GWL_USERDATA ) == 0x49474541 )
		return FALSE;

	return TRUE;
}

// from jugg's tasks.dll, based on code from Fahim and re5ource
HICON GetIconFromWindow( HWND hWnd, BOOL bBigIcon )
{
	HICON hIcon = NULL;

	if( bBigIcon )
	{
		SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
		if( !hIcon ) SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
	}
	else
	{
		SendMessageTimeout( hWnd, WM_GETICON, ICON_SMALL, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICONSM );
		if( !hIcon ) SendMessageTimeout( hWnd, WM_QUERYDRAGICON, 0, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) SendMessageTimeout( hWnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG, 1000, (LPDWORD) &hIcon );
		if( !hIcon ) hIcon = (HICON) GetClassLong( hWnd, GCL_HICON );
	}

	return hIcon;
}

BOOL WINAPIV PrintLog( LPCTSTR pszFormat, ... )
{
	TCHAR szText[1024];
	DWORD dwCount;
	va_list argList;
	HANDLE hFile;
	
	va_start( argList, pszFormat );
	wvsprintf( szText, pszFormat, argList );
	lstrcat( szText, TEXT("\r\n") );
	
	hFile = CreateFile( TEXT("C:\\LITESTEP\\TASKBAR.LOG"),
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL );
	
	SetFilePointer( hFile, 0, NULL, FILE_END );
	WriteFile( hFile, szText, lstrlen( szText ), &dwCount, 0 );
	
	CloseHandle( hFile );
	return TRUE;
}
