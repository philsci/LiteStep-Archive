/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
06-04-00 Bobby G. Vinyard (Message)
  - hParent not being set, changed to GetLitetepWnd when sending LM_REGISTERMESSAGE
     and LM_UNREGISTERMESSAGE, will now show in !about
05-20-00 Bobby G. Vinyard (Message)
  - Fixed a bug where the last character in the theme file was being 
     overwritten with a null-terminating character (\0) if the file did not
     end in a newline (\n)
  - General house cleaning in drawing routines and data validation
05-19-00 Bobby G. Vinyard (Message)
  - Rewrote lstime to d2 format using cpp and lswinbase
  - General cleaning (its finally working now)
****************************************************************************/
#include "resource.h"
#include "lstime.h"

const char szAppName[] = "LSTimeClass"; // Our window class, etc

const char rcsRevision[] = "$Revision: 1.10.2.2 $"; // Our Version
const char rcsId[] = "$Id: lstime.cpp,v 1.10.2.2 2000/06/04 19:53:40 message Exp $"; // The Full RCS ID.

Lstime *lsTime; // The module

//=========================================================
// Initialization and cleanup
//=========================================================

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
  int code;

  Window::init(dllInst);
  lsTime = new Lstime(ParentWnd, code, wd);

  return code;
}


void quitWharfModule(HINSTANCE dllInst)
{
  delete lsTime;
}


//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Lstime::Lstime(HWND parentWnd, int& code, wharfDataType* wd):
Window(szAppName)
{

#ifdef _NTP_SUPPORT
  int ntpcode;

  ntpclient = new NtpClient(NULL, ntpcode);

	popup = CreatePopupMenu();
	AppendMenu(popup, MF_ENABLED | MF_STRING, 100, "&Open Time && Date panel");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 101, "&NTP Setup");
	AppendMenu(popup, MF_ENABLED | MF_STRING, 102, "&Synchronize!");
#endif

	bDigiClock = FALSE;
	bDigiDay = FALSE;
	bDigiMonth = FALSE;
	bDigiYear = FALSE;
	bDigi2dYear = FALSE;
	bAnaDay = FALSE;
	bAnaMonth = FALSE;
	bAnaClock = FALSE;
	bBackground = FALSE;
	bHourHandShade = FALSE;
	bMinHandColor = FALSE;
	bMinHandShade = FALSE;
  bSecHandColor = FALSE;

  memcpy(&wharfData, wd, sizeof(wharfDataType));

  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_CHILD,
                    wharfData.borderSize, wharfData.borderSize,
                    64-wharfData.borderSize*2, 64-wharfData.borderSize*2,
                    parentWnd))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

 SetClassLong(hWnd, GCL_STYLE, CS_DBLCLKS);

  //ShowWindow(hWnd, SW_SHOWNORMAL);

  code = 0;
}


Lstime::~Lstime()
{
#ifdef _NTP_SUPPORT
  delete ntpclient;
  DestroyMenu(popup);
#endif
  destroyWindow();
}


//=========================================================
// Bang commands
//=========================================================

//=========================================================
// Module code
//=========================================================
void Lstime::themeParse(FILE* themeFile)
{
  char tmpParse[MAX_LINE_LENGTH+1];
  char* opt;
  char* val;

  while (!feof(themeFile))
  {
    if (fgets(tmpParse, sizeof(tmpParse), themeFile))
    {
      if(tmpParse[lstrlen(tmpParse)-1] == '\n')
        tmpParse[lstrlen(tmpParse)-1] = '\0';
      if (lstrlen(tmpParse))
      {
        opt = strtok(tmpParse, " ");
        val = strtok(NULL, "");

        if (!strcmpi(opt, "BitmapFile"))
        {
          themePic.usePic = LoadLSImage(val, NULL);
          strcpy(ThemePicName, val);
          themePic.picDC = CreateCompatibleDC(NULL);//lsTimeGlob.bkGrnd.picDC);
          oldBMP3 = (HBITMAP)SelectObject(themePic.picDC, themePic.usePic);
        }
        else if (!strcmpi(opt, "DateFont"))
          sscanf(val, "%d %d %d %d",
          &sDateFontPos.sX,
          &sDateFontPos.sY,
          &sDateFontPos.w,
          &sDateFontPos.h);
        else if (!strcmpi(opt, "DigiClockFont"))
          sscanf(val, "%d %d %d %d",
          &sDigiFontPos.sX,
          &sDigiFontPos.sY,
          &sDigiFontPos.w,
          &sDigiFontPos.h);
        else if (!strcmpi(opt, "AnaDayFont"))
          sscanf(val, "%d %d %d %d",
          &sAnaDayFontPos.sX,
          &sAnaDayFontPos.sY,
          &sAnaDayFontPos.w,
          &sAnaDayFontPos.h);
        else if (!strcmpi(opt, "AnaMonthFont"))
          sscanf(val, "%d %d %d %d",
          &sAnaMonthFontPos.sX,
          &sAnaMonthFontPos.sY,
          &sAnaMonthFontPos.w,
          &sAnaMonthFontPos.h);
        else if (!strcmpi(opt, "DigiClock"))
        {
          sscanf(val, "%d %d",
            &sDigiClockPos.dX,
            &sDigiClockPos.dY);
          bDigiClock = TRUE;
        }
        else if (!strcmpi(opt, "DigiDay"))
        {
          sscanf(val, "%d %d",
            &sDigiDayPos.dX,
            &sDigiDayPos.dY);
          bDigiDay = TRUE;
        }
        else if (!strcmpi(opt, "DigiMonth"))
        {
          sscanf(val, "%d %d",
            &sDigiMonthPos.dX,
            &sDigiMonthPos.dY);
          bDigiMonth = TRUE;
        }
        else if (!strcmpi(opt, "AnaDay"))
        {
          sscanf(val, "%d %d",
            &sAnaDayPos.dX,
            &sAnaDayPos.dY);
          bAnaDay = TRUE;
        }
        else if (!strcmpi(opt, "AnaMonth"))
        {
          sscanf(val, "%d %d",
            &sAnaMonthPos.dX,
            &sAnaMonthPos.dY);
          bAnaMonth = TRUE;
        }
        else if (!strcmpi(opt, "DigiYear"))
        {
          sscanf(val, "%d %d",
            &sDigiYearPos.dX,
            &sDigiYearPos.dY);
          bDigiYear = TRUE;
        }
        else if (!strcmpi(opt, "Digi2dYear"))
        {
          sscanf(val, "%d %d",
            &sDigi2dYearPos.dX,
            &sDigi2dYearPos.dY);
          bDigi2dYear = TRUE;
        }
        else if (!strcmpi(opt, "AnaClock"))
        {
          sscanf(val, "%d %d %d %d",
            &sAnaClockPos.dX,
            &sAnaClockPos.dY,
            &sAnaClockPos.w,
            &sAnaClockPos.h);
          bAnaClock = TRUE;
        }
        else if (!strcmpi(opt, "Background"))
        {
          sscanf(val, "%d %d %d %d %d %d",
            &sBackground.sX,
            &sBackground.sY,
            &sBackground.dX,
            &sBackground.dY,
            &sBackground.w,
            &sBackground.h);
          bBackground = TRUE;
        }
        else if (!strcmpi(opt, "HourHandColor"))
        {
          sscanf(val, "%x", &cHourHandColor);
          bHourHandColor = TRUE;
        }
        else if (!strcmpi(opt, "HourHandShade"))
        {
          sscanf(val, "%x", &cHourHandShade);
          bHourHandShade = TRUE;
        }
        else if (!strcmpi(opt, "MinHandColor"))
        {
          sscanf(val, "%x", &cMinHandColor);
          bMinHandColor = TRUE;
        }
        else if (!strcmpi(opt, "MinHandShade"))
        {
          sscanf(val, "%x", &cMinHandShade);
          bMinHandShade = TRUE;
        }
        else if (!strcmpi(opt, "SecHandColor"))
        {
          sscanf(val, "%x", &cSecHandColor);
          bSecHandColor = TRUE;
        }
      }
    }
  }
  fclose(themeFile);

  // Validate the data
  if (bAnaClock) {
    if (!bHourHandColor)
    {
      MessageBox(hParent, "HourHandColor not defined!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (!bMinHandColor)
    {
      MessageBox(hParent, "MinHandColor not defined!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (!bSecHandColor)
    {
      MessageBox(hParent, "SecHandColor not defined!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (bAnaDay && !sAnaDayFontPos.w)
    {
      MessageBox(hParent, "AnaDayFont not defined, or Width is 0!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (bAnaMonth && !sAnaMonthFontPos.w)
    {
      MessageBox(hParent, "AnaMonthFont not defined, or Width is 0!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (!bHourHandShade)
    {
      cHourHandShade = cHourHandColor;
      bHourHandShade = TRUE;
    }
    if (!bMinHandShade)
    {
      cMinHandShade = cMinHandColor;
      bMinHandShade = TRUE;
    }    
  }
  else {
    if ((bDigiClock || bDigiDay || bDigiMonth || bDigiYear) && !themePic.usePic)
    {
      MessageBox(hParent, "Bitmap not present.", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
    if (bDigiClock && !sDigiFontPos.w)
    {
      MessageBox(hParent, "DigiClockFont not defined, or Width is 0!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    } 
    if ((bDigiDay || bDigiMonth || bDigiYear) && !sDateFontPos.w)
    {
      MessageBox(hParent, "DigiDateFont not defined, or Width is 0!", szAppName, MB_OK);
      quitWharfModule(hInstance);
    }
  }
}


HRGN Lstime::getLSRegion(int xoffset, int yoffset)
{
  HRGN t = NULL;
  HDC thdc = CreateCompatibleDC(themePic.picDC);
  HBITMAP nnn;
  HBITMAP Reference;
  HBITMAP oldBMP;
  RECT r;
  HBRUSH hb2;
  
  if (bBackground && themePic.usePic)
  {
    Reference = LoadLSImage(ThemePicName, NULL);
    oldBMP = (HBITMAP)SelectObject(thdc, Reference);
    nnn = CreateCompatibleBitmap(thdc, 64, 64);
    SelectObject(thdc, nnn);
    hb2= CreateSolidBrush(RGB(255,0,255));
    r.top=0;
    r.left=0;
    r.bottom = 64;
    r.right = 64;
    FillRect(thdc, &r, hb2);
    DeleteObject(hb2);
    TransparentBltLS(thdc,
      sBackground.dX,
      sBackground.dY,
      sBackground.w,
      sBackground.h,
      themePic.picDC,
      sBackground.sX,
      sBackground.sY,
      RGB(255,0,255));
    t = BitmapToRegion(nnn, RGB(255,0,255), 0x101010, xoffset, yoffset);
  }
  SelectObject(thdc, oldBMP);
  DeleteDC(thdc);
  DeleteObject(nnn);
  DeleteObject(Reference);
  return t;
}


void Lstime::makeBuffer(HWND hWnd)
{
  RECT r;
  HDC hdc = GetDC(hWnd);
  HBRUSH hb2;
  GetClientRect(hWnd,&r);
  hb2 = CreateSolidBrush(RGB(255,0,255));
  
  FillRect(bkGrnd.picDC, &r, hb2);
  BitBlt(bkGrnd.picDC, 0, 0, r.right, r.bottom, hdc, 0, 0, SRCCOPY);
  ReleaseDC(hWnd, hdc);
  DeleteObject(hb2);
  
  if (bBackground && !themePic.usePic)
  {
    MessageBox(hParent, "Bitmap not present.", szAppName, MB_OK);
    quitWharfModule(hInstance);
  }
  //SelectObject(bkGrnd.picDC, themePic.picDC);
  TransparentBltLS(bkGrnd.picDC,
    sBackground.dX,
    sBackground.dY,
    sBackground.w,
    sBackground.h,
    themePic.picDC,
    sBackground.sX,
    sBackground.sY,
    RGB(255,0,255));
}

void Lstime::drawDigiClock()
{
  time_t tVal;
  struct tm* stVal;
  char tmp[10];
  char tmp2[10];
  char rClockVal[10];
  char rDayVal[10];
  char rMonthVal[10];
  char rYearVal[10];
  int iTmp;
  int x;
  
  BitBlt(dblBuf, 0, 0, 64, 64, bkGrnd.picDC, 0, 0, SRCCOPY);
  
    time(&tVal);
    stVal = localtime(&tVal);
    if (wharfData.usClock)
      strftime(tmp, sizeof(tmp), "%I", stVal);
    else
      strftime(tmp, sizeof(tmp), "%H", stVal);
    iTmp = atoi(tmp);
    itoa(iTmp, rClockVal, 10);
    if (strlen(rClockVal) == 1)
    {
      strcpy(tmp, "0");
      strcat(tmp, rClockVal);
      strcpy(rClockVal, tmp);
    }
    strcat(rClockVal, ":");
    strftime(tmp, sizeof(tmp), "%M", stVal);
    iTmp = atoi(tmp);
    itoa(iTmp, tmp, 10);
    if (strlen(tmp) == 1)
    {
      strcpy(tmp2, "0");
      strcat(tmp2, tmp);
      strcpy(tmp, tmp2);
    }
    strcat(rClockVal, tmp);
    for (x=0;x<lstrlen(rClockVal);x++)
    {
      if (rClockVal[x] != ':')
      {
        TransparentBltLS(
          dblBuf,
          sDigiClockPos.dX + (x * sDigiFontPos.w),
          sDigiClockPos.dY,
          sDigiFontPos.w,
          sDigiFontPos.h,
          themePic.picDC,
          sDigiFontPos.sX + ((rClockVal[x] - '0') * sDigiFontPos.w),
          sDigiFontPos.sY,
          RGB(255,0,255));
      }
      else
      {
        if (globCounter)
        {
          TransparentBltLS(
            dblBuf,
            sDigiClockPos.dX + (x * sDigiFontPos.w),
            sDigiClockPos.dY,
            sDigiFontPos.w,
            sDigiFontPos.h,
            themePic.picDC,
            sDigiFontPos.sX + (10 * sDigiFontPos.w),
            sDigiFontPos.sY,
            RGB(255,0,255));
          globCounter = false;
        }
        else
        {
          TransparentBltLS(
            dblBuf,
            sDigiClockPos.dX + (x * sDigiFontPos.w),
            sDigiClockPos.dY,
            sDigiFontPos.w,
            sDigiFontPos.h,
            themePic.picDC,
            sDigiFontPos.sX + (11 * sDigiFontPos.w),
            sDigiFontPos.sY,
            RGB(255,0,255));
          globCounter= true;
        }
      }
    }

  if (bDigiDay || bDigiMonth ||
    bDigiYear || bDigi2dYear)
  {
    time(&tVal);
    stVal = localtime(&tVal);
    
    if (bDigiDay)
    {
      strftime(rDayVal, sizeof(rDayVal), "%d", stVal);
      for (x=0;x<lstrlen(rDayVal);x++)
      {
        
        if (x == 0 && rDayVal[x] == '0')
        {
          TransparentBltLS(
            dblBuf,
            sDigiDayPos.dX + (x * sDateFontPos.w),
            sDigiDayPos.dY,
            sDateFontPos.w,
            sDateFontPos.h,
            themePic.picDC,
            sDateFontPos.sX + (10 * sDateFontPos.w),
            sDateFontPos.sY,
            RGB(255,0,255));
        }
        else
        {
          TransparentBltLS(
            dblBuf,
            sDigiDayPos.dX + (x * sDateFontPos.w),
            sDigiDayPos.dY,
            sDateFontPos.w,
            sDateFontPos.h,
            themePic.picDC,
            sDateFontPos.sX + ((rDayVal[x] - '0') * sDateFontPos.w),
            sDateFontPos.sY,
            RGB(255,0,255));
        }
      }
    }
    if (bDigiMonth)
    {
      strftime(rMonthVal, sizeof(rMonthVal), "%m", stVal);
      for (x=0;x<lstrlen(rMonthVal);x++)
      {
        if (x == 0 && rMonthVal[0] == '0')
        {
          TransparentBltLS(
            dblBuf,
            sDigiMonthPos.dX + (x * sDateFontPos.w),
            sDigiMonthPos.dY,
            sDateFontPos.w,
            sDateFontPos.h,
            themePic.picDC,
            sDateFontPos.sX + (10 * sDateFontPos.w),
            sDateFontPos.sY,
            RGB(255,0,255));
        }
        else
        {
          TransparentBltLS(
            dblBuf,
            sDigiMonthPos.dX + (x * sDateFontPos.w),
            sDigiMonthPos.dY,
            sDateFontPos.w,
            sDateFontPos.h,
            themePic.picDC,
            sDateFontPos.sX + ((rMonthVal[x] - '0') * sDateFontPos.w),
            sDateFontPos.sY,
            RGB(255,0,255));
        }
      }
    }
    if (bDigiYear)
    {
      /* Use %Y for y2k compliancy.. weee */
      strftime(rYearVal, sizeof(rYearVal), "%Y", stVal);
      for (x=0;x<lstrlen(rYearVal);x++)
      {
        TransparentBltLS(
          dblBuf,
          sDigiYearPos.dX + (x * sDateFontPos.w),
          sDigiYearPos.dY,
          sDateFontPos.w,
          sDateFontPos.h,
          themePic.picDC,
          sDateFontPos.sX + ((rYearVal[x] - '0') * sDateFontPos.w),
          sDateFontPos.sY,
          RGB(255,0,255));
      }
    }
    if (bDigi2dYear)
    {
      /* Bad Cop! No Y2K! */
      strftime(rYearVal, sizeof(rYearVal), "%y", stVal);
      for (x=0;x<lstrlen(rYearVal);x++)
      {
        TransparentBltLS(
          dblBuf,
          sDigi2dYearPos.dX + (x * sDateFontPos.w),
          sDigi2dYearPos.dY,
          sDateFontPos.w,
          sDateFontPos.h,
          themePic.picDC,
          sDateFontPos.sX + ((rYearVal[x] - '0') * sDateFontPos.w),
          sDateFontPos.sY,
          RGB(255,0,255));
      }
    }
  }

}


void Lstime::drawAnaClock()
{
  /* Heavily based off of Whodini's aLSClock module. (Cos my circle math blows :>) */

  SYSTEMTIME tm;
  HPEN anaClockPen;
  HPEN anaOldPen;
  double angle;
  int hx, hy, mx, my, sx, sy;
  time_t tVal;
  struct tm* stVal;
  char rDayVal[10];
  char rMonthVal[10];
  int iTmp;

  BitBlt(dblBuf, 0, 0, 64, 64, bkGrnd.picDC, 0, 0, SRCCOPY);
  
  GetLocalTime(&tm);
   
  if (bAnaDay)
  {
    time(&tVal);
    stVal = localtime(&tVal);
    
    strftime(rDayVal, sizeof(rDayVal), "%w", stVal);
    TransparentBltLS(
      dblBuf,
      sAnaDayPos.dX,
      sAnaDayPos.dY,
      sAnaDayFontPos.w,
      sAnaDayFontPos.h,
      themePic.picDC,
      sAnaDayFontPos.sX + ((rDayVal[0] - '0') * sAnaDayFontPos.w),
      sAnaDayFontPos.sY,
      RGB(255,0,255));
  }
  if (bAnaMonth)
  {
    time(&tVal);
    stVal = localtime(&tVal);
    /*
    if (!anamonthfirsttime)
    {
    
      anamonthfirsttime=1;
      }
    */

    strftime(rMonthVal, sizeof(rMonthVal), "%m", stVal);
    if (rMonthVal[0] == '0')
      TransparentBltLS(
      dblBuf,
      sAnaMonthPos.dX,
      sAnaMonthPos.dY,
      sAnaMonthFontPos.w,
      sAnaMonthFontPos.h,
      themePic.picDC,
      sAnaMonthFontPos.sX + ((rMonthVal[1] - '1') * sAnaMonthFontPos.w),
      sAnaMonthFontPos.sY,
      RGB(255,0,255));
    else
    {
      iTmp = atoi(rMonthVal);
      TransparentBltLS(
        dblBuf,
        sAnaMonthPos.dX,
        sAnaMonthPos.dY,
        sAnaMonthFontPos.w,
        sAnaMonthFontPos.h,
        themePic.picDC,
        sAnaMonthFontPos.sX + ((iTmp - 1) * sAnaMonthFontPos.w),
        sAnaMonthFontPos.sY,
        RGB(255,0,255));
    }
  }    
  
  angle = (M_PI / 6.0) * (double) tm.wHour + (M_PI / 360.0) * (double) tm.wMinute;
  hx = ((sAnaClockPos.dX + (sAnaClockPos.w / 2))) +
    (int) (((sAnaClockPos.w / 2) / 1.88)
    * sin(angle));
  
  hy = ((sAnaClockPos.dY + (sAnaClockPos.h / 2))) -
    (int) (((sAnaClockPos.h / 2) / 1.88)
    * cos(angle));
  
  angle = (M_PI / 30.0) * (double) tm.wMinute;
  mx = ((sAnaClockPos.dX + (sAnaClockPos.w / 2))) +
    (int) (((sAnaClockPos.w / 2) / 1.35)
    * sin(angle));
  my = ((sAnaClockPos.dY + (sAnaClockPos.h / 2))) -
    (int) (((sAnaClockPos.h / 2) / 1.35)
    * cos(angle));
  
  angle = (M_PI / 30.0) * (double) tm.wSecond;
  sx = ((sAnaClockPos.dX + (sAnaClockPos.w / 2))) +
    (int) (((sAnaClockPos.w / 2) / 1.05)
    * sin(angle));
  sy = ((sAnaClockPos.dY + (sAnaClockPos.h / 2))) -
    (int) (((sAnaClockPos.h / 2) / 1.05)
    * cos(angle));
  
  
  anaClockPen = CreatePen(PS_SOLID, 2, cMinHandColor);
  anaOldPen = (HPEN)SelectObject(dblBuf, anaClockPen);
  MoveToEx(dblBuf,
    (sAnaClockPos.dX + sAnaClockPos.w / 2) - 1,
    (sAnaClockPos.dY + sAnaClockPos.h / 2) - 1,
    NULL);
  LineTo(dblBuf,
    mx - 1,
    my - 1);
  SelectObject(dblBuf, anaOldPen);
  DeleteObject(anaClockPen);
  anaClockPen = CreatePen(PS_SOLID, 1, cMinHandShade);
  anaOldPen = (HPEN)SelectObject(dblBuf, anaClockPen);
  MoveToEx(dblBuf,
    sAnaClockPos.dX + sAnaClockPos.w / 2,
    sAnaClockPos.dY + sAnaClockPos.h / 2,
    NULL);
  LineTo(dblBuf,
    mx,
    my);
  SelectObject(dblBuf, anaOldPen);
  DeleteObject(anaClockPen);
  anaClockPen = CreatePen(PS_SOLID, 2, cHourHandColor);
  anaOldPen = (HPEN)SelectObject(dblBuf, anaClockPen);
  MoveToEx(dblBuf,
    (sAnaClockPos.dX + sAnaClockPos.w / 2) - 1,
    (sAnaClockPos.dY + sAnaClockPos.h / 2) - 1,
    NULL);
  LineTo(dblBuf,
    hx - 1,
    hy - 1);
  SelectObject(dblBuf, anaOldPen);
  DeleteObject(anaClockPen);
  anaClockPen = CreatePen(PS_SOLID, 1, cHourHandShade);
  anaOldPen = (HPEN)SelectObject(dblBuf, anaClockPen);
  MoveToEx(dblBuf,
    sAnaClockPos.dX + sAnaClockPos.w / 2,
    sAnaClockPos.dY + sAnaClockPos.h / 2,
    NULL);
  LineTo(dblBuf,
    hx,
    hy);
  SelectObject(dblBuf, anaOldPen);
  DeleteObject(anaClockPen);
  anaClockPen = CreatePen(PS_SOLID, 1, cSecHandColor);
  anaOldPen = (HPEN)SelectObject(dblBuf, anaClockPen);
  MoveToEx(dblBuf,
    sAnaClockPos.dX + sAnaClockPos.w / 2,
    sAnaClockPos.dY + sAnaClockPos.h / 2,
    NULL);
  LineTo(dblBuf,
    sx,
    sy);
  SelectObject(dblBuf, anaOldPen);
  DeleteObject(anaClockPen);
}


//=========================================================
// Registered messages
//=========================================================

void Lstime::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onPaint,             WM_PAINT)
    //MESSAGE(onPaint,             LM_REPAINT)
    MESSAGE(onCreate,            WM_CREATE)
    MESSAGE(onDestroy,           WM_DESTROY)
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onMouseButtonDown,   WM_RBUTTONDOWN)
    MESSAGE(onTimer,             WM_TIMER)
    MESSAGE(onMouseButtonDBL,    WM_LBUTTONDBLCLK)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
#ifdef _NTP_SUPPORT
    MESSAGE(onMouseButtonUp,     WM_RBUTTONUP)
    MESSAGE(onCommand,           WM_COMMAND)
#endif
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void Lstime::onCreate(Message& message)
{
  
  FILE* tmpTheme;
  char tmpThemeFName[MAX_LINE_LENGTH+1];
  HDC parentDC;
  
  globCounter = true;
  firstTime = true;
  
  int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

  SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
  
  parentDC = GetDC(hParent);
  bkGrnd.picDC = CreateCompatibleDC(parentDC);
  bkGrnd.usePic = CreateCompatibleBitmap(parentDC, 64, 64);
  oldBMP1 = (HBITMAP)SelectObject(bkGrnd.picDC, bkGrnd.usePic);
  ReleaseDC(hParent, parentDC);
  dblBuf = CreateCompatibleDC(bkGrnd.picDC);
  dblBufBMP = CreateCompatibleBitmap(bkGrnd.picDC, 64, 64);
  oldBMP2 = (HBITMAP)SelectObject(dblBuf, dblBufBMP);
  SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
  //SetWindowLong(hMainWin, GWL_USERDATA, magicDWord);
  if (GetRCString("LSTimeThemeFile", tmpThemeFName, "nofile.thm", MAX_LINE_LENGTH+1))
  {
    tmpTheme = fopen(tmpThemeFName, "r");
    if (!tmpTheme)
    {
      MessageBox(hParent, "Invalid Theme File specified.", szAppName, MB_OK);
    }
    else
      themeParse(tmpTheme);
  }
  else
  {
    MessageBox(hParent, "No Theme File specified.", szAppName, MB_OK);
  }
  if (bAnaClock)
    drawAnaClock();
  else
    drawDigiClock();

  SetTimer(hWnd, 0, ONE_SEC_IN_MS, NULL);
  // show the main window
  SetCursor(LoadCursor(NULL, IDC_ARROW));
  SetWindowPos(hWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
  ShowWindow(hWnd, SW_SHOWNORMAL); 


}


void Lstime::onDestroy(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

  SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  if (bkGrnd.picDC) {
    SelectObject(bkGrnd.picDC, oldBMP1);
    DeleteDC(bkGrnd.picDC);
  }
  if (bkGrnd.usePic)
    DeleteObject(bkGrnd.usePic);
  if (dblBuf) {
    SelectObject(dblBuf, oldBMP2);
    DeleteDC(dblBuf);
  }
  if (dblBufBMP)
    DeleteObject(dblBufBMP);
  if (themePic.picDC) {
    SelectObject(themePic.picDC, oldBMP3);
    DeleteDC(themePic.picDC);
  }
  if (themePic.usePic)
    DeleteObject(themePic.usePic);
  if (themePic.oldPic)
    DeleteObject(themePic.oldPic);
}


void Lstime::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Lstime::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "lstime2.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}

void Lstime::onMouseButtonDown(Message& message)
{
  RECT r;
  GetWindowRect(hWnd, &r);
  PostMessage(GetParent(GetParent(hParent)), 9182,
    r.top+(int)HIWORD(message.lParam), r.left+(int)LOWORD(message.lParam));
}


void Lstime::onMouseButtonDBL(Message& message)
{
  char winDir[MAX_LINE_LENGTH+1];
  GetSystemDirectory(winDir, MAX_LINE_LENGTH);
  LSExecuteEx(hWnd, "open", "rundll32.exe", "shell32.dll,Control_RunDLL timedate.cpl", winDir, SW_SHOWNORMAL);
}

void Lstime::onPaint(Message& message)
{
  if (firstTime)
  {
    makeBuffer(hParent);
    firstTime = false;
  }
  else
  {
    PAINTSTRUCT ps;
    HDC screenDC = BeginPaint(hWnd, &ps);
    RECT r;
    GetClientRect(hWnd, &r);
    if (bAnaClock)
      drawAnaClock();
    else
      drawDigiClock();
    BitBlt(screenDC, 0, 0, r.right, r.bottom, dblBuf,
      0, 0, SRCCOPY);
    EndPaint(hWnd, &ps);
  }
}


void Lstime::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Lstime::onTimer(Message& message)
{
  RECT r;
	GetClientRect(hWnd, &r);
	InvalidateRect(hWnd, &r, FALSE);
}

#ifdef _NTP_SUPPORT
void Lstime::onMouseButtonUp(Message& message)
{
	DWORD dw = GetMessagePos();
	TrackPopupMenu(popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hWnd, NULL);
}


void Lstime::onCommand(Message& message)
{
  switch (message.wParam) 
  {
    case 100:
      onMouseButtonDBL(message);
      break;
    case 101:
      ntpclient->showNTPSetup();
      break;
    case 102:
      ntpclient->doNTPSync();
      break;
  }
}
#endif


//=========================================================
// Bang command handling
//=========================================================