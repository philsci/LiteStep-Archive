#include "hookmgr.h"

HookManager* phmHookMgr = NULL;

LRESULT CALLBACK WndProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	if (phmHookMgr) {
		switch (msg) {
		case WM_COPYDATA: // Used for passing messages
			phmHookMgr->ProcessMsgMessage((HWND)wParam,(HOOKMSGDATA*)lParam);
			break;
		case LM_REGISTERMESSAGE: //Register to recieve messages
			if (lParam == 0) phmHookMgr->AddShellHook((HWND)wParam); // lParam = 0, register for shell messages
			else phmHookMgr->AddMsgHook((UINT)lParam, (HWND)wParam); // Otherwise lParam is the message to monitor
			break;
		case LM_UNREGISTERMESSAGE: // Opposite of register, you can figure it out
			if (lParam == 0) phmHookMgr->RemoveShellHook((HWND)wParam);
			else phmHookMgr->RemoveMsgHook((UINT)lParam, (HWND)wParam);
			break;
		case LM_SHELLMESSAGE:
			switch(lParam) {
			case HSHELL_GETMINRECT: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_MINMAXWIN);
				break;
			case HSHELL_WINDOWACTIVATED: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_ACTIVEWIN);
				break;
			case HSHELL_WINDOWCREATED: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_ADDWINDOW);
				break;
			case HSHELL_WINDOWDESTROYED: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_REMOVEWINDOW);
				break;
		/* Windows 2000 - Leave out for now
			case HSHELL_ACCESSIBILITYSTATE: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_ACCESSSTATE);
				break;
		*/
			case HSHELL_ACTIVATESHELLWINDOW: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_ACTIVESHELLWIN);
				break;
		/* Windows 2000 - Leave out for now
			case HSHELL_APPCOMMAND: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_APPCOMMAND);
				break;
		*/
			case HSHELL_LANGUAGE: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_LANGUAGE);
				break;
			case HSHELL_REDRAW: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_REDRAW);
				break;
			case HSHELL_TASKMAN: // Shell message
				phmHookMgr->ProcessShellMessage((HWND)wParam, LM_TASKMAN);
				break;
			default: // Default =P
				break;
			}
			break;
		}
	}

    return DefWindowProc(hWnd,msg,wParam,lParam);    
}

HWND hHookMgrWndw;

int initModuleEx(HWND parent, HINSTANCE hiDLL, LPCSTR szPath)
{
    
    
    WNDCLASSEX wcxHookMgrWndw; // Hook Manager Window Class
    // Initializing Window Class
    wcxHookMgrWndw.cbSize = sizeof(wcxHookMgrWndw);
    wcxHookMgrWndw.style = CS_DBLCLKS;
    wcxHookMgrWndw.lpfnWndProc = (WNDPROC)WndProc;
    wcxHookMgrWndw.cbClsExtra = 0; 
    wcxHookMgrWndw.cbWndExtra = 0; 
    wcxHookMgrWndw.hInstance = hiDLL;
    wcxHookMgrWndw.hIcon = NULL; 
    wcxHookMgrWndw.hCursor = NULL;
    wcxHookMgrWndw.hbrBackground = NULL; 
    wcxHookMgrWndw.lpszMenuName = NULL; 
    wcxHookMgrWndw.lpszClassName = WC_MAIN; 
    wcxHookMgrWndw.hIconSm = NULL;
    
    ATOM result = RegisterClassEx(&wcxHookMgrWndw); // Register the class

    //Create the window
    hHookMgrWndw = CreateWindowEx(
		WS_EX_TOOLWINDOW,
        WC_MAIN,
        NULL,
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        (HWND) NULL,
        (HMENU) NULL,
        hiDLL,
        NULL);
    
    phmHookMgr = new HookManager(hHookMgrWndw);
    return 0;
}

int quitModule(HINSTANCE dll)
{
	DestroyWindow(hHookMgrWndw);
    delete phmHookMgr;
	phmHookMgr = NULL;
    return 0;
}
