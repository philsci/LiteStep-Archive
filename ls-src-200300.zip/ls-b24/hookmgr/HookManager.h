#ifndef __HOOKMANAGER_H
#define __HOOKMANAGER_H

#define STRICT
#define WIN32_LEAN_AND_MEAN

#pragma	warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include "../hook/hook.h"

#include <map> // STL
#include <set> // STL

using namespace std;
typedef set<HWND> sShellHookList;  // Shell message list
typedef set<HWND> sMsgHookList; // Basically a dynamic list of HWNDs for MessageHooks
typedef map<UINT, sMsgHookList*> msg2hwnd; // Maps a message to a list of HWNDs

class HookManager {
public:
    HookManager(HWND);
    ~HookManager();
    bool AddMsgHook(UINT, HWND);
    bool RemoveMsgHook(UINT, HWND);
    bool AddShellHook(HWND);
    bool RemoveShellHook(HWND);
    void ProcessMsgMessage(HWND, HOOKMSGDATA*);
    void ProcessShellMessage(HWND, UINT);

private:

    msg2hwnd _m2hmap;
    int _numMessages;
    HWND _hTasks;
    sShellHookList _sHookList;
};

#endif __HOOKMANAGER_H