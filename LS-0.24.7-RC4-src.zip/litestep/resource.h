//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by litestep.rc
//
#define IDS_LITESTEP_TITLE_WARNING      1
#define IDS_LITESTEP_TITLE_ERROR        2
#define IDS_LITESTEP_ERROR1             3
#define IDS_LITESTEP_ERROR2             4
#define IDS_LITESTEP_ERROR3             5
#define IDS_LITESTEP_ERROR4             6
#define IDS_LITESTEP_ERROR5             7
#define IDS_LITESTEP_ERROR6             8
#define IDS_LITESTEP_ERROR7             9
#define IDS_LITESTEP_RECYCLELS          10
#define IDS_LITESTEP_QUITLS             11
#define IDS_LITESTEP_TERMINATELS        12
#define IDS_LITESTEP_RUN                13
#define IDS_LITESTEP_SHUTDOWNWIN        14
#define IDS_MODULEQUIT_ERROR            15
#define IDS_MODULENOTFOUND_ERROR        16
#define IDS_INITMODULEEXNOTFOUND_ERROR  17
#define IDS_QUITMODULENOTFOUND_ERROR    18
#define IDS_MODULEINITEXCEPTION_ERROR   19
#define IDS_LITESTEP_CREATEWINDOW_ERROR 20
#define IDS_HOOKMGR_CREATETHREAD_ERROR  21
#define IDS_HOOKMGR_LOADHOOK_ERROR      22
#define IDS_LITESTEP_BANGEXCEPTION      23
#define IDS_LITESTEP_REGISTERCLASS_ERROR 24
#define IDI_LS                          101
#define IDB_LS                          102
#define IDD_ABOUTBOX                    103
#define IDC_HEADER                      1001
#define IDC_TITLE                       1002
#define IDC_LOGO                        1003
#define IDC_COMPILETIME                 1004
#define IDC_COMBOBOX                    1005
#define IDC_LISTVIEW                    1006
#define IDC_THEME_INFO                  1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
