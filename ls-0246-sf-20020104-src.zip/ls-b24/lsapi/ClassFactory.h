// class factory template to save time on com library implementation

template <class COCLASS>
class ClassFactory: public IClassFactory
{
	long refCount;
	IID ifc;
	BOOL *lock;

public:

	// pass in the IID this class factory will be creating instance of and a locking variable pointer
	ClassFactory(REFIID i, BOOL *lockVar): refCount(0), ifc(i), lock(lockVar)
	{}
	;
	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(
	    /* [in] */ REFIID riid,
	    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv)
	{

		if (riid == IID_IUnknown)
		{
			*ppv = static_cast<IUnknown*>(this);
		}
		else if (riid == IID_IClassFactory)
		{
			*ppv = static_cast<IClassFactory*>(this);
		}
		else
		{
			*ppv = 0;
			return E_NOINTERFACE;
		}

		reinterpret_cast<IUnknown*>(*ppv)->AddRef();
		return S_OK;
	};

	virtual ULONG STDMETHODCALLTYPE AddRef( void)
	{
		return InterlockedIncrement(&refCount);
	};

	virtual ULONG STDMETHODCALLTYPE Release( void)
	{
		LONG count = InterlockedDecrement(&refCount);

		if (count == 0)
		{
			delete this;
		}

		return count;
	};

	/////////////////////////////////////////////////////////////////////////////
	// From IClassFactory
	virtual /* [local] */ HRESULT STDMETHODCALLTYPE CreateInstance(
	    /* [unique][in] */ IUnknown __RPC_FAR *pUnkOuter,
	    /* [in] */ REFIID riid,
	    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject)
	{

		*ppvObject = NULL;

		COCLASS *myCoClass = new COCLASS();
		if (riid == ifc)
		{
			return myCoClass->QueryInterface(ifc, ppvObject);
		}
		else if (riid == IID_IUnknown)
		{
			return myCoClass->QueryInterface(IID_IUnknown, ppvObject);
		}
		else
		{
			return E_FAIL;
		}
	}

	virtual /* [local] */ HRESULT STDMETHODCALLTYPE LockServer(
	    /* [in] */ BOOL fLock)
	{

		*lock = fLock;

		return S_OK;
	}
};

