/*

 This is a part of the LiteStep Shell Source code.

 Copyright (C) 1997-2001 The LiteStep Development Team

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
01/28/00 - Charles Oliver Nutter (Headius)
  - Modified boolean statements to perform comparisons rather than forced
	  conversion
	- Added pragma to disable stl warnings
01/26/00 - Joachim Calvert (NeXTer)
  - The topmost problem is finally fixed with a little assistance from jugg
12/15/00 - Joachim Calvert (NeXTer)
  - Hopefully the ontop problems are gone
12/10/00 - Joachim Calvert (NeXTer)
  - Code cleanup in preparation for LS coding standards draft
11/30/00 - Joachim Calvert (NeXTer)
  - Cleaned up the new code
11/30/00 - Bobby G. Vinyard (Message)
  - Added code to move a shortcut whose position was not on a display monitor
    to the nearest monitor (This should cure the problem with shortcuts not
    being visible because of different resolution in multimon systems)
11/30/00 - Joachim Calvert (NeXTer)
  - Added the 'r' flag that makes the shortcut relative to the one before it
11/28/00 - Bobby G. Vinyard (Message)
  - Added multimonitor support
11/21/00 - Joachim Calvert (NeXTer)
  - Added the ability to place shortcuts relative the screen center. Just add
    a 'c' after the relevant coordinate (i.e., -42c)
10/06/00 - Joachim Calvert (NeXTer)
  - The caption set for the shortcut is now set as the window caption for
    the shortcut, so that operations can be performed on individual shortcuts
    when using an advanced scripting module
  - Added the ability to set whether or not captions are shown for all and
    individual shortcuts. See shortcut2.txt for details
08/20/00 - Joachim Calvert (NeXTer)
  - Added the ability to define default sounds, see shortcut2.txt for details
08/17/00 - Joachim Calvert (NeXTer)
  - Can be refreshed with the use of the !Refresh command
  - The shortcuts now revert to the normal state before being shown
08/15/00 - Joachim Calvert (NeXTer)
  - When using sounds you can now use .none for the mouseover to only get sound
    on click
08/10/00 - Joachim Calvert (NeXTer)
  - Added drag'n'drop, courtesy of Sylvain Rouquette (Syl)
08/07/00 - Joachim Calvert (NeXTer)
  - Added sound support, courtesy of Sylvain Rouquette (Syl)
05/28/00 - Joachim Calvert (NeXTer)
  - When using opaque shortcut images, you can speed up loading considerably
    by adding an 'o' to the flags. This will prevent the use of regions for
    the marked shortcut.
05/25/00 - Joachim Calvert (NeXTer)
  - After a tip from blkhawk, all drawing is now done in the WM_ERASEBKGND
    handler. Should be a wee bit smother than before.
05/21/00 - Joachim Calvert (NeXTer)
  - Had forgotten to reset the region after changing the topmost attribute.
05/20/00 - Joachim Calvert (NeXTer)
  - !ShortcutGroupOnTopToggle now works... I had forgotten to add the actual code
05/17/00 - Joachim Calvert (NeXTer)
  - Added the command !ShortcutGroupOnTopToggle.
05/12/00 - Joachim Calvert (NeXTer)
  - If a shortcut is started as hidden, the resources for it aren't created
    until it is shown, substantially decreasing the time to load LS if there
    are many hidden shortcuts.
04/27/00 - Joachim Calvert (NeXTer)
  - You now have to preceed any creation flags with '#', otherwise it'll be
    assumed that it's the command.
04/26/00 - Joachim Calvert (NeXTer)
  - After som thorough testing by rootrider, it should now be pretty stable.
    Currently supported bang commands are !ShortcutGroupToggle,
    !ShortcutGroupShow, !ShortcutGroupHide, !ShortcutGroupOnTop &
    !ShortcutGroupOnBottom, followed by one or more group numbers, or * to
    perform the operation on all groups.
04/25/00 - Joachim Calvert (NeXTer)
  - Complete rewrite from scratch, 2nd edition. The first edition
    accidentally got overwritten when I had finished it...
****************************************************************************/
#pragma warning(disable: 4786)
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>

#include "shortcut.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/safestr.h"

using namespace std;

//---------------------------------------------------------
// Global defs and vars
//---------------------------------------------------------

const char APP_NAME[] = "ShortcutClass"; // Our window class, etc
const char RCS_REVISION[] = "$Revision: 1.2 $"; // Our Version
const char RCS_ID[] = "$Id: shortcut.cpp,v 1.2 2001/11/20 22:39:52 message Exp $"; // The Full RCS ID.
const LEAVE_TIMER_ID = 1;
const UM_SETTOPMOST = WM_USER;

ShortcutFactory* shortcutFactory;
HWND desktopWnd;


//---------------------------------------------------------
// Module startup and shutdown
//---------------------------------------------------------

int initModuleEx(HWND parentWnd, HINSTANCE hInst, LPCSTR)
{
	int code;

	desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktopWnd)
		desktopWnd = GetDesktopWindow();

	Window::init(hInst);

	shortcutFactory = new ShortcutFactory(parentWnd, code);

	return code;
}


void quitModule(HINSTANCE)
{
	delete shortcutFactory;
}


//=========================================================
// ShortcutFactory ////////////////////////////////////////
//=========================================================

ShortcutFactory::ShortcutFactory(HWND parentWnd, int& code):
		Window(APP_NAME),
		fSoundClick(NULL),
		fSoundHover(NULL),
		fShowCaptions(true),
		fBangLock(false)
{
	fShortcutHints = CreateWindow(TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
	                              CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
	                              NULL, NULL, hInstance, NULL);
	if (fShortcutHints)
		SetWindowPos(fShortcutHints, HWND_TOPMOST, 0, 0, 0, 0,
		             SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

	createWindow(WS_EX_TOOLWINDOW, "ShortcutFactory", WS_POPUP,
	             0, 0, 0, 0, parentWnd);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	createShortcuts();
}


ShortcutFactory::~ShortcutFactory()
{
	destroyWindow();
}


void ShortcutFactory::relayHintMessage(HWND hWnd, Message& message)
{
	MSG hintMessage = {hWnd, message.uMsg, message.wParam, message.lParam};

	if (!fShortcutHints)
		return ;
	SendMessage(fShortcutHints, TTM_RELAYEVENT, 0, LPARAM(&hintMessage));
	SetWindowPos(fShortcutHints, HWND_TOPMOST, 0, 0, 0, 0,
	             SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}


void ShortcutFactory::addHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!fShortcutHints)
		return ;
	GetClientRect(hWnd, &clientRect);
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(fShortcutHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::removeHint(HWND hWnd)
{
	TOOLINFO ti;
	RECT emptyRect = {0, 0, 0, 0};

	if (!fShortcutHints)
		return ;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = emptyRect;
	ti.hinst = hInstance;
	ti.lpszText = NULL;
	ti.lParam = 0;
	SendMessage(fShortcutHints, TTM_DELTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::createShortcuts()
{
	char configLine[MAX_LINE_LENGTH];
	FILE* step;
	DWORD groupNumber;
	ShortcutMap::iterator smIter;
	Shortcut* newShortcut;

	GetRCString("shortcutSoundClick", configLine, ".none", MAX_LINE_LENGTH);
	if (!StrIPos(configLine, ".none"))
	{
		fSoundClick = new char[StrLen(configLine) + 1];
		StrCopy(fSoundClick, configLine);
	}
	GetRCString("shortcutSoundHover", configLine, ".none", MAX_LINE_LENGTH);
	if (!StrIPos(configLine, ".none"))
	{
		fSoundHover = new char[StrLen(configLine) + 1];
		StrCopy(fSoundHover, configLine);
	}
	fShowCaptions = GetRCBoolDef("shortcutShowCaptions", TRUE) != FALSE;

	step = LCOpen(NULL);
	if (step)
	{
		while (LCReadNextConfig(step, "*shortcut", configLine, MAX_LINE_LENGTH))
		{
			newShortcut = new Shortcut(this, configLine, groupNumber);
			smIter = fShortcutGroups.find(groupNumber);
			if (smIter == fShortcutGroups.end())
				fShortcutGroups.insert(ShortcutMap::value_type(groupNumber, newShortcut));
			else
			{
				newShortcut->append(smIter->second);
				smIter->second = newShortcut;
			}
		}
		LCClose(step);
	}
}


void ShortcutFactory::destroyShortcuts()
{
	ShortcutMap::iterator smIter;

	for (smIter = fShortcutGroups.begin(); smIter != fShortcutGroups.end(); smIter++)
		if (smIter->second)
			delete smIter->second;
	fShortcutGroups.clear();

	if (fSoundClick)
		delete[] fSoundClick;
	if (fSoundHover)
		delete[] fSoundHover;
	fSoundClick = NULL;
	fSoundHover = NULL;
}


void ShortcutFactory::setVisible(LPCSTR groups, int state)
{
	char group[MAX_LINE_LENGTH];
	LPCSTR nextGroup = groups;
	ShortcutMap::iterator smIter;

	if (CharInStr('*', groups))
	{
		for (smIter = fShortcutGroups.begin(); smIter != fShortcutGroups.end(); smIter++)
		{
			if (smIter->second)
				smIter->second->setVisible(state);
		}
	}
	else
		while (GetToken(nextGroup, group, &nextGroup, false))
		{
			smIter = fShortcutGroups.find(atoi(group));
			if (smIter != fShortcutGroups.end())
				if (smIter->second)
					smIter->second->setVisible(state);
		}
}


//---------------------------------------------------------
// Bang commands
//---------------------------------------------------------

void ShortcutFactory::bangGroupToggle(HWND sender, LPCSTR args)
{
	shortcutFactory->setVisible(args, 0);
}


void ShortcutFactory::bangGroupShow(HWND sender, LPCSTR args)
{
	shortcutFactory->setVisible(args, 1);
}


void ShortcutFactory::bangGroupHide(HWND sender, LPCSTR args)
{
	shortcutFactory->setVisible(args, -1);
}


void ShortcutFactory::bangGroupOnTopToggle(HWND sender, LPCSTR args)
{
	int state = 0;
	while (shortcutFactory->fBangLock)
		;
	shortcutFactory->fBangLock = true;
	SendMessage(shortcutFactory->handle(), UM_SETTOPMOST, WPARAM(args), LPARAM(state));
	shortcutFactory->fBangLock = false;
}


void ShortcutFactory::bangGroupOnTop(HWND sender, LPCSTR args)
{
	int state = 1;

	while (shortcutFactory->fBangLock)
		;
	shortcutFactory->fBangLock = true;
	SendMessage(shortcutFactory->handle(), UM_SETTOPMOST, WPARAM(args), LPARAM(state));
	shortcutFactory->fBangLock = false;
}


void ShortcutFactory::bangGroupOnBottom(HWND sender, LPCSTR args)
{
	int state = -1;

	while (shortcutFactory->fBangLock)
		;
	shortcutFactory->fBangLock = true;
	SendMessage(shortcutFactory->handle(), UM_SETTOPMOST, WPARAM(args), LPARAM(state));
	shortcutFactory->fBangLock = false;
}


//---------------------------------------------------------
// Message handling
//---------------------------------------------------------

void ShortcutFactory::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onRefresh, LM_REFRESH)
	MESSAGE(onSetTopmost, UM_SETTOPMOST)
	END_MESSAGEPROC
}


void ShortcutFactory::onCreate(Message& message)
{
	int lsMessages[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

	AddBangCommand("!shortcutgrouptoggle", bangGroupToggle);
	AddBangCommand("!shortcutgroupshow", bangGroupShow);
	AddBangCommand("!shortcutgrouphide", bangGroupHide);
	AddBangCommand("!shortcutgroupontoptoggle", bangGroupOnTopToggle);
	AddBangCommand("!shortcutgroupontop", bangGroupOnTop);
	AddBangCommand("!shortcutgrouponbottom", bangGroupOnBottom);
}


void ShortcutFactory::onDestroy(Message& message)
{
	ShortcutMap::iterator smIter;
	int lsMessages[] = {LM_GETREVID, LM_REFRESH, 0};

	destroyShortcuts();

	if (fShortcutHints)
		DestroyWindow(fShortcutHints);

	SendMessage(hParent, LM_UNREGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

	RemoveBangCommand("!shortcutgrouptoggle");
	RemoveBangCommand("!shortcutgroupshow");
	RemoveBangCommand("!shortcutgrouphide");
	RemoveBangCommand("!shortcutgroupontoptoggle");
	RemoveBangCommand("!shortcutgroupontop");
	RemoveBangCommand("!shortcutgrouponbottom");
}


void ShortcutFactory::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
		case 0:
		sprintf(buf, "shortcut2.dll: %s", &RCS_REVISION[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
		default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void ShortcutFactory::onRefresh(Message& message)
{
	destroyShortcuts();
	createShortcuts();
}


void ShortcutFactory::onSetTopmost(Message& message)
{
	LPCSTR groups = LPCSTR(message.wParam);
	int topMost = int(message.lParam);
	char group[MAX_LINE_LENGTH];
	LPCSTR nextGroup = groups;
	ShortcutMap::iterator smIter;

	if (CharInStr('*', groups))
	{
		for (smIter = fShortcutGroups.begin(); smIter != fShortcutGroups.end(); smIter++)
			if (smIter->second)
				smIter->second->setTopMost(topMost);
	}
	else
		while (GetToken(nextGroup, group, &nextGroup, false))
		{
			smIter = fShortcutGroups.find(atoi(group));
			if (smIter != fShortcutGroups.end())
				if (smIter->second)
					smIter->second->setTopMost(topMost);
		}
}


//=========================================================
// Shortcut ///////////////////////////////////////////////
//=========================================================

Shortcut::Shortcut(ShortcutFactory* owner, LPCSTR szLine, DWORD& group):
		Window(APP_NAME),
		fOwner(owner),
		fNext(NULL),
		fRICurrent(NULL),
		fCaption(NULL),
		fCommand(NULL),
		fCommandArgs(NULL),
		fNormalName(NULL),
		fHoverName(NULL),
		fClickName(NULL),
		fHoverSound(NULL),
		fClickSound(NULL),
		fState(ssNormal),
		fIsTopMost(false),
		fIsVisible(true),
		fIsOpaque(false),
		fShowCaption(true),
		fLeaveTimer(0),
		fLeft(0),
		fTop(0),
		fLeftCenter(false),
		fTopCenter(false),
		fWidth(32),
		fHeight(32),
		fPaintDC(NULL)
{
	memset(&fRINormal, 0, sizeof(RegionImage));
	memset(&fRIHover, 0, sizeof(RegionImage));
	memset(&fRIClick, 0, sizeof(RegionImage));

	group = parseConfig(szLine);

	if (fIsVisible)
		createShortcut();
}


Shortcut::~Shortcut()
{
	if (fNext)
		delete fNext;
	clear();
	destroyWindow();
}


void Shortcut::append(Shortcut* shortcut)
{
	fNext = shortcut;
}


void Shortcut::setVisible(int visible)
{
	bool wasVisible = fIsVisible;

	if (!visible)
		fIsVisible = !fIsVisible;
	else
		fIsVisible = visible > 0;

	if (!hWnd && fIsVisible)
		createShortcut();

	if (fIsVisible != wasVisible)
		ShowWindow(hWnd, (fIsVisible ? SW_SHOW : SW_HIDE));

	if (fNext)
		fNext->setVisible(visible);
}


void Shortcut::setTopMost(int topMost)
{
	bool wasTopMost = fIsTopMost;

	if (!topMost)
		fIsTopMost = !fIsTopMost;
	else
		fIsTopMost = topMost > 0;

	if (hWnd && (fIsTopMost != wasTopMost))
	{
		SetWindowLong(handle(), GWL_STYLE,
		              (GetWindowLong(handle(), GWL_STYLE) & ~WS_POPUP) | WS_CHILD);
		if (fIsTopMost)
		{
			SetParent(handle(), NULL);
			SetWindowText(handle(), NULL);
			SetWindowLong(handle(), GWL_STYLE,
			              (GetWindowLong(handle(), GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
			SetWindowPos(handle(), HWND_TOPMOST, 0, 0, 0, 0,
			             SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
		}
		else
		{
			SetParent(handle(), desktopWnd);
			SetWindowText(handle(), (fCaption ? fCaption : "shortcut"));
		}
	}

	if (fNext)
		fNext->setTopMost(topMost);
}


DWORD Shortcut::parseConfig(LPCSTR szConfigLine)
{
	char token[MAX_LINE_LENGTH];
	LPCSTR nextToken = szConfigLine;
	DWORD result = 0;
	bool hasCommand = true;
	bool clickSoundDef = false;
	bool hoverSoundDef = false;
	static int lastLeft = 0;
	static int lastTop = 0;

	clear();

	GetToken(nextToken, NULL, &nextToken, false);
	if (GetToken(nextToken, token, &nextToken, false))
	{
		fCaption = new char[StrLen(token) + 1];
		StrCopy(fCaption, token);
	}

	if (GetToken(nextToken, token, &nextToken, false))
	{
		fLeft = atoi(token);
		strlwr(token);
		fLeftCenter = strchr(token, 'c') != 0;
		if (strchr(token, 'r'))
			fLeft += lastLeft;
	}
	if (GetToken(nextToken, token, &nextToken, false))
	{
		fTop = atoi(token);
		strlwr(token);
		fTopCenter = strchr(token, 'c') != 0;
		if (strchr(token, 'r'))
			fTop += lastTop;
	}
	lastLeft = fLeft;
	lastTop = fTop;

	if (GetToken(nextToken, token, &nextToken, false))
	{
		fNormalName = new char[strlen(token) + 1];
		StrCopy(fNormalName, token);
	}
	if (GetToken(nextToken, token, &nextToken, false))
	{
		fHoverName = new char[strlen(token) + 1];
		StrCopy(fHoverName, token);
	}
	if (GetToken(nextToken, token, &nextToken, false))
	{
		fClickName = new char[strlen(token) + 1];
		StrCopy(fClickName, token);
	}

	if (GetToken(nextToken, token, &nextToken, false))
	{
		if (token[0] == '#')
		{
			strlwr(token);
			result = atoi(&token[1]);
			fIsVisible = !strchr(token, 'h');
			fIsTopMost = strchr(token, 't') != 0;
			fIsOpaque = strchr(token, 'o') != 0;
			if (fOwner->getShowCaptions())
				fShowCaption = !strchr(token, 'c');
			else
				fShowCaption = strchr(token, 'c') != 0;
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		}

		if (StrIPos(token, ".wav"))
		{
			fHoverSound = new char[StrLen(token) + 1];
			StrCopy(fHoverSound, token);
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		}
		else if (StrIPos(token, ".none"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".def"))
		{
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
			hoverSoundDef = true;
		}
		else
			hoverSoundDef = true;

		if (StrIPos(token, ".wav"))
		{
			fClickSound = new char[StrLen(token) + 1];
			StrCopy(fClickSound, token);
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		}
		else if (StrIPos(token, ".none"))
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
		else if (StrIPos(token, ".def"))
		{
			hasCommand = GetToken(nextToken, token, &nextToken, false) != FALSE;
			clickSoundDef = true;
		}
		else
			clickSoundDef = true;

		if (hoverSoundDef && fOwner->getSoundHover())
		{
			fHoverSound = new char[StrLen(fOwner->getSoundHover()) + 1];
			StrCopy(fHoverSound, fOwner->getSoundHover());
		}

		if (clickSoundDef && fOwner->getSoundClick())
		{
			fClickSound = new char[StrLen(fOwner->getSoundClick()) + 1];
			StrCopy(fClickSound, fOwner->getSoundClick());
		}

		if (hasCommand)
		{
			fCommand = new char[StrLen(token) + 1];
			StrCopy(fCommand, token);
		}
		if (nextToken)
		{
			fCommandArgs = new char[StrLen(nextToken) + 1];
			StrCopy(fCommandArgs, nextToken);
		}
	}

	return result;
}


void Shortcut::createShortcut()
{
	if (fNormalName)
		fRINormal.image = LoadLSImage(fNormalName, NULL);
	if (fHoverName)
		fRIHover.image = LoadLSImage(fHoverName, NULL);
	if (fClickName)
		fRIClick.image = LoadLSImage(fClickName, NULL);

	if (!fIsOpaque)
	{
		if (fRINormal.image)
			fRINormal.region = BitmapToRegion(fRINormal.image, RGB(255, 0, 255),
			                                  0x101010, 0, 0);
		if (fRIHover.image)
			fRIHover.region = BitmapToRegion(fRIHover.image, RGB(255, 0, 255),
			                                 0x101010, 0, 0);
		if (fRIClick.image)
			fRIClick.region = BitmapToRegion(fRIClick.image, RGB(255, 0, 255),
			                                 0x101010, 0, 0);
	}

	fRelOrigin = convertCoords(fLeft, fTop);

	createWindow((fIsTopMost ? WS_EX_TOPMOST | WS_EX_TOOLWINDOW : 0),
	             (fIsTopMost ? NULL : (fCaption ? fCaption : "shortcut")),
	             (fIsTopMost ? WS_POPUP : WS_CHILD) | WS_CLIPSIBLINGS,
	             fRelOrigin.x, fRelOrigin.y, fWidth, fHeight,
	             (fIsTopMost ? NULL : desktopWnd));

	ShowWindow(hWnd, SW_SHOW);
}


void Shortcut::clear()
{
	if (fCaption)
		delete[] fCaption;
	if (fCommand)
		delete[] fCommand;
	if (fCommandArgs)
		delete[] fCommandArgs;
	if (fNormalName)
		delete[] fNormalName;
	if (fHoverName)
		delete[] fHoverName;
	if (fClickName)
		delete[] fClickName;
	if (fHoverSound)
		delete[] fHoverSound;
	if (fClickSound)
		delete[] fClickSound;

	if (fRINormal.image)
		DeleteObject(fRINormal.image);
	if (fRINormal.region)
		DeleteObject(fRINormal.region);
	if (fRIHover.image)
		DeleteObject(fRIHover.image);
	if (fRIHover.region)
		DeleteObject(fRIHover.region);
	if (fRIClick.image)
		DeleteObject(fRIClick.image);
	if (fRIClick.region)
		DeleteObject(fRIClick.region);
	if (fPaintDC)
		DeleteObject(fPaintDC);

	fCaption = NULL;
	fCommand = NULL;
	fCommandArgs = NULL;
	fNormalName = NULL;
	fHoverName = NULL;
	fClickName = NULL;
	fHoverSound = NULL;
	fClickSound = NULL;
	fPaintDC = NULL;
	memset(&fRINormal, 0, sizeof(RegionImage));
	memset(&fRIHover, 0, sizeof(RegionImage));
	memset(&fRIClick, 0, sizeof(RegionImage));
}


void Shortcut::setImage(RegionImage& regionImage, bool reset = false)
{
	if (!regionImage.image || (!reset && (&regionImage == fRICurrent)))
		return ;

	RECT clientRect;

	fRICurrent = &regionImage;
	GetLSBitmapSize(fRICurrent->image, &fWidth, &fHeight);
	SetWindowPos(hWnd, HWND_TOP, 0, 0, fWidth, fHeight,
	             SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);

	if (!fIsOpaque)
	{
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);

		CombineRgn(windowRgn, fRICurrent->region, NULL, RGN_COPY);
		SetWindowRgn(hWnd, windowRgn, true);
	}

	GetClientRect(hWnd, &clientRect);
	InvalidateRect(hWnd, &clientRect, true);
}

POINT Shortcut::convertCoords(const int left, const int top) const
{
	POINT relPt;

	if (fLeftCenter)
		relPt.x = (SCREEN_WIDTH / 2) + left;
	else
		relPt.x = CONVERT_COORDINATE_X(left);

	if (fTopCenter)
		relPt.y = (SCREEN_HEIGHT / 2) + top;
	else
		relPt.y = CONVERT_COORDINATE_Y(top);

	if (!MonitorFromPoint(relPt, MONITOR_DEFAULTTONULL))
	{
		RECT rcMon;
		MONITORINFO mi;
		mi.cbSize = sizeof(mi);

		GetMonitorInfo(MonitorFromPoint(relPt, MONITOR_DEFAULTTONEAREST), &mi);
		rcMon = mi.rcMonitor;
		if (relPt.x < rcMon.left)
			relPt.x = rcMon.left;
		else if (relPt.x > rcMon.right)
			relPt.x = rcMon.right;
		if (relPt.y < rcMon.top)
			relPt.y = rcMon.top;
		else if (relPt.y > rcMon.bottom)
			relPt.y = rcMon.bottom;
	}
	return relPt;
}


//---------------------------------------------------------
// Message handling
//---------------------------------------------------------

void Shortcut::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onMouseMove, WM_MOUSEMOVE)
	MESSAGE(onMouseActivate, WM_MOUSEACTIVATE)
	MESSAGE(onTimer, WM_TIMER)
	MESSAGE(onLButtonDown, WM_LBUTTONDOWN)
	MESSAGE(onLButtonUp, WM_LBUTTONUP)
	MESSAGE(onDropFiles, WM_DROPFILES)
	MESSAGE(onEraseBkgnd, WM_ERASEBKGND)
	MESSAGE(onDisplayChange, WM_DISPLAYCHANGE)
	MESSAGE(onShowWindow, WM_SHOWWINDOW)
	END_MESSAGEPROC
}


void Shortcut::onCreate(Message& message)
{
	DragAcceptFiles(hWnd, true);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
	setImage(fRINormal);
	if (fCaption && fShowCaption)
		fOwner->addHint(hWnd, fCaption);
}


void Shortcut::onDestroy(Message& message)
{
	if (fLeaveTimer)
		KillTimer(hWnd, fLeaveTimer);
	fLeaveTimer = 0;
	fOwner->removeHint(hWnd);
}


void Shortcut::onEndSession(Message& message)
{
	message.lResult = SendMessage(GetLitestepWnd(), message.uMsg, message.wParam, message.lParam);
}


void Shortcut::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(GetLitestepWnd(), WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Shortcut::onMouseMove(Message& message)
{
	if (!fLeaveTimer)
		fLeaveTimer = SetTimer(hWnd, LEAVE_TIMER_ID, 20, NULL);

	if (fState != ssNormal)
		return ;

	fState = ssHover;
	setImage(fRIHover);

	if (fHoverSound)
		PlaySound(fHoverSound, NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT);

	fOwner->relayHintMessage(hWnd, message);
}


void Shortcut::onMouseActivate(Message& message)
{
	PostMessage(hWnd, WM_LBUTTONDOWN, 0, 0);
	message.lResult = MA_ACTIVATE;
}


void Shortcut::onTimer(Message& message)
{
	if (message.wParam != LEAVE_TIMER_ID)
		return ;

	POINT cursorPos;
	bool isWithin;

	GetCursorPos(&cursorPos);
	cursorPos.x -= fRelOrigin.x;
	cursorPos.y -= fRelOrigin.y;

	if (fIsOpaque)
	{
		RECT clientRect;

		GetClientRect(hWnd, &clientRect);
		isWithin = PtInRect(&clientRect, cursorPos) != FALSE;
	}
	else
	{
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);

		GetWindowRgn(hWnd, windowRgn);
		isWithin = PtInRegion(windowRgn, cursorPos.x, cursorPos.y) != FALSE;
		DeleteObject(windowRgn);
	}

	if (!isWithin)
	{
		if (fState != ssNormal)
		{
			fState = ssNormal;
			setImage(fRINormal);
		}
		KillTimer(hWnd, fLeaveTimer);
		fLeaveTimer = 0;
	}
}


void Shortcut::onLButtonDown(Message& message)
{
	if (fState == ssClick)
		return ;

	fState = ssClick;

	setImage(fRIClick);
}


void Shortcut::onLButtonUp(Message& message)
{
	char buffer[MAX_LINE_LENGTH];

	if (fState != ssClick)
		return ;

	fState = ssNormal;
	setImage((fRIHover.image ? fRIHover : fRINormal));

	if (fClickSound)
		PlaySound(fClickSound, NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT);

	if (fCommand)
	{
		if (fCommandArgs)
			sprintf(buffer, "[%s] %s", fCommand, fCommandArgs);
		else
			sprintf(buffer, "[%s]", fCommand);
		LSExecute(hWnd, buffer, SW_SHOWDEFAULT);
	}
}


void Shortcut::onDropFiles(Message& message)
{
	LPSTR commandLine, iter;
	UINT fileCount = DragQueryFile(HDROP(message.wParam), ~0, NULL, 0);
	size_t totalLength = StrLen(fCommand) + 3;
	UINT i;

	if (!fileCount)
		return ;

	if (fClickSound)
		PlaySound(fClickSound, NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT);

	for (i = 0; i < fileCount; i++)
	{
		totalLength += DragQueryFile(HDROP(message.wParam), i, NULL, 0) + 3;
	}

	commandLine = new char[totalLength];
	sprintf(commandLine, "[%s]", fCommand);
	iter = commandLine + StrLen(commandLine);

	for (i = 0; i < fileCount; i++)
	{
		strcpy(iter, " \"");
		iter += StrLen(iter);
		iter += DragQueryFile(HDROP(message.wParam), i, iter,
		                      totalLength - (iter - commandLine));
		*iter = '\"';
		iter++;
		*iter = '\0';
	}

	LSExecute(hWnd, commandLine, SW_SHOWDEFAULT);
	delete[] commandLine;
}


void Shortcut::onEraseBkgnd(Message& message)
{
	HDC hDC = (HDC)message.wParam;
	HBITMAP oldImage;

	if (!fRICurrent)
		return ;
	if (!fPaintDC)
		fPaintDC = CreateCompatibleDC(hDC);
	oldImage = HBITMAP(SelectObject(fPaintDC, fRICurrent->image));
	BitBlt(hDC, 0, 0, fWidth, fHeight, fPaintDC, 0, 0, SRCCOPY);
	SelectObject(fPaintDC, oldImage);
}


void Shortcut::onDisplayChange(Message& message)
{
	fRelOrigin = convertCoords(fLeft, fTop);
	SetWindowPos(hWnd, HWND_TOP, fRelOrigin.x, fRelOrigin.y, 0, 0,
	             SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}


void Shortcut::onShowWindow(Message& message)
{
	if (message.wParam)
		setImage(fRINormal);
}
