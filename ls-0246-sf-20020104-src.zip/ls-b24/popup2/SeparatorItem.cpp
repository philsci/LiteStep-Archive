/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "SeparatorItem.h"
#include "PopupMenu.h"

SeparatorItem::SeparatorItem()
{
	m_nSortPriority = -10;
	m_bDecoration = TRUE;
	SetHeight(4);
}

SeparatorItem::SeparatorItem(BOOL bDecoration)
{
	m_nSortPriority = -10;
	m_bDecoration = bDecoration;
	SetHeight(4);
}

SeparatorItem::~SeparatorItem()
{
}

void SeparatorItem::Paint(HDC hDC)
{
	HPEN hPen;
	HPEN hOldPen;

	MenuItem::Paint(hDC);

	if (m_bDecoration)
	{
		hPen = CreatePen(PS_SOLID, 1, m_nDarkColor);
		hOldPen = (HPEN) SelectObject(hDC, hPen);

		MoveToEx(hDC, 2, m_nTop + GetHeight() / 2, NULL);
		LineTo(hDC, GetWidth() - 2, m_nTop + GetHeight() / 2);

		DeleteObject(hPen);
		hPen = CreatePen(PS_SOLID, 1, m_nLightColor);
		SelectObject(hDC, hPen);

		MoveToEx(hDC, 2, m_nTop + GetHeight() / 2 + 1, NULL);
		LineTo(hDC, GetWidth() - 2, m_nTop + GetHeight() / 2 + 1);

		SelectObject(hDC, hOldPen);
		DeleteObject(hPen);
	}
}

/*LRESULT SeparatorItem::NcHitTest(int x, int y)
{
	if(IsOver(x, y))
	{
		// since i will tell window that i am a caption, window will not
		// send me any WM_MOUSEMOVE messages .. sigh .. so i send it my
		// self, this is important for tracking the activa menu item.
		PostMessage(GetWindow(), WM_MOUSEMOVE, MAKEWORD(x,y), 0);
 
		// tell window that i am a caption so the user can drag the popup
		// around ... what fun!
		return HTCAPTION;
	}
	return 0;
}*/
