/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
/****************************************************************************

 06/02/98 - F. Gastellu
            This file contains the source code for the XMouse module

 To do: fix dropdown listboxes

****************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "xmouse.h"

char szAppName[] = "xMouse";

LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT HookFunction(int code, WPARAM wParam, LPARAM lParam);

HINSTANCE dllInstance;
long oldWindowProc;
HWND watchedWnd;
BOOL inTimer=FALSE;
HHOOK hSystemHook;
UINT timerId=0;
ATOM semaphore;

BOOL BringToTop=TRUE;
int timeOut = 500;

HWND hMainWnd=NULL;

// -------------------------------------------------------------------------------------------------------
// Module init
// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
timeOut = wd->xmouseDelay;
BringToTop = wd->xmouseBringToTop;

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.lpfnWndProc = WindowProc;			// our window procedure
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(ParentWnd,"Error registering window class",szAppName,MB_OK);
			return 1;
		}
		
		hMainWnd = CreateWindowEx(0, szAppName, "", 0,
		                          0, 0, 0, 0, NULL, NULL, dllInst, NULL); 

		if (!hMainWnd)
			{
			UnregisterClass(szAppName, dllInst);
			MessageBox(ParentWnd,"Error creating dialog window",szAppName,MB_OK);
			return 1;
			}
	}


dllInstance = dllInst;
// Hook every threads for mouse events
// This cause a lot of instances of this DLL to be mapped in the process'
// memory space, but worst, it cause other instances to loose variables
// modifications (the DLL is just as if it was just loaded). So every instance
// Will have to load the setup data by sending messages to the main xmouse
// window (which is invisible and whose only purpose is to act as a 'setup server'
hSystemHook = SetWindowsHookEx(WH_MOUSE, (TIMERPROC)HookFunction, dllInstance, 0);
return 0;
}

// -------------------------------------------------------------------------------------------------------
// Wait function
// -------------------------------------------------------------------------------------------------------
void Wait(int n)
{
int deb = clock();
while (clock() < deb + n);
}

// -------------------------------------------------------------------------------------------------------
// Cleanup module
// -------------------------------------------------------------------------------------------------------
void quitModule(HINSTANCE dllInst)
{
ATOM end;
//char txt[20];
//int i;
end = GlobalAddAtom("XMOUSEEND");
UnhookWindowsHookEx(hSystemHook);

if (inTimer)
	{
	inTimer = FALSE;
	KillTimer(NULL, timerId);
	GlobalDeleteAtom(semaphore);
	}

Wait(timeOut+500);

GlobalDeleteAtom(end);
CoFreeUnusedLibraries();
DestroyWindow(hMainWnd);
UnregisterClass(szAppName, dllInst);
}

// -----------------------------------------------------------------------------------------------
// Find root window from any child window (parent's owner...)
// -----------------------------------------------------------------------------------------------
HWND RootWnd(HWND hwnd)
{
while (GetParent(hwnd))
	hwnd = GetParent(hwnd);
while (GetWindow(hwnd, GW_OWNER))
	hwnd = GetWindow(hwnd, GW_OWNER);
hwnd = GetLastActivePopup(hwnd);
return hwnd;
}

// -----------------------------------------------------------------------------------------------
// Our replacement window procedure
// This allows avoiding change in Zorder. First we subclass the window to
// give focus to, then we give it focus. Our window procedure stops windows
// from changing the zorder, then we can unsubclass the window.
// -----------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
if (message == WM_WINDOWPOSCHANGING)
        { 
	WINDOWPOS *lpwp = (WINDOWPOS*)lParam;
	lpwp->flags |= SWP_NOZORDER;
	return 0;
	}
return CallWindowProc((WNDPROC)oldWindowProc, hwnd, message, wParam, lParam);
}

// -------------------------------------------------------------------------------------------------------
// Our timer procedure
// -------------------------------------------------------------------------------------------------------
VOID CALLBACK TimerProc(HWND hwndRef, UINT uMsg, UINT idEvent, DWORD dwTime)
{
POINT pt;
HWND hwnd;
	
GetCursorPos(&pt);
hwnd = RootWnd(WindowFromPoint(pt));

KillTimer(NULL, timerId);

if (hwnd == watchedWnd)
	{
	if (!BringToTop)
		{
		oldWindowProc = (long)GetWindowLong(hwnd, GWL_WNDPROC);
		SetWindowLong(hwnd, GWL_WNDPROC, (long)WndProc);
		}
	SetForegroundWindow(hwnd);
	if (!BringToTop)
		SetWindowLong(hwnd, GWL_WNDPROC, oldWindowProc);
	}

//GlobalDeleteAtom(semaphore);
inTimer = FALSE;
}

// -----------------------------------------------------------------------------------------------
// Hook function
// -----------------------------------------------------------------------------------------------
LRESULT HookFunction(int code, WPARAM wParam, LPARAM lParam)
{
if (code >= 0 && !inTimer)
	{
	HWND hwnd;
	if (!hMainWnd)
		{
		hMainWnd = FindWindow(szAppName, NULL);
		timeOut = SendMessage(hMainWnd, 9198, 0, 0);
		BringToTop = SendMessage(hMainWnd, 9199, 0, 0);
		}
	hwnd = RootWnd(((MOUSEHOOKSTRUCT *)lParam)->hwnd);
	if (hwnd != RootWnd(GetForegroundWindow()))
		{
		if (!GlobalFindAtom("XMOUSEEND"))
			{
			timerId = SetTimer(NULL, 0, timeOut, (TIMERPROC)TimerProc);
			inTimer = TRUE;
			watchedWnd = hwnd;
			}
		}
	}

return CallNextHookEx(NULL, code, wParam, lParam);
}

// -----------------------------------------------------------------------------------------------
// The main window procedure. Every instance of the DLL will ask the main
// window for setup informations.
// -----------------------------------------------------------------------------------------------
LRESULT CALLBACK WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
if (message == 9198)
	return timeOut;
if (message == 9199)
	return BringToTop;
return DefWindowProc(hwnd, message, wParam, lParam);
}

