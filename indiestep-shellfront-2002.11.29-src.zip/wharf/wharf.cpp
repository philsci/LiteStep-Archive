/*

This is a part of the LiteStep Shell Source code.
 
Copyright (C) 1997-98 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
	
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
	  
*/

/****************************************************************************
06/15/02 - Erik Christiansson (Sci)
  - Moved !ToggleWharf from the LS core to this module
10/29/00 - Joachim Calvert (NeXTer)
  - After inceasant pestering by DeViLbOi, WharfAlwaysOnTop now defaults to
    false
10/03/00 - Joachim Calvert (NeXTer)
  - Fixed the sound handling, thanks to DeViLbOi for pointing it out
08/31/00 - Joachim Calvert (NeXTer)
  - Altered the WM_POPUP message to pass both mouse coords in lParam
08/26/00 - Joachim Calvert (NeXTer)
  - Added the setting WharfAlwaysOnTop
08/25/00 - Charles Oliver Nutter (Headius)
  Rewrote the wharf types to be classes, subwharfType extends wharfType
	Moved painting code into wharf type classes
	Restructured paint handling to call class methods
	Fixed the immovable wharf bug
	Fixed (re-implemented) the right-click popup
07/21/00 - Bobby G. Vinyard (Message)
  Add LM_REGISTER/UNREGISTER message handler. (Using LSWinbase, hParent was 
    being set to the hwnd of the wharf and not LiteStep its self, therefore
    the LM_REGISTER msgs were being sent to the wharf, the wharf no fowards
    these msgs to LiteStep's _tmain exe)
04/16/00 - Joachim Calvert (NeXTer)
  Fixed a bug where the wharf wouldn't hide properly when the following
  settings where used:
    AutoHideWharf
    WharfCloseOnSwitch
    ;WharfNoAnim  (swithed off)
  (Courtesy of Sergey Popov)
  The message handling was radically overhauled to prepare the code for
  a convertion to proper C++ style.
04/12/00 - Joachim Calvert (NeXTer)
  It moves itself on resolution changes.
04/06/00 - Joachim Calvert (NeXTer)
  Now notices changes in screen resolution.
01/17/00 - Charles Nutter (Headius)
  Fixes to _tremove dependency on the great winList array.
  Note: Not thread-safe yet.
11/16/98 - Bug*Killer added by Fahim
  Added facility for popup menu to open when right clicked on wharf
  Divided the title bar in two parts : drag the left one to move the
  bar, click on the right one to shade/unshade the bar. When the wharf
  bar is not shaded, a double click on the left part _putts it in shaded
  mode & then moves it to a special position :
  ScreenWidth - "WharfDblClickXPosition",0. When the wharf bar is
  shaded, a double click on the left part unshades the bar, then docks
  it on the right, or on the left if the "WharfDblClickDockOnLeft"
  step.rc entry is specified.
11/15/98 - cael
  Added checks in SetWorkArea() to not change the work area if
  SetDesktopArea is true
11/03/98 - W. Konkel
  Added the better wharf movement as well as sound to !WharfTasks
11/02/98 - W. Konkel
  Added wharf open/close/min/max sounds (with the help/request
  of snowchyld)
11/01/98 - T. Engel
  Added back WharfTitleFont, WharfTitleFontSize, and a new
  option WharfTitleFontWeight
11/01/98 - W. Konkel
  Added better wharf movement (fixed a few small bugs)
  Made WharfCloseOnSwitch work much much better
10/31/98 - Cyberian
  Fixed crashing on recycle when WharfCloseOnSwitch is enabled
10/29/98 - Cyberian (Fahim Farook)
  Added WharfCloseOnSwitch to step.rc so that you can have the
  subwharf folders auto-close when focus is lost if you desire
  Added support for wharf hints
 
10/10/98 - W. Konkel
  Added snap-to-edge wharf and the ability to not include the
  default.bmp and 3dots.bmp in wharf layer.
10/09/98 - C. Boyda
  Made the trans titlebar much more efficent in speed
 
10/03/98 - J. Vaughn
  Added fully functional, working transparency to the wharf
  titlebar (why was it left out to begin with?? :P)
 
09/03/98 - C. Boyda
  Added fully functional, working transparency to the wharf
  D. Hodgkiss
  Folders support is now in
 
08/31/98 - D. Hodgkiss
  Added ability to move the wharf anywhere on the screen
  Added a titlebar to the wharf
  Added hide/unhide support
 
08/25/98 - D. Hodgkiss
  This file contains the source for the wharf bar
 
****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <malloc.h>
#include <stdio.h>
#include <commctrl.h>
#include "../lsapi/lswinbase.h"
#include "../lsapi/lsapi.h"
#include "wharf.h"
#include "../core/ifcs.h"

// -------------------------------------------------------------------------------------------------------

const LPCSTR szMainWindowClass = "TWharfGlobalContainer";
const LPCSTR szHiddenWindowClass = "LineDownSide";
const char rcsRevision[] = "1.2.1 $"; // Our Version
const char rcsId[] = "wharf.cpp,v 1.2.1 2002/06/15 15:15:00 Sci Exp $"; // The Full RCS ID.


FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

// our window procedures
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK HiddenWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// -------------------------------------------------------------------------------------------------------

void CloseAllFolders();
void ExecuteWharfTasks(int i);
void ExecuteSubWharf(int i, int x);
BOOL CreateSubWharf(int i, int x, LPCSTR);
BOOL CreateWharf(int, LPCSTR);
BOOL PartOfWharf(HWND myWnd);
void ReadConfig(void);
int GetWharfByWnd(HWND hwnd);
void ExecuteWharf(int i);
void SetWorkArea(void);
void togglePressOffset(int i, BOOL bToggle);
void ShowWharf(void);
void HideWharf(void);
void CreateWharfhints(HWND hWnd, char *txt, RECT *r);
void RemoveWharfhints(HWND hWnd);
void SoundOpen(void);
void SoundClose(void);
void SoundMin(void);
void SoundMax(void);
void BangToggleWharf(HWND hCaller, LPCSTR szArgs);

char szLitestepPath[256];
char lsPath[256];
char wharfOpenSound[256];
char wharfCloseSound[256];
char wharfMinSound[256];
char wharfMaxSound[256];

char szImagePath[256];
char szDefPixmap[256];
char szFolderPixmap[256];
HBITMAP titlebarImage = NULL;
HBITMAP defaultBackImage = NULL;
HBITMAP folderImage = NULL;
HBITMAP defaultFolderImage = NULL;
HINSTANCE dll;
HWND hMainWnd;
HWND HiddenWnd;
HWND parent;
HWND oldCapt = NULL;
HWND wharfHints = NULL;
HRGN hMainRgn;
int ScreenWidth, ScreenHeight, wharfTileSize;
int wharfBaseX = 0, wharfBaseY = 0;
//wharfType *wharfs = NULL;
WharfVector wharfs;
int numWharfs = 0;
int wharfDirection = WHARF_DOWN;
int titleSize;
int wharfShadeButton;
int wharfDblClickXPosition = 120;
BOOL wharfDblClickDockOnLeft = FALSE;
int wharfClosingPos;
int wharfAnimTime;
int wharfDocked = 0;
int wharfStep = 64;
int autoHideDelay = 300;
int autoShowDelay = 300;
int hiddenWidth = 1;
int OpenFolders = 0;
int wharfPressOffset = 1;
BOOL wharfAlwaysOnTop = TRUE;
BOOL wharfClosing = FALSE;
BOOL wharfHide = FALSE;
BOOL wharfTitlebar = TRUE;
BOOL wharfNoAnim = FALSE;
BOOL wharfAutoClose = TRUE;
BOOL wharfTitles = FALSE;
BOOL wharfCloseOnSwitch = FALSE;
BOOL showbg = TRUE;
BOOL snapTo = FALSE;
BOOL wharfAutoHide = FALSE;
BOOL hideTimerActive = FALSE;
BOOL showTimerActive = FALSE;
BOOL wharfHidden = FALSE;
BOOL wharfAutoUnpress = FALSE;
BOOL wharfNoHints = TRUE;
int snapToSensitivity = 16;
int bevelWidth;
int capHeight;
COLORREF titleFore, titleBack;
char szTitleFont[256] = "Arial";
int iTitleFontSize = 8, iTitleFontWeight = 400;
BOOL setDesktopArea = TRUE;
BOOL isFirst = TRUE;

// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	UINT Msgs[10];
	RECT r;
	int i;
	HWND desktop;

	dll = dllInst;

	GetClientRect(GetDesktopWindow(), &r);
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

	parent = GetLitestepWnd();

	strcpy(szLitestepPath, szPath);
	ReadConfig();
	if (!wharfNoHints)
	{
		wharfHints = CreateWindow
		             (TOOLTIPS_CLASS,
		              "LSWharfHints",
		              TTS_ALWAYSTIP,
		              CW_USEDEFAULT,
		              CW_USEDEFAULT,
		              CW_USEDEFAULT,
		              CW_USEDEFAULT,
		              NULL,
		              (HMENU) NULL,
		              dll,
		              NULL
		             );
		if (!wharfHints)
		{
			MessageBox(parent, "Error creating hints window", "Wharf Hints Error", MB_OK | MB_TOPMOST);
			return 1;
		}
		SetWindowPos(wharfHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
	}

	if (wharfTitlebar)
		titleSize = capHeight;
	else
		titleSize = 0;

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc, 0, sizeof(wc));
		wc.lpfnWndProc = MainWndProc;				  // our window procedure
		wc.hInstance = dllInst; 				// hInstance of DLL
		wc.lpszClassName = szMainWindowClass;	   // our window class name
		wc.style = CS_DBLCLKS;

		if (!RegisterClass(&wc))
		{
			MessageBox(parent, "Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}

		if (wharfAutoHide)
		{
			WNDCLASS wc;
			memset(&wc, 0, sizeof(wc));
			wc.lpfnWndProc = HiddenWndProc;				  // our window procedure
			wc.hInstance = dllInst; 				// hInstance of DLL
			wc.lpszClassName = szHiddenWindowClass;	   // our window class name
			wc.style = 0;

			if (!RegisterClass(&wc))
			{
				MessageBox(parent, "Error registering window class", "Wharf", MB_OK | MB_TOPMOST);
				return 1;
			}
		}



	}
	desktop = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktop)
		desktop = GetDesktopWindow();
	hMainWnd = CreateWindowEx(
	               WS_EX_TOOLWINDOW | (wharfAlwaysOnTop ? WS_EX_TOPMOST : 0),
	               szMainWindowClass,
	               "LSWharf",
	               WS_CLIPCHILDREN | WS_POPUP,
	               wharfBaseX,
	               wharfBaseY,
	               0,
	               0,
	               desktop,
	               NULL,
	               dllInst,
	               NULL
	           );

	if (!hMainWnd)
	{
		MessageBox(parent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
		return 1;
	}


	SetWindowLong (hMainWnd, GWL_USERDATA, magicDWord);

	if (wharfAutoHide)
	{
		HiddenWnd = CreateWindowEx(
		                WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
		                szHiddenWindowClass,
		                "LSWharfHidden",
		                WS_POPUP,
		                (wharfBaseX == 0) ? 0 : wharfBaseX + wharfTileSize - hiddenWidth,
		                wharfBaseY,
		                hiddenWidth,
		                ScreenHeight,
		                parent,
		                NULL,
		                dllInst,
		                NULL
		            );

		if (!HiddenWnd)
		{
			MessageBox(parent, "Error creating wharf", "Wharf", MB_OK | MB_TOPMOST);
			return 1;
		}


		SetWindowLong (HiddenWnd, GWL_USERDATA, magicDWord);
	}


	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

	{
		FILE *f;

		f = LCOpen (NULL);
		if (f)
		{
			char	buffer[4096];
			char	token1[4096], token2[4096], token3[4096], token4[4096], extra_text[4096];
			char*	tokens[4];
			BOOL	inFolder = FALSE;

			tokens[0] = token1;
			tokens[1] = token2;
			tokens[2] = token3;
			tokens[3] = token4;

			buffer[0] = 0;

			while (LCReadNextConfig (f, "*Wharf", buffer, sizeof (buffer)))
			{
				int count;

				token1[0] = token2[0] = token3[0] = token4[0] = extra_text[0] = '\0';

				count = LCTokenize (buffer, tokens, 4, extra_text);

				switch (count)
				{
					case 2:
					if (!strcmpi(token2, "~Folder"))
					{
						inFolder = FALSE;
						numWharfs++;
						break;
					}
					case 4:
					{
						// token 1 is "*Wharf", token 2 is the name, token 3 is the
						// graphic, token 4 is the executable, and the extra_text are
						// the program arguments.
						char windowName[256];

						windowName[0] = '\0';

						if ((token4[0] == '%') && (strrchr(token4, '%') == token4))
						{
							char szTempToken[4096];
							char*	tokens2[5];
							tokens2[0] = token1;
							tokens2[1] = token2;
							tokens2[2] = token3;
							tokens2[3] = szTempToken;
							tokens2[4] = token4;


							strcpy (windowName, token4 + 1);

							extra_text[0] = token4[0] = '\0';
						}

						if (inFolder)
						{
							char szTT[1024];
							int w = numWharfs;
							int x = wharfs[w]->numSubwharfs;

							/*if (!wharfs[w]->subwharfs)
						{
								wharfs[w]->subwharfs = (subwharfType *)malloc(sizeof(subwharfType));
						}
							else
						{
								wharfs[w]->subwharfs = (subwharfType *)realloc(wharfs[w]->subwharfs, (x+1)*sizeof(subwharfType));
						}*/
							wharfs[w]->subwharfs.push_back(new subwharfType(wharfs[w]));
							//memset(wharfs[w]->subwharfs[x], 0, sizeof(subwharfType));

							if (token3[0] == '*')
							{
								char *temptoken3;
								temptoken3 = token3;
								if (*temptoken3 == '*')
									temptoken3++;
								strcpy(token3, temptoken3);
								wharfs[numWharfs]->subwharfs[x]->showbg = FALSE;
							}
							else
							{
								wharfs[numWharfs]->subwharfs[x]->showbg = TRUE;
							}

							strcpy (wharfs[w]->subwharfs[x]->szName, token2);
							strcpy (wharfs[w]->subwharfs[x]->szCommand, token4);
							strcpy (wharfs[w]->subwharfs[x]->szParameters, extra_text);
							strcpy (szTT, token4);
							if (strnicmp(".extract", token3, 8) && extra_text && strlen(extra_text))
							{
								//								MessageBox(0, extra_text, "Got Here", MB_OK|MB_TOPMOST);
								strcat (szTT, " ");
								strcat (szTT, extra_text);
							}

							wharfs[w]->subwharfs[x]->frontImage = LoadLSImage (token3, szTT);

							CreateSubWharf(numWharfs, wharfs[w]->numSubwharfs, windowName);
							wharfs[w]->numSubwharfs++;
						}
						else
						{
							//char *szTemp;
							char szTT[1024];

							/*if (!wharfs)
						{
								wharfs = (wharfType *)malloc(sizeof(wharfType));
						}
							else
						{
								wharfs = (wharfType *)realloc(wharfs, (numWharfs+1)*sizeof(wharfType));
						}*/
							wharfs.push_back(new wharfType);
							//memset(wharfs[numWharfs], 0, sizeof(wharfType));

							if (token3[0] == '*')
							{
								char *temptoken3;
								temptoken3 = token3;
								if (*temptoken3 == '*')
									temptoken3++;
								strcpy(token3, temptoken3);
								wharfs[numWharfs]->showbg = FALSE;
							}
							else
							{
								wharfs[numWharfs]->showbg = TRUE;
							}

							strcpy(wharfs[numWharfs]->szName, token2);
							strcpy(wharfs[numWharfs]->szCommand, token4);
							strcpy(wharfs[numWharfs]->szParameters, extra_text);

							if (!strcmpi (token4, "Folder"))
							{
								strcpy(szTT, token2);
							}
							else
							{
								strcpy(szTT, token4);
								if (strnicmp(".extract", token3, 8) && extra_text && strlen(extra_text))
								{
									strcat (szTT, " ");
									strcat (szTT, extra_text);
								}
							}
							wharfs[numWharfs]->frontImage = LoadLSImage(token3, szTT);

							CreateWharf(numWharfs, windowName);

							if (!strcmpi(token4, "Folder"))
							{
								inFolder = TRUE;
								wharfs[numWharfs]->subwharfs.clear();
								wharfs[numWharfs]->numSubwharfs = 0;
								wharfs[numWharfs]->subwharfOpen = FALSE;
								wharfs[numWharfs]->bPressed = FALSE;
								wharfs[numWharfs]->bTogglePressed = FALSE;
								wharfs[numWharfs]->hsubwharfWnd = CreateWindowEx(
								                                      WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
								                                      szMainWindowClass,
								                                      "LSWharflet",
								                                      WS_CLIPCHILDREN | WS_POPUP,
								                                      0, 0,
								                                      0, 0,
								                                      parent,
								                                      NULL,
								                                      dll,
								                                      NULL
								                                  );

								SetWindowLong(wharfs[numWharfs]->hsubwharfWnd, GWL_USERDATA, magicDWord);
								ShowWindow(wharfs[numWharfs]->hsubwharfWnd, SW_SHOWNORMAL);
							}
							else
							{
								numWharfs++;
							}
						}
					}
				}
			}
			LCClose(f);
		}
	}

	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = LM_GETREVID;
	Msgs[2] = 0;
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	/* transparent titlebar */
	if (wharfTitlebar && titlebarImage)
	{
		HRGN hClipRgn, hTitlebarRgn;

		hClipRgn = CreateRectRgn(0, 0, wharfTileSize, capHeight);
		hTitlebarRgn = BitmapToRegion(titlebarImage, RGB(255, 0, 255), 0x101010, 0, 0);

		if (hMainRgn)
		{
			CombineRgn(hTitlebarRgn, hClipRgn, hTitlebarRgn, RGN_DIFF);
			CombineRgn(hMainRgn, hMainRgn, hTitlebarRgn, RGN_DIFF);
		}

		DeleteObject(hClipRgn);
		DeleteObject(hTitlebarRgn);
	}

	/* set our region for hMainWnd now, this sets the wharf into our transparency mode     */
	/* after we compiled the full region for the parent window of the child, tile, windows */
	/* C. Boyda                                                                            */

	SetWindowRgn(hMainWnd, hMainRgn, TRUE);
	hMainRgn = NULL;

	for (i = 0; i < numWharfs; i++)
	{
		if (wharfs[i]->hsubwharfWnd)
		{
			SetWindowRgn(wharfs[i]->hsubwharfWnd, wharfs[i]->subRgn, TRUE);
			wharfs[i]->subRgn = NULL;
		}
	}

	ShowWindow(hMainWnd, SW_SHOWNORMAL);


	// If we are autohiding, set the autohide delay.
	if (wharfAutoHide)
	{
		RECT r;
		GetClientRect(hMainWnd, &r);

		SetWindowPos(HiddenWnd, 0, 0, 0, hiddenWidth, r.bottom - r.top, SWP_NOZORDER | SWP_NOMOVE);

		SetTimer(HiddenWnd, 1, 50, NULL);
	}
	SetWorkArea();
	isFirst = FALSE;

	AddBangCommand("!ToggleWharf", BangToggleWharf);
	
	return 0;
}

// -------------------------------------------------------------------------------------------------------

void HiddenWnd_EndSession(Message& message)
{
	message.lResult = SendMessage(parent, message.uMsg, message.wParam, message.lParam);
}


void HiddenWnd_SysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(parent, WM_KEYDOWN, LM_SHUTDOWN, 0);
}


void HiddenWnd_DisplayChange(Message& message)
{
	bool WasDocked = (wharfBaseX + wharfTileSize) == ScreenWidth;
	int RelativeX = ScreenWidth - wharfBaseX;
	bool MoveRelative = RelativeX > (ScreenWidth / 2);
	CloseAllFolders();
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	if (WasDocked)
		wharfBaseX = ScreenWidth - wharfTileSize;
	else if (MoveRelative)
		wharfBaseX = ScreenWidth - RelativeX;
	SetWindowPos(hMainWnd, HWND_TOPMOST, wharfBaseX, wharfBaseY, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}


void HiddenWnd_Paint(Message& message)
{
	PAINTSTRUCT ps;
	RECT r;
	HDC hdc = BeginPaint(HiddenWnd, &ps);
	HBRUSH hb = CreateSolidBrush(0xFFFFFF);

	GetClientRect(HiddenWnd, &r);
	r.right += 1;
	r.bottom += 1;

	FillRect(hdc, &r, hb);

	DeleteObject(hb);
	EndPaint(HiddenWnd, &ps);
}


void HiddenWnd_Timer(Message& message)
{
	if (wharfDocked)
	{
		switch (message.wParam)
		{
			case 0:
			if (wharfAutoHide)
				HideWharf();
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
			break;
			case 1:
			if (wharfAutoHide && !wharfHidden && !hideTimerActive)
			{
				POINT pt;
				RECT r;
				GetCursorPos(&pt);
				GetWindowRect(hMainWnd, &r);
				if ((pt.x < r.left || pt.x > r.right || pt.y < r.top || pt.y > r.bottom) &&
				        (wharfNoAnim || wharfCloseOnSwitch ? TRUE : !OpenFolders))
				{
					SetTimer(HiddenWnd, 0, autoHideDelay, NULL);
					hideTimerActive = TRUE;
				}
			}
			else
			{
				if (wharfAutoHide && wharfHidden && !showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if (pt.x >= r.left && pt.x <= r.right && pt.y >= r.top && pt.y <= r.bottom)
					{
						SetTimer(HiddenWnd, 2, autoShowDelay, NULL);
						showTimerActive = TRUE;
					}

				}
				else if (wharfHidden && showTimerActive)
				{
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(HiddenWnd, &r);
					if (pt.x < r.left || pt.x > r.right || pt.y < r.top || pt.y > r.bottom)
					{
						KillTimer(HiddenWnd, 2);
						showTimerActive = FALSE;
					}
				}
			}
			break;
			case 2:
			if (wharfAutoHide)
				ShowWharf();
			KillTimer(HiddenWnd, 2);
			showTimerActive = FALSE;
			break;

		}
	}
	else
	{
		if (hideTimerActive)
		{
			KillTimer(HiddenWnd, 0);
			hideTimerActive = FALSE;
		}
	}
}


LRESULT CALLBACK HiddenWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch (uMsg)
	{
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
		HiddenWnd_EndSession(message);
		break;
		case WM_SYSCOMMAND:
		HiddenWnd_SysCommand(message);
		break;
		case WM_DISPLAYCHANGE:
		HiddenWnd_DisplayChange(message);
		break;
		case WM_PAINT:
		HiddenWnd_Paint(message);
		break;
		case WM_TIMER:
		HiddenWnd_Timer(message);
		break;
		default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}


void MainWnd_GetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);

	switch (message.wParam)
	{
		case 0:
		strcpy(buf, "wharf.dll: ");
		strcat(buf, &rcsRevision[0]);
		buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
		strcpy(buf, &rcsId[0]);
		buf[strlen(buf) - 1] = '\0';
		break;
		default:
		strcpy(buf, "");
	}
}


void MainWnd_EndSession(Message& message)
{
	message.lResult = SendMessage(parent, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_SysCommand(HWND hWnd, Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(parent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_Recycle(Message& message)
{
	SendMessage(parent, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_ShadeToggle(Message& message)
{
	if (wharfClosing)
		return ;
	CloseAllFolders();
	if (!wharfHide)
	{
		if (wharfMinSound[0])
			SoundMin();
		if (wharfNoAnim)
		{
			SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, wharfTileSize, titleSize, SWP_NOZORDER);
			wharfHide = TRUE;
			return ;
		}
		wharfClosing = TRUE;
		wharfClosingPos = (numWharfs * wharfTileSize) + titleSize;
		SetTimer(hMainWnd, 1, wharfAnimTime, NULL);
	}
	else
	{
		if (wharfMaxSound[0])
			SoundMax();
		if (wharfNoAnim)
		{
			SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, wharfTileSize, (numWharfs*wharfTileSize) + titleSize, SWP_NOZORDER);
			wharfHide = FALSE;
			return ;
		}
		wharfClosing = TRUE;
		wharfClosingPos = titleSize;
		SetTimer(hMainWnd, 0, wharfAnimTime, NULL);
	}
}


void MainWnd_Timer(HWND hWnd, Message& message)
{
	if (wharfClosing && message.wParam == 0)
	{
		wharfClosingPos += wharfStep;
		SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, wharfTileSize, wharfClosingPos, SWP_NOZORDER);
		if (wharfClosingPos >= (numWharfs*wharfTileSize) + titleSize)
		{
			wharfHide = FALSE;
			wharfClosing = FALSE;
			KillTimer(hMainWnd, 0);
		}
	}
	if (wharfClosing && message.wParam == 1)
	{
		if (wharfClosingPos - wharfStep <= titleSize )
			wharfClosingPos = titleSize;
		else
			wharfClosingPos -= wharfStep;
		//			wharfClosingPos -= wharfStep;
		SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, wharfTileSize, wharfClosingPos, SWP_NOZORDER);
		if (wharfClosingPos <= titleSize)
		{
			wharfHide = TRUE;
			wharfClosing = FALSE;
			KillTimer(hMainWnd, 1);
		}
	}
	if (message.wParam == 2)   //sub wharf opening
	{
		int x, i = -1;

		for (x = 0; x < numWharfs; x++)
		{
			if (wharfs[x]->hsubwharfWnd == hWnd)
			{
				i = x;
				break;
			}
		}
		if (i != -1) // subwharf positions
		{
			if (wharfs[i]->closing)
			{
				KillTimer(wharfs[i]->hsubwharfWnd, 2);
				SetTimer(wharfs[i]->hsubwharfWnd, 3, wharfAnimTime, NULL);
			}
			else
			{
				if (wharfs[i]->movingPos + wharfStep >= wharfs[i]->numSubwharfs*wharfTileSize)
					wharfs[i]->movingPos = wharfs[i]->numSubwharfs * wharfTileSize;
				else
					wharfs[i]->movingPos += wharfStep;
				//				wharfs[i]->movingPos += wharfStep;

				/*				togglePressOffset(i, TRUE);
				wharfs[i]->bPressed = TRUE;
				*/				
				KillTimer(wharfs[i]->hWnd,  4);

				if ((wharfBaseX + (wharfTileSize / 2)) > ScreenWidth / 2)
				{
					SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX - wharfs[i]->movingPos, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->movingPos, wharfTileSize, SWP_NOZORDER);
					if (wharfs[i]->movingPos >= wharfs[i]->numSubwharfs*wharfTileSize)
					{
						wharfs[i]->subwharfOpen = TRUE;
						wharfs[i]->moving = FALSE;
						wharfs[i]->closing = TRUE;
						KillTimer(wharfs[i]->hsubwharfWnd, 2);
					}
				}
				else
				{
					SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX + wharfTileSize, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->movingPos, wharfTileSize, SWP_NOZORDER);
					if (wharfs[i]->movingPos >= wharfs[i]->numSubwharfs*wharfTileSize)
					{
						wharfs[i]->subwharfOpen = TRUE;
						wharfs[i]->moving = FALSE;
						wharfs[i]->closing = TRUE;
						KillTimer(wharfs[i]->hsubwharfWnd, 2);
					}
				}
			}
		}
	}
	if (message.wParam == 3)  // sub wharf closing
	{
		for (int i = 0; i < numWharfs; i++)
		{
			if (wharfs[i]->hsubwharfWnd == hWnd)
			{
				if (!wharfs[i]->closing)
				{
					KillTimer(wharfs[i]->hsubwharfWnd, 3);
					SetTimer(wharfs[i]->hsubwharfWnd, 2, wharfAnimTime, NULL);
				}
				else
				{

					wharfs[i]->movingPos -= wharfStep;

					//					wharfs[i]->bPressed = FALSE;
					//					togglePressOffset(i, FALSE);
					KillTimer(wharfs[i]->hWnd, 4);

					if ((wharfBaseX + (wharfTileSize / 2)) > ScreenWidth / 2)
					{
						SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX - wharfs[i]->movingPos, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->movingPos, wharfTileSize, SWP_NOZORDER);
						if (wharfs[i]->movingPos <= 0)
						{
							wharfs[i]->subwharfOpen = FALSE;
							wharfs[i]->bPressed = FALSE;
							togglePressOffset(i, FALSE);
							wharfs[i]->moving = FALSE;
							wharfs[i]->closing = FALSE;
							KillTimer(wharfs[i]->hsubwharfWnd, 3);
						}
					}
					else
					{
						SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX + wharfTileSize, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->movingPos, wharfTileSize, SWP_NOZORDER);
						if (wharfs[i]->movingPos <= 0)
						{
							wharfs[i]->subwharfOpen = FALSE;
							wharfs[i]->moving = FALSE;
							wharfs[i]->closing = FALSE;
							wharfs[i]->bPressed = FALSE;
							togglePressOffset(i, FALSE);
							KillTimer(wharfs[i]->hsubwharfWnd, 3);
						}
					}
				}
			}
		}
	}
	if (message.wParam == 4)
	{
		for (int i = 0; i < numWharfs; i++)
		{
			POINT pt;
			GetCursorPos(&pt);
			if (wharfs[i]->bPressed && !wharfs[i]->subwharfOpen && !PtInRegion(hMainRgn, pt.x, pt.y))
				togglePressOffset(i, FALSE);
		}

	}
}


void MainWnd_NCLButtonDown(HWND hWnd, Message& message)
{
	if ((int)(message.lParamLo) - wharfBaseX >= wharfShadeButton)
	{
		SendMessage(hWnd, LM_SHADETOGGLE, 0, 0);
	}
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_NCLButtonDblClick(HWND hWnd, Message& message)
{
	if ((hWnd == hMainWnd) && wharfTitlebar)
	{
		if (wharfHide)
		{
			wharfBaseX = wharfDblClickDockOnLeft ? 0 : ScreenWidth - wharfTileSize;
		}
		else
		{
			wharfBaseX = ScreenWidth - wharfDblClickXPosition;
			if (wharfBaseX >= ScreenWidth - wharfTileSize)
				wharfBaseX = ScreenWidth - wharfTileSize;
		}
		wharfBaseY = 0;
		SetWorkArea();
		SendMessage(hWnd, LM_SHADETOGGLE, 0, 0);
	}
}


void MainWnd_WindowPosChanging(HWND hWnd, Message& message)
{
	if ((hWnd == hMainWnd) && wharfTitlebar)
	{
		LPWINDOWPOS lpwp = (LPWINDOWPOS)(message.lParam);

		if (lpwp->y <= 0)
			lpwp->y = 0;
		else if (lpwp->y >= ScreenHeight - capHeight)
			lpwp->y = ScreenHeight - capHeight;

		if (lpwp->x >= ScreenWidth - wharfTileSize)
			lpwp->x = ScreenWidth - wharfTileSize;
		else if (lpwp->x <= 0)
			lpwp->x = 0;

		if (snapTo)
			if (lpwp->y <= snapToSensitivity)
				lpwp->y = 0;

		if (lpwp->x >= ScreenWidth - wharfTileSize - snapToSensitivity)
			lpwp->x = ScreenWidth - wharfTileSize;
		else if (lpwp->x <= snapToSensitivity)
			lpwp->x = 0;

	}
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_NCHitTest(HWND hWnd, Message& message)
{
	if ((hWnd == hMainWnd) && wharfTitlebar)
		message.lResult = HTCAPTION;
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void MainWnd_Move(HWND hWnd, Message& message)
{
	if (hWnd != hMainWnd)
		return ;

	char szIni[256];
	char szBuf[256];

	CloseAllFolders();

	wharfBaseX = message.lParamLo;
	wharfBaseY = message.lParamHi;

	SetWorkArea();

	sprintf(szIni, "%s\\MODULES.INI", szLitestepPath);
	sprintf(szBuf, "%d,%d", wharfBaseX, wharfBaseY);
	WritePrivateProfileString("Wharf", "Position", szBuf, szIni);
}


void MainWnd_DisplayChange(Message& message)
{
	bool WasDocked = (wharfBaseX + wharfTileSize) == ScreenWidth;
	int RelativeX = ScreenWidth - wharfBaseX;
	bool MoveRelative = RelativeX > (ScreenWidth / 2);
	CloseAllFolders();
	ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
	ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	if (WasDocked)
		wharfBaseX = ScreenWidth - wharfTileSize;
	else if (MoveRelative)
		wharfBaseX = ScreenWidth - RelativeX;
	SetWindowPos(hMainWnd, HWND_TOPMOST, wharfBaseX, wharfBaseY, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
}


void MainWnd_Paint(HWND hWnd, Message& message)
{
	HBITMAP oldBMP = NULL;
	int i = GetWharfByWnd(hWnd);
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);
	HDC src = CreateCompatibleDC(hdc);

	if (hWnd == hMainWnd && wharfTitlebar && titlebarImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, titlebarImage);
		BitBlt(hdc, 0, 0, wharfTileSize, titleSize, src, 0, 0, SRCCOPY);
		SelectObject(src, oldBMP);
	}

	// if we are painting a wharf...
	if (i != -1)
	{
		wharfs[i]->Paint(hdc, src);
		/*
		// have a background image?
		  if (wharfs[i]->backImage)
		  {
		    oldBMP = (HBITMAP)SelectObject(src, wharfs[i]->backImage);
			// are we pressed down?
		    if (wharfs[i]->bPressed)
		      TransparentBltLS(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, RGB(255,0,255));
		    else
		      BitBlt(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
		  }
		  if (wharfTitles && !wharfs[i]->hInst) // displaying titles, and not a module?
		  {
		    RECT r;
		    HBRUSH back;
		    HFONT titleFont, oldFont;
		    int nHeight;
		    int len = lstrlen(wharfs[i]->szName);

		    back = CreateSolidBrush(titleBack);
		    GetClientRect(hWnd, &r);
		    //					r.bottom = 10;
		    //					FillRect(hdc, &r, back);
		    nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72);
		    r.bottom = nHeight +2;
		    FillRect(hdc, &r, back);
		    titleFont = CreateFont(
		      nHeight, // 8,
		      0, // 6,
		      0,
		      0,
		      iTitleFontWeight, // 0,
		      FALSE,
		      FALSE,
		      FALSE,
		      ANSI_CHARSET,
		      OUT_DEFAULT_PRECIS,
		      CLIP_DEFAULT_PRECIS,
		      DEFAULT_QUALITY,
		      DEFAULT_PITCH | FF_DONTCARE, // DEFAULT_PITCH,
		      szTitleFont
		    );
		    oldFont = (HFONT)SelectObject(hdc, titleFont);
		    SetBkMode(hdc, TRANSPARENT);
		    SetTextColor(hdc, titleFore);
		    TextOut(hdc, 2, 1, wharfs[i]->szName, len);
		    SelectObject(hdc, oldFont);
		    DeleteObject(titleFont);
		    DeleteObject(back);
		  }
		  if (bevelWidth) // displaying a beveled edge?
		  {
		    RECT r = {0, 0, wharfTileSize, wharfTileSize};
		    Frame3D(hdc, r, RGB(255,255,255), RGB(0,0,0), bevelWidth);
		  }*/
	}
	else
	{
		// not painting a wharf...a subwharf perhaps?
		int x, y;

		for (x = 0; x < numWharfs; x++)
		{
			// subwharfs available?
			if (wharfs[x]->subwharfs.size())
			{
				for (y = 0; y < wharfs[x]->numSubwharfs; y++)
				{
					// painting this subwharf?
					if (hWnd == wharfs[x]->subwharfs[y]->hWnd)
					{
						wharfs[x]->subwharfs[y]->Paint(hdc, src);
						/*if (wharfs[x]->subwharfs[y]->backImage)
					{
						  oldBMP = (HBITMAP)SelectObject(src, wharfs[x]->subwharfs[y]->backImage);
						  BitBlt(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
					}
						if ((wharfTitles && !wharfs[x]->subwharfs[y]->hInst)||(!strcmpi(wharfs[x]->szCommand, "!WharfTasks")))
					{
						  RECT r;
						  HBRUSH back;
						  HFONT titleFont, oldFont;
						  int nHeight;
						  int len = lstrlen(wharfs[x]->subwharfs[y]->szName);

						  back = CreateSolidBrush(titleBack);
						  GetClientRect(hWnd, &r);
						  //	r.bottom = 10;
						  //	FillRect(hdc, &r, back);
						  nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(hdc, LOGPIXELSY), 72);
						  r.bottom = nHeight +2;
						  FillRect(hdc, &r, back);
						  titleFont = CreateFont(
						    nHeight, // 8,
						    0, // 6,
						    0,
						    0,
						    iTitleFontWeight, // 0,
						    FALSE,
						    FALSE,
						    FALSE,
						    ANSI_CHARSET,
						    OUT_DEFAULT_PRECIS,
						    CLIP_DEFAULT_PRECIS,
						    DEFAULT_QUALITY,
						    DEFAULT_PITCH | FF_DONTCARE, // DEFAULT_PITCH,
						    szTitleFont
						  );
						  oldFont = (HFONT)SelectObject(hdc, titleFont);
						  SetBkMode(hdc, TRANSPARENT);
						  SetTextColor(hdc, titleFore);
						  TextOut(hdc, 2, 1, wharfs[x]->subwharfs[y]->szName, len);
						  SelectObject(hdc, oldFont);
						  DeleteObject(titleFont);
						  DeleteObject(back);
					}
						if (bevelWidth)
					{
						  RECT r = { 0, 0, wharfTileSize, wharfTileSize };
						  Frame3D(hdc, r, RGB(255,255,255), RGB(0,0,0), bevelWidth);
					}*/
					}
				}
			}
		}
	}
	EndPaint(hWnd, &ps);
	DeleteDC(src);
}


void MainWnd_LButtonDown(HWND hWnd, Message& message)
{
	int i = GetWharfByWnd(hWnd);

	for (int x = 0; x < numWharfs; x++)
		wharfs[x]->bPressed = FALSE;

	if (i != -1)
	{
		wharfs[i]->bPressed = TRUE;
		togglePressOffset(i, TRUE);
		SetTimer(wharfs[i]->hWnd, 4, 50, NULL);
	}
}


void MainWnd_LButtonUp(HWND hWnd, Message& message)
{
	int i = GetWharfByWnd(hWnd);

	if (i != -1 && wharfs[i]->bPressed)
	{
		//				if (!(!strcmpi(wharfs[i]->szCommand, "Folder") || !strcmpi(wharfs[i]->szCommand, "!WharfTasks")) ||
		//					wharfs[i]->subwharfOpen || wharfAutoUnpress)
		if (wharfAutoUnpress)
		{
			wharfs[i]->bPressed = FALSE;
			togglePressOffset(i, FALSE);
		}

		KillTimer(wharfs[i]->hWnd, 4);
		ExecuteWharf(i);
	}
	else
	{
		for (int x = 0; x < numWharfs; x++)
		{
			if (wharfs[x]->subwharfs.size())
			{
				for (int y = 0; y < wharfs[x]->numSubwharfs; y++)
				{
					if (hWnd == wharfs[x]->subwharfs[y]->hWnd)
					{
						ExecuteSubWharf(x, y);
						if (wharfAutoClose)
							CloseAllFolders();

						return ;
					}
				}
			}
		}
	}
}


void MainWnd_MouseMove(HWND hWnd, Message& message)
{
	MSG TooltipMessage;

	int i = GetWharfByWnd(hWnd);
	if (wharfAutoHide && hideTimerActive)
	{
		KillTimer(HiddenWnd, 0);
		hideTimerActive = FALSE;
	}

	if (!wharfNoHints)
	{
		if (i >= 0)
		{
			TooltipMessage.hwnd = wharfs[i]->hWnd;
			TooltipMessage.message = message.uMsg;
			TooltipMessage.wParam = message.wParam;
			TooltipMessage.lParam = message.lParam;
			SendMessage(wharfHints, TTM_RELAYEVENT, 0, (LPARAM)&TooltipMessage);
			SetWindowPos(wharfHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
		}
	}

	if (message.wParam & MK_LBUTTON)
	{
		for (int x = 0; x < numWharfs; x++)  // could be more efficent?
		{
			if ((x == i) && wharfs[x]->bPressed)
				togglePressOffset(i, TRUE);
			else if (!wharfs[x]->subwharfOpen)
				togglePressOffset(x, FALSE);
		}
	}
}


void MainWnd_Activate(Message& message)
{
	if (!wharfCloseOnSwitch)
		return ;

	if (wharfs.size() && message.wParamLo == WA_INACTIVE)
	{
		if (!PartOfWharf((HWND)(message.lParam)))
			CloseAllFolders();
	}
}


LRESULT CALLBACK MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	Message message;

	message.uMsg = uMsg;
	message.wParam = wParam;
	message.lParam = lParam;
	message.lResult = 0;

	switch (uMsg)
	{
		case LM_GETREVID:
		MainWnd_GetRevId(message);
		break;
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
		MainWnd_EndSession(message);
		break;
		case WM_SYSCOMMAND:
		MainWnd_SysCommand(hWnd, message);
		break;
		case LM_RECYCLE:
		MainWnd_Recycle(message);
		break;
		case LM_SHADETOGGLE:
		MainWnd_ShadeToggle(message);
		break;
		case WM_TIMER:
		MainWnd_Timer(hWnd, message);
		break;
		case WM_NCLBUTTONDOWN:
		MainWnd_NCLButtonDown(hWnd, message);
		break;
		case WM_NCLBUTTONDBLCLK:
		MainWnd_NCLButtonDblClick(hWnd, message);
		break;
		case WM_WINDOWPOSCHANGING:
		MainWnd_WindowPosChanging(hWnd, message);
		break;
		case WM_NCHITTEST:
		MainWnd_NCHitTest(hWnd, message);
		break;
		case WM_MOVE:
		MainWnd_Move(hWnd, message);
		break;
		case WM_CREATE:
		break;
		case WM_ERASEBKGND:
		break;
		case WM_DISPLAYCHANGE:
		MainWnd_DisplayChange(message);
		break;
		case WM_PAINT:
		MainWnd_Paint(hWnd, message);
		break;
		case WM_LBUTTONDOWN:
		MainWnd_LButtonDown(hWnd, message);
		break;
		case WM_LBUTTONUP:
		MainWnd_LButtonUp(hWnd, message);
		break;
		case WM_MOUSEMOVE:
		MainWnd_MouseMove(hWnd, message);
		break;
		case WM_ACTIVATE:
		MainWnd_Activate(message);
		break;
		case WM_RBUTTONDOWN:
		{
			POINT point = {message.lParamLo, message.lParamHi};

			ClientToScreen(hWnd, &point);
			SendMessage(GetLitestepWnd(), LM_POPUP, 0, MAKELPARAM(point.x, point.y));
			break;
		}
		case LM_REGISTERMESSAGE:
		case LM_UNREGISTERMESSAGE:
		SendMessage(GetLitestepWnd(), uMsg, wParam, lParam);
		break;
		default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return message.lResult;
}


BOOL PartOfWharf(HWND myWnd)
{
	int i, j;
	if (myWnd == NULL)
		return FALSE;
	if (hMainWnd == myWnd)
		return TRUE;
	if (HiddenWnd == myWnd)
		return TRUE;
	if (parent == myWnd)
		return TRUE;

	for (i = 0;i < numWharfs;i++)
		if (wharfs[i]->hWnd == myWnd)
			return TRUE;
	for (i = 0;i < numWharfs;i++)
		if (wharfs[i]->hsubwharfWnd == myWnd)
			return TRUE;

	for (i = 0; i < numWharfs; i++)
	{
		for (j = 0; j < wharfs[i]->numSubwharfs; j++)
			if (myWnd == wharfs[i]->subwharfs[j]->hWnd || myWnd == wharfs[i]->subwharfs[j]->taskWnd)
				return TRUE;

	}

	return FALSE;

}

void ShowWharf(void)
{
	ShowWindow(HiddenWnd, SW_HIDE);
	ShowWindow(hMainWnd, SW_SHOWNORMAL);
	wharfHidden = FALSE;
}

void HideWharf(void)
{
	ShowWindow(HiddenWnd, SW_SHOWNORMAL);
	ShowWindow(hMainWnd, SW_HIDE);
	wharfHidden = TRUE;
}

void SetWorkArea(void)
{
	RECT deskRect;
	int oldDocked = wharfDocked;

	SystemParametersInfo(SPI_GETWORKAREA, 0, &deskRect, 0);

	if (wharfBaseX == 0)
	{
		wharfDocked = 1;

		if (setDesktopArea == FALSE)
		{
			deskRect.left = (wharfAutoHide) ? hiddenWidth : wharfTileSize;
			deskRect.right = ScreenWidth;
		}
	}
	else if (wharfBaseX + wharfTileSize == ScreenWidth)
	{
		wharfDocked = 2;

		if (setDesktopArea == FALSE)
		{
			deskRect.left = 0;
			deskRect.right = (wharfAutoHide) ? ScreenWidth - hiddenWidth : ScreenWidth - wharfTileSize;
		}
	}
	else
	{
		wharfDocked = 0;

		if (setDesktopArea == FALSE)
		{
			deskRect.left = 0;
			deskRect.right = ScreenWidth;
		}
	}

	if (wharfDocked != oldDocked)
	{
		SystemParametersInfo(SPI_SETWORKAREA, (isFirst ? 0 : 1), &deskRect, SPIF_SENDCHANGE);
	}

	if (wharfAutoHide && wharfDocked)
	{
		switch (wharfDocked)
		{
			case 1:
			SetWindowPos(HiddenWnd, 0, 0, wharfBaseY, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
			case 2:
			SetWindowPos(HiddenWnd, 0, ScreenWidth - hiddenWidth, wharfBaseY, 0, 0, SWP_NOACTIVATE | SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_NOZORDER );
			break;
		}
	}
}

void togglePressOffset(int i, BOOL bToggle)
{
	if (wharfDirection == WHARF_DOWN)
	{
		if (wharfs[i]->bTogglePressed != bToggle) // redundancy check...see below comment
			SetWindowPos(wharfs[i]->hWnd,
			             0,
			             bToggle ? wharfPressOffset : 0,
			             bToggle ? (wharfTileSize*i) + titleSize + wharfPressOffset : (wharfTileSize*i) + titleSize,
			             wharfTileSize,
			             bToggle ? wharfTileSize - 1 : wharfTileSize,
			             SWP_NOZORDER);
	}
	else if (wharfDirection == WHARF_RIGHT)
	{
		if (wharfs[i]->bTogglePressed != bToggle) // redundancy check...see below comment
			SetWindowPos(wharfs[i]->hWnd,
			             0,
			             bToggle ? (wharfTileSize*i) + wharfPressOffset : (wharfTileSize*i),
			             bToggle ? wharfPressOffset : 0,
			             bToggle ? (wharfTileSize - 1) : wharfTileSize,
			             wharfTileSize,
			             SWP_NOZORDER);
	}
	wharfs[i]->bTogglePressed = bToggle; // could this be replaced by checking the windows current position for a 1, 1 offset?
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class

void quitModule(HINSTANCE dllInst)
{
	RECT deskRect;
	int i;
	UINT Msgs[10];

	if (oldCapt)
	{
		SetCapture(oldCapt);
		oldCapt = NULL;
	}
	if (!wharfNoHints)
	{
		if (wharfHints)
		{
			DestroyWindow (wharfHints);
			wharfHints = NULL;
		}
	}
	for (i = 0; i < numWharfs; i++)
	{

		if (wharfs[i]->subwharfs.size())
		{
			int x;
			for (x = 0; x < wharfs[i]->numSubwharfs; x++)
			{
				if (wharfs[i]->subwharfs[x]->hInst)
				{
					(*wharfs[i]->subwharfs[x]->quitWharfModule)(wharfs[i]->subwharfs[x]->hInst);
					FreeLibrary(wharfs[i]->subwharfs[x]->hInst);
				}
				DestroyWindow(wharfs[i]->subwharfs[x]->hWnd);
				if (wharfs[i]->subwharfs[x]->backImage)
					DeleteObject(wharfs[i]->subwharfs[x]->backImage);
				if (wharfs[i]->subwharfs[x]->frontImage)
					DeleteObject(wharfs[i]->subwharfs[x]->frontImage);
				delete wharfs[i]->subwharfs[x];
			}
			wharfs[i]->subwharfs.clear();
		}
		if (wharfs[i]->hsubwharfWnd)
			DestroyWindow(wharfs[i]->hsubwharfWnd);
		if (wharfs[i]->subRgn)
			DeleteObject(wharfs[i]->subRgn);
		if (wharfs[i]->hInst)
		{
			(*wharfs[i]->quitWharfModule)(wharfs[i]->hInst);
			FreeLibrary(wharfs[i]->hInst);
		}
		DestroyWindow(wharfs[i]->hWnd);
		if (wharfs[i]->backImage)
			DeleteObject(wharfs[i]->backImage);
		if (wharfs[i]->frontImage)
			DeleteObject(wharfs[i]->frontImage);
		delete wharfs[i];
	}
	//free(wharfs);
	//wharfs = NULL;
	wharfs.clear();
	Msgs[0] = LM_SHADETOGGLE;
	Msgs[1] = LM_GETREVID;
	Msgs[2] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	if (hMainRgn)
		DeleteObject(hMainRgn);
	DestroyWindow(hMainWnd);
	if (wharfAutoHide)
		DestroyWindow(HiddenWnd);

	if (defaultBackImage)
		DeleteObject(defaultBackImage);
	if (folderImage)
		DeleteObject(folderImage);
	if (defaultFolderImage)
		DeleteObject(defaultFolderImage);
	if (titlebarImage)
		DeleteObject(titlebarImage);

	// Reset the work area since we no longer have a docked wharf, or any wharf at all, hah!
	SystemParametersInfo(SPI_GETWORKAREA, 0, &deskRect, 0);
	deskRect.left = 0;
	deskRect.right = ScreenWidth;
	SystemParametersInfo(SPI_SETWORKAREA, 0, &deskRect, 0);

	UnregisterClass(szMainWindowClass, dllInst); // unregister window class
	if (wharfAutoHide)
		UnregisterClass(szHiddenWindowClass, dllInst);

	RemoveBangCommand("!ToggleWharf");
}

void ReadConfig (void)
{
	char szBuf[256], *tmp;
	char szToken[256];

	wharfAlwaysOnTop = GetRCBoolDef("WharfAlwaysOnTop", FALSE);
	setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
	wharfAutoUnpress = GetRCBool("WharfAutoUnpress", TRUE);
	wharfAutoClose = GetRCBool("WharfNoAutoClose", FALSE);
	wharfTitlebar = GetRCBool("WharfNoTitleBar", FALSE);
	wharfNoAnim = GetRCBool("WharfNoAnim", TRUE);
	wharfTitles = GetRCBool("WharfAllTitles", TRUE);
	wharfTileSize = GetRCInt("WharfTileSize", 64);
	wharfShadeButton = GetRCInt("WharfShadeButton", (wharfTileSize / 2));
	wharfDblClickXPosition = GetRCInt("WharfDblClickXPosition", 120);
	wharfDblClickDockOnLeft = GetRCBool("WharfDblClickDockOnLeft", TRUE);
	capHeight = GetRCInt("WharfCapHeight", 16);
	titleFore = GetRCColor("WharfTitleFore", 0xFFFFFF);
	titleBack = GetRCColor("WharfTitleBack", 0x802020);
	bevelWidth = GetRCInt("WharfBevelWidth", 1);
	if (bevelWidth < 0)
		bevelWidth = 0;
	wharfStep = GetRCInt("WharfAnimStep", 64);
	wharfAnimTime = GetRCInt("WharfAnimDelay", 10);
	wharfAutoHide = GetRCBool("AutoHideWharf", TRUE);
	autoHideDelay = GetRCInt("AutoHideDelay", 300);
	autoShowDelay = GetRCInt("AutoShowDelay", autoHideDelay);
	hiddenWidth = GetRCInt("WharfHiddenWidth", 1);
	wharfPressOffset = GetRCInt("WharfPressOffset", 1);
	wharfNoHints = GetRCBool("WharfNoHints", TRUE);
	wharfCloseOnSwitch = GetRCBool("WharfCloseOnSwitch", TRUE);
	GetRCString("WharfOpenSound", wharfOpenSound, "", 256);
	GetRCString("WharfCloseSound", wharfCloseSound, "", 256);
	GetRCString("WharfMinSound", wharfMinSound, "", 256);
	GetRCString("WharfMaxSound", wharfMaxSound, "", 256);


	snapTo = GetRCBool("SnapToWharf", TRUE);
	snapToSensitivity = GetRCInt("SnapToSensitivity", 16);

	// Modified - Maduin, 10-20-1999
	//   Changed to use new API LSGetImagePath rather than
	//   access the step.rc directly.

	LSGetImagePath( szImagePath, 256 );

	if (GetRCString("DefaultBackPix", szDefPixmap, "", 256))
	{
		//		char szTemp[256];
		//		wsprintf(szTemp, "%s%s", szImagePath, szDefPixmap);
		//		defaultBackImage = LoadLSImage (szTemp, NULL);
		defaultBackImage = LoadLSImage (szDefPixmap, NULL);
	}

	if (GetRCString("FolderBackPix", szFolderPixmap, "", 256))
	{
		//		char szTemp[256];
		//		wsprintf(szTemp, "%s%s", szImagePath, szFolderPixmap);
		//		defaultFolderImage = LoadLSImage (szTemp, NULL);
		defaultFolderImage = LoadLSImage (szFolderPixmap, NULL);
	}

	if (GetRCString("FolderPix", szToken, "", 256))
	{
		//		char szTemp[256];
		//		wsprintf(szTemp, "%s%s", szImagePath, szToken);
		//		folderImage = LoadLSImage (szTemp, NULL);
		folderImage = LoadLSImage (szToken, NULL);
	}

	if (GetRCString("WharfTitlebarPix", szToken, "", 256))
	{
		//		char szTemp[256];
		//		wsprintf(szTemp, "%s%s", szImagePath, szToken);
		//		titlebarImage = LoadLSImage (szTemp, NULL);
		titlebarImage = LoadLSImage (szToken, NULL);
	}


	sprintf (szBuf, "%s\\MODULES.INI", szLitestepPath);
	//    wharfAnimTime = GetPrivateProfileInt("Wharf", "AnimDelay", wharfAnimTime, szBuf);
	//	Set default string to "-wharfTileSize, 0"?
	GetPrivateProfileString("Wharf", "Position", "-64,0", (char *)&szBuf, sizeof(szBuf), szBuf);
	tmp = strtok(szBuf, ",");
	wharfBaseX = atoi(tmp);
	tmp = strtok(NULL, "");
	wharfBaseY = atoi(tmp);
	if (wharfBaseX < 0)
		wharfBaseX += ScreenWidth;
	if (wharfBaseY < 0)
		wharfBaseY += ScreenHeight;

	GetRCString("WharfTitleFont", szTitleFont, "Arial", 256);
	iTitleFontSize = GetRCInt("WharfTitleFontSize", 8);
	iTitleFontWeight = GetRCInt("WharfTitleFontWeight", 400);
}

void CloseAllFolders()
{
	__try {
	    int i;

	    for (i = 0; i < numWharfs; i++)
    {
	    if (wharfs[i]->subwharfOpen || wharfs[i]->moving)
		    {
			    wharfs[i]->bPressed = FALSE;
			    togglePressOffset(i, FALSE);
			    if (wharfNoAnim)
			    {
				    SetWindowPos(wharfs[i]->hsubwharfWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				    wharfs[i]->subwharfOpen = FALSE;
			    }
			    else
			    {
				    wharfs[i]->moving = TRUE;
				    wharfs[i]->closing = TRUE;
				    //wharfs[i]->movingPos = wharfs[i]->numSubwharfs*64;
				    SetTimer(wharfs[i]->hsubwharfWnd, 3, wharfAnimTime, NULL);
			    }
			    OpenFolders--;
		    }
	    }
	} __except(GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION)
	{}
	;
}


BOOL CreateWharf(int i, LPCSTR szWindowName)
{
	HWND hWnd;
	RECT r;

	hWnd = CreateWindowEx(
	           WS_EX_TRANSPARENT,
	           szMainWindowClass,
	           szWindowName,
	           WS_CHILD,
	           0, 0,
	           wharfTileSize, wharfTileSize,
	           hMainWnd,
	           NULL,
	           dll,
	           NULL);

	if (!hWnd)
	{
		MessageBox(parent, "Error creating wharf tile", "Wharf", MB_OK | MB_TOPMOST);
		return FALSE;
	}
	wharfs[i]->hWnd = hWnd;
	SetWindowLong(wharfs[i]->hWnd, GWL_USERDATA, magicDWord);
	//Wharf hints
	if (!wharfNoHints)
	{
		if (hWnd)
		{
			RECT r;
			GetClientRect (hWnd, &r);
			CreateWharfhints (hWnd, wharfs[i]->szName, &r);
		}
	}

	if (wharfDirection == WHARF_DOWN)
	{
		SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, wharfTileSize, ((i + 1)*wharfTileSize) + titleSize, SWP_NOZORDER);
		SetWindowPos(wharfs[i]->hWnd, 0, 0, (wharfTileSize*i) + titleSize, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	}
	else if (wharfDirection == WHARF_RIGHT)
	{
		SetWindowPos(hMainWnd, 0, wharfBaseX, wharfBaseY, (i + 1)*wharfTileSize, wharfTileSize, SWP_NOZORDER);
		SetWindowPos(wharfs[i]->hWnd, 0, wharfTileSize*i, 0, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	}

	if (wharfs[i]->szCommand[0] == '@')
	{
		int (FAR *FinitWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *FquitWharfModule)(HINSTANCE);
		HRGN (FAR *FGetLSRegion)(int, int);

		char *module;
		HINSTANCE moduleInst;

		module = wharfs[i]->szCommand;
		if (*module == '@')
			module++;
		moduleInst = LoadLibrary(module);
		if ((UINT)moduleInst > HINSTANCE_ERROR)
		{
			FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "initWharfModule");
			if (!FinitWharfModule)
				FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "_initWharfModule");
			FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "quitWharfModule");
			if (!FquitWharfModule)
				FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "_quitWharfModule");
			FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "GetLSRegion");
			if (!FGetLSRegion)
				FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "_GetLSRegion");

			if (!FinitWharfModule || !FquitWharfModule)
			{
				MessageBox(NULL, module, "Invalid Wharf module", MB_OK | MB_TOPMOST);
				FreeLibrary(moduleInst);
				wharfs[i]->hInst = NULL;
			}
			else
			{
				wharfs[i]->hInst = moduleInst;
				wharfs[i]->initWharfModule = FinitWharfModule;
				wharfs[i]->quitWharfModule = FquitWharfModule;
				wharfs[i]->GetLSRegion = FGetLSRegion;
				ExecuteWharf(i);
			}
		}
		else
		{
			wharfs[i]->hInst = NULL;
			MessageBox(NULL, module, "Error loading module", MB_OK | MB_TOPMOST);
		}
	}

	/* Combine our images into one */
	{
		HBITMAP oldBMP1, oldBMP2 = NULL;
		HDC src = CreateCompatibleDC(NULL);
		HDC dst = CreateCompatibleDC(NULL);
		HBRUSH hb = CreateSolidBrush(RGB(255, 0, 255));
		HDC tempDC = GetDC(wharfs[i]->hWnd);
		RECT r;

		wharfs[i]->backImage = CreateCompatibleBitmap(tempDC, wharfTileSize, wharfTileSize);
		oldBMP1 = (HBITMAP)SelectObject(dst, wharfs[i]->backImage);
		r.left = 0;
		r.top = 0;
		r.right = wharfTileSize;
		r.bottom = wharfTileSize;
		FillRect(dst, &r, hb);
		if (wharfTitles && !wharfs[i]->hInst)
		{
			HBRUSH hb2 = CreateSolidBrush(RGB(0, 0, 128));
			r.bottom = 10;
			FillRect(dst, &r, hb2);
			DeleteObject(hb2);
		}
		if (wharfs[i]->hInst && !wharfs[i]->GetLSRegion)
		{
			HDC ddc = GetDC(GetDesktopWindow());
			POINT p;

			p.x = 0;
			p.y = 0;
			ClientToScreen(wharfs[i]->hWnd, &p);
			BitBlt(dst, 0, 0, wharfTileSize, wharfTileSize, ddc, p.x, p.y, SRCCOPY);
			ReleaseDC(GetDesktopWindow(), ddc);
		}
		if (defaultBackImage)
		{
			if ( wharfs[i]->showbg == TRUE )
			{
				SelectObject(src, defaultBackImage);
				TransparentBltLS(dst, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, RGB(255, 0, 255));
			}
		}
		if (wharfs[i]->frontImage)
		{
			BITMAP bmInfo;

			GetObject(wharfs[i]->frontImage, sizeof(bmInfo), &bmInfo);
			if (bmInfo.bmWidth > wharfTileSize)
				bmInfo.bmWidth = wharfTileSize;
			if (bmInfo.bmHeight > wharfTileSize)
				bmInfo.bmHeight = wharfTileSize;
			oldBMP2 = (HBITMAP)SelectObject(src, wharfs[i]->frontImage);
			TransparentBltLS(dst, (wharfTileSize / 2) - (bmInfo.bmWidth / 2), (wharfTileSize / 2) - (bmInfo.bmHeight / 2), bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255, 0, 255));
			DeleteObject(wharfs[i]->frontImage);
		}
		if ((folderImage) && ((!strcmpi(wharfs[i]->szCommand, "Folder")) || (!strcmpi(wharfs[i]->szCommand, "!WharfTasks"))))
		{
			if ( wharfs[i]->showbg == TRUE )
			{
				if (oldBMP2)
					SelectObject(src, folderImage);
				else
					oldBMP2 = (HBITMAP)SelectObject(src, folderImage);
				TransparentBltLS(dst, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, RGB(255, 0, 255));
			}
		}

		ReleaseDC(wharfs[i]->hWnd, tempDC);
		SelectObject(src, oldBMP2);
		DeleteDC(src);
		SelectObject(dst, oldBMP1);
		DeleteDC(dst);
		DeleteObject(hb);
	}
	/* Calculate transparent regions for hMainWnd here, compile regions per bitmap/tile and add together
	* for a full transparent parent window - <toasty@iav.com>  */
	if (wharfs[i]->backImage && !wharfs[i]->hInst)
	{
		HRGN wharfRgn;

		wharfRgn = BitmapToRegion(wharfs[i]->backImage, RGB(255, 0, 255), 0x101010, 0, (wharfTileSize * i) + titleSize);

		if (hMainRgn)
		{
			CombineRgn(hMainRgn, hMainRgn, wharfRgn, RGN_OR);
		}
		else
		{
			hMainRgn = CreateRectRgn(0, 0, wharfTileSize, titleSize);
			CombineRgn(hMainRgn, hMainRgn, wharfRgn, RGN_OR);
		}
		DeleteObject(wharfRgn);
	}
	else
	{
		HRGN rgn;
		if (wharfs[i]->GetLSRegion)
		{
			HRGN bgRgn = BitmapToRegion(wharfs[i]->backImage, RGB(255, 0, 255), 0x101010, 0, (wharfTileSize * i) + titleSize);
			rgn = wharfs[i]->GetLSRegion(0, (wharfTileSize * i) + titleSize);
			if (rgn)
			{
				CombineRgn(rgn, rgn, bgRgn, RGN_OR);
				DeleteObject(bgRgn);
			}
			else
			{
				rgn = bgRgn;
			}
		}
		else
		{
			rgn = CreateRectRgn(0, (wharfTileSize * i) + titleSize, wharfTileSize, (wharfTileSize * i) + wharfTileSize + titleSize);
		}

		if (hMainRgn)
		{
			CombineRgn(hMainRgn, hMainRgn, rgn, RGN_OR);
		}
		else
		{
			hMainRgn = rgn;

			rgn = CreateRectRgn(0, 0, wharfTileSize, titleSize);
			CombineRgn(hMainRgn, hMainRgn, rgn, RGN_OR);
		}
		DeleteObject(rgn);
	}

	ShowWindow(wharfs[i]->hWnd, SW_SHOWNORMAL);
	GetClientRect(wharfs[i]->hWnd, &r);
	InvalidateRect(wharfs[i]->hWnd, &r, TRUE);

	return TRUE;
}

BOOL CreateSubWharf(int i, int x, LPCSTR szWindowName)
{
	HWND hWnd;

	hWnd = CreateWindowEx(
	           0,
	           szMainWindowClass,
	           szWindowName,
	           WS_CHILD,
	           0, 0,
	           wharfTileSize, wharfTileSize,
	           wharfs[i]->hsubwharfWnd,
	           NULL,
	           dll,
	           NULL);

	wharfs[i]->subwharfs[x]->hWnd = hWnd;
	SetWindowLong(wharfs[i]->subwharfs[x]->hWnd, GWL_USERDATA, magicDWord);
	//Wharf hints
	if (!wharfNoHints)
	{
		if (hWnd)
		{
			RECT r;
			GetClientRect (hWnd, &r);
			CreateWharfhints (hWnd, wharfs[i]->subwharfs[x]->szName, &r);
		}
	}

	if (wharfDirection == WHARF_DOWN)
	{
		SetWindowPos(wharfs[i]->subwharfs[x]->hWnd, 0, x*wharfTileSize, 0, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	}

	if (wharfs[i]->subwharfs[x]->szCommand[0] == '@')
	{
		int (FAR *FinitWharfModule)(HWND, HINSTANCE, wharfDataType*);
		int (FAR *FquitWharfModule)(HINSTANCE);
		HRGN (FAR *FGetLSRegion)(int, int);

		char *module;
		HINSTANCE moduleInst;

		module = wharfs[i]->subwharfs[x]->szCommand;
		if (*module == '@')
			module++;
		moduleInst = LoadLibrary(module);
		if ((UINT)moduleInst > HINSTANCE_ERROR)
		{
			FinitWharfModule = (int (FAR *)(HWND, HINSTANCE, wharfDataType*))GetProcAddress(moduleInst, "initWharfModule");
			FquitWharfModule = (int (FAR *)(HINSTANCE))GetProcAddress(moduleInst, "quitWharfModule");
			FGetLSRegion = (HRGN (FAR *)(int, int))GetProcAddress(moduleInst, "GetLSRegion");

			if (!FinitWharfModule || !FquitWharfModule)
			{
				MessageBox(NULL, module, "Invalid Wharf module", MB_OK | MB_TOPMOST);
				FreeLibrary(moduleInst);
				wharfs[i]->subwharfs[x]->hInst = NULL;
			}
			else
			{
				wharfs[i]->subwharfs[x]->hInst = moduleInst;
				wharfs[i]->subwharfs[x]->initWharfModule = FinitWharfModule;
				wharfs[i]->subwharfs[x]->quitWharfModule = FquitWharfModule;
				wharfs[i]->subwharfs[x]->GetLSRegion = FGetLSRegion;
				ExecuteSubWharf(i, x);
			}
		}
		else
		{
			wharfs[i]->subwharfs[x]->hInst = NULL;
			MessageBox(NULL, module, "Error loading module", MB_OK | MB_TOPMOST);
		}
	}

	/* Combine our images into one */
	{
		HBITMAP oldBMP1, oldBMP2 = NULL;
		HDC src = CreateCompatibleDC(NULL);
		HDC dst = CreateCompatibleDC(NULL);
		HDC tempDC = GetDC(wharfs[i]->subwharfs[x]->hWnd);
		HBRUSH hb = CreateSolidBrush(RGB(255, 0, 255));
		RECT r;

		wharfs[i]->subwharfs[x]->backImage = CreateCompatibleBitmap(tempDC, wharfTileSize, wharfTileSize);
		oldBMP1 = (HBITMAP)SelectObject(dst, wharfs[i]->subwharfs[x]->backImage);
		r.left = 0;
		r.top = 0;
		r.right = wharfTileSize;
		r.bottom = wharfTileSize;
		FillRect(dst, &r, hb);
		if (wharfTitles && !wharfs[i]->subwharfs[x]->hInst)
		{
			HBRUSH hb2 = CreateSolidBrush(RGB(0, 0, 128));
			r.bottom = 10;
			FillRect(dst, &r, hb2);
			DeleteObject(hb2);
		}

		if (defaultFolderImage)
		{
			if ( wharfs[i]->subwharfs[x]->showbg == TRUE )
			{
				oldBMP2 = (HBITMAP)SelectObject(src, defaultFolderImage);
				BitBlt(dst, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
			}
		}
		if (wharfs[i]->subwharfs[x]->frontImage)
		{
			BITMAP bmInfo;

			GetObject(wharfs[i]->subwharfs[x]->frontImage, sizeof(bmInfo), &bmInfo);
			if (bmInfo.bmWidth > wharfTileSize)
				bmInfo.bmWidth = wharfTileSize;
			if (bmInfo.bmHeight > wharfTileSize)
				bmInfo.bmHeight = wharfTileSize;
			if (oldBMP2)
				SelectObject(src, wharfs[i]->subwharfs[x]->frontImage);
			else
				oldBMP2 = (HBITMAP)SelectObject(src, wharfs[i]->subwharfs[x]->frontImage);
			TransparentBltLS(dst, (wharfTileSize / 2) - (bmInfo.bmWidth / 2), (wharfTileSize / 2) - (bmInfo.bmHeight / 2), bmInfo.bmWidth, bmInfo.bmHeight, src, 0, 0, RGB(255, 0, 255));
			DeleteObject(wharfs[i]->subwharfs[x]->frontImage);
		}
		ReleaseDC(wharfs[i]->subwharfs[x]->hWnd, tempDC);
		SelectObject(src, oldBMP2);
		DeleteDC(src);
		SelectObject(dst, oldBMP1);
		DeleteDC(dst);
		DeleteObject(hb);
	}
	if (wharfs[i]->subwharfs[x]->backImage && !wharfs[i]->subwharfs[x]->hInst)
	{
		HRGN wharfRgn;

		wharfRgn = BitmapToRegion(wharfs[i]->subwharfs[x]->backImage, RGB(255, 0, 255), 0x101010, (wharfTileSize * x), 0);
		//if (CombineRgn(wharfs[i]->subRgn, wharfs[i]->subRgn, wharfRgn, RGN_OR) == ERROR)
		if (wharfs[i]->subRgn)
		{
			CombineRgn(wharfs[i]->subRgn, wharfs[i]->subRgn, wharfRgn, RGN_OR);
			DeleteObject(wharfRgn);
		}
		else
		{
			wharfs[i]->subRgn = wharfRgn;
		}
	}
	else
	{
		HRGN rgn;
		if (wharfs[i]->subwharfs[x]->GetLSRegion)
		{
			HRGN bgRgn = BitmapToRegion(wharfs[i]->subwharfs[x]->backImage, RGB(255, 0, 255), 0x101010, (wharfTileSize * x), 0);
			rgn = wharfs[i]->subwharfs[x]->GetLSRegion(wharfTileSize * x, 0);
			if (rgn)
			{
				CombineRgn(rgn, rgn, bgRgn, RGN_OR);
				DeleteObject(bgRgn);
			}
			else
			{
				rgn = bgRgn;
			}

		}
		else
		{
			rgn = CreateRectRgn(wharfTileSize * x, 0, wharfTileSize * (x + 1), wharfTileSize);
		}

		if (wharfs[i]->subRgn)
		{
			CombineRgn(wharfs[i]->subRgn, wharfs[i]->subRgn, rgn, RGN_OR);
			DeleteObject(rgn);
		}
		else
		{
			wharfs[i]->subRgn = rgn;
		}
	}

	ShowWindow(wharfs[i]->subwharfs[x]->hWnd, SW_SHOWNORMAL);

	return TRUE;
}

int GetWharfByWnd(HWND hwnd)
{
	int i;

	for (i = 0;i < numWharfs;i++)
		if (wharfs[i]->hWnd == hwnd)
			return i;
	return -1;
}

void GetWharfData(wharfDataType *wd)
{

	strcpy(lsPath, szLitestepPath);
	if (lsPath[strlen(lsPath)] != '\\')
		strcat(lsPath, "\\");

	wd->trayIconSize = GetRCInt("TrayIconSize", 16);
	wd->taskBarFore = GetRCColor("LSTaskBarFore", 0x000000);
	wd->taskBarBack = GetRCColor("LSTaskBarBack", 0x7f7f7f);
	wd->taskBarText = GetRCColor("LSTaskBarText", 0xffffff);
	wd->taskBarFore2 = GetRCColor("LSTaskBarFore2", 0x3f3f3f3f);
	wd->taskBar = GetRCBool("NoTaskBar", FALSE);
	wd->showBeta = GetRCBool("NoShowBeta", TRUE);
	;
	wd->usClock = GetRCBool("UsClock", TRUE);
	wd->vwmVelocity = GetRCInt("VWMVelocity", 300);
	wd->VWMDistance = GetRCInt("VWMSecurityDistance", 5);
	wd->VWMNoAuto = GetRCBool("VWMNoAuto", TRUE);
	wd->pixmapDir = szImagePath;
	wd->defaultBmp = szDefPixmap;
	wd->vwmBackColor = GetRCColor("VWMBackColor", 0x000000);
	wd->vwmSelBackColor = GetRCColor("VWMSelBackColor", 0x3f3f3f);
	wd->vwmForeColor = GetRCColor("VWMForeColor", 0x906090);
	wd->vwmBorderColor = GetRCColor("VWMBorderColor", 0xffffff);
	wd->lsPath = lsPath;
	wd->borderSize = bevelWidth;
}

void SoundOpen(void)
{
	sndPlaySound(wharfOpenSound, SND_ASYNC | SND_NODEFAULT);
}

void SoundClose(void)
{
	sndPlaySound(wharfCloseSound, SND_ASYNC | SND_NODEFAULT);
}

void SoundMin(void)
{
	sndPlaySound(wharfMinSound, SND_ASYNC | SND_NODEFAULT);
}

void SoundMax(void)
{
	sndPlaySound(wharfMaxSound, SND_ASYNC | SND_NODEFAULT);
}


void ExecuteWharf(int i)
{
	int q;
	if (!strcmpi(wharfs[i]->szCommand, "Folder"))
	{
		if (wharfClosing)
		{
			CloseAllFolders();
			return ;
		}
		// Below closes all folders if WharfAutoClose is actiavted...

		if (wharfAutoClose)
		{
			for (q = 0; q < numWharfs; q++)
			{
				if ((wharfs[q]->subwharfOpen || wharfs[q]->moving) && q != i)
				{
					wharfs[q]->bPressed = FALSE;
					togglePressOffset(q, FALSE);
					if (wharfNoAnim)
					{
						SetWindowPos(wharfs[q]->hsubwharfWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
					}
					else
					{
						wharfs[q]->moving = TRUE;
						wharfs[q]->closing = TRUE;
						//wharfs[q]->movingPos = wharfs[q]->numSubwharfs*64;
						SetTimer(wharfs[q]->hsubwharfWnd, 3, wharfAnimTime, NULL);
					}
					wharfs[q]->subwharfOpen = FALSE;
					OpenFolders--;
				}
			}
		}

		if (wharfs[i]->moving)
		{
			if (wharfs[i]->closing)
			{
				wharfs[i]->closing = FALSE;
				if (wharfOpenSound[0])
					SoundOpen();
			}
			else
			{
				wharfs[i]->closing = TRUE;
				if (wharfCloseSound[0])
					SoundClose();
			}
		}
		else if (wharfs[i]->subwharfOpen == FALSE)
		{
			if (wharfOpenSound[0])
				SoundOpen();
			wharfs[i]->subwharfOpen = TRUE;
			if (wharfNoAnim)
			{
				if ((wharfBaseX + (wharfTileSize / 2)) > ScreenWidth / 2)
					SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX - (wharfs[i]->numSubwharfs*wharfTileSize), wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->numSubwharfs*wharfTileSize, wharfTileSize, SWP_NOZORDER);
				else
					SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX + wharfTileSize, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->numSubwharfs*wharfTileSize, wharfTileSize, SWP_NOZORDER);
			}
			else
			{
				wharfs[i]->moving = TRUE;
				wharfs[i]->closing = FALSE;
				SetTimer(wharfs[i]->hsubwharfWnd, 2, wharfAnimTime, NULL);
				OpenFolders++;
			}
		}
		else if (wharfs[i]->subwharfOpen)
		{
			if (wharfCloseSound[0])
				SoundClose();
			if (wharfNoAnim)
			{
				wharfs[i]->subwharfOpen = FALSE;
				wharfs[i]->bPressed = FALSE;
				togglePressOffset(i, FALSE);
				SetWindowPos(wharfs[i]->hsubwharfWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
			}
			else
			{
				wharfs[i]->moving = TRUE;
				wharfs[i]->closing = TRUE;
				SetTimer(wharfs[i]->hsubwharfWnd, 3, wharfAnimTime, NULL);
				OpenFolders--;
			}
		}
		return ;
	}

	if (wharfs[i]->szCommand[0] == '@')
	{
		wharfDataType wharfData;
		memset (&wharfData, 0, sizeof (wharfData));
		GetWharfData(&wharfData);

		(*wharfs[i]->initWharfModule)(wharfs[i]->hWnd, wharfs[i]->hInst, &wharfData);
		return ;
	}

	if (wharfs[i]->szCommand[0] == '!')
	{
		if (!strcmpi(wharfs[i]->szCommand, "!WharfTasks"))
		{
			ExecuteWharfTasks(i);
		}
		else
			ParseBangCommand(wharfs[i]->hWnd, wharfs[i]->szCommand, wharfs[i]->szParameters);
		return ;
	}

	{
		//SHELLEXECUTEINFO si;
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];

		_splitpath(wharfs[i]->szCommand, drive, dir, NULL, NULL);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);

		if (!wharfAutoUnpress)
		{
			wharfs[i]->bPressed = FALSE;
			togglePressOffset(i, FALSE);
		}

		LSExecuteEx(NULL, NULL, wharfs[i]->szCommand, wharfs[i]->szParameters, workDirectory, SW_SHOWNORMAL);
		/*
		memset(&si, 0, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);
		si.lpDirectory = workDirectory;
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = wharfs[i]->szCommand;
		si.lpParameters = wharfs[i]->szParameters;
		ShellExecuteEx(&si);
		*/ 
		return ;
	}
}


void ExecuteSubWharf(int i, int x)
{
	if (wharfs[i]->subwharfs[x]->szCommand[0] == '@')
	{
		wharfDataType wharfData;
		char lsPath[256];

		strcpy(lsPath, szLitestepPath);
		if (lsPath[strlen(lsPath)] != '\\')
			strcat(lsPath, "\\");
		memset (&wharfData, 0, sizeof (wharfData));
		GetWharfData(&wharfData);

		(*wharfs[i]->subwharfs[x]->initWharfModule)(wharfs[i]->subwharfs[x]->hWnd, wharfs[i]->subwharfs[x]->hInst, &wharfData);
		return ;
	}

	if (wharfs[i]->subwharfs[x]->szCommand[0] == '!')
	{
		if (!strcmpi(wharfs[i]->szCommand, "!WharfTasks"))
		{
			if (!SendMessage(parent, LM_BRINGTOFRONT, 0, (long)wharfs[i]->subwharfs[x]->taskWnd))
				SwitchToThisWindow(wharfs[i]->subwharfs[x]->taskWnd, 1);
		}
		else
		{
			ParseBangCommand(wharfs[i]->hsubwharfWnd, wharfs[i]->subwharfs[x]->szCommand, wharfs[i]->subwharfs[x]->szParameters);
			//			MessageBox(0, "So far so good", "Wharf", MB_OK | MB_TOPMOST);
		}
		return ;
	}

	{
		//SHELLEXECUTEINFO si;
		char workDirectory[MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];

		_splitpath(wharfs[i]->subwharfs[x]->szCommand, drive, dir, NULL, NULL);
		strcpy(workDirectory, drive);
		strcat(workDirectory, dir);

		LSExecuteEx(NULL, NULL, wharfs[i]->subwharfs[x]->szCommand, wharfs[i]->subwharfs[x]->szParameters, workDirectory, SW_SHOWNORMAL);
		/*
		memset(&si, 0, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);
		si.lpDirectory = workDirectory;
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = wharfs[i]->subwharfs[x]->szCommand;
		si.lpParameters = wharfs[i]->subwharfs[x]->szParameters;
		ShellExecuteEx(&si);
		*/ 
		return ;
	}
}

void ExecuteWharfTasks(int i)
{
	IWindowList *windowList;
	char capt[256];
	int n, q, x;

	if (wharfClosing)
	{
		CloseAllFolders();
		return ;
	}


	if (wharfAutoClose)
	{
		for (q = 0; q < numWharfs; q++)
		{
			if ((wharfs[q]->subwharfOpen || wharfs[q]->moving) && q != i)
			{
				wharfs[q]->bPressed = FALSE;
				togglePressOffset(q, FALSE);
				if (wharfNoAnim)
				{
					SetWindowPos(wharfs[q]->hsubwharfWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
				}
				else
				{
					wharfs[q]->moving = TRUE;
					wharfs[q]->closing = TRUE;
					//wharfs[q]->movingPos = wharfs[q]->numSubwharfs*64;
					SetTimer(wharfs[q]->hsubwharfWnd, 3, wharfAnimTime, NULL);
				}
				wharfs[q]->subwharfOpen = FALSE;
				OpenFolders--;
			}
		}
	}

	if (wharfs[i]->moving)
	{
		if (wharfs[i]->closing)
		{
			wharfs[i]->closing = FALSE;
			if (wharfOpenSound[0])
				SoundOpen();
		}
		else
		{
			wharfs[i]->closing = TRUE;
			if (wharfCloseSound[0])
				SoundClose();
		}
	}
	else if (wharfs[i]->subwharfOpen)
	{
		if (wharfCloseSound[0])
			SoundClose();
		if (wharfNoAnim)
		{
			wharfs[i]->subwharfOpen = FALSE;
			wharfs[i]->bPressed = FALSE;
			togglePressOffset(i, FALSE);
			SetWindowPos(wharfs[i]->hsubwharfWnd, 0, 0, 0, 0, 0, SWP_NOZORDER);
		}
		else
		{
			wharfs[i]->moving = TRUE;
			wharfs[i]->closing = TRUE;
			SetTimer(wharfs[i]->hsubwharfWnd, 3, wharfAnimTime, NULL);
			OpenFolders--;
		}
	}
	else
	{
		if (wharfs[i]->subwharfs.size())
		{
			for (x = 0; x < wharfs[i]->numSubwharfs; x++)
			{
				DeleteObject(wharfs[i]->subwharfs[x]->backImage);
				DeleteObject(wharfs[i]->subwharfs[x]->frontImage);
				DestroyWindow(wharfs[i]->subwharfs[x]->hWnd);
				delete wharfs[i]->subwharfs[x];
			}
			DestroyWindow(wharfs[i]->hsubwharfWnd);
			wharfs[i]->subwharfs.clear();
		}

		wharfs[i]->subwharfs.clear();
		wharfs[i]->numSubwharfs = 0;
		wharfs[i]->subwharfOpen = FALSE;
		wharfs[i]->hsubwharfWnd = CreateWindowEx(
		                              WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
		                              szMainWindowClass,
		                              "LSWharflet",
		                              WS_CLIPCHILDREN | WS_POPUP,
		                              0, 0,
		                              0, 0,
		                              parent,
		                              NULL,
		                              dll,
		                              NULL
		                          );

		SetWindowLong(wharfs[i]->hsubwharfWnd, GWL_USERDATA, magicDWord);
		ShowWindow(wharfs[i]->hsubwharfWnd, SW_SHOWNORMAL);

		windowList = (IWindowList *)SendMessage(parent, LM_WINDOWLIST, 0, 0);
		long count;
		HWND *hwnds;

		count = windowList->GetWindowCount();
		hwnds = new HWND[count];
		count = windowList->GetWindowList(hwnds, count);

		for (n = 0; n < count; n++)
		{
			HICON hIcon = NULL;
			HWND parent, window;

			window = hwnds[n];

			if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
				continue;
			if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
				continue;
			parent = GetParent(window);
			if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
				continue;

			x = wharfs[i]->numSubwharfs;
			/*if (!wharfs[i]->subwharfs)
		{				
				wharfs[i]->subwharfs = (subwharfType *)malloc(sizeof(subwharfType));
		} else {
				wharfs[i]->subwharfs = (subwharfType *)realloc(wharfs[i]->subwharfs, (x+1)*sizeof(subwharfType));
		}
			memset(&wharfs[i]->subwharfs[x], 0, sizeof(wharfs[i]->subwharfs[x]));*/
			wharfs[i]->subwharfs.push_back(new subwharfType(wharfs[i]));

			SendMessageTimeout(window, WM_GETICON, 1, 0, 0, 250, (unsigned long *)&hIcon);
			if (!hIcon)
				SendMessageTimeout(window, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long *)&hIcon);
			if (!hIcon)
				hIcon = (HICON)GetClassLong(window, GCL_HICON);
			if (!hIcon)
				hIcon = (HICON)GetClassLong(window, GCL_HICONSM);
			if (hIcon) /* not working for some reason */
			{
				HBITMAP oldBMP;
				HDC dst = CreateCompatibleDC(NULL);
				HDC tempDC = GetDC(wharfs[i]->hsubwharfWnd);
				HBRUSH hb = CreateSolidBrush(RGB(255, 0, 255));
				HBRUSH hb2 = CreateSolidBrush(RGB(0, 0, 128));
				RECT r;
				int nHeight;

				wharfs[i]->subwharfs[x]->frontImage = CreateCompatibleBitmap(tempDC, wharfTileSize, wharfTileSize);
				oldBMP = (HBITMAP)SelectObject(dst, wharfs[i]->subwharfs[x]->frontImage);
				r.left = 0;
				r.top = 0;
				r.right = wharfTileSize;
				r.bottom = wharfTileSize;
				FillRect(dst, &r, hb);
				//				r.bottom = 10;
				nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(dst, LOGPIXELSY), 72);
				r.bottom = nHeight + 2;
				r.right = wharfTileSize;
				FillRect(dst, &r, hb2);
				DrawIconEx(dst, 16, 16, hIcon, 32, 32, 0, NULL, DI_NORMAL);
				ReleaseDC(wharfs[i]->hsubwharfWnd, tempDC);
				SelectObject(dst, oldBMP);
				DeleteDC(dst);
				DeleteObject(hb);
				DeleteObject(hb2);
				DeleteObject(hIcon);
			}

			capt[0] = 0;
			if (window != NULL)
			{
				GetWindowText(window, (char *)&capt, sizeof(capt));
				strcpy(wharfs[i]->subwharfs[x]->szName, capt);
			}
			strcpy(wharfs[i]->subwharfs[x]->szCommand, "!none");
			wharfs[i]->subwharfs[x]->taskWnd = window;
			wharfs[i]->subwharfs[x]->showbg = TRUE;
			CreateSubWharf(i, wharfs[i]->numSubwharfs, "");
			wharfs[i]->numSubwharfs++;
		}

		delete [] hwnds;

		SetWindowRgn(wharfs[i]->hsubwharfWnd, wharfs[i]->subRgn, TRUE);

		if (wharfOpenSound[0])
			SoundOpen();
		wharfs[i]->subwharfOpen = TRUE;

		if (wharfNoAnim)
		{
			if ((wharfBaseX + (wharfTileSize / 2)) > ScreenWidth / 2)
				SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX - (wharfs[i]->numSubwharfs*wharfTileSize), wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->numSubwharfs*wharfTileSize, wharfTileSize, SWP_NOZORDER);
			else
				SetWindowPos(wharfs[i]->hsubwharfWnd, 0, wharfBaseX + wharfTileSize, wharfBaseY + (i*wharfTileSize) + titleSize, wharfs[i]->numSubwharfs*wharfTileSize, wharfTileSize, SWP_NOZORDER);
			wharfs[i]->subwharfOpen = TRUE;
			return ;
		}
		else
		{
			wharfs[i]->moving = TRUE;
			wharfs[i]->closing = FALSE;
			SetTimer(wharfs[i]->hsubwharfWnd, 2, wharfAnimTime, NULL);
			OpenFolders++;
		}
	}

}

void CreateWharfhints(HWND hWnd, char *txt, RECT *r)
{
	TOOLINFO ti;    // tool information

	if (wharfNoHints)
	{
		return ;
	}

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = txt;
	ti.rect = *r;

	SendMessage(wharfHints, TTM_ADDTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

void RemoveWharfhints(HWND hWnd)
{
	TOOLINFO ti;    // tool information
	RECT r = {0, 0, 0, 0};

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.hinst = dll;
	ti.uId = 0;
	ti.lpszText = NULL;
	ti.rect = r;

	SendMessage(wharfHints, TTM_DELTOOL, 0, (LPARAM) (LPTOOLINFO) &ti);
}

wharfType::wharfType()
{
	hInst = 0;
	hWnd = 0;
	hsubwharfWnd = 0;
	backImage = 0;
	frontImage = 0;
	szName[0] = 0;
	szCommand[0] = 0;
	szParameters[0] = 0;
	numSubwharfs = 0;
	subwharfX = 0;
	subwharfY = 0;
	subwharfOpen = 0;
	moving = 0;
	closing = 0;
	showbg = TRUE;
	bPressed = 0;
	bTogglePressed = 0;
	movingPos = 0;
	initWharfModule = 0;
	quitWharfModule = 0;
	GetLSRegion = 0;
	subRgn = 0;
}

void wharfType::Paint(HDC hdc, HDC src)
{
	HBITMAP oldBMP = NULL;

	// have a background image?
	if (backImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, backImage);
		// are we pressed down?
		if (bPressed)
			TransparentBltLS(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, RGB(255, 0, 255));
		else
			BitBlt(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
	}

	// displaying titles, but not a wharf module?
	if (wharfTitles && !hInst)
	{
		PaintTitle(hdc, src);
	}
	if (bevelWidth) // displaying a beveled edge?
	{
		RECT r = {0, 0, wharfTileSize, wharfTileSize};
		Frame3D(hdc, r, RGB(255, 255, 255), RGB(0, 0, 0), bevelWidth);
	}

	if (oldBMP)
	{
		SelectObject(src, oldBMP);
	}
}

void wharfType::PaintTitle(HDC hdc, HDC src)
{
	RECT r;
	HBRUSH back;
	HFONT titleFont, oldFont;
	int nHeight;
	int len = lstrlen(szName);

	back = CreateSolidBrush(titleBack);
	GetClientRect(hWnd, &r);
	//					r.bottom = 10;
	//					FillRect(hdc, &r, back);
	nHeight = MulDiv(iTitleFontSize, GetDeviceCaps(src, LOGPIXELSY), 72);
	r.bottom = nHeight + 2;
	FillRect(src, &r, back);
	titleFont = CreateFont(
	                nHeight,  // 8,
	                0,  // 6,
	                0,
	                0,
	                iTitleFontWeight,  // 0,
	                FALSE,
	                FALSE,
	                FALSE,
	                ANSI_CHARSET,
	                OUT_DEFAULT_PRECIS,
	                CLIP_DEFAULT_PRECIS,
	                DEFAULT_QUALITY,
	                DEFAULT_PITCH | FF_DONTCARE,  // DEFAULT_PITCH,
	                szTitleFont
	            );
	oldFont = (HFONT)SelectObject(src, titleFont);
	SetBkMode(src, TRANSPARENT);
	SetTextColor(src, titleFore);
	TextOut(src, 2, 1, szName, len);
	BitBlt(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
	SelectObject(src, oldFont);
	DeleteObject(titleFont);
	DeleteObject(back);
}

subwharfType::subwharfType(wharfType *p)
{
	wharfType();
	parent = p;
	taskWnd = 0;
}

void subwharfType::Paint(HDC hdc, HDC src)
{
	HBITMAP oldBMP = NULL;

	if (backImage)
	{
		oldBMP = (HBITMAP)SelectObject(src, backImage);
		BitBlt(hdc, 0, 0, wharfTileSize, wharfTileSize, src, 0, 0, SRCCOPY);
	}
	if ((wharfTitles && !hInst) || (!strcmpi(parent->szCommand, "!WharfTasks")))
	{
		PaintTitle(hdc, src);
	}
	if (bevelWidth)
	{
		RECT r = { 0, 0, wharfTileSize, wharfTileSize };
		Frame3D(hdc, r, RGB(255, 255, 255), RGB(0, 0, 0), bevelWidth);
	}

	if (oldBMP)
	{
		SelectObject(src, oldBMP);
	}
}

void BangToggleWharf(HWND hCaller, LPCSTR szArgs)
{
	Message message;
	MainWnd_ShadeToggle(message);
}

/*
$Log: wharf.cpp,v $
Revision 1.3  2002/06/15 13:27:37  scilence
Moved !ToggleWharf from lsapi to wharf

Revision 1.2  2002/05/08 00:18:06  ilmcuts
fixed Revision IDs

Revision 1.1.1.1  2002/05/07 01:22:56  repugnant
no message

Revision 1.2  2001/11/20 22:39:59  message
  - Removed all the TCHAR, _TEXT hoopla (it was never properly implemented fully
    and just made the source look like poo)
  - Source formatting! All the source should have a standard look now.
    (formatting done using the astyle @ http://www.sourceforge.net/projects/astyle)
    (command line options were: astyle -cbKpt *.cpp *.h *.c)
    (Using tabs instead of spaces)

Revision 1.1.1.1  2001/05/31 11:57:52  headius
importing LiteStep b24 code into cvs
 
Revision 1.11.2.10  2001/02/02 21:55:55  headius
see changes.txt, Headius, 2/2/2001
 
Revision 1.11.2.9  2001/01/21 00:24:55  message
*** empty log message ***
 
Revision 1.11.2.8  2000/10/29 08:48:06  NeXTer
See changes.txt
 
Revision 1.11.2.7  2000/10/03 05:41:23  NeXTer
See changes.txt
 
Revision 1.11.2.6  2000/09/04 05:57:39  headius
*** empty log message ***
 
Revision 1.11.2.5  2000/08/31 21:31:40  NeXTer
See changes.txt
 
Revision 1.11.2.4  2000/08/25 22:40:32  NeXTer
See changes.txt
 
Revision 1.11.2.3  2000/08/25 19:56:44  headius
fixes and rewrites in wharf
 
Revision 1.11.2.2  2000/08/03 21:35:38  NeXTer
- Added the ability to pause a recycle by holding the shift key
- Added the MB_TOPMOST flag to all messageboxes
 
Revision 1.11.2.1  2000/07/22 03:37:24  message
*** empty log message ***
 
Revision 1.11  2000/04/22 04:57:37  message
*** empty log message ***
 
Revision 1.5  2000/02/24 20:54:13  headius
see changes.txt
 
Revision 1.1.1.1  2000/01/28 05:57:39  headius
Import of Litestep into new cvs
 
Revision 1.2  2000/01/21 06:16:15  headius
Tabifying
 
Revision 1.1  2000/01/17 10:23:25  headius
Update of wharf to be .cpp and to use the new WindowList class
Not thread-safe yet.
 
  Revision 1.112  2000/01/06 05:26:15  message
  Changed source files back to dos format, somehow had become unix format, updated
  dependencies of desktop to include lsutil, wasn't linking properly because lsutil
  was not being built first.
  
	Revision 1.92  1998/11/17 19:27:39  bryan
	Some more mods and fixes.
	
	  Revision 1.91  1998/11/17 15:13:28  cyberian
	  *** empty log message ***
	  
*/
