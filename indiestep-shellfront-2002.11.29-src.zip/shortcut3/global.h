#if !defined(__GLOBAL_H__INCLUDED__)
#define __GLOBAL_H__INCLUDED__

#define MODULE_NAME "Shortcut3"
#define MODULE_VERSION "1.8"
#define MODULE_INFO MODULE_NAME ":" MODULE_VERSION

const char APP_NAME[] = "ShortcutClass"; // Our window class, etc
const char RCS_REVISION[] = "$Revision: 1.5 $"; // Our Version
const char RCS_ID[] = "$Id: global.h,v 1.5 2002/08/13 20:37:56 mickem Exp $"; // The Full RCS ID.

#endif // __GLOBAL_H__INCLUDED__