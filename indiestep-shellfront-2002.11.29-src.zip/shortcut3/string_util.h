#ifndef __STRING_UTIL_H__
#define __STRING_UTIL_H__

#include <string>
#include "../lsapi/lsapi.h"


typedef struct {
	int x;
	int y;
	struct t_bools {
		bool x;
		bool y;
	} ;
	struct t_bools centerd;
	struct t_bools relative;
} POSITION;

std::string itos(int i);
int stoi(std::string s);

POSITION GetPosition(std::string &szArg);
POSITION GetPosition(std::string x, std::string y);
POINT readjustCoords(POSITION pos) ;
bool isCloseTo(const POINT pos, const POINT size, int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY);

std::string GetToken(std::string &szString, BOOL useBrackets);
boolean GetToken(std::string &szToken, std::string &szString, BOOL useBrackets);
std::string GetWindowText(HWND hWnd);
#define LSErrorPrintf(str) \
	LSLogPrintf(LOG_ERROR, "shortcut3" __FILE__, "%d" str, __LINE__
#define LSE )
//#define LSErrorPrintf(str, data) \
//	LSLogPrintf(LOG_ERROR, "shortcut3" __FILE__, "%d" str, __LINE__, data) 

#define LSError(str) \
	LSLogPrintf(LOG_ERROR, "shortcut3" __FILE__, "%d" str, __LINE__) 

#define SF2(nr) #nr
#define DBG(ln, nr) ln ":" SF2(nr)


#endif //__STRING_UTIL_H__