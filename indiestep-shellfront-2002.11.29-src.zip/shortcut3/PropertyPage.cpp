// PropertyPage.cpp: implementation of the CMyPropertyPage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdatl.h"

#include <atlbase.h>
#include <windows.h>
#include <commctrl.h>
#include "PropertyPage.h"
#include "typeinfo.h"
#include "PropertySheet.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyPropertyPage::CMyPropertyPage(IConfigurationItem *pRootItem) : 
	m_iCtrlIndex(10), 
	m_pCurrentItem(NULL), 
	m_iLastSelectedDlgItem(-1),
	m_pRootItem(pRootItem),
	m_bLableEdit(false)
{
		m_font.CreateFont(12,0, 0, 0, 800, 0, 0, 0, 0, 1, 2, 1, DEFAULT_PITCH | FF_SWISS | TMPF_TRUETYPE, "Tahoma");
		m_hBrush = ::CreateSolidBrush(RGB(252,252,204));
}

CMyPropertyPage::~CMyPropertyPage()
{
	for (T_LST_ICI::iterator it = m_lstItems.begin(); it != m_lstItems.end(); it++) {
		delete (*it);
	}
	m_lstItems.clear();
	DeleteObject(m_hBrush);
}

/**
 *
 * parse
 *
 * Description:
 * Parses all dialog items and initalizes all objects.
 *
 * @created	2002-07-17 14:36
 * @author	MickeM <mickem@medin.nu>
 */
void CMyPropertyPage::parse(IConfigurationItem *pItem, HTREEITEM hParent)
{
	if (!pItem)
		return;
	m_lstItems.push_back(pItem);
	pItem->initializeNode(this);

	HTREEITEM hItem = m_tree.InsertItem(_T(pItem->getName().c_str()), pItem->getIcon(), pItem->getIcon(), hParent, TVI_LAST);
	if (!hItem) {
		STD_ICI_ERR(SCE_BAD_HANDLE, pItem);
		return;
	}
	m_tree.SetItemData(hItem, (DWORD)(void*)pItem);
	if (pItem->hasChildren()) {
		IConfigurationItem::LST_CHILD child = pItem->getChildren();
		for (IConfigurationItem::LST_CHILD::iterator it = child.begin(); it != child.end(); it++) {
			parse((*it), hItem);
		}
	}
}


void CMyPropertyPage::resizeControls() 
{
	RECT rect;
	GetClientRect(&rect);
	int r = rect.right;
	int h = rect.bottom-rect.top;
	rect.right = rect.left + 200;
	int w = r-rect.right;
	m_tree.SetWindowPos(NULL, &rect, SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER);

	rect.left = rect.right + 5;
	rect.right = r;
	rect.top = rect.bottom-40;
	m_helptext.SetWindowPos(NULL, &rect, SWP_NOACTIVATE|SWP_NOZORDER);
	m_helptext.InvalidateRect(NULL, NULL);

	if (CConfigurationHandlerImpl::hasActiveTemplate()) 
		CConfigurationHandlerImpl::getActiveTemplate()->resize(w-5, h-45);
}

/**
 *
 * onSize
 *
 * Description:
 * Handles resizing of the dialog
 *
 * @created	2002-07-17 14:37
 * @author	MickeM <mickem@medin.nu>
 */
LRESULT CMyPropertyPage::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled)
{
	resizeControls();
	return 0;
}

LRESULT CMyPropertyPage::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled)
{
	RECT rect;
	GetClientRect(&rect);
	int r = rect.right;
	rect.right = rect.left + 200;
	m_tree.Create(m_hWnd, rect, "test", WS_VISIBLE|WS_CHILD|WS_TABSTOP|
		TVS_FULLROWSELECT|TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT|TVS_SHOWSELALWAYS|TVS_EDITLABELS, WS_EX_CLIENTEDGE, CTL_TREE_ID);
	rect.left = rect.right + 5;
	rect.right = r;
	rect.top = rect.bottom-40;
	m_helptext.Create(m_hWnd, rect,"STATIC", WS_CHILD|WS_VISIBLE|SS_CENTER, WS_EX_CLIENTEDGE, CTL_HELPTEXT_ID);
	m_helptext.SetWindowText("This is the help text, select a control to see help here");
	parse(m_pRootItem, TVI_ROOT);
	return 0;
}

void readjustRect(RECT &r1, RECT &r2)
{
	r1.left += r2.right-r2.left +10;
	r1.right += r2.right-r2.left +10;
}

bool CMyPropertyPage::showPage(IConfigurationItem* pItem)
{
	if (!pItem)
		return false;
	pItem->show();
	
	if (CConfigurationHandlerImpl::hasActiveTemplate()) {
		::EnableWindow(::GetDlgItem(GetParent(),ID_APPLY_NOW), CConfigurationHandlerImpl::getActiveTemplate()->hasApply()?TRUE:FALSE);
		::EnableWindow(::GetDlgItem(GetParent(),IDOK), CConfigurationHandlerImpl::getActiveTemplate()->hasOk()?TRUE:FALSE);
		::EnableWindow(::GetDlgItem(GetParent(),IDCANCEL), CConfigurationHandlerImpl::getActiveTemplate()->hasCancel()?TRUE:FALSE);
	}

	m_helptext.SetWindowText(_T((pItem->getDescription() + "\nThis is the help text, select a control to see help here").c_str()));
	return true;
}

bool CMyPropertyPage::hidePage(IConfigurationItem* pItem)
{
	if (!pItem)
		return false;

	pItem->hide();
	return true;
}

bool CMyPropertyPage::addDialogItem(RECT rTree, IConfigurationDlgItem *itm)
{
	/*
	if (!itm)
		return false;
	SIZE s = {400, 400};
	itm->createDlgItem(this, m_hWnd, rTree.right-rTree.left+5, s);
	*/
	return true;
}

LRESULT CMyPropertyPage::OnSelChanged(int wParam, LPNMHDR lParam, BOOL bHandled)
{
	NMTREEVIEW *pnmtv = (LPNMTREEVIEW) lParam;
	IConfigurationItem *newItm = NULL;
	if (!pnmtv)
		return 0;

	if (pnmtv->itemOld.hItem)
		hidePage(reinterpret_cast<IConfigurationItem *>(m_tree.GetItemData(pnmtv->itemOld.hItem)));

	if (pnmtv->itemNew.hItem)
		showPage(reinterpret_cast<IConfigurationItem *>(m_tree.GetItemData(pnmtv->itemNew.hItem)));

	resizeControls();
	return 0;
}
void addMenuItem(CMenu &menu, string title, int id, bool enabled = true)
{
	MENUITEMINFO info;
	info.cbSize = sizeof(MENUITEMINFO);
	info.fType = MFT_STRING;
	info.fMask = MIIM_TYPE|MIIM_DATA|MIIM_ID|MIIM_STATE;
	info.fState = enabled?0:MFS_DISABLED;
	info.wID = id;
	info.cch = title.length();
	info.dwTypeData = (char*)title.c_str();
	menu.InsertMenuItem(id, TRUE, &info);
}
void addMenuSeparator(CMenu &menu, int id)
{
	MENUITEMINFO info;
	info.cbSize = sizeof(MENUITEMINFO);
	info.fType = MFT_SEPARATOR;
	info.fMask = MIIM_TYPE|MIIM_ID;
	info.wID = id;
	menu.InsertMenuItem(id, TRUE, &info);
}

LRESULT CMyPropertyPage::OnRightClick(int wParam, LPNMHDR lParam, BOOL bHandled)
{
	if (lParam->idFrom == CTL_TREE_ID) {
		POINT pos;
		GetCursorPos(&pos);
		m_tree.ScreenToClient(&pos);
		HTREEITEM hItm = m_tree.HitTest(pos, NULL);
		if (hItm == NULL)
			return 0;
		m_tree.SelectItem(hItm);

		IConfigurationItem *pItm = reinterpret_cast<IConfigurationItem*>(m_tree.GetItemData(hItm));
		if (!pItm)
			return 0;
		m_tree.ClientToScreen(&pos);

		CMenu menu;
		menu.CreatePopupMenu();
		addMenuItem(menu, pItm->getName(), 0, false);
		IConfigurationItem::LST_STRING children = pItm->getPosibleChildren();
		if (children.size() > 0) {
			addMenuSeparator(menu, 1);
			addMenuItem(menu, "Add new shortcut:", 2, false);
			int i = 100;
			for (IConfigurationItem::LST_STRING::iterator it = children.begin(); it!= children.end(); it++, i++) {
				addMenuItem(menu, (*it), i);
			}
		}
		addMenuSeparator(menu, 200);
		addMenuItem(menu, "Copy configuration:", 201, false);
		addMenuItem(menu, "This node", 202);
		addMenuItem(menu, "Recursivly", 203);
		addMenuSeparator(menu, 210);
		addMenuItem(menu, "Save step.rc", 211);
		int ret = menu.TrackPopupMenuEx(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RETURNCMD|TPM_NONOTIFY, pos.x, pos.y, m_hWnd);
		if ((ret >= 100)&&(ret <= 200)) {
			int i = 100;
			for (IConfigurationItem::LST_STRING::iterator it = children.begin(); it!= children.end(); it++, i++)
				if (i == ret)
					break;
			if (it == children.end()) {
				scErrorMessageSimpleParamEx(pItm, SCE_CANT_ADD_CHILD, 0);
				return 0;
			}
			IConfigurationItem *pNewItm = pItm->addNewChild((*it).c_str());
			parse(pNewItm, hItm);
		} else if (ret == 202) {
			copyToClipBoard(pItm->getStepRC(false));
		} else if (ret == 203) {
			copyToClipBoard(pItm->getStepRC(true));
		} else if (ret == 211) {
			if (!pItm->saveStepRC()) {
				::MessageBox(m_hWnd, _T("Saving falied!"), _T("Could not save STEP.RC"),MB_ICONERROR|MB_OK);
			}
		}
	}
	return 0;
}


BOOL CMyPropertyPage::OnApply()
{
	if (CConfigurationHandlerImpl::hasActiveTemplate()) 
		CConfigurationHandlerImpl::getActiveTemplate()->onApply();
	return TRUE;
}

BOOL CMyPropertyPage::OnOK()
{
	/*
	if (!m_pCurrentItem)
		return FALSE;
	IConfigurationDialog *dlgIF = m_pCurrentItem->getDialogInterface();
	if (!dlgIF)
		return FALSE;
	return dlgIF->onOk()?TRUE:FALSE;
	*/
		return TRUE;

}

bool CMyPropertyPage::copyToClipBoard(string str) {
	string::size_type pos = str.find("\n");
	while (pos != str.npos) {
		str.replace(pos, 1, "\r\n");
		pos = str.find("\n", pos+2);
	}
    LPTSTR  lptstrCopy;
    HGLOBAL hglbCopy;
    if (!OpenClipboard())
        return false;
    EmptyClipboard();
	hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (str.length() + 1) * sizeof(TCHAR));
	if (hglbCopy == NULL) { 
		CloseClipboard();
		return false;
	}
	
	lptstrCopy = reinterpret_cast<char*>(GlobalLock(hglbCopy));
	memcpy(lptstrCopy, str.c_str(), str.length()*sizeof(TCHAR));
	lptstrCopy[str.length()] = (TCHAR)0;
	GlobalUnlock(hglbCopy);
	SetClipboardData(CF_TEXT, hglbCopy);
    CloseClipboard();
    return true;
}

LRESULT CMyPropertyPage::OnBeginLableEdit(int wParam, LPNMHDR lParam, BOOL bHandled){
	NMTVDISPINFO *ptvdi = (LPNMTVDISPINFO) lParam;
	IConfigurationItem *pItm = reinterpret_cast<IConfigurationItem*>(m_tree.GetItemData(ptvdi->item.hItem));
	if (!pItm)
		return TRUE;
	if (!pItm->canRename())
		return TRUE;
	m_bLableEdit = true;
	return FALSE;
}

LRESULT CMyPropertyPage::OnEndLableEdit(int wParam, LPNMHDR lParam, BOOL bHandled){
	::SendMessage(::GetDlgItem(GetParent(),IDOK), BM_SETSTYLE, BS_DEFPUSHBUTTON|BS_TEXT, TRUE);
	NMTVDISPINFO *ptvdi = (LPNMTVDISPINFO) lParam;
	if (!ptvdi->item.pszText)
		return TRUE;
	IConfigurationItem *pItm = reinterpret_cast<IConfigurationItem*>(m_tree.GetItemData(ptvdi->item.hItem));
	if (!pItm)
		return TRUE;
	if (!pItm->setName(ptvdi->item.pszText))
		return TRUE;
	return FALSE;
}


LRESULT CMyPropertyPage::OnSetFocus(int wParam, LPNMHDR lParam, BOOL bHandled)
{
	::SendMessage(::GetDlgItem(GetParent(),IDOK), BM_SETSTYLE, BS_PUSHBUTTON|BS_TEXT, TRUE);
	return 0;
}
LRESULT CMyPropertyPage::OnKillFocus(int wParam, LPNMHDR lParam, BOOL bHandled)
{
	if (m_bLableEdit)
		return 0;
	::SendMessage(::GetDlgItem(GetParent(),IDOK), BM_SETSTYLE, BS_DEFPUSHBUTTON|BS_TEXT, TRUE);
	return 0;
}
