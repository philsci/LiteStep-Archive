// SettingsDialog.cpp: implementation of the CSettingsDialog class.
//
//////////////////////////////////////////////////////////////////////

#include "SettingsDialog.h"
#include "PropertyPage.h"
#include "IConfigurationItem.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAppModule _Module;

CSettingsDialog::CSettingsDialog(HINSTANCE hInstance) : m_hThread(NULL), m_pDlgPtr(NULL)
{
	HRESULT hRes = ::CoInitialize(NULL);
	if (FAILED(hRes))
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not initialize CoComBase: %x", hRes);

	::InitCommonControls();

	hRes = 	_Module.Init(NULL, hInstance);
	if (FAILED(hRes))
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not initialize Core WTL Module: %x", hRes);

}

CSettingsDialog::~CSettingsDialog()
{
	if (m_pDlgPtr) {
		::DestroyWindow(m_pDlgPtr->m_hWnd);
		m_pDlgPtr = NULL;
	}
	if (m_hThread)
		TerminateThread(m_hThread, 0);
	::CloseHandle(m_hThread);
	_Module.Term();
	::CoUninitialize();
}


void CSettingsDialog::show(HWND hWnd, IConfigurationItem *pItem, RECT r)
{
	MSG msg;
	::PeekMessage(&msg, NULL, WM_USER, WM_USER, PM_NOREMOVE);
	AddThread(hWnd, pItem, r);
}

// thread init param
struct _RunData
{
	HWND hWnd;
	RECT r;
	IConfigurationItem *pItem;
	CSettingsDialog *pCoreItem;
};

DWORD CSettingsDialog::AddThread(HWND hWnd, IConfigurationItem *pItem, RECT r)
{
	if (m_pDlgPtr) {
		::BringWindowToTop(m_pDlgPtr->m_hWnd);
		return 0;
	}
	_RunData* pData = new _RunData;
	pData->hWnd = hWnd;
	pData->pItem = pItem;
	pData->pCoreItem = this;
	pData->r = r;

	DWORD dwThreadID;
	m_hThread = ::CreateThread(NULL, 0, RunThread, pData, 0, &dwThreadID);
	if(!m_hThread)	{
		LSLogPrintf(LOG_ERROR, __FILE__, "Cannot create thread!");
		return 0;
	}
	return dwThreadID;
}

void CSettingsDialog::setDialog(CMyPropertySheet *pDlg) 
{
	m_pDlgPtr = pDlg;
}
// thread proc
DWORD WINAPI CSettingsDialog::RunThread(LPVOID lpData)
{
	_RunData *pData = reinterpret_cast<_RunData*>(lpData);

	CMyPropertyPage page(pData->pItem);
	CSettingsDialog *pCorePtr = pData->pCoreItem;
	HWND hWnd = pData->hWnd;
	delete pData;
	CMyPropertySheet pProperties;
	pCorePtr->setDialog(&pProperties);
	page.SetTitle(_T("Module configuration."));
	pProperties.SetTitle(_T("LiteStep configuration manager."));
	pProperties.changeWnd();
	pProperties.m_initRect = pData->r;
	if (!pProperties.AddPage(page))
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not add property page: %d", GetLastError());
	if (pProperties.DoModal(hWnd) == -1) 
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not create propertysheet: %d", GetLastError());
	pCorePtr->setDialog(NULL);
	::SendMessage(hWnd, WM_DESTROYSETTINGS, 0, 0);
	return 0;
}

HWND CSettingsDialog::getHWnd() {
	if (!m_pDlgPtr)
		return NULL;
	return m_pDlgPtr->m_hWnd;
}
