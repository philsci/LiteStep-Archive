// SettingsDialog.h: interface for the CSettingsDialog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SETTINGSDIALOG_H__45719766_69EA_4C10_9835_1AAF114E58C9__INCLUDED_)
#define AFX_SETTINGSDIALOG_H__45719766_69EA_4C10_9835_1AAF114E58C9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StdAtl.h"
#include <atlbase.h>
#include <atlwin.h>
#include <atlapp.h>
#include <atlframe.h>
#include <atlgdi.h>
#include <atlctrls.h>
#include <atldlgs.h>
#include "../lsapi/common.h"

#define WM_DESTROYSETTINGS WM_USER+123

#include "PropertySheet.h"
class CMyPropertySheet;
class IConfigurationItem;
class CSettingsDialog 
{
public:
	void show(HWND hWnd, IConfigurationItem *pItem, RECT r);
	CSettingsDialog(HINSTANCE hInstance);
	virtual ~CSettingsDialog();

	static DWORD WINAPI RunThread(LPVOID lpData);
	DWORD AddThread(HWND hWnd, IConfigurationItem *pItem, RECT r);
	void setDialog(CMyPropertySheet *pDlg);
	HWND getHWnd();
private:

	CMyPropertySheet *m_pDlgPtr;
	HANDLE m_hThread;
};

#endif // !defined(AFX_SETTINGSDIALOG_H__45719766_69EA_4C10_9835_1AAF114E58C9__INCLUDED_)
