// ShortcutGroup.cpp: implementation of the ShortcutGroup class.
//
//////////////////////////////////////////////////////////////////////

#include "ShortcutGroup.h"
#include "ShortcutFactory.h"
#include "string_util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFG_ITM_SET_TEMPLATE_CPP(CCIShortcutGroup, CCDTShortcutGroup);
CFG_ITM_SET_TEMPLATE_CPP(CCIStepRC, CCDTStepRC);

CShortcutGroup::CShortcutGroup(CShortcutFactory *pSf, string configLine) : IShortcut(pSf)
{
	m_iCommandArray[SCG_CMD_ADDSC]	= IShortcut::m_pFactory->getStringID("addToGroup");
	if (!configLine.empty())
		preAddConfig("addToGroup " + configLine);
}

CShortcutGroup::~CShortcutGroup()
{

}

void CShortcutGroup::preAddConfig(string str)
{
	if (str.substr(0,10) != "addToGroup") {
		m_sContainedStepRC += "*shortcutEx " + str + "\n";
	}
	IShortcut::preAddConfig(str);
}

void CShortcutGroup::createShortcut()
{
	/*
	for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++) {
		if ((*it).pSC)
			(*it).pSC->createShortcut();
	}
	*/
}

void CShortcutGroup::execBang(int iCmd, string szArg)
{
	if (iCmd == m_iCommandArray[SCG_CMD_ADDSC]) {
		addShortcut(szArg);
	} else {
		for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++) {
			if ((*it).pSC)
				(*it).pSC->execBang(iCmd, szArg);
		}
	}
}

void CShortcutGroup::addShortcut(string name)
{
	TYPE_SHORTCUT itm;
	itm.name = name;
	itm.pSC = IShortcut::m_pFactory->findShortcut(itm.name);
	m_lstShortcuts.push_front(itm);
	if (!itm.pSC) {
		LSLogPrintf(LOG_ERROR, __FILE__, "Shortcut (%s) not found in group: %s", name.c_str(), IShortcut::getName().c_str());
		return;
	}
}
/**
 *
 * setItems
 *
 * Description:
 * Sets the list with shortcuts and regets all shortcut interfaces.
 *
 * @created	2002-08-04 12:38
 * @author	MickeM <mickem@medin.nu>
 */
void CShortcutGroup::setItems(SC_LST items) {
	m_lstShortcuts = items;
	for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++) {
		(*it).pSC = IShortcut::m_pFactory->findShortcut((*it).name);
	}
}


void CShortcutGroup::MoveShortcut(int x, int y)
{
	for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++) {
		if ((*it).pSC)
			(*it).pSC->MoveShortcut(x, y);
	}
}

void CShortcutGroup::MoveShortcutDelta(int x, int y)
{
	for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++) {
		if ((*it).pSC)
			(*it).pSC->MoveShortcutDelta(x, y);
	}
}

bool CShortcutGroup::isCloseTo(int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY)
{
	return false;
//	::isCloseTo(x, y, cx, cy, span, matchX, matchY)
}


IConfigurationItem* CShortcutGroup::getConfigurationIF() {
	return new CCIShortcutGroup(this);
}

string CShortcutGroup::getStepRC(bool bRecursive) {
	string ret = ";\n";
	ret += "*shortcutEx \"" + CShortcutGroup::getShortName() + "\" \"" + IShortcut::getName() + "\"\n";
	for (SC_LST::iterator it = m_lstShortcuts.begin(); it != m_lstShortcuts.end(); it++)
		ret += "*ShortcutEx addToGroup " + (*it).name + "\n";
	ret += getContainedStepRC() + "\n";
	ret += "*shortcutEx ~" + CShortcutGroup::getShortName() + "\n";
	return ret;
}
