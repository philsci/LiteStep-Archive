// State.h: interface for the CState class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STATE_H__5879C140_EC6F_4662_9E37_C0EF4C583166__INCLUDED_)
#define AFX_STATE_H__5879C140_EC6F_4662_9E37_C0EF4C583166__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <string>
#include "../lsapi/lsapi.h"
#include "mmsystem.h"
#include "Bitmap.h"
#include "Action.h"
#include "IConfigurationItem.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "resource.h"


using namespace std;


#define S_CMD_IMAGE		1
#define S_CMD_COMMAND	2
#define S_CMD_CMDARG	3
#define S_CMD_SOUND		4
#define S_CMD_ALPHA		5
#define S_CMD_ICON		6
#define S_CMD_COUNT		7

#define MAX_ACTIONS		6
class IShortcutImpl;
class IConfigurationActionItem;
class CShortcutFactory;
class CState  
{
friend IConfigurationActionItem;
public:
	typedef enum ShortcutActions {ssNormal = 0 , ssHover = 1, ssRight = 2, ssLeft = 3, ssMiddle = 4, ssDrop = 5, ssNone};
protected:
public:
	bool execBang(int iCmd, string szArg);
	static ShortcutActions getAction(LPCSTR str);
	static ShortcutActions getAction(string str);
	static string getActionName(ShortcutActions action);
	void setAlpha(ShortcutActions action, int level);
	void setCommandArgument(ShortcutActions action, string command);
	void setCommand(ShortcutActions action, string command, string arguments = "");
	void setSound(ShortcutActions action, string sound);
	void setImage(ShortcutActions action, string command);
	CAction* getAction(ShortcutActions newAction, bool bCreate = true);
	void exec(CAction *pAction, HWND hWnd, string commandArguments);
	CState(CShortcutFactory *sf);
	virtual ~CState();

protected:
	CAction *m_currentAction;
	CAction *m_hover;
	CAction *m_normal;
	CAction *m_right;
	CAction *m_left;
	CAction *m_middle;
	CAction *m_drop;
	CShortcutFactory *m_pFactory;
	int m_iCommandArray[S_CMD_COUNT];
public:

	void exec(ShortcutActions action, HWND hWnd, string commandArguments);

	inline void setAction(ShortcutActions newAction) 
	{	
		m_currentAction = getAction(newAction, false);	
	}

	CLSBitmap* getBitmap(ShortcutActions action) {
		CAction *pAction = getAction(action, true);
		if (!pAction) {
			scErrorMessageSimpleNone(SCE_BAD_ACTION_ID, action);
			return NULL;
		}
		return pAction->getBitmap();
	}
	inline CLSBitmap* getBitmap() {
		if (!m_currentAction)
			return NULL;
		return m_currentAction->getBitmap();
	}
};



class CCIState : public CConfigurationItemImpl {
private:
	IShortcutImpl *pShortcut;
	CState *pState;
public:
	CCIState(CState *_pState, IShortcutImpl *_pShortcut) : pState(_pState), pShortcut(_pShortcut) {}
	virtual ~CCIState() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("States");
	CI_SET_DESCRIPTION("This is a wrapper for the states contained inside this shortcut");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_SET_STEPRC_RELAY_CHILDREN();
	CFG_ITM_SET_TEMPLATE_H(CCIState, CCDTState);

	CI_CHILD_BEGIN();
	ret.push_back(new CCIAction(pState->getAction(CState::ssNormal, true), pShortcut));
	ret.push_back(new CCIAction(pState->getAction(CState::ssHover, true), pShortcut));
	ret.push_back(new CCIAction(pState->getAction(CState::ssLeft, true), pShortcut));
	ret.push_back(new CCIAction(pState->getAction(CState::ssMiddle, true), pShortcut));
	ret.push_back(new CCIAction(pState->getAction(CState::ssRight, true), pShortcut));
	ret.push_back(new CCIAction(pState->getAction(CState::ssDrop, true), pShortcut));
	CI_CHILD_END();

};

class CCDTState : public CConfigurationDialogTemplateImplT<CCDTState>, public CDialogImpl<CCDTState>
{
public:
	enum { IDD = IDD_NO_CONFIGURATION };
	BEGIN_MSG_MAP(CCDTState);
	MESSAGE_HANDLER(WM_SIZE, OnSize)
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTState>);
	END_MSG_MAP();
	CCDTState(CCIState *pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTState>(pICH)	
	{}
	virtual ~CCDTState() {}

	virtual LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled) {
		HWND hWnd = GetDlgItem(IDC_NOCFG);
		RECT r;
		GetWindowRect(&r);
		::SetWindowPos(hWnd, NULL, 5, 5, r.right-r.left-10, r.bottom-r.top-10, SWP_NOZORDER|SWP_NOACTIVATE);
		::InvalidateRect(hWnd, NULL, NULL);
		return 0;
	}

};

#endif // !defined(AFX_STATE_H__5879C140_EC6F_4662_9E37_C0EF4C583166__INCLUDED_)
