#ifndef __INIT_H__
#define __INIT_H__

#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}


#endif // __INIT_H__