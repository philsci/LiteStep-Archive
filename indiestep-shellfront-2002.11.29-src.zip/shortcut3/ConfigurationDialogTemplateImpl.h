// ConfigurationDialogTemplateImpl.h: interface for the CConfigurationDialogTemplateImpl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONFIGURATIONDIALOGTEMPLATEIMPL_H__674005CF_EBAA_40F4_B8C8_6F599B7C8B35__INCLUDED_)
#define AFX_CONFIGURATIONDIALOGTEMPLATEIMPL_H__674005CF_EBAA_40F4_B8C8_6F599B7C8B35__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdatl.h"
#include <atlbase.h>
#include <windows.h>
#include <commctrl.h>
#include "resource.h"
#include <string>
#include <map>
#include "IConfigurationItem.h"

class IDataSaver;

template <class TRootWnd = CWindow, class TRootIF = IConfigurationDialogTemplate>
class CConfigurationDialogTemplateImplT : public TRootIF {
public:
	typedef std::map<UINT,std::string> mapIntStr;
	typedef std::list<IDataHandler*> lstDataHandler;

private:
	UINT m_uLastID;
	bool m_bCreated;
	bool m_bLoaded;
	mapIntStr m_mapHelpText;
	IConfigurationHandler *m_pHandler;
	lstDataHandler m_lstDataHandler;

public:
	BEGIN_MSG_MAP(CConfigurationDialogTemplateImplT)
		COMMAND_HANDLER(LOWORD(wParam), EN_SETFOCUS, setFocus);
		COMMAND_HANDLER(LOWORD(wParam), BN_SETFOCUS, setFocus);
	END_MSG_MAP()

public:
	CConfigurationDialogTemplateImplT(IConfigurationHandler *pHandler) 
		: TRootIF(pHandler), 
		m_bCreated(false), 
		m_pHandler(pHandler),
		m_uLastID(-1),
		m_bLoaded(false)
	{
	}
	virtual ~CConfigurationDialogTemplateImplT()
	{
		m_pHandler = NULL;
		clearDataHandlers();
	}
	
	//////////////////////////////////////////////////////////////////////////
	// Message handlers
	LRESULT setFocus(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		bHandled = FALSE;
		if (m_uLastID == uID)
			return 0;
		m_uLastID = uID;
		mapIntStr::iterator it = m_mapHelpText.find(uID);
		if (it != m_mapHelpText.end()) {
			setHelpText((*it).second);
			bHandled = TRUE;
		}
		return 0;
	}


	//////////////////////////////////////////////////////////////////////////
	// Helper Functions
	void addHelpText(UINT ctrl, std::string text) {
		m_mapHelpText[ctrl] = text;
	}

	//////////////////////////////////////////////////////////////////////////
	// IConfigurationDialogTemplate
	//
	void resize(int width, int height) {
		TRootWnd* pT = static_cast<TRootWnd*>(this);
		pT->SetWindowPos(NULL, 0, 0, width, height, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
	void move(int x, int y) {
		TRootWnd* pT = static_cast<TRootWnd*>(this);
		pT->SetWindowPos(NULL, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
	void createDialog(HWND hWndParrent) {
		if (!m_bCreated) {
			TRootWnd* pT = static_cast<TRootWnd*>(this);
			pT->Create(hWndParrent);
			m_bCreated = true;
		}
	}
	void destroyDialog() {
	}
	void show() {
		TRootWnd* pT = static_cast<TRootWnd*>(this);
		pT->ShowWindow(SW_NORMAL);
//		loadData();
	}
	void hide() {
		TRootWnd* pT = static_cast<TRootWnd*>(this);
		pT->ShowWindow(SW_HIDE);
	}
	void onApply() {
		saveData();
	}
	void onOk() {
		saveData();
	}
	void onCancel() {
		loadData();
	}

	virtual bool hasApply(){
		return true;
	}
	virtual bool hasOk() {
		return true;
	}
	virtual bool hasCancel() {
		return true;
	}

	void setHelpText(std::string text) {
		if (m_pHandler != NULL)
			m_pHandler->setHelpText(text);
	}

	HWND getHWnd() {
		TRootWnd* pT = static_cast<TRootWnd*>(this);
		return pT->m_hWnd;
	}

	void addDataHandler(IDataHandler *pHandler) {
		if (!pHandler) {
			LSLogPrintf(LOG_ERROR, __FILE__, "Cant setup datahandler");
			return;
		}
		pHandler->addTemplteIF(this);
		m_lstDataHandler.push_back(pHandler);
	}

	void clearDataHandlers() {
		m_bLoaded = false;
		lstDataHandler::iterator it = m_lstDataHandler.begin();
		for (;it!= m_lstDataHandler.end(); it++) {
			(*it)->removeTemplteIF(this);
			delete (*it);
		}
		m_lstDataHandler.clear();
	}

	bool removeDataHandler(IDataHandler *pHandler) {
		lstDataHandler::iterator it = m_lstDataHandler.begin();
		for (;it!= m_lstDataHandler.end(); it++) {
			if ((*it) == pHandler) {
				(*it)->removeTemplteIF(this);
				m_lstDataHandler.erase(it);
				delete pHandler;
				return true;
			}
		}
		return false;
	}

	void saveData() {
		if (!m_bLoaded)
			return;
		lstDataHandler::iterator it = m_lstDataHandler.begin();
		for (;it!= m_lstDataHandler.end(); it++) {
			(*it)->get();
		}
		onSaveData();
	}

	virtual void onSaveData() {}
	void loadData() {
		lstDataHandler::iterator it = m_lstDataHandler.begin();
		for (;it!= m_lstDataHandler.end(); it++) {
			(*it)->set();
		}
		onLoadData();
		m_bLoaded = true;
	}
	virtual void onLoadData() {}
	bool hasLoaded() {
		return m_bLoaded;
	}
};

class IDataHandlerImpl : public IDataHandler {
private:
	IConfigurationDialogTemplate *m_pTpl;
public:
	IDataHandlerImpl() : m_pTpl(NULL) {};
	virtual ~IDataHandlerImpl() {};

	void addTemplteIF(IConfigurationDialogTemplate *pTpl) {
		// TODO: add support for multiple templates.
		m_pTpl = pTpl;
	}
	void removeTemplteIF(IConfigurationDialogTemplate *pTpl) {
		onRemove(pTpl);
		// TODO: add check to see if the correct one is removed
		m_pTpl = NULL;
	}
	void set() {
		if (m_pTpl)
			iSet(m_pTpl);
	}
	void get() {
		if (m_pTpl)
			iGet(m_pTpl);
	}

	virtual LRESULT onMessageRelay(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		bHandled = FALSE;
		return 0;
	}
	virtual LRESULT onCommandRelay(HWND hDlgWnd, UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		bHandled = FALSE;
		return 0;
	}
	virtual void iSet(IConfigurationDialogTemplate *pTpl) = 0;
	virtual void iGet(IConfigurationDialogTemplate *pTpl) = 0;
	virtual void onRemove(IConfigurationDialogTemplate *pTpl) = 0;
};

class IDataSaverString : public IDataHandlerImpl {
public:
	UINT m_uID;
	IDataSaverString(UINT uID) : m_uID(uID) {}
	virtual ~IDataSaverString() {}

	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(""));
	}
	void iSet(IConfigurationDialogTemplate *pTpl) {
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(getValue().c_str()));
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		HWND hWnd = ::GetDlgItem(pTpl->getHWnd(), m_uID);
		int len = (WORD) ::SendMessage(hWnd, EM_LINELENGTH, (WPARAM)0, (LPARAM)0);
		if (len > 0) {
			char *c = new char[len+1];
			*((LPWORD)c) = len; 
			::SendMessage(hWnd, EM_GETLINE, (WPARAM)0, (LPARAM) c);
			c[len] = '\0';
			setValue(c);
			delete [] c;
		}
	}
	virtual void setValue(std::string value) = 0;
	virtual std::string getValue() = 0;
};


class IDataSaverMLString : public IDataHandlerImpl {
public:
	UINT m_uID;
	IDataSaverMLString(UINT uID) : m_uID(uID) {}
	virtual ~IDataSaverMLString() {}

	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(""));
	}
	void iSet(IConfigurationDialogTemplate *pTpl) {
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(getValue().c_str()));
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		HWND hWnd = ::GetDlgItem(pTpl->getHWnd(), m_uID);
		int len = (WORD) ::SendMessage(hWnd, WM_GETTEXTLENGTH, (WPARAM)0, (LPARAM)0);
		if (len > 0) {
			char *c = new char[len+1];
			::SendMessage(hWnd, WM_GETTEXT, (WPARAM)len, (LPARAM) c);
			c[len] = '\0';
			setValue(c);
			delete [] c;
		}
	}
	virtual void setValue(std::string value) = 0;
	virtual std::string getValue() = 0;
};
class CDataSaverString : public IDataSaverString {
public:
	std::string *m_str;
	CDataSaverString(UINT uID, std::string *str) : IDataSaverString(uID), m_str(str) {}
	virtual ~CDataSaverString() {}

	virtual void setValue(std::string value) {
		(*m_str) = value;
	}
	virtual std::string getValue() {
		return (*m_str);
	}
};

class CDataSaverCaption : public IDataHandlerImpl {
public:
	UINT m_uID;
	std::string m_str;
	CDataSaverCaption(UINT uID, std::string str) : m_uID(uID), m_str(str) {}
	virtual ~CDataSaverCaption() {}
	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(m_str.c_str()));
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(""));
	}
};

class CDataSaverBool : public IDataHandlerImpl {
public:
	UINT m_uID;
	CDataSaverBool(UINT uID) : m_uID(uID) {}
	virtual ~CDataSaverBool() {}
	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), BM_SETCHECK, (WPARAM)(getValue())?BST_CHECKED:BST_UNCHECKED, (LPARAM)0);
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		setValue(::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), BM_GETCHECK, (WPARAM)0, (LPARAM)0) == BST_CHECKED);
	}
	virtual void setValue(bool value) = 0;
	virtual bool getValue() = 0;
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), BM_SETCHECK, (WPARAM)BST_UNCHECKED, (LPARAM)0);
	}
};

class CDataSaverInt : public IDataHandlerImpl {
public:
	UINT m_uID;
	CDataSaverInt(UINT uID) : m_uID(uID) {}
	virtual ~CDataSaverInt() {}
	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T((IConfigurationHelpers::itos(getValue())).c_str()));
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		HWND hWnd = ::GetDlgItem(pTpl->getHWnd(), m_uID);
		int len = (WORD) ::SendMessage(hWnd, EM_LINELENGTH, (WPARAM)0, (LPARAM)0);
		if (len > 0) {
			char *c = new char[len+1];
			*((LPWORD)c) = len; 
			::SendMessage(hWnd, EM_GETLINE, (WPARAM)0, (LPARAM) c);
			c[len] = '\0';
			setValue(atoi(c));
			delete [] c;
		}
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		::SendMessage(::GetDlgItem(pTpl->getHWnd(), m_uID), WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)_T(""));
	}
	virtual void setValue(int value) = 0;
	virtual int getValue() = 0;
};

/**
 *
 * CDataSaverFtor
 *
 * Description:
 * This is an endwrapper for all savers to link them to a functor set.
 *
 * @created	2002-07-23 10:47
 * @author	MickeM <mickem@medin.nu>
 */
template <class TRoot, class TType, class TTarget>
class CDataSaverFtor : public TRoot {
	void (TTarget::*fptSetter)(TType);
	TType (TTarget::*fptGetter)();
	TTarget* pt2Object;
public:
	CDataSaverFtor(UINT uID, TTarget* _pt2Object, void(TTarget::*_fptSetter)(TType), TType(TTarget::*_fptGetter)()) : 
		TRoot(uID) ,
		pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CDataSaverFtor() {}
	void setValue(TType value) {
		(*pt2Object.*fptSetter)(value);
	}
	TType getValue() {
		return (*pt2Object.*fptGetter)();
	}
};
#endif // !defined(AFX_CONFIGURATIONDIALOGTEMPLATEIMPL_H__674005CF_EBAA_40F4_B8C8_6F599B7C8B35__INCLUDED_)
