// ShortcutFactory.h: interface for the CShortcutFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHORTCUTFACTORY_H__C5040D55_7918_43C4_9696_9A3F69FEC65A__INCLUDED_)
#define AFX_SHORTCUTFACTORY_H__C5040D55_7918_43C4_9696_9A3F69FEC65A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <string>
#include <list>
#ifdef _COOL_STL
#	include <slist>
#endif
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"
#include "state.h"
#include "IConfigurationItem.h"

#ifndef TTS_BALLOON
# define TTS_BALLOON 0x40
#endif
using namespace std;

#define SF_CONFIG	1
#define SF_CMD_COUNT	10

#include "ConfigurationDialogTemplateImpl.h"


class IShortcut;
class IShortcutImpl;
class CNormalShortcut;
class CSimpleShortcut;
class CShortcutGroup;
class CSettingsDialog;
class CCDTShortcutFactory;
class CShortcutFactory : public Window
{
friend IShortcut;
friend IShortcutImpl;
friend CNormalShortcut;
friend CSimpleShortcut;
friend CShortcutGroup;
friend CState;
public:
	typedef list < pair < string, string > > T_LST_STRSTR;
	typedef list<IShortcut*> T_LST_SC;
public:
	void renameShortcut(string oldName, string newName, IShortcut *pIf);
	T_LST_SC getShortcutList();
	IShortcut* findShortcut(string name);
	void execOldBang(string cmd, string targets, string parameters);
	void execBang(string targets, string cmd, string parameters);
	void playSound(CState::ShortcutActions action);
	CShortcutFactory(HWND parentWnd, int& code, HWND desktopWnd);
	virtual ~CShortcutFactory();
	HWND getDesktopWindow();


public:
	// properties:
	RECT getSettingsPos();
	int getShortcutCount();
	string getSound(CState::ShortcutActions action);
	void setSound(CState::ShortcutActions action, string sound);
	IConfigurationItem* getConfigurationIF();
	void setUseBaloonTips(bool b);
	bool getUseBaloonTips();
	void setSnapSpace(int i);
	int getSnapSpace();


protected:
	string getIDString(int iCmd);
	int getStringID(string str);
	void onWindowPosChanging(WINDOWPOS *pos);
	void relayHintMessage(HWND hWnd, Message& message);
	void addHint(HWND hWnd, LPSTR caption);
	void removeHint(HWND hWnd);

	void setTopMost(LPCSTR groups, int topMost);

	static void bangGroupToggle(HWND sender, LPCSTR args);
	static void bangGroupShow(HWND sender, LPCSTR args);
	static void bangGroupHide(HWND sender, LPCSTR args);
	static void bangGroupOnTop(HWND sender, LPCSTR args);
	static void bangGroupOnBottom(HWND sender, LPCSTR args);
	static void bangGroupOnTopToggle(HWND sender, LPCSTR args);
	static void bangShortcut(HWND sender, LPCSTR args);

	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onGetRevId(Message& message);
	void onRefresh(Message& message);
	void onDestroyConfig(Message& message);

private:
	void createShortcuts();
	void parseConfig(IShortcut *newShortcut, FILE *step);
	void parseOldConfig(IShortcut *sc, string szConfigLine);
	void destroyShortcuts();
	void addShortcut(IShortcut *newShortcut);
	void parseStepRC();
	
	typedef map<string,IShortcut*> T_MAP_STR_SC;
	typedef map<string,int> T_MAP_STR_INT;

	T_MAP_STR_SC m_mapShortcuts;
	T_MAP_STR_INT m_mapStrings;
	T_LST_SC m_lstShortcuts;
	T_LST_STRSTR m_lstShortcutTypes;

	CRITICAL_SECTION m_cs;
	int m_iCommandArray[SF_CMD_COUNT];
	string m_sShortcutSound[MAX_ACTIONS];
	HWND fShortcutHints;
	bool m_bBaloonTip;
	HWND m_hDesktopWnd;
	int m_iSnapSpace;
	CSettingsDialog *m_pSettingsDialog;
	string m_sShortcutFile;

private:
	IShortcut* createShortcut(string type, string name, string arguments, bool makeList = false);
public:
	string getStepRC(bool bRecursive);
	bool saveStepRC();
	T_LST_STRSTR getShortuctutTypes() {
		return m_lstShortcutTypes;
	}
	IShortcut* addNewShortcut(string type, string name);
};

class CSFSoundSaver : public IDataSaverString {
public:
	std::string *m_str;
	CState::ShortcutActions m_action;
	CShortcutFactory *m_pFactory;
	CSFSoundSaver(UINT uID, CShortcutFactory *pFactory, CState::ShortcutActions action) : IDataSaverString(uID), m_pFactory(pFactory), m_action(action) {}
	virtual ~CSFSoundSaver() {}

	void setValue(string value) {
		if (m_pFactory)
			m_pFactory->setSound(m_action, value);
	}
	virtual string getValue() {
		if (!m_pFactory)
			return "";
		return m_pFactory->getSound(m_action);
	}
};

class CCIShortcutFactory : public CConfigurationItemImpl {
private:
	CShortcutFactory *pFactory;
public:
	///////////////////////////////////////////////////////////////////
	// IConfigurationItem
	CCIShortcutFactory(CShortcutFactory *_pFactory) : pFactory(_pFactory)
	{}
	virtual ~CCIShortcutFactory() {}

	CFG_ITM_SET_TEMPLATE_H(CCIShortcutFactory, CCDTShortcutFactory);
	CI_SET_VERIFY_ALWAYS(pFactory);
	CI_SET_NAME_STATIC("Shortcut ]I[");
	CI_SET_DESCRIPTION("This is the root of the shortcuts...");
	CI_SET_ICON_DISABLED();
	CI_SET_DELETE_DISABLED();
	CI_SET_STEPRC_RELAY(pFactory);
	CI_SET_SAVERC_RELAY(pFactory);


	LST_CHILD getChildren();
	bool hasChildren() {return true;}
	LST_STRING getPosibleChildren() {
		LST_STRING ret;
		CShortcutFactory::T_LST_STRSTR lst = pFactory->getShortuctutTypes();
		for (CShortcutFactory::T_LST_STRSTR::iterator it = lst.begin(); it != lst.end(); it++) {
			ret.push_back((*it).second);
		}
		return ret;
	}

	// Methogs
	IConfigurationItem* addNewChild(string type);
	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CDataSaverCaption(IDC_SC_COUNT, "Shortcut count: " + IConfigurationHelpers::itos(pFactory->getShortcutCount())));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_NORMAL, pFactory, CState::ssNormal));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_HOVER, pFactory, CState::ssHover));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_RIGHT, pFactory, CState::ssRight));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_LEFT, pFactory, CState::ssLeft));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_MIDDLE, pFactory, CState::ssMiddle));
		pTpl->addDataHandler(new CSFSoundSaver(IDC_SOUND_DRAG, pFactory, CState::ssDrop));
		pTpl->addDataHandler(new CDataSaverFtor<CDataSaverBool, bool, CShortcutFactory>(IDC_USE_BALOON, pFactory, CShortcutFactory::setUseBaloonTips, CShortcutFactory::getUseBaloonTips));
		pTpl->addDataHandler(new CDataSaverFtor<CDataSaverInt, int, CShortcutFactory>(IDC_SNAP_SPACE, pFactory, CShortcutFactory::setSnapSpace, CShortcutFactory::getSnapSpace));
	}
};


class CCDTShortcutFactory : public CConfigurationDialogTemplateImplT<CCDTShortcutFactory>, public CDialogImpl<CCDTShortcutFactory>
{
public:
	enum { IDD = IDD_SHORTCUTFACTORY };
	BEGIN_MSG_MAP(CCDTShortcutFactory);
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTShortcutFactory>);
	END_MSG_MAP();
	CCDTShortcutFactory(CCIShortcutFactory *pFactory, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTShortcutFactory>(pICH)	
	{
		addHelpText(IDC_SOUND_HOVER, "Sound for hovering the shortcut");
		addHelpText(IDC_USE_BALOON, "Use ballontips. (Only availible on w2k/xp).");
		addHelpText(IDC_SNAP_SPACE, "Snap distance used when you move the shortcuts.");
		addHelpText(IDC_SOUND_NORMAL, "Sound used when a shortcut reverts back after a state.");
		addHelpText(IDC_SOUND_HOVER, "Sound used when a shortcut is hoverd.");
		addHelpText(IDC_SOUND_RIGHT, "Sound used when a shortcut is clicked.");
		addHelpText(IDC_SOUND_LEFT, "Sound used when a shortcut is clicked.");
		addHelpText(IDC_SOUND_MIDDLE, "Sound used when a shortcut is clicked.");
		addHelpText(IDC_SOUND_DRAG, "Sound used when a file is drag onto a shortcut.");
	}
	virtual ~CCDTShortcutFactory() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		onRefresh();
		saveData();
		return 0;
	}
	void onRefresh() {
	}
};

// Locking class, should probably move to some utility files
class CLock
{
public:
	CLock(CRITICAL_SECTION &cs) : m_cs(cs) {
		EnterCriticalSection(&m_cs);
	}
	~CLock() {
		LeaveCriticalSection(&m_cs);
	}

protected:
	CRITICAL_SECTION &m_cs;
};

#endif // !defined(AFX_SHORTCUTFACTORY_H__C5040D55_7918_43C4_9696_9A3F69FEC65A__INCLUDED_)

