// CFGTemplates.h: Helper-classes: various Configuration Templates.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__CFGTemplates_H__INCLUDED_)
#define __CFGTemplates_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// WTL Includes
#include "StdAtl.h"
#include <AtlCtrls.h>
// LS Includes
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"
// STL/Standrd includes
#include <string>
#include <limits.h>
// SC3 Includes
#include "IConfigurationItem.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "IShortcut.h"
#include "IShortcutImpl.h"
using namespace std;





/**
 *
 * CISIPosition - class interface Shortcut Implementation Position
 *
 * Description:
 * Class for handeling the data of a position block.
 *
 * @created	2002-07-26 00:24
 * @author	MickeM <mickem@medin.nu>
 */
class CISIPosition : public IDataHandlerImpl {
private:
	IShortcutImpl *pt2Object;
	void (IShortcutImpl::*fptSetter)(POSITION);
	POSITION (IShortcutImpl::*fptGetter)();
public:
	CISIPosition(IShortcutImpl *_pt2Object, void (IShortcutImpl::*_fptSetter)(POSITION), POSITION (IShortcutImpl::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CISIPosition() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		POSITION pos = (*pt2Object.*fptGetter)();
		if (pos.centerd.x) {
			::SendMessage(GetDlgItem(hWnd, IDC_X_C), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_X, IConfigurationHelpers::itos(pos.x));
		} else if (pos.x < 0) {
			::SendMessage(GetDlgItem(hWnd, IDC_X_R), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_X, IConfigurationHelpers::itos(-pos.x));
		} else {
			::SendMessage(GetDlgItem(hWnd, IDC_X_L), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_X, IConfigurationHelpers::itos(pos.x));
		}
		if (pos.centerd.y) {
			::SendMessage(GetDlgItem(hWnd, IDC_Y_C), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_Y, IConfigurationHelpers::itos(pos.y));
		} else if (pos.y < 0) {
			::SendMessage(GetDlgItem(hWnd, IDC_Y_B), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_Y, IConfigurationHelpers::itos(-pos.y));
		} else {
			::SendMessage(GetDlgItem(hWnd, IDC_Y_T), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_Y, IConfigurationHelpers::itos(pos.y));
		}
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		POSITION pos;
		pos.centerd.x = false;
		pos.centerd.y = false;
		pos.x = IConfigurationHelpers::stoi(IConfigurationHelpers::GetTextBoxText(hWnd, IDC_X));
		pos.y = IConfigurationHelpers::stoi(IConfigurationHelpers::GetTextBoxText(hWnd, IDC_Y));
		if (::SendMessage(GetDlgItem(hWnd, IDC_X_C), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			pos.centerd.x = true;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_X_R), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			pos.x = - pos.x;
		} 
		if (::SendMessage(GetDlgItem(hWnd, IDC_Y_C), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			pos.centerd.y = true;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_Y_B), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			pos.y = - pos.y;
		} 
		(*pt2Object.*fptSetter)(pos);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		// TODO: Implement this
	}
};


class CCIPosition : public CConfigurationItemImpl {
private:
	IShortcutImpl *pObj;
public:
	CCIPosition(IShortcutImpl *_pObj)
		: pObj(_pObj)
	{}
	virtual ~CCIPosition() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("Position");
	CI_SET_DESCRIPTION("The position of the object.");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();
	CI_SET_STEPRC_SIMPLE_EX("; Unimplemented on this level. Refer to the parrent node.", "");

	// Methogs
	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	CFG_ITM_SET_TEMPLATE_H(CCIPosition, CCDTPosition);
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CISIPosition(pObj, IShortcutImpl::setPosition, IShortcutImpl::getPosition));
	}
};



class CCDTPosition : public CConfigurationDialogTemplateImplT<CCDTPosition>, public CDialogImpl<CCDTPosition>
{
private:

public:
	enum { IDD = IDD_POSITION_CFG };
	BEGIN_MSG_MAP(CCDTPosition);
	MESSAGE_HANDLER(WM_INITDIALOG,onInitDialog);
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTPosition>);
	END_MSG_MAP();
	CCDTPosition(void* _pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTPosition>(pICH)
	{
		addHelpText(IDC_X_L, "Align to the left edge of the screen.");
		addHelpText(IDC_X_C, "Align to the centre of the screen.");
		addHelpText(IDC_X_R, "Align to the right edge of the screen.");
		addHelpText(IDC_Y_T, "Align to the top edge of the screen.");
		addHelpText(IDC_Y_C, "Align to the centre of the screen.");
		addHelpText(IDC_Y_B, "Align to the bottom edge of the screen.");
		addHelpText(IDC_X, "Screen pixels in horizontal (X) direction from the anchor point.");
		addHelpText(IDC_Y, "Screen pixels in vertical (Y) direction from the anchor point.");
	}
	virtual ~CCDTPosition() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		saveData();
		return 0;
	}
	void onRefresh() {
	}
	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		SendDlgItemMessage(IDC_SPIN_X, UDM_SETRANGE32, _I32_MIN, _I32_MAX);
		SendDlgItemMessage(IDC_SPIN_Y, UDM_SETRANGE32, _I32_MIN, _I32_MAX);
		return 0;
	}
};




/**
 *
 * CISIZOrder - class interface Shortcut Implementation ZORder
 *
 * Description:
 * Class for handeling the data of a Z-order block.
 *
 * @created	2002-07-26 00:24
 * @author	MickeM <mickem@medin.nu>
 */
class CISIZOrder : public IDataHandlerImpl {
private:
	IShortcutImpl *pt2Object;
	void (IShortcutImpl::*fptSetter)(IShortcutImpl::SHORTCUTORWINDOW);
	IShortcutImpl::SHORTCUTORWINDOW (IShortcutImpl::*fptGetter)();
public:
	CISIZOrder(IShortcutImpl *_pt2Object, void (IShortcutImpl::*_fptSetter)(IShortcutImpl::SHORTCUTORWINDOW), IShortcutImpl::SHORTCUTORWINDOW (IShortcutImpl::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CISIZOrder() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		IShortcutImpl::SHORTCUTORWINDOW sc = (*pt2Object.*fptGetter)();
		::SendMessage(GetDlgItem(hWnd, IDC_NA), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_ONTOP), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_TOP), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_BOTTOM), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_AFTER_SC), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_AFTER_WND), BM_SETCHECK, BST_UNCHECKED, 0);
		if (sc.hWnd == HWND_TOPMOST) {
			::SendMessage(GetDlgItem(hWnd, IDC_ONTOP), BM_SETCHECK, BST_CHECKED, 0);
		} else if (sc.hWnd == HWND_TOP) {
			::SendMessage(GetDlgItem(hWnd, IDC_TOP), BM_SETCHECK, BST_CHECKED, 0);
		} else if (sc.hWnd == HWND_BOTTOM) {
			::SendMessage(GetDlgItem(hWnd, IDC_BOTTOM), BM_SETCHECK, BST_CHECKED, 0);
		} else if (sc.hWnd == HWND_NOTOPMOST) {
			::SendMessage(GetDlgItem(hWnd, IDC_NA), BM_SETCHECK, BST_CHECKED, 0);
		} else if (!sc.scName.empty()) {
			::SendMessage(GetDlgItem(hWnd, IDC_AFTER_SC), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_SEL_SC, sc.scName);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_DIST, IConfigurationHelpers::itos(sc.data));
		} else if ((!sc.wndClass.empty()) || (!sc.wndTitle.empty())) {
			::SendMessage(GetDlgItem(hWnd, IDC_AFTER_WND), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_WND_CLS, sc.wndClass);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_WND_CAP, sc.wndTitle);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_DIST, IConfigurationHelpers::itos(sc.data));
		}
		if (!pt2Object)
			return;
		if (!pt2Object->getFactory())
			return;
		CShortcutFactory::T_LST_SC lst = pt2Object->getFactory()->getShortcutList();
		::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
		
		for (CShortcutFactory::T_LST_SC::iterator it = lst.begin(); it!=lst.end();it++) {
			if (!(*it)->getName().empty())
				::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_ADDSTRING, (WPARAM)0, (LPARAM)(*it)->getName().c_str());
		}
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		IShortcutImpl::SHORTCUTORWINDOW sc;
		if (::SendMessage(GetDlgItem(hWnd, IDC_ONTOP), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.hWnd = HWND_TOPMOST;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_TOP), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.hWnd = HWND_TOP;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_BOTTOM), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.hWnd = HWND_BOTTOM;
		} else {
			sc.hWnd = HWND_NOTOPMOST;
		} 
		if (::SendMessage(GetDlgItem(hWnd, IDC_AFTER_SC), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.scName = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_SEL_SC);
			sc.data = IConfigurationHelpers::stoi(IConfigurationHelpers::GetTextBoxText(hWnd, IDC_DIST));
		} else {
			sc.scName = "";
		}

		if (::SendMessage(GetDlgItem(hWnd, IDC_AFTER_WND), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.wndClass = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_WND_CLS);
			sc.wndTitle = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_WND_CAP);
			sc.data = IConfigurationHelpers::stoi(IConfigurationHelpers::GetTextBoxText(hWnd, IDC_DIST));
		} else {
			sc.wndClass = "";
			sc.wndTitle = "";
		}
		(*pt2Object.*fptSetter)(sc);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		// TODO: Implement this
	}
};

class CCIZOrder : public CConfigurationItemImpl {
private:
	IShortcutImpl *pSCImpl;
public:
	CCIZOrder(IShortcutImpl *_pSCImpl) : pSCImpl(_pSCImpl) {}
	virtual ~CCIZOrder() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("Z-Order");
	CI_SET_DESCRIPTION("Setup the z-order");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();
	CFG_ITM_SET_TEMPLATE_H(CCIZOrder, CCDTZOrder);

	string getStepRC(bool bRecursive) {
		if (pSCImpl->getZOrder().hWnd == HWND_TOP)
			return "*shortcutEx z-order top\n";
//		else if (pSCImpl->getZOrder().hWnd == HWND_TOPMOST)
//			return "*shortcutEx z-order topmost\n";
		else if (pSCImpl->getZOrder().hWnd == HWND_BOTTOM)
			return "*shortcutEx z-order bottom\n";
		else if ((!pSCImpl->getZOrder().scName.empty())||
				(!pSCImpl->getZOrder().wndClass.empty())||
				(!pSCImpl->getZOrder().wndTitle.empty()))
		{
			if (pSCImpl->getZOrder().data == 0)
				return "*shortcutEx z-order after \"" + pSCImpl->getZOrder().scName + "\" \"" + pSCImpl->getZOrder().wndClass + "\" \"" + pSCImpl->getZOrder().wndTitle + "\" \n";
			return "*shortcutEx z-order after \"" + pSCImpl->getZOrder().scName + "\" \"" + pSCImpl->getZOrder().wndClass + "\" \"" + pSCImpl->getZOrder().wndTitle + "\" " + IConfigurationHelpers::itos(pSCImpl->getZOrder().data) + "\n";
		} else {
			return "";
		}
	}
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		pTpl->addDataHandler(new CISIZOrder(pSCImpl, IShortcutImpl::setZOrder, IShortcutImpl::getZOrder));
	}
};



class CCDTZOrder : public CConfigurationDialogTemplateImplT<CCDTZOrder>, public CDialogImpl<CCDTZOrder>
{
private:
	IConfigurationHelpers::CWindowFinder finder;

public:
	enum { IDD = IDD_ZORDER_CFG };
	BEGIN_MSG_MAP(CCDTZOrder);
	if (finder.ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult))  
		 return TRUE;
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTZOrder>);
	END_MSG_MAP();
	CCDTZOrder(CCIZOrder *_pSC, IConfigurationHandler *pICH) 
		: CConfigurationDialogTemplateImplT<CCDTZOrder>(pICH),
		finder(_Module.GetModuleInstance(), IDC_GRABBER, IDC_WND_CLS, IDC_WND_CAP, IDC_GRABBER)
	{
		addHelpText(IDC_NA, "Dont care about the Z-order.");
		addHelpText(IDC_TOP, "Put the shortcut over other windows (not topmost).");
		addHelpText(IDC_ONTOP, "Always put the shortcut over other non topmost windows.");
		addHelpText(IDC_BOTTOM, "Put the shortcut on the bottom (not bottom most).");
		addHelpText(IDC_AFTER_SC, "Put the shortcut after another shortcut.");
		addHelpText(IDC_AFTER_WND, "Put the shortcut after another window.");
		addHelpText(IDC_WND_CLS, "The class of the window, use the locator on the right to find a window.");
		addHelpText(IDC_WND_CAP, "The caption/title of the window, use the locator on the right to find a window. IF this is empty the first window of the class above will be used.");
		addHelpText(IDC_DIST, "This is the distance from the window that the shortcut will apere. set this to -1 to make the shortcut just before another window.");

	}
	virtual ~CCDTZOrder() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		saveData();
		return 0;
	}
	void onRefresh() {
		::EnableWindow(GetDlgItem(IDC_SEL_SC), (::SendMessage(GetDlgItem(IDC_AFTER_SC), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_WND_CAP), (::SendMessage(GetDlgItem(IDC_AFTER_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_WND_CLS), (::SendMessage(GetDlgItem(IDC_AFTER_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_GRABBER), (::SendMessage(GetDlgItem(IDC_AFTER_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		BOOL bHanveAny = ((::SendMessage(GetDlgItem(IDC_AFTER_SC), BM_GETCHECK, 0, 0)==BST_CHECKED)||
			(::SendMessage(GetDlgItem(IDC_AFTER_WND), BM_GETCHECK, 0, 0)==BST_CHECKED))?TRUE:FALSE;
		::EnableWindow(GetDlgItem(IDC_DIST), bHanveAny);
		::EnableWindow(GetDlgItem(IDC_DIST_SPIN), bHanveAny);
	}
	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		SendDlgItemMessage(IDC_DIST_SPIN, UDM_SETRANGE32, _I32_MIN, _I32_MAX);
		return 0;
	}
};



/**
 *
 * CISIParrent - class interface Shortcut Implementation ZORder
 *
 * Description:
 * Class for handeling the data of a Z-order block.
 *
 * @created	2002-07-26 00:24
 * @author	MickeM <mickem@medin.nu>
 */
class CISIParrent : public IDataHandlerImpl {
private:
	IShortcutImpl *pt2Object;
	void (IShortcutImpl::*fptSetter)(IShortcutImpl::SHORTCUTORWINDOW);
	IShortcutImpl::SHORTCUTORWINDOW (IShortcutImpl::*fptGetter)();
public:
	CISIParrent(IShortcutImpl *_pt2Object, void (IShortcutImpl::*_fptSetter)(IShortcutImpl::SHORTCUTORWINDOW), IShortcutImpl::SHORTCUTORWINDOW (IShortcutImpl::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CISIParrent() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		IShortcutImpl::SHORTCUTORWINDOW sc = (*pt2Object.*fptGetter)();
		::SendMessage(GetDlgItem(hWnd, IDC_NA), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_DESKTOP), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_SC), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_USE_SC), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_USE_WND), BM_SETCHECK, BST_UNCHECKED, 0);
		if (sc.data == 1) {
			::SendMessage(GetDlgItem(hWnd, IDC_NA), BM_SETCHECK, BST_CHECKED, 0);
		} else if (sc.data == 2) {
			::SendMessage(GetDlgItem(hWnd, IDC_DESKTOP), BM_SETCHECK, BST_CHECKED, 0);
		} else if (sc.data == 3) {
			::SendMessage(GetDlgItem(hWnd, IDC_SC), BM_SETCHECK, BST_CHECKED, 0);
		} else if (!sc.scName.empty()) {
			::SendMessage(GetDlgItem(hWnd, IDC_USE_SC), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_SEL_SC, sc.scName);
		} else if ((!sc.wndClass.empty()) || (!sc.wndTitle.empty())) {
			::SendMessage(GetDlgItem(hWnd, IDC_USE_WND), BM_SETCHECK, BST_CHECKED, 0);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_WND_CLS, sc.wndClass);
			IConfigurationHelpers::SetTextBoxText(hWnd, IDC_WND_CAP, sc.wndTitle);
		}
		if (!pt2Object)
			return;
		if (!pt2Object->getFactory())
			return;
		CShortcutFactory::T_LST_SC lst = pt2Object->getFactory()->getShortcutList();
		::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
		
		for (CShortcutFactory::T_LST_SC::iterator it = lst.begin(); it!=lst.end();it++) {
			if (!(*it)->getName().empty())
				::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_ADDSTRING, (WPARAM)0, (LPARAM)(*it)->getName().c_str());
		}
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		IShortcutImpl::SHORTCUTORWINDOW sc;
		if (::SendMessage(GetDlgItem(hWnd, IDC_NA), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.data = 1;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_DESKTOP), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.data = 2;
		} else if (::SendMessage(GetDlgItem(hWnd, IDC_SC), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.data = 3;
		} else {
			sc.data = 0;
		} 
		if (::SendMessage(GetDlgItem(hWnd, IDC_USE_SC), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.scName = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_SEL_SC);
		} else {
			sc.scName = "";
		}

		if (::SendMessage(GetDlgItem(hWnd, IDC_USE_WND), BM_GETCHECK, 0, 0) == BST_CHECKED) {
			sc.wndClass = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_WND_CLS);
			sc.wndTitle = IConfigurationHelpers::GetTextBoxText(hWnd, IDC_WND_CAP);
		} else {
			sc.wndClass = "";
			sc.wndTitle = "";
		}
		(*pt2Object.*fptSetter)(sc);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		// TODO: Implement this
	}
};

class CCIParrent : public CConfigurationItemImpl {
private:
	IShortcutImpl *pSCImpl;
public:
	CCIParrent(IShortcutImpl *_pSCImpl) : pSCImpl(_pSCImpl) {}
	virtual ~CCIParrent() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("Parrent");
	CI_SET_DESCRIPTION("Setup the z-order");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();

	string getStepRC(bool bRecursive) {
		if (pSCImpl->getParrentWindow().data == 1)
			return "*shortcutEx parrent none\n";
		else if (pSCImpl->getParrentWindow().data == 2)
			return "*shortcutEx parrent desktop\n";
		else if (pSCImpl->getParrentWindow().data == 3)
			return "*shortcutEx parrent shortcut\n";
		else if (!pSCImpl->getParrentWindow().scName.empty())
			return "*shortcutEx parrent use \"\" \"\" " + pSCImpl->getParrentWindow().scName + "\n";
		else if ((!pSCImpl->getParrentWindow().wndClass.empty())||(!pSCImpl->getParrentWindow().wndTitle.empty()))
			return "*shortcutEx parrent use \"" + pSCImpl->getParrentWindow().wndClass + "\" \"" + pSCImpl->getParrentWindow().wndTitle + "\"\n";
		else
			return "";
	}

	CFG_ITM_SET_TEMPLATE_H(CCIParrent, CCDTParrent);
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CISIParrent(pSCImpl, IShortcutImpl::setParrentWindow, IShortcutImpl::getParrentWindow));
	}
};



class CCDTParrent : public CConfigurationDialogTemplateImplT<CCDTParrent>, public CDialogImpl<CCDTParrent>
{
private:
	IConfigurationHelpers::CWindowFinder finder;
public:
	enum { IDD = IDD_PARRENT_CFG };
	BEGIN_MSG_MAP(CCDTParrent);
	if (finder.ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult))  
		 return TRUE;
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTParrent>);
	END_MSG_MAP();
	CCDTParrent(CCIParrent *_pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTParrent>(pICH),
		finder(_Module.GetModuleInstance(), IDC_GRABBER, IDC_WND_CLS, IDC_WND_CAP, IDC_GRABBER)
	{
		addHelpText(IDC_NA, "Shortcut will be its own layer.");
		addHelpText(IDC_DESKTOP, "Put the shortcut on the desktop layer.");
		addHelpText(IDC_SC, "Put the shortcut on the shortcut layer.");
		addHelpText(IDC_USE_SC, "Use another shortcut as a layer.");
		addHelpText(IDC_USE_WND, "Use another window as a layer.");
	}
	virtual ~CCDTParrent() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		saveData();
		return 0;
	}
	void onRefresh() {
		::EnableWindow(GetDlgItem(IDC_SEL_SC), (::SendMessage(GetDlgItem(IDC_USE_SC), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_WND_CAP), (::SendMessage(GetDlgItem(IDC_USE_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_WND_CLS), (::SendMessage(GetDlgItem(IDC_USE_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
		::EnableWindow(GetDlgItem(IDC_GRABBER), (::SendMessage(GetDlgItem(IDC_USE_WND), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?FALSE:TRUE);
	}

};


typedef struct {
	string key;
	string name;
	string help;
} TYPE_FLAG;

/**
 *
 * CISIFlags - class interface Shortcut Implementation ZORder
 *
 * Description:
 * Class for handeling the data of a Z-order block.
 *
 * @created	2002-07-26 00:24
 * @author	MickeM <mickem@medin.nu>
 */
class CISIFlags : public IDataHandlerImpl {
private:
	IShortcutImpl *pt2Object;
	void (IShortcutImpl::*fptSetter)(string, bool);
	bool (IShortcutImpl::*fptGetter)(string);
public:
	CISIFlags(IShortcutImpl *_pt2Object, void (IShortcutImpl::*_fptSetter)(string, bool), bool(IShortcutImpl::*_fptGetter)(string)) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CISIFlags() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SC_LIST);
		int id = lvCtrl.GetNextItem(-1, LVNI_ALL);
		if (id == -1) 
			return;
		do {
			TYPE_FLAG *pItm = (TYPE_FLAG*) lvCtrl.GetItemData(id);
			if (pItm) {
				bool b = (*pt2Object.*fptGetter)(pItm->key);
				lvCtrl.SetCheckState(id, b?TRUE:FALSE);
			}
			id = lvCtrl.GetNextItem(id, LVNI_ALL);
		} while (id != -1);
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SC_LIST);
		int id = lvCtrl.GetNextItem(-1, LVNI_ALL);
		if (id == -1) 
			return;
		do {
			TYPE_FLAG *pItm = (TYPE_FLAG*) lvCtrl.GetItemData(id);
			if (pItm)
				(*pt2Object.*fptSetter)(pItm->key, lvCtrl.GetCheckState(id)?true:false);
			id = lvCtrl.GetNextItem(id, LVNI_ALL);
		} while (id != -1);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
	}
};
class CCDTFlags;
class CCIFlags : public CConfigurationItemImpl {
friend CCDTFlags;
public:
private:
	IShortcutImpl *pSCImpl;
protected:
	list<TYPE_FLAG> lstFlags;
public:
	CCIFlags(IShortcutImpl *_pSCImpl) : pSCImpl(_pSCImpl) {}
	virtual ~CCIFlags() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("Flags");
	CI_SET_DESCRIPTION("Setup and manage flags");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();
	CI_SET_STEPRC_SIMPLE("");
	CFG_ITM_SET_TEMPLATE_H(CCIFlags, CCDTFlags);

	void addFlag(TYPE_FLAG flg) {
		lstFlags.push_back(flg);
	}
	void addFlag(string key, string name, string help) {
		TYPE_FLAG flg;
		flg.key = key;
		flg.name = name;
		flg.help = help;
		lstFlags.push_back(flg);
	}

	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CISIFlags(pSCImpl, IShortcutImpl::setFlagValue, IShortcutImpl::getFlagValue));
	}
};



class CCDTFlags : public CConfigurationDialogTemplateImplT<CCDTFlags>, public CDialogImpl<CCDTFlags>
{
private:
	int iSize;
	CCIFlags *pFlag;
	TYPE_FLAG *lstFlags;
public:
	enum { IDD = IDD_FLAG_CFG };
	BEGIN_MSG_MAP(CCDTFlags);
	MESSAGE_HANDLER(WM_SIZE, onSize);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	NOTIFY_HANDLER(IDC_SLAVE_LIST, NM_CLICK, onClick);
	NOTIFY_HANDLER(IDC_FLAGS, LVN_GETINFOTIP, onGetInfoTip)
	NOTIFY_HANDLER(IDC_FLAGS, LVN_ITEMCHANGED, onItemChanged)
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTFlags>);
	END_MSG_MAP();
	CCDTFlags(CCIFlags *_pFlag, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTFlags>(pICH), pFlag(_pFlag)
	{
		iSize = pFlag->lstFlags.size();
		lstFlags = new TYPE_FLAG[iSize];
		list<TYPE_FLAG>::iterator it = pFlag->lstFlags.begin();
		int i=0;
		for (; it != pFlag->lstFlags.end(); it++, i++) {
			if (i > iSize)
				break;
			lstFlags[i] = (*it);
		}
	}
	virtual ~CCDTFlags() {
		delete [] lstFlags;
	}
	HRESULT onItemChanged(int wPartam, NMHDR *nmItem, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		NMLISTVIEW *pnmv = (LPNMLISTVIEW) nmItem; 
		if (pnmv->iItem == -1)
			return 0;
		if (pnmv->uChanged == LVIF_STATE) {
			saveData();
		}
		return 0;
	}
	LRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled) {
		if (!pFlag)
			return 0;
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_FLAGS);
		lvCtrl.AddColumn("Flags", 0);
		lvCtrl.SetExtendedListViewStyle(LVS_EX_CHECKBOXES|LVS_EX_INFOTIP  ,0);
		for (int i=0;i<iSize; i++) {
			int id = lvCtrl.AddItem(0, 0,  _T(lstFlags[i].name.c_str()));
			lvCtrl.SetItemData(id, (DWORD)(void*)&lstFlags[i]);
		}
		lvCtrl.SetColumnWidth(0, LVSCW_AUTOSIZE);
		lvCtrl.m_hWnd = NULL;
		return 0;
	}
	HRESULT onClick(int wPartam, NMHDR *nmItem, BOOL &bHandled) {
		updateHelp();
		return 0;
	}
	void updateHelp() {
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_FLAGS);
		if (lvCtrl.GetSelectedIndex() == -1)
			return;
		TYPE_FLAG *itm = (TYPE_FLAG*) lvCtrl.GetItemData(lvCtrl.GetSelectedIndex());
		if (itm)
			setHelpText(itm->help.c_str());
	}

	HRESULT onGetInfoTip(int wPartam, NMHDR *nmItem, BOOL &bHandled) {
		NMLVGETINFOTIP *pGetInfoTip = (LPNMLVGETINFOTIP)nmItem;
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_FLAGS);
		if (pGetInfoTip->iItem == -1)
			return 0;
		TYPE_FLAG *itm = (TYPE_FLAG*) lvCtrl.GetItemData(pGetInfoTip->iItem);
		if (!itm)
			return 0;
		if (pGetInfoTip->dwFlags == LVGIT_UNFOLDED)
			strncat(pGetInfoTip->pszText, itm->help.c_str(), pGetInfoTip->cchTextMax-strlen(pGetInfoTip->pszText)-1);
		else
			strncpy(pGetInfoTip->pszText, itm->help.c_str(), pGetInfoTip->cchTextMax-1);
		return 0;
	}
	LRESULT onSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled) {
		::SetWindowPos(GetDlgItem(IDC_FLAGS), NULL, 0, 0, LOWORD(lParam), HIWORD(lParam), SWP_NOZORDER|SWP_NOMOVE);
		return 0;
	}

};

#endif //__CFGTemplates_H__INCLUDED_