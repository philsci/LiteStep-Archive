// Messages.h: interface for the Messages class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESSAGES_H__308E3380_6391_4B20_8C60_A5503F762637__INCLUDED_)
#define AFX_MESSAGES_H__308E3380_6391_4B20_8C60_A5503F762637__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// STL includes
#include <string>
// SC3 Includes
#include "global.h"

using namespace std;

#define SCE_UNKNOWN -1
#define SCE_CANT_DESTROY 1
#define SCW_NO_PARRENT_REORDER 2
#define SCW_UNSUPPORTED 3
#define SCE_MISCONFIGURATION 4
#define SCW_NO_ZORDER_REORDER 5
#define SCE_MISSING_IMAGE 6
#define SCE_SETLAYERD_FAILED 7
#define SCE_BAD_ALPHA_MAP 8
#define SCE_SHORTCUT_NOT_CREATED 9
#define SCE_SHORTCUT_HAS_NO_WINDOW 10
#define SCE_SHORTCUT_NOT_FOUND 11
#define SCE_WINDOW_NOT_FOUND 12
#define SCE_UNKNOWN_FLAG 13
#define SCE_UNKNOWN_SLAVE 14
#define SCE_BAD_CAST 15
#define SCE_TEMPLATE_OUT_OF_RANGE 16
#define SCE_NO_TEMPLATE 17
#define SCE_BAD_ICON 18
#define SCE_BAD_HANDLE 19
#define SCE_CANT_ADD_CHILD 20
#define SCE_BAD_ACTION_ID 21

//#define NO_STRS_EX

#ifdef NO_STRS_EX
#define scWarningMessageSimpleLocal(id, code) void()
#define scErrorMessageSimpleLocal(id, code) void()
#define scErrorMessageSimpleParam(name, id, code) void()
#define scErrorMessageSimpleNone(id, code) void()
#define scErrorMessageSimpleParamEx(item, id, code) void()

#else
#define scWarningMessageSimpleLocal(id, code) \
	scLogMessage(__FILE__, __LINE__, MODULE_INFO, LOG_WARNING, id, IShortcut::getName(), code)
#define scErrorMessageSimpleLocal(id, code) \
	scLogMessage(__FILE__, __LINE__, MODULE_INFO, LOG_ERROR, id, IShortcut::getName(), code)
#define scErrorMessageSimpleParam(name, id, code) \
	scLogMessage(__FILE__, __LINE__, MODULE_INFO, LOG_ERROR, id, name, code)
#define scErrorMessageSimpleNone(id, code) \
	scLogMessage(__FILE__, __LINE__, MODULE_INFO, LOG_ERROR, id, "<none>", code)
#define scErrorMessageSimpleParamEx(pItem, id, code) \
	scLogMessage(__FILE__, __LINE__, MODULE_INFO, LOG_ERROR, id, pItem?pItem->getName():"<NULL>", code)
#endif
void scLogMessage(string sFile, int sLine, string sModule, int iLogCode, int iTextId, string sName, int iErrorCode);
void scLogMessage(string sFile, int sLine, string sModule, int iLogCode, int iTextId, string sName, string sErrorMsg);


#endif // !defined(AFX_MESSAGES_H__308E3380_6391_4B20_8C60_A5503F762637__INCLUDED_)
