// IShortcut.h: interface for the IShortcut class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISHORTCUT_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_)
#define AFX_ISHORTCUT_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "../lsapi/common.h"
#include <string>
#include <list>
#include <map>
#include "IConfigurationItem.h"


using namespace std;

#define ISC_CMD_CREATE		0
#define ISC_CMD_COUNT		1


class CShortcutFactory;
class IShortcut /*: public CConfigurationItemImpl, public IConfigurationDialogImpl*/
{
private:
	string m_sName;
	///////////////////////////////////////////////////////////////////
	// IShortcut
	//
	// Pure virtual functions:
public:
	virtual void createShortcut() = 0;
	virtual bool isCloseTo(int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY) = 0;
	virtual void MoveShortcut(int x, int y) = 0;
	virtual void MoveShortcutDelta(int x, int y) = 0;
	virtual IConfigurationItem* getConfigurationIF() {
		return NULL;
	}
	//
	// Methods
public:
	virtual void parseConfig();
	virtual void preAddConfig(string str);
	virtual void execBang(string szAarg);
	virtual void execBang(int iCmd, string szAarg);
	IShortcut(CShortcutFactory *sf);
	virtual ~IShortcut();
	//
	// Internal variables accessable by derived objects
protected:
	CShortcutFactory *m_pFactory;
	int m_iCommandArray[ISC_CMD_COUNT];
	list<string> m_lstConfig;
	//
public:
	///////////////////////////////////////////////////////////////////
	// IConfigurationItem
	//
	// Properties
	virtual string getName()
	{	return m_sName;	}
	virtual bool setName(string name);
	CShortcutFactory* getFactory() {
		return m_pFactory;
	}
};

#endif // !defined(AFX_ISHORTCUT_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_)
