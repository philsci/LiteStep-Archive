// ShortcutFactory.cpp: implementation of the CShortcutFactory class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)
#include "stdatl.h"
#include <stdio.h>
#include <windows.h>
#include <commctrl.h>
#include <time.h>


#include "ShortcutFactory.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/safestr.h"
#include "global.h"
#include "bang_cmd.h"
#include "IShortcut.h"
#include "SimpleShortcut.h"
#include "NormalShortcut.h"
#include "ShortcutGroup.h"
#include "string_util.h"
#include "SettingsDialog.h"

#include "resource.h"
using namespace std;

extern CShortcutFactory* shortcutFactory;

#define WM_CONFIG WM_USER+123

CFG_ITM_SET_TEMPLATE_CPP(CCIShortcutFactory, CCDTShortcutFactory);




//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CShortcutFactory::CShortcutFactory(HWND parentWnd, int& code, HWND desktopWnd) : 
	Window(APP_NAME), 
	m_bBaloonTip(false), 
	m_iSnapSpace(0),
	m_pSettingsDialog(NULL)
{
	InitializeCriticalSection(&m_cs);
	m_hDesktopWnd = desktopWnd;
	m_bBaloonTip = GetRCBool("shortcutBaloonTips", TRUE) == TRUE;
	fShortcutHints = CreateWindow(TOOLTIPS_CLASS, NULL, m_bBaloonTip?(TTS_ALWAYSTIP|TTS_BALLOON):(TTS_ALWAYSTIP),
	                              CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
	                              NULL, NULL, hInstance, NULL);
	if (fShortcutHints)
		SetWindowPos(fShortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

	createWindow(WS_EX_TOOLWINDOW, "ShortcutFactory", WS_POPUP, 0, 0, 0, 0, parentWnd);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	m_iCommandArray[SF_CONFIG] = getStringID("configure");
	parseStepRC();
	createShortcut("", "", "", true);
}

CShortcutFactory::~CShortcutFactory()
{
	if (fShortcutHints)
		::DestroyWindow(fShortcutHints);
	if (m_pSettingsDialog)
		delete m_pSettingsDialog;
	destroyShortcuts();
	if (!destroyWindow())
		LSLogPrintf(0, "shortcut3", "Could not destroy shortcut factory: %d", GetLastError());
	DeleteCriticalSection(&m_cs);
}

/**
 *
 * Parses a "simple config line" 
 *
 */
void CShortcutFactory::parseOldConfig(IShortcut *sc, string szConfigLine)
{
	string token;
	bool hasCommand = true;
	bool clickSoundDef = false;
	bool hoverSoundDef = false;

	GetToken(szConfigLine, false);
	sc->setName(GetToken(szConfigLine, false));

	string x = GetToken(szConfigLine, false);
	string y = GetToken(szConfigLine, false);
	sc->preAddConfig("pos "+ x + " " + y);
	sc->preAddConfig("normal image "+ GetToken(szConfigLine, false));
	sc->preAddConfig("hover image " + GetToken(szConfigLine, false));
	sc->preAddConfig("left image " + GetToken(szConfigLine, false));
	sc->preAddConfig("parrent none");
	if (!GetToken(token, szConfigLine, false))
		return;

	if ((token[0] == '#') && (token.length() > 1)) {
		int result = atoi(token.substr(1).c_str());
		if (result != 0) {
			char s[10];
			sprintf(s, "%d", result);
			IShortcut *sg = findShortcut(s);
			if (sc->getName().empty()) {
				sc->setName("GenName_" + IConfigurationHelpers::itos(rand()));
			}
			if (sg) 
				sg->preAddConfig("addToGroup " + sc->getName());
			else
				addShortcut(createShortcut("group", s, sc->getName()));
		}
		string flags;
		if (token.find_first_of("cC") != token.npos)
			flags += "caption ";
		if (token.find_first_of("tT") != token.npos)
			flags += "ontop ";
		if (token.find_first_of("hH") != token.npos)
			flags += "hide ";
		if (token.find_first_of("oO") != token.npos)
			flags += "opaque ";
		sc->preAddConfig("flags " + flags);
		if (!GetToken(token, szConfigLine, false)) 
			return;
	}
	string command;
	if ((StrIPos(token.c_str(), ".wav"))||(StrIPos(token.c_str(), ".none"))||(StrIPos(token.c_str(), ".def"))) {
		sc->preAddConfig("hover sound " + token);
		if (!GetToken(token, szConfigLine, false))
			return;
		if ((StrIPos(token.c_str(), ".wav"))||(StrIPos(token.c_str(), ".none"))||(StrIPos(token.c_str(), ".def"))) {
			sc->preAddConfig("left sound " + token);
		} else {
			sc->preAddConfig("left command " + (string)"\"" + (string)token +(string)"\" " + szConfigLine);
			return;
		}
	} else {
		sc->preAddConfig("left command " + (string)"\"" + (string)token +(string)"\" " + szConfigLine);
		return;
	}
	if (!GetToken(token, szConfigLine, false))
		return;
	sc->preAddConfig("left command " + (string)"\"" + (string)token +(string)"\" " + szConfigLine);
}


void CShortcutFactory::parseConfig(IShortcut *newShortcut, FILE *step) 
{
	if (!newShortcut)
		return;
	char configLine[MAX_LINE_LENGTH];
	char token[MAX_LINE_LENGTH];
	while (LCReadNextConfig(step, "*ShortcutEx", configLine, MAX_LINE_LENGTH)) {
		LPCSTR nextToken = configLine;
		if (strchr(configLine, '~')) {
			return;
		}
		if (GetToken(nextToken, token, &nextToken, false)) {
			if (nextToken)
				newShortcut->preAddConfig(nextToken);
		}
	}
}

void CShortcutFactory::parseStepRC()
{
	char configLine[MAX_LINE_LENGTH];
	LPCSTR nextToken = configLine;
	FILE* step;

	GetRCString("shortcutSoundClick", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssLeft] = configLine;
	GetRCString("shortcutSoundLeft", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssLeft] = configLine;
	GetRCString("shortcutSoundRight", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssRight] = configLine;
	GetRCString("shortcutSoundMiddle", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssMiddle] = configLine;
	GetRCString("shortcutSoundDrop", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssDrop] = configLine;
	GetRCString("shortcutSoundHover", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssHover] = configLine;
	GetRCString("shortcutSoundNormal", configLine, ".none", MAX_LINE_LENGTH);
	if ((!StrIPos(configLine, ".none"))&&(strlen(configLine) > 0))
		m_sShortcutSound[CState::ssNormal] = configLine;
	GetRCString("shortcutRCFile", configLine, "", MAX_LINE_LENGTH);
	if (configLine)
		m_sShortcutFile = configLine;

	m_iSnapSpace = GetRCInt("shortcutSnapSpace", 10);

	step = LCOpen(NULL);
	if (!step)
		return;
	// Read all "old-style" shortcuts
	while (LCReadNextConfig(step, "*shortcut", configLine, MAX_LINE_LENGTH)) {
		IShortcut *sc = new CNormalShortcut(this, "");
		parseOldConfig(sc, configLine);
		addShortcut(sc);
	}
	LCClose(step);

	// Parse all "New" Shortcuts lines
	step = LCOpen(NULL);
	if (!step)
		return;
	while (LCReadNextConfig(step, "*shortcutEx", configLine, MAX_LINE_LENGTH)) {
		string arguments = configLine;
		GetToken(arguments, false);
		string type = GetToken(arguments, false);
		string name = GetToken(arguments, false);
		IShortcut *newShortcut = createShortcut(type, name, arguments);
		parseConfig(newShortcut, step);
		addShortcut(newShortcut);
	}
	LCClose(step);
	step = LCOpen(NULL);
	if (!step)
		return;
	while (LCReadNextConfig(step, "*shortcutEx~", configLine, MAX_LINE_LENGTH)) {
		string arguments = configLine;
		GetToken(arguments, false);
		string type = GetToken(arguments, false);
		string name = GetToken(arguments, false);
		addShortcut(createShortcut(type, name, arguments));
	}
	LCClose(step);
	createShortcuts();
}


void CShortcutFactory::relayHintMessage(HWND hWnd, Message& message)
{
	MSG hintMessage = {hWnd, message.uMsg, message.wParam, message.lParam};

	if (!fShortcutHints)
		return ;
	SendMessage(fShortcutHints, TTM_RELAYEVENT, 0, LPARAM(&hintMessage));
	SetWindowPos(fShortcutHints, HWND_TOPMOST, 0, 0, 0, 0,SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}


void CShortcutFactory::addHint(HWND hWnd, LPSTR caption)
{
	TOOLINFO ti;
	RECT clientRect;

	if (!fShortcutHints)
		return ;
	GetClientRect(hWnd, &clientRect);

	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = TTF_SUBCLASS;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = clientRect;
	ti.hinst = hInstance;
	ti.lpszText = caption;
	ti.lParam = 0;
	SendMessage(fShortcutHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}


void CShortcutFactory::removeHint(HWND hWnd)
{
	TOOLINFO ti;
	RECT emptyRect = {0, 0, 0, 0};

	if (!fShortcutHints)
		return ;
	ti.cbSize = sizeof(TOOLINFO);
	ti.uFlags = 0;
	ti.hwnd = hWnd;
	ti.uId = 0;
	ti.rect = emptyRect;
	ti.hinst = hInstance;
	ti.lpszText = NULL;
	ti.lParam = 0;
	SendMessage(fShortcutHints, TTM_DELTOOL, 0, LPARAM(&ti));
}

//---------------------------------------------------------
// Bang commands
//---------------------------------------------------------
void CShortcutFactory::bangGroupToggle(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("show", args, "toggle");
}

void CShortcutFactory::bangGroupShow(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("show", args, "");
}

void CShortcutFactory::bangGroupHide(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("show", args, "hide");
}

void CShortcutFactory::bangGroupOnTopToggle(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("ontop", args, "toggle");
}

void CShortcutFactory::bangGroupOnTop(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("ontop", args, "");
}

void CShortcutFactory::bangGroupOnBottom(HWND sender, LPCSTR args)
{
	shortcutFactory->execOldBang("onbottom", args, "");
}

string CShortcutFactory::getIDString(int iCmd) 
{
	string ret;
	T_MAP_STR_INT::iterator it = m_mapStrings.begin();
	for (;it!=m_mapStrings.end();it++) {
		if ((*it).second == iCmd) {
			if (!ret.empty())
				ret += ", " + (*it).first;
			else
				ret = (*it).first;
		}
	}
	return ret;
}

int CShortcutFactory::getStringID(string str) 
{	
	char *c = new char[str.length()+1];
	strcpy(c, str.c_str());
	_strupr(c);
	str = c;
	delete [] c;
	T_MAP_STR_INT::iterator it = m_mapStrings.find(str);
	if (it != m_mapStrings.end())
		return (*it).second;
	int id = m_mapStrings.size()+1;
	m_mapStrings[str] = id;
	return id;
}
// !shortcut <target>[,<target>[,...]] <action> [<parameter>]
void CShortcutFactory::bangShortcut(HWND sender, LPCSTR args)
{
	string arg = args;
	string targets = GetToken(arg, false);
	string cmd = GetToken(arg, false);
	string action = GetToken(arg, false);
	shortcutFactory->execBang(targets, cmd, args);
}
void CShortcutFactory::execOldBang(string cmd, string targets, string parameters)
{
	CLock lock(m_cs);
	string token;
	int iCmd = getStringID(cmd);
	while (GetToken(token, targets, FALSE)) {
		IShortcut *sc = findShortcut(token);
		if (sc)
			sc->execBang(iCmd, parameters);
	}

}

void CShortcutFactory::execBang(string targets, string cmd, string parameters)
{
	CLock lock(m_cs);
	int iCmd = getStringID(cmd);
	if (targets == "core") {
		if (iCmd == m_iCommandArray[SF_CONFIG]) {
			RECT r = getSettingsPos();
			if (!m_pSettingsDialog)
				m_pSettingsDialog = new CSettingsDialog(instance());
			m_pSettingsDialog->show(Window::handle(), getConfigurationIF(), r);
		}
	} else {
		if ((stricmp(targets.c_str(), "all") == 0)||(strchr(targets.c_str(), '*'))) {
			for (T_LST_SC::iterator sIter = m_lstShortcuts.begin(); sIter != m_lstShortcuts.end(); sIter++ ) {
				if ((*sIter)) 
					(*sIter)->execBang(iCmd, parameters);
			}
		} else {
			string::size_type pos = targets.find(',');
			while (pos != targets.npos) {
				string name = targets.substr(0, pos);
				targets = targets.substr(pos);
				pos = targets.find(',');
				IShortcut *sc = findShortcut(targets);
				if (sc)
					sc->execBang(iCmd, parameters);
			}
		}
	}
}
void CShortcutFactory::onWindowPosChanging(WINDOWPOS *pos)
{
	if (m_iSnapSpace == 0)
		return;
	bool x = false;
	bool y = false;
	for (T_LST_SC::iterator p = m_lstShortcuts.begin();p!=m_lstShortcuts.end();p++) {
		IShortcut *sc = (*p);
		if (sc->isCloseTo(pos->x, pos->y, pos->cx, pos->cy, 20, x, y))
			return;
	}
}


//---------------------------------------------------------
// Message handling
//---------------------------------------------------------

void CShortcutFactory::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onRefresh, LM_REFRESH)
	MESSAGE(onDestroyConfig, WM_DESTROYSETTINGS)
	END_MESSAGEPROC
}
void CShortcutFactory::onDestroyConfig(Message& message)
{
	if (m_pSettingsDialog)
		delete m_pSettingsDialog;
	m_pSettingsDialog = NULL;
}

void CShortcutFactory::onCreate(Message& message)
{
	int lsMessages[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(hParent, LM_REGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

	AddBangCommand("!ShortcutGroupHide", bangGroupHide);
	AddBangCommand("!ShortcutGroupShow", bangGroupShow);
	AddBangCommand("!ShortcutGroupToggle", bangGroupToggle);
	AddBangCommand("!ShortcutGroupOnTop", bangGroupOnTop);
	AddBangCommand("!ShortcutGroupOnBottom", bangGroupOnBottom);
	AddBangCommand("!ShortcutGroupOnTopToggle", bangGroupOnTopToggle);

	AddBangCommand("!shortcut", bangShortcut);
}


void CShortcutFactory::onDestroy(Message& message)
{
	int lsMessages[] = {LM_GETREVID, LM_REFRESH, 0};

	if ((fShortcutHints)&&(IsWindow(fShortcutHints)))
		DestroyWindow(fShortcutHints);

	destroyShortcuts();

	SendMessage(hParent, LM_UNREGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

	RemoveBangCommand("!shortcutgrouptoggle");
	RemoveBangCommand("!shortcutgroupshow");
	RemoveBangCommand("!shortcutgrouphide");
	RemoveBangCommand("!shortcutgroupontoptoggle");
	RemoveBangCommand("!shortcutgroupontop");
	RemoveBangCommand("!shortcutgrouponbottom");
	RemoveBangCommand("!shortcut");

}


void CShortcutFactory::onGetRevId(Message& message)
{
	char* buf = (char*)(message.lParam);
	if (message.wParam == 0) {
			sprintf(buf, "shortcut3.dll: %s (%s - %s)", &RCS_REVISION[11], __DATE__, __TIME__);
			buf[strlen(buf) - 1] = '\0';
	} else {
			strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void CShortcutFactory::onRefresh(Message& message)
{
	destroyShortcuts();
	parseStepRC();
}

void CShortcutFactory::createShortcuts()
{
	T_LST_SC::iterator it;
	for (it = m_lstShortcuts.begin();it != m_lstShortcuts.end();it++) {
		(*it)->parseConfig();
	}
	// TODO: figure out why this has to be done reversed...
	it = m_lstShortcuts.end();
	while (it-- != m_lstShortcuts.begin()) {
		(*it)->createShortcut();
	}
}

void CShortcutFactory::addShortcut(IShortcut *newShortcut)
{
	if (!newShortcut)
		return;
	// If we have set a name add it to the name lookup map
	if (!newShortcut->getName().empty())
		m_mapShortcuts[newShortcut->getName()] = newShortcut;
	// finaly add it to the list so we can later destroy it
	m_lstShortcuts.push_back(newShortcut);
}

void CShortcutFactory::destroyShortcuts()
{
	// clear out all shortcuts lists so we wont acidentaly do things with broken pointers.
	m_mapShortcuts.clear();
	// destroy all loaded shortcuts
	for (T_LST_SC::iterator p = m_lstShortcuts.begin();p!=m_lstShortcuts.end();p++) {
		delete (*p);
	}
	// Clear out the list now that we have deleted all shortcuts
	m_lstShortcuts.clear();
}

void CShortcutFactory::playSound(CState::ShortcutActions action)
{
	if (!m_sShortcutSound[action].empty())
		::PlaySound(m_sShortcutSound[action].c_str(), NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT);	
}

void CShortcutFactory::renameShortcut(string oldName, string newName, IShortcut *pIf) 
{
	if (oldName.empty())
		return;
	T_MAP_STR_SC::iterator it = m_mapShortcuts.find(oldName); 
	if (it == m_mapShortcuts.end()) {
		LSLogPrintf(LOG_ERROR, __FILE__, "Shortcut not found when trying to rename it");
		return;
	}
	if ((*it).second != pIf)  {
		LSLogPrintf(LOG_ERROR, __FILE__, "Shortcut not same when trying to rename it");
		return;
	}
	m_mapShortcuts.erase(it);
	m_mapShortcuts[newName] = pIf;
}


IShortcut* CShortcutFactory::findShortcut(string name)
{
	if (name.empty())
		return NULL;
	T_MAP_STR_SC::iterator snIter = m_mapShortcuts.find(name); 
	if (snIter == m_mapShortcuts.end()) {
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not find shortcut: %s", name.c_str());
		return NULL;
	}
	return ((*snIter).second);
}


CShortcutFactory::T_LST_SC CShortcutFactory::getShortcutList()
{
	return m_lstShortcuts;
}

///////////////////////////////////////////////////////////////////////
// IConfigurationItem
IConfigurationItem* CShortcutFactory::getConfigurationIF()
{
	return new CCIShortcutFactory(this);
}


//////////////////////////////////////////////////////////////////////////
// Properties
// 
// Count [get]
int CShortcutFactory::getShortcutCount() {
	return m_lstShortcuts.size();
}
// 
// Sounds [get, set]
string CShortcutFactory::getSound(CState::ShortcutActions action) {
	return m_sShortcutSound[action];
}
void CShortcutFactory::setSound(CState::ShortcutActions action, string sound) {
	m_sShortcutSound[action] = sound;
}
//
// Baloon tips [get, set]
void CShortcutFactory::setUseBaloonTips(bool b) {
	m_bBaloonTip = b;
}
bool CShortcutFactory::getUseBaloonTips() {
	return m_bBaloonTip;
}
//
// Desktop window [get]
HWND CShortcutFactory::getDesktopWindow() {
	return m_hDesktopWnd;
}
//
// SNap Space [get, set]
int CShortcutFactory::getSnapSpace() {
	return m_iSnapSpace;
}
void CShortcutFactory::setSnapSpace(int i) {
	m_iSnapSpace = i;
}
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

#define ADD_SHORTCUT_TYPE_BEGIN \
IShortcut* CShortcutFactory::createShortcut(string type, string name, string arguments, bool makeList) {  \
	IShortcut *ret = NULL; \
	if (makeList) { \
		m_lstShortcutTypes.clear(); \
	} 

#define ADD_SHORTCUT_TYPE(className) \
	if (makeList) { \
		m_lstShortcutTypes.push_back(pair<string, string>(className::getShortName(), className::getLongName())); \
	} else if (type == className::getShortName()) { \
		ret = new className(this, arguments); \
	} 

#define ADD_SHORTCUT_TYPE_END \
	if (ret) \
		ret->setName(name); \
	return ret; \
}


string CShortcutFactory::getStepRC(bool bRecursive) {
	string ret;
	if (m_bBaloonTip)
		ret += "shortcutBaloonTips\n";
	if (m_iSnapSpace != 10)
		ret += "shortcutSnapSpace " + IConfigurationHelpers::itos(m_iSnapSpace) + "\n"; 
	if (!m_sShortcutSound[CState::ssNormal].empty())
		ret += "shortcutSoundNormal " + m_sShortcutSound[CState::ssNormal] + "\n";
	if (!m_sShortcutSound[CState::ssLeft].empty())
		ret += "shortcutSoundLeft " + m_sShortcutSound[CState::ssLeft] + "\n";
	if (!m_sShortcutSound[CState::ssRight].empty())
		ret += "shortcutSoundRight " + m_sShortcutSound[CState::ssRight] + "\n";
	if (!m_sShortcutSound[CState::ssMiddle].empty())
		ret += "shortcutSoundMiddle " + m_sShortcutSound[CState::ssMiddle] + "\n";
	if (!m_sShortcutSound[CState::ssHover].empty())
		ret += "shortcutSoundHover " + m_sShortcutSound[CState::ssHover] + "\n";
	if (!m_sShortcutSound[CState::ssDrop].empty())
		ret += "shortcutSoundDrop " + m_sShortcutSound[CState::ssDrop] + "\n";

	RECT r = getSettingsPos();
	ret += "shortcutGUIPosTop " + IConfigurationHelpers::itos(r.top) + "\n"; 
	ret += "shortcutGUIPosLeft " + IConfigurationHelpers::itos(r.left) + "\n"; 
	ret += "shortcutGUIPosRight " + IConfigurationHelpers::itos(r.right) + "\n"; 
	ret += "shortcutGUIPosBottom " + IConfigurationHelpers::itos(r.bottom) + "\n"; 

	if (bRecursive) {
		T_LST_SC lst = getShortcutList();
		for (CShortcutFactory::T_LST_SC::iterator it = lst.begin(); it != lst.end();it++) {
			IConfigurationItem *pItem = (*it)->getConfigurationIF();
			if (pItem)
				ret += pItem->getStepRC(true);
			delete pItem;
		}
	}
	return ret;
}

//
// Add all new shortcut types below here
//
//{{
ADD_SHORTCUT_TYPE_BEGIN
ADD_SHORTCUT_TYPE(CNormalShortcut);
ADD_SHORTCUT_TYPE(CShortcutGroup);
ADD_SHORTCUT_TYPE(CSimpleShortcut);
ADD_SHORTCUT_TYPE_END
//}}


//////////////////////////////////////////////////////////////////////////
// CCIShortcutFactory
IConfigurationItem::LST_CHILD CCIShortcutFactory::getChildren() {
	IConfigurationItem::LST_CHILD children;
	CI_VERIFY(children);
	CShortcutFactory::T_LST_SC lst = pFactory->getShortcutList();
	for (CShortcutFactory::T_LST_SC::iterator it = lst.begin(); it != lst.end();it++) {
		children.push_back((*it)->getConfigurationIF());
	}
	return children;
}

bool CShortcutFactory::saveStepRC() {
	if (m_sShortcutFile.empty())
		return false;
	string s = getStepRC(true);
	FILE *f = fopen(m_sShortcutFile.c_str(), "wt");
	if (!f) {
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not open step.rc file: %s", m_sShortcutFile.c_str());
		return false;
	}
	if (fwrite(s.c_str(), sizeof(char), s.length(),  f) != s.length()) {
		LSLogPrintf(LOG_ERROR, __FILE__, "Error while writing file: %s (%d).", m_sShortcutFile.c_str(), GetLastError());
		fclose(f);
		return false;
	}
	fclose(f);
	return true;
}

IConfigurationItem* CCIShortcutFactory::addNewChild(string type) {
	string typeName;
	CShortcutFactory::T_LST_STRSTR lst = pFactory->getShortuctutTypes();
	for (CShortcutFactory::T_LST_STRSTR::iterator it = lst.begin(); it != lst.end(); it++) {
		if (type == (*it).second)
			typeName = (*it).first;
	}
	if (typeName.empty())
		return NULL;
	IShortcut *sc = pFactory->addNewShortcut(typeName, (string)"New " + typeName);
	if (sc) {
		return sc->getConfigurationIF();
	} 
	return NULL;
}

IShortcut* CShortcutFactory::addNewShortcut(string type, string name) {
	IShortcut* ret = createShortcut(type, name, "");
	ret->setName(name);
	addShortcut(ret);
	ret->parseConfig();
	ret->createShortcut();
	return ret;
}

RECT CShortcutFactory::getSettingsPos() {
	RECT r;
	if (!m_pSettingsDialog) {
		r.top = GetRCInt("shortcutGUIPosTop", 50);
		r.left = GetRCInt("shortcutGUIPosLeft", 50);
		r.right = GetRCInt("shortcutGUIPosRight", 590);
		r.bottom = GetRCInt("shortcutGUIPosBottom", 430);
	} else {
		::GetWindowRect(m_pSettingsDialog->getHWnd(), &r);
	}
	return r;
}
