// IShortcutImpl.cpp: implementation of the IShortcutImpl class.
//
//////////////////////////////////////////////////////////////////////

#include "IShortcutImpl.h"
#include "ShortcutFactory.h"
#include "global.h"
#include "../lsapi/safestr.h"
#include "bang_cmd.h"
#include "typeinfo.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IShortcutImpl::IShortcutImpl(CShortcutFactory *sf) : IShortcut(sf),
		Window(APP_NAME), 
		UpdateLayeredWindow(NULL),
		SetLayeredWindowAttributes(NULL),
		m_bOpaque(false),
		m_hPaintDC(NULL),
		m_bUseAlphaMap(false),
		m_bUseAlphaTrans(false),
		m_bCaptioned(false),
		m_bVisible(true),
		m_bKeepOnDesktop(true),
		m_pBitmap(NULL),
		m_bVisibleSet(false)
{
	OSVERSIONINFO os = { sizeof(os) };
	GetVersionEx(&os);
	if ( VER_PLATFORM_WIN32_NT == os.dwPlatformId && os.dwMajorVersion >= 5 ) {
		HMODULE hUser32 = GetModuleHandle(_T("USER32.DLL"));
		UpdateLayeredWindow = (lpfnUpdateLayeredWindow)GetProcAddress(hUser32, "UpdateLayeredWindow");
		SetLayeredWindowAttributes = (lpfnSetLayeredWindowAttributes)GetProcAddress(hUser32, "SetLayeredWindowAttributes");
	}
	m_iCommandArray[ISCI_CMD_PARRENT]=IShortcut::m_pFactory->getStringID("parrent");
	m_iCommandArray[ISCI_CMD_FLAGS]	= IShortcut::m_pFactory->getStringID("flags");
	m_iCommandArray[ISCI_CMD_FLAG]	= IShortcut::m_pFactory->getStringID("flag");
	m_iCommandArray[ISCI_CMD_POS]	= IShortcut::m_pFactory->getStringID("pos");
	m_iCommandArray[ISCI_CMD_ZORDER]=IShortcut::m_pFactory->getStringID("z-order");
	m_iCommandArray[ISCI_CMD_SHOW]	=IShortcut::m_pFactory->getStringID("show");
	
	m_zOrderWindow.hWnd = NULL;
	m_parrentWindow.hWnd = NULL;
	m_curSize.cx = m_curSize.cy = 0;
}

IShortcutImpl::~IShortcutImpl()
{
	for (IConfigurationItem::LST_CHILD::iterator it = m_cachedChildList.begin(); it != m_cachedChildList.end(); it++) {
		delete (*it);
	}
	if (m_hPaintDC)
		DeleteDC(m_hPaintDC);
	if ((Window::handle())&&(!Window::destroyWindow()))
		scErrorMessageSimpleLocal(SCE_CANT_DESTROY, GetLastError());
}

/**
 *
 * reCreateShortcutRemote
 *
 * Description:
 * Recreate the shortdut from a remote thread (this is marshaled over the message pump)
 *
 * @created	2002-08-08 19:18
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcutImpl::reCreateShortcutRemote()
{
	if (isCreated()) 
		SendMessage(Window::handle(), WM_SC3_RECREATE_WINDOW, 0, 0);
}

/**
 *
 * reCreateShortcut
 *
 * Description:
 * Recreate the shortcut (from this thread, ie. not marshaled)
 *
 * @created	2002-08-08 19:18
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcutImpl::reCreateShortcut()
{
	if (!Window::destroyWindow())
		scErrorMessageSimpleLocal(SCE_CANT_DESTROY, GetLastError());
	createShortcut();
}


/**
 *
 * iCreateShortcut
 *
 * Description:
 * cv. createShortcut
 *
 * @created	2002-08-08 19:20
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcutImpl::createShortcut()
{
	if (Window::handle()) 
		return;
	if ((!m_bVisibleSet)&&(!m_bVisible))
		return;
	DWORD wsEx=WS_EX_TOOLWINDOW;
	DWORD ws=WS_VISIBLE;

	if ((m_bUseAlphaTrans)||(m_bUseAlphaMap))
		wsEx |= WS_EX_LAYERED;

	HWND hParrentWnd = NULL;
	if (m_parrentWindow.data == 0) {
		if (!findWindow(m_parrentWindow))
			scWarningMessageSimpleLocal(SCW_NO_PARRENT_REORDER, GetLastError());
		else
			hParrentWnd = m_parrentWindow.hWnd;
	} else if (m_parrentWindow.data == 1) {
		// no parrent 
	} else if (m_parrentWindow.data == 2) {
		// desktop parrent 
		hParrentWnd = IShortcut::m_pFactory->getDesktopWindow();
	} else if (m_parrentWindow.data == 3) {
		// TODO: add some generic SC layer here
		scWarningMessageSimpleLocal(SCW_UNSUPPORTED, 1);
//		hParrentWnd = IShortcut::m_pFactory->getDesktopWindow();
	} else 
		scErrorMessageSimpleLocal(SCE_MISCONFIGURATION, 1);
	if (hParrentWnd)
		ws |= WS_CHILD;
	else
		ws |= WS_POPUP;
	if (m_zOrderWindow.hWnd == HWND_TOPMOST)
		wsEx = WS_EX_TOPMOST;

	m_curPos = readjustCoords(m_position);
	Window::createWindow(wsEx, IShortcut::getName().c_str(), ws, m_curPos.x, m_curPos.y, m_curSize.cx, m_curSize.cy, hParrentWnd);
	if (findWindow(m_zOrderWindow)) {
		if (m_zOrderWindow.hWnd != HWND_TOPMOST)
			SetWindowPos(Window::handle(), m_zOrderWindow.hWnd, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	} else
		scWarningMessageSimpleLocal(SCW_NO_ZORDER_REORDER, GetLastError());
	
	applyImage(false);
	ShowWindow(Window::handle(), SW_NORMAL);
}

/**
 *
 * setupImage
 *
 * Description:
 * Setup image data (this is applyed with applyImage() function)
 *
 * @created	2002-08-08 19:20
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcutImpl::setupImage(CLSBitmap *bmp)
{	m_pBitmap = bmp;	}

/**
 *
 * applyImage
 *
 * Description:
 * Realise the image data and resize/repaint/etc.
 *
 * @created	2002-08-08 19:21
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcutImpl::applyImage(bool refresh)
{
	if ((!m_pBitmap)||(!Window::handle())) {
		scErrorMessageSimpleLocal(SCE_MISSING_IMAGE, GetLastError());
		return;
	}

	HBITMAP hBitmap = m_pBitmap->getBitmapHandle();
	HRGN hRegion = m_pBitmap->getRegionHandle();
	if (!hBitmap) {
		scErrorMessageSimpleLocal(SCE_MISSING_IMAGE, GetLastError());
		return;
	}

	SIZE sOldSize = m_curSize;
	GetLSBitmapSize(hBitmap, (int*)&m_curSize.cx, (int*)&m_curSize.cy);

	if ((sOldSize.cx != m_curSize.cx)||(sOldSize.cy != m_curSize.cy))
		SetWindowPos(Window::handle(), 0, 0, 0, m_curSize.cx, m_curSize.cy,SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
	if ((!m_bOpaque) && (hRegion)) {
		// Setup region
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(windowRgn, hRegion, NULL, RGN_COPY);
		if (!SetWindowRgn(Window::handle(), windowRgn, TRUE)) {
			::DeleteObject(windowRgn);
		}
	}
	if ((m_bUseAlphaTrans)&&(SetLayeredWindowAttributes)) {
		// Setup alpha trans
		if (!SetLayeredWindowAttributes(Window::handle(), 0, m_pBitmap->getAlphaLevel(), LWA_ALPHA)) 
			scErrorMessageSimpleLocal(SCE_SETLAYERD_FAILED, GetLastError());
	} else if ((m_bUseAlphaMap) && (UpdateLayeredWindow)) {
		// Setup alpha Map
		HBITMAP hAlphaBitmap = m_pBitmap->getAlphaBitmapHandle();
		if (!hAlphaBitmap) {
			scErrorMessageSimpleLocal(SCE_BAD_ALPHA_MAP, GetLastError());
			return;
		}
		HDC dcScreen = GetDC(NULL);
		HDC dcMemory = CreateCompatibleDC(dcScreen);
		HBITMAP pOldBitmap = (HBITMAP)SelectObject(dcMemory, hAlphaBitmap);
		BLENDFUNCTION blendPixelFunction = { AC_SRC_OVER, 0, m_pBitmap->getAlphaLevel(), AC_SRC_ALPHA };
		POINT ptSrc = {0,0};
		if (!UpdateLayeredWindow(Window::handle(), dcScreen, &m_curPos, &m_curSize, dcMemory, &ptSrc, 0, &blendPixelFunction, ULW_ALPHA))
			scErrorMessageSimpleLocal(SCE_SETLAYERD_FAILED, GetLastError());
		SelectObject(dcMemory, pOldBitmap);
		DeleteDC(dcMemory);
		ReleaseDC(NULL, dcScreen);
	}

	if (refresh) {
		RECT clientRect;
		GetClientRect(Window::handle(), &clientRect);
		InvalidateRect(Window::handle(), &clientRect, TRUE);
	}
}


/**
 *
 * Will (during erase) paint the current image into the DC
 *
 * The current image is "m_hCurrentBitmap" and can be set using setImage();
 *
 * Is implemented in the interface
 *
 */
void IShortcutImpl::onEraseBkgnd(Message& message)
{
	HDC hDC = (HDC)message.wParam;
	if (!m_pBitmap) 
		return;
	HBITMAP hBitmap = m_pBitmap->getBitmapHandle();
	if (!hBitmap)
		return;

	if (!m_hPaintDC)
		m_hPaintDC = CreateCompatibleDC(hDC);
	HBITMAP oldImage = (HBITMAP)SelectObject(m_hPaintDC, hBitmap);
	BitBlt(hDC, 0, 0, m_curSize.cx, m_curSize.cy, m_hPaintDC, 0, 0, SRCCOPY);
	SelectObject(m_hPaintDC, oldImage);
}

void IShortcutImpl::onCreate(Message& message)
{
	if (m_bKeepOnDesktop)
		SetWindowLong(Window::handle(), GWL_USERDATA, magicDWord);
}

void IShortcutImpl::onEndSession(Message& message)
{
	message.lResult = SendMessage(GetLitestepWnd(), message.uMsg, message.wParam, message.lParam);
}

void IShortcutImpl::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(GetLitestepWnd(), WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(Window::handle(), message.uMsg, message.wParam, message.lParam);
}

void IShortcutImpl::onReCreateWindow(Message& message)
{
	reCreateShortcut();
}
void IShortcutImpl::onDisplayChange(Message& message)
{
	m_curPos = readjustCoords(m_position);
	MoveShortcut(m_curPos);
}

void IShortcutImpl::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onEraseBkgnd, WM_ERASEBKGND)
	MESSAGE(onDisplayChange, WM_DISPLAYCHANGE)
	MESSAGE(onReCreateWindow, WM_SC3_RECREATE_WINDOW)
	END_MESSAGEPROC
}

/**
 *
 * findWindow
 *
 * Description:
 * Find a window and fill the SHORTCUTORWINDOW struct
 *
 * @created	2002-08-08 19:22
 * @author	MickeM <mickem@medin.nu>
 */
bool IShortcutImpl::findWindow(SHORTCUTORWINDOW &scOrWnd)
{
	if (!scOrWnd.scName.empty()) {
		scOrWnd.hWnd = NULL;
		IShortcut *sc = IShortcut::m_pFactory->findShortcut(scOrWnd.scName);
		if (sc)	{
			try {
				IShortcutImpl* scImpl = dynamic_cast<IShortcutImpl*>(sc);
				if (!scImpl->getHWnd())
					scErrorMessageSimpleLocal(SCE_SHORTCUT_NOT_CREATED, GetLastError());
				scOrWnd.hWnd = scImpl->getHWnd();
			} catch (bad_cast) {
				scErrorMessageSimpleLocal(SCE_SHORTCUT_HAS_NO_WINDOW, GetLastError());
				return false;
			}
		} else {
			scErrorMessageSimpleLocal(SCE_SHORTCUT_NOT_FOUND, GetLastError());
			return false;
		}
	} else if ((!scOrWnd.wndClass.empty()) || (!scOrWnd.wndTitle.empty())){
		scOrWnd.hWnd = FindWindow(scOrWnd.wndClass.empty()?NULL:scOrWnd.wndClass.c_str(), scOrWnd.wndTitle.empty()?NULL:scOrWnd.wndTitle.c_str());
		if (scOrWnd.hWnd == NULL) {
			LSLogPrintf(LOG_WARNING, __FILE__, "Findow (class=%s, caption=%s) was not found in shortcut (%s)", scOrWnd.wndClass.c_str(), scOrWnd.wndTitle.c_str(), IShortcut::getName().c_str());
			return false;
		}
	} else 
		return true;
	if (!scOrWnd.hWnd) {
		scErrorMessageSimpleLocal(SCE_WINDOW_NOT_FOUND, GetLastError());
		return false;
	}

	if (scOrWnd.data == 0)
		return true;

	int dir = (scOrWnd.data<0)?GW_HWNDPREV:GW_HWNDNEXT;
	int i = abs(scOrWnd.data);
	while (i-- > 0)
		scOrWnd.hWnd = GetNextWindow(scOrWnd.hWnd, dir);
	return true;
}

void IShortcutImpl::setPosition(POSITION pos) 
{
	m_position = pos;
	m_curPos = readjustCoords(m_position);
	if (isCreated())
		MoveShortcut(m_curPos);
}

void IShortcutImpl::setZOrder(SHORTCUTORWINDOW zOrder) 
{
	m_zOrderWindow = zOrder;
	if (isCreated()) {
		if (findWindow(m_zOrderWindow))
			SetWindowPos(Window::handle(), m_zOrderWindow.hWnd, 0, 0, 0, 0, SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE);
		else
			scWarningMessageSimpleLocal(SCW_NO_ZORDER_REORDER, GetLastError());
	}
}

void IShortcutImpl::setParrentWindow(SHORTCUTORWINDOW parrent) 
{
	if (m_parrentWindow == parrent)
		return;
	m_parrentWindow = parrent;
	if (isCreated())
		reCreateShortcutRemote();
}

// TODO: is this implemented/inuse ?
void IShortcutImpl::setCaption(bool bCaption) 
{
	if (m_bCaptioned == bCaption)
		return;
	if (isCreated()) {
		m_bCaptioned = bCaption;
		reCreateShortcutRemote();
	} else {
		m_bCaptioned = bCaption;
	}
}

void IShortcutImpl::execBang(int iCmd, string szArg)
{
	if (iCmd == m_iCommandArray[ISCI_CMD_POS]) {
		setPosition(GetPosition(szArg));
	} else if (iCmd == m_iCommandArray[ISCI_CMD_SHOW]) {
		string cmd = GetToken(szArg, false);
		if (isCreated()) {
			m_bVisibleSet = true;
			if (cmd == "hide")
				::ShowWindow(Window::handle(), SW_HIDE);
			else if (cmd == "toggle") {
				if (::IsWindowVisible(Window::handle())) 
					::ShowWindow(Window::handle(), SW_HIDE);
				else
					::ShowWindow(Window::handle(), SW_SHOWNORMAL);
			} else
				::ShowWindow(Window::handle(), SW_SHOWNORMAL);
		} else {
			m_bVisibleSet = true;
			if (cmd != "hide") {
				createShortcut();
			} 
		}
	} else if (iCmd == m_iCommandArray[ISCI_CMD_PARRENT]) {
		string cmd = GetToken(szArg, false);
		m_parrentWindow.hWnd = NULL;
		if (cmd == "none") {
			m_parrentWindow.data = 1;
		} else if (cmd == "desktop") {
			m_parrentWindow.data = 2;
		} else if (cmd == "shortcut") {
			m_parrentWindow.data = 3;
		} else {
			m_parrentWindow.data = 0;
			m_parrentWindow.scName = GetToken(szArg, false);
			m_parrentWindow.wndClass = GetToken(szArg, false);
			m_parrentWindow.wndTitle = GetToken(szArg, false);
		}
	} else if (iCmd == m_iCommandArray[ISCI_CMD_FLAGS]) {
		string token;
		while (GetToken(token, szArg, false)) {
			execBang(m_iCommandArray[ISCI_CMD_FLAG], token);
		}
	} else if (iCmd == m_iCommandArray[ISCI_CMD_ZORDER]) {
		string cmd = GetToken(szArg, false);
		SHORTCUTORWINDOW m_zOrder;
		m_zOrder.scName = m_zOrder.wndClass = m_zOrder.wndTitle = "";
		if (cmd == "bottom") {
			m_zOrder.hWnd = HWND_BOTTOM;
		} else if (cmd == "notopmost") {
			m_zOrder.hWnd = HWND_NOTOPMOST;
		} else if (cmd == "top") {
			m_zOrder.hWnd = HWND_TOP;
		} else if (cmd == "topmost") {
			m_zOrder.hWnd = HWND_TOPMOST;
		} else if (cmd == "after") {
			m_zOrder.scName = GetToken(szArg, false);
			m_zOrder.wndClass = GetToken(szArg, false);
			m_zOrder.wndTitle = GetToken(szArg, false);
			m_zOrder.data = IConfigurationHelpers::stoi(GetToken(szArg, false));
		} 
		setZOrder(m_zOrder);
	} else if (iCmd == m_iCommandArray[ISCI_CMD_FLAG]) {
		if (stricmp(szArg.c_str(), "caption") == 0) {
			setCaption(true);
		} else if (stricmp(szArg.c_str(), "alphaMap") == 0) {
			setFlagValue("alphaMap", true);
		} else if (stricmp(szArg.c_str(), "alphaTrans") == 0) {
			setFlagValue("alphaTrans", true);
		} else if (stricmp(szArg.c_str(), "hide") == 0) {
			m_bVisible = false;
		} else if (stricmp(szArg.c_str(), "ontop") == 0) {
			setFlagValue("onTop", true);
		} else if (stricmp(szArg.c_str(), "opaque") == 0) {
			setFlagValue("opaque", true);
		} else {
			int pos1 = szArg.find(':');
			if (pos1 == szArg.npos)
				return;
			while (pos1 != szArg.npos) {
				execBang(m_iCommandArray[ISCI_CMD_FLAG], szArg.substr(0, pos1));
				szArg = szArg.substr(pos1+1);
				pos1 = szArg.find(':');
			}
			execBang(m_iCommandArray[ISCI_CMD_FLAG], szArg);
		}
	} else
		IShortcut::execBang(iCmd, szArg);
}

void IShortcutImpl::MoveShortcut(int x, int y)
{
	m_curPos.x = x;
	m_curPos.y = y;
	if (isCreated())
		SetWindowPos(Window::handle(), 0, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
}

void IShortcutImpl::MoveShortcutDelta(int x, int y)
{
	m_curPos.x += x;
	m_curPos.y += y;
	MoveShortcut(m_curPos.x, m_curPos.y);
}

void IShortcutImpl::MoveShortcut(POSITION pos)
{
	MoveShortcut(pos.x, pos.y);
}

void IShortcutImpl::MoveShortcut(POINT pos)
{
	MoveShortcut(pos.x, pos.y);
}

const bool IShortcutImpl::isCreated() const
{
	return IsWindow(Window::handle())?true:false;
}


bool IShortcutImpl::isCloseTo(int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY)
{
	POINT pt = {m_curSize.cx, m_curSize.cy	};
	return ::isCloseTo(m_curPos, pt, x, y, cx, cy, span, matchX, matchY);
}



