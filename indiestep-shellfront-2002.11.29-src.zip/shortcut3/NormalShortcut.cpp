// NormalShortcut.cpp: implementation of the CNormalShortcut class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)

#include <windows.h>
#include <commctrl.h>
#include "ShortcutFactory.h"
#include "global.h"
#include "bang_cmd.h"
#include "NormalShortcut.h"
#include "../lsapi/safestr.h"
#include "string_util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CFG_ITM_SET_TEMPLATE_CPP(CCINormalShortcut, CCDTNormalShortcut);
CFG_ITM_SET_TEMPLATE_CPP(CCISlaves, CCDTSlaves);

CNormalShortcut::CNormalShortcut(CShortcutFactory *sf, string configuration) : IShortcutImpl(sf), 
		LEAVE_TIMER_ID(1),
		fLeaveTimer(0),
		m_iMoveButton(0),
		m_bHaveSlaves(false),
		m_currentAction(CState::ssNormal),
		m_bNoGrabFocus(false),
		m_state(sf)
{
	m_iCommandArray[SC_CMD_TOOLTIP]	= IShortcut::m_pFactory->getStringID("tooltip");
	m_iCommandArray[SC_CMD_IMAGES]	= IShortcut::m_pFactory->getStringID("images");
	m_iCommandArray[SC_CMD_COMMANDS]= IShortcut::m_pFactory->getStringID("commands");
	m_iCommandArray[SC_CMD_SOUNDS]	= IShortcut::m_pFactory->getStringID("sounds");
	m_iCommandArray[SC_CMD_SLAVE]	= IShortcut::m_pFactory->getStringID("slave");
	m_iCommandArray[SC_CMD_MOVEBTN]	= IShortcut::m_pFactory->getStringID("AddToMoveButton");
	m_iCommandArray[SC_CMD_MOVEBTNS]= IShortcut::m_pFactory->getStringID("moveButton");
	m_iCommandArray[SC_CMD_SETACTION]=IShortcut::m_pFactory->getStringID("setAction");
	m_iCommandArray[SC_CMD_ALPHAS]	= IShortcut::m_pFactory->getStringID("alphaLevels");
	m_iCommandArray[SC_CMD_FLAG]	= IShortcut::m_pFactory->getStringID("flag");
	


	// <x> <y> <normal-image> <hover-image> <left-cliked-image> 
	string x = GetToken(configuration, false);
	string y = GetToken(configuration, false);
	IShortcut::execBang("pos " + x + " " + y);
	IShortcut::execBang("normal image " + GetToken(configuration, false));
	IShortcut::execBang("hover image " + GetToken(configuration, false));
	IShortcut::execBang("left image " + GetToken(configuration, false));

}
/**
 *
 * Parses a "simple config line" 
 *
 * Is implemented in the interface (should not be changed)
 *
 */


CNormalShortcut::~CNormalShortcut()
{
	fLeaveTimer = 0;
}

//---------------------------------------------------------
// Message handling
//---------------------------------------------------------
void CNormalShortcut::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onMouseActivate, WM_MOUSEACTIVATE)
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onMouseMove, WM_MOUSEMOVE)
	MESSAGE(onTimer, WM_TIMER)
	case WM_LBUTTONDOWN:
		onButtonDown(CState::ssLeft, message);
		break;
	case WM_RBUTTONDOWN:
		onButtonDown(CState::ssRight, message);
		break;
	case WM_MBUTTONDOWN:
		onButtonDown(CState::ssMiddle, message);
		break;
	case WM_LBUTTONUP:
		onButtonUp(CState::ssLeft);
		break;
	case WM_RBUTTONUP:
		onButtonUp(CState::ssRight);
		break;
	case WM_MBUTTONUP:
		onButtonUp(CState::ssMiddle);
		break;
	MESSAGE(onDropFiles, WM_DROPFILES)
	MESSAGE(onShowWindow, WM_SHOWWINDOW)
	MESSAGE(onNotify, WM_NOTIFY)
	MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
	default: 
		IShortcutImpl::windowProc(message);
	}
}
void CNormalShortcut::createShortcut()
{
	setAction(CState::ssNormal, false);
	IShortcutImpl::createShortcut();
}
void CNormalShortcut::onWindowPosChanging(Message& message)
{
	WINDOWPOS *pos = (LPWINDOWPOS) message.lParam;
//	if (!(pos->flags&SWP_NOACTIVATE)&&(m_bNoGrabFocus)) {
//	if (m_bNoGrabFocus) {
//		pos->hwndInsertAfter = m_zOrderWindow.hWnd; // Window::handle();
//		pos->flags |= SWP_NOACTIVATE;
//	} 
//	pos->flags |= SWP_NOOWNERZORDER;
	if (!Window::handle())
		return;
	if (!(pos->flags&SWP_NOMOVE)) {
		if (!IShortcutImpl::m_bIsMoving)
			IShortcut::m_pFactory->onWindowPosChanging(pos);
		if (m_bHaveSlaves) {
			int x = pos->x-IShortcutImpl::m_curPos.x;
			int y = pos->y-IShortcutImpl::m_curPos.y;
			if (x||y) {
				for (LST_SLAVES::iterator it = m_lstSlaves.begin(); it != m_lstSlaves.end();it++) {
					if ((!(*it).hWnd)&&(!(*it).sc))
						(*it) = recreateSlave((*it));
					if ((*it).sc)
						((*it).sc)->MoveShortcutDelta(x, y);
					else if (IsWindow((*it).hWnd)) {
						RECT r;
						GetWindowRect((*it).hWnd, &r);
						SetWindowPos((*it).hWnd, HWND_TOP, r.left+x, r.top+y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
					} else {
						scErrorMessageSimpleLocal(SCE_UNKNOWN_SLAVE, GetLastError());
					}
				}
			}
		}
		IShortcutImpl::m_curPos.x = pos->x;
		IShortcutImpl::m_curPos.y = pos->y;
	}
}

CNormalShortcut::TYPE_SLAVES CNormalShortcut::recreateSlave(TYPE_SLAVES slave) {
	if (!slave.scName.empty()) {
		slave.sc = IShortcut::m_pFactory->findShortcut(slave.scName);
		slave.hWnd = NULL;
	} else {
		slave.sc = NULL;
		slave.hWnd = FindWindow(slave.wndClass.empty()?NULL:slave.wndClass.c_str(), 
			slave.wndCaption.empty()?NULL:slave.wndCaption.c_str());
	}
	return slave;
}

void CNormalShortcut::onNotify(Message& message)
{
	NMHDR *pnmh = (LPNMHDR) message.lParam;
	if (pnmh->code == TTN_GETDISPINFO) {
		 NMTTDISPINFO *nmtdi = (LPNMTTDISPINFO)message.lParam;
		 if (m_sToolTip.length() > 79)
			 strcpy(nmtdi->szText, (m_sToolTip.substr(0,76) + "...").c_str());
		 else
			 strcpy(nmtdi->szText, m_sToolTip.c_str());
	}
}


void CNormalShortcut::onCreate(Message& message)
{
	DragAcceptFiles(Window::handle(), true);
	IShortcutImpl::onCreate(message);
	setAction(m_currentAction);
	if (!m_sToolTip.empty())
		IShortcut::m_pFactory->addHint(Window::handle(), LPSTR_TEXTCALLBACK);
}


void CNormalShortcut::onDestroy(Message& message)
{
	if (fLeaveTimer)
		KillTimer(Window::handle(), LEAVE_TIMER_ID);
//		KillTimer(handle(), fLeaveTimer);
	fLeaveTimer = 0;
	IShortcut::m_pFactory->removeHint(Window::handle());
}

void CNormalShortcut::onMouseMove(Message& message)
{
	if (!fLeaveTimer)
		fLeaveTimer = SetTimer(Window::handle(), LEAVE_TIMER_ID, 20, NULL);

	if ((m_iMoveButton) && ((message.wParam&m_iMoveButton)==m_iMoveButton)) {
		SendMessage(Window::handle(), WM_NCLBUTTONDOWN,HTCAPTION,0);
	}

	if (m_currentAction != CState::ssNormal)
		return;

	setAction(CState::ssHover);
	execAction(CState::ssHover);
	IShortcut::m_pFactory->relayHintMessage(Window::handle(), message);
}

void CNormalShortcut::onMouseActivate(Message& message)
{
	PostMessage(Window::handle(), message.lParamHi, 0, 0);
	message.lResult = MA_NOACTIVATEANDEAT; // MA_ACTIVATE; //MA_NOACTIVATEANDEAT; // MA_NOACTIVATE;
}


void CNormalShortcut::onTimer(Message& message)
{
	if (message.wParam != LEAVE_TIMER_ID)
		return ;

	POINT cursorPos;
	bool isWithin;

	GetCursorPos(&cursorPos);
	cursorPos.x -= IShortcutImpl::m_curPos.x;
	cursorPos.y -= IShortcutImpl::m_curPos.y;

	if (m_bOpaque) {
		RECT clientRect;
		GetClientRect(Window::handle(), &clientRect);
		isWithin = (PtInRect(&clientRect, cursorPos) != FALSE);
	} else {
		HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
		GetWindowRgn(Window::handle(), windowRgn);
		isWithin = (PtInRegion(windowRgn, cursorPos.x, cursorPos.y) != FALSE);
		DeleteObject(windowRgn);
	}

	if (!isWithin) {
		KillTimer(Window::handle(), fLeaveTimer);
		fLeaveTimer = 0;
		setAction(CState::ssNormal);
		execAction(CState::ssNormal);
	}
}

void CNormalShortcut::onButtonDown(CState::ShortcutActions action, Message& message)
{
	if (m_currentAction == action)
		return;
	setAction(action);
}

inline void CNormalShortcut::onButtonUp(CState::ShortcutActions action)
{
	if (m_currentAction != action)
		return;
	execAction(action);
	setAction(CState::ssHover);
}

void CNormalShortcut::onDropFiles(Message& message)
{

	UINT fileCount = DragQueryFile(HDROP(message.wParam), ~0, NULL, 0);
	string arguments;

	if (!fileCount)
		return ;

	for (int i = 0; i < fileCount; i++) {
		UINT len = DragQueryFile(HDROP(message.wParam), i, NULL, 0) + 1;
		char *str = new char[len+1];
		DragQueryFile(HDROP(message.wParam), i, str, len);
		arguments += "\"" + (string) str + "\" ";
		delete [] str;
	}
	execAction(CState::ssDrop, arguments);
}

void CNormalShortcut::onShowWindow(Message& message)
{
	if (((BOOL)message.wParam)&&(m_currentAction != CState::ssNormal))
		setAction(CState::ssNormal);
}

void CNormalShortcut::setAction(CState::ShortcutActions newAction, bool refresh)
{
	if (newAction == CState::ssNone)
		return;
	m_state.setAction(newAction);
	m_currentAction = newAction;
	CLSBitmap* pBmp = m_state.getBitmap();
	if ((!pBmp)||(!pBmp->getBitmapHandle()))
		return;
	IShortcutImpl::setupImage(pBmp);
	if (refresh)
		IShortcutImpl::applyImage(refresh);
}

void CNormalShortcut::execAction(CState::ShortcutActions action, string arguments)
{
//	SetForegroundWindow(m_pFactory->handle());
	m_state.exec(action, IShortcut::m_pFactory->handle(), arguments);
}

#define FIXUP_ALL_RECURSIVE_BEGIN() \
	string token;

#define FIXUP_ONE_RECURSIVE(newCmd, str) \
	if (!GetToken(token, szArg, false)) \
		return; \
		execBang(m_iCommandArray[newCmd], (string)str + GetToken(szArg, false));

#define FIXUP_ALL_RECURSIVE(newCmd) \
	FIXUP_ONE_RECURSIVE(newCmd, "normal "); \
	FIXUP_ONE_RECURSIVE(newCmd, "hover "); \
	FIXUP_ONE_RECURSIVE(newCmd, "left "); \
	FIXUP_ONE_RECURSIVE(newCmd, "right "); \
	FIXUP_ONE_RECURSIVE(newCmd, "middle "); \
	FIXUP_ONE_RECURSIVE(newCmd, "drag ");

void CNormalShortcut::execBang(int iCmd, string szArg)
{
	if (false) {
	} else if (iCmd == m_iCommandArray[SC_CMD_SLAVE]) {
		string scName = GetToken(szArg, false);
		string wndClass = GetToken(szArg, false);
		string wndCaption = GetToken(szArg, false);
		AddSlave(scName, wndClass, wndCaption);
	} else if (iCmd == m_iCommandArray[SC_CMD_MOVEBTN]) {
		if (stricmp(szArg.c_str(), "right") == 0) {
			m_iMoveButton |= MK_RBUTTON;
		} else if (stricmp(szArg.c_str(), "left") == 0) {
			m_iMoveButton |= MK_LBUTTON;
		} else if (stricmp(szArg.c_str(), "middle") == 0) {
			m_iMoveButton |= MK_MBUTTON;
		} else if (stricmp(szArg.c_str(), "ctrl") == 0) {
			m_iMoveButton |= MK_CONTROL;
		} else if (stricmp(szArg.c_str(), "shift") == 0) {
			m_iMoveButton |= MK_SHIFT;
		}
	} else if (iCmd == m_iCommandArray[SC_CMD_FLAG]) {
		if (szArg == "retainZOrder") {
			m_bNoGrabFocus = true;
		} else {
			IShortcutImpl::execBang(iCmd, szArg);
		}
	} else if (iCmd == m_iCommandArray[SC_CMD_MOVEBTNS]) {
		m_iMoveButton = 0;
		string token;
		while (GetToken(token, szArg, TRUE)) {
			execBang(m_iCommandArray[SC_CMD_MOVEBTN], token);
		}
	} else if (iCmd == m_iCommandArray[SC_CMD_SETACTION]) {
		setAction(CState::getAction(GetToken(szArg, false).c_str()));
	} else if (iCmd == m_iCommandArray[SC_CMD_TOOLTIP]) {
		m_sToolTip = szArg;
	}else {
		if (!m_state.execBang(iCmd, szArg))
			IShortcutImpl::execBang(iCmd, szArg);
	}
}

void CNormalShortcut::AddSlave(string name, string wndClass, string wndTitle)
{
	TYPE_SLAVES slave;
	slave.scName = name;
	slave.wndClass = wndClass;
	slave.wndCaption = wndTitle;
	slave.hWnd = NULL;
	slave.sc = NULL;
	m_lstSlaves.push_back(recreateSlave(slave));
	m_bHaveSlaves = m_lstSlaves.size() > 0;
}

CState* CNormalShortcut::getState()
{
	return &m_state;
}


void CNormalShortcut::onRefreshShortcut()
{
}
IConfigurationItem* CNormalShortcut::getConfigurationIF() {
	return new CCINormalShortcut(this);
}

string CNormalShortcut::getStepRC(bool bRecursive) {
	string ret;
	ret += "; \n";
	ret += "*shortcutEx \"" + CNormalShortcut::getShortName() + "\" \"" + IShortcut::getName() + "\" " + IConfigurationHelpers::itos(IShortcutImpl::getPosition().x) + " " + IConfigurationHelpers::itos(IShortcutImpl::getPosition().y) + "\n";
	if (bRecursive) {
		CCIZOrder zorder(this);
		ret += zorder.getStepRC(true);
		CCIParrent parrent(this);
		ret += parrent.getStepRC(true);
		CCIState state(getState(), this);
		ret += state.getStepRC(true);
	}
	// Generate flags
	string flg;
	if (!IShortcutImpl::m_bVisible)
		flg += "hide ";
	if (IShortcutImpl::getZOrder().hWnd == HWND_TOPMOST)
		flg += "ontop ";
	if (IShortcutImpl::m_bUseAlphaMap)
		flg += "alphaMap ";
	if (IShortcutImpl::m_bUseAlphaTrans)
		flg += "alphaTrans ";
	if (IShortcutImpl::m_bOpaque)
		flg += "opaque ";
	if (!flg.empty()) 
		ret += "*shortcutEx flags " + flg + "\n";

	if (m_iMoveButton) {
			ret += "*shortcutEx moveButton ";
			if (m_iMoveButton&MK_LBUTTON) 		ret += "left ";
			if (m_iMoveButton&MK_MBUTTON) 		ret += "middle ";
			if (m_iMoveButton&MK_RBUTTON) 		ret += "right ";
			if (m_iMoveButton&MK_CONTROL) 		ret += "ctrl ";
			if (m_iMoveButton&MK_SHIFT) 		ret += "shift ";
			ret += "\n";
	}
	for (LST_SLAVES::iterator it = m_lstSlaves.begin(); it != m_lstSlaves.end();it++) {
		TYPE_SLAVES slv = (*it);
		ret += "*shortcutEx slave \"" + slv.scName + "\" \"" + slv.wndClass + "\" \"" + slv.wndCaption + "\"\n";
	}
	ret += "*shortcutEx ~" + CNormalShortcut::getShortName() + "\n";
	return ret;
}
