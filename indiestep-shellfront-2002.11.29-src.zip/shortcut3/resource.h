//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by shortcut3.rc
//
#define IDD_SHORTCUTFACTORY             101
#define IDD_NO_CONFIGURATION            102
#define IDD_STATE_CFG                   103
#define IDD_ZORDER_CFG                  104
#define IDD_POSITION_CFG                105
#define IDD_PROPPAGE_MEDIUM             106
#define IDD_PARRENT_CFG                 107
#define IDI_GRAB_001                    108
#define IDI_GRAB_002                    109
#define IDD_NORMAL_SC_CFG               111
#define IDD_SLAVE_CFG                   113
#define IDD_SCGROUP_CFG                 114
#define IDD_STEPRC_CFG                  115
#define IDD_SIMPLE_SC_CFG               116
#define IDD_FLAG_CFG                    117
#define IDR_MAINFRAME                   128
#define IDD_PAGE0                       201
#define IDD_PAGE1                       202
#define IDD_PAGE2                       203
#define IDC_FRAME1                      1001
#define IDC_CHECK1                      1003
#define IDC_USE_BALOON                  1003
#define IDC_SOUND_DEFAULT               1003
#define IDC_RETENTION                   1003
#define IDC_BTN_L                       1003
#define IDC_RADIO1                      1004
#define IDC_NA                          1004
#define IDC_BTN_M                       1004
#define IDC_LIST1                       1005
#define IDC_ONTOP                       1005
#define IDC_BTN_R                       1005
#define IDC_SLAVE_LIST                  1005
#define IDC_SC_LIST                     1005
#define IDC_FLAGS                       1005
#define IDC_STATIC_A                    1006
#define IDC_TOP                         1006
#define IDC_KEY_C                       1006
#define IDC_GROUPBOX_A                  1007
#define IDC_BOTTOM                      1007
#define IDC_AFTER_SC                    1008
#define IDC_AFTER_WND                   1009
#define IDC_KEY_S                       1009
#define IDC_SNAP_SPACE                  1012
#define IDC_SNAP_SPACE_SPIN             1013
#define IDC_SOUND_NORMAL                1014
#define IDC_SOUND_HOVER                 1015
#define IDC_SOUND_RIGHT                 1016
#define IDC_SOUND_MIDDLE                1017
#define IDC_SOUND_LEFT                  1018
#define IDC_SOUND_DRAG                  1019
#define IDC_SC_COUNT                    1020
#define IDC_OPTIONS_POS                 1021
#define IDC_COMMAND                     1022
#define IDC_ARGUMENT                    1023
#define IDC_SOUND                       1024
#define IDC_IMAGE                       1026
#define IDC_NOCFG                       1027
#define IDC_ALPHA                       1027
#define IDC_WND_CLS                     1028
#define IDC_SEL_SC                      1029
#define IDC_WND_CAP                     1030
#define IDC_WND_DST                     1031
#define IDC_DIST                        1031
#define IDC_DIST_SPIN                   1033
#define IDC_SPIN_Y                      1034
#define IDC_X                           1036
#define IDC_X_C                         1037
#define IDC_X_L                         1038
#define IDC_X_R                         1039
#define IDC_Y                           1040
#define IDC_Y_C                         1041
#define IDC_Y_T                         1042
#define IDC_Y_B                         1043
#define IDC_SPIN_X                      1044
#define IDC_DESKTOP                     1045
#define IDC_SC                          1046
#define IDC_USE_SC                      1047
#define IDC_USE_WND                     1048
#define IDC_GRABBER                     1049
#define IDC_BROWSE                      1050
#define IDC_TOOLTIP                     1051
#define IDC_ACTION                      1053
#define IDC_BTN_ADD                     1054
#define IDC_BTN_DEL                     1055
#define IDC_STEP_RC                     1059
#define IDC_ALPHASPIN                   1063
#define IDC_ALPHA_SPIN                  1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
