/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/ 
// DataStore.cpp: implementation of the DataStore class.
//
//////////////////////////////////////////////////////////////////////
#pragma warning(disable: 4786)
#include "DataStore.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DataStore::DataStore()
{
}

DataStore::~DataStore()
{
	Clear();
}

BOOL DataStore::StoreData(WORD id, void *data, WORD len)
{
	dataHolderMap::iterator iter;
	DataHolder *holder;

	iter = dataMap.find(id);

	if (iter != dataMap.end())
	{
		return FALSE;
	}

	holder = new DataHolder(data, len);

	dataMap[id] = holder;

	return TRUE;
}

BOOL DataStore::ReleaseData(WORD id, void *data, WORD len)
{
	dataHolderMap::iterator iter;
	DataHolder *holder;

	iter = dataMap.find(id);

	if (iter == dataMap.end())
	{
		return FALSE;
	}

	holder = iter->second;
	holder->GetData(data, len);

	delete holder;
	dataMap.erase( iter );

	return TRUE;
}

DataHolder::DataHolder()
{
	len = 0;
	data = NULL;
}

DataHolder::DataHolder(void *theData, WORD length)
{
	if (theData == NULL || length == 0)
	{
		len = 0;
		data = NULL;
		return ;
	}

	data = new BYTE[length];
	len = length;

	memcpy(data, theData, length);
}

DataHolder::~DataHolder()
{
	if (data)
	{
		delete data;
	}
}

int DataHolder::GetData(void *target, WORD length)
{
	if (data == NULL || target == NULL ||
	        len == 0 || length == 0)
	{
		return 0;
	}

	if (length > len)
	{
		length = len;
	}

	memcpy(target, data, length);

	return length;
}

int DataHolder::SetData(void *source, WORD length)
{
	if (source == NULL || length == 0)
	{
		if (data)
		{
			delete data;
			data = NULL;
			len = 0;
		}
		return 0;
	}

	if (data == NULL)
	{
		data = new BYTE[length];
	}

	memcpy(data, source, length);

	len = length;

	return length;
}

void DataStore::Clear()
{
	dataHolderMap::iterator iter;

	iter = dataMap.begin();

	while (iter != dataMap.end())
	{
		delete iter->second;
		iter++;
	}

	dataMap.clear();
}
