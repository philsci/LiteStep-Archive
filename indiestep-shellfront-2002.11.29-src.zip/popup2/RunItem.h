/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_RUNITEM_H__173AFC53_87D4_11D2_B6C0_00C0DF466974__INCLUDED_)
#define AFX_RUNITEM_H__173AFC53_87D4_11D2_B6C0_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_POPRUN_HISTORY 5
#define MAX_POPRUN_STRING 1024

#include "commandItem.h"
#include "..\lsapi\mru.h" 
/**
a menuitem that contains an editbox. the user can enter text in the edit box
and execute simple commands. Bang commands and common commands are supported.
the runitem implements autocompletion and history
*/
class RunItem : public CommandItem
{
public:
	/**
	constructs a runitem object

	@param pszTitle the title that is painted to the left of the editbox
	                this usually 'Run:' or 'Execute:' or something like that.
	*/
	RunItem(LPSTR pszTitle);

	/// destroy the object
	virtual ~RunItem();

	/**
	notifies the object that it have been connected to a menu

	@param pMenu pointer to the menu that the item is connected
	*/
	void Attached(PopupMenu* pMenu);

	/**
	handles WM_COMMAND messages. this item is listening for IDOK (user presses
	enter in the editbox, VK_UP (user presses arrow up and VK_DOWN (user presses
	key down

	@param wParam
	@param lParam
	*/
	LRESULT Command(WPARAM wParam, LPARAM lParam);

	/**
	(de)activate this run item

	@param bActive the new active state
	*/
	BOOL Active(BOOL bActive);

	/**
	sets the runitems position withing the menu

	@param nLeft x location
	@param nTop y location
	*/
	void SetPosition(int nLeft, int nTop);

	/**
	should the last executed command be saved in the editobx

	@param bRememeberLast should the last executed command stay?
	*/
	static void SetRememberLast(BOOL bRememberLast)
	{
		m_bRememberLast = bRememberLast;
	};

	/**
	invokes the runitem
	*/
	void Invoke();

protected:

	// Run items can have icons
	BOOL ShouldPaintIcon()
	{
		return TRUE;
	}

	/// handle to the editbox
	HWND m_hEdit;

	/// should we delete the information in the editobx after it is exevuted
	static BOOL m_bRememberLast;

	/// MRU Run list class...
	MRUList mruList;
};

#endif // !defined(AFX_RUNITEM_H__173AFC53_87D4_11D2_B6C0_00C0DF466974__INCLUDED_)
