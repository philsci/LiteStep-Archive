/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include "stdafx.h"
#include "GradientPainter.h"
#include "MenuItem.h"

GradientPainter::GradientPainter(COLORREF nFrom, COLORREF nTo)
{
	m_nFrom = nFrom;
	m_nTo = nTo;

	m_nBuffHeight = 0;
	m_nBuffWidth = 0;

	m_hBuffDC = NULL;
	m_hBuffBmp = NULL;
}

GradientPainter::~GradientPainter()
{
	if (m_hBuffDC)
		DeleteDC(m_hBuffDC);
	m_hBuffDC = NULL;

	if (m_hBuffBmp)
		DeleteObject(m_hBuffBmp);
	m_hBuffBmp = NULL;
}

void GradientPainter::Paint(HDC hDC, CONST RECT *prc)
{
	RECT r;
	CopyRect(&r, prc);

	int nWidth = r.right - r.left;
	int nHeight = r.bottom - r.top;

	if (nWidth != m_nBuffWidth || nHeight != m_nBuffHeight)
	{
		RECT r2;
		double stepX;
		double cr, cg, cb, dr, dg, db;
		HBRUSH hBrush;
		int gradSteps = nWidth / 2;

		if (m_hBuffDC)
			DeleteDC(m_hBuffDC);

		if (m_hBuffBmp)
			DeleteObject(m_hBuffBmp);

		m_nBuffWidth = nWidth;
		m_nBuffHeight = nHeight;

		m_hBuffDC = CreateCompatibleDC(hDC);
		m_hBuffBmp = CreateCompatibleBitmap(hDC, m_nBuffWidth, m_nBuffHeight);
		SelectObject(m_hBuffDC, m_hBuffBmp);

		// get current color
		cr = GetRValue(m_nFrom);
		cg = GetGValue(m_nFrom);
		cb = GetBValue(m_nFrom);

		// Get delta color
		dr = (cr - GetRValue(m_nTo)) / gradSteps;
		dg = (cg - GetGValue(m_nTo)) / gradSteps;
		db = (cb - GetBValue(m_nTo)) / gradSteps;

		stepX = ((double)(r.right - r.left)) / (double)gradSteps;

		for (int i = 0; i < gradSteps + 1; i++)
		{
			hBrush = CreateSolidBrush(RGB((int)cr, (int)cg, (int)cb));

			cr -= dr;
			cg -= dg;
			cb -= db;

			//SetRect(&r2, (int)(stepX*(i-1)),r.top,(int)(stepX*i),r.bottom);
			SetRect(&r2, (int)(stepX*(i - 1)), 0, (int)(stepX*i), m_nBuffHeight);
			FillRect(m_hBuffDC, &r2, hBrush);
			DeleteObject(hBrush);
		}
	}

	// copy our buffer to the screen
	BitBlt(hDC, r.left, r.top, m_nBuffWidth, m_nBuffHeight, m_hBuffDC, 0, 0, SRCCOPY);
}

/* void GradientPainter::Paint(MenuItem* m, HDC hDC)
{
	RECT r;
 
	// call super
	Painter::Paint(m, hDC);
 
	m->GetItemRect(&r);
 
	if((m->GetWidth()) != m_nBuffWidth || (m->GetHeight())!= m_nBuffHeight)
	{
		RECT r2;
		double stepX;
		double cr,cg,cb,dr,dg,db;
		HBRUSH hBrush;
		int gradSteps = m->GetWidth()/2;
		
		if(m_hBuffDC)
			DeleteDC(m_hBuffDC);
 
		if(m_hBuffBmp)
			DeleteObject(m_hBuffBmp);
 
		m_nBuffWidth = m->GetWidth();
		m_nBuffHeight = m->GetHeight();
	
		m_hBuffDC = CreateCompatibleDC(hDC);
		m_hBuffBmp = CreateCompatibleBitmap(hDC, m_nBuffWidth, m_nBuffHeight);
		SelectObject(m_hBuffDC,m_hBuffBmp);
 
		// get current color
		cr = GetRValue(m_nFrom);
		cg = GetGValue(m_nFrom);
		cb = GetBValue(m_nFrom);
 
		// Get delta color
		dr = (cr - GetRValue(m_nTo))/gradSteps;
		dg = (cg - GetGValue(m_nTo))/gradSteps;
		db = (cb - GetBValue(m_nTo))/gradSteps;
 
		stepX = ((double)(r.right-r.left))/(double)gradSteps;
 
		for(int i=0; i<gradSteps+1; i++)
		{
			hBrush = CreateSolidBrush(RGB((int)cr,(int)cg,(int)cb));
 
			cr-=dr;
			cg-=dg;
			cb-=db;
 
			//SetRect(&r2, (int)(stepX*(i-1)),r.top,(int)(stepX*i),r.bottom);
			SetRect(&r2, (int)(stepX*(i-1)),0,(int)(stepX*i),m_nBuffHeight);
			FillRect(m_hBuffDC, &r2, hBrush);
			DeleteObject(hBrush);		
		}
	}
 
	// copy our buffer to the screen
	BitBlt(hDC, r.left, r.top, m_nBuffWidth, m_nBuffHeight, m_hBuffDC, 0, 0, SRCCOPY);
 
} */
