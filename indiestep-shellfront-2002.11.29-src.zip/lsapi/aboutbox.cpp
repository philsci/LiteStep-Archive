/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05/22/02 - Alessandro Limonta (allelimo)
  - Removed everything but dev team and system info from the about box
  - Restored the original size of the about box
05/16/02 - Erik Christiansson (Sci)
  - Merged changes, log and help into one function
05/15/02 - Alessandro Limonta (allelimo)
  - renamed from "Litestep Control Panel" to "About Litestep..."
  - changed from "Indie Litestep - build" to Litestep - Indie build" 
05/10/02 - Simon (ilmcuts)
  - if the about box is already open, !about will just bring it to the front
  - removed obsolete code (due to not having to handle multiple hwnds now)
05/08/02 - John Woltman (repugnant)
  - moved bulk of WM_NOTIFY listview code into separate functions
  - pressing escape to dismiss the box works now
05/08/02 - Simon (ilmcuts)
  - cleaned up logfile viewer a bit
05/04/02 - Alessandro Limonta (allelimo)
  - additional options:
	1 - theme switcher (only a start...)
	2 - logfile viewer
  - re-added "System Information"
05/03/02 - Simon (ilmcuts)
  - fixed LsHelp.txt not appearing if changes.txt was missing
  - options "changes.txt" and "LS Help" also appear if the files are missing,
  in this case the expected location is shown instead of the files' contents
  - added "Configuration Files" - displays "step.rc" and the names of all
  included files plus the full path of each file. Doubleclicking should open
  the file in the associated program
  - removed "System Information"
04/30/02 - Alessandro Limonta (allelimo)
  - additional option in the drop down list: LsHelp
04/26/02 - Erik Christiansson (Sci)
  - Right-click menu added to !bang list
04/25/02 - John Woltman (repugnant)
  - Right-click a loaded module to copy its path or unload/reload it
04/22/02 - Christoffer Sj�berg (Vendicator)
  - Copy a bang to the clipboard by right-clicking
04/22/02 - John Woltman (repugnant)
  - About box can now execute bang commands
05/29/01 - Joachim Calvert (NeXTer)
  - Windows XP was erroneously reported as Windows 2000
01/02/01 - Bobby G. Vinyard (Message)
  - If changes.txt is present in the same directory as litestep.exe, an
  additonal option "changes.txt" will appear in the drop down list, selecting
  it will display the changes.txt
****************************************************************************/

#include "common.h"
#include "lsapi.h"
#include <commctrl.h>
//#include "../core/ifcs.h"
#include <math.h>

//#define IDM_COPYMODULEPATH		1001
//#define IDM_UNLOADMODULE		1002
//#define IDM_RELOADMODULE		1003
//#define IDM_EXECUTEBANG			1010
//#define IDM_EXECUTEBANGPARAMS	1011
//#define IDM_COPYBANG			1012
//#define IDM_COPYBANGPARAMS		1013
//#define IDM_COPYCODE			1014

HFONT CreateSimpleFont(LPCSTR, int, BOOL, BOOL);
int GetClientWidth(HWND);
void CopyToClipboard(const char  pszText[]);
void FormatBytes(DWORD, char *);
void TrimLeft(char *);
BOOL (WINAPI *SwitchToThisWindow)(HWND, BOOL)
	= (BOOL (WINAPI *)(HWND, BOOL)) GetProcAddress(GetModuleHandle("USER32.DLL"),
	"SwitchToThisWindow");


//extern const char rcsRevision[];
//extern char szAppPath[];
//extern char szRcPath[];

HWND hAboutBox;		// since there can only be one box it can be global
HWND hListView;
bool bBoxOpen = false;

enum
{
//	ABOUT_BANGS,
//	ABOUT_RCFILES,
	ABOUT_DEVTEAM,
//	ABOUT_MODULES,
//	ABOUT_REVIDS,
	ABOUT_SYSINFO,
//	ABOUT_THEMESW,
//	ABOUT_CHANGES,
//	ABOUT_LOGFILE,
//	ABOUT_HELP
};

//void AboutBangs();
void AboutDevTeam();
//void AboutModules();
//void AboutRevIDs();
void AboutSysInfo();
//void AboutThemeSw();
//void AboutLogFile();
//void AboutChanges();
//void AboutHelp();
//void AboutRCFiles();
//void AboutTextfile();

//char szTextfile[MAX_PATH] = "";

typedef void (*AboutFunction)();

struct
{
	const char *option;
	AboutFunction function;
}
aboutOptions[] = {
//	"Bang Commands",		AboutBangs,
//	"Configuration Files",	AboutRCFiles,
	"Development Team",		AboutDevTeam,
//	"Loaded Modules",		AboutModules,
//	"Revision IDs",			AboutRevIDs,
	"System Information",	AboutSysInfo,
	/*"Changes",				AboutChanges,
	"Log File",				AboutLogFile,
	"Help",					AboutHelp,*/
//	"Changes",				AboutTextfile,
//	"Log File",				AboutTextfile,
//	"Help",					AboutTextfile,
};

const int aboutOptionsCount = sizeof(aboutOptions) / sizeof(aboutOptions[0]);

// handlers for the listview
//void OnDoubleClickBangs(int iItem);
//void OnRightClickBangs(int iItem);
//void OnDoubleClickRCFiles(int iItem);
//void OnRightClickModules(int iItem);
//void OnRightClickHelp(int iItem);
//void OnDoubleClickHelp(int iItem);


//
// AboutBox Dialog Procedure
//

BOOL WINAPI AboutBoxProcedure(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_INITDIALOG:
		{
			hAboutBox = hWnd;
			hListView = GetDlgItem(hWnd, IDC_LISTVIEW);

			// Set full row selection
			ListView_SetExtendedListViewStyle(hListView, LVS_EX_FULLROWSELECT);

			// set title's font to Verdana 13pt Bold
			HFONT titleFont = CreateSimpleFont("Verdana", 13, FALSE, FALSE);
			SendDlgItemMessage(hWnd, IDC_TITLE, WM_SETFONT, (WPARAM) titleFont, FALSE);

			// set title with LS version
			SetDlgItemText(hWnd, IDC_TITLE, "LiteStep 0.24.6");
			//set Theme info
			char themeAuthor[17];
			char themeName[26];
			char themeOut[MAX_LINE_LENGTH];
			themeName[0] = themeAuthor[0] = 0;

			GetRCString("ThemeAuthor", themeAuthor, "(unknown)", sizeof(themeAuthor));
			GetRCString("ThemeName", themeName, "", sizeof(themeName));

			if(themeName[0])
				wsprintf(themeOut, "Theme: %s by %s", themeName, themeAuthor);
			else
				wsprintf(themeOut, "Theme by %s", themeAuthor);

			SetDlgItemText(hWnd, IDC_THEME_INFO, themeOut);

			// set compile time
			char compileTime[64];
			wsprintf(compileTime, "LiteStep - Indie build: %s", __DATE__); //, __TIME__ );
			SetDlgItemText(hWnd, IDC_COMPILETIME, compileTime);

			// add options to combo box
			for(int i = 0; i < aboutOptionsCount; i++)
				SendDlgItemMessage(hWnd, IDC_COMBOBOX, CB_ADDSTRING, 0, (LPARAM) aboutOptions[i].option);

			// default to revision IDs -> default to dev team
//			ShowWindow(GetDlgItem(hAboutBox, IDC_PARAMLABEL), SW_HIDE);
//			ShowWindow(GetDlgItem(hAboutBox, IDC_BANGPARAMS), SW_HIDE);
//			ShowWindow(GetDlgItem(hAboutBox, IDC_HELPFIND), SW_HIDE);
//			ShowWindow(GetDlgItem(hAboutBox, IDC_GOFIND), SW_HIDE);
			SendDlgItemMessage(hWnd, IDC_COMBOBOX, CB_SETCURSEL, ABOUT_DEVTEAM, 0);
			SetWindowLong(hAboutBox, GWL_USERDATA, ABOUT_DEVTEAM);
			aboutOptions[ABOUT_DEVTEAM].function();

			// center dialog on screen
			RECT rc;
			GetWindowRect(hWnd, &rc);

			bBoxOpen =  SetWindowPos(hWnd, HWND_TOP,
						(GetSystemMetrics(SM_CXSCREEN) - (rc.right - rc.left)) / 2,
						(GetSystemMetrics(SM_CYSCREEN) - (rc.bottom - rc.top)) / 2, 
						0, 0, SWP_NOSIZE | SWP_NOSENDCHANGING | SWP_SHOWWINDOW);

			// bring us to the front
			SwitchToThisWindow(hWnd, TRUE);
			return bBoxOpen;
		}

		
		case WM_CTLCOLORSTATIC:
		{
			// the header and title need a white (COLOR_WINDOW) background
			int id = GetDlgCtrlID((HWND) lParam);

			if(id == IDC_TITLE || id == IDC_THEME_INFO)
			{
				HDC hDC = (HDC) wParam;

				SetTextColor(hDC, GetSysColor(COLOR_WINDOWTEXT));
				SetBkColor(hDC, GetSysColor(COLOR_WINDOW));

				return (BOOL) GetSysColorBrush(COLOR_WINDOW);
			}
			else if(id == IDC_HEADER || id == IDC_LOGO)
				return (BOOL) GetSysColorBrush(COLOR_WINDOW);

			return FALSE;
		}


		case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
				case IDC_COMBOBOX:
					if (HIWORD(wParam) == CBN_SELCHANGE) {

						int i;

						// delete listview items
						SendDlgItemMessage(hWnd, IDC_LISTVIEW, LVM_DELETEALLITEMS, 0, 0);

						// delete listview columns
						for (i = 3; i >= 0; i--)
							SendDlgItemMessage(hWnd, IDC_LISTVIEW, LVM_DELETECOLUMN, (WPARAM) i, 0);

						// hide old elements
//						switch(GetWindowLong(hAboutBox, GWL_USERDATA))
//						{
//						case ABOUT_BANGS:
//							{
//								ShowWindow(GetDlgItem(hWnd, IDC_PARAMLABEL), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_BANGPARAMS), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_COMPILETIME), SW_SHOW);								
//							}
//							break;
//						case ABOUT_HELP:
//							{
//								ShowWindow(GetDlgItem(hWnd, IDC_HELPFIND), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_GOFIND), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_COMPILETIME), SW_SHOW);								
//							}
//							break;
//						}
						
						// get new selection
						i = SendDlgItemMessage(hWnd, IDC_COMBOBOX, CB_GETCURSEL, 0, 0);

						
						SetWindowLong(hAboutBox, GWL_USERDATA, i);
						aboutOptions[i].function();

//						switch(GetWindowLong(hAboutBox, GWL_USERDATA))
//						{
//						case ABOUT_BANGS:
//							{
//								ShowWindow(GetDlgItem(hWnd, IDC_COMPILETIME), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_PARAMLABEL), SW_SHOW);
//								ShowWindow(GetDlgItem(hWnd, IDC_BANGPARAMS), SW_SHOW);
//								
//							}
//							break;
//						case ABOUT_HELP:
//							{
//								ShowWindow(GetDlgItem(hWnd, IDC_COMPILETIME), SW_HIDE);
//								ShowWindow(GetDlgItem(hWnd, IDC_HELPFIND), SW_SHOW);
//								ShowWindow(GetDlgItem(hWnd, IDC_GOFIND), SW_SHOW);
//								
//							}
//							break;
//						}
						return true;

					} else break;

				case IDOK:
				case IDCANCEL:
				{
					// release title font
					HFONT titleFont = (HFONT) SendDlgItemMessage(hWnd, IDC_TITLE, WM_GETFONT, 0, 0);
					DeleteObject(titleFont);

					// close the dialog box
					EndDialog(hWnd, IDOK);
					bBoxOpen = false;
					return TRUE;
				}
			
//				case IDC_GOFIND:
//				{
//					char szFind[MAX_PATH];
//					GetDlgItemText(hWnd, IDC_HELPFIND, szFind, MAX_PATH);
//
//					int iSearch;
//					LV_FINDINFO plvfi;
//					int iStart = -1;
//
//					plvfi.flags = LVFI_PARTIAL | LVFI_STRING;
//					plvfi.psz = szFind;    //szFind contains the search string
//
//    				iSearch = ListView_FindItem(hListView, iStart , &plvfi);
//
//					ListView_SetHotItem(hListView, iSearch);
//					ListView_EnsureVisible(hListView, iSearch, TRUE);
//					return true;
//				}
			}
			return FALSE;
		}


//		case WM_NOTIFY:
//		{
//			int iBangLen = 0;
//
//			int iID = (int) wParam;
//			LPNMHDR pnmh = (LPNMHDR) lParam;
//
//			// if we catch a notify from the listview and there's a selected item
//			if(pnmh->idFrom == IDC_LISTVIEW ) {
//
//				if ( pnmh->code == LVN_DELETEITEM )
//					return TRUE;
//
//				int iSelItem = ListView_GetNextItem(hListView, -1, LVNI_SELECTED);
//
//				if (ListView_GetSelectedCount(hListView))
//				{
//					switch ( GetWindowLong(hWnd, GWL_USERDATA) )
//					{
//						case ABOUT_BANGS:
//							if ( pnmh->code == NM_DBLCLK )
//								OnDoubleClickBangs(iSelItem);
//							else if ( pnmh->code == NM_RCLICK)
//								OnRightClickBangs(iSelItem);
//							break;
//
//						case ABOUT_RCFILES:
//							if ( pnmh->code == NM_DBLCLK)
//								OnDoubleClickRCFiles(iSelItem);
//							break;
//							
//						case ABOUT_MODULES:
//							if ( pnmh->code == NM_RCLICK)
//								OnRightClickModules(iSelItem);
//							break;
//
//						case ABOUT_HELP:
//							if ( pnmh->code == NM_RCLICK)
//								OnRightClickHelp(iSelItem);
//							else if ( pnmh->code ==NM_DBLCLK)
//								OnDoubleClickHelp(iSelItem);
//							break;
///*						case ABOUT_THEMESW:
//							if (pnmh->code == NM_DBLCLK)
//							{
//								// We must have a selected item.
//								if ( iSelItem >= 0 )
//								{
//									char szThemePath[MAX_BANGCOMMAND];   
//									ListView_GetItemText(hListView, iSelItem, 0, szThemePath, MAX_BANGCOMMAND);
//
//									FILE *f;
//								
//									f = fopen (szRcPath, "r+");
//									if(!f)
//									{
//										MessageBox(hWnd, "no way", NULL, NULL);
//										return false;
//									} else {
//										char szrcStep[256] = "rcStep \"step.rc\";\n";
//										char szDirTheme[128] = "dirTheme \"$LitestepDir$themes\\";
//										char szEnding[10] = "\\\";\n";
//										char szInclude[35] = "include   \"$dirTheme$$rcStep$\"; ";
//								
//										strcat(szrcStep, szDirTheme);
//										strcat(szrcStep, szThemePath);
//										strcat(szrcStep, szEnding);
//										strcat(szrcStep, szInclude);
//									
//										//fwrite( & szrcStep, MAX_SWITCHLINE, 1, f);
//										fwrite( szrcStep, strlen(szrcStep), 1, f);
//									}
//									fclose(f);
//						
//									//ending with
//									LSExecuteEx(hWnd, NULL, "!Recycle", NULL, NULL, 0);
//
//									// release title font
//									HFONT titleFont = (HFONT) SendDlgItemMessage(hWnd, IDC_TITLE, WM_GETFONT, 0, 0);
//									DeleteObject(titleFont);   
//
//									// close the dialog box
//									EndDialog(hWnd, IDOK);
//									bBoxOpen = false;
//									return TRUE;
//								}
//								return false;
//							}*/
////							return false;
//					}
////					return false;
//				}
////				return false;
//			}
////			return false;
//		}
	}
	return false;
}


//
// handlers for the listview
//


// Double-click handler for bang list
//
//void OnDoubleClickBangs(int iItem)
//{
//	char szCommand[MAX_BANGCOMMAND + MAX_BANGARGS + 5];  // holds entire command
//	
//	memset(szCommand, 0, sizeof(szCommand)); // for safety
//	
//	ListView_GetItemText(hListView, iItem, 0, szCommand, MAX_BANGCOMMAND);
//
//	int iBangLen = strlen(szCommand);
//
//	// if there are parameters...
//	if ( GetDlgItemText(hAboutBox, IDC_BANGPARAMS, &szCommand[iBangLen + 1], MAX_BANGARGS) )
//		szCommand[iBangLen] = ' '; // ...make sure space between command/params
//
//	LSExecute(hAboutBox, szCommand, 0);
//}

// Right-click handler for bang list
//
//void OnRightClickBangs(int iItem)
//{
//	POINT cursorPos;
//	GetCursorPos(&cursorPos);
//	
//	HMENU hMenu = CreatePopupMenu();
//
//	// "Execute"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_EXECUTEBANG, IDS_LITESTEP_EXECUTEBANG, "&Execute");
//								
//	// "Execute with arguments"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_EXECUTEBANGPARAMS, IDS_LITESTEP_EXECUTEBANGPARAMS, "Execute with &parameters");
//	
//	// "Copy !bang"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_COPYBANG, IDS_LITESTEP_COPYBANG, "&Copy !bang to clipboard");
//	
//	// "Copy !bang with params"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_COPYBANGPARAMS, IDS_LITESTEP_COPYBANGPARAMS, "Copy !bang with p&arameters");
//
//	// not really a boolean value...oh well, its M$
//	BOOL menuItem = TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RETURNCMD, cursorPos.x, cursorPos.y, 0, hAboutBox, 0);
//
//	// if the user picked a menu item
//	if ( menuItem )
//	{
//		ScreenToClient(hListView, &cursorPos);
//		
//		LVHITTESTINFO hitInfo;
//		hitInfo.pt = cursorPos;
//
//		int i = ListView_HitTest(hListView, &hitInfo);
//
//		// and they were over a listview item
//		if(i == iItem)
//		{
//			char szBangCommand[MAX_PATH];
//			ListView_GetItemText(hListView, iItem, 0, szBangCommand, MAX_PATH);
//
//			switch (menuItem)
//			{
//			case IDM_COPYBANG:
//				CopyToClipboard(szBangCommand);
//				break;
//			case IDM_COPYBANGPARAMS:
//			{
//				char szCommand[MAX_BANGCOMMAND + MAX_BANGARGS + 5];
//				char szBangArgs[MAX_BANGARGS];
//				GetDlgItemText(hAboutBox, IDC_BANGPARAMS, szBangArgs, MAX_BANGARGS);
//				sprintf(szCommand, "%s %s\0", szBangCommand, szBangArgs);
//				CopyToClipboard(szCommand);
//				break;
//			}
//			case IDM_EXECUTEBANG:
//				LSExecuteEx(hAboutBox, NULL, szBangCommand, NULL, NULL, 0);
//				break;
//			case IDM_EXECUTEBANGPARAMS:
//			{
//				char szBangArgs[MAX_BANGARGS];
//				GetDlgItemText(hAboutBox, IDC_BANGPARAMS, szBangArgs, MAX_BANGARGS);
//				LSExecuteEx(hAboutBox, NULL, szBangCommand, szBangArgs, NULL, 0);
//			}
//			}
//		}
//	}
//	
//}

// Double-click handler for RC file list
//
//void OnDoubleClickRCFiles(int iItem)
//{
//	char szFile[MAX_PATH];
//	memset(szFile, 0, sizeof(szFile)); // initialize everything to null for safety.
//	
//	ListView_GetItemText(hListView, iItem, 1, szFile, MAX_PATH);
//	
//	ShellExecute(hAboutBox, NULL, szFile, NULL, NULL, SW_SHOWNORMAL);	
//}

// Right-click handler for module list
//
//void OnRightClickModules(int iItem)
//{
//	POINT cursorPos;
//	GetCursorPos(&cursorPos);
//	
//	HMENU hMenu = CreatePopupMenu();
//	
//	// "Copy module path"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_COPYMODULEPATH, IDS_LITESTEP_COPYMODULEPATH, "&Copy path to clipboard");
//	
//	// "Unload Module"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_UNLOADMODULE, IDS_LITESTEP_UNLOADMODULE, "&Unload module");
//	
//	// "Reload Module"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_RELOADMODULE, IDS_LITESTEP_RELOADMODULE, "&Reload module");
//	
//	// not really a boolean value...oh well, its M$
//	BOOL menuItem = TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RETURNCMD, cursorPos.x, cursorPos.y, 0, hAboutBox, 0);
//	
//	if ( menuItem )
//	{
//		ScreenToClient(hListView, &cursorPos);
//		LVHITTESTINFO hitInfo;
//		hitInfo.pt = cursorPos;
//		int i = ListView_HitTest(hListView, &hitInfo);
//		if ( i == iItem )
//		{
//			char szModulePath[MAX_PATH];
//			ListView_GetItemText(hListView, iItem, 0, szModulePath, MAX_PATH);
//			
//			switch (menuItem)
//			{
//			case IDM_COPYMODULEPATH:
//				CopyToClipboard(szModulePath);
//				break;
//			case IDM_UNLOADMODULE:
//				{
//					LSExecuteEx(hAboutBox, NULL, "!UnloadModule", szModulePath, NULL, 0);
//					
//					// remove the module from the list
//					SendMessage(hListView, LVM_DELETEITEM, (WPARAM) iItem, 0);
//				}
//				break;
//			case IDM_RELOADMODULE:
//				{
//					LSExecuteEx(hAboutBox, NULL, "!ReloadModule", szModulePath, NULL, 0);
//					SendMessage(hAboutBox, WM_COMMAND, MAKEWPARAM(IDC_COMBOBOX, CBN_SELCHANGE), 0);
//				}
//				break;
//			}
//		}
//	}
//	DestroyMenu(hMenu);
//}

// Right-click handler for LS Help
//
//void OnRightClickHelp(int iItem)
//{
//	POINT cursorPos;
//	GetCursorPos(&cursorPos);
//	
//	HMENU hMenu = CreatePopupMenu();
//	
//	// "Copy code"
//	RESOURCE_STR_APPENDMENU(hAboutBox, hMenu, IDM_COPYCODE, IDS_LITESTEP_COPYCODE, "&Copy code to clipboard");
//	
//	// not really a boolean value...oh well, its M$
//	BOOL menuItem = TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_RETURNCMD, cursorPos.x, cursorPos.y, 0, hAboutBox, 0);
//	
//	if ( menuItem )
//	{
//		ScreenToClient(hListView, &cursorPos);
//		LVHITTESTINFO hitInfo;
//		hitInfo.pt = cursorPos;
//		int i = ListView_HitTest(hListView, &hitInfo);
//		if ( i == iItem )
//		{
//			char szModulePath[MAX_PATH];
//			ListView_GetItemText(hListView, iItem, 0, szModulePath, MAX_PATH);
//			
//			switch (menuItem)
//			{
//			case IDM_COPYCODE:
//				OnDoubleClickHelp(iItem);				
//				break;
//			}
//		}
//	}
//	DestroyMenu(hMenu);
//}



//void OnDoubleClickHelp(int iItem)
//{
//	char szCodeSnip[MAX_PATH];
//	ListView_GetItemText(hListView, iItem, 0, szCodeSnip, MAX_PATH);
//	CopyToClipboard(szCodeSnip);
//}


//
// AboutBox Thread Procedure
//

ULONG WINAPI AboutBoxThread( LPVOID lpParam )
{
	if (!bBoxOpen)
		DialogBox(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_ABOUTBOX),
			NULL, (DLGPROC) AboutBoxProcedure);
	else
		SwitchToThisWindow(hAboutBox, TRUE);

	return 0;
}


//
// Items' Procedures
//

// Fill listview with bang command information
//

//void AboutBangs()
//{
//	LVCOLUMN columnInfo;
//
//	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	columnInfo.fmt = LVCFMT_LEFT;
//	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
//	columnInfo.pszText = "Bang Command";
//	columnInfo.iSubItem = 0;
//
//	ListView_InsertColumn( hListView, 0, &columnInfo );
//
//	// get bang command names from bang manager
//	ILitestep *litestep;
//	IBangManager *bangMgr;
//
//	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
//	litestep->GetBangManager( &bangMgr );
//
//	if ( !bangMgr )
//		return ;
//
//	long count = bangMgr->GetBangCommandCount(), total = 0;
//	BSTR *array = new BSTR[count];
//	if ( !array )
//		return ;
//
//	total = bangMgr->GetBangCommandNames(count, array);
//
//	if ( !total )
//		return ;
//
//	for ( int i = 0; i < count; i++ )
//	{
//		LVITEM itemInfo;
//		char buffer[64];
//
//		WideCharToMultiByte( CP_ACP,
//		                     0,
//		                     array[i],
//		                     -1,
//		                     buffer,
//		                     64,
//		                     NULL,
//		                     NULL );
//
//		SysFreeString(array[i]);
//
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = i;
//		itemInfo.pszText = buffer;
//		itemInfo.iSubItem = 0;
//
//		ListView_InsertItem( hListView, &itemInfo );
//	}
//
//	// free up array damnit, done right this time
//	delete [] array;
//}


// Fill listview with development team information
//

struct
{
	const char *nick;
	const char *realName;
}
theDevTeam[] =
    {
//        "Headius", "Charles Oliver Nutter",
//        "Message", "Bobby G. Vinyard",
//        "NeXTer", "Joachim Calvert",
        "Maduin", "Kevin Schaffer",
//        "murphy", "Torsten Stelling",
//        "grd", "Gustav Munkby",
//        "GeekMaster", "Lowell Heddings",
//        "c0mrade", "Kirill Arushanov",
//        "Noodge", "Dustin Williams",
        "Chaku", "Chao-Kuo Lin",
		"Vendicator", "Christoffer Sj�berg",
		"repugnant", "John Woltman",
		"Sci", "Erik Christiansson",
		"allelimo", "Alessandro Limonta",
		"ilmcuts", "Simon"

    };

const int theDevTeamCount = sizeof(theDevTeam) / sizeof(theDevTeam[0]);

void AboutDevTeam()
{
	LVCOLUMN columnInfo;
	int width = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = width * 7 / 24;
	columnInfo.pszText = "Nick";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	columnInfo.cx = width - columnInfo.cx;
	columnInfo.pszText = "Real Name";
	columnInfo.iSubItem = 1;

	ListView_InsertColumn( hListView, 1, &columnInfo );

	for ( int i = 0; i < theDevTeamCount; i++ )
	{
		LVITEM itemInfo;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = i;
		itemInfo.pszText = (char *) theDevTeam[i].nick;
		itemInfo.iSubItem = 0;

		ListView_InsertItem( hListView, &itemInfo );
		ListView_SetItemText( hListView, i, 1, (char *) theDevTeam[i].realName );
	}
}


// Fill listview with module information
//

//void AboutModules()
//{
//	LVCOLUMN columnInfo;
//
//	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	columnInfo.fmt = LVCFMT_LEFT;
//	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
//	columnInfo.pszText = "Module";
//	columnInfo.iSubItem = 0;
//
//	ListView_InsertColumn( hListView, 0, &columnInfo );
//
//	// get module names from module manager
//	ILitestep *litestep;
//	IModuleManager *moduleMgr;
//
//	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
//	litestep->GetModuleManager( &moduleMgr );
//
//	if ( !moduleMgr )
//		return ;
//
//	int count = 0;
//	moduleMgr->GetModuleCount( &count );
//
//	if ( count == 0 )
//		return ;
//
//	SAFEARRAY *array = SafeArrayCreateVector( VT_BSTR, 0, count );
//	moduleMgr->GetModuleList( array, &count );
//
//	BSTR *arrayData;
//	SafeArrayAccessData( array, (void **) &arrayData );
//
//	for ( int i = 0; i < count; i++ )
//	{
//		LVITEM itemInfo;
//		char buffer[MAX_PATH];
//
//		WideCharToMultiByte( CP_ACP,
//		                     0,
//		                     arrayData[i],
//		                     -1,
//		                     buffer,
//		                     MAX_PATH,
//		                     NULL,
//		                     NULL );
//
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = i;
//		itemInfo.pszText = buffer;
//		itemInfo.iSubItem = 0;
//
//		ListView_InsertItem( hListView, &itemInfo );
//	}
//
//	SafeArrayUnaccessData( array );
//	SafeArrayDestroy( array );
//}


// Fill listview with revision ID (LM_GETREVID) information
//

//void AboutRevIDs()
//{
//	LVCOLUMN columnInfo;
//	LVITEM itemInfo;
//	int i = 0;
//	char buffer[256];
//
//	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	columnInfo.fmt = LVCFMT_LEFT;
//	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
//	columnInfo.pszText = "Revision ID";
//	columnInfo.iSubItem = 0;
//
//	ListView_InsertColumn( hListView, 0, &columnInfo );
//
//	// special cases: litestep.exe and lsapi.dll
//	itemInfo.mask = LVIF_TEXT;
//	itemInfo.iItem = i++;
//	itemInfo.pszText = buffer;
//	itemInfo.iSubItem = 0;
//
//	strcpy( buffer, "litestep.exe: 0.24.6" );
//	ListView_InsertItem( hListView, &itemInfo );
//
//	itemInfo.iItem = i++;
//
//	strcpy( buffer, "lsapi.dll: " );
//	strcat( buffer, &rcsRevision[0] );
//	buffer[strlen( buffer ) - 1] = 0;
//
//	ListView_InsertItem( hListView, &itemInfo );
//
//	// ask message manager which windows handle LM_GETREVID
//	ILitestep *litestep;
//	IMessageManager *msgMgr;
//
//	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
//	litestep->GetMessageManager( &msgMgr );
//
//	if ( !msgMgr )
//		return ;
//
//	SAFEARRAY *array = NULL;
//	msgMgr->GetWindowsForMessage( LM_GETREVID, &array );
//
//	if ( !array )
//		return ;
//
//	long lbound, ubound;
//
//	SafeArrayGetLBound( array, 1, &lbound );
//	SafeArrayGetUBound( array, 1, &ubound );
//
//	int count = ubound - lbound + 1;
//
//	HWND *arrayData;
//	SafeArrayAccessData( array, (void **) &arrayData );
//
//	for ( int j = 0; j < count; j++ )
//	{
//		if ( !IsWindow( arrayData[j] ) )
//			continue;
//
//		buffer[0] = 0;
//		SendMessage( arrayData[j], LM_GETREVID, 0, (LPARAM) buffer );
//
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = i++;
//		itemInfo.pszText = buffer;
//		itemInfo.iSubItem = 0;
//
//		ListView_InsertItem( hListView, &itemInfo );
//	}
//
//	SafeArrayUnaccessData( array );
//	SafeArrayDestroy( array );
//}


// Fill listview with _tsystem information
//

void AboutSysInfo()
{
	LVCOLUMN columnInfo;
	LVITEM itemInfo;
	int i = 0;
	char buffer[64];

	int width = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = width / 2;
	columnInfo.pszText = "Name";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	columnInfo.cx = width / 2;
	columnInfo.pszText = "Value";
	columnInfo.iSubItem = 1;

	ListView_InsertColumn( hListView, 1, &columnInfo );

	// operating system and version
	itemInfo.mask = LVIF_TEXT;
	itemInfo.iItem = i;
	itemInfo.pszText = "Operating System";
	itemInfo.iSubItem = 0;

	ListView_InsertItem( hListView, &itemInfo );

	OSVERSIONINFO versionInfo;
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx( &versionInfo );

	if ( versionInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
	{
		if ( versionInfo.dwMinorVersion >= 90 )
			strcpy( buffer, "Windows ME" );
		else if ( versionInfo.dwMinorVersion >= 10 )
			strcpy( buffer, "Windows 98" );
		else
			strcpy( buffer, "Windows 95" );
	}
	else
	{
		if (( versionInfo.dwMajorVersion == 5 ) && ( versionInfo.dwMinorVersion >= 1 ))
			strcpy( buffer, "Windows XP" );
		else if ( versionInfo.dwMajorVersion == 5 )
			strcpy( buffer, "Windows 2000" );
		else
			sprintf( buffer, "Windows NT %d.%d", versionInfo.dwMajorVersion, versionInfo.dwMinorVersion );
	}

	TrimLeft(versionInfo.szCSDVersion);

	if (versionInfo.szCSDVersion[0])
	{
		lstrcat(buffer, " (");
		lstrcat(buffer, versionInfo.szCSDVersion);
		lstrcat(buffer, ")");
	}

	ListView_SetItemText( hListView, i++, 1, buffer );

	// memory information
	MEMORYSTATUS ms;
	ms.dwLength = sizeof(MEMORYSTATUS);
	GlobalMemoryStatus( &ms );

	itemInfo.iItem = i;
	itemInfo.pszText = "Memory Load";

	ListView_InsertItem( hListView, &itemInfo );

	sprintf( buffer, "%d%%", ms.dwMemoryLoad );
	ListView_SetItemText( hListView, i++, 1, buffer );

	itemInfo.iItem = i;
	itemInfo.pszText = "Physical Memory Total";

	ListView_InsertItem( hListView, &itemInfo );

	FormatBytes( ms.dwTotalPhys, buffer );
	ListView_SetItemText( hListView, i++, 1, buffer );

	itemInfo.iItem = i;
	itemInfo.pszText = "Physical Memory Available";

	ListView_InsertItem( hListView, &itemInfo );

	FormatBytes( ms.dwAvailPhys, buffer );
	ListView_SetItemText( hListView, i++, 1, buffer );

	itemInfo.iItem = i;
	itemInfo.pszText = "Swap Space Total";

	ListView_InsertItem( hListView, &itemInfo );

	FormatBytes( ms.dwTotalPageFile, buffer );
	ListView_SetItemText( hListView, i++, 1, buffer );

	itemInfo.iItem = i;
	itemInfo.pszText = "Swap Space Available";

	ListView_InsertItem( hListView, &itemInfo );

	FormatBytes( ms.dwAvailPageFile, buffer );
	ListView_SetItemText( hListView, i++, 1, buffer );

}

/*void AboutChanges()
{
	LVCOLUMN columnInfo;

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
	columnInfo.pszText = "Changes";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	char szChangesTxtPath[MAX_PATH];

	LSGetLitestepPath(szChangesTxtPath, MAX_PATH-13);

	//strncpy(szChangesTxtPath, szAppPath, MAX_PATH-13);
	strcat(szChangesTxtPath, "\\changes.txt");

	FILE *f;

	f = fopen (szChangesTxtPath, "r");

	if (f)
	{
		fseek (f, 0, SEEK_SET);
	}

    else
	{
	  char text[MAX_LINE_LENGTH];
	  wsprintf(text, "Changes.txt unavailable");
	  LVITEM itemInfo;
	  itemInfo.mask = LVIF_TEXT;
	  itemInfo.iItem = 0;
	  itemInfo.pszText = text;
	  itemInfo.iSubItem = 0;
	  ListView_InsertItem( hListView, &itemInfo);
	  wsprintf(text,"Expected location: %s", szChangesTxtPath);
	  itemInfo.iItem = 1;
	  itemInfo.pszText = text;
	  ListView_InsertItem( hListView, &itemInfo);
	  return;
	}
	char szTempBuffer[MAX_LINE_LENGTH];
	int i = 0;
	int j = 0;
	int width = columnInfo.cx;

	while (f && !feof (f))
	{

		if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
			break;

		int tempWidth = ListView_GetStringWidth( hListView, szTempBuffer );
		if (tempWidth > width)
		{
			width = tempWidth;
			ListView_SetColumnWidth( hListView, 0, width);
		}

		LVITEM itemInfo;

		j = 0;
		while (szTempBuffer[j] != 0)
			j++;
		szTempBuffer[j - 1] = 0;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = i++;
		itemInfo.pszText = szTempBuffer;
		itemInfo.iSubItem = 0;

		ListView_InsertItem( hListView, &itemInfo );
	}

	fclose(f);
}*/

//void AboutTextfile()
//{
//	int nSection = GetWindowLong(hAboutBox, GWL_USERDATA);
//
//	char szFile[MAX_PATH] = "";
//	char szTitle[32] = "";
//	char szMissing[1024] = "";
//
//	switch(nSection)
//	{
//	case ABOUT_CHANGES:
//		LSGetLitestepPath(szFile, MAX_PATH-12);
//		strcat(szFile, "changes.txt");
//		strcpy(szTitle, "Changes");
//		strcpy(szMissing, "Changes.txt unavailable");
//		break;
//	case ABOUT_LOGFILE:
//		{
//			extern char szLogFile[MAX_PATH];
//			strcpy(szFile, szLogFile);
//		}
//		strcpy(szTitle, "Log");
//		strcpy(szMissing, "No logfile specified");
//		break;
//	case ABOUT_HELP:
//		LSGetLitestepPath(szFile, MAX_PATH-9);
//		strcat(szFile, "help.txt");
//		strcpy(szTitle, "Help");
//		strcpy(szMissing, "Help.txt unavailable");
//		break;
//	}
//
//	LVCOLUMN columnInfo;
//
//	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	columnInfo.fmt = LVCFMT_LEFT;
//	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
//	columnInfo.pszText = szTitle;
//	columnInfo.iSubItem = 0;
//
//	ListView_InsertColumn( hListView, 0, &columnInfo );
//
//	FILE *f;
//
//	f = fopen(szFile, "r");
//
//	if(f) {
//		fseek(f, 0, SEEK_SET);
//	}
//    else {
//		char text[MAX_LINE_LENGTH];
//		//wsprintf(text, "Changes.txt unavailable");
//		LVITEM itemInfo;
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = 0;
//		//itemInfo.pszText = text;
//		itemInfo.iSubItem = 0;
//		//ListView_InsertItem(hListView, &itemInfo);
//		wsprintf(text, "Expected location: %s", szFile);
//		//itemInfo.iItem = 1;
//		itemInfo.pszText = text;
//		ListView_InsertItem(hListView, &itemInfo);
//		return;
//	}
//	char szTempBuffer[MAX_LINE_LENGTH];
//	int i = 0;
//	int j = 0;
//	int width = columnInfo.cx;
//
//	while(f && !feof (f))
//	{
//
//		if(!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
//			break;
//
//		int tempWidth = ListView_GetStringWidth(hListView, szTempBuffer);
//		if(tempWidth > width)
//		{
//			width = tempWidth;
//			ListView_SetColumnWidth(hListView, 0, width);
//		}
//
//		LVITEM itemInfo;
//
//		j = 0;
//		while (szTempBuffer[j] != 0)
//			j++;
//		szTempBuffer[j - 1] = 0;
//
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = i++;
//		itemInfo.pszText = szTempBuffer;
//		itemInfo.iSubItem = 0;
//
//		ListView_InsertItem(hListView, &itemInfo);
//	}
//
//	fclose(f);
//}

/*void AboutHelp()
{
	LVCOLUMN columnInfo;

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
	columnInfo.pszText = "LS Help";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	char szHelpTxtPath[MAX_PATH];

	LSGetLitestepPath(szHelpTxtPath, MAX_PATH-11);
	//strncpy(szLsHelpTxtPath, szAppPath, MAX_PATH-11);
	strcat(szHelpTxtPath, "\\help.txt");

	FILE *f;

	f = fopen(szHelpTxtPath, "r");

	if (f) {
		fseek (f, 0, SEEK_SET);
	}

	else
	{
		char text[MAX_LINE_LENGTH];
		wsprintf(text, "help.txt unavailable");
		LVITEM itemInfo;
		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = 0;
		itemInfo.pszText = text;
		itemInfo.iSubItem = 0;
		ListView_InsertItem( hListView, &itemInfo);
		wsprintf(text,"Expected location: %s", szHelpTxtPath);
		itemInfo.iItem = 1;
		itemInfo.pszText = text;
		ListView_InsertItem(hListView, &itemInfo);
		return;
	}

	char szTempBuffer[MAX_LINE_LENGTH];
	int i = 0;
	int j = 0;
	int width = columnInfo.cx;

	while (f && !feof (f))
	{

    if (!fgets(szTempBuffer, MAX_LINE_LENGTH, f))
		break;

    int tempWidth = ListView_GetStringWidth(hListView, szTempBuffer);
    if (tempWidth > width)
    {
		width = tempWidth;
		ListView_SetColumnWidth(hListView, 0, width);
    }

		LVITEM itemInfo;

		j=0;
		while (szTempBuffer[j]!=0) j++;
		szTempBuffer[j-1]=0;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = i++;
		itemInfo.pszText = szTempBuffer;
		itemInfo.iSubItem = 0;
		
		ListView_InsertItem(hListView, &itemInfo);    
	}

	fclose(f);
}*/

//void AboutRCFiles()
//{
//	LVCOLUMN columnInfo;
//	int width = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
//
//	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	columnInfo.fmt = LVCFMT_LEFT;
//	columnInfo.cx = width * 7 / 24;
//	columnInfo.pszText = "File";
//	columnInfo.iSubItem = 0;
//
//	ListView_InsertColumn( hListView, 0, &columnInfo );
//
//	columnInfo.cx = width - columnInfo.cx;
//	columnInfo.pszText = "Full Path";
//	columnInfo.iSubItem = 1;
//
//	ListView_InsertColumn( hListView, 1, &columnInfo );
//
//	// this is NOT the ideal solution, it would be better to obtain a list
//	// of all included files from stepsets
//
//	FILE *f;
//	f = LCOpen(NULL);
//	if(f)
//	{
//		LVITEM itemInfo;
//
//		char* tmp;
//		char* shortname;
//		char szRCPath[MAX_PATH];
//
//		char buffer[MAX_LINE_LENGTH];
//
//		// step.rc itself...
//		LSGetLitestepPath(szRCPath, MAX_PATH-8);
//		strcat(szRCPath, "step.rc");
//
//		//strncpy(buffer,szRcPath,MAX_LINE_LENGTH);
//		/*tmp = strtok(szRCPath, "\\");
//		do {
//			shortname = tmp;
//			tmp = strtok(NULL, "\\");
//		} while (tmp);
//		*/
//
//		itemInfo.mask = LVIF_TEXT;
//		itemInfo.iItem = 0;
//		itemInfo.pszText = "step.rc";
//		itemInfo.iSubItem = 0;
//		ListView_InsertItem( hListView, &itemInfo );
//		ListView_SetItemText( hListView, 0, 1, (char *) szRCPath );
//
//		// and all included files
//
//		char* tokens[2];
//		char name[MAX_LINE_LENGTH];
//		char fullpath[MAX_LINE_LENGTH];
//
//		int i = 1;
//
//		tokens[0] = name;
//		tokens[1] = fullpath;
//		name[0] = fullpath[0] = 0;
//		while(LCReadNextConfig(f, "include", buffer, sizeof(buffer)))
//		{
//			LCTokenize(buffer, tokens, 2, NULL);
//
//			char* tmp;
//			char* shortname;
//	
//			strcpy(buffer,fullpath);
//			tmp = strtok(buffer, "\\");
//			do {
//				shortname = tmp;
//				tmp = strtok(NULL, "\\");
//			} while (tmp);
//
//			itemInfo.mask = LVIF_TEXT;
//			itemInfo.iItem = i;
//			itemInfo.pszText = (char *) shortname;
//			itemInfo.iSubItem = 0;
//			ListView_InsertItem( hListView, &itemInfo );
//			ListView_SetItemText( hListView, i++, 1, (char *) fullpath );
//		}
//		LCClose(f);
//	} else {	// step.rc invalid...
//	  LVITEM itemInfo;
//	  itemInfo.mask = LVIF_TEXT;
//	  itemInfo.iItem = 0;
//	  itemInfo.pszText = "step.rc not found";
//	  itemInfo.iSubItem = 0;
//	  ListView_InsertItem( hListView, &itemInfo);
//  }
//}


//theme switcher
//
/*void AboutThemeSw()
{
	LVCOLUMN columnInfo;

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
	columnInfo.pszText = "Theme Switcher";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

  char szThemeSwitchPath[MAX_PATH];
  
  LSGetLitestepPath(szThemeSwitchPath, MAX_PATH);
  strcat(szThemeSwitchPath, "ThemeSwitch.txt");

  FILE *f;

  f = fopen (szThemeSwitchPath, "r");

  if (f)
  {
    fseek (f, 0, SEEK_SET);
  }

  else
  {
	  char text[MAX_LINE_LENGTH];
	  wsprintf(text, "ThemeSwitch.txt unavailable");
	  LVITEM itemInfo;
	  itemInfo.mask = LVIF_TEXT;
	  itemInfo.iItem = 0;
	  itemInfo.pszText = text;
	  itemInfo.iSubItem = 0;
	  ListView_InsertItem( hListView, &itemInfo);
	  wsprintf(text,"Expected location: %s", szThemeSwitchPath);
	  itemInfo.iItem = 1;
	  itemInfo.pszText = text;
	  ListView_InsertItem( hListView, &itemInfo);
	  return;
  }

  char szTempBuffer[MAX_LINE_LENGTH];
  int i = 0;
  int j = 0;
  int width = columnInfo.cx;

  while (f && !feof (f))
  {

    if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
      break;

    int tempWidth = ListView_GetStringWidth( hListView, szTempBuffer );
    if (tempWidth > width)
    {
      width = tempWidth;
      ListView_SetColumnWidth( hListView, 0, width);
    }

		LVITEM itemInfo;

		j=0;
		while (szTempBuffer[j]!=0) j++;
		szTempBuffer[j-1]=0;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = i++;
		itemInfo.pszText = szTempBuffer;
		itemInfo.iSubItem = 0;
		
		ListView_InsertItem( hListView, &itemInfo );    
  }

  fclose(f);
}*/

//LsLogFile
//
/*void AboutLogFile()
{
	LVCOLUMN columnInfo;

	columnInfo.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
	columnInfo.fmt = LVCFMT_LEFT;
	columnInfo.cx = GetClientWidth( hListView ) - GetSystemMetrics( SM_CXVSCROLL );
	columnInfo.pszText = "Log File";
	columnInfo.iSubItem = 0;

	ListView_InsertColumn( hListView, 0, &columnInfo );

	extern char szLogFile[MAX_PATH];

	if (szLogFile[0]) {

		FILE *f;

		f = fopen (szLogFile, "r");

		if (f)
		{

			fseek (f, 0, SEEK_SET);

		} else {
			
			char text[MAX_LINE_LENGTH];

			LVITEM itemInfo;

			itemInfo.mask = LVIF_TEXT;
			itemInfo.iItem = 0;
			itemInfo.pszText = "Logfile not found";
			itemInfo.iSubItem = 0;
			ListView_InsertItem( hListView, &itemInfo);

			wsprintf(text,"Expected location: %s", szLogFile);
			itemInfo.iItem = 1;
			itemInfo.pszText = text;
			ListView_InsertItem( hListView, &itemInfo);

			return;
		}
  
		char szTempBuffer[MAX_LINE_LENGTH];
		int i = 0;
		int j = 0;
		int width = columnInfo.cx;

		while (f && !feof (f))
		{
			if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
				break;

			int tempWidth = ListView_GetStringWidth( hListView, szTempBuffer );
			if (tempWidth > width)
			{
				width = tempWidth;
				ListView_SetColumnWidth( hListView, 0, width);
			}

			LVITEM itemInfo;

			j=0;
			while (szTempBuffer[j]!=0) j++;
			szTempBuffer[j-1]=0;

			itemInfo.mask = LVIF_TEXT;
			itemInfo.iItem = i++;
			itemInfo.pszText = szTempBuffer;
			itemInfo.iSubItem = 0;
		
			ListView_InsertItem( hListView, &itemInfo );
		}
		fclose(f);
	} else {
		
		char text[MAX_LINE_LENGTH];

		LVITEM itemInfo;

		itemInfo.mask = LVIF_TEXT;
		itemInfo.iItem = 0;
		itemInfo.pszText = "No logfile specified";
		itemInfo.iSubItem = 0;
		ListView_InsertItem( hListView, &itemInfo);

		return;
	}
}*/


//
// Utility Functions
//


// Simplified version of CreateFont
//

HFONT CreateSimpleFont(LPCSTR faceName, int sizeInPoints, BOOL bold, BOOL italic)
{
	// convert size from points to pixels
	HDC hDC = GetDC(NULL);
	int sizeInPixels = -MulDiv(sizeInPoints, GetDeviceCaps(hDC, LOGPIXELSY), 72);
	ReleaseDC(NULL, hDC);

	// fill in LOGFONT structure
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));

	lf.lfHeight = sizeInPixels;
	lf.lfWeight = bold ? FW_BOLD : FW_NORMAL;
	lf.lfItalic = italic;
	strncpy(lf.lfFaceName, faceName, LF_FACESIZE);

	// create it
	return CreateFontIndirect(&lf);
}


// Return the width of the window's client area
//

int GetClientWidth(HWND hWnd)
{
	RECT r;
	GetClientRect(hWnd, &r);

	return r.right - r.left;
}


// Trims whitespace from the beginning of a string in-place
//

void TrimLeft(char *toTrim)
{
	char *trimmed = toTrim;

	// skip past spaces
	while(*toTrim && isspace(*toTrim))
		toTrim++;

	// copy the rest of the string over
	while(*toTrim)
		*trimmed++ = *toTrim++;

	// null-terminate it
	*trimmed = 0;
}


// Formats a byte count into a string suitable for display to the user
//

LPCSTR units[] = {
	"bytes", "KB", "MB", "GB", "TB"
};

void FormatBytes(DWORD bytes, LPSTR buffer)
{
	double value = (double) bytes;
	int unit = 0;

	while (value >= 1024)
	{
		value /= 1024;
		unit++;
	}

	wsprintf(buffer, "%d %s", (int) floor(value + 0.5), units[unit]);
}

// Copies text to clipboard
//

//void CopyToClipboard(const char pszText[])
//{
//	if(OpenClipboard(hAboutBox))
//	{
//		
//		EmptyClipboard();
//		
//		HGLOBAL hGlobal = GlobalAlloc( GMEM_MOVEABLE|GMEM_ZEROINIT, strlen(pszText)+1 );
//		
//		if ( hGlobal != NULL )
//		{
//			TCHAR * lock = (LPTSTR) GlobalLock(hGlobal);
//			memcpy( lock, pszText, strlen(pszText)+1 );
//			GlobalUnlock(hGlobal);
//			SetClipboardData(CF_TEXT, hGlobal);
//		}
//		CloseClipboard();
//	}
//}
