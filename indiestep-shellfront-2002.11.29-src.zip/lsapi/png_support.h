#pragma once

#pragma include_alias("zlib.h", "zlib\zlib.h")
#pragma comment(linker, "/NODEFAULTLIB:libc.lib")
#pragma comment(lib, "libpng/lib/libpng.lib")
#pragma comment(lib, "zlib/lib/libz.lib")

// #pragma comment(lib, "libpng.lib")
// #pragma comment(lib, "zlib.lib")

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef STRICT
#define STRICT
#endif
#ifndef NOCRYPT
#define NOCRYPT
#endif

#include <windows.h>
#include "libpng\png.h"
// #include <png.h>

typedef struct _PNGERROR
{
	HWND Wnd;
	jmp_buf ErrorJump;
}
PNGERROR, *PPNGERROR;

void PNGErrorHandler(png_structp PngStruct, png_const_charp Message);
HBITMAP LoadFromPNG(LPCSTR pszFilename);
