/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
14/11/02 - Christoffer Sj�berg (Vendicator)
  - Made a simple LogManager which uses the old syntax to distribute message,
    interface: AddLogListener(), RemoveLogListener() which assigns functions
    to be notified when a log message is broadcast
    Old SetLsLogFile() adds the filewriter function into the LogManager

05/16/02 - John Woltman (repugnant)
  - Added ability to execute a command when the log gets above a certain
    size (LSLogMaxSize and LSLogOnMaxSize)
****************************************************************************/
#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include "lsapi.h"
#include "log.h"

// Maximum length of log message
#define MAX_LOG_MESSAGE_LEN 2048

// Log file
TCHAR szLogFile[MAX_PATH] = { 0 };
int nLogLevel = LOG_WARNING;
unsigned int g_nMaxSize = 0;
TCHAR g_szOnMaxSize[MAX_BANGCOMMAND + MAX_BANGARGS + 1];

// setup logmanager
LogManager *logman = new LogManager;

// ----------------------------------------------------------------------------
//  LSLog
// ----------------------------------------------------------------------------
//  Adds a message to the log file
// ----------------------------------------------------------------------------

BOOL WINAPI
LSLog(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	// stub
	//return LSLogFile(nLevel, pszModule, pszMessage);

	// send to LogMessage here
	return logman->LogMessage(nLevel, pszModule, pszMessage);
}

// add this with AddLogListener
BOOL //WINAPI
 LSLogFile(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	// Has a log file been assigned?
	if(!szLogFile[0])
		return FALSE;

	// Should this message be logged?
	if(nLevel > nLogLevel)
		return FALSE;

	if ( g_nMaxSize )
	{
		WIN32_FIND_DATA wfd;
		// if we find the file at all
		if ( (FindFirstFile(szLogFile, &wfd) != INVALID_HANDLE_VALUE) && (wfd.nFileSizeLow/1024) >  g_nMaxSize) {
			//LSLogPrintf(LOG_DEBUG, "logger", "size: %d kb", wfd.nFileSizeLow/1024);
			LSExecute(GetLitestepWnd(), g_szOnMaxSize, 0);
		}
	}
		

	// If so, open it
	HANDLE hLogFile = CreateFile(szLogFile, 
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	// Did open succeed?
	if(hLogFile == INVALID_HANDLE_VALUE)
		return FALSE;

	// Move to the end of the file
	SetFilePointer(hLogFile, 0, NULL, FILE_END);

	// Get timestamp
	SYSTEMTIME st;
	GetLocalTime(&st);

	// Add timestamp and module name to message
	TCHAR szLine[MAX_LOG_MESSAGE_LEN];
	int nLen;

	nLen = wsprintf(szLine, "%02d-%02d-%04d %02d:%02d:%02d - %s: %s\r\n",
		st.wMonth, st.wDay, st.wYear, st.wHour, st.wMinute, st.wSecond,
		pszModule, pszMessage);

	// Write it to the log file
	DWORD dwCount;
	WriteFile(hLogFile, szLine, nLen, &dwCount, NULL);

	// Close the log
	CloseHandle(hLogFile);

	return TRUE;
}

// ----------------------------------------------------------------------------
//  LSLogPrintf
// ----------------------------------------------------------------------------
//  Adds a printf-style formatted message to the log file
// ----------------------------------------------------------------------------

BOOL WINAPIV
LSLogPrintf(int nLevel, LPCSTR pszModule, LPCSTR pszFormat, ...)
{
	// Don't waste the effort if this won't get logged
	if(!szLogFile[0] || nLevel > nLogLevel)
		return FALSE;

	// Format the message
	CHAR szMessage[MAX_LOG_MESSAGE_LEN];
	va_list argList;

	va_start(argList, pszFormat);
	wvsprintf(szMessage, pszFormat, argList);
	va_end(argList);

	// Call LSLog to the real work
	return LSLog(nLevel, pszModule, szMessage);
}

// ----------------------------------------------------------------------------
//  SetLSLogFile
// ----------------------------------------------------------------------------
//  Sets the path to the log file
// ----------------------------------------------------------------------------

BOOL WINAPI
SetLSLogFile(LPCSTR pszLogFile)
{
	szLogFile[0] = 0;

	if(pszLogFile)
		lstrcpyn(szLogFile, pszLogFile, MAX_PATH);

	// add the old file logger here since a file has been specified
	AddLogListener(LSLogFile);

	return TRUE;
}

// ----------------------------------------------------------------------------
//  SetLSLogLevel
// ----------------------------------------------------------------------------
//  Sets the maximum logging level
// ----------------------------------------------------------------------------

BOOL WINAPI
SetLSLogLevel(int nMaxLevel)
{
	nLogLevel = max(nMaxLevel, LOG_ERROR);
	return TRUE;
}

// ----------------------------------------------------------------------------
//  SetLSLogMaxSizeAndBang
// ----------------------------------------------------------------------------
//  Sets the maximum size of the log (in KB) and the command to execute when
//  it exceeds the max size.
// ----------------------------------------------------------------------------
BOOL WINAPI
SetLSLogMaxSizeAndBang(int nMaxSize, LPCSTR pszBang)
{
	if ( nMaxSize) {
		g_nMaxSize = nMaxSize;
		strncpy(g_szOnMaxSize, pszBang, sizeof(g_szOnMaxSize));
	}
	else {
		g_szOnMaxSize[0] = '\0';
	}
	return TRUE;
}

LSAPI BOOL WINAPI CleanUpLogListener()
{
	if (logman)
	{
		logman->CleanUpListeners();
		return TRUE;
	}
	return FALSE;
}

// add function
LSAPI BOOL WINAPI AddLogListener(LogFunction logF)
{
	if (logman)
	{
		logman->AddListener(logF);
		return TRUE;
	}
	return FALSE;
}

// add function
LSAPI BOOL WINAPI RemoveLogListener(LogFunction logF)
{
	if (logman)
	{
		logman->RemoveListener(logF);
		return TRUE;
	}
	return FALSE;
}

// LogManager
LogManager::LogManager() : listeners(NULL)
{
	// initialize vector
	//listeners = new list<LogFunction>;
}

LogManager::~LogManager()
{
	CleanUpListeners();
}

BOOL LogManager::AddListener(LogFunction logF)
{
	// insert into vector here
	listeners.push_back(logF);
	return TRUE;
}

// only for use with list?
BOOL LogManager::RemoveListener(LogFunction logF)
{
	listeners.remove(logF);
	return TRUE;
}

BOOL LogManager::CleanUpListeners()
{
	// remove all listeners
	listeners.clear();
    return TRUE;
}

BOOL LogManager::LogMessage(const int level, LPCSTR sender, LPCSTR message)
{
	LogFunction f;
	// iterate through Vector and send the info to the listeners
	list<LogFunction>::iterator it;
    for (it=listeners.begin(); it != listeners.end(); ++it)
	{
        f = *it;
		f(level, sender, message);
	}
	return TRUE;
}