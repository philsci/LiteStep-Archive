/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************

- Next features (to do list):
  - Check for getrc(), lslogprintf(), setvar()
  - Trillian displays wrong tooltip, internally correct tho
  - Jesus tooltip fix sets systray2 also to ontop, removed, how to get it back?
  (-) Change paint icon to accept flash support
  - Check per pixel alpha support
  (-) Update check on icon / tooltip (definable?) for better update control
  - Scroll of icon without autosize, !systrayScrollIcons next, prev (back), auto
  - Use getrccoordinate in lsbox hook and use lsbox size for maxsize positioning

- Fixed [systray2 / Vendicator / 2002-11-14]
  - Found a gdi leak from not removing a test region when checking transp.

- Fixed [systray2 / Vendicator / 2002-09-15] 
  - Fixed autosizing always happening in !refresh

- Fixed [systray2 / Ilmcuts / 2002-09-08]
  - OnNumList2, ignoreTag, and flashTag weren't initialized to NULL in the constructor.

- Changed [systray2 / Vendicator / 2002-08-26]
  - Removed internal icons counter and using a function check instead for !bang commands
  - Exported the following evars:
  $SystrayCurrentIcons$, $SystrayCurrentX$, $SystrayCurrentY$, $SystrayCurrentHeight$, $SystrayCurrentWidth$

- Fixed [systray2 / Vendicator / 2002-08-17]
  - Fixed update check to only use the title and not icon change, will allow for
    hiding of zonealarm for instance
  - Jesus_mjjg's fix temporarily disabled until the reason why systray also sets
    it self above all windows is determined

- Fixed [systray2 / Vendicator / 2002-08-12]
  - Fixed a small mem leak (2bytes per flash config read)
  - Merged icon removal between hidden&shown icons
  - Tweaked more code to save some cycles here and there

- Fixed [systray2 / Jesus_mjjg / 2002-07-26]
  - Shouldn't tooltip windows be always on top of any other window ?
    now they are (but maybe i could make that cleaner)

- Added [systray2 / Vendicator / 2002-07-18]
  - Added setting "SystrayAlwaysFlashOnMatch", which continues to flash an icon even when
    icon is activated, this means that it will only stop when the match of the icon stops
	(ie icon removed, or tooltip doesn't match no more). If used with no tooltip and a
	flash limit, it the icon will only be able to flash once (since that is always matched).

- Fixed [systray2 / Vendicator / 2002-07-09]
  - Added an extra #define so that whichever strange os/msvc version can compile this again.

- Changed [systray2 / Vendicator / 2002-07-08]
  - Changed flash format to:
	*systrayflash "classname" "title (optional)" flashes/update
	to be able to specify max flashes, 0 to flash until you click the icon.
	This means that the icon won't flash anymore until you activate it (even if it's updated again).
  - Added setting "SystrayFlashInScreensaver", to specify if flashing should
    occur even when a screensaver is running, the flashing will most likely turn off the screensaver.

- Fixed [systray2 / Vendicator / 2002-07-02] 
  - Rewrote the adjustsize algorithm, previous seemed to fail sometimes when hiding icons
  - Moved more code around, most settings read through functions, makes editing startup behaviour easier (!refresh, !recycle, startup)
  - Fixed !refresh some more... sometime tray isn't visible in lsbox, when does this happen?
  - Fixed a bug in the move code
  - Added systrayAlign which accepts a string like "right bottom" to define from which corner
    systray should be placed, defined size might give strange results.

- Added [systray2 / Vendicator / 2002-07-01]
  - Added output of window classes to log file (lv3) on !systrayinfo for easier config of hiding/flashing
  - Added scroll flashing on icon update through code from taskbar3,
    needs window classname, optional tooltip text (case sensitive, check log file).
  - Added mouse enter / leave !bang running.
  - Restructured how checks flash&hide checks are made, saves some cycles.
  - Fixed *Wharfmodule from LSBox, thanks to someone who I lost the mail from for pointing it out.
  - Started implementation of !refresh... still a little flaky
  - Ilmcuts noticed that the previous hue code used BGR format, changed to RGB even though a warning
    from grd was present in the code, but it's checked and doesn't appear to have any problems.

- Fixed [systray2 / Vendicator / 2002-06-17]
  - On recycle the remove commands were removed before run, fixed.

- Fixed [systray2 / Sci / 2002-06-16]
  - Stole a one-liner from the geOShell tray service, the right click menu is
    now closed when it loses focus!

- Updated [systray2 / Vendicator / 2002-06-10]
  - Did some code cleanup & added some more logging with #ifdef
  - Fixed saturation misspelling =)

- Updated [systray2 / ilmcuts / 2002-06-09]
  - the minimum value for systrayIconSize is now 1 instead of 0
  - fixed warnings about signed/unsigned int conflicts
  - tweaked wharf/lsbox compatibility (hopefully positive)
  - misc tweaks (thanks to Maduin for the new ontop code)

- Fixed [systray2 / Vendicator / 2002-06-08]
  - Fixed wierd systray placement bug that affected some ppl.

- Added [systray2 / Vendicator 2002-06-06]
  - Added grdTrays icon effects, hue & saturation (grdtray never wanted to work on my comp)
    Settings:systrayIconHueIntensity systrayIconHueColor systrayIconSaturation.

- Fixed [systray2 / Vendicator / MickeM / 2002-05-31]
  - MickeM started fixing some memory leaks and I continued..
  - Icon was set to NULL on update before it tried to delete it... fixed

- Added [systray2 / Vendicator / 2002-05-30]
  - Checks systray size in timer when "SystrayTimerCleaning" is used.
  - Killed timer too
  - Added !SystrayIconInfo, mainly for debugging purposes.
  - Moved and grouped functions better in the source =)

- Fixed [systray2 / Vendicator / 2002-05-29]
  - Fixed b0rked lsbox support, thanks to Maestr0 for pointing it out.

- Added [systray2 / Vendicator / 2002-05-28]
  - Added cleaning of crashed programs on timer, use "SystrayTimerCleaning".
  - Fixed a routine which didn't handle hidden icons before.
  - Added log of deleted icons

- Fixed [systray2 / Sci / 2002-05-22]
  - Multiline tooltips now works (DUN icon)

- Added [systray2 / Vendicator / 2002-05-17]
  - Implemented icon hiding base on window class name.
    Format: *systrayhide Window_Class_Name min_inactive_before_hiding
  - Added SystrayIconTimer, which set how often to do the check for inactive icons
    defaults to every minute, setting 0 disables check.
  - Added !SystrayShowIcons to display any hidden icons.
  - Added some logging, watch out on loglevel 4 =)
  - Rewrote the systray2kad stuff to skip vector notation...
  - Todo: Testing

- Problem [systray2 / Vendicator / 2002-05-06]
  - Works in lsbox and on desktop, but I'm guessing not in a wharf...

- Fixed [systray2 / Vendicator / 2002-05-05]
  - Added compensation for lsbox position, needed when using autoresize in lsbox.
  - Entered the systray2kad hacks for command execution on add/del of icons.

- Fixed [systray2 / Vendicator / 2002-05-02]
  - Added lsbox support, seems to hide if the tray resizes, watch of with autoresize...

- Fixed [systray2 / Vendicator / 2002-04-15]
  - Now using GetRCCoordinates to get X,Y position

- Fixed [systray2 / Message / 2001-11-26]
  - Stripped everything out of it except for basic gui, this modulewill not run
    without a new build

- Fixed [systray2 / Message / 2001-11-21]
  - Added Windows2000 and WindowxXP support. Seems to work fine when first loaded,
    but after a recycle w2k loses its volume icon and xp loses all icons (?). A simple fix
    for w2k is to run trayfix.exe after a recycle, and that will put the volume icon back.
    
    NOTES:
    The DUN icon uses 4 icons to display status, when NIM_ADD the icons, they all have the
    same HWND, but differ in NOTIFYICONDATA.uID. To get around this, we only check to see
    if an icon already exists by HWND only, and not uID. On NIM_MODIFY, we set the uID
    of any found icon to the modifying icon's uID or problems occur with the mouse handling.
    
    UnloadShellServiceObjects needs to be called before LM_SAVESYSTRAY is handled or
    the DUN/Volume icons get saved also and won't be handled properly when the tray is
    restarted after a recycle.
    
    (The tooltip on the DUN icon still doesn't handle well. I think this is our implementation
    and not MS related.) - Fixed by Sci
****************************************************************************/
#include "systray.h"

// use old size adjustment routine:
//#define OLD_ADJUST

// extra debug info:
//#define DEBUG_EXTRA

// spamming debug info:
//#define DEBUG_SPAM

// defined directions
#define TD_VERTICAL		0x2
#define TD_TOTOPLEFT	0x4
// for alignment, default value:
#define TD_OFF			0x0

#define TD_RIGHT		0x1
#define TD_LEFT			(TD_TOTOPLEFT)
#define TD_UP			(TD_TOTOPLEFT|TD_VERTICAL)
#define TD_DOWN			(TD_VERTICAL)

enum // timers starting at 1
{
	TIMER_AUTOHIDE = 1,
	TIMER_SCROLL
};

enum // icons starting at 10
{
	ICONS_VISIBLE = 10,
	ICONS_NOTVISIBLE, // = scrolled + hidden
	ICONS_SCROLLED,
	ICONS_HIDDEN,
	ICONS_ALL,
	ICONS_FLASHING,
	ICONS_ROOMFOR
};

enum // matches starting at 20
{
	MATCH_NONE = -1,
	MATCH_HIDE = 20,
	MATCH_FLASH
};

enum // icon scrolling
{
	SCROLL_BACK = 30,
	SCROLL_NEXT,
	SCROLL_AUTO
};

enum // icon visibility status
{
	HIDDEN = 40,
	SHOWN,
	SCROLLED
};

// defined effects
#define FX_ICONHUE		0x1
#define FX_SATURATION	0x2
#define FX_ANY			(FX_ICONHUE|FX_SATURATION)

// name of shelldesktop class
#define WC_SHELLDESKTOP    "DesktopBackgroundClass"

// defines for strange windows version
#ifndef SPI_GETSCREENSAVERRUNNING
#define SPI_GETSCREENSAVERRUNNING 114
#endif

const char szAppName[] = "systray"; // Our window class, etc

const char rcsRevision[] = "1.84$"; // Our Version*/
const char rcsId[] = "systray.cpp,v 1.84$"; // The Full RCS ID.*/


systray *tray; // The module

//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;
	Window::init(dllInst);
	tray = new systray(GetLitestepWnd(), code, false);
	return code;
}
int initWharfModule(HWND parentWnd, HINSTANCE dllInst, void *wharfData)
{
	int code;
	Window::init(dllInst);
	tray = new systray(parentWnd, code, true);
	return code;
}
void quitModule(HINSTANCE dllInst)
{
	delete tray;
}
void quitWharfModule(HINSTANCE dllInst)
{
	delete tray;
}

/***************************/
/* !BANG COMMAND FUNCTIONS */
/***************************/

// cut & paste module hook..
void bangHook(HWND caller, LPCTSTR szArgs)
{
	tray->boxhook(szArgs);
}

void bangIconInfo( HWND sender, const char *args )
{
	tray->IconInfo();
}

void bangShow( HWND sender, const char *args )
{
	tray->show();
}
void bangHide( HWND sender, const char *args )
{
	tray->hide();
}
void bangToggle( HWND sender, const char *args )
{
	tray->toggle();
}
void bangOnTop( HWND sender, const char *args )
{
	tray->toggleOnTop();
}
void bangMove( HWND sender, const char *args )
{
	char szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	char *tokens[2] = {szX, szY};
	LCTokenize( args, tokens, 2, NULL );
	tray->move(atoi(szX), atoi(szY));
}
void bangSize( HWND sender, const char *args )
{
	char szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	char *tokens[2] = {szCX, szCY};
	LCTokenize( args, tokens, 2, NULL );
	tray->size(atoi(szCX), atoi(szCY));
}

void bangShowAllIcons( HWND sender, const char *args )
{
	tray->ShowAllIcons();
}

void bangDisableFlash( HWND sender, const char *args )
{
	tray->AcceptFlash(FALSE);
}

void bangEnableFlash( HWND sender, const char *args )
{
	tray->AcceptFlash(TRUE);
}

void bangScrollIcons( HWND sender, const char *args )
{
	if (strnicmp(args, "next", 4))
		tray->ScrollIcons(SCROLL_NEXT);
	else if (strnicmp(args, "back", 4) || strnicmp(args, "prev", 4))
		tray->ScrollIcons(SCROLL_BACK);
	else
		tray->ScrollIcons(SCROLL_AUTO);
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
systray::systray(HWND parentWnd, int& code, BOOL bInWharf):
		Window(szAppName),
		OnAddCommand(NULL),
		OnDelCommand(NULL),
		OnMouseEnterCommand(NULL),
		OnMouseLeaveCommand(NULL),
		hrgnBack(NULL),
		lsboxed(false),
		inWharf(bInWharf),
		scrollWas(GetKeyState(VK_SCROLL) != 0),
		CommandsRead(0),
		numFlash(0),
		numIgnore(0),
		PaintOffset(0),
		PaintNext(true),
		bHover(false),
		bScreenSaverRunning(FALSE),
		firstAlignDone(FALSE),
		OnNumList2(NULL),
		ignoreTag(NULL),
		flashTag(NULL),
		desktop(NULL),
		parentWindow(parentWnd)
{

	// reading settings for window creation
	// ======================================

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_WARNING, szAppName, "*Debug* Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#else
	LSLogPrintf(LOG_DEBUG, szAppName, "Version info: %s, %s, %s %s", rcsRevision, rcsId, __DATE__, __TIME__);
#endif

	// get ls window handle
	liteStep = GetLitestepWnd();
	if (!liteStep) {
		LSLog(LOG_ERROR, szAppName, "Could not find litestep window, aborting");
		code = 2;
		return;
	}

	desktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if (!desktop)
	{
#ifdef DEBUG_EXTRA
		LSLog(LOG_WARNING, szAppName, "Didn't find desktop window class, trying function");
#endif
		desktop = GetDesktopWindow();
	}
	if (!desktop)
		LSLog(LOG_ERROR, szAppName, "Could not find desktop window");

	// get the position and size of the _tmain window
	// using different method if it's docked in the wharf
	ReadSizeAndPos();
	
	// FIXME: this logging stuff might need an update
	LSLogPrintf(LOG_DEBUG, szAppName, "Creating Window, pos:%d,%d size:%d,%d, p:%d, l:%d, d:%d", trayX, trayY, trayWidth, trayHeight, parentWindow, liteStep, desktop);
	
	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, inWharf ? WS_CHILD : WS_POPUP,
	                trayX, trayY, trayWidth, trayHeight, inWharf ? parentWindow : desktop))
	{
		LSLog(LOG_ERROR, szAppName, "unable to create window");
		RESOURCE_MSGBOX(hInstance, IDS_SYSTRAY2_ERROR3, "Unable to create window.", szAppName)
		code = 1;
		return ;
	}
	else
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "window created, 0x%X", hWnd);
	}

	PostMessage(liteStep, LM_SYSTRAYREADY, NULL, NULL);
	LSLog(LOG_NOTICE, szAppName, "loaded successfully");

	OSVERSIONINFO OSVersionInfo;
	OSVersionInfo.dwOSVersionInfoSize = sizeof(OSVersionInfo);
	GetVersionEx(&OSVersionInfo);
	bWinNT5 = OSVersionInfo.dwMajorVersion >= 5 && OSVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT;

	code = 0;
}

systray::~systray()
{
	destroyWindow();
	// remove commands after window is destroyed and icons removed
	DeleteCommands();
	LSLog(LOG_NOTICE, szAppName, "shut down");
}

/***************************/
/**** MESSAGE HANDLING *****/
/***************************/

void systray::windowProc(Message& message)
{
#ifdef DEBUG_SPAM
	LSLogPrintf(LOG_DEBUG, szAppName, "Message: %d", message.uMsg) ;
#endif

	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onDestroy, WM_DESTROY)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onSysTray, LM_SYSTRAY)
	MESSAGE(onRefresh, LM_REFRESH)
	MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(onKeyMessage, WM_KEYDOWN)
	MESSAGE(onKeyMessage, WM_KEYUP)
	MESSAGE(onKeyMessage, WM_HOTKEY)
	MESSAGE(onMouse, WM_LBUTTONDOWN)
	MESSAGE(onMouse, WM_MBUTTONDOWN)
	MESSAGE(onMouse, WM_RBUTTONDOWN)
	MESSAGE(onMouse, WM_LBUTTONUP)
	MESSAGE(onMouse, WM_MBUTTONUP)
	MESSAGE(onMouse, WM_RBUTTONUP)
	MESSAGE(onMouse, WM_LBUTTONDBLCLK)
	MESSAGE(onMouse, WM_MBUTTONDBLCLK)
	MESSAGE(onMouse, WM_RBUTTONDBLCLK)
	MESSAGE(onMouse, WM_MOUSEMOVE)
	MESSAGE(onPaint, WM_PAINT)
	MESSAGE(onPaint, LM_REPAINT)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onTimer, WM_TIMER)
	END_MESSAGEPROC
}

void systray::onEndSession(Message& message)
{
	message.lResult = SendMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void systray::onKeyMessage(Message& message)
{
	// Forward these messages
	PostMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void systray::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(liteStep, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else if (message.wParam == SC_SCREENSAVE)
	{
		bScreenSaverRunning = TRUE;
		LSLog(LOG_DEBUG, szAppName, "screensaver start msg");	
	}
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void systray::onRefresh(Message& message)
{
	LSLog(LOG_DEBUG, szAppName, "refreshing...");

	// ondestroy

	if (HIDE_TIMER)
		KillTimer(hWnd, TIMER_AUTOHIDE); // kill timer
	if (SCROLL_TIMER)
		KillTimer(hWnd, TIMER_SCROLL); // kill timer

	HIDE_TIMER=min( max(GetRCInt("systrayIconTimer", 1), 0), 60); // how often we look for icons to hide.
	if (HIDE_TIMER)
		SetTimer(hWnd, TIMER_AUTOHIDE, HIDE_TIMER*60000, NULL); // set timer in minutes

	SCROLL_TIMER=min( max(GetRCInt("SystrayScrollFlashInterval", 500), 100), 2000); // how often we flash.
	if (SCROLL_TIMER)
		SetTimer(hWnd, TIMER_SCROLL, SCROLL_TIMER, NULL);

	// destroy the tooltip window
	if (tooltip)
		DestroyWindow( tooltip );
	// delete gdi objects...
	if (hbmSkin)
		DeleteObject( hbmSkin );
	if (hbmBack)
		DeleteObject( hbmBack );
	if (hrgnBack)
		DeleteObject( hrgnBack );

	// reading settings for window creation
	// ======================================

	// get the position and size of the main window
	// using different method if it's docked in the wharf
	ReadSizeAndPos();
	
	// FIXME: this logging stuff might need an update
	LSLogPrintf(LOG_DEBUG, szAppName, "Moving Window, pos:%d,%d", trayX, trayY);
	move(trayX, trayY);
		
	LSLogPrintf(LOG_DEBUG, szAppName, "Sizing Window, size:%d,%d", trayWidth, trayHeight);
	size(trayWidth, trayHeight);

	// oncreate
	ReadGUIProps();
	ReadSizeProps();

	DeleteCommands();
	ReadCommands();

	DeleteWindowLists();
	ReadWindowLists();

	// flash
	TrayFlash = GetRCBool("SystrayScrollFlash", TRUE);
	FlashInSS = GetRCBool("SystrayFlashInScreensaver", TRUE);

	ClearIconsOnTimer = GetRCBool("SystrayTimerCleaning", TRUE);
	AlwaysFlash = GetRCBool("SystrayAlwaysFlashOnMatch", TRUE);

	setFirstLast();
	createBackground();

	// set always on top
	if (onTop)
		setAlwaysOnTop(true);
	else
		setAlwaysOnTop(false);

	// show window
	ShowWindow( hWnd, (!visible || hideIfEmpty) ? SW_HIDE : SW_SHOWNOACTIVATE );
#ifdef DEBUG_EXTRA
	if (!visible || hideIfEmpty) LSLog(LOG_DEBUG, szAppName, "hiding tray");
#endif
	InvalidateRect( hWnd, NULL, TRUE );

	if (autoSize)
		adjustSize();

	int icons = NrIcons(ICONS_VISIBLE);
	int i = 0;
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "starting add bang execution, %d icons to go through", icons);
#endif
	for (i=1; i<=icons; i++) {
		if ( CommandsRead > 0 && i <= CommandsRead && OnNumExe ) { // OnNumList.size()
			LSLogPrintf(LOG_DEBUG, szAppName, "running nr: %d - %s", i+1, OnNumList2[i-1].command);
			LSExecute(liteStep, OnNumList2[i-1].command, NULL);
		}

        if ( OnDelCommand != NULL ) {
            LSLogPrintf(LOG_DEBUG, szAppName, "running OnDel command: %s", OnDelCommand);
            LSExecute(liteStep, OnDelCommand, NULL);
        }

        if ( OnAddCommand != NULL ) {
			LSLogPrintf(LOG_DEBUG, szAppName, "running OnAdd command: %s", OnAddCommand);
			LSExecute(liteStep, OnAddCommand, NULL);
		}
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "finished nr %d add bang execution", i);
#endif
		
	}

	//uLastID = 1;

	LSLog(LOG_DEBUG, szAppName, "done refresh");
}

void systray::onCreate(Message& message)
{
	LSLog(LOG_DEBUG, szAppName, "Reading Systray Config Lines");
	int tmpInteger = 0;
	int msgs[] = {LM_GETREVID, LM_SYSTRAY, LM_REFRESH, 0};

	// register messages
	SendMessage(liteStep, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// has to be done
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	// make sure it handle dblclicks... =)
	SetClassLong(hWnd, GCL_STYLE, CS_DBLCLKS | GetClassLong(hWnd, GCL_STYLE));

	ReadGUIProps();
	ReadSizeProps();

	DeleteCommands();
	ReadCommands();

	DeleteWindowLists();
	ReadWindowLists();

	// flash
	TrayFlash = GetRCBool("SystrayScrollFlash", TRUE);
	FlashInSS = GetRCBool("SystrayFlashInScreensaver", TRUE);
	timerScroll = max(100, GetRCInt("SystrayScrollFlashInterval", 500) );

	ClearIconsOnTimer = GetRCBool("SystrayTimerCleaning", TRUE);
	AlwaysFlash = GetRCBool("SystrayAlwaysFlashOnMatch", TRUE);

	HIDE_TIMER=min( max(GetRCInt("systrayIconTimer", 1), 0), 60); // how often we look for icons to hide.
	SCROLL_TIMER=min( max(GetRCInt("systrayScrollFlashInterval", 500), 100), 2000);

	LSLog(LOG_DEBUG, szAppName, "Done Reading Systray Config Lines");

	setFirstLast();
	createBackground();

	// NOT FOR WHARF
	if ( !inWharf )
	{
		LSLog(LOG_DEBUG, szAppName, "Registering Systray Bangs");
		AddBangCommand( "!systrayIconInfo", bangIconInfo );
		AddBangCommand( "!systrayhide", bangHide );
		AddBangCommand( "!systrayshow", bangShow );
		AddBangCommand( "!systraytoggle", bangToggle );
		AddBangCommand( "!systrayontop", bangOnTop );
		AddBangCommand( "!systraymove", bangMove );
		AddBangCommand( "!systraysize", bangSize );
		AddBangCommand( "!systrayShowIcons", bangShowAllIcons );
		AddBangCommand( "!systrayHook", bangHook );
		AddBangCommand( "!systrayDisableFlash", bangDisableFlash );
		AddBangCommand( "!systrayEnableFlash", bangEnableFlash );
		AddBangCommand( "!systrayScrollIcons", bangScrollIcons );
		LSLog(LOG_DEBUG, szAppName, "Done Systray Bangs");
	}
	LSLog(LOG_DEBUG, szAppName, "Setting Systray Window Props.");

	// set always on top
	if (onTop)
		setAlwaysOnTop(true);
	else setAlwaysOnTop(false);

	// show window
	ShowWindow( hWnd, (!visible || hideIfEmpty) ? SW_HIDE : SW_SHOWNOACTIVATE );
	InvalidateRect( hWnd, NULL, TRUE );

	// create a tooltip window
	tooltip = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP | WS_POPUP, 0, 0, 0, 0, hWnd, NULL, NULL, NULL);

	// allow multiline tooltip for DUN icon
	SendMessage( tooltip, TTM_SETMAXTIPWIDTH, 0, 300 );

	uLastID = 1;
	pFirst = NULL;
	pLast = NULL;

	if (HIDE_TIMER)
		SetTimer(hWnd, TIMER_AUTOHIDE, HIDE_TIMER*60000, NULL); // set timer in minutes
	if (SCROLL_TIMER)
		SetTimer(hWnd, TIMER_SCROLL, SCROLL_TIMER, NULL);
	hideFirst = NULL;
	hideLast = NULL;

	LSLog(LOG_DEBUG, szAppName, "Done Systray Window Props.");
}

void systray::onDestroy(Message& message)
{
	int i = 0;
	int msgs[] = {LM_GETREVID, LM_SYSTRAY, LM_REFRESH, 0};

	// NOT FOR WHARF
	if ( !inWharf )
	{
		LSLog(LOG_DEBUG, szAppName, "Removing Systray Bangs");
		RemoveBangCommand("!systrayIconInfo");
		RemoveBangCommand("!systrayHide");
		RemoveBangCommand("!systrayShow");
		RemoveBangCommand("!systrayToggle");
		RemoveBangCommand("!systrayOnTop");
		RemoveBangCommand("!systrayMove");
		RemoveBangCommand("!systraySize");
		RemoveBangCommand("!systrayShowIcons");
		RemoveBangCommand("!systrayHook");
		RemoveBangCommand("!systrayDisableFlash");
		RemoveBangCommand("!systrayEnableFlash");
		RemoveBangCommand("!systrayScrollIcons");
		LSLog(LOG_DEBUG, szAppName, "Done Systray Bangs");
	}

	SendMessage(liteStep, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// destroy the list of icons
	iconListDelAll();

	// delete various lists
	DeleteWindowLists();

	// kill timers
	if (HIDE_TIMER)
		KillTimer(hWnd, TIMER_AUTOHIDE);
	if (SCROLL_TIMER)
		KillTimer(hWnd, TIMER_SCROLL);

	// destroy the tooltip window
	if (tooltip)
		DestroyWindow( tooltip );
	// delete gdi objects...
	if (hbmSkin)
		DeleteObject( hbmSkin );
	if (hbmBack)
		DeleteObject( hbmBack );
	if (hrgnBack)
		DeleteObject( hrgnBack );

}

void systray::onGetRevId(Message& message)
{
	LPSTR buf = (LPSTR)(message.lParam);

	switch (message.wParam)
	{
		case 0:
		sprintf(buf, "systray2.dll: %s", &rcsRevision[0]);
		buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
		strcpy(buf, &rcsId[0]);
		buf[strlen(buf) - 1] = '\0';
		break;
		default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}

void systray::onSysTray(Message& message)
{
	switch ( message.wParam )
	{
		case NIM_ADD:
		{
			message.lResult = (BOOL)( iconAdd((PLSNOTIFYICONDATA)message.lParam ) != NULL);
			break;
		}
		case NIM_MODIFY:
		{
			message.lResult = (BOOL)( iconMod((PLSNOTIFYICONDATA)message.lParam ) != NULL);
			break;
		}
		case NIM_DELETE:
		{
			message.lResult = (BOOL)iconDel((PLSNOTIFYICONDATA)message.lParam);
			break;
		}
		default:
		{
			message.lResult = FALSE;
			break;
		}
	}
}

void systray::onMouse(Message& message)
{
	int x = message.lParamLo, y = message.lParamHi;
	RECT rc;
	POINT pt;
	GetCursorPos(&pt);
	GetWindowRect(hWnd, &rc);

	if(PtInRect(&rc, pt))
	{
		if(GetCapture() != hWnd)
			SetCapture(hWnd);
		if(!bHover) {
			bHover = TRUE;
			LSExecute(liteStep, OnMouseEnterCommand, NULL);
			LSLogPrintf(LOG_DEBUG, szAppName, "Mouse enter, exe: %s", OnMouseEnterCommand);
		}
	}
	else
	{
		bHover = FALSE;
		ReleaseCapture();
		LSExecute(liteStep, OnMouseLeaveCommand, NULL);
		LSLogPrintf(LOG_DEBUG, szAppName, "Mouse leave, exe: %s", OnMouseLeaveCommand);
	}

	if (!onMouseIcon(message))
	{
		if (message.uMsg == WM_LBUTTONDOWN)
		{
			if ( borderDrag && ( (x <= borderLeft) || (x >= trayWidth - borderRight) ||
			                     (y <= borderTop) || (y >= trayHeight - borderBottom) ) )
				SendMessage( hWnd, WM_SYSCOMMAND, SC_MOVE | 2, message.lParam );
		}
		else if (message.uMsg == WM_RBUTTONUP)
		{
			pt.x = x;
			pt.y = y;
			ClientToScreen(hWnd, &pt);
			PostMessage( liteStep, LM_POPUP, 0, MAKELPARAM(pt.x, pt.y) );
		}
	}
	message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

BOOL systray::onMouseIcon(Message& message)
{
	PSYSTRAYICON pSysTrayIcon;
	MSG msg;
	POINT pt;
	pt.x = message.lParamLo;
	pt.y = message.lParamHi;

	// get icon at point
	pSysTrayIcon = iconListFindPt(pt);

	//SetForegroundWindow(pSysTrayIcon->hWnd);

	msg.hwnd = hWnd;
	msg.message = message.uMsg;
	msg.wParam = message.wParam;
	msg.lParam = message.lParam;
	msg.time = GetTickCount();
	msg.pt = pt;
	SendMessage( tooltip, TTM_RELAYEVENT, 0, (LPARAM) &msg );

	// icon was activated, clear flash, makes exception?
	if (pSysTrayIcon != NULL && !AlwaysFlash)
	{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "Mouse pass over icon, clear flash");
#endif
		pSysTrayIcon->state.isFlashing = FALSE;
		pSysTrayIcon->state.FlashCount = 0;
	}

	// remove "unwanted" icons
	iconListCleanup();

	// post message to that icon
	if (pSysTrayIcon && pSysTrayIcon->uCallbackMessage)
	{
		if(message.uMsg == WM_RBUTTONDOWN && bWinNT5)
			SetForegroundWindow(pSysTrayIcon->hWnd);

		SendMessage(pSysTrayIcon->hWnd, pSysTrayIcon->uCallbackMessage, (WPARAM)pSysTrayIcon->uID, (LPARAM)message.uMsg);
		return TRUE;
	}
	return FALSE;
}

void systray::onTimer(Message& message)
{

#ifdef DEBUG_SPAM
	LSLogPrintf(LOG_DEBUG, szAppName, "Timer activated: %d", (int)message.wParam);
#endif

	switch ( message.wParam )
	{
		case TIMER_AUTOHIDE:
		{
			PSYSTRAYICON pSysTrayIcon = NULL;

			// check & cleanup icons
			if (ClearIconsOnTimer)
			{
				iconListCleanup();
				// adjust size
				adjustSize();
			}

			pSysTrayIcon = pFirst;
			if (numIgnore>0)
			{
				while (pSysTrayIcon)
				{
					if ( HideIconTimeout(pSysTrayIcon) ) // if the icon isn't already hidden
					{
						pSysTrayIcon->state.VisibilityStatus = HIDDEN;
						HideIcon(pSysTrayIcon);
					}
					pSysTrayIcon = pSysTrayIcon->pNext;
				}
			}
		}
		case TIMER_SCROLL:
		{
#ifdef DEBUG_EXTRA
			// log screensaver status change:
			BOOL test = IsSaverRunning();
			if (test != bScreenSaverRunning)
				LSLogPrintf(LOG_DEBUG, szAppName, "Screensaver status changed to: %d", test);
				bScreenSaverRunning = test;
#else
			// check if running
			bScreenSaverRunning = IsSaverRunning();
#endif
			// don't issue flash if screensaver running or if specified to do so
			if(TrayFlash && (FlashInSS || !bScreenSaverRunning) )
			{
				if ( NrIcons(ICONS_FLASHING) > 0 )
				{
					ScrollFlashing = TRUE;
					keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | 0, 0 );
					keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
				}
				else if (ScrollFlashing && (scrollWas && !GetKeyState(VK_SCROLL)) || (!scrollWas && GetKeyState(VK_SCROLL)))
				{
					ScrollFlashing = FALSE;
		  			keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | 0, 0 );
					keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
				}
			}
		}
		/*else if (resetScroll == true){
			if ((scrollWas && !GetKeyState(VK_SCROLL)) || (!scrollWas && GetKeyState(VK_SCROLL))){
		  		keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | 0, 0 );
				keybd_event( VK_SCROLL, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);
			}
			resetScroll = false;
		}*/
	}
}

void systray::onWindowPosChanging(Message& message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)message.lParam;

	if ( !( lpwp->flags & SWP_NOSIZE ) )
	{
		if ( (trayWidth != lpwp->cx) || (trayHeight != lpwp->cy) )
		{
			trayWidth = lpwp->cx;
			trayHeight = lpwp->cy;
		}
	}

	if ( !( lpwp->flags & SWP_NOMOVE ) )
	{
		if (snapDistance)
		{
			if ( abs(lpwp->x) <= snapDistance )
				lpwp->x = 0;
			if ( abs(lpwp->y) <= snapDistance )
				lpwp->y = 0;
			if ( abs(lpwp->x + trayWidth - GetSystemMetrics(SM_CXSCREEN)) <= snapDistance )
				lpwp->x = GetSystemMetrics(SM_CXSCREEN) - trayWidth;
			if ( abs(lpwp->y + trayHeight - GetSystemMetrics(SM_CYSCREEN)) <= snapDistance )
				lpwp->y = GetSystemMetrics(SM_CYSCREEN) - trayHeight;
		}
		trayX = lpwp->x;
		trayY = lpwp->y;
	}

	if ( !( lpwp->flags & SWP_NOSIZE) )
	{
		setFirstLast();
		createBackground();

		InvalidateRect(hWnd, NULL, TRUE);
	}
	message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void systray::onPaint(Message& message)
{
	HDC hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	if (transpBack)
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	paintBackground(hdcBuffer, hrgn);

	// blit the icons
	iconListPaint(hdcBuffer, hrgn);

	// set the windowRgn
	if (transpBack)
		SetWindowRgn(hWnd, hrgn, TRUE);

	// delete hrgn again
	if (hrgn)
		DeleteObject(hrgn);	

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, trayWidth, trayHeight, hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// _tremove the memory DC
	DeleteDC(hdcBuffer);

	EndPaint(hWnd, &ps);
}

/***************************/
/***** !BANG COMMANDS ******/
/***************************/

void systray::AcceptFlash(BOOL flash)
{
	// enable flash or not...
	TrayFlash = flash;
}

void systray::IconInfo(void)
{
	int icons[2];
	int i;
	int j;
	char classname[MAX_LINE_LENGTH]="";

	PSYSTRAYICON pSysTrayIcon = pFirst;
	for(i=0; i<2; i++)
	{
		j = 0;
		while (pSysTrayIcon)
		{
			// checking if in correct list
			if (i==0 && pSysTrayIcon->state.VisibilityStatus != SHOWN)
				LSLogPrintf(LOG_NOTICE, szAppName, "Icon in wrong list (shown) \"%s\" - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);
			if (i==1 && pSysTrayIcon->state.VisibilityStatus == SHOWN)
				LSLogPrintf(LOG_NOTICE, szAppName, "Icon in wrong list (!shown) \"%s\" - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);
			j++;
			// output window classnames
			GetClassName(pSysTrayIcon->hWnd, classname, MAX_LINE_LENGTH-1 ); // sizeof(classname)/sizeof(classname[0])-1
			LSLogPrintf(LOG_NOTICE, szAppName, "Icon: \"%s\", shown:%d, class: \"%s\"", pSysTrayIcon->szTip, pSysTrayIcon->state.VisibilityStatus, classname);
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
		icons[i] = j;
		pSysTrayIcon = hideFirst; // now count the hidden icons
	}
	
	// check last icon
	pSysTrayIcon = pLast;
	LSLogPrintf(LOG_DEBUG, szAppName, "last icon \"%s\" - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);

	LSLogPrintf(LOG_NOTICE, szAppName, "icons shown: %d, hidden: %d, flashing: %d", icons[0], icons[1], NrIcons(ICONS_FLASHING) );
}

void systray::ShowAllIcons(void)
{
	PSYSTRAYICON pSysTrayIcon = hideFirst;

	while (pSysTrayIcon)
	{
		pSysTrayIcon->state.VisibilityStatus = SHOWN;
		ShowIcon(pSysTrayIcon);

		pSysTrayIcon = pSysTrayIcon->pNext;
	}	
}

void systray::boxhook(LPCSTR szArgs)
{
	LSLog(LOG_DEBUG, szAppName, "Attempting to hook to LSBox");
	char *handle = strrchr(szArgs,' ');
	if (handle) 
	{
		HWND boxwnd = (HWND)atoi(handle+1);
		if (boxwnd) 
		{
			lsboxed = TRUE;
			if (boxwnd != GetParent(hWnd))
			{
				SetWindowLong(hWnd, GWL_STYLE, (GetWindowLong(hWnd, GWL_STYLE) &~ WS_POPUP)|WS_CHILD);
				SetParent(hWnd, boxwnd);
				// set new pos using getrccordinate again with boxwnd size
			}
			LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox successful");
		} else LSLog(LOG_DEBUG, szAppName, "Hooking to LSBox failed");
	}
	return;
}

void systray::show(void)
{
	visible = TRUE;
	ShowWindow( hWnd, SW_SHOWNOACTIVATE );
}

void systray::hide(void)
{
	visible = FALSE;
	ShowWindow(hWnd, SW_HIDE);
}

void systray::toggle(void)
{
	visible = !IsWindowVisible(hWnd);
	ShowWindow(hWnd, visible ? SW_SHOWNOACTIVATE : SW_HIDE);
}

void systray::setAlwaysOnTop(BOOL fAlwaysOnTop)
{
    if (!lsboxed && !inWharf)
	{
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);
		SetParent(hWnd, fAlwaysOnTop ? NULL : desktop);
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);
	}

    /* // previous code, breaks lsbox
	if (!lsboxed && !inWharf)
		ModifyStyle(hWnd, WS_POPUP, WS_CHILD);

    SetParent(hWnd, fAlwaysOnTop ? NULL : desktop);

    if (!lsboxed && !inWharf)
		ModifyStyle(hWnd, WS_CHILD, WS_POPUP);*/

   
    SetWindowPos(hWnd, fAlwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
        0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE);
   
    onTop = fAlwaysOnTop;
}

void systray::toggleOnTop(void)
{
	onTop ? setAlwaysOnTop(false) : setAlwaysOnTop(true);
}

void systray::move(int x, int y)
{
	RECT rc;
	if (x < 0) x += GetSystemMetrics(SM_CXSCREEN);
	if (y < 0) y += GetSystemMetrics(SM_CYSCREEN);
	GetWindowRect(hWnd, &rc);

	// aligning
	if (align & TD_RIGHT)
		x -= (rc.right - rc.left);
	if (align & TD_DOWN)
		y -= (rc.bottom - rc.top);

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "new pos: x:%d,y:%d, align -: x:%d, y:%d", x, y, (rc.right - rc.left), (rc.bottom - rc.top) );
#endif

	SetWindowPos(hWnd, NULL, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}

void systray::size(int x_size, int y_size)
{
	SetWindowPos(hWnd, NULL, 0, 0, x_size, y_size, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
}

// calculates the paint offset for scrolling
void systray::ScrollIcons(int Type)
{
	int icons = NrIcons(ICONS_VISIBLE);
	int scrolledicons;
	int roomfor = NrIcons(ICONS_ROOMFOR);
	// if wrapcount is defined use that, otherwise change with amount that can fit
	int deltaPaint = (wrapCount > 0) ? wrapCount : roomfor;
	BOOL removeicons;
	int i;
	PSYSTRAYICON pSysTrayIcon, nextSysTrayIcon;

	if (!autoSize && icons > roomfor)
	{
		scrolledicons = NrIcons(ICONS_SCROLLED);
		switch(Type)
		{
		case SCROLL_AUTO:
			if (PaintNext)
				Type = SCROLL_NEXT;
			else
				Type = SCROLL_BACK;
		case SCROLL_BACK:
			if (PaintOffset > deltaPaint)
				PaintOffset -= deltaPaint;
			else
			{
				PaintOffset = 0;
				// switch auto direction
				PaintNext = true;
			}
			removeicons = false;
		break;
		case SCROLL_NEXT:
			// if there is more than one line left to scroll to
			if (icons-roomfor > deltaPaint)
				PaintOffset += deltaPaint;
			else
			{
				// switch auto direction
				PaintNext = false;
				PaintOffset = icons-roomfor;
			}
			removeicons = true;
		break;
		}
	
		if (removeicons)
		{
			pSysTrayIcon = pFirst;
			for (i=0; i < (PaintOffset - scrolledicons); i++)
			{
				if (!pSysTrayIcon)
					break;
				while (pSysTrayIcon)
				{
					pSysTrayIcon->state.VisibilityStatus = SCROLLED;
					nextSysTrayIcon = pSysTrayIcon->pNext;
					HideIcon(pSysTrayIcon);
					pSysTrayIcon = nextSysTrayIcon;
				}
			}
		}
		else
		{
			pSysTrayIcon = hideFirst;
			for (i=0; i < abs(PaintOffset - scrolledicons); i++)
			{
				if (!pSysTrayIcon)
					break;
				while (pSysTrayIcon)
				{
					nextSysTrayIcon = pSysTrayIcon->pNext;
					if (pSysTrayIcon->state.VisibilityStatus == SCROLLED)
					{
						pSysTrayIcon->state.VisibilityStatus = SHOWN;
						ShowIcon(pSysTrayIcon);
					}					
					pSysTrayIcon = nextSysTrayIcon;
				}
			}
		}

	}
}

/***************************/
/********* HELPERS *********/
/***************************/

BOOL systray::IsSaverRunning()
{
	BOOL sRunning = FALSE;
	BOOL res = SystemParametersInfo(SPI_GETSCREENSAVERRUNNING,0,&sRunning,0);
	if (res)
		return sRunning;
	// Works under 95, 98 and NT>=5. For older OS:s below
	HDESK hDesk=OpenDesktop(TEXT("screen-saver"), 0, FALSE, MAXIMUM_ALLOWED);
	if (hDesk != NULL)
	{
		CloseDesktop(hDesk);
		return TRUE;
	}
	if (GetLastError() == ERROR_ACCESS_DENIED)
		return TRUE;
	else
		return FALSE;
}

int systray::NrIcons(int Type)
{
	int nr = 0;
	PSYSTRAYICON pSysTrayIcon = NULL;
	switch(Type)
	{
	case ICONS_VISIBLE:
		pSysTrayIcon = pFirst;
		while (pSysTrayIcon)
		{
			nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
	break;
	case ICONS_HIDDEN:
		pSysTrayIcon = hideFirst;
		while (pSysTrayIcon)
		{
			if (pSysTrayIcon->state.VisibilityStatus == HIDDEN)
				nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
	break;
	case ICONS_SCROLLED:
		pSysTrayIcon = hideFirst;
		while (pSysTrayIcon)
		{
			if (pSysTrayIcon->state.VisibilityStatus == SCROLLED)
				nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
	}
	case ICONS_NOTVISIBLE:
		pSysTrayIcon = hideFirst;
		while (pSysTrayIcon)
		{
			nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
	}
	case ICONS_ALL:
		pSysTrayIcon = pFirst;
		while (pSysTrayIcon)
		{
			nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
		pSysTrayIcon = hideFirst;
		while (pSysTrayIcon)
		{
			nr++;
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
	break;
	case ICONS_FLASHING:
		pSysTrayIcon = pFirst;
		while (pSysTrayIcon)
		{
			if (  pSysTrayIcon->state.isFlashing && ( (*flashTag[pSysTrayIcon->setting.MatchFlashPos].maxFlash == 0) || (pSysTrayIcon->state.FlashCount < *flashTag[pSysTrayIcon->setting.MatchFlashPos].maxFlash) )  ) 
			{
				nr++;
				pSysTrayIcon->state.FlashCount++;
#ifdef DEBUG_EXTRA
				if (*flashTag[pSysTrayIcon->setting.MatchFlashPos].maxFlash > 0)
					LSLogPrintf(LOG_DEBUG, szAppName, "flash count: %d < %d", pSysTrayIcon->state.FlashCount, *flashTag[pSysTrayIcon->setting.MatchFlashPos].maxFlash);
#endif
			}
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
	break;
	case ICONS_ROOMFOR:
		// calculate amount of icons that can fit into the systray window
		RECT rcOrg;
		int x_size, y_size, x_room, y_room;
		GetWindowRect(hWnd, &rcOrg);
		x_size = rcOrg.right - rcOrg.left;
		y_size = rcOrg.bottom - rcOrg.top;
		x_room = (x_size - (borderLeft+borderRight)-iconSpacingX) / (iconSize+iconSpacingX);
		y_room = (y_size - (borderTop+borderBottom)-iconSpacingY) / (iconSize+iconSpacingY);
		nr = x_room * y_room;
	break;
	}
	return nr;
}

// calculates first and last icon positions
void systray::setFirstLast()
{
	// the following settings are used with the icon rectangles
	// to ensure they match the desired pattern
	firstX = ( ( direction == TD_LEFT ) || ( wrapDirection == TD_LEFT ) ) ?
	         ( trayWidth - borderRight - iconSpacingX - iconSize ) :
	         ( borderLeft + iconSpacingX );
	lastX = firstX + ( wrapCount - 1 ) * deltaX;

	firstY = ( ( direction == TD_DOWN ) || ( wrapDirection == TD_DOWN ) ) ?
	         ( borderTop + iconSpacingY ) :
	         ( trayHeight - borderBottom - iconSpacingY - iconSize );

	lastY = firstY + ( wrapCount - 1 ) * deltaY;
}

void systray::createBackground()
{
	HDC hdcScreen, hdcDst;
	HBITMAP hbmDstOld;

	// delete old objects if necessary...
	if ( hbmBack )
		DeleteObject( hbmBack );
	hbmBack = NULL;

	if ( hrgnBack )
		DeleteObject( hrgnBack );
	hrgnBack = NULL;

	// initiate a new destination dc
	hdcScreen = GetDC(hWnd);

	hdcDst = CreateCompatibleDC(hdcScreen);
	hbmBack = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
	hbmDstOld = (HBITMAP)SelectObject(hdcDst, hbmBack);

	ReleaseDC(hWnd, hdcScreen);

	// if the background colors are needed put them on...
	if ((!hbmSkin) || transpSkin)
	{
		RECT r;
		HBRUSH brush;

		// fill the border with the border colors
		if (borderTop || borderLeft || borderBottom || borderTop)
		{
			brush = CreateSolidBrush(clrBorder);

			if (borderTop)
			{
				SetRect(&r, 0, 0, trayWidth, borderTop);
				FillRect(hdcDst, &r, brush);
			}
			if (borderLeft)
			{
				SetRect(&r, 0, borderTop, borderLeft, trayHeight - borderBottom);
				FillRect(hdcDst, &r, brush);
			}
			if (borderRight)
			{
				SetRect(&r, trayWidth - borderRight, borderTop, trayWidth, trayHeight - borderBottom);
				FillRect(hdcDst, &r, brush);
			}
			if (borderBottom)
			{
				SetRect(&r, 0, trayHeight - borderBottom, trayWidth, trayHeight);
				FillRect(hdcDst, &r, brush);
			}
			DeleteObject(brush);
		}

		// now fill the inner rectangle (excluding the borders) with the background color
		brush = CreateSolidBrush(clrBack);

		SetRect(&r, borderLeft, borderTop, trayWidth - borderRight, trayHeight - borderBottom);
		FillRect(hdcDst, &r, brush);

		DeleteObject(brush);
	}

	// if a background image is provided, put it on...
	if (hbmSkin)
	{

		HDC hdcSrc;
		HBITMAP hbmSrcOld;
		BITMAP bm;
		int innerWidth, innerHeight, bmInnerWidth, bmInnerHeight;

		// get info from the bitmap
		GetObject(hbmSkin, sizeof(BITMAP), &bm);

		// this is to prevent negative values on the width
		innerWidth = max(trayWidth - (borderLeft + borderRight), 0);
		innerHeight = max(trayHeight - (borderTop + borderBottom), 0);
		bmInnerWidth = max(bm.bmWidth - (borderLeft + borderRight), 1);
		bmInnerHeight = max(bm.bmHeight - (borderTop + borderBottom), 1);

		hdcSrc = CreateCompatibleDC(hdcDst);
		hbmSrcOld = (HBITMAP)SelectObject(hdcSrc, hbmSkin);

		if (borderTop || borderLeft || borderBottom || borderTop)
		{

			// paint the four corners first, and then the borders
			// topleft, topright, bottomright, bottomleft
			copyBlt(hdcDst, 0, 0, borderLeft, borderTop, hdcSrc, 0, 0);
			copyBlt(hdcDst, trayWidth - borderRight, 0, borderRight, borderTop, hdcSrc, bm.bmWidth - borderRight, 0);
			copyBlt(hdcDst, trayWidth - borderRight, trayHeight - borderBottom, borderRight, borderBottom, hdcSrc, bm.bmWidth - borderRight, bm.bmHeight - borderBottom);
			copyBlt(hdcDst, 0, trayHeight - borderBottom, borderLeft, borderBottom, hdcSrc, 0, bm.bmHeight - borderBottom);

			if (borderTop && innerWidth)
				sizeBlt(hdcDst, borderLeft, 0, innerWidth, borderTop, hdcSrc, borderLeft, 0, bmInnerWidth, borderTop);
			if (borderLeft && innerHeight)
				sizeBlt(hdcDst, 0, borderTop, borderLeft, innerHeight, hdcSrc, 0, borderTop, borderLeft, bmInnerHeight);
			if (borderRight && innerHeight)
				sizeBlt(hdcDst, trayWidth - borderRight, borderTop, borderRight, innerHeight, hdcSrc, bm.bmWidth - borderRight, borderTop, borderRight, bmInnerHeight);
			if (borderBottom && innerWidth)
				sizeBlt(hdcDst, borderLeft, trayHeight - borderBottom, innerWidth, borderBottom, hdcSrc, borderLeft, bm.bmHeight - borderBottom, bmInnerWidth, borderBottom);
		}

		// draw area in the middle
		if (innerWidth && innerHeight)
			sizeBlt(hdcDst, borderLeft, borderTop, innerWidth, innerHeight, hdcSrc, borderLeft, borderTop, bmInnerWidth, bmInnerHeight);

		SelectObject( hdcSrc, hbmSrcOld );
		DeleteDC( hdcSrc );
	}

	SelectObject( hdcDst, hbmDstOld );
	DeleteDC( hdcDst );

	if (!transpSkin)
	{
		transpBack = FALSE;
	}
	else
	{
		HRGN hOpaqueRgn = CreateRectRgn(0, 0, trayWidth, trayHeight);
		hrgnBack = BitmapToRegion(hbmBack, RGB(255, 0, 255), 0x101010, 0, 0);

		// to see if any pixels are transparent
		transpBack = !EqualRgn(hrgnBack, hOpaqueRgn);

		DeleteObject(hOpaqueRgn);

		if (!transpBack)
		{
			DeleteObject(hrgnBack);
			hrgnBack = NULL;
		}
	}
}

void systray::paintBackground( HDC hdcDst, HRGN hrgnDst )
{

	HDC hdcSrc;
	HBITMAP hbmOld;

	// if the background isn't there, make one...
	if (!hbmBack)
	{
		createBackground();
	}
	else
	{
		BITMAP bm;
		GetObject(hbmBack, sizeof(BITMAP), &bm);
		if (bm.bmWidth != trayWidth || bm.bmHeight != trayHeight)
		{
			createBackground();
		}
	}

	// if there is no background now... do nothing
	if (!hbmBack)
		return ;


	hdcSrc = CreateCompatibleDC(hdcDst);
	hbmOld = (HBITMAP)SelectObject(hdcSrc, hbmBack);

	BitBlt(hdcDst, 0, 0, trayWidth, trayHeight, hdcSrc, 0, 0, SRCCOPY);

	SelectObject(hdcSrc, hbmOld);
	DeleteDC(hdcSrc);

	if ( hrgnBack && transpBack )
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_COPY);

}

// grd Blitting functions...
// to enable transp / not transp painting
// and to enable tile / stretch resizing
int systray::copyBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc)
{
	if (transpSkin)
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, RGB(255, 0, 255));
	else
		return BitBlt(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, SRCCOPY);

	return 0;
}

int systray::sizeBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc)
{
	HDC	hdcTmp;
	HBITMAP hbmTmp, hbmOld;
	int tmpX, tmpY;

	if (transpSkin)
	{
		hdcTmp = CreateCompatibleDC( hdcDst );
		hbmTmp = CreateCompatibleBitmap( hdcDst, cxDst, cyDst );
		hbmOld = (HBITMAP)SelectObject( hdcTmp, hbmTmp );
		tmpX = 0, tmpY = 0;
	}
	else
	{
		hdcTmp = hdcDst;
		tmpX = xDst, tmpY = yDst;
	}

	if (skinTiled)
	{
		int x, y;
		// fill the first row of images
		for (x = 0; x < cxDst; x += cxSrc)
			BitBlt(hdcTmp, tmpX + x, tmpY, min(cxSrc, cxDst - x), min(cySrc, cyDst), hdcSrc, xSrc, ySrc, SRCCOPY);
		// copy this row down the y axis...
		for (y = cySrc; y < cyDst; y += cySrc)
			BitBlt(hdcTmp, tmpX, tmpY + y, cxDst, min(cySrc, cyDst - y), hdcTmp, tmpX, tmpY, SRCCOPY);

	}
	else
	{
		// stretch it
		StretchBlt(hdcTmp, tmpX, tmpY, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY);
	}

	// blit the resulting image onto the destination dc
	if (transpSkin)
	{
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcTmp, tmpX, tmpY, RGB(255, 0, 255));

		// cleanup
		SelectObject( hdcTmp, hbmOld );
		DeleteObject( hbmTmp );
		DeleteDC( hdcTmp );
	}
	return 0;
}

PSYSTRAYICON systray::iconListFind(HWND hWnd, UINT uID)
{
	int i;
	PSYSTRAYICON pSysTrayIcon = pFirst;
	for (i=0; i<2; i++)
	{
		while (pSysTrayIcon)
		{
			if ((pSysTrayIcon->hWnd == hWnd) && (pSysTrayIcon->uID == uID))
				return pSysTrayIcon;
			pSysTrayIcon = pSysTrayIcon->pNext;
		}

		// then search through hidden icons
		pSysTrayIcon = hideFirst;
	}

	return NULL;
}

PSYSTRAYICON systray::iconListFindPt(POINT pt)
{
// unnecessary to check mouseover on hidden icons...
	//int i;
	PSYSTRAYICON pSysTrayIcon = pFirst;
	//for(i=0; i<2; i++)
	//{
		while (pSysTrayIcon)
		{
			if ( PtInRect(&pSysTrayIcon->rc, pt) )
			{
				if (IsWindow(pSysTrayIcon->hWnd) )
				{
					return pSysTrayIcon;
				}
				else
				{
					iconDelGRD(pSysTrayIcon);
					return NULL;
				}
			}
			pSysTrayIcon = pSysTrayIcon->pNext;
		}
		//pSysTrayIcon = hideFirst;
	//}

	return NULL;
}

void systray::iconListCleanup()
{
	int i;
	PSYSTRAYICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;
	for(i=0; i<2; i++)
	{
		while (pSysTrayIcon)
		{
			pSysTrayIcon2 = pSysTrayIcon->pNext;
			#ifdef DEBUG_SPAM
				LSLogPrintf(LOG_DEBUG, szAppName, "checking window: 0x%X", pSysTrayIcon->hWnd);
			#endif

			if (!IsWindow(pSysTrayIcon->hWnd))
				iconDelGRD(pSysTrayIcon);

			pSysTrayIcon = pSysTrayIcon2;
		}
		pSysTrayIcon = hideFirst;
	}
}

BOOL systray::iconListDelAll()
{
	int i;
	int removed[2] = {0, 0};
	LSLog(LOG_DEBUG, szAppName, "Deleting all icons");
	PSYSTRAYICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;
	for(i=0; i<2; i++)
	{
		while (pSysTrayIcon)
		{
			// save the one to be deleted and move to the next
			pSysTrayIcon2 = pSysTrayIcon->pNext;
			// delete this history item
			iconDelGRD(pSysTrayIcon);
			pSysTrayIcon = pSysTrayIcon2;
			removed[i]++;
		}
		pSysTrayIcon = hideFirst; // now delete the hidden icons
	}
	
	LSLogPrintf(LOG_DEBUG, szAppName, "Deleted icons: shown %d, hidden %d", removed[0], removed[1]);
	return TRUE;
}

void systray::iconListPaint( HDC hdcDst, HRGN hrgnDst )
{
	/*
	//old code:
	PSYSTRAYICON pSysTrayIcon = pFirst;

	while (pSysTrayIcon)
	{
		if ( pSysTrayIcon->show ) // if it should be shown, extra precaution
		{
			if (pSysTrayIcon->hIcon)
			{
				DrawIconEx(hdcDst, pSysTrayIcon->rc.left, pSysTrayIcon->rc.top, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);

				// combine the region
				if (pSysTrayIcon->hRgn && transpBack)
				{
					OffsetRgn(pSysTrayIcon->hRgn, pSysTrayIcon->rc.left, pSysTrayIcon->rc.top);
					CombineRgn(hrgnDst, hrgnDst, pSysTrayIcon->hRgn, RGN_OR);
					OffsetRgn(pSysTrayIcon->hRgn, -pSysTrayIcon->rc.left, -pSysTrayIcon->rc.top);
				}
			}
		}
		pSysTrayIcon = pSysTrayIcon->pNext;
	}*/

	PSYSTRAYICON pSysTrayIcon = pFirst;

	while(pSysTrayIcon)
	{
		RECT *rc    = &pSysTrayIcon->rc; // test
		HRGN  hRgn  = (HRGN)pSysTrayIcon->hRgn;

		#ifdef DEBUG_SPAM
			char title[128];
			memset(title, 0, sizeof(title)/sizeof(title[0]) );
			GetWindowText( pSysTrayIcon->hWnd, title, sizeof(title)/sizeof(title[0]) );
			LSLogPrintf(LOG_DEBUG, szAppName, "painting icon, owner window title=\"%s\"", title);
		#endif

		if(pSysTrayIcon->hIcon)
		{
			if (effectFlags & FX_ANY)
			{
				COLORREF useClrHue;
				UCHAR useHueIntensity;
				UCHAR useSaturation;
				if (pSysTrayIcon->state.isFlashing) // hue effect depending on flashing
				{
					useClrHue = flashClrHue;
					useHueIntensity = flashHueIntensity;
					useSaturation = flashSaturation;
				}
				else
				{
					useClrHue = clrHue;
					useHueIntensity = hueIntensity;
					useSaturation = saturation;
				}

				UINT y = 0;
				HDC hdc        = ::CreateCompatibleDC(hdcDst);
				HBITMAP hbmNew = ::CreateCompatibleBitmap(hdcDst, 2*iconSize, iconSize);
				HBITMAP hbmOld = (HBITMAP) ::SelectObject(hdc, hbmNew);

				DrawIconEx(hdc, 0, 0, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);
				DrawIconEx(hdc, iconSize, 0, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_MASK);

				while (y < iconSize)
				{
					UINT x = 0;
					while (x < iconSize)
					{
						// loop through all transparent pixels...
						while (x < iconSize)
						{
							// if the mask-pixel is white, then break
							if ( !GetPixel(hdc, x+iconSize, y) )
							{
								COLORREF cl = ::GetPixel(hdc, x, y);
								BYTE r = GetRValue(cl);
								BYTE g = GetGValue(cl);
								BYTE b = GetBValue(cl);

								// saturation effect
								if (effectFlags & FX_SATURATION)
								{
									BYTE gray = (BYTE)(r*0.3086+g*0.6094+b*0.0820);

									r = (BYTE)((r*useSaturation+gray*(255-useSaturation)+255)>>8);
									g = (BYTE)((g*useSaturation+gray*(255-useSaturation)+255)>>8);
									b = (BYTE)((b*useSaturation+gray*(255-useSaturation)+255)>>8);
								}
								// icon hue effect
								if (effectFlags & FX_ICONHUE)
								{
									// the B & R values of the hue is swapped here, can somebody tell me why it only works that way?
									// test normal
									r = (BYTE)((r*(255-useHueIntensity)+GetRValue(useClrHue)*useHueIntensity+255)>>8);
									g = (BYTE)((g*(255-useHueIntensity)+GetGValue(useClrHue)*useHueIntensity+255)>>8);
									b = (BYTE)((b*(255-useHueIntensity)+GetBValue(useClrHue)*useHueIntensity+255)>>8);
								}
								SetPixel(hdcDst, rc->left+x, rc->top+y, RGB(r, g, b));
							}
							x++;
						}
					}
					y++;
				}
				SelectObject(hdc, hbmOld);
				DeleteObject(hbmNew);
				DeleteDC(hdc);

			}
			else
				DrawIconEx(hdcDst, rc->left, rc->top, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);

			// combine the region
			if (hRgn && transpBack)
			{ 
				OffsetRgn(hRgn, rc->left, rc->top);
				CombineRgn(hrgnDst, hrgnDst, hRgn, RGN_OR);
				OffsetRgn(hRgn, -rc->left, -rc->top);
			}
		}
		pSysTrayIcon = pSysTrayIcon->pNext;
	}
}

/***************************/
/**** PROPERTY CHANGERS ****/
/***************************/

void systray::setIcon(PSYSTRAYICON pSysTrayIcon, HICON icon)
{
	if (pSysTrayIcon->hRgn)
		DeleteObject(pSysTrayIcon->hRgn);
	pSysTrayIcon->hRgn = NULL;
	
	//pSysTrayIcon->hIcon = NULL; // <- this would prevent destroyicon from being run

	if (pSysTrayIcon->hIcon)
		DestroyIcon(pSysTrayIcon->hIcon);
		pSysTrayIcon->hIcon = NULL;
	if (icon)
		pSysTrayIcon->hIcon = CopyIcon(icon);


	if (pSysTrayIcon->hIcon && transpBack)
	{
		pSysTrayIcon->hRgn = ::CreateRectRgn(0, 0, 0, 0);

		HDC hdc = ::CreateCompatibleDC( NULL );
		HBITMAP hbmNew = ::CreateCompatibleBitmap( hdc, iconSize, iconSize );
		HBITMAP hbmOld = (HBITMAP) ::SelectObject( hdc, hbmNew );

		if ( DrawIconEx(hdc, 0, 0, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_MASK) )
		{
			UINT y = 0;
			while ( y < iconSize )
			{
				UINT x = 0;
				while ( x < iconSize )
				{
					UINT firstNTX = 0;
					// loop through all transparent pixels...
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( !::GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// set first non transparent pixel
					firstNTX = x;
					// loop through all non transparent pixels
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// if found one or more non-transparent pixels in a row, add them to the rgn...
					if ((x - firstNTX) > 0)
					{
						HRGN hTempRgn = CreateRectRgn(firstNTX, y, x, y + 1);
						CombineRgn(pSysTrayIcon->hRgn, pSysTrayIcon->hRgn, hTempRgn, RGN_OR);
						DeleteObject(hTempRgn);
					}
					x++;

				}
				y++;

			}

		}
		SelectObject( hdc, hbmOld );
		DeleteObject( hbmOld ); // testing
		DeleteObject( hbmNew );
		DeleteDC(hdc);
	}
}

void systray::setToolTip(PSYSTRAYICON pSysTrayIcon, char *szNewToolTip)
{
	BOOL existed = TRUE;
	UINT uStrLen = 0;
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd	= hWnd;
	ti.hinst = NULL;

	if (!pSysTrayIcon->szTip)
	{
		existed = FALSE;
		pSysTrayIcon->uToolTip = uLastID++;
	}

	ti.uId = pSysTrayIcon->uToolTip;

	// delete old tip
	if (existed) {
		delete[] pSysTrayIcon->szTip;
		pSysTrayIcon->szTip = NULL;
	}

	// set the new tip
	if (szNewToolTip)
	{
		pSysTrayIcon->szTip = new char[strlen(szNewToolTip) + 1];
		strcpy(pSysTrayIcon->szTip, szNewToolTip);
	}

	ti.lpszText = pSysTrayIcon->szTip;

	if ( existed )
	{
		if (IsWindow(tooltip))
		{
			SendMessage(tooltip, (pSysTrayIcon->szTip) ? TTM_UPDATETIPTEXT : TTM_DELTOOL, 0, (LPARAM)&ti);
		}
	}
	else if ( pSysTrayIcon->szTip )
	{
		ti.uFlags = 0;
		ti.rect = pSysTrayIcon->rc;
		SendMessage(tooltip, TTM_ADDTOOL, 0, (LPARAM)&ti);
	}
	// jesus_mjjg, tooltip topmost
	//SetWindowPos( tooltip, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

// calculates & sets where this icon should be placed, using previous location
void systray::adjustRect(PSYSTRAYICON pSysTrayIcon)
{

	if ( pSysTrayIcon->state.VisibilityStatus != SHOWN ) return; // if it should be painted, extra precaution

	if (pSysTrayIcon->pPrev)
	{
		if (direction & TD_VERTICAL)
		{
			// if there is room for one more icon
			if (pSysTrayIcon->pPrev->rc.top != lastY)
			{
				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + deltaY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left;
			}
			else
			{
				pSysTrayIcon->rc.top = firstY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + deltaX;
			}
		}
		else
		{
			// if there is room for one more icon
			if (pSysTrayIcon->pPrev->rc.left != lastX)
			{
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + deltaX;
				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top;
			}
			else
			{
				pSysTrayIcon->rc.left = firstX;
				pSysTrayIcon->rc.top = pSysTrayIcon->pPrev->rc.top + deltaY;
			}
		}
	}
	else
	{
		pSysTrayIcon->rc.left = firstX;
		pSysTrayIcon->rc.top = firstY;
	}

	pSysTrayIcon->rc.right = pSysTrayIcon->rc.left + iconSize;
	pSysTrayIcon->rc.bottom = pSysTrayIcon->rc.top + iconSize;

	if (pSysTrayIcon->szTip)
	{
		TOOLINFO ti;
		ti.hwnd = hWnd;
		ti.uId = pSysTrayIcon->uToolTip;
		ti.rect = pSysTrayIcon->rc;
		SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
	}
}

// should be rewritten to be more robust..
#ifdef OLD_ADJUST
void systray::adjustSize()
{
	RECT rcOrg;
	int x, y, cx, cy;

	// this is the new size...
	if (pLast)
	{

		cx = iconSize + 2 * iconSpacingX + borderRight + borderLeft;
		cy = iconSize + 2 * iconSpacingY + borderBottom + borderTop;

		if (direction & TD_VERTICAL)
		{
			if (pLast->rc.left != firstX)
				cy += (direction == TD_DOWN) ? (lastY - firstY) : (firstY - lastY);
			else
				cy += (direction == TD_DOWN) ? (pLast->rc.top - firstY) : (firstY - pLast->rc.top);

			cx += (wrapDirection == TD_RIGHT) ? (pLast->rc.left - firstX) : (firstX - pLast->rc.left);
		}
		else
		{
			if (pLast->rc.top != firstY)
				cx += (direction == TD_RIGHT) ? (lastX - firstX) : (firstX - lastX);
			else
				cx += (direction == TD_RIGHT) ? (pLast->rc.left - firstX) : (firstX - pLast->rc.left);

			cy += (wrapDirection == TD_DOWN) ? (pLast->rc.top - firstY) : (firstY - pLast->rc.top);
		}
	}
	else
	{
		cx = borderLeft + borderRight;
		cy = borderTop + borderBottom;
	}

	// position it according to the old position
	GetWindowRect(hWnd, &rcOrg);

	x = ((direction == TD_RIGHT) || (wrapDirection == TD_RIGHT)) ? rcOrg.left : rcOrg.right - cx;
	y = ((direction == TD_DOWN) || (wrapDirection == TD_DOWN)) ? rcOrg.top : rcOrg.bottom - cy;

	SetWindowPos(hWnd, NULL, x, y, cx, cy, SWP_NOACTIVATE | SWP_NOZORDER);

#ifdef DEBUG_EXTRA
	// test:
	if (pLast) {
		LSLogPrintf(LOG_DEBUG, szAppName, "Adjusting size: x:%d, y:%d, cx:%d, cy:%d", x,y,cx,cy);
		LSLogPrintf(LOG_DEBUG, szAppName, "Last Icon: \"%s\", l:%d, t:%d, r:%d, b:%d", pLast->szTip, pLast->rc.left,pLast->rc.top,pLast->rc.right,pLast->rc.bottom);
		LSLogPrintf(LOG_DEBUG, szAppName, "borders: l:%d, r:%d, t:%d, b:%d, sX:%d, sY:%d, ico:%d, icons:%d", borderLeft, borderRight, cy = borderTop, borderBottom, iconSpacingX, iconSpacingY, iconSize, NrIcons(ICONS_VISIBLE) );
	}
#endif

	/*trayX = x;
	trayY = y;
	trayWidth = cx;
	trayHeight = cy;

	setFirstLast();
	createBackground();*/

	if (pLast)
	{
		PSYSTRAYICON pSysTrayIcon = pFirst;

		while (pSysTrayIcon)
		{
			adjustRect(pSysTrayIcon);
			pSysTrayIcon = (PSYSTRAYICON)pSysTrayIcon->pNext;
		}
	}

	if (inWharf || lsboxed) {
		// compensate for position of the lsbox, works when placed on desktop too..
		HWND boxwnd = GetParent(hWnd);
		GetWindowRect(boxwnd, &rcOrg);
		SetWindowPos(hWnd, NULL, x-rcOrg.left, y-rcOrg.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	}
}

#else
// newer adjustsize, uses nr of visible icons, old one failed to resize correctly sometimes
void systray::adjustSize()
{
	RECT rcOrg;
	int x_pos, y_pos, x_size, y_size;
	int Icons = NrIcons(ICONS_VISIBLE);
	int wrapLines = 0; // wrap testing
	int wrapDivlines = (wrapCount > 0) ? (Icons / wrapCount) : 0; // integer division lines, maybe used later
	int wrapRest = (wrapCount > 0) ? Icons % wrapCount : Icons; // nr icons in last line
	int wrapSize = (wrapDivlines > 0) ? wrapCount : Icons; // nr of icons in each wrapline

	// if we have wrap, check how many lines we wrap
	// and check if the integer division leaves any icon, then extra line
	// also we get a line if no wrap at all, but there are icons...
	wrapLines = ((wrapCount > 0) ? wrapDivlines:0) + ((wrapRest > 0) ? 1:0);

	// this is the new size...
	if (pLast) // if we have icons at all
	{
		if (direction & TD_VERTICAL)
		{
			x_size = iconSize * wrapLines + iconSpacingX * (wrapLines+1) + borderRight + borderLeft;
			y_size = iconSize * wrapSize + iconSpacingY * (wrapSize+1) + + borderBottom + borderTop;
		}
		else
		{
			x_size = iconSize * wrapSize + iconSpacingX * (wrapSize+1) + borderRight + borderLeft;
			y_size = iconSize * wrapLines + iconSpacingY * (wrapLines+1) + + borderBottom + borderTop;
		}
	}
	else
	{
		x_size = borderLeft + borderRight;
		y_size = borderTop + borderBottom;
	}

	// position it according to the old position
	GetWindowRect(hWnd, &rcOrg);

	x_pos = ((direction == TD_RIGHT) || (wrapDirection == TD_RIGHT)) ? rcOrg.left : rcOrg.right - x_size;
	y_pos = ((direction == TD_DOWN) || (wrapDirection == TD_DOWN)) ? rcOrg.top : rcOrg.bottom - y_size;

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "rcOrg: l%d r%d t%d b%d ", rcOrg.left, rcOrg.right, rcOrg.top, rcOrg.bottom);
	LSLogPrintf(LOG_DEBUG, szAppName, "xpos: %d, %d, %d", rcOrg.right - x_size, rcOrg.right, x_size);
#endif

	// aligning
	if (!firstAlignDone) 
	{
		firstAlignDone = TRUE;
		if (align & TD_RIGHT && x_pos == rcOrg.left)
			x_pos -= x_size;
		if (align & TD_DOWN && y_pos == rcOrg.top)
			y_pos -= y_size;
	}

	SetWindowPos(hWnd, NULL, x_pos, y_pos, x_size, y_size, SWP_NOACTIVATE | SWP_NOZORDER);

#ifdef DEBUG_EXTRA
	// test:
	if (pLast) {
		LSLogPrintf(LOG_DEBUG, szAppName, "Adjusting size: x:%d, y:%d, size x:%d, size y:%d", x_pos,y_pos,x_size,y_size);
		LSLogPrintf(LOG_DEBUG, szAppName, "wrapCount: %d, wrapRest: %d, wrapDivlines: %d, wrapSize: %d, wrapLines: %d", wrapCount, wrapRest, wrapDivlines, wrapSize, wrapLines);
		LSLogPrintf(LOG_DEBUG, szAppName, "borders: l:%d, r:%d, t:%d, b:%d, sX:%d, sY:%d, ico:%d, icons:%d", borderLeft, borderRight, borderTop, borderBottom, iconSpacingX, iconSpacingY, iconSize, NrIcons(ICONS_VISIBLE) );
	}
#endif*/

	/*trayX = x;
	trayY = y;
	trayWidth = cx;
	trayHeight = cy;

	setFirstLast();
	createBackground();*/

	// place icons in window
	if (pLast)
	{
		PSYSTRAYICON pSysTrayIcon = pFirst;

		while (pSysTrayIcon)
		{
			adjustRect(pSysTrayIcon);
			pSysTrayIcon = (PSYSTRAYICON)pSysTrayIcon->pNext;
		}
	}

	if (inWharf || lsboxed) {
		// compensate for position of the lsbox, works when placed on desktop too..
		HWND boxwnd = GetParent(hWnd);
		GetWindowRect(boxwnd, &rcOrg);
		SetWindowPos(hWnd, NULL, x_pos-rcOrg.left, y_pos-rcOrg.top, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	}
}
#endif

DWORD systray::ModifyStyle(HWND hWnd, DWORD dwRemove, DWORD dwAdd)
{
	DWORD dwStyle = (DWORD) GetWindowLong(hWnd, GWL_STYLE);
	SetWindowLong(hWnd, GWL_STYLE, (dwStyle & ~dwRemove) | dwAdd);
	return dwStyle;
}

PSYSTRAYICON systray::iconAdd(PLSNOTIFYICONDATA pnid)
{
	if ( !IsWindow(pnid->hWnd) )
		return NULL;

	PSYSTRAYICON pSysTrayIcon;

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "Adding Icon: \"%s\" - (0x%.8X) - (0x%.8X)", pnid->szTip, pnid->hWnd, pnid->uID);
#endif

	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if found, modify instead of add
	if ( pSysTrayIcon )
		return iconMod( pnid );

	//PrintLog("iconAdd %s - (0x%.8X) - (0x%.8X)", pnid->szTip, pnid->hWnd, pnid->uID);

	// if not found (which is the way it should go)
	pSysTrayIcon = new SYSTRAYICON;
	memset(pSysTrayIcon, 0, sizeof(SYSTRAYICON));

	// transfer properties
	pSysTrayIcon->hWnd = pnid->hWnd;
	pSysTrayIcon->uID = pnid->uID;
	pSysTrayIcon->uCallbackMessage = ((pnid->uFlags & NIF_MESSAGE) ? pnid->uCallbackMessage : NULL);

	// set icon and region properties
	setIcon( pSysTrayIcon, (pnid->uFlags & NIF_ICON) ? pnid->hIcon : NULL );

	// add to last position in the list
	if (!pFirst)
	{
		pFirst = pSysTrayIcon;
		pSysTrayIcon->pPrev = NULL;
	}
	if (pLast)
	{
		pSysTrayIcon->pPrev = pLast;
		pLast->pNext = pSysTrayIcon;
	}
	pLast = pSysTrayIcon;
	pSysTrayIcon->pNext = NULL;

	// check class name once on add
	pSysTrayIcon->setting.MatchHidePos = MatchIconClass(pSysTrayIcon, MATCH_HIDE);
	pSysTrayIcon->setting.MatchFlashPos = MatchIconClass(pSysTrayIcon, MATCH_FLASH);

	// check tooltip
	pSysTrayIcon->setting.canHide = MatchIconTitle(pSysTrayIcon, pnid->szTip, MATCH_HIDE);
	if (pSysTrayIcon->setting.canHide)
		pSysTrayIcon->state.updated = time(NULL); // update time
	//pSysTrayIcon->setting.canFlash = MatchIconTitle(pSysTrayIcon, pnid->szTip, MATCH_FLASH);

	// no flash on start
	pSysTrayIcon->state.isFlashing = FALSE;
	pSysTrayIcon->state.FlashCount = 0;

	// set if icon should be shown or not
	if ( HideIconTimeout(pSysTrayIcon) ) // check windowclass
	{
		pSysTrayIcon->state.VisibilityStatus = HIDDEN; // if found don't show
		HideIcon(pSysTrayIcon); // should do all the handling
	}
	else
	{
		// these functions shouldn't be run on hidden icons
		pSysTrayIcon->state.VisibilityStatus = SHOWN;
		ExportEvars();
		RunCommandAdd();

		// if it's the first icon, send an SHOW message
		if ( (pFirst == pSysTrayIcon) && (hideIfEmpty) && visible)
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);
	}

	// adjust the rectangle to the correct position ( uses list position )
	adjustRect(pSysTrayIcon);

	// remove "unwanted" icons
	iconListCleanup();

	// add tooltip (uses rect)
	setToolTip(pSysTrayIcon, (pnid->uFlags & NIF_TIP) ? pnid->szTip : NULL);

	LSLogPrintf(LOG_DEBUG, szAppName, "Icon Added \"%s\", shown:%d (settings F:%d, H:%d)", pSysTrayIcon->szTip, pSysTrayIcon->state.VisibilityStatus, pSysTrayIcon->setting.MatchFlashPos, pSysTrayIcon->setting.MatchHidePos);

	if (autoSize)
	{
		adjustSize(); // which will repaint the window
	}
	else
	{
		InvalidateRect(hWnd, &pSysTrayIcon->rc, TRUE);
	}

	// return the newly created icon
	return pSysTrayIcon;
}

PSYSTRAYICON systray::iconMod(PLSNOTIFYICONDATA pnid)
{
	PSYSTRAYICON pSysTrayIcon;
	bool titleUpdated = false;

	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if not found, add instead of modify
	if (!pSysTrayIcon)
		return iconAdd(pnid);

	pSysTrayIcon->uID = pnid->uID;

	// only if this icon has a setting flash or hide
	if (pSysTrayIcon->setting.MatchFlashPos != MATCH_NONE || pSysTrayIcon->setting.MatchHidePos != MATCH_NONE)
		// icon considered updated if the tooltip has changed
		if (strncmp(pSysTrayIcon->szTip, pnid->szTip, max(strlen(pSysTrayIcon->szTip), strlen(pnid->szTip))) != 0)
			titleUpdated = true;

	// update if there is a new title...
	if (titleUpdated) {
		pSysTrayIcon->state.updated = time(NULL); // update time
		pSysTrayIcon->setting.canHide = MatchIconTitle(pSysTrayIcon, pnid->szTip, MATCH_HIDE);

		pSysTrayIcon->state.isFlashing = MatchIconTitle(pSysTrayIcon, pnid->szTip, MATCH_FLASH);
	#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "Icon update %s, flash: %d", pnid->szTip, pSysTrayIcon->state.isFlashing);
	#endif

	}

	/*else
	{
		// reset flash count
		pSysTrayIcon->state.FlashCount = 0;
	}*/

	if (pnid->uFlags & NIF_MESSAGE)
		pSysTrayIcon->uCallbackMessage = pnid->uCallbackMessage;

	if (pnid->uFlags & NIF_TIP)
		setToolTip(pSysTrayIcon, pnid->szTip);

	if (pnid->uFlags & NIF_ICON)
		setIcon(pSysTrayIcon, pnid->hIcon);

	if ( pSysTrayIcon->state.VisibilityStatus == HIDDEN && !HideIconTimeout(pSysTrayIcon) ) // icon was updated & it has a timer > 0
	{	
		pSysTrayIcon->state.VisibilityStatus = SHOWN;
		ShowIcon(pSysTrayIcon);
	}		

#ifdef DEBUG_SPAM
	if ( pSysTrayIcon->state.isFlashing )
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "Icon should flash: %s", pSysTrayIcon->szTip);
	}
#endif

	// remove "unwanted" icons
	iconListCleanup();

	InvalidateRect(hWnd, NULL, TRUE);

	// return the "refreshed" icon
	return pSysTrayIcon;
}

BOOL systray::iconDel(PLSNOTIFYICONDATA pnid)
{
	PSYSTRAYICON pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	if (pSysTrayIcon)
	{
		return iconDelGRD(pSysTrayIcon);
	}

	return FALSE;
}

BOOL systray::iconDelGRD(PSYSTRAYICON pSysTrayIcon)
{
	PSYSTRAYICON pIteratorSysTrayIcon;
	TOOLINFO ti;

	if ( !pSysTrayIcon )
		return FALSE;

	LSLogPrintf(LOG_DEBUG, szAppName, "Deleting Icon: %s - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);

	// remove the tooltip
	setToolTip(pSysTrayIcon, NULL);

	// remove the icon
	setIcon(pSysTrayIcon, NULL);

	// store the corresponding first&last icons
	PSYSTRAYICON *last;
	PSYSTRAYICON *first;

	if (pSysTrayIcon->state.VisibilityStatus == SHOWN) {
		last = &pLast;
		first = &pFirst;
	}
	else {
		last = &hideLast;
		first = &hideFirst;
	}

#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "Adjusting rectangles and tooltips");
#endif

	// change all the rectangles and update the tooltips
	// swap rectangles... this is smooth, only on shown icons?
	if (pSysTrayIcon->state.VisibilityStatus == SHOWN)
	{
		pIteratorSysTrayIcon = *last;
		while (pIteratorSysTrayIcon != pSysTrayIcon)
		{
			if (pIteratorSysTrayIcon && pIteratorSysTrayIcon->pPrev)
				pIteratorSysTrayIcon->rc = pIteratorSysTrayIcon->pPrev->rc;
			
			if (pIteratorSysTrayIcon->szTip)
			{
				ti.hwnd = hWnd;
				ti.uId = pIteratorSysTrayIcon->uToolTip;
				ti.rect = pIteratorSysTrayIcon->rc;
				if (IsWindow(tooltip))
					SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
			}
			pIteratorSysTrayIcon = pIteratorSysTrayIcon->pPrev;
		}
	}

#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "Moving pointers");
#endif

	// if it's first or last, move those pointers
	if (*first == pSysTrayIcon)
		*first = pSysTrayIcon->pNext;
	else
		pSysTrayIcon->pPrev->pNext = pSysTrayIcon->pNext;
	if (*last == pSysTrayIcon)
		*last = pSysTrayIcon->pPrev;
	else
		pSysTrayIcon->pNext->pPrev = pSysTrayIcon->pPrev;

	if (pSysTrayIcon->state.VisibilityStatus == SHOWN) // only execute bang on visible icons
	{
		ExportEvars();
		RunCommandDel();
	}

	// remove the icon class
	delete pSysTrayIcon;

	if (!pFirst && hideIfEmpty)
	{
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		if (autoSize)
			adjustSize();
		else
			InvalidateRect( hWnd, NULL, TRUE );
	}

#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "Icon Deleted");
#endif

	return TRUE;
}

void systray::ExportEvars()
{
	char var[256];
	
	// nr of icons visible
	memset(var, 0, 256);
	sprintf(var, "%d", NrIcons(ICONS_VISIBLE));
	LSSetVariable("SystrayCurrentIcons", var);

	memset(var, 0, 256);
	sprintf(var, "%d", trayX);
	LSSetVariable("SystrayCurrentX", var);

	memset(var, 0, 256);
	sprintf(var, "%d", trayY);
	LSSetVariable("SystrayCurrentY", var);

	memset(var, 0, 256);
	sprintf(var, "%d", trayWidth);
	LSSetVariable("SystrayCurrentWidth", var);

	memset(var, 0, 256);
	sprintf(var, "%d", trayHeight);
	LSSetVariable("SystrayCurrentHeight", var);

}

void systray::RunCommandAdd(void)
{
	
	//OnNumCount++;

	int ExecuteNr = NrIcons(ICONS_VISIBLE);

#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "starting add bang execution");
#endif

	if ( CommandsRead > 0 && ExecuteNr <= CommandsRead && OnNumExe && ExecuteNr > 0) { // OnNumList.size()
		LSLogPrintf(LOG_DEBUG, szAppName, "running nr: %d - %s", ExecuteNr, OnNumList2[(ExecuteNr - 1)].command);
		LSExecute(liteStep, OnNumList2[(ExecuteNr - 1)].command, NULL);
	}

	if ( OnAddCommand != NULL ) {
		LSLogPrintf(LOG_DEBUG, szAppName, "running standard command: %s", OnAddCommand);
		LSExecute(liteStep, OnAddCommand, NULL);
	}
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "finished add bang execution");
#endif
}

void systray::RunCommandDel(void)
{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "starting del bang execution");
#endif

	int ExecuteNr = NrIcons(ICONS_VISIBLE);

	if ( CommandsRead > 0 && ExecuteNr  <= CommandsRead && OnNumExe && ExecuteNr > 0) {
		LSLogPrintf(LOG_DEBUG, szAppName, "running nr: %d - %s", ExecuteNr , OnNumList2[(ExecuteNr  - 1)].command);
		LSExecute(liteStep, OnNumList2[(ExecuteNr  - 1)].command, NULL);
	}
	if ( OnDelCommand != NULL ) {
		LSLogPrintf(LOG_DEBUG, szAppName, "running standard command: %s", OnDelCommand);
		LSExecute(liteStep, OnDelCommand, NULL);
	}
	//OnNumCount--; // here or begining?
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "finished del bang execution");
#endif
}

/***************************/
/** ICON HIDING FUNCTIONS* */
/***************************/

void systray::HideIcon(PSYSTRAYICON pSysTrayIcon)
{
	if (pSysTrayIcon->state.VisibilityStatus != SHOWN)
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "iconHide \"%s\" - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);
		// change position

		// link out of systray chain
		if (pFirst == pSysTrayIcon)
			pFirst = pSysTrayIcon->pNext;
		else
			pSysTrayIcon->pPrev->pNext = pSysTrayIcon->pNext;

		if (pLast == pSysTrayIcon)
			pLast = pSysTrayIcon->pPrev;
		else
			pSysTrayIcon->pNext->pPrev = pSysTrayIcon->pPrev;

		// move in to last position in the hidden list
		if (!hideFirst)
		{
			hideFirst = pSysTrayIcon;
			pSysTrayIcon->pPrev = NULL;
		}
		if (hideLast)
		{
			pSysTrayIcon->pPrev = hideLast;
			hideLast->pNext = pSysTrayIcon;
		}
		hideLast = pSysTrayIcon;
		pSysTrayIcon->pNext = NULL;

		// hide window if this was the last shown icon
		if (hideIfEmpty && pFirst == NULL)
		{
			ShowWindow(hWnd, SW_HIDE);
		}

		ExportEvars();
		RunCommandDel(); // run command on hide

		// adjust size or repaint window
		if (autoSize)
			adjustSize();
		else
			InvalidateRect( hWnd, NULL, TRUE );
	}
}

void systray::ShowIcon(PSYSTRAYICON pSysTrayIcon)
{
	if (pSysTrayIcon->state.VisibilityStatus == SHOWN)
	{
		LSLogPrintf(LOG_DEBUG, szAppName, "iconShow \"%s\" - (0x%.8X) - (0x%.8X) shown:%d", pSysTrayIcon->szTip, pSysTrayIcon->hWnd, pSysTrayIcon->uID, pSysTrayIcon->state.VisibilityStatus);
		// change position

		// link out of hidden chain
		if (hideFirst == pSysTrayIcon)
			hideFirst = pSysTrayIcon->pNext;
		else
			pSysTrayIcon->pPrev->pNext = pSysTrayIcon->pNext;

		if (hideLast == pSysTrayIcon)
			hideLast = pSysTrayIcon->pPrev;
		else
			pSysTrayIcon->pNext->pPrev = pSysTrayIcon->pPrev;

		// move in to last position in the systray list
		if (!pFirst)
		{
			pFirst = pSysTrayIcon;
			pSysTrayIcon->pPrev = NULL;
		}
		if (pLast)
		{
			pSysTrayIcon->pPrev = pLast;
			pLast->pNext = pSysTrayIcon;
		}
		pLast = pSysTrayIcon;
		pSysTrayIcon->pNext = NULL;

		// set this icons position
		adjustRect(pSysTrayIcon);

		// if it's the first icon, send an SHOW message
		if ( (pFirst == pSysTrayIcon) && (hideIfEmpty) && visible)
			ShowWindow(hWnd, SW_SHOWNOACTIVATE);

		ExportEvars();
		RunCommandAdd(); // run command on show

		if (autoSize)
			adjustSize();
		else
			InvalidateRect( hWnd, NULL, TRUE );
	}
}

// looks for icon in defined configs, returns position in config list, MATCH_NONE if not found
int systray::MatchIconClass(PSYSTRAYICON pSysTrayIcon, int matchType)
{
	int i;
	char classname[MAX_LINE_LENGTH]="";

	GetClassName(pSysTrayIcon->hWnd, classname, MAX_LINE_LENGTH-1 ); // sizeof(classname)/sizeof(classname[0])-1

	switch(matchType)
	{
		case MATCH_HIDE:
		{
			if (numIgnore>0)
			{
				for (i=0; i<numIgnore; i++)
				{
					// if we find a match...
					if (strstr(classname, ignoreTag[i].classname) )
					{
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "(hide) Classname \"%s\" matched with \"%s\", saving config position, hide timer: %d min", classname, ignoreTag[i].classname, *ignoreTag[i].timer);
	if (ignoreTag[i].tip != NULL) {
		LSLog(LOG_DEBUG, szAppName, "tooltip != NULL");
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "no tip specified");
	}
#endif
						return i;
					}
				}
			}
		}
		break;
		case MATCH_FLASH:
		{
			if (numFlash>0)
			{
				for (i=0; i<numFlash; i++)
				{
					// if we find a match...
					if (strstr(classname, flashTag[i].classname) )
					{
#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "(flash) Classname \"%s\" matched with \"%s\", saving config position, max flash: %d", classname, flashTag[i].classname, *flashTag[i].maxFlash/2);
		if (flashTag[i].tip != NULL) {
			LSLog(LOG_DEBUG, szAppName, "tooltip != NULL");
		}
		else
		{
			LSLog(LOG_DEBUG, szAppName, "no tip specified");
		}
#endif
						return i;
					}
				}
			}
		}
		break;
	}
	return MATCH_NONE;
}

// checks icons title against configs title (if set)
BOOL systray::MatchIconTitle(PSYSTRAYICON pSysTrayIcon, PTSTR szTip, int matchType)
{
	switch(matchType)
	{
		case MATCH_HIDE:
		{
			if (pSysTrayIcon->setting.MatchHidePos != MATCH_NONE
				&& (ignoreTag[pSysTrayIcon->setting.MatchHidePos].tip == NULL || strstr(szTip, ignoreTag[pSysTrayIcon->setting.MatchHidePos].tip)) )
			{
				return TRUE;
			}
		}
		break;
		case MATCH_FLASH:
		{
			if (pSysTrayIcon->setting.MatchFlashPos != MATCH_NONE
				&& (flashTag[pSysTrayIcon->setting.MatchFlashPos].tip == NULL || strstr(szTip, flashTag[pSysTrayIcon->setting.MatchFlashPos].tip)) )
			{
				return TRUE;
			}
		}
		break;
	}
	return FALSE;

}

// measures time since last update if deemed to be able to hide
BOOL systray::HideIconTimeout(PSYSTRAYICON pSysTrayIcon)
{
	// if classname was matched, tip is matched and timer has gone out..
	if (pSysTrayIcon->setting.canHide && time(NULL) >= (*ignoreTag[pSysTrayIcon->setting.MatchHidePos].timer)*60+pSysTrayIcon->state.updated )
		return TRUE;
	else
		return FALSE;
}

/***************************/
/**** SETTINGS READERS *****/
/***************************/

void systray::ReadWindowLists()
{
	LSLog(LOG_DEBUG, szAppName, "starting read of *SystrayHide commands");
	ignoreTag = NULL; // initialize this?
	ReadSystrayHide(); // which icons should be hidden
	LSLogPrintf(LOG_DEBUG, szAppName, "finished reading of *SystrayHide commands, total: %d", numIgnore);
	
	LSLog(LOG_DEBUG, szAppName, "starting read of *SystrayFlash commands");
	flashTag = NULL; // initialize this?
	ReadSystrayFlash(); // which icons should be flashing
	LSLogPrintf(LOG_DEBUG, szAppName, "finished reading of *SystrayFlash commands, total: %d", numFlash);
}

void systray::DeleteWindowLists()
{
	int i = 0;
	LSLog(LOG_DEBUG, szAppName, "deleting window lists");

	// remove ignored icons
	for (i=0; i<numIgnore; i++)
	{
		delete [] ignoreTag[i].classname; // delete ignore lists
		delete ignoreTag[i].timer;
		if (ignoreTag[i].tip) delete [] ignoreTag[i].tip;
	}
	if (ignoreTag)
	{
		free(ignoreTag);
		ignoreTag = NULL;
		LSLogPrintf(LOG_DEBUG, szAppName, "removed hiding data, total: %d", i);
	}

	// remove flashing icons
	for (i=0; i<numFlash; i++)
	{
		delete [] flashTag[i].classname; // delete ignore lists
		delete flashTag[numFlash].maxFlash;
		if (flashTag[i].tip) delete [] flashTag[i].tip;
	}
	if (flashTag)
	{
		free(flashTag);
		flashTag = NULL;
		LSLogPrintf(LOG_DEBUG, szAppName, "removed flashing data, total: %d", i);
	}
}

void systray::DeleteCommands()
{
	int i = 0;

	LSLog(LOG_DEBUG, szAppName, "deleting event commands");

	if (OnDelCommand != NULL) {
		delete [] OnDelCommand;
		OnDelCommand = NULL;
	}
	if (OnAddCommand != NULL) {
		delete [] OnAddCommand;
		OnAddCommand = NULL;
	}
	if (OnMouseEnterCommand != NULL) {
		delete [] OnMouseEnterCommand;
		OnMouseEnterCommand = NULL;
	}
	if (OnMouseLeaveCommand != NULL) {
		delete [] OnMouseLeaveCommand;
		OnMouseLeaveCommand = NULL;
	}

	// delete Commands lists
	for (i=0; i<CommandsRead; i++)
	{
		delete [] OnNumList2[i].command;
	}
	if (OnNumList2 != NULL)
	{
		free(OnNumList2);
		OnNumList2 = NULL;
		LSLogPrintf(LOG_DEBUG, szAppName, "removed add commands, total: %d", i);
	}

}

void systray::ReadCommands()
{
	char szTemp[256];

	// OnAdd and OnDel commands
	GetRCLine("SysTrayOnAdd", szTemp, MAX_LINE_LENGTH, "!NONE"); // added icon command
	OnAddCommand = new char[strlen(szTemp)+1];
	strcpy(OnAddCommand, szTemp);

	GetRCLine("SysTrayOnDel", szTemp, MAX_LINE_LENGTH, "!NONE"); // removed icon command
	OnDelCommand = new char[strlen(szTemp)+1];
	strcpy(OnDelCommand, szTemp);

	// OnMouseEnter and OnMouseLeave commands
	GetRCLine("SysTrayOnMouseEnter", szTemp, MAX_LINE_LENGTH, "!NONE"); // mouse enter command
	OnMouseEnterCommand = new char[strlen(szTemp)+1];
	strcpy(OnMouseEnterCommand, szTemp);

	GetRCLine("SysTrayOnMouseLeave", szTemp, MAX_LINE_LENGTH, "!NONE"); // mouse leave command
	OnMouseLeaveCommand = new char[strlen(szTemp)+1];
	strcpy(OnMouseLeaveCommand, szTemp);

	LSLog(LOG_DEBUG, szAppName, "starting read of *SystrayOn commands");
	OnNumList2 = NULL; // initialize this?
	ReadAddCommands(); // certain commands for amount of icons
	LSLogPrintf(LOG_DEBUG, szAppName, "finished reading of *SystrayOn commands, total: %d", CommandsRead);

	// for 24.7 compatibility, why is this needed?
	#define size_test MAX_LINE_LENGTH // between 1200-1300
	char tok1[size_test], tok2[size_test], tok3[size_test]; // can name these any way you like
	char* tokn[3] = { tok1, tok2, tok3}; // can name these any way you like
	LCTokenize (NULL, tokn, 0, NULL); // removing this line crashes 0.24.7

}

void systray::ReadGUIProps()
{
	char szTemp[256];
	int tmpInteger = 0;

	// load settings here
	// ===========================================
	BOOL hidden = GetRCBool("systrayHidden", TRUE);
	visible = inWharf || !hidden;

#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "Hidden: %d, Visible: %d", hidden, visible);
#endif

	onTop = !inWharf && GetRCBool("systrayAlwaysOnTop", TRUE);
	hideIfEmpty = !inWharf && GetRCBool("systrayHideIfEmpty", TRUE);
	autoSize = !inWharf && GetRCBool("systrayAutoSize", TRUE);
	tmpInteger = GetRCInt("systrayBorderSize", 0);
	borderTop = max(GetRCInt("systrayBorderTop", tmpInteger), 0);
	borderLeft = max(GetRCInt("systrayBorderLeft", tmpInteger), 0);
	borderRight = max(GetRCInt("systrayBorderRight", tmpInteger), 0);
	borderBottom = max(GetRCInt("systrayBorderBottom", tmpInteger), 0);
	borderDrag = !inWharf && GetRCBool("systrayBorderDrag", TRUE);
	snapDistance = max(GetRCInt("systraySnapDistance", (GetRCBool("systraySnap", TRUE) ? 10 : 0)), 0);

	// icon effects
	effectFlags = 0;

	hueIntensity    = (UCHAR)min( max( GetRCInt("systrayIconHueIntensity",0), 0), 255 );
	flashHueIntensity    = (UCHAR)min( max( GetRCInt("systrayIconFlashHueIntensity",0), 0), 255 );
	clrHue          = GetRCColor("systrayIconHueColor",RGB(128,128,128));
	flashClrHue          = GetRCColor("systrayIconFlashHueColor",RGB(128,128,128));
	if ( hueIntensity || flashHueIntensity)
		effectFlags |= FX_ICONHUE;

	saturation     = (UCHAR)min( max( GetRCInt("systrayIconSaturation",255), 0), 255 );
	flashSaturation     = (UCHAR)min( max( GetRCInt("systrayIconFlashSaturation",255), 0), 255 );
	if ( saturation != 255 || flashSaturation != 255 )
		effectFlags |= FX_SATURATION;
	//LSLogPrintf(LOG_DEBUG, szAppName, "hue int: %d, saturation: %d", (int)hueIntensity, (int)saturation);

	// colors
	clrBack = GetRCColor("systrayBGColor", RGB(255, 255, 255));
	clrBorder = GetRCColor("systrayBorderColor", RGB(0, 0, 0));

	// skinning
	GetRCString("systrayBitmap", szTemp, "" , 256);

	if ( szTemp[0] == '\0' )
	{
		hbmSkin = NULL;
		transpSkin = (clrBack == RGB(255, 0, 255));
		if (!transpSkin)
			transpSkin = (borderTop + borderLeft + borderRight + borderBottom > 0) && (clrBorder == RGB(255, 0, 255));
	}
	else
	{
		BITMAP bm;
		HRGN hBitmapRgn, hOpaqueRgn;

		hbmSkin = LoadLSImage(szTemp, NULL);

		// get info from the bitmap
		GetObject( hbmSkin, sizeof(BITMAP), &bm );

		hBitmapRgn = BitmapToRegion( hbmSkin, RGB(255, 0, 255), 0x101010, 0, 0);
		hOpaqueRgn = CreateRectRgn( 0, 0, bm.bmWidth, bm.bmHeight );

		// to see if any pixels are transparent
		transpSkin = !EqualRgn( hBitmapRgn, hOpaqueRgn );

		DeleteObject( hBitmapRgn );
		DeleteObject( hOpaqueRgn );
	}
	skinTiled = GetRCBool("systrayBitmapTiled", TRUE);

	// initiate vars for the background creation
	hbmBack = NULL;
	transpBack = FALSE;
}

void systray::ReadSizeProps()
{
	char szTemp[256];
	//tray wrapping
	wrapCount = max(GetRCInt("systrayWrapCount", 0), 0);

	// get direction
	GetRCString("systrayDirection", szTemp, "", 256);
	if ( !::strnicmp(szTemp, "left", 5) )
		direction = TD_LEFT;
	else if ( !::strnicmp(szTemp, "up", 3) )
		direction = TD_UP;
	else if ( !::strnicmp(szTemp, "down", 5) )
		direction = TD_DOWN;
	else
		direction = TD_RIGHT;

	// get alignment
	GetRCString("systrayAlign", szTemp, "", 256);
	LSLogPrintf(LOG_DEBUG, szAppName, "align string: %s", szTemp);
	align = TD_OFF;

	if ( strstr(szTemp, "left") )
	{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "left align");
#endif
		align |= TD_LEFT;
	}
	else if ( strstr(szTemp, "right") )
	{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "right align");
#endif
		align |= TD_RIGHT;
	}

	if ( strstr(szTemp, "top") )
	{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "top align");
#endif
		align |= TD_UP;
	}
	else if ( strstr(szTemp, "bottom") )
	{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "bottom align");
#endif
		align |= TD_DOWN;
	}

	// get wrap-direction
	GetRCString("systrayWrapDirection", szTemp, "", 256);
	if (direction & TD_VERTICAL)
	{
		if ( !::strnicmp( szTemp, "left", 5 ) )
			wrapDirection = TD_LEFT;
		else
			wrapDirection = TD_RIGHT;
	}
	else
	{
		if ( !::strnicmp( szTemp, "up", 3) )
			wrapDirection = TD_UP;
		else
			wrapDirection = TD_DOWN;
	}

	// icon
	iconSize = max(GetRCInt( "systrayIconSize", 16 ), 1);
	iconSpacingX = max(GetRCInt( "systrayIconSpacingX", 1 ), 0);
	iconSpacingY = max(GetRCInt( "systrayIconSpacingY", 1 ), 0);

	// this section evaluates how the placing of new icons should be calculated
	deltaX = ((( direction & TD_VERTICAL ) ? wrapDirection : direction ) == TD_LEFT) ? -1 : 1;
	deltaY = ((( direction & TD_VERTICAL ) ? direction : wrapDirection ) == TD_DOWN) ? 1 : -1;

	deltaX *= iconSize + iconSpacingX;
	deltaY *= iconSize + iconSpacingY;
}

void systray::ReadSizeAndPos()
{
	if ( inWharf )
	{
		LSLog(LOG_DEBUG, szAppName, "loaded in wharf, reading wharf settings");
		RECT rc;
		int wharfBorder;

		// get the wharf window size
		GetClientRect( parentWindow, &rc );
		wharfBorder = GetRCInt( "WharfBevelWidth", 0 );

#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "wharf: p: %d,%d, s:%d,%d", rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top);
#endif

		trayX = wharfBorder;
		trayY = wharfBorder;
		trayWidth = rc.right - 2 * wharfBorder;
		trayHeight = rc.bottom - 2 * wharfBorder;
		LSLog(LOG_DEBUG, szAppName, "Done reading wharf settings");
	}
	else
	{
		LSLog(LOG_DEBUG, szAppName, "not in wharf, reading size settings");
		trayX = GetRCCoordinate("SystrayX", 0, GetSystemMetrics(SM_CXSCREEN));
		trayY = GetRCCoordinate("SystrayY", 0, GetSystemMetrics(SM_CYSCREEN));
		trayWidth = GetRCInt( "systrayWidth", 64 );
		trayHeight = GetRCInt( "systrayHeight", 64 );
		LSLog(LOG_DEBUG, szAppName, "Done reading size settings");
	}
}

void systray::ReadSystrayHide(void)
{
	FILE *f;
	unsigned int i;
	int count;
	char *token[3];
	char extra[MAX_LINE_LENGTH]="";
	char buffer[4096];
	memset(extra, 0, sizeof(extra)/sizeof(extra[0]));
	numIgnore = 0;
	f = LCOpen(NULL);
	if (!f)
	{
		LSLog(LOG_ERROR, szAppName, "can't open .rc file for *systrayhide reading");
		return;
	}
	for (i=0;i< ( sizeof(token)/sizeof(token[0]) ); i++)
		token[i] = new char[MAX_LINE_LENGTH];
	while (LCReadNextConfig (f, "*SystrayHide", buffer, sizeof(buffer)-1 ))
	{
		count = LCTokenize (buffer, token, ( sizeof(token)/sizeof(token[0]) ), extra);
#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "hide classname: %s", token[1]);
#endif
		//if (!StripWS(token[1])) continue;
		if (count >= 3)
		{
			if (!ignoreTag)
				ignoreTag = (IgnoreList *)malloc(sizeof(IgnoreList));
			else
				ignoreTag = (IgnoreList *)realloc(ignoreTag, (numIgnore+1)*sizeof(IgnoreList));

			ignoreTag[numIgnore].classname = new char[strlen(token[1])+1];
			strcpy(ignoreTag[numIgnore].classname, token[1]);

			ignoreTag[numIgnore].timer = new int;

			if ( !extra[0] )
			{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "No tooltip of icon specified");
#endif
				ignoreTag[numIgnore].tip = NULL;
				*ignoreTag[numIgnore].timer = atoi(token[2]); // min timer
			}
			else
			{
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "tooltip specified: \"%s\"", token[2]);
#endif
				ignoreTag[numIgnore].tip = new char[strlen(token[2])+1];
				strcpy(ignoreTag[numIgnore].tip, token[2]);
				*ignoreTag[numIgnore].timer = atoi(extra); // min timer
			}
			numIgnore++;
		}
	}
	LCClose(f);
	for (i = 0; i < sizeof(token)/sizeof(token[0]); i++)
		delete [] token[i];
	return;
}

void systray::ReadAddCommands(void)
{
	char szTemp[256];
	FILE *f;
	f = LCOpen(NULL);

	char token1[MAX_LINE_LENGTH], token2[MAX_LINE_LENGTH], extra[MAX_LINE_LENGTH];
	char *tokens[2] = { token1, token2 };
	//char *tempNew;
	CommandsRead = 0;
	int tmpMark, Mark = 1;
	//OnNumCount = 0;
	OnNumExe = 1;

	while ( LCReadNextConfig (f, "*SysTrayOn", szTemp, sizeof(szTemp) ) ) {

		LCTokenize (szTemp, tokens, 2, extra);
		tmpMark = atoi(token2);

		if ( tmpMark != Mark )
		{
			// fill with !none commands until found one is reached
			for ( ; Mark < tmpMark ; Mark++ ) {
				if (!OnNumList2)
					OnNumList2 = (OnNumCommands *)malloc(sizeof(OnNumCommands));
				else
					OnNumList2 = (OnNumCommands *)realloc(OnNumList2, (Mark+1)*sizeof(OnNumCommands));

				OnNumList2[Mark-1].command = new char[6];
				strcpy(OnNumList2[Mark-1].command, "!none");
				CommandsRead++;
			}
		}

		if (!OnNumList2)
			OnNumList2 = (OnNumCommands *)malloc(sizeof(OnNumCommands));
		else
			OnNumList2 = (OnNumCommands *)realloc(OnNumList2, (Mark+1)*sizeof(OnNumCommands));

		OnNumList2[Mark-1].command = new char[strlen(extra)+1];
		strcpy(OnNumList2[Mark-1].command, extra);

		// original using vector commands
		/*if ( tmpMark != Mark )
		{
			for ( ; Mark < tmpMark ; Mark++ ) {
				tempNew = new char[6];
				strcpy(tempNew, "!none");
				OnNumList.push_back(tempNew);
			}
		}

		tempNew = new char[strlen(token3) + 1];
		strcpy(tempNew, token3);
		OnNumList.push_back(tempNew);*/

		CommandsRead++;
		Mark++;
	}

	LCClose(f);
}

// read systray flash lines:
// format *systrayflash "classname" "title (optional)" flashes/update
void systray::ReadSystrayFlash(void)
{
	FILE *f;
	unsigned int i;
	int count;
	char *token[4];
	char buffer[4096];
	numFlash = 0;
	f = LCOpen(NULL);
	if (!f)
	{
		LSLog(LOG_ERROR, szAppName, "can't open .rc file for *systrayflash reading");
		return;
	}
	for (i=0;i< ( sizeof(token)/sizeof(token[0]) ); i++)
		token[i] = new char[MAX_LINE_LENGTH];
	while (LCReadNextConfig (f, "*SystrayFlash", buffer, sizeof(buffer)-1 ))
	{
		count = LCTokenize (buffer, token, ( sizeof(token)/sizeof(token[0]) ), NULL);
#ifdef DEBUG_EXTRA
		LSLogPrintf(LOG_DEBUG, szAppName, "flash on classname: %s", token[1]);
#endif
		//if (!StripWS(token[1])) continue;

		if (count > 2)
		{
			if (!flashTag)
				flashTag = (flashList *)malloc(sizeof(flashList));
			else
				flashTag = (flashList *)realloc(flashTag, (numFlash+1)*sizeof(flashList));

			flashTag[numFlash].classname = new char[strlen(token[1])+1];
			flashTag[numFlash].maxFlash = new int;
			*flashTag[numFlash].maxFlash = 0;
			strcpy(flashTag[numFlash].classname, token[1]);
			if (count < 4)
			{
#ifdef DEBUG_EXTRA
	LSLog(LOG_DEBUG, szAppName, "No tooltip of icon specified");
#endif
				flashTag[numFlash].tip = NULL;
				*flashTag[numFlash].maxFlash = atoi(token[2])*2;
			}
			else
			{
#ifdef DEBUG_EXTRA
	LSLogPrintf(LOG_DEBUG, szAppName, "tooltip specified: \"%s\"", token[2]);
#endif
				flashTag[numFlash].tip = new char[strlen(token[2])+1];
				strcpy(flashTag[numFlash].tip, token[2]);
				// *2 since it's on,off
				*flashTag[numFlash].maxFlash = atoi(token[3])*2;
			}
			numFlash++;
		}
		else
		{
			LSLogPrintf(LOG_WARNING, szAppName, "To few config items in setting: \"%s\", format is *systrayflash \"classname\" \"title (optional)\" flashes/update", buffer);
		}
	}
	LCClose(f);
	for (i = 0; i < sizeof(token)/sizeof(token[0]); i++)
		delete [] token[i];
	return;
}