#ifndef __HOOK_H
#define __HOOK_H

#include <stdio.h>
#include "../lsapi/lsapi.h"

#ifdef HOOK_DLL
	#define HOOK_EXPORT __declspec(dllexport)
#else
	#define HOOK_EXPORT __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

HOOK_EXPORT void AttachHookDll(HWND hwndParent);
HOOK_EXPORT bool InstallMsgFilter(bool install);
HOOK_EXPORT bool InstallShellFilter(bool install);

#ifdef __cplusplus
}
#endif

//
// Structure that contains the hook message data sent from the hook
// to the hooking app.  The hwnd is sent using wParam of
// the WM_COPYDATA message, and the message number is in the dwData
// field of the COPYDATASTRUCT.  This structure allows the wParam,
// lParam and any optional extra data to be passed across.
//
typedef struct
{
    WPARAM wParam;
    LPARAM lParam;
    UINT dwData;
    BYTE ExtraData[64];
} HOOKMSGDATA, *PHOOKMSGDATA;

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT	CALLBACK GetMsgProc (int nCode, WPARAM wParam, LPARAM lParam );

#endif
