/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
// Desktop.dll - dummy module to inform users they need to load desktop2 instead

#include "../lsapi/macros.h"
#include "../lsapi/lsapi.h"
#include "../core/ifcs.h"
#include "resource.h"

//=========================================================
// Initialization and cleanup
//=========================================================

IModuleManager *g_mod_man;

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
	ILitestep *litestep;

	litestep = (ILitestep*)SendMessage(GetLitestepWnd(), LM_GETLSOBJECT, 0, 0);

	RESOURCE_MSGBOX(dllInst , IDS_DESKTOP_ERROR1, 
				_TEXT("DESKTOP.DLL is no longer support in LiteStep 24.6.\n\nPlease edit your step.rc file and _tremove the LoadModule line for Desktop.dll.\nReplace it with LoadModule lines for Desktop2.dll and (optionally) Taskbar.dll and Systray2.dll."), 
				_TEXT("LiteStep 24.6"))
  
	litestep->GetModuleManager(&g_mod_man);
	g_mod_man->LoadModule(OLESTR("desktop2.dll"), NULL);

  return 0;
}


void quitModule(HINSTANCE dllInst)
{
  g_mod_man->QuitModule(OLESTR("desktop2.dll"));
}
