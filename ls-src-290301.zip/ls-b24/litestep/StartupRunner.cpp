/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
// StartupRunner.cpp: implementation of the StartupRunner class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <tchar.h>
#include <shlobj.h>
#include <io.h>
#include "../lsapi/lsapi.h"
#include "StartupRunner.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StartupRunner::StartupRunner()
{

}

StartupRunner::~StartupRunner()
{

}

// [Startup Handler Code]
//DWORD WINAPI StartupRunner::RunStartupStuff (void *underExplorer)
void StartupRunner::RunStartupStuff (void *underExplorer)
{
	const LPCTSTR szRunPath = _T(_TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Run"));
	const LPCTSTR szRunOncePath = _T(_TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"));

	if (!*(BOOL*)underExplorer) {
		// Run HKLM entries
		RunEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
		DeleteEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
		RunEntriesIn (HKEY_LOCAL_MACHINE, szRunPath);

		// Run HKCU entries and startup items
		RunEntriesIn (HKEY_CURRENT_USER, szRunPath);
		RunStartupMenu ();
		RunEntriesIn (HKEY_CURRENT_USER, szRunOncePath);
		DeleteEntriesIn (HKEY_CURRENT_USER, szRunOncePath);
	}
  //return 0;
}

void StartupRunner::RunEntriesIn (HKEY key, LPCTSTR path) {
	HKEY    hKey = NULL;
	LONG    lResult;

	lResult = RegOpenKeyEx(key, path, 0, KEY_READ, &hKey);

	if (lResult == ERROR_SUCCESS) {
		TCHAR szNameBuffer[1024], szValueBuffer[1024];
		DWORD dwLoop, dwNameSize, dwValueSize;

		for (dwLoop = 0; ; ++dwLoop) {
			dwNameSize = sizeof (szNameBuffer);
			dwValueSize = sizeof (szValueBuffer);
			lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
				(LPBYTE) szValueBuffer, &dwValueSize);
			if (lResult == ERROR_NO_MORE_ITEMS) {break;}
			if (lResult == ERROR_SUCCESS) {WinExec (szValueBuffer, SW_SHOW);}
			else {break;}
		}
		RegCloseKey (hKey);
	}
}

void StartupRunner::DeleteEntriesIn (HKEY key, LPCTSTR path) {
	HKEY    hKey = NULL;
	LONG    lResult;
	
	lResult = RegOpenKeyEx(key, path, 0, KEY_ALL_ACCESS, &hKey);
	if (lResult == ERROR_SUCCESS) {
		TCHAR szNameBuffer[1024], szValueBuffer[1024];
		DWORD dwLoop, dwNameSize, dwValueSize;
		
		for (dwLoop = 0; ;) {
			dwNameSize = sizeof (szNameBuffer);
			dwValueSize = sizeof (szValueBuffer);
			
			lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
				(LPBYTE) szValueBuffer, &dwValueSize);
			if (lResult == ERROR_NO_MORE_ITEMS) {break;}
			if (lResult == ERROR_SUCCESS) {
				lResult = RegDeleteValue(hKey,szNameBuffer);
				if (lResult != ERROR_SUCCESS) {break;}
			}
			else {break;}
		}
		RegCloseKey (hKey);
	}
}

void StartupRunner::RunStartupMenu (void) {
	_TCHAR szPath[256];
	LPITEMIDLIST item;
	LPMALLOC pMalloc;
	SHGetSpecialFolderLocation(NULL, CSIDL_COMMON_STARTUP, &item);
	SHGetPathFromIDList(item, szPath);
	RunFolderContents(szPath);
	if(SUCCEEDED(SHGetMalloc(&pMalloc))) {
		pMalloc->Free(item);
		pMalloc->Release();
	}
	
	SHGetSpecialFolderLocation(NULL,CSIDL_STARTUP,&item);
	SHGetPathFromIDList(item, szPath);
	RunFolderContents(szPath);
	if(SUCCEEDED(SHGetMalloc(&pMalloc))) {
		pMalloc->Free(item);
		pMalloc->Release();
	}
}

void StartupRunner::RunFolderContents(LPCTSTR szParams) {
	_TCHAR szDir[256], szPath[256];
	WIN32_FIND_DATA findData;
	HANDLE hSearch;
	
	_tcscpy(szPath, szParams);
	_tcscpy(szDir, szPath);
	if (szPath[_tcsclen(szPath)-1] != '\\') 
    _tcscat(szPath, _TEXT("\\"));
	_tcscat(szPath, _TEXT("*.*"));
	
	if (_tcscmp(szPath, _TEXT("\\*.*")) != 0) {
		hSearch = FindFirstFile(szPath, &findData);
		while (hSearch != INVALID_HANDLE_VALUE)
    {
			if (_tcscmp(findData.cFileName, _TEXT(".")) && _tcscmp(findData.cFileName, _TEXT("..")))
				LSExecuteEx(NULL, NULL, findData.cFileName, NULL, szDir, SW_SHOWNORMAL);
			
      if (!FindNextFile(hSearch, &findData))
      {
				FindClose(hSearch);
				hSearch = INVALID_HANDLE_VALUE;
      }
		}
	}
}

