#include <windows.h>
#include <comdef.h>
#include "lsapi.h"
#include "../core/ifcs.h"

IStepSettings *g_settings;

// dll exports

__declspec(dllexport) void SetStepSettings(IStepSettings *stepsets) {
	g_settings = stepsets;
	// should we AddRef or not? Hard to clean up in a dll...
}

FILE* LCOpen(LPCTSTR szPath)
{
  return (FILE*)g_settings->GetIterator(_bstr_t(szPath));
}


BOOL LCClose (FILE *f)
{
	((IStepIterator*)f)->Release();
	
	return TRUE;
}


BOOL LCReadNextCommand (FILE *f, LPTSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextLine();

	if (buffer != NULL) {

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else
		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	} else {
		SysFreeString(buffer);
		return FALSE;
	}
}


BOOL LCReadNextConfig (FILE *f, LPCTSTR szPrefix, LPTSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextConfig(_bstr_t(szPrefix));

	if (buffer != NULL) {

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else
		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	} else {
		SysFreeString(buffer);
		return FALSE;
	}
}


BOOL LCReadNextLine (FILE *f, LPTSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextLine();

	if (buffer != NULL) {

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else
		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	} else {
		SysFreeString(buffer);
		return FALSE;
	}
}

int _Tokenize(LPCTSTR szString, LPTSTR *lpszBuffers, DWORD dwNumBuffers, LPTSTR szExtraParameters, BOOL useBrackets) {
	BSTR *tokens = new BSTR[dwNumBuffers];
	BSTR remainder;
	int count;
	
	count = g_settings->Tokenize(_bstr_t(szString), dwNumBuffers, tokens, &remainder, FALSE);

	for (int i = 0; i < count; i++) {
		if (i < (int)dwNumBuffers) {
#ifdef _UNICODE
			wcscpy(lpszBuffers[i], tokens[i]);
#else
			WideCharToMultiByte(CP_ACP, 0, tokens[i], SysStringLen(tokens[i]) + 1, lpszBuffers[i], SysStringLen(tokens[i]) + 1, NULL, NULL);
#endif
		}

		SysFreeString(tokens[i]);
	}

	if (szExtraParameters != NULL) {
#ifdef _UNICODE
		wcscpy(szExtraParameters, remainder);
#else
		WideCharToMultiByte(CP_ACP, 0, remainder, SysStringLen(remainder) + 1, szExtraParameters, SysStringLen(remainder) + 1, NULL, NULL);
#endif
	}

	SysFreeString(remainder);
	delete [] tokens;

	return count;
}

int LCTokenize (LPCTSTR szString, LPTSTR *lpszBuffers, DWORD dwNumBuffers, LPTSTR szExtraParameters)
{
	return _Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, FALSE);
}

BOOL GetToken(LPCTSTR szString, LPTSTR szToken, LPCTSTR* szNextToken, BOOL useBrackets) {
	BSTR token;
	int index;
	BOOL result;

 	result = g_settings->Token(_bstr_t(szString), &token, &index, useBrackets);

	if (index != NULL) {
		if (szNextToken != NULL) {
			// pointer to next token is original plus index times size of characters
			*szNextToken = szString + index * sizeof(_TCHAR);
		}
	} else {
		if (szNextToken != NULL) {
			*szNextToken = NULL;
		}
	}

	if (szToken != NULL) {
#ifdef _UNICODE
		wcscpy(szToken, token);
#else
		WideCharToMultiByte(CP_ACP, 0, token, SysStringLen(token) + 1, szToken, SysStringLen(token) + 1, NULL, NULL);
#endif
	}

	SysFreeString(token);

	return result;
}

int CommandTokenize(LPCTSTR szString, LPTSTR *lpszBuffers, DWORD dwNumBuffers, LPTSTR szExtraParameters)
{
  return _Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, TRUE);
}


int GetRCInt(LPCTSTR szKeyName, int nDefault)
{
  return g_settings->GetInt(_bstr_t(szKeyName), nDefault);
}


BOOL GetRCBool(LPCTSTR szKeyName, BOOL ifFound)
{
  return g_settings->GetBool(_bstr_t(szKeyName), ifFound);
}


BOOL GetRCBoolDef(LPCTSTR szKeyName, BOOL bDefault)
{
  return g_settings->GetBoolDef(_bstr_t(szKeyName), bDefault);
}


BOOL GetRCString(LPCTSTR szKeyName, LPTSTR szValue, LPCTSTR defStr, int maxLen)
{
	BSTR value = g_settings->GetString(_bstr_t(szKeyName), _bstr_t(defStr));
	BOOL result = FALSE;

	if (value == NULL) {
		return result;
	}

	if (szValue != NULL) {
#ifdef _UNICODE
		wcsncpy(szValue, value, maxLen);
#else
		WideCharToMultiByte(CP_ACP, 0, value, SysStringLen(value) + 1, szValue, maxLen, NULL, NULL);
#endif
	}

	result = SysStringLen(value) > 0;

	SysFreeString(value);

	return result;
}


COLORREF GetRCColor(LPCTSTR szKeyName, COLORREF colDef)
{
  return g_settings->GetColor(_bstr_t(szKeyName), colDef);
}


BOOL GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault)
{
	BSTR value = g_settings->GetLine(_bstr_t(szKeyName), _bstr_t(szDefault));
	BOOL result = FALSE;

	if (value == NULL) {
		return result;
	}

	if (szBuffer != NULL) {
#ifdef _UNICODE
		wcsncpy(szBuffer, value, nBufLen);
#else
		WideCharToMultiByte(CP_ACP, 0, value, SysStringLen(value) + 1, szBuffer, nBufLen, NULL, NULL);
#endif
	}

	result = SysStringLen(value) > 0;

	SysFreeString(value);

	return result;
}


void VarExpansion(_TCHAR *buffer, const _TCHAR * value)
{
	BSTR output = g_settings->VarExpansion(_bstr_t(value));

	if (buffer != NULL) {
#ifdef _UNICODE
		wcsncpy(buffer, output, nBufLen);
#else
		WideCharToMultiByte(CP_ACP, 0, output, SysStringLen(output) + 1, buffer, SysStringLen(output) + 1, NULL, NULL);
#endif
	}

	SysFreeString(output);
}

