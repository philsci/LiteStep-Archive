/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef _BANGS_H
#define _BANGS_H

void BangAbout(HWND caller, LPCTSTR args);
void BangAlert(HWND caller, LPCTSTR args);
void BangCascadeWindows(HWND caller, LPCTSTR args);
void BangConfirm(HWND caller, LPCTSTR args);
void BangExecute(HWND caller, LPCTSTR args);
void BangGather(HWND caller, LPCTSTR args);
void BangLogoff(HWND caller, LPCTSTR args);
void BangMinimizeWindows(HWND caller, LPCTSTR args);
void BangPopup(HWND caller, LPCTSTR args);
void BangQuit(HWND caller, LPCTSTR param);
void BangRecycle (HWND caller, LPCTSTR args);
void BangRefresh(HWND caller, LPCTSTR args);
void BangReload(HWND caller, LPCTSTR args);
void BangReloadModule (HWND caller, LPCTSTR args);
void BangRestoreWindows(HWND caller, LPCTSTR args);
void BangRun (HWND caller, LPCTSTR args);
void BangShutdown(HWND caller, LPCTSTR args);
void BangTileWindowsH(HWND caller, LPCTSTR args);
void BangTileWindowsV(HWND caller, LPCTSTR args);
void BangToggleWharf(HWND caller, LPCTSTR args);
void BangUnloadModule (HWND caller, LPCTSTR args);

#endif

