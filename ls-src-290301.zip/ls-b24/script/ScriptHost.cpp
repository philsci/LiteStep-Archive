/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
// ScriptHost.cpp: implementation of the ScriptHost class.
//
//////////////////////////////////////////////////////////////////////

#include <tchar.h>
#include <comdef.h>
#include "../core/ifcs.h"
#include "../lsapi/lsapi.h"
#include "ScriptHost.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ScriptHost::ScriptHost()
{
	refCount = 0;

	litestep = (ILitestep*)SendMessage(GetLitestepWnd(), LM_GETLSOBJECT, 0, 0);
	IBangManager *bangman;
	litestep->GetBangManager(&bangman);
	bangman->QueryInterface(IID_DBangManager, (void**)&dbangman);

	ITypeLib *tlib;
	LoadRegTypeLib(LIBID_LitestepCore, 0, 0, 0, &tlib);
	tlib->GetTypeInfoOfGuid(IID_DBangManager, &dbangmanInfo);
	tlib->Release();

	CLSID cls1;
	CLSIDFromString(L"{B54F3741-5B07-11CF-A4B0-00AA004A55E8}", &cls1);
	CoCreateInstance(cls1, NULL, CLSCTX_INPROC_SERVER, IID_IActiveScriptParse, (void**)&scriptParse);

	scriptParse->QueryInterface(IID_IActiveScript, (void**)&activeScript);

	scriptParse->InitNew();
	activeScript->SetScriptSite(dynamic_cast<IActiveScriptSite*>(this));

	activeScript->AddNamedItem(L"BangManager", SCRIPTITEM_ISVISIBLE);
	/*if (FAILED(activeScript->SetScriptState(SCRIPTSTATE_INITIALIZED))) {
		int a = 1;
	}*/

}

ScriptHost::~ScriptHost()
{

}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE ScriptHost::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IActiveScriptSite) {
		*ppv = static_cast<IActiveScriptSite*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE ScriptHost::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE ScriptHost::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

// From IActiveScriptSite
HRESULT STDMETHODCALLTYPE ScriptHost::GetLCID( 
    /* [out] */ LCID __RPC_FAR *plcid) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::GetItemInfo( 
    /* [in] */ LPCOLESTR pstrName,
    /* [in] */ DWORD dwReturnMask,
    /* [out] */ IUnknown __RPC_FAR *__RPC_FAR *ppiunkItem,
    /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppti) {
	if (wcscmp(pstrName, L"BangManager") == 0) {
		dbangman->QueryInterface(IID_IUnknown, (void**)ppiunkItem);
		dbangmanInfo->QueryInterface(IID_ITypeInfo, (void**)ppti);

		return S_OK;
	}

	return E_FAIL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::GetDocVersionString( 
    /* [out] */ BSTR __RPC_FAR *pbstrVersion) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::OnScriptTerminate( 
    /* [in] */ const VARIANT __RPC_FAR *pvarResult,
    /* [in] */ const EXCEPINFO __RPC_FAR *pexcepinfo) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::OnStateChange( 
    /* [in] */ SCRIPTSTATE ssScriptState) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::OnScriptError( 
    /* [in] */ IActiveScriptError __RPC_FAR *pscripterror) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::OnEnterScript( void) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE ScriptHost::OnLeaveScript( void) {
	return E_NOTIMPL;
}

void ScriptHost::RunScriptlet(LPSTR script)
{
	//scriptParse->InitNew();
	//AddRef();
	//HRESULT q = activeScript->SetScriptSite(dynamic_cast<IActiveScriptSite*>(this));

	/*
	if (FAILED(q)) {
		switch (q) {
		case E_UNEXPECTED:
			int a = 1;
		}
	}*/

	_bstr_t myScriptText = "Sub MySubroutine\nBangManager.Execute(\"!Recycle\")\nEnd Sub";

	activeScript->SetScriptState(SCRIPTSTATE_STARTED);
	HRESULT hr = scriptParse->ParseScriptText(myScriptText, NULL, NULL, NULL, 0, 0, 0, NULL, NULL);
	if (FAILED(hr)) {
		switch (hr) {
		case E_UNEXPECTED:
	SCRIPTSTATE state;
	activeScript->GetScriptState(&state);
			MessageBox(NULL, "blah", "blah", MB_OK | MB_TOPMOST);
			break;
		}
	}

	IDispatch *myDisp;
	activeScript->GetScriptDispatch(L"script", &myDisp);

	OLECHAR *myname = L"script";

	DISPID myDispID;

	myDisp->GetIDsOfNames(IID_NULL, &myname, 1, 0, &myDispID);
	myDisp->Invoke(myDispID, IID_NULL, 0, 0, NULL, NULL, NULL, NULL);
}
