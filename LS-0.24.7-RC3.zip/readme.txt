=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    LiteStep 0.24.7 Release Candidate 3
    Readme/Release Notes
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


-- PREFACE ------------------------------------------------------------

 Hot on the heels of the State of the Step, your friendly devteam
 announces Release Candidate 3 of LiteStep 0.24.7. Changes since
 Release Candidate 2 are listed below as usual. Refer to changes.txt
 for a a list of changes since 0.24.6.

 This will hopefully be the last Release Candidate. Please let us know
 if you find any showstoppers.
 Installation instructions are not included. Use at your own risk.


-- CHANGES SINCE RELEASE CANDIDATE 2 ----------------------------------

 - Fixed XP logon delay (many, many thanks to Nicolas Escuder)

 - Fixed Logitech QuickSwitch closing LiteStep on middleclick

 - TrayService now preserves NIM_SETVERSION and NIM_SETFOCUS return
   values

 - STLport no longer necessary to compile or use Litestep

 - Various minor fixes


-- FINAL WORDS --------------------------------------------------------

 Thanks to the LiteStep Community for all the positive feedback and
 support; and for the endless patience. It has taken a long time, but
 we may yet see a Final Release.

 Please send any suggestions or bug reports to the LS Mailing List or
 use the lsdev.org forums. You can also send a private email to ilmcuts
 at gmx dot net.
 
 Happy LiteStepping,

 - The LiteStep Development Team