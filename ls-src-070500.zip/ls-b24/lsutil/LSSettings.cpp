// implementation of settings object
#include "../lsapi/lsapi.h"
#include "LSSettings.h"

LSSettings::LSSettings() {
}

int LSSettings::loadSettings() {
    char tmpbuf[200];	
	char *param;
	
    //AddBangCommand((char *) test, DebugMessages);	
    trayIconSize = GetRCInt("SysTrayIconSize", 16);
    autoHideDelay = GetRCInt("AutoHideDelay", 500);
    
	fNoSystray = GetRCBool("NoSystray", TRUE);
	isShell = GetRCBool("LSSetAsShell", TRUE);
	dockToWharf = GetRCBool("SystrayDockToWharf", TRUE);
	setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
    appBar = GetRCBool("NoTaskBar", FALSE);
    autoHideWharf = GetRCBool("AutoHideWharf", TRUE);
	sdaLeft = GetRCInt("SDALeft", 0);
	sdaRight = GetRCInt("SDARight", 600);
	sdaTop = GetRCInt("SDATop", 0);
	sdaBottom = GetRCInt("SDABottom", 450);
	
    autoHide = GetRCBool("AutoHideTaskBar", TRUE);
    startButton = GetRCBool("TaskbarStartButton", TRUE);
   	taskBMP.bitmap = NULL;
    //if (appBar) {
		newStyle = GetRCBool("MSTaskBar", FALSE);	
		stripBar = GetRCBool("StripTaskBar", TRUE);
		startButtonSize = GetRCInt("StartButtonSize", 32);
		GetRCString("StartButtonText", (LPSTR)&startButtonText, "Start", 50);
		GetRCString("StartButtonImage", (LPSTR)&startButtonImage, "default", MAX_PATH);
		fore = GetRCColor("LSTaskBarFore", 0x000000);
		fore2 = GetRCColor("LSTaskBarFore2", 0x3f3f3f);
		back = GetRCColor("LSTaskBarBack", 0x7f7f7f);
		text = GetRCColor("LSTaskBarText", 0xffffff);
		GetRCString("StartButtonLeft", StartButtonLeft, "", 256);
		startbuttonleftBMP.bitmap = LoadLSImage(StartButtonLeft, NULL);
		GetLSBitmapSize(startbuttonleftBMP.bitmap, &startbuttonleftBMP.x, &startbuttonleftBMP.y);
		GetRCString("StartButtonRight", StartButtonRight, "", 256);
		startbuttonrightBMP.bitmap = LoadLSImage(StartButtonRight, NULL);
		GetLSBitmapSize(startbuttonrightBMP.bitmap, &startbuttonrightBMP.x, &startbuttonrightBMP.y);
		GetRCString("StartButtonSkin", StartButtonSkin, "", 256);
		startbuttonskinBMP.bitmap = LoadLSImage(StartButtonSkin, NULL);
		GetLSBitmapSize(startbuttonskinBMP.bitmap, &startbuttonskinBMP.x, &startbuttonskinBMP.y);
		GetRCString("TaskBarSkin", TaskbarSkin, "", 256);
		taskBMP.bitmap = LoadLSImage(TaskbarSkin, NULL);
		GetLSBitmapSize(taskBMP.bitmap, &taskBMP.x, &taskBMP.y);
		GetRCString("TaskButtonSkin", TaskbtnSkin, "", 256);
		taskbtnskinBMP[0].bitmap = LoadLSImage(TaskbtnSkin, NULL);
		GetLSBitmapSize(taskbtnskinBMP[0].bitmap, &taskbtnskinBMP[0].x, &taskbtnskinBMP[0].y);
		GetRCString("TaskButtonSkinActive", TaskbtnSkinActive, "", 256);
		taskbtnskinBMP[1].bitmap = LoadLSImage(TaskbtnSkinActive, NULL);
		GetLSBitmapSize(taskbtnskinBMP[1].bitmap, &taskbtnskinBMP[1].x, &taskbtnskinBMP[1].y);
		GetRCString("TaskButtonLeft", TaskbtnLeft, "", 256);
		taskbtnleftBMP[0].bitmap = LoadLSImage(TaskbtnLeft, NULL);
		GetLSBitmapSize(taskbtnleftBMP[0].bitmap, &taskbtnleftBMP[0].x, &taskbtnleftBMP[0].y);
		GetRCString("TaskButtonLeftActive", TaskbtnLeftActive, "", 256);
		taskbtnleftBMP[1].bitmap = LoadLSImage(TaskbtnLeftActive, NULL);
		GetLSBitmapSize(taskbtnleftBMP[1].bitmap, &taskbtnleftBMP[1].x, &taskbtnleftBMP[1].y);
		GetRCString("TaskButtonRight", TaskbtnRight, "", 256);
		taskbtnrightBMP[0].bitmap = LoadLSImage(TaskbtnRight, NULL);
		GetLSBitmapSize(taskbtnrightBMP[0].bitmap, &taskbtnrightBMP[0].x, &taskbtnrightBMP[0].y);
		GetRCString("TaskButtonRightActive", TaskbtnRightActive, "", 256);
		taskbtnrightBMP[1].bitmap = LoadLSImage(TaskbtnRightActive, NULL);
		GetLSBitmapSize(taskbtnrightBMP[1].bitmap, &taskbtnrightBMP[1].x, &taskbtnrightBMP[1].y);
		GetRCString("TaskTraySkin", TasktraySkin, "", 256);
		tasktrayskinBMP.bitmap = LoadLSImage(TasktraySkin, NULL);
		GetLSBitmapSize(tasktrayskinBMP.bitmap, &tasktrayskinBMP.x, &tasktrayskinBMP.y);
		GetRCString("TaskTrayLeft", TasktrayLeft, "", 256);
		tasktrayleftBMP.bitmap = LoadLSImage(TasktrayLeft, NULL);
		GetLSBitmapSize(tasktrayleftBMP.bitmap, &tasktrayleftBMP.x, &tasktrayleftBMP.y);
		GetRCString("TaskTrayRight", TasktrayRight, "", 256);
		tasktrayrightBMP.bitmap = LoadLSImage(TasktrayRight, NULL);
		GetLSBitmapSize(tasktrayrightBMP.bitmap, &tasktrayrightBMP.x, &tasktrayrightBMP.y);
		TaskbarNoTextShift = GetRCBool("TaskbarNoTextShift", TRUE);
		TaskbarNoSkinShift = GetRCBool("TaskbarNoSkinShift", TRUE);
    //}
	
    GetRCString("SystrayOrientation",(LPSTR)&tmpbuf,"bottomleft",128);
	param = strlwr(tmpbuf);
	if (strstr(param, "right")) { 
		sysTrayRight = 1;
	} else {
		if (strstr(param, "left")) {
			sysTrayRight = 0;
		}
	}
	if (strstr(param, "bottom")) {
		sysTrayBottom = 1;
	} else {
		if (strstr(param, "top")) {
			sysTrayBottom = 0;
		}
	}
	if (strstr(param, "vertical")) {
		sysTrayVertical = 1;
	} else {
		if (strstr(param, "horizontal")) {
			sysTrayVertical = 0;
		}
	}
    
    sysTrayWrap = GetRCInt("SystrayWrapCount", 1000);
	if (sysTrayWrap <= 0)
		sysTrayWrap = 1000;	// Don't wrap.
	sysTrayOffset = GetRCInt("SystrayOffset",0);
	
    {	// modules.ini section.
		/*char ini_path[256];
		char temp_string[32];
		
		wsprintf(ini_path, "%s\\modules.ini", lsPath);
		
		bAudioAutoplay = GetPrivateProfileInt
			( "DESKTOP", "AudioAutoplay", 1, ini_path );
		
		itoa( (int)bAudioAutoplay, temp_string, 10);
		WritePrivateProfileString
			( "DESKTOP", "AudioAutoplay", temp_string, ini_path );*/
    }
    return 0;
}