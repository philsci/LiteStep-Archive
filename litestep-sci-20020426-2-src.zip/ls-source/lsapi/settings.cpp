#include <windows.h>
#include <comdef.h>
//#include <string.h> // not needed for coordinate parser
#include "lsapi.h"
#include "../core/ifcs.h"

IStepSettings *g_settings;

// dll exports

__declspec(dllexport) void SetStepSettings(IStepSettings *stepsets)
{
	g_settings = stepsets;
	// should we AddRef or not? Hard to clean up in a dll...
}

FILE* LCOpen(LPCSTR szPath)
{
	return (FILE*)g_settings->GetIterator(_bstr_t(szPath));
}


BOOL LCClose (FILE *f)
{
	((IStepIterator*)f)->Release();

	return TRUE;
}


BOOL LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextLine();

	if (buffer != NULL)
	{

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else

		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	}
	else
	{
		SysFreeString(buffer);
		return FALSE;
	}
}


BOOL LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextConfig(_bstr_t(szPrefix));

	if (buffer != NULL)
	{

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else

		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	}
	else
	{
		SysFreeString(buffer);
		return FALSE;
	}
}


BOOL LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	IStepIterator *iter = (IStepIterator*)f;
	BSTR buffer = iter->NextLine();

	if (buffer != NULL)
	{

#ifdef _UNICODE
		wcsncpy(szBuffer, buffer, dwLength);
#else

		WideCharToMultiByte(CP_ACP, 0, buffer, SysStringLen(buffer) + 1, szBuffer, dwLength, NULL, NULL);
#endif

		SysFreeString(buffer);
		return TRUE;
	}
	else
	{
		SysFreeString(buffer);
		return FALSE;
	}
}

int _Tokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters, BOOL useBrackets)
{
	BSTR *tokens = new BSTR[dwNumBuffers];
	BSTR remainder;
	int count;

	count = g_settings->Tokenize(_bstr_t(szString), dwNumBuffers, tokens, &remainder, useBrackets);

	for (int i = 0; i < count; i++)
	{
		if (i < (int)dwNumBuffers)
		{
#ifdef _UNICODE
			wcscpy(lpszBuffers[i], tokens[i]);
#else

			WideCharToMultiByte(CP_ACP, 0, tokens[i], SysStringLen(tokens[i]) + 1, lpszBuffers[i], SysStringLen(tokens[i]) + 1, NULL, NULL);
#endif

		}

		SysFreeString(tokens[i]);
	}

	if (szExtraParameters != NULL)
	{
#ifdef _UNICODE
		wcscpy(szExtraParameters, remainder);
#else

		WideCharToMultiByte(CP_ACP, 0, remainder, SysStringLen(remainder) + 1, szExtraParameters, SysStringLen(remainder) + 1, NULL, NULL);
#endif

	}

	SysFreeString(remainder);
	delete [] tokens;

	return count;
}

int LCTokenize (LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
	return _Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, FALSE);
}

BOOL GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets)
{
	BSTR token;
	int index;
	BOOL result;

	result = g_settings->Token(_bstr_t(szString), &token, &index, useBrackets);

	if (index != NULL)
	{
		if (szNextToken != NULL)
		{
			// pointer to next token is original plus index times size of characters
			*szNextToken = szString + index * sizeof(char);
		}
	}
	else
	{
		if (szNextToken != NULL)
		{
			*szNextToken = NULL;
		}
	}

	if (szToken != NULL)
	{
#ifdef _UNICODE
		wcscpy(szToken, token);
#else

		WideCharToMultiByte(CP_ACP, 0, token, SysStringLen(token) + 1, szToken, SysStringLen(token) + 1, NULL, NULL);
#endif

	}

	SysFreeString(token);

	return result;
}

int CommandTokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
	return _Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, TRUE);
}

// Do NOT call this function directly, call MathEvaluate
double Eval(char* szInput)
{
	int nCount, nBlock = 0, nStart, nLen = (int)strlen(szInput);

	for(nCount = 0; nCount <= nLen; nCount++)
		if((szInput[nCount] == '(') && (++nBlock == 1))
			nStart = nCount;
		else if((szInput[nCount] == ')') && !--nBlock && !nStart && (nCount == nLen - 1)) //One pair of parentheses surrounding the whole expression
		{
			szInput[nCount] = 0;
			return Eval(szInput + 1);
		}

	char rcSign[4] = {'+', '-', '*', '/'};
	for(int nSign = 0; nSign < 4; nSign++)
		for(nCount = 0; nCount <= nLen; nCount++)
			if(szInput[nCount] == '(')
				nBlock++;
			else if(szInput[nCount] == ')')
				nBlock--;
			else if((szInput[nCount] == rcSign[nSign]) && !nBlock)
			{
				szInput[nCount] = 0;
				switch(nSign)
				{
				case 0: return Eval(szInput) + Eval(szInput + nCount + 1);
				case 1: return Eval(szInput) - Eval(szInput + nCount + 1);
				case 2: return Eval(szInput) * Eval(szInput + nCount + 1);
				case 3: return Eval(szInput) / Eval(szInput + nCount + 1);
				}
			}

	if(!stricmp(szInput, "pi")) return 3.1415926535897932384626433832795;
	else if(!stricmp(szInput, "true")) return 1;
	else if(!stricmp(szInput, "false")) return 0;

	return atof(szInput);
}

// Evaluates a mathematical expression
double MathEvaluate(const char* szInput)
{
	//_strdup ???
	char szBuffer[1024];
	int nBuffer = 0, nLen = (int)strlen(szInput);

	if(!strchr(szInput, ' ') && !strchr(szInput, '\t'))
		strcpy(szBuffer, szInput);
	else
		for(int nCount = 0; nCount <= nLen; nCount++)
			if((szInput[nCount] != ' ') && (szInput[nCount] != '\t'))
				szBuffer[nBuffer++] = szInput[nCount];


	return Eval(szBuffer);
}

int GetRCInt(LPCSTR szKeyName, int nDefault)
{
	char szVal[MAX_LINE_LENGTH];
	GetRCString(szKeyName, szVal, "", MAX_LINE_LENGTH);
	if(szVal[0])
		return (int)MathEvaluate(szVal);
	else
		return nDefault;

	//return g_settings->GetInt(_bstr_t(szKeyName), nDefault);
}


BOOL GetRCBool(LPCSTR szKeyName, BOOL ifFound)
{
	return g_settings->GetBool(_bstr_t(szKeyName), ifFound);
}


BOOL GetRCBoolDef(LPCSTR szKeyName, BOOL bDefault)
{
	return g_settings->GetBoolDef(_bstr_t(szKeyName), bDefault);
}


BOOL GetRCString(LPCSTR szKeyName, LPSTR szValue, LPCSTR defStr, int maxLen)
{
	BSTR value = g_settings->GetString(_bstr_t(szKeyName), _bstr_t(defStr));
	BOOL result = FALSE;

	if (value == NULL)
	{
		return result;
	}

	if (szValue != NULL)
	{
#ifdef _UNICODE
		wcsncpy(szValue, value, maxLen);
#else

		WideCharToMultiByte(CP_ACP, 0, value, SysStringLen(value) + 1, szValue, maxLen, NULL, NULL);
#endif

	}

	result = SysStringLen(value) > 0;

	SysFreeString(value);

	return result;
}

//own parser, inspired by label.dll:
int ParseCoordinate(LPSTR strVal, int defaultVal, int maxVal)
{
	int length = strlen(strVal);

	boolean negative = false;
	boolean center = false;
	boolean percentual = false;
	int value = 0;

	if(length == 0)
		return defaultVal;

	if(strVal[0] == '-')
	{
		negative = true;
		strVal[0] = '0'; // clear sign
	}
	
	if(strVal[length-1] == 'C' || strVal[length-1] == 'c')
	{
		center = true;
		strVal[length-1] = '\0'; // clear ending C
	}
	else if(strVal[length-1] == '%')
	{
		percentual = true;
		strVal[length-1] = '\0'; // clear ending C
	}

	//value = atoi(strVal); // convert remains to int
	value = (int)MathEvaluate(strVal); // convert remains to int

	if(center)
	{
		if(negative)
			value = (maxVal / 2) - value;
		else
			value = (maxVal / 2) + value;
	}
	else if (percentual) // percentual positioning ie 30% from left side, -30% to count from right
	{
		if (negative)
			value = maxVal*(1-value/100);
		else
			value = maxVal*value/100;
	}
	else if(negative)
	{
		value = maxVal - value;
	}

	return value;
}

// parser from label.dll, more elegant.
/*int ParseCoordinate(LPCSTR strVal, int defaultVal, int maxVal)
{
	int length = strlen(strVal);

	boolean negative = false;
	boolean center = false;
	int i = 0;
	int value = 0;

	if(length == 0)
		return defaultVal;

	if(strVal[i] == '-')
	{
		negative = true;
		i++;
	}
	else if(strVal[i] == '+')
	{
		i++;
	}

	while(i < length)
	{
		if(strVal[i] >= '0' && strVal[i] <= '9')
		{
			value = (value * 10) + (strVal[i] - '0');
		}
		else
		{
			if(strVal[i] == 'c' || strVal[i] == 'C')
				center = true;

			break;
		}

		i++;
	}

	if(center)
	{
		if(negative)
			value = (maxVal / 2) - value;
		else
			value = (maxVal / 2) + value;
	}
	else if(negative)
	{
		value = maxVal - value;
	}

	return value;
}*/

// retrieve a coordinate from step.rc, accounting for negative values and centering
int GetRCCoordinate(LPCSTR property, int defaultVal, int maxVal)
{
	char strVal[MAX_LINE_LENGTH];
	GetRCString(property, strVal, "", MAX_LINE_LENGTH);
	return ParseCoordinate(strVal, defaultVal, maxVal);
}

COLORREF GetRCColor(LPCSTR szKeyName, COLORREF colDef)
{
	return g_settings->GetColor(_bstr_t(szKeyName), colDef);
}


BOOL GetRCLine(LPCSTR szKeyName, LPSTR szBuffer, UINT nBufLen, LPCSTR szDefault)
{
	BSTR value = g_settings->GetLine(_bstr_t(szKeyName), _bstr_t(szDefault));
	BOOL result = FALSE;

	if (value == NULL)
	{
		return result;
	}

	if (szBuffer != NULL)
	{
#ifdef _UNICODE
		wcsncpy(szBuffer, value, nBufLen);
#else

		WideCharToMultiByte(CP_ACP, 0, value, SysStringLen(value) + 1, szBuffer, nBufLen, NULL, NULL);
#endif

	}

	result = SysStringLen(value) > 0;

	SysFreeString(value);

	return result;
}


void VarExpansion(char *buffer, const char * value)
{
	BSTR output = g_settings->VarExpansion(_bstr_t(value));

	if (buffer != NULL)
	{
#ifdef _UNICODE
		wcsncpy(buffer, output, nBufLen);
#else

		WideCharToMultiByte(CP_ACP, 0, output, SysStringLen(output) + 1, buffer, SysStringLen(output) + 1, NULL, NULL);
#endif

	}

	SysFreeString(output);
}

