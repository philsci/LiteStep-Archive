/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __SHORTCUT_H_
#define __SHORTCUT_H_

#include <map>
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"

using namespace std;


class Shortcut;

typedef map<UINT, Shortcut*> ShortcutMap;

class ShortcutFactory : public Window
{
protected:
  HWND fShortcutHints;
  ShortcutMap fShortcutGroups;
  LPSTR fSoundClick;
  LPSTR fSoundHover;
  bool fShowCaptions;
  bool fBangLock;

public:
  inline LPCSTR getSoundClick() { return fSoundClick; }
  inline LPCSTR getSoundHover() { return fSoundHover; }
  inline bool getShowCaptions() { return fShowCaptions; }

  ShortcutFactory(HWND parentWnd, int& code);
  ~ShortcutFactory();

  void relayHintMessage(HWND hWnd, Message& message);
  void addHint(HWND hWnd, LPSTR caption);
  void removeHint(HWND hWnd);

protected:
  void createShortcuts();
  void destroyShortcuts();

  void setVisible(LPCSTR groups, int state);
  void setTopMost(LPCSTR groups, int topMost);

  static void bangGroupToggle(HWND sender, LPCSTR args);
  static void bangGroupShow(HWND sender, LPCSTR args);
  static void bangGroupHide(HWND sender, LPCSTR args);
  static void bangGroupOnTop(HWND sender, LPCSTR args);
  static void bangGroupOnBottom(HWND sender, LPCSTR args);
  static void bangGroupOnTopToggle(HWND sender, LPCSTR args);

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onGetRevId(Message& message);
  void onRefresh(Message& message);
  void onSetTopmost(Message& message);
};

struct RegionImage
{
  HBITMAP image;
  HRGN region;
};


enum ShortcutState {ssNormal, ssHover, ssClick};

class Shortcut : public Window
{
protected:
  ShortcutFactory* fOwner;
  LPSTR fCaption;
  LPSTR fCommand;
  LPSTR fCommandArgs;
  LPSTR fNormalName;
  LPSTR fHoverName;
  LPSTR fClickName;
  LPSTR fHoverSound;
  LPSTR fClickSound;
  RegionImage* fRICurrent;
  RegionImage fRINormal;
  RegionImage fRIHover;
  RegionImage fRIClick;
  int fLeft;
  int fTop;
  POINT fRelOrigin;
  bool fLeftCenter;
  bool fTopCenter;
  int fWidth;
  int fHeight;
  ShortcutState fState;
  Shortcut* fNext;
  bool fChangeZOrder;
  bool fIsVisible;
  bool fIsTopMost;
  bool fIsOpaque;
  bool fShowCaption;
  UINT fLeaveTimer;
  HDC fPaintDC;

public:
  Shortcut(ShortcutFactory* owner, LPCSTR szConfigLine, DWORD& group);
  ~Shortcut();

  void append(Shortcut* shortcut);
  void setVisible(int visible);
  void setTopMost(int topMost);

protected:
  DWORD parseConfig(LPCSTR szLine);
  void createShortcut();
  void clear();
  void setImage(RegionImage& regionImage, bool reset);
  POINT convertCoords(const int left, const int top) const;

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onEndSession(Message& message);
  void onSysCommand(Message& message);
  void onMouseMove(Message& message);
  void onMouseActivate(Message& message);
  void onTimer(Message& message);
  void onLButtonDown(Message& message);
  void onLButtonUp(Message& message);
  void onDropFiles(Message& message);
  void onEraseBkgnd(Message& message);
  void onDisplayChange(Message& message);
  void onShowWindow(Message& message);
};


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif

