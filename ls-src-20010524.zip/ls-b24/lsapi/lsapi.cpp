/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************
2/19/01 - Chao-Kuo Lin (Chaku)
  - Fixed the functions GetResStr and GetResStrEx to load 
    string table resource properly

12/19/00 - Bobby G. Vinyard (Message)
  - Added following variables:
      $commonadmintoolsdir$
      All Users\Start Menu\Programs\Administrative Tools
      $admintoolsdir$
      <user name>\Start Menu\Programs\Administrative Tools
12/07/00 - Bobby G. Vinyard (Message)
  - Split some of the functions in lsapi.cpp off into different files to be more manageable.
  - Added multimonitor functions to lsapi (these are basically the same functions as those found in
    Microsoft's multimon.h)
  - Some general house cleaning of unused varaibles and code
12/04/00 - Bobby G. Vinyard (Message)
  - Turned off warning message when using ShellExecute via LsExecute, this will
    keep that annoying "access to the specified device, path, or file was denied"
    window from popping up
11/26/00 - Bobby G. Vinyard (Message)
  - Fixed Frame3D, it was swapping some coordinates
10/18/00 - Bobby G. Vinyard (Message)
  - Added two new variables ResolutionX and ResolutionX which is the screen height and
    width in pixels, not very usefull with the current if,else implementation, but
    provided for future use with expressions
10/14/00 - Bobby G. Vinyard (Message)
  - If a variable is a _tsystem variable (i.e. $windir$) it will now append a
    backslash to the variable, this should make all directory variables behave the
    same with a back slash now
10/03/00 - Joachim Calvert (NeXTer)
  - Changed GetRCBoolDef() to interpret the value as true if declared but not
    assigned a value, or assigned a value not recognized as a false
09/17/00 - Bobby G. Vinyard (Message)
  - Added ThemeName and ThemeAuthor to about box
08/31/00 - Joachim Calvert (NeXTer)
  - Altered the WM_POPUP message to pass both mouse coords in lParam
08/29/00 - Joachim Calvert (NeXTer)
  - Cleaned up GetRCColor() after the change to the settings caching
08/28/00 - Charles Oliver Nutter (Headius)
  - Rewrote the settings cache internally to avoid a flaw.
	  The flaw caused settings requested twice as different types to be cached
		and returned on calls after the first incorrectly
08/26/00 - Joachim Calvert (NeXTer)
  - Added the function BOOL GetRCBoolDef(LPCTSTR szKeyName, BOOL bDefault)
    If not found, or no value specified, it returns bDefault, otherwise it
    returns the value
08/24/00 - Joachim Calvert (NeXTer)
  - Changed LSGetImagePath() to work properly with the new caching _tsystem
08/23/00 - Joachim Calvert (NeXTer)
  - Changed LoadLSImage() so that it uses the correct path if LSImageFolder
    has been changed during a recycle
08/17/00 - Charles Oliver Nutter (Headius)
  - Added support for bang threading
08/17/00 - Joachim Calvert (NeXTer)
  - Changed GetRCColor() back to the old way. Whatever the problem was, the fix
    broke it...
08/16/00 - Charles Oliver Nutter (Headius)
  - Changed !RecycleStep to !Refresh and added the LM_REFRESH message to
    tell modules to update themselves
08/16/00 - Bobby G. Vinyard (Message)
  - Added !RecycleStep which clears the step.rc cache and reloads it with out 
    a hard recycle of litestep so now you can do this 
      !execute [!recyclestep][!reloadmodule $litestepdir$popup2.dll] 
    and changes made in the step.rc affecting only popup2.dll will take affect 
    without recycling all of litestep
08/14/00 - Gustav Munkby (grd)
	- Recoded BitmapToRegion, using a combination of the old and the new versions
	- Recoded TransparentBltLS and fixed:
	  a) issue that might have caused leakage or protection faults.
		b) implementation that would make TransparentBltLS cause flicker.
	- Experimental recoding of LoadLSIcon, might not be compatible with all modules
08/21/00 - Joachim Calvert (NeXTer)
  - Made !UnloadModule and !ReloadModule able to handle an unlimited number
    of modules. Each module should be enclosed in quotes to follow the
    recommendations for forward compatibility.
07/21/00 - Joachim Calvert (NeXTer)
  - Changed the parsing _tsystem to treat token"token" as a single token, to
	  make the use of older themes easier.
06/09/00 - Charles Oliver Nutter (Headius)
  - Added LitestepAPIInit function to initialized lsapi on startup
	- Added support for TransparentBlt to TransparentBltLS to speed up FF00FF-
	  style transparency
05/28/00 - Charles Oliver Nutter (Headius)
  - Added support for arbitrary .rc files to the .rc file caching mechanism
	- Wired the new CacheRCFile function into SetupRC and LCOpen so that files
	  could be loaded and cached in a lazy way - on request
	- Fixed stdcall/cdecl issue on bang commands
05/27/00 - Bobby G Vinyard (Message)
  - Fixed a memory leak in AddVariable, it was returning before deleting 
    lowerName
  - Fixed a memory leak in ParseBangCommand, was not deleting tempCommand if
    (FAILED(hr))
  - Removed all references to BangMap, !About bangs not functioning at this 
    time
05/23/00 - Joachim Calvert (NeXTer)
  - Due to popular demand, yesterdays syntax change is no longer in effect.
    GetRCColor() will assume hex for single values and dec for triplets.
  - However, GetRCInt() does, as of yesterday accept values in either octal,
    decimal or hexadecimal. (Examples: Oct: 0370, Dec: 42, Hex: 0xF0E1D2C3)
  - Fixed the problem with LSGetImagePath() where it wouldn't refresh the
    setting after updating step.rc. (Thanks to Jugg for pointing it out)
05/22/00 - Joachim Calvert (NeXTer)
  - Fixed Headius' use of vectors, since it caused a crash when built under
    BCB. Should also be marginally faster since it now also makes proper
    use of iterators.
  - Also tweaked the GetRCxxx functions a bit. Bools can now be turned off with
    either off, false and no.
  - GetRCColor() now accepts color values as either a single value or a
    triplet in the bases octal, decimal and hexadecimal. All values default to
    decimal, so if you want hex, begin the value with 0x (zero x-ray), or just
    0 (zero) for octal. (Examples: 1241245, 0x00FF8040, 255 0 0, 020 030 040)
05/12/00 - Joachim Calvert (NeXTer)
  - Tweaked the parsers a bit
05/12/00 - Charles Oliver Nutter (Headius)
  - changed RCBuffer, ThemeBuffer, and PicBuffer to use a vector internally
04/26/00 - Joachim Calvert (NeXTer)
  - Now clears all evars on recycle.
04/25/00 - Bret Anderson (MrJukes)
  - Replaced BitmapToRegion() with a streamlined version.
04/23/00 - Joachim Calvert (NeXTer)
  - Various fixes to the parsing _tsystem. GetToken() is now exported.
04/22/00 - Joachim Calvert (NeXTer)
  - Swapped the argument names for LoadLSImage() so they represent the correct
    data  
04/21/00 - Joachim Calvert (NeXTer)
  - Fixed UniversalTokenize(): didn't clear the passed strings like it should.
04/19/00 - Joachim Calvert (NeXTer)
  - Merged LCTokenize() and CommandTokenize() into a single function, both
    remain for compatibility reasons.
04/18/00 - Joachim Calvert (NeXTer)
  - Added LS_GWL_CLASSPOINTER to lsapi.h to simplify the creation of classbased
    modules. More along these lines are to be expected in the future.
  - Rewrote CommandParse() from scratch. CommandTokenize() will follow shortly.
04/17/00 - Joachim Calvert (NeXTer)
  Fixed the problem with passing NULL as the argument to ParseBangCommand().
  Also fixed a memory leak in the same function, for good measure.
04/17/00 - Joachim Calvert (NeXTer)
  Merged new code for merging images in LoadLSImage(). Thank's to
  Gustav Munkby (grd) for the new code.
  Removed some old junk.
  Added the struct Message for passing messages from the WndProc to the
  actual message handlers.
04/16/00 - Bobby G. Vinyard (Message)
  Fixed popups displaying in upper left hand corner in certain cases
04/14/00 - Bobby G. Vinyard (Message)
  Fixed a variable redefinition error in GetRCString
  Uncommented _LMBANGCOMMANDA in lsapi.h, this was used in litestep.cpp for
    the prupose of allowing none litestep modules to run litestep bang commands
04/15/00 - Joachim Calvert (NeXTer)
  Reworked the setupVars() function, and added more definitions.
04/14/00 - Joachim Calvert (NeXTer)
  Added StripComment() to make LCReadNextLine() _tremove comments from the
  lines. This saves some time, and also allows Messy's modification
  work with lines containing comments.
04/14/00 - Bobby G. Vinyard (Message)
  Changed GetRCString() to return the whole line instead of only the first
    token.
04/14/00 - Joachim Calvert (NeXTer)
  Some general cleaning of the code, some redundant code commented out
    until we know everything works without it.
04/14/00 - Bobby G. Vinyard (Message)
  Wasn't allowing modules to redefine bangs (e.g. sysvwm & lsvwm redefined
    !vwmleft..etc)
04/13/00 - Bobby G. Vinyard (Message)
  Bang commands now stored in a stl map structure
  Rewrote AddBangCommand, AddBangCommandEx, ParseBangCommand, RemoveBangCommand
  Change BangAbout to use the new map when displaying bang commands
  Added setupBangs called in litestep startup to register lsapi bangs
  Fixed GetRCString on returning the full line in the step if it was all qouted
    now                   SetDesktopLeftClick !popup x=0 y=0
    will work the same as SetDesktopLeftClick "!popup x=0 y=0"
04/13/00 - Joachim Calvert (NeXTer)
  Rewrote the LCTokenize() function from scratch, it's mow less than half
  the size of the original (I must've missed something important ;) ).
04/11/00 - Joachim Calvert (NeXTer)
  Fixed the LSReadNextConfig() function not recognizing tabs as a valid
  whitespace.
  Fixed a leak in LSExecuteEx().
04/08/00 - Bobby G. Vinyard. (Message)
  Added VarExpansion to ParseBangCommand (now when a third party module, i.e.
    lsxcommand, sends a bang command to be parsed, variables will be expanded.
    e.g. previously you had to do !unloadmodule c:\litestep\modules\systray.dll,
    now you should be able to do !unloadmodule %moduledir%systray.dll, or
    something similiar)
  Reimplemented !about, !about detailed
  Added !about bangs, will display all registered bang commands
  Changed About dialog to use a listbox instead of a textbox (modules will be
    unaffected by this change)
  Changed !popup to take coordinates to display the popup (e.g. !popup x=0 y=0)
03/12/00 - Bobby G. Vinyard. (Message)
  Fixed lsapi crashing with an undeclared variable (envvar was being set to NULL,
    and then was being added to the map)
  Added MessageBox warning if lsapi finds an unitialized variable, will tell the 
    variable, and the line
03/05/00 - Bobby G. Vinyard. (Message)
  Added $litestepdir$ variable
03/04/00 - Joachim Calvert
  Changed Messy's routines to use all lowercase for variable names, to
    avoid conflicting declarations.
03/04/00 - Bobby G. Vinyard. (Message)
  Added variable caching to litestep step.rc variables, and added support
    for predefinedvariables to common window paths.
02/18/00 - Bobby G. Vinyard. (Message)
  Removed the EasterEgg Bang declaration =P
18/01/00 - Joachim Calvert aka NeXTer
  Removed the EasterEgg bang, since it's never done anything but crash LS.
11/04/99 - Adrian Heath
  Added function to _tremove bang commands to allow unloading of modules
  Also changed the AddBangCommand to cope with reloading a bang command
    for old modules.
  Added two new BangCommands that Load/Unload Modules.  These simply send
    a message to LiteStep.exe giving the module name
12/10/98 - Fahim Farook
  Added code by Thedd to facilitate bitmap merging so that you can
    specify more than one image separated by the "|" symbol
11/11/98 - Fahim Farook
  Added a new function called GetLSBitmapSize to replace the old
  GetBitmapSize in popups as C has a similar function and because
    taskbar skinning added by Thedd uses the same function as well
07/11/98 - Fahim Farook
  Added a dialog box to show version information
31/10/98 - Fahim Farook
  Added a function for loading and/or extracting icon files
15/10/98 - B. Kilian
  Added the pattern matching stuff in.
15/09/98 - J. Vaughn
  Added Bang commands for the VWM, and ability to give params
    to the command.
31/08/98 - D. Hodgkiss
  Added TransparentBltLS command
25/08/98 - D. Hodgkiss
  This file contains the source for general functions
    that can be called by core modules

****************************************************************************/

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings
#include <time.h>
#include <stdio.h>
#include <tchar.h>
#include <crtdbg.h>
#include <windows.h>
#include <shlobj.h>
#include <comutil.h>
#include <vector>
#include <map>
#include <string>
#include "../core/ifcs.h"
#include "ThreadedBangCommand.h"
//#include "StepSettings.h"
#include "lsapi.h"
#include "safestr.h"
#include "macros.h"
#include "bangs.h"
#include "match.h"

using namespace std;

struct tThemePic
{
  _TCHAR program[255];
  _TCHAR bitmap[255];
};

extern const _TCHAR rcsRevision[];
const _TCHAR rcsRevision[] = "$Revision: 1.53.2.74 $"; // Our Version
const _TCHAR rcsId[] = "$Id: lsapi.cpp,v 1.53.2.74 2001/03/11 02:22:35 headius Exp $"; // The Full RCS ID.

typedef vector<tThemePic*> ThemePicVector;

ThemePicVector PicBuffer;

#define WHITESPACE _TEXT(" \t\n\r")

bool usingTheme;
extern IStepSettings *g_settings;
DWORD g_main_thread;

HWND hwndLiteStep = NULL;

CHAR szAppPath[256], szRcPath[256];

static IBangManager *globalBangManager = NULL;

// TransparentBlt API call for 98 and 2k
//typedef WINGDIAPI BOOL  (WINAPI *TRANSPARENTBLT)(HDC,int,int,int,int,HDC,int,int,int,int,UINT);
//TRANSPARENTBLT TransBlt = NULL;


BOOL DLLMain(HINSTANCE hinst, DWORD reason, LPVOID) {
	if (reason == DLL_PROCESS_ATTACH) {
	}

	return TRUE;
}


void LitestepAPIInit() {
	//if (!TransBlt) {
	//	TransBlt = (TRANSPARENTBLT)GetProcAddress(LoadLibrary("msimg32.dll"), "TransparentBlt");
	//}
  
	// Create a settings object to use
  //g_settings = new StepSettings();

	// Only the _tmain thread should call LitestepAPIInit, save that thread ID
	g_main_thread = GetCurrentThreadId();
}


// A shortcut to speed up debugging
//*
int Pause(LPCTSTR msg)
{
  return MessageBox(NULL, msg, "LiteStep", MB_ICONEXCLAMATION | MB_TOPMOST);
}
//*/


BOOL GetShellFolderPath(int nFolder, LPTSTR szPath)
{
	LPITEMIDLIST pidl;
	IMalloc *pMalloc;
	HRESULT hr;
	BOOL fResult = FALSE;

	hr = SHGetSpecialFolderLocation(NULL, nFolder, &pidl);

	if(SUCCEEDED(hr))
	{
		fResult = SHGetPathFromIDList(pidl, szPath);

		if(fResult)
			lstrcat(szPath, TEXT("\\"));
	}

	if(SUCCEEDED(SHGetMalloc(&pMalloc)))
	{
		pMalloc->Free(pidl);
		pMalloc->Release();
	}

	return fResult;
}

#if !defined(CSIDL_COMMON_ADMINTOOLS)
#define CSIDL_COMMON_ADMINTOOLS 0x002F
#define CSIDL_ADMINTOOLS 0x0030
#endif

void setupVars(LPCTSTR szLSPath)
{
  _TCHAR szTemp[MAX_PATH];
  DWORD dwLength = MAX_PATH;

  StrCopy(szAppPath, szLSPath);
  StrCopy(szTemp, szLSPath);
  _tcscat(szTemp, "\\");
  g_settings->SetVariable(_bstr_t("litestepdir"), _bstr_t(szTemp));
  szTemp[0] = 0;
  GetUserName(szTemp, &dwLength);
  g_settings->SetVariable(_bstr_t("username"), _bstr_t(szTemp));
  g_settings->SetVariable(_bstr_t("bitbucket"), _bstr_t("::{645FF040-5081-101B-9F08-00AA002F954E}"));
  g_settings->SetVariable(_bstr_t("documents"), _bstr_t("::{450D8FBA-AD25-11D0-98A8-0800361B1103}"));
  g_settings->SetVariable(_bstr_t("drives"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"));
  g_settings->SetVariable(_bstr_t("network"), _bstr_t("::{208D2C60-3AEA-1069-A2D7-08002B30309D}"));
  g_settings->SetVariable(_bstr_t("controls"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{21EC2020-3AEA-1069-A2DD-08002B30309D}"));
  g_settings->SetVariable(_bstr_t("dialup"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{992CFFA0-F557-101A-88EC-00DD010CCC48}"));
  g_settings->SetVariable(_bstr_t("networkanddialup"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{7007ACC7-3202-11D1-AAD2-00805FC1270E}"));
  g_settings->SetVariable(_bstr_t("printers"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{2227A280-3AEA-1069-A2DE-08002B30309D}"));
  g_settings->SetVariable(_bstr_t("scheduled"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{D6277990-4C6A-11CF-8D87-00AA0060F5BF}"));
  g_settings->SetVariable(_bstr_t("admintools"), _bstr_t("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{21EC2020-3AEA-1069-A2DD-08002B30309D}\\::{D20EA4E1-3957-11d2-A40B-0C5020524153}"));
  // GetShellFolderPath(CSIDL_BITBUCKET, szPath);
  // AddVariable("bitbucket", szPath);
  GetShellFolderPath(CSIDL_COMMON_DESKTOPDIRECTORY, szTemp);
  g_settings->SetVariable(_bstr_t("commondesktopdir"), _bstr_t(szTemp));
  // GetShellFolderPath(CSIDL_COMMON_DOCUMENTS, szPath);
  // AddVariable("commondocuments", szPath);
  GetShellFolderPath(CSIDL_COMMON_FAVORITES, szTemp);
  g_settings->SetVariable(_bstr_t("commonfavorites"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_COMMON_PROGRAMS, szTemp);
  g_settings->SetVariable(_bstr_t("commonprograms"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_COMMON_STARTMENU, szTemp);
  g_settings->SetVariable(_bstr_t("commonstartmenu"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_COMMON_STARTUP, szTemp);
  g_settings->SetVariable(_bstr_t("commonstartup"), _bstr_t(szTemp));
  // GetShellFolderPath(CSIDL_CONTROLS, szTemp);
  // SetVariable(_bstr_t("controls"), _bstr_t(szTemp);
  GetShellFolderPath(CSIDL_COOKIES, szTemp);
  g_settings->SetVariable(_bstr_t("cookies"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_DESKTOP, szTemp);
  g_settings->SetVariable(_bstr_t("desktop"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_DESKTOPDIRECTORY, szTemp);
  g_settings->SetVariable(_bstr_t("desktopdir"), _bstr_t(szTemp));
  // GetShellFolderPath(CSIDL_DRIVES, szTemp);
  // SetVariable(_bstr_t("drives"), _bstr_t(szTemp);
  GetShellFolderPath(CSIDL_FAVORITES, szTemp);
  g_settings->SetVariable(_bstr_t("favorites"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_FONTS, szTemp);
  g_settings->SetVariable(_bstr_t("fonts"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_HISTORY, szTemp);
  g_settings->SetVariable(_bstr_t("history"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_INTERNET, szTemp);
  g_settings->SetVariable(_bstr_t("internet"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_INTERNET_CACHE, szTemp);
  g_settings->SetVariable(_bstr_t("internetcache"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_NETHOOD, szTemp);
  g_settings->SetVariable(_bstr_t("nethood"), _bstr_t(szTemp));
  // GetShellFolderPath(CSIDL_NETWORK, szTemp);
  // AddVariable("network", szTemp);
  GetShellFolderPath(CSIDL_PERSONAL, szTemp);
  g_settings->SetVariable(_bstr_t("documentsdir"), _bstr_t(szTemp));
  // GetShellFolderPath(CSIDL_PRINTERS, szTemp);
  // AddVariable("printers", szTemp);
  GetShellFolderPath(CSIDL_PRINTHOOD, szTemp);
  g_settings->SetVariable(_bstr_t("printhood"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_PROGRAMS, szTemp);
  g_settings->SetVariable(_bstr_t("programs"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_RECENT, szTemp);
  g_settings->SetVariable(_bstr_t("recent"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_SENDTO, szTemp);
  g_settings->SetVariable(_bstr_t("sendto"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_STARTMENU, szTemp);
  g_settings->SetVariable(_bstr_t("startmenu"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_STARTUP, szTemp);
  g_settings->SetVariable(_bstr_t("startup"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_TEMPLATES, szTemp);
  g_settings->SetVariable(_bstr_t("templates"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_COMMON_ADMINTOOLS, szTemp);
  g_settings->SetVariable(_bstr_t("commonadmintoolsdir"), _bstr_t(szTemp));
  GetShellFolderPath(CSIDL_ADMINTOOLS, szTemp);
  g_settings->SetVariable(_bstr_t("admintoolsdir"), _bstr_t(szTemp));

	// OS variables
	OSVERSIONINFO verInfo;
	verInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&verInfo);

	if(verInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
	{
		if(verInfo.dwMinorVersion >= 90) // Windows ME (4.90)
			g_settings->SetVariable(_bstr_t("WinME"), _bstr_t("true"));
		else if(verInfo.dwMinorVersion >= 10) // Windows 98 (4.10)
			g_settings->SetVariable(_bstr_t("Win98"), _bstr_t("true"));
		else // Windows 95 (4.00)
			g_settings->SetVariable(_bstr_t("Win95"), _bstr_t("true"));

		// Any Win9x-series OS
		g_settings->SetVariable(_bstr_t("Win9x"), _bstr_t("true"));
	}
	else if(verInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)
	{
		if(verInfo.dwMajorVersion >= 5) // Windows 2000 (5.0)
			g_settings->SetVariable(_bstr_t("Win2000"), _bstr_t("true"));
		else if(verInfo.dwMajorVersion >= 4) // Windows NT 4.0
			g_settings->SetVariable(_bstr_t("WinNT4"), _bstr_t("true"));

		// Any WinNT-series OS
		g_settings->SetVariable(_bstr_t("WinNT"), _bstr_t("true"));
	}

	// screen resolution
	_TCHAR buffer[8];

	wsprintf(buffer, "%d", GetSystemMetrics(SM_CXSCREEN));
	g_settings->SetVariable(_bstr_t("ResolutionX"), _bstr_t(buffer));

	wsprintf(buffer, "%d", GetSystemMetrics(SM_CYSCREEN));
	g_settings->SetVariable(_bstr_t("ResolutionY"), _bstr_t(buffer));
}

BOOL SetupRC(LPCTSTR szPath)
{
	StrCopy(szRcPath, szPath);
	
	// parse the step.rc file
	g_settings->ParseFile(_bstr_t(szPath));
	
	// Modified - Maduin, 10-20-1999
	//   Accept both ThemeFile and LSThemeFile to facilitate
	//   greater backwards compatibility.  
	BSTR buffer = g_settings->GetString(_bstr_t("LSThemeFile"), _bstr_t(""));
	if(SysStringLen(buffer) == 0) {
		SysFreeString(buffer);
		buffer = g_settings->GetString(_bstr_t("ThemeFile"), _bstr_t(""));
	}
	
	if (SysStringLen(buffer) > 0) {
		BSTR theme = g_settings->ParseFile(buffer);
		SysFreeString(buffer);
		
		if (SysStringLen(theme) > 0) {
			usingTheme = true;
		}
		
		// Get Pics from theme for picbuffer
		IStepIterator *iter = g_settings->GetIterator(theme);
		
		buffer = iter->NextConfig(_bstr_t("*ThemePic"));
		while (SysStringLen(buffer) > 0) { // check for empty string
			BSTR token2;
			BSTR token3;
			BSTR tokens[3];
			BSTR remainder;
			int blah = 0, count;
			
			count = g_settings->Tokenize(buffer, 3, tokens, &remainder, FALSE);
			if (count < 3)
				continue;
			
			token2 = tokens[1];
			token3 = tokens[2];
			
			if (is_valid_pattern(_bstr_t(token2), &blah))
			{
				tThemePic *pPic = new tThemePic;
				StrLCopy(pPic->program, _bstr_t(token2), 255);
				StrLCopy(pPic->bitmap, _bstr_t(token3), 255);
				PicBuffer.push_back(pPic);
			}
			
			SysFreeString(buffer);
			SysFreeString(tokens[0]);
			SysFreeString(tokens[1]);
			SysFreeString(tokens[2]);
		}
		
		iter->Release();
	}
	
	return TRUE;
}


void CloseRC(void)
{
  g_settings->Clear();

  if (PicBuffer.size())
  {
	  ThemePicVector::iterator iter = PicBuffer.begin();
	  while (iter != PicBuffer.end())
	  {
		  delete *iter;
		  iter++;
	  }
	  PicBuffer.clear();
  }
}



void SetBangManager(void *bangman) {
	if (globalBangManager == NULL) {
		globalBangManager = (IBangManager*)bangman;
		globalBangManager->AddRef();
	}
}

void ClearBangManager() {
	if (globalBangManager != NULL) {
		globalBangManager->Release();
		globalBangManager = NULL;
	}
}

BOOL AddBangCommand(LPCTSTR command, BangCommand f)
{
	DWORD thread_id = GetCurrentThreadId();

  int length = StrLen(command);
  wchar_t* tempCommand = new wchar_t[StrLen(command) + 1];
  MultiByteToWideChar(CP_ACP, 0, command, length + 1, tempCommand, length + 1);
  wcslwr(tempCommand);

  IUnknown *unk = new ThreadedBangCommand(thread_id, f);
  IBangCommand *bang;
  unk->QueryInterface(IID_IBangCommand, (void**)&bang);

  BSTR comm = SysAllocString(tempCommand);
  globalBangManager->AddBangCommand(comm, bang);
  SysFreeString(comm);

  delete[] tempCommand;
  return true;
}


BOOL AddBangCommandEx(LPCTSTR command, BangCommandEx f) // Killarny
{
	DWORD thread_id = GetCurrentThreadId();

  int length = StrLen(command);
  wchar_t* tempCommand = new wchar_t[StrLen(command) + 1];
  MultiByteToWideChar(CP_ACP, 0, command, length + 1, tempCommand, length + 1);
  wcslwr(tempCommand);

  IUnknown *unk = new ThreadedBangCommand(thread_id, f, tempCommand);
  IBangCommand *bang;
  unk->QueryInterface(IID_IBangCommand, (void**)&bang);

  BSTR comm = SysAllocString(tempCommand);
  globalBangManager->AddBangCommand(comm, bang);
  SysFreeString(comm);
  
  delete[] tempCommand;
  return true;
}


BOOL RemoveBangCommand(LPCTSTR command)
{
  BOOL result;

  int length = StrLen(command);
  wchar_t* tempCommand = new wchar_t[StrLen(command) + 1];
  MultiByteToWideChar(CP_ACP, 0, command, length + 1, tempCommand, length + 1);
  wcslwr(tempCommand);

  BSTR comm = SysAllocString(tempCommand);
  result = globalBangManager->RemoveBangCommand(_bstr_t(tempCommand));
  SysFreeString(comm);

  delete[] tempCommand;

  return result;
}


BOOL ParseBangCommand(HWND caller, LPCTSTR command, LPCTSTR args)
{
  BSTR szTempBuffer = NULL;
  wchar_t* tempCommand;
  wchar_t* tempArgs = NULL;
  BOOL result = false;
  int length;

  if (!command)
    return result;

  length = StrLen(command);
  tempCommand = new wchar_t[length + 1];
  MultiByteToWideChar(CP_ACP, 0, command, length + 1, tempCommand, length + 1);
  wcslwr(tempCommand);

  if (args) {
	  length = StrLen(args);
	  tempArgs = new wchar_t[length + 1];
	  MultiByteToWideChar(CP_ACP, 0, args, length + 1, tempArgs, length + 1);
	  szTempBuffer = g_settings->VarExpansion(tempArgs);
  }

  BSTR comm = SysAllocString(tempCommand);
  result = globalBangManager->ExecuteBangCommand(comm, (OLE_HANDLE)caller, szTempBuffer);
  SysFreeString(comm);
  if (szTempBuffer) {
	  SysFreeString(szTempBuffer);
  }

  delete [] tempCommand;
  if (tempArgs) {
	  delete [] tempArgs;
  }

  return result;
}

void CommandParse(LPCTSTR cmd, LPTSTR cmdBuf, LPTSTR argsBuf, DWORD dwCmdBufSize, DWORD dwArgsBufSize)
{
  _TCHAR command[MAX_LINE_LENGTH];
  _TCHAR* tempCommand;
  LPCTSTR tempArgs;

  if (cmdBuf)
    cmdBuf[0] = '\0';
  if (argsBuf)
    argsBuf[0] = '\0';
  if (!cmd)
    return;

  VarExpansion(command, cmd);

  tempCommand = new _TCHAR[MAX_LINE_LENGTH];

  GetToken(command, tempCommand, &tempArgs, true);

  if (cmdBuf)
    StrLCopy(cmdBuf, tempCommand, dwCmdBufSize);
  if (argsBuf)
    StrLCopy(argsBuf, tempArgs, dwArgsBufSize);

  delete[] tempCommand;
}

HINSTANCE LSExecuteEx(HWND Owner, LPCTSTR szOperation, LPCTSTR szCommand, LPCTSTR szArgs, LPCTSTR szDirectory, int nShowCmd)
{
  DWORD type;
  SHELLEXECUTEINFO si;
  _TCHAR *cmd, *args;
  HINSTANCE result;

  if (!StrLen(szCommand))
    return HINSTANCE(32);

  if(*szCommand == '!')
  {
    cmd = new _TCHAR[StrLen(szCommand) + 1];
    args = new _TCHAR[StrLen(szArgs) + 1];
    StrCopy(cmd, szCommand);
    StrCopy(args, szArgs);
    result = ParseBangCommand(Owner, cmd, args) ? HINSTANCE(33) : HINSTANCE(32);
    delete[] cmd;
    delete[] args;
    return result;
  }
  else
  {
    type = GetFileAttributes(szCommand);
    if(type & FILE_ATTRIBUTE_DIRECTORY && type != 0xFFFFFFFF)
      return ShellExecute(Owner, szOperation, szCommand, szArgs, NULL, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    else
    {
      memset(&si, 0, sizeof(si));
      si.cbSize = sizeof(SHELLEXECUTEINFO);
      si.hwnd = Owner;
      si.lpVerb = szOperation;
      si.lpFile = szCommand;
      si.lpParameters = szArgs;
      si.lpDirectory = szDirectory;
      si.nShow = nShowCmd;
      si.fMask = SEE_MASK_DOENVSUBST | SEE_MASK_FLAG_NO_UI;
      ShellExecuteEx(&si);
      return si.hInstApp;
      //return (HINSTANCE)GetLastError();
    }
  }
}


HINSTANCE LSExecute(HWND Owner, LPCTSTR szCommand, int nShowCmd)
{
  _TCHAR command[MAX_LINE_LENGTH];
  _TCHAR newCmd[MAX_LINE_LENGTH];
  LPCTSTR args;
  _TCHAR dir[_MAX_DIR];
  _TCHAR full_directory[_MAX_DIR + _MAX_DRIVE + 1];
  HINSTANCE val = (HINSTANCE)(-1);

  if (!(szCommand && szCommand[0]))
    return HINSTANCE(32);

  VarExpansion(command, szCommand);

  if (GetToken(command, newCmd, &args, true))
  {
	int length = lstrlen(command);
	if(args > (command + length)) args = 0;

    if(newCmd[0] == '!')
      val = LSExecuteEx(Owner, NULL, newCmd, args, NULL, 0);
    else
    {
      _tsplitpath(newCmd, full_directory, dir, NULL, NULL);
      _tcscat(full_directory, dir);
      val = LSExecuteEx(Owner, "open", newCmd, args, full_directory, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    }
  }

  return val;
}

void CheckTheme(_TCHAR *szImage, LPCTSTR szFile)
{
  _TCHAR filename[MAX_PATH];
  ThemePicVector::iterator iter;

  if (PicBuffer.size() && szFile)
  {
    StrCopy(filename, szFile);

    for (iter = PicBuffer.begin(); iter != PicBuffer.end(); iter++)
    {
      if (match((*iter)->program, filename))
      {
        StrCopy(szImage, (*iter)->bitmap);
        return;
      }
    }
  }
}

void SetDesktopArea(int left, int top, int right, int bottom) {
  RECT r;

  r.left = left;
  r.top = top;
  r.right = right;
  r.bottom = bottom;
  SystemParametersInfo(SPI_SETWORKAREA, 0, (PVOID)&r, SPIF_SENDCHANGE);
  SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)&r, SPIF_SENDCHANGE);
}


HWND GetLitestepWnd()
{
  if (!hwndLiteStep)
    hwndLiteStep = FindWindow("TApplication", "LiteStep");
  return hwndLiteStep;
}


void GetResStr(HINSTANCE hInstance, UINT uIDText, LPTSTR szText, int len, LPCTSTR szDefText)
{
	//0 length == failed
	if(LoadString(hInstance, uIDText, szText, len) == 0)
		_tcsnccpy(szText,szDefText, len);
}


void GetResStrEx(HINSTANCE hInstance, UINT uIDText, LPTSTR szText, int len, LPCTSTR szDefText, ...)
{
	_TCHAR szFormat[MAX_LINE_LENGTH+1];
	va_list vargs;

	GetResStr(hInstance, uIDText, szFormat, MAX_LINE_LENGTH, szDefText);
	
	va_start (vargs,szDefText);
	_vstprintf (szText, szFormat, vargs);
	va_end (vargs);

}


// Added - Maduin, 10-20-1999
//   Helper function to retrieve the directory in which
//   LITESTEP.EXE resides.

BOOL WINAPI LSGetLitestepPath( LPTSTR pszPath, UINT nMaxLen )
{
	static TCHAR szPath[MAX_PATH] = "";

	if( !szPath[0] )
	{
		HINSTANCE hInstance;
		int nLen;

		hInstance = (HINSTANCE) GetWindowLong( GetLitestepWnd(), GWL_HINSTANCE );
		GetModuleFileName( hInstance, szPath, MAX_PATH );
		nLen = lstrlen( szPath ) - 1;

		while( nLen > 0 && szPath[nLen] != '\\' )
			nLen--;

		szPath[nLen + 1] = 0;
	}

	lstrcpyn( pszPath, szPath, nMaxLen );
	return TRUE;
}


// Added - Maduin, 10-20-1999
//   Function added to prevent modules from querying
//   for the LSImageFolder (PixmapPath) command using
//   GetRCString directly.

BOOL WINAPI LSGetImagePath( LPTSTR pszPath, UINT nMaxLen )
{
	TCHAR szPath[MAX_PATH] = "";

  if (!GetRCString(TEXT("LSImageFolder"), szPath, TEXT(""), MAX_PATH))
	{
    if (!GetRCString(TEXT("PixmapPath"), szPath, TEXT(""), MAX_PATH))
		{
			LSGetLitestepPath(szPath, MAX_PATH);

			if (szPath[0])
				lstrcat( szPath, TEXT("images\\") );
		}
	}

	if (szPath[0] && (szPath[lstrlen( szPath ) - 1] != '\\'))
		lstrcat(szPath, TEXT("\\"));

	lstrcpyn(pszPath, szPath, nMaxLen);
	return szPath[0];
}


/*
  $Log: lsapi.cpp,v $
  Revision 1.53.2.74  2001/03/11 02:22:35  headius
  see changes.txt, Headius, 3-10-01

  Revision 1.53.2.73  2001/03/02 04:44:35  maduin
  *** empty log message ***

  Revision 1.53.2.72  2001/02/20 16:14:16  headius
  Fixed call to bang manager that cause access violation

  Revision 1.53.2.71  2001/02/19 18:44:19  Chaku


  see changes.txt

  Revision 1.53.2.70  2001/02/18 23:31:18  headius
  added localization strings for modules and core

  Revision 1.53.2.69  2001/02/06 21:42:14  headius
  *** empty log message ***

  Revision 1.53.2.68  2001/02/05 23:03:24  headius
  see changes.txt, Headius 2001/02/05

  Revision 1.53.2.67  2001/02/05 00:35:15  headius
  see changes.txt, Headius, 2-4-01

  Revision 1.53.2.66  2001/01/31 23:34:50  headius
  see changes.txt, Headius, 1-31-2001

  Revision 1.53.2.65  2001/01/31 19:53:19  headius
  working on stepsettings

  Revision 1.53.2.64  2001/01/21 00:19:37  message
  *** empty log message ***

  Revision 1.53.2.63  2001/01/20 03:23:36  message
  *** empty log message ***

  Revision 1.53.2.62  2000/12/20 01:35:44  maduin
  *** empty log message ***

  Revision 1.53.2.61  2000/12/19 07:17:50  message
  *** empty log message ***

  Revision 1.53.2.60  2000/12/09 04:43:51  message
  *** empty log message ***

  Revision 1.53.2.59  2000/12/06 14:29:26  message
  *** empty log message ***

  Revision 1.53.2.58  2000/12/05 02:27:55  message
  *** empty log message ***

  Revision 1.53.2.57  2000/11/28 04:39:08  message
  *** empty log message ***

  Revision 1.53.2.56  2000/11/27 02:35:09  message
  *** empty log message ***

  Revision 1.53.2.55  2000/11/23 03:08:08  message
  *** empty log message ***

  Revision 1.53.2.54  2000/11/20 00:35:47  maduin
  Added !alert and !confirm

  Revision 1.53.2.53  2000/11/17 16:42:25  NeXTer
  See changes.txt

  Revision 1.53.2.52  2000/11/07 00:53:02  NeXTer
  Fixed a naming error

  Revision 1.53.2.51  2000/11/06 12:43:26  NeXTer
  See changes.txt

  Revision 1.53.2.50  2000/10/19 07:54:57  maduin
  *** empty log message ***

  Revision 1.53.2.49  2000/10/19 04:21:43  maduin
  *** empty log message ***

  Revision 1.53.2.48  2000/10/19 03:49:07  message
  *** empty log message ***

  Revision 1.53.2.47  2000/10/18 14:38:15  maduin
  Added conditionals (If, etc)

  Revision 1.53.2.46  2000/10/15 03:27:40  message
  *** empty log message ***

  Revision 1.53.2.45  2000/10/03 15:44:30  NeXTer
  See changes.txt

  Revision 1.53.2.44  2000/09/18 04:11:22  message
  ThemeName and ThemeAuthor finished

  Revision 1.53.2.43  2000/09/04 05:57:38  headius
  *** empty log message ***

  Revision 1.53.2.42  2000/08/31 21:31:38  NeXTer
  See changes.txt

  Revision 1.53.2.41  2000/08/29 20:05:54  NeXTer
  See changes.txt

  Revision 1.53.2.40  2000/08/29 19:58:13  headius
  blah

  Revision 1.53.2.39  2000/08/29 04:08:57  message
  GetResStr and GetResStrEx Added

  Revision 1.53.2.38  2000/08/29 02:50:57  headius
  blah

  Revision 1.53.2.37  2000/08/27 20:02:17  message
  *** empty log message ***

  Revision 1.53.2.36  2000/08/25 22:40:31  NeXTer
  See changes.txt

  Revision 1.53.2.35  2000/08/24 17:56:19  headius
  bleh

  Revision 1.53.2.34  2000/08/24 02:18:24  NeXTer
  See changes.txt

  Revision 1.53.2.33  2000/08/23 20:11:51  NeXTer
  See changes.txt

  Revision 1.53.2.32  2000/08/17 18:13:28  headius
  bang threading, popup fix

  Revision 1.53.2.31  2000/08/17 05:21:34  NeXTer
  See changes.txt

  Revision 1.53.2.30  2000/08/17 00:23:28  NeXTer
  See changes.txt

  Revision 1.53.2.29  2000/08/16 19:14:33  headius
  blah

  Revision 1.53.2.28  2000/08/16 18:42:42  headius
  added refreshsettings message, changed recyclestep accordingly

  Revision 1.53.2.27  2000/08/16 03:56:17  message
  *** empty log message ***

  Revision 1.53.2.26  2000/08/16 02:44:55  NeXTer
  See changes.txt

  Revision 1.53.2.25  2000/08/15 20:50:45  headius
  more fixes

  Revision 1.53.2.24  2000/08/15 18:32:12  headius
  fixes to transparentbltls and dllmgr threading

  Revision 1.53.2.23  2000/08/15 01:27:26  headius
  put grd's changes back in

  Revision 1.53.2.22  2000/08/15 01:16:01  headius
  *** empty log message ***

  Revision 1.53.2.21  2000/08/15 00:34:54  headius
  grd's rewrites to BitmapToRegion, TransparentBltLS, etc
  Headius's caching improvements to settings

  Revision 1.53.2.20  2000/08/10 12:46:43  NeXTer
  Improved the unload/reload bangs and added the theme files for lstime2 to
  the release/lstime/ dir

  Revision 1.53.2.19  2000/07/29 04:54:54  headius
  see changes.txt

  Revision 1.53.2.18  2000/07/21 19:11:48  NeXTer
  *** empty log message ***

  Revision 1.53.2.17  2000/06/10 20:09:47  maduin
  Replaced !About

  Revision 1.53.2.16  2000/06/10 19:02:11  headius
  Added TransparentBlt support, LitestepAPIInit function

  Revision 1.53.2.15  2000/06/09 16:04:12  maduin
  *** empty log message ***

  Revision 1.53.2.14  2000/06/09 06:12:51  maduin
  *** empty log message ***

  Revision 1.53.2.13  2000/06/06 20:12:35  maduin
  Fixed bug in LCOpen when szPath was NULL

  Revision 1.53.2.12  2000/06/04 19:53:39  message
  *** empty log message ***

  Revision 1.53.2.11  2000/06/03 23:19:47  headius
  fixing problem with lsopen trying to open "" pass as filename

  Revision 1.53.2.10  2000/05/30 02:02:26  headius
  destroying safearray in parsebangcommand

  Revision 1.53.2.9  2000/05/29 00:56:23  headius
  fixing stdcall/cdecl issues

  Revision 1.53.2.8  2000/05/29 00:00:21  headius
  fixing rc file caching

  Revision 1.53.2.7  2000/05/27 16:52:21  message
  *** empty log message ***

  Revision 1.53.2.6  2000/05/27 00:35:23  headius
  Adding callback bang command definition and wiring bang manger into appropriate functions

  Revision 1.53.2.5  2000/05/25 15:23:43  headius
  see changes.txt

  Revision 1.53.2.3  2000/05/24 16:26:32  headius
  removing neato debug dialogs in lsapi

  Revision 1.53.2.2  2000/05/24 04:24:44  headius
  Added hierarchical caching for rc file config lines

  Revision 1.53.2.1  2000/05/24 03:15:44  headius
  Modified rc file caching to use vector entries in a map, to allow for additional files

  Revision 1.53  2000/05/23 16:10:32  NeXTer
  Misc fixes to LSAPI

  Revision 1.10  2000/03/04 17:09:44  nexter
  *** empty log message ***

  Revision 1.9  2000/03/03 06:16:39  maduin
  *** empty log message ***

  Revision 1.1.1.1  2000/01/28 05:57:37  headius
  Import of Litestep into new cvs

  Revision 1.1  2000/01/21 06:11:45  headius
  C++-ifying lsapi, removal of var-len bangcommand prototype

Revision 1.73  2000/01/18 17:20:23  NeXTer
*** empty log message ***

  Revision 1.43  1999/01/16 02:37:16  bryan
  Variable Expansion extended to the whole of LS.
  
  Revision 1.42  1999/01/08 21:01:17  cyberian
  
  Fixed crash on recycle and loading of startup items
  
  Revision 1.39  1998/11/11 19:55:20  cyberian
  *** empty log message ***
  
 */

