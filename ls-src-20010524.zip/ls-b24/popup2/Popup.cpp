/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "PopupMaker.h"
#include "PopupMenu.h"
#include "Popup.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/macros.h"
PopupMaker* pPopupMaker;

void PopupBangCommand(HWND hCaller, const _TCHAR *pszName, const _TCHAR *pszArguments);

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
	g_hResStrInstance = dllInst;
	CoInitialize(NULL);
	pPopupMaker = new PopupMaker();
	pPopupMaker->Initialize(ParentWnd, dllInst, szPath);

	return 0;
}

int quitModule(HINSTANCE dllInst)
{
	CoUninitialize();
	delete pPopupMaker;

	return 1;
}

// Dummy startup routine that does almost nothing.
// This cuts out all of the standard startup code crud that
// bloats the DLL, and makes it take longer to load
BOOL __stdcall _DllMainCRTStartup(HINSTANCE hInst, DWORD fdwReason, LPVOID lpvRes)
{
     // We don't need thread notifications for what we're doing.  Thus, get
     // rid of them, thereby eliminating some of the overhead of this DLL
     DisableThreadLibraryCalls(hInst);
	 
	 return TRUE;
}

// handle !PopupXXX bang commands
void PopupBangCommand(HWND hCaller, const _TCHAR *pszName, const _TCHAR *pszArguments)
{
	_TCHAR szFirst[32];
	_TCHAR szSecond[32];
	_TCHAR szThird[32];
	_TCHAR szFourth[32];

	_TCHAR *rgszTokens[] = { szFirst, szSecond, szThird, szFourth };
	int nTokens = LCTokenize(pszArguments, rgszTokens, 4, 0);

	_TCHAR *pszAlignX = 0;
	_TCHAR *pszAlignY = 0;

	int nX;
	int nY;
	int nAlignX = ALIGN_LEFT;
	int nAlignY = ALIGN_TOP;

	POINT pt;
	GetCursorPos(&pt);

	nX = pt.x;
	nY = pt.y;

	if(nTokens >= 2)
	{
		if(_istdigit(szFirst[0]) || szFirst[0] == '-' || strnicmp(szFirst, "X=", 2) == 0)
		{
			if(strnicmp(szFirst, "X=", 2) == 0)
				nX = _ttoi(szFirst + 2);
			else
				nX = _ttoi(szFirst);

			if(strnicmp(szSecond, "Y=", 2) == 0)
				nY = _ttoi(szSecond + 2);
			else
				nY = _ttoi(szSecond);

			if(nTokens >= 4)
			{
				pszAlignX = szThird;
				pszAlignY = szFourth;
			}
		}
		else
		{
			pszAlignX = szFirst;
			pszAlignY = szSecond;
		}

		if(pszAlignX != 0 && pszAlignY != 0)
		{
			if(stricmp(pszAlignX, "center") == 0)
				nAlignX = ALIGN_CENTER;
			else if(stricmp(pszAlignX, "right") == 0)
				nAlignX = ALIGN_RIGHT;

			if(stricmp(pszAlignY, "center") == 0)
				nAlignY = ALIGN_CENTER;
			else if(stricmp(pszAlignY, "bottom") == 0)
				nAlignY = ALIGN_BOTTOM;
		}
	}
	
	nX = CONVERT_COORDINATE_X(nX);
	nY = CONVERT_COORDINATE_Y(nY);

	for(int i = 0; i < pPopupMaker->m_RootMenus.size(); i++)
	{
		PopupMenu *pPopup = pPopupMaker->m_RootMenus[i];
		
		if(pPopup->GetBangName() && lstrcmpi(pPopup->GetBangName(), pszName) == 0)
		{
			pPopup->Show(nX, nY, nAlignX, nAlignY);
			SetForegroundWindow(pPopup->GetWindow());
			break;
		}
	}
}
