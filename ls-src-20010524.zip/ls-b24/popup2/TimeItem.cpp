/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "TimeItem.h"
#include "PopupMenu.h"
#include "MenuItem.h"
#include "Re5ources.h"
#include <time.h>
#define TIMEITEM_TIMER 34792
#define MAXTIMEBUFFER  128

#define _countof(array) (sizeof(array)/sizeof(array[0]))

TimeItem::TimeItem(int nAlign, LPTSTR pszFormat)
{
	m_nAlign = DT_VCENTER|DT_SINGLELINE|nAlign;
	m_nTimer = 0;
	m_pszFormat = pszFormat != NULL ? strdup(pszFormat) : NULL;
}

TimeItem::~TimeItem()
{
	if(m_nTimer != 0)
		KillTimer(GetWindow(), m_nTimer);
	m_nTimer = 0;

	if(m_pszFormat) free(m_pszFormat);
	m_pszFormat = NULL;
}

void TimeItem::Paint(HDC hDC)
{
	time_t now;
	tm*	   ptmTemp;

	_TCHAR pszDateTime[MAXTIMEBUFFER];
	RECT r;

	MenuItem::Paint(hDC);

	// get the current time
	time(&now);
	ptmTemp = localtime(&now);

	if (ptmTemp == NULL || !_tcsftime(pszDateTime, _countof(pszDateTime), m_pszFormat, ptmTemp))
		pszDateTime[0] = '\0';
	MergeInternetTime(pszDateTime, GetInetTime(now));

	// calclulate the bounding box of the time
	r.top = m_nTop;
	r.left = 3 + GetIndent();
	r.bottom = GetHeight() + m_nTop;
	r.right = GetWidth() + m_nLeft - GetRightIndent() - 3;

	DrawText(hDC, pszDateTime, lstrlen(pszDateTime), &r, m_nAlign);		

	if(m_bDrawBevel)
		PaintBevel(hDC, m_nTop);
}

void TimeItem::MergeInternetTime(LPTSTR pszBuffer, int nTime)
{
	_TCHAR pszPattern[MAXTIMEBUFFER];
	_tcscpy(pszPattern, pszBuffer);
	LPTSTR pszInternetTime = _tcsstr(pszPattern, _TEXT("%@"));

	if(pszInternetTime)
	{
		// convert the %@ into a %d so we can use _stprintf to insert the time
		pszInternetTime[1] = 'd';
		_stprintf(pszBuffer, pszPattern, nTime);
	}
}

void TimeItem::Invoke()
{
	// Taken from aLSClock 
	_TCHAR winDir[_MAX_DIR+1];
	GetSystemDirectory(winDir, _MAX_DIR);
	ShellExecute(GetWindow(), _TEXT("open"), _TEXT("rundll32.exe"), 
		_TEXT("shell32.dll,Control_RunDLL timedate.cpl"),
		winDir, SW_SHOWNORMAL);
}
			
void TimeItem::Timer(int nTimer)
{
	if(TIMEITEM_TIMER == nTimer)
	{
		RECT r;
		GetItemRect(&r);
		RedrawWindow(GetWindow(), &r, NULL, RDW_INVALIDATE);
	}
}

void TimeItem::Attached(PopupMenu* pMenu)
{
	MenuItem::Attached(pMenu);
	m_nTimer = SetTimer(GetWindow(), TIMEITEM_TIMER, 1000, NULL);
}

BOOL TimeItem::Active(BOOL bActive)
{
	// do nothing .. one can not activate a separator
	return FALSE;
}
