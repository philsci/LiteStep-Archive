/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// TitleItem.h: interface for the TitleItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TITLEITEM_H__85C99963_7631_11D2_B6A4_00C0DF466974__INCLUDED_)
#define AFX_TITLEITEM_H__85C99963_7631_11D2_B6A4_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MenuItem.h"

// a menu item with a title
class TitleItem  : public MenuItem
{
public:
	TitleItem(_TCHAR* pszTitle);
	
	virtual ~TitleItem();
	void Paint(HDC hDC);
	_TCHAR* GetTitle(){return m_pszTitle;};

	_TCHAR* GetSortString(){return m_pszTitle;};
protected:
	/**
	subclasses may overload this method to alter the way that drawtext is called
	@return an UINT that represents how drawtext is called
	*/
	virtual UINT GetDrawTextFormat(){return GetAlignment() | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOCLIP; }
	virtual void GetTitleRect(RECT* r);
	_TCHAR* m_pszTitle;
};

#endif // !defined(AFX_TITLEITEM_H__85C99963_7631_11D2_B6A4_00C0DF466974__INCLUDED_)
