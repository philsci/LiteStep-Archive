/*
                                                                  
  This is a part of the LiteStep Shell Source code.               
                                                                    
  Copyright (C) 1997-98 The LiteStep Development Team              
                                                                   
  This program is free software; you can redistribute it and/or   
  modify it under the terms of the GNU General Public License     
  as published by the Free Software Foundation; either version 2     
  of the License, or (at your option) any later version.             
                                                                      
  This program is distributed in the hope that it will be useful,    
  but WITHOUT ANY WARRANTY; without even the implied warranty of     
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the      
  GNU General Public License for more details.                        
                                                                     
  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software         
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/19/00 - Joachim Calvert (NeXTer)
  - Commenced conversion to C++ style, lots of work remains, but it's a start
18/08/1999 (Ender)
                 - Rearranged code, made a lot of bug fixes, broke some stuff
                   at random.
21/08/1999 (Ender)
                 - Altered step.rc parsing, broke .winicon
25/08/1999 (Ender)
                 - Added ShortcutPassClicks step.rc option. Open's popup on
                   right click. Best used with Shortcutdragmode 1/2
10/09/1999 (Ender)
                 - Merged Visigoth's LSExecute from LSApi & added own []
                   parsing. Winicon fixed, & Merged with CVS
15/09/1999 (Ender)
                 - Re-added negitive coord's for Shortcuts
18/09/1999 (Ender)
                 - Fixed mouseover images
19/09/1999 (Ender)
                 - Renamed 'ShortcutPassClicks' to 'ShortcutMenu'
                   If 0, no menu. If 1, will open popup on right click.
20/09/1999 (GeekMaster)
                 - Added ShortcutMenu 2, which opens a right-click menu with
                   items like 'Move', 'Delete', 'Snapshot', etc.
24/09/1999 (GeekMaster)
                 - Changed ShortcutMenu so that Shortcutmenu 0 will move on right click, 
                   ShortcutMenu 1 will open Litestep Popup, and ShortcutMenu 2 will
                   open right-click menu.
24/09/1999 (GeekMaster)
                 - Changed source so that when right click move is enabled, a right
                   click will immediately let you move, fixing a bug where you had to
                   hit an arrow key to move the shortcut.
25/09/1999 (Ender)
                 - Semi-Working Multiple Master Groups. Has wierd behavior
                   I can't figure out, someone feel free to fix :)
                   Method: #3M{2,5}T  : Master for group's 3, 2 AND 5
                   
25/09/1999 (GeekMaster)
                  - Added a new right-click menu option: Select Image! This pops up a 
                    common dialog box that lets you choose a bmp file, which updates immediately.
                    It does not currently save that setting, and is a little buggy.

****************************************************************************/

#include <windows.h>
#include <mmsystem.h>
#include <time.h>
#include <stdio.h>
#include <malloc.h>
#include <commctrl.h>

#include "shortcut.h"
#include "../lsapi/lsapi.h"

//****************************************************************************
// Application Constants
const char szAppName[] = "ShortcutClass"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.5 $"; // Our Version 
const char rcsId[] = "$Id: shortcut.cpp,v 1.5 2000/04/26 09:51:34 nexter Exp $"; // The Full RCS ID.

// Shortcut definitions and defaults
INT  Shortcutmode;
INT  SysTrayDocked = -1;
INT  numShortcuts = 0;
INT  ShortcutMenuMode;
INT  ScreenWidth = 800;
INT  ScreenHeight = 600;
BOOL AlwaysOnTop = FALSE;
BOOL ShortcutCaptions = FALSE;
BOOL windowsHidden = TRUE;
BOOL noShortcutHints = FALSE;
HWND parent;
HWND refToplevel;
HWND desktop = NULL;
HWND shortcutHints = NULL;
HWND SysTrayHwnd = NULL;
CHAR szLitestepPath[256];
CHAR szImagePath[256];
CHAR szMouseOverSound[256];
CHAR szClickSound[256];
LONG DesktopOldWndProc;
HINSTANCE dll;
shortcutType *shortcuts = NULL;
HMENU ShortCutMenu;  // Right-Click Menu

// Window Callbacks
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK DesktopWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam); // Ender - V1
//****************************************************************************
// Bang Prototypes
void BangShowShortcutGroup (HWND caller, LPCSTR args);
void BangHideShortcutGroup (HWND caller, LPCSTR args);
void BangToggleShortcutGroup (HWND caller, LPCSTR args);
void BangSwitchToShortcutGroups (HWND caller, LPCSTR args);
void BangToggleOntop (HWND caller, LPCSTR args);
void BangSnapShot(HWND caller, LPCSTR args);

// Other Prototypes
void ParseShortcut(LPCSTR szString);
void SetShortcutImageSizes(int i);
void AddHook(void);
void DeleteHook(void);
void ReadConfig(void);
void CreateHints(HWND hWnd, char *txt, RECT *r);
void RemoveHints(HWND hWnd);
void NewShortcut(char* file, POINT drop_point);
INT  GetShortcutByWnd(HWND hwnd);
BOOL CreateShortcut(int i);
BOOL ReadLine (FILE *f, LPSTR szBuffer, DWORD dwLength);
char *StripLine (LPSTR szBuffer);
HBITMAP LoadPic (LPCSTR szImage, LPCSTR szFile, int snum);

// Note: Move these to globals exported from LsAPI at a later date
HINSTANCE ELSExecute(HWND Owner, LPCSTR szCommand, int nShowCmd);
void LCToke (LPCSTR szString, LPSTR part1, LPSTR part2, BOOL keepquotes);
void LS_RunCommand(char* szString, HWND caller);
void GetBMPSize(HBITMAP hBitmap, int *x, int *y);

//****************************************************************************
//\\//\\ Shortcut code. Module entry and exit code


int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  RECT r;

  dll = dllInst;
  parent = ParentWnd;
  strcpy(szLitestepPath, szPath);
  ReadConfig();
  if (!noShortcutHints)
  {
    shortcutHints = CreateWindow
    (
      TOOLTIPS_CLASS,
      (LPSTR)NULL,
      TTS_ALWAYSTIP,
      CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
      NULL,
      (HMENU)NULL,
      dll,
      NULL
    );
    if (!shortcutHints)
    {
      MessageBox(parent, "Error creating hints window", "Shortcut Hints Error", MB_OK);
      return 1;
    }
    SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
  }

  GetClientRect(GetDesktopWindow(), &r);
  ScreenWidth = r.right;
  ScreenHeight = r.bottom;

  desktop = FindWindow("DesktopBackgroundClass", NULL);
  if (!desktop)
    desktop = GetDesktopWindow();

  {       // Register our window class
    WNDCLASS wc;
    memset(&wc, 0, sizeof(wc));
    wc.lpfnWndProc = WndProc;                                 // our window procedure
    wc.hInstance = dllInst;                                 // hInstance of DLL
    wc.lpszClassName = szAppName;                      // our window class name
    wc.style = CS_DBLCLKS;

    if (!RegisterClass(&wc))
    {
      MessageBox(parent, "Error registering window class", "Shell_TickerClass", MB_OK | MB_TOPMOST);
      return 1;
    }
  }

  {
    FILE *f;

    f = LCOpen(NULL);
    if (f)
    {
      char buffer[4096];
      while (LCReadNextConfig(f, "*Shortcut", buffer, sizeof (buffer)))
        ParseShortcut(buffer);
    }
    LCClose(f);
  }

  /* Register the Bang Commands */

  AddBangCommand("!SHOWSHORTCUTGROUP", BangShowShortcutGroup);
  AddBangCommand("!HIDESHORTCUTGROUP", BangHideShortcutGroup);
  AddBangCommand("!TOGGLESHORTCUTGROUP", BangToggleShortcutGroup);
  AddBangCommand("!SWITCHTOSHORTCUTGROUP", BangSwitchToShortcutGroups);
  AddBangCommand("!ToggleOnTopShortcutGroup", BangToggleOntop);
  AddBangCommand("!Snapshot", BangSnapShot);
  AddHook();

  // Create Right-Click Menu
  ShortCutMenu = CreatePopupMenu();
  AppendMenu(ShortCutMenu, MF_ENABLED | MF_STRING, 100, "Move");
  AppendMenu(ShortCutMenu, MF_ENABLED | MF_STRING, 101, "SnapShot");
  AppendMenu(ShortCutMenu, MF_ENABLED | MF_STRING, 102, "Select Image");
  return 0;
}


// Module is being unloaded
void quitModule(HINSTANCE dllInst)
{
  if (!noShortcutHints && shortcutHints)     // If we have shortcut hints
  {
    DestroyWindow (shortcutHints);            // then remove them and free
    shortcutHints = NULL;                     // the memory
  }

  if (shortcuts)                             // Cycle and destroy all
  {
    int i;                                    // shortcut objects

    for (i = 0; i < numShortcuts; i++)
    {
      DragAcceptFiles(shortcuts[i].hwnd, FALSE);
      if (shortcuts[i].uTimer)
      {
        KillTimer (shortcuts[i].hwnd, i);
        shortcuts[i].uTimer = 0;
      }
      if (shortcuts[i].hwnd)
        DestroyWindow(shortcuts[i].hwnd);
      if (shortcuts[i].bmpOff)
        DeleteObject(shortcuts[i].bmpOff);
      if (shortcuts[i].bmpOn)
        DeleteObject(shortcuts[i].bmpOn);
      if (shortcuts[i].bmpClick)
        DeleteObject(shortcuts[i].bmpClick);
      if (shortcuts[i].transOnRgn)
        DeleteObject(shortcuts[i].transOnRgn);
      if (shortcuts[i].transOffRgn)
        DeleteObject(shortcuts[i].transOffRgn);
      if (shortcuts[i].transClickRgn)
        DeleteObject(shortcuts[i].transClickRgn);
    }
    free(shortcuts);
  }

  DeleteHook();                       // Unhook from desktop dll
  UnregisterClass(szAppName,dllInst); // Unregister window class
}


void AddHook(void)
{
  SetWindowLong(desktop, GWL_EXSTYLE, GetWindowLong(desktop, GWL_EXSTYLE) | WS_EX_ACCEPTFILES);
  DesktopOldWndProc = GetWindowLong(desktop, GWL_WNDPROC);
  SetWindowLong(desktop, GWL_WNDPROC, (LONG) DesktopWndProc); // V1.1xxx
}


void DeleteHook(void)
{
  SetWindowLong(desktop, GWL_WNDPROC, DesktopOldWndProc);
}


//****************************************************************************
//\\//\\ Shortcut code. Shortcut creation

BOOL CreateShortcut(int i)
{
  HWND hWnd;
  HRGN h = CreateRectRgn(0, 0, 0, 0);
  int realx;
  int realy;
  SetShortcutImageSizes(i);
  shortcuts[i].uTimer = 0;

  realx = shortcuts[i].x;
  realy = shortcuts[i].y;
  if (shortcuts[i].x < 0)
    realx += ScreenWidth;
  if (shortcuts[i].y < 0)
    realy += ScreenHeight;

  if ((AlwaysOnTop) || shortcuts[i].alwaysontop)
    hWnd = CreateWindowEx
    (
      WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
      szAppName,
      "",
      WS_POPUP,
      0, 0, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy,
      desktop,
      NULL,
      dll,
      NULL
    );
  else
    hWnd = CreateWindowEx
    (
      WS_EX_TOOLWINDOW,
      szAppName,
      "",
      WS_CHILD | WS_CLIPSIBLINGS,
      0, 0, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy,
      desktop,
      NULL,
      dll,
      NULL
    );

  if (!hWnd)
  {
    MessageBox(parent,"Error creating window","Shortcuts",MB_OK | MB_TOPMOST);
    return FALSE;
  }

  if (i == 0)
  {
    int Msgs[] = {LM_GETREVID, 0};

    SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)Msgs);
  }

  shortcuts[i].hwnd = hWnd;
  if (!noShortcutHints && hWnd)
  {
    RECT r;
    GetClientRect (hWnd, &r);
    CreateHints (hWnd, shortcuts[i].szName, &r);
  }

  shortcuts[i].transOnRgn = BitmapToRegion(shortcuts[i].bmpOn, RGB(255,0,255), 0x101010, 0, 0);
  shortcuts[i].transOffRgn = BitmapToRegion(shortcuts[i].bmpOff, RGB(255,0,255), 0x101010, 0, 0);
  shortcuts[i].transClickRgn = BitmapToRegion(shortcuts[i].bmpClick, RGB(255,0,255), 0x101010, 0, 0);

  if (shortcuts[i].bmpOff)
  {
    CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
    SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
  }
  else if (shortcuts[i].bmpOn)
  {
    CombineRgn(h, shortcuts[i].transOnRgn, NULL, RGN_COPY);
    SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
  }
  else if (shortcuts[i].bmpClick)
  {
    CombineRgn(h, shortcuts[i].transClickRgn, NULL, RGN_COPY);
    SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
  }
  else
    DeleteObject(h);

  SetWindowLong(shortcuts[i].hwnd, GWL_USERDATA, magicDWord);
  SetWindowPos(shortcuts[i].hwnd, 0, realx, realy, 0, 0, SWP_NOZORDER | SWP_NOSIZE);

  DragAcceptFiles(shortcuts[i].hwnd, TRUE);
  shortcuts[i].state = 0;

  if(shortcuts[i].bVisible)  // Only Show window if not initially hidden
  {
    RECT r;
    ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
    GetClientRect (shortcuts[i].hwnd, &r);
    InvalidateRect(shortcuts[i].hwnd, &r, TRUE);
  }

  return TRUE;
}


void CreateHints(HWND hWnd, char *txt, RECT *r)
{
  TOOLINFO ti;    // tool information

  if (noShortcutHints) return;

  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = TTF_SUBCLASS;
  ti.hwnd = hWnd;
  ti.hinst = dll;
  ti.uId = 0;
  ti.lpszText = txt;
  ti.rect = *r;

  SendMessage(shortcutHints, TTM_ADDTOOL, 0, (LPARAM)(LPTOOLINFO)&ti);
}


void RemoveHints(HWND hWnd)
{
  TOOLINFO ti;    // tool information
  RECT r={0,0,0,0};

  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = 0;
  ti.hwnd = hWnd;
  ti.hinst = dll;
  ti.uId = 0;
  ti.lpszText = NULL;
  ti.rect = r;

  SendMessage(shortcutHints, TTM_DELTOOL, 0, (LPARAM)(LPTOOLINFO) &ti);
}


void NewShortcut(char* file, POINT drop_point)
{
  char sysdir[256];
  char windir[256];

  shortcuts = (shortcutType*)realloc(shortcuts, (numShortcuts+1)*sizeof(shortcutType));
  memset(&shortcuts[numShortcuts], 0, sizeof(shortcutType));

  GetWindowsDirectory(windir, 256);
  GetSystemDirectory(sysdir, 256);

  strcpy(shortcuts[numShortcuts].szName, file);
  strcpy(shortcuts[numShortcuts].szCommand, file);

  shortcuts[numShortcuts].x = drop_point.x;
  shortcuts[numShortcuts].y = drop_point.y;

  strcpy(shortcuts[numShortcuts].sz_bmpOff, ".winicon");
  strcpy(shortcuts[numShortcuts].sz_bmpOn, ".winicon");
  strcpy(shortcuts[numShortcuts].sz_bmpClick, ".winicon");

  shortcuts[numShortcuts].bmpOff   = LoadPic(shortcuts[numShortcuts].sz_bmpOff, NULL, numShortcuts);
  shortcuts[numShortcuts].bmpOn    = LoadPic(shortcuts[numShortcuts].sz_bmpOn, NULL, numShortcuts);
  shortcuts[numShortcuts].bmpClick = LoadPic(shortcuts[numShortcuts].sz_bmpClick, NULL, numShortcuts);
  SetShortcutImageSizes(numShortcuts);
  shortcuts[numShortcuts].bVisible = TRUE;
  shortcuts[numShortcuts].uGroup = 0;

  shortcuts[numShortcuts].uTimer = 0;
  CreateShortcut(numShortcuts);
  numShortcuts++;
}


void SetShortcutImageSizes(int i)
{
  BITMAP bmInfo;
  if (shortcuts[i].bmpOff)
  {
    int res = GetObject(shortcuts[i].bmpOff, sizeof(bmInfo), &bmInfo);
    if (res > 0)
    {
      shortcuts[i].offSize.cx = bmInfo.bmWidth;
      shortcuts[i].offSize.cy = bmInfo.bmHeight;
    }
    else
      shortcuts[i].offSize.cx   = shortcuts[i].offSize.cy = 64;
  }
  if (shortcuts[i].bmpOn)
  {
    int res = GetObject(shortcuts[i].bmpOn, sizeof(bmInfo), &bmInfo);
    if (res > 0)
    {
      shortcuts[i].onSize.cx = bmInfo.bmWidth;
      shortcuts[i].onSize.cy = bmInfo.bmHeight;
    }
    else
      shortcuts[i].onSize.cx    = shortcuts[i].onSize.cy = 64;
  }
  if (shortcuts[i].bmpClick)
  {
    int res = GetObject(shortcuts[i].bmpClick, sizeof(bmInfo), &bmInfo);
    if (res > 0)
    {
      shortcuts[i].clickSize.cx = bmInfo.bmWidth;
      shortcuts[i].clickSize.cy = bmInfo.bmHeight;
    }
    else
      shortcuts[i].clickSize.cx = shortcuts[i].clickSize.cy = 64;
  }
}


//****************************************************************************
//\\//\\ Shortcut code. Shortcut control
void MoveGroup(int grp, int xmod, int ymod)
{
  int i;

  for (i=0;i<numShortcuts;i++)
  if (shortcuts[i].uGroup == grp)
  {
    shortcuts[i].x = shortcuts[i].x - xmod;
    shortcuts[i].y = shortcuts[i].y - ymod;

    if (shortcuts[i].masterdrag) // Recursive Protection
    {
      shortcuts[i].masterdrag = FALSE;
      MoveWindow(shortcuts[i].hwnd, shortcuts[i].x, shortcuts[i].y, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy, 1);
      shortcuts[i].masterdrag = TRUE;
    }
    else
      MoveWindow(shortcuts[i].hwnd, shortcuts[i].x, shortcuts[i].y, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy, 1);
  }

  if (SysTrayDocked == grp)
  {
    RECT sysrect;
    GetWindowRect(SysTrayHwnd, &sysrect);
    SetWindowPos(SysTrayHwnd, 0, sysrect.left - xmod, sysrect.top - ymod, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOSENDCHANGING);
    PostMessage(SysTrayHwnd,WM_MOVE,0,(LPARAM)MAKELONG(sysrect.left - xmod, sysrect.top - ymod));
  }
}


LRESULT CALLBACK DesktopWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case WM_DROPFILES:
      int numDropped;
      char szFname[256];
      POINT drop_point;
      numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
      if (numDropped > 1)
      {
        MessageBox(0, "Please only drag one shortcut (to the desktop) at a time", "Error adding shortcut!", MB_OK|MB_TOPMOST);
        return 0;
      }

      DragQueryFile((HDROP) wParam, 0, szFname, sizeof(szFname));
      if (szFname && szFname[0])
      {
        DragQueryPoint((HDROP) wParam, &drop_point);
        NewShortcut(szFname, drop_point);
      }
      DragFinish((HDROP) wParam);
      return 0;

    default:
      //return CallWindowProc((int (__stdcall *)())(DesktopOldWndProc), hwnd, message, wParam, lParam);
       return CallWindowProc(WNDPROC(DesktopOldWndProc), hwnd, message, wParam, lParam);
  }
}


//****************************************************************************
//\\//\\ Shortcut code. Bang commands
void BangShowShortcutGroup (HWND caller, LPCSTR args)
{
  int i;
  int pGroup = atoi(args);

  if (SysTrayDocked == pGroup)
  ShowWindow(SysTrayHwnd, SW_SHOWNORMAL);

  for (i = 0; i < numShortcuts; i++)
  {
    if(!shortcuts[i].bVisible && shortcuts[i].uGroup == pGroup && shortcuts[i].hwnd)
    {
      ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
      shortcuts[i].bVisible = TRUE;
    }
  }
}


void BangHideShortcutGroup (HWND caller, LPCSTR args)
{
  int i;
  int pGroup = atoi(args);

  if (SysTrayDocked == pGroup)
  ShowWindow(SysTrayHwnd, SW_HIDE);

  if(pGroup)              // Don't allow hiding of Group 0
  {
    for (i = 0; i < numShortcuts; i++)
    {
      if (shortcuts[i].bVisible && shortcuts[i].uGroup == pGroup && shortcuts[i].hwnd)
      {
        ShowWindow(shortcuts[i].hwnd, SW_HIDE);
        shortcuts[i].bVisible = FALSE;
      }
    }
  }
}


void BangToggleShortcutGroup (HWND caller, LPCSTR args)
{
  int i;
  int pGroup = atoi(args);

  if(pGroup)
  {
    for (i = 0; i < numShortcuts; i++)
    {
      if(shortcuts[i].hwnd && shortcuts[i].uGroup == pGroup)
      {
        if(shortcuts[i].bVisible)
        {
          ShowWindow(shortcuts[i].hwnd, SW_HIDE);
          shortcuts[i].bVisible = FALSE;
          if (SysTrayDocked == pGroup)
            ShowWindow(SysTrayHwnd, SW_HIDE);
        }
        else
        {
          ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
          shortcuts[i].bVisible = TRUE;
          if (SysTrayDocked == pGroup)
            ShowWindow(SysTrayHwnd, SW_SHOWNORMAL);
        }
      }
    }
  }
}

void BangSwitchToShortcutGroups (HWND caller, LPCSTR args)
{
  int pGroup = atoi(args);
  int i;

  for (i = 0; i < numShortcuts; i++)
  {
    if(shortcuts[i].hwnd)
    {
      if(shortcuts[i].uGroup == pGroup && !shortcuts[i].bVisible)
      {
        ShowWindow(shortcuts[i].hwnd, SW_SHOWNORMAL);
        shortcuts[i].bVisible = TRUE;
      }
      else if (shortcuts[i].uGroup != pGroup && shortcuts[i].uGroup != 0)
      {
        ShowWindow(shortcuts[i].hwnd, SW_HIDE);
        shortcuts[i].bVisible = FALSE;
      }
    }
  }
}


void BangToggleOntop (HWND caller, LPCSTR args)
{
  int pGroup = atoi(args);
  int i;

  if(pGroup)
  {
    for (i = 0; i < numShortcuts; i++)
    {
      if(shortcuts[i].hwnd && shortcuts[i].uGroup == pGroup)
      {
        if(shortcuts[i].alwaysontop)
        {
          shortcuts[i].alwaysontop = FALSE;
          DestroyWindow(shortcuts[i].hwnd);
          CreateShortcut(i);
        }
        else
        {
          shortcuts[i].alwaysontop = TRUE;
          DestroyWindow(shortcuts[i].hwnd);
          CreateShortcut(i);
        }
      }
    }
  }
}

void BangSnapShot(HWND caller, LPCSTR args)
{
  FILE *f, *sr;
  char line[256], source[256], target[256];
  int i, prefix_length;
  i = prefix_length = 0;

  strcpy(source, szLitestepPath); strcat(source, "\\step.rc");
  sr = fopen(source, "r");

  strcpy(target, szLitestepPath); strcat(target, "\\shortcut.rc");
  f = fopen(target, "w");
  prefix_length = strlen ("*shortcut");

  // This code copys the existing step.rc, and replaces existing *shortcut's
  // (Replaces/updates in the same position they were already in)

  while (ReadLine(sr, line, sizeof (line)))
  {
    if (!strnicmp (StripLine(line), "*shortcut", prefix_length))
    {
      if (i < numShortcuts)
      {
        fprintf(f, "*Shortcut \"%s\" %d %d %s %s %s %s %s %s %s\n", shortcuts[i].szName, shortcuts[i].x, shortcuts[i].y, shortcuts[i].sz_bmpOff, shortcuts[i].sz_bmpOn, shortcuts[i].sz_bmpClick, shortcuts[i].sz_Group, shortcuts[i].szSoundOnMouseOver, shortcuts[i].szSoundOnMouseClicked, shortcuts[i].szCommand);
        i++;
      }
    }
    else
    fprintf(f, "%s", line);
  }

  // Appends new shortcuts to the end of step.rc
  for (i=i; i<numShortcuts; i++)
    fprintf(f, "*Shortcut \"%s\" %d %d %s %s %s %s %s %s %s\n", shortcuts[i].szName, shortcuts[i].x, shortcuts[i].y, shortcuts[i].sz_bmpOff, shortcuts[i].sz_bmpOn, shortcuts[i].sz_bmpClick, shortcuts[i].sz_Group, shortcuts[i].szSoundOnMouseOver, shortcuts[i].szSoundOnMouseClicked, shortcuts[i].szCommand);

  fclose(f); fclose(sr);
  strcpy(line, szLitestepPath);
  strcat(line, "\\step.org");

  CopyFile(source, line, 0);
  CopyFile(target, source, 0);
  DeleteFile(target);
}


//****************************************************************************
//\\//\\ Shortcut code. Misc. code

void ReadConfig(void)
{

  // Modified - Maduin, 10-20-1999
  //   Changed to use new API LSGetImagePath rather than
  //   access the step.rc directly.

  LSGetImagePath(szImagePath, 256);

  GetRCString("ShortcutMouseOverSound", szMouseOverSound, "", 256);
  GetRCString("ShortcutClickSound", szClickSound, "", 256);

  noShortcutHints  = GetRCBool("NoShortcutHints",      TRUE);
  AlwaysOnTop      = GetRCBool("ShortcutsAlwaysOnTop", TRUE);
  ShortcutMenuMode = GetRCInt("ShortcutMenu", 0);
  Shortcutmode     = GetRCInt("ShortcutDragMode", 0);
}


BOOL ReadLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  while (f && !feof(f))
  {
    if (!fgets(szBuffer, dwLength, f))
      break;
    return TRUE;
  }

  return FALSE;
}


char* StripLine (LPSTR szBuffer)
{
  static char strip[256];
  int length;
  length = strlen (szBuffer);
  strcpy(strip, szBuffer);

  while (length && isspace(strip[0]))
  {
    length--;
    strcpy (strip, strip + 1);
  }
  while (length && isspace(strip[length-1]))
    strip[--length] = '\0';

  return(strip);
}


void LS_RunCommand(char* szString, HWND caller)
{
  // Multi-Command parsing
  char  *pOutput;
  char  **tokens;
  char  buffer[4096];
  int   cnt = 0;
  int   cnt2 = 0;

  tokens = (char **)malloc(sizeof(char*) * 50); // Define 50 by default
  strcpy(buffer, szString);
  pOutput = strtok(buffer, "[]");

  while (cnt2 < 1)
  {
    tokens[cnt] = (char *)malloc(4096);              // Lock Memory
    strcpy(tokens[cnt], pOutput);                    // Store previous token
    pOutput = strtok(NULL, "[]");                    // Get Next Token
    cnt++;                                           // DaCounter (tm)

    if(pOutput == NULL)                              // End of sequence
    {
      for(cnt2 = 0; cnt2<cnt; cnt2++)
      {
        ELSExecute(caller, StripLine(tokens[cnt2]), 0);// Run command
        free(tokens[cnt2]);                            // Free buffer
      }
      free(tokens);                                   // Free structure
    }
  }
}


HBITMAP LoadPic(LPCSTR szImage, LPCSTR szFile, int snum)
{
  HBITMAP hBitmap;
  char szImageBuf[MAX_PATH];

  strcpy(szImageBuf, szImage);

  if (!strnicmp (szImageBuf, ".winicon", 8))
  {
    // Returns the ASSOCIATED icon for this file/type
    HICON hIcon;
    SHFILEINFO shf;
    CHAR dir[255];
    CHAR command[1024];
    CHAR params[1024];
    char* tok[1];

    // FIXME! This should -work-
    strcpy(command, "\0"); strcpy(params, "\0");
    tok[0] = command; tok[1] = params;
    LCTokenize(shortcuts[snum].szCommand, tok, 2, params);

    SHGetFileInfo(command, 0, &shf, sizeof(shf), SHGFI_ICON);
    if (shf.hIcon != NULL)
      hIcon = shf.hIcon;
    else
    {
      _searchenv(command, "PATH", dir);
      if (strlen(dir) == 0)
      {
        strcat(command, ".exe");
        _searchenv(command, "PATH", dir);
      }
      if (strlen(dir) != 0)
      {
        SHGetFileInfo(dir, 0, &shf, sizeof(shf), SHGFI_ICON);
        hIcon = shf.hIcon;
      }
    }

    if (hIcon)
    {
      hBitmap = BitmapFromIcon(hIcon);
      DestroyIcon (hIcon);
    }
  }
  else
    hBitmap = LoadLSImage(szImage, szFile);

  if (hBitmap)
    return hBitmap;
  return NULL;
}


int GetShortcutByWnd(HWND hwnd)
{
  int i;

  for (i = 0; i < numShortcuts; i++)
    if (shortcuts[i].hwnd == hwnd)
      return i;

  return -1;
}


//****************************************************************************
//\\//\\ Shortcut code. Unsorted

void ParseShortcut(LPCSTR szString)
{
  char* tokens[11];
  char buffer[4096];
  char token[4096];
  char t1[4096];
  char t2[4096];
  char t3[4096];
  char t4[4096];
  char t5[4096];
  char t6[4096];
  char t7[4096];
  int count;

  tokens[0] = t1;
  tokens[1] = t2;
  tokens[2] = t3;
  tokens[3] = t4;
  tokens[4] = t5;
  tokens[5] = t6;
  tokens[6] = t7;

  if (!shortcuts)
    shortcuts = (shortcutType *)malloc(sizeof(shortcutType));
  else
    shortcuts = (shortcutType*)realloc(shortcuts, (numShortcuts+1)*sizeof(shortcutType));

  memset(&shortcuts[numShortcuts], 0, sizeof(shortcutType));

  strcpy(buffer, szString);
  count = LCTokenize (buffer, tokens, 7, buffer);

  if (count >= 7)
  {
    strcpy(shortcuts[numShortcuts].szName, tokens[1]);
    shortcuts[numShortcuts].x = atoi(tokens[2]);
    shortcuts[numShortcuts].y = atoi(tokens[3]);
    strcpy(shortcuts[numShortcuts].sz_bmpOff, tokens[4]);
    strcpy(shortcuts[numShortcuts].sz_bmpOn, tokens[5]);
    strcpy(shortcuts[numShortcuts].sz_bmpClick, tokens[6]);

    // Default group parameters
    shortcuts[numShortcuts].bVisible = TRUE;
    shortcuts[numShortcuts].uGroup = 0;
    strcpy(buffer, StripLine(buffer));

    if(buffer[0] == '#')                    // Parse group entry (if exists)
    {
      LCToke(buffer, token, buffer, TRUE);
      strcpy(shortcuts[numShortcuts].sz_Group, token);
      shortcuts[numShortcuts].uGroup = atoi(&token[1]);

      if (strstr(strlwr(token), "h"))
        shortcuts[numShortcuts].bVisible = FALSE;
      if (strstr(strlwr(token), "t"))
        shortcuts[numShortcuts].alwaysontop = TRUE;
      if (strstr(strlwr(token), "s"))
        shortcuts[numShortcuts].sstatic = TRUE;
      if (strstr(strlwr(token), "o"))
        shortcuts[numShortcuts].mouseover = TRUE;
      if (strstr(strlwr(token), "m"))
      {
        char *pOutput;
        shortcuts[numShortcuts].masterdrag = TRUE;
        strtok(token, "{}");
        pOutput = strtok(NULL, "{}");
        if (pOutput != NULL) strcpy(shortcuts[numShortcuts].extra_group, pOutput);
      }
    }
    strcpy(shortcuts[numShortcuts].szCommand, buffer);

    // Load Images (last, because .winicon requires szCommand)
    shortcuts[numShortcuts].bmpOff   = LoadPic(tokens[4], NULL, numShortcuts);
    shortcuts[numShortcuts].bmpOn    = LoadPic(tokens[5], NULL, numShortcuts);
    shortcuts[numShortcuts].bmpClick = LoadPic(tokens[6], NULL, numShortcuts);

    // Create the shortcut
    CreateShortcut(numShortcuts);
    numShortcuts++;
  }
}


void LCToke (LPCSTR szString, LPSTR part1, LPSTR part2, BOOL keepquotes)
{
  char buffer[4096];
  char *pOutput;

  strcpy(buffer, szString); strcpy(part1, "\0"); strcpy(part2, "\0");
  if (!strlen(buffer))
    return;

  pOutput = strtok(buffer, " ");
  strcpy(part1, pOutput);
  if (pOutput != NULL)
  {
    pOutput = strtok(NULL, "");
    if (pOutput)
      strcpy(part2, pOutput);
  }
}




HINSTANCE ELSExecuteEx(HWND Owner, LPSTR szOperation, LPSTR szCommand, LPSTR szArgs, LPSTR szDirectory, int nShowCmd)
{
  SHELLEXECUTEINFO si;
  if (strlen(szCommand) < 2)  // Error Check
    return NULL;

  if(*szCommand == '!')
    return ParseBangCommand(Owner, szCommand, szArgs) ? (HINSTANCE)1 : (HINSTANCE)0;
  else if(GetFileAttributes(szCommand) & FILE_ATTRIBUTE_DIRECTORY)
    return ShellExecute(Owner, szOperation, szCommand, szArgs, NULL, nShowCmd);
  else
  {
    memset(&si, 0, sizeof(si));
    si.cbSize = sizeof(SHELLEXECUTEINFO);
    si.hwnd = Owner;
    si.lpVerb = szOperation;
    si.lpFile = szCommand;
    si.lpParameters = szArgs;
    si.lpDirectory = szDirectory;
    si.nShow = nShowCmd;
    si.fMask = SEE_MASK_DOENVSUBST;
    ShellExecuteEx(&si);
    return (HINSTANCE)GetLastError();
  }
}

HINSTANCE ELSExecute(HWND Owner, LPCSTR szCommand, int nShowCmd)
{
  char command[4096];
  char *newcmd;
  char *args;
  char *p;
  char dir[_MAX_DIR];
  char full_directory[_MAX_DIR + _MAX_DRIVE + 1]; // Can't rely on MAX_PATH for command
  HINSTANCE val;

  if (!szCommand || strlen(szCommand) < 1)
    return 0;

  VarExpansion(command, szCommand);

  if (*command == '\"')
  {
    newcmd = command + sizeof(char);
    newcmd = strtok(newcmd, "\"");
    args = strtok(NULL, "\0");

    if (!newcmd)
      return 0;
  }
  else
  {
    newcmd = strtok(command, "\t ");
    if (!newcmd)
    {
      newcmd = command;
      args = NULL;
    }
    else
    {
      args = strtok(NULL, "\0");
    }
  }

  p = newcmd + (strlen(newcmd) - 1)*sizeof(char);
  while (isspace(*newcmd))
    newcmd++;
  while (isspace(*p))
  {
    *p = '\0';
    p--;
  }

  if (*newcmd != '!')
  {
    if (args)
    {
      p = args + (strlen(args) - 1)*sizeof(char);
      while (isspace(*args) || *args == '\"')
        args++;
      while (isspace(*p) || *p == '\"')
      {
        *p = '\0';
        p--;
      }
    }
  }
  else if (args)
  {
    p = args + (strlen(args) - 1)*sizeof(char);
    while (isspace(*args))
      args++;
    while (isspace(*p))
    {
      *p = '\0';
      p--;
    }
  }

  if(*newcmd == '!')
    val = ELSExecuteEx(Owner, NULL, newcmd, args, NULL, 0);
  else
  {
    if(GetFileAttributes(newcmd) & FILE_ATTRIBUTE_DIRECTORY)
      val = ELSExecuteEx(Owner, "open", newcmd, args, NULL, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    else
    {
      _splitpath(newcmd, full_directory, dir, NULL, NULL);
      strcat(full_directory, dir);
      val = ELSExecuteEx(Owner, "open", newcmd, args, full_directory, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    }
  }

  //  free(command);
  return val;
}


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case LM_GETREVID:
    {
      char *buf = (char*)lParam;
      if (wParam == 0)
      {
        strcpy(buf, "shortcut.dll: ");
        strcat(buf, &rcsRevision[11]);
        buf[strlen(buf)-1] = '\0';
      }
      else if (wParam == 1)
      {
        strcpy(buf, &rcsId[1]);
        buf[strlen(buf)-1] = '\0';
      }
      else
      {
        strcpy(buf, "");
      }
      return strlen(buf);
    }

    case WM_MOUSEMOVE:
    {
      MSG TooltipMessage;
      int i = GetShortcutByWnd(hwnd);
      if (i == -1) return 0;

      if ((Shortcutmode == 1) && (wParam == MK_LBUTTON) && !(shortcuts[i].sstatic))
      {
        UINT t = GetTickCount() + 1000;
        while (GetTickCount() < t);
        if (GetKeyState(VK_LBUTTON))
        {
          SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE | 2, 0);
          return 0;
        }
      }

      if (!strcmpi(shortcuts[i].szCommand, ".none"))
        return 0;
      if (!shortcuts[i].state)
      {
        if (!noShortcutHints)
        {
          if (i >= 0)
          {
            TooltipMessage.hwnd = shortcuts[i].hwnd;
            TooltipMessage.message = message;
            TooltipMessage.wParam = wParam;
            TooltipMessage.lParam = lParam;
            SendMessage(shortcutHints, TTM_RELAYEVENT, 0, (LPARAM)&TooltipMessage);
            SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
          }
        }

        // Removed calls that stop currently playing sound
        if (shortcuts[i].szSoundOnMouseOver[0])
        {
          //sndPlaySound(NULL, 0);
          sndPlaySound(shortcuts[i].szSoundOnMouseOver, SND_ASYNC|SND_NODEFAULT);
        }
        else if (szMouseOverSound[0])
        {
          //sndPlaySound(NULL, 0);
          sndPlaySound(szMouseOverSound, SND_ASYNC|SND_NODEFAULT);
        }

        if (shortcuts[i].bmpOn)
        {
          RECT r;
          HRGN h;
          h = CreateRectRgn(0, 0, 0, 0);

          CombineRgn(h, shortcuts[i].transOnRgn, NULL, RGN_COPY);
          SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
          shortcuts[i].state = 1;
          GetClientRect(hwnd, &r);
          InvalidateRect(hwnd, &r, TRUE);

          if (!shortcuts[i].uTimer)
          {
            shortcuts[i].uTimer = i;
            SetTimer (shortcuts[i].hwnd, i, 5, NULL);
          }
        }
      }   // !shortcuts[i].state
    }
    return 0;

    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
      return SendMessage(parent,message,wParam,lParam);

    case WM_CREATE:
      return 0;

    case WM_ERASEBKGND:
      return 1;

    case WM_TIMER:
      {
      int i = GetShortcutByWnd(hwnd);
      if (i == -1)
        return 0;

      if (!strcmpi(shortcuts[i].szCommand, ".none"))
        return 0;

      if (shortcuts[i].state)
      {
      POINT pos;
      RECT r;
      HRGN h = CreateRectRgn(0, 0, 0, 0);

      GetCursorPos(&pos);
      GetWindowRgn(hwnd, h);

      if ((!PtInRegion(h, pos.x-shortcuts[i].x, pos.y-shortcuts[i].y)))
      {
        if (shortcuts[i].bmpOff)
        {
          CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
          SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
        }

        shortcuts[i].state = 0;
        GetClientRect(hwnd, &r);
        InvalidateRect(hwnd, &r, TRUE);

        if (shortcuts[i].uTimer)
        {
          KillTimer (shortcuts[i].hwnd, i);
          shortcuts[i].uTimer = 0;
        }
        }
        else
        DeleteObject(h);
        }
      }
      return 0;

    case WM_PAINT:
      {
        PAINTSTRUCT ps;
        int i = GetShortcutByWnd(hwnd);
        HDC hdc = BeginPaint(hwnd,&ps);
        HDC src = CreateCompatibleDC(NULL);

        if (i == -1)
          return 0;

        if (shortcuts[i].state == 0 && shortcuts[i].bmpOff)
        {
          SelectObject(src, shortcuts[i].bmpOff);
          BitBlt(hdc, 0, 0, shortcuts[i].offSize.cx, shortcuts[i].offSize.cy, src, 0, 0, SRCCOPY);
        }
        if (shortcuts[i].state == 1 && shortcuts[i].bmpOn)
        {
          SelectObject(src, shortcuts[i].bmpOn);
          BitBlt(hdc, 0, 0, shortcuts[i].onSize.cx, shortcuts[i].onSize.cy, src, 0, 0, SRCCOPY);
        }
        if (shortcuts[i].state == 3 && shortcuts[i].bmpClick)
        {
          SelectObject(src, shortcuts[i].bmpClick);
          BitBlt(hdc, 0, 0, shortcuts[i].clickSize.cx, shortcuts[i].clickSize.cy, src, 0, 0, SRCCOPY);
        }

        EndPaint(hwnd,&ps);
        DeleteDC(src);
      }
      return 0;


    case WM_LBUTTONDOWN:
      {
        RECT r;
        int i = GetShortcutByWnd(hwnd);

        if (i == -1)
          return 0;

        if (shortcuts[i].bmpClick)
        {
          HRGN h;
          h = CreateRectRgn(0, 0, 0, 0);
          CombineRgn(h, shortcuts[i].transClickRgn, NULL, RGN_COPY);
          SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
        }

        shortcuts[i].state = 3;
        GetClientRect(hwnd, &r);
        InvalidateRect(hwnd, &r, TRUE);

        if (!shortcuts[i].uTimer)
        {
          shortcuts[i].uTimer =  i;
          SetTimer (shortcuts[i].hwnd, i, 5, NULL);
        }

        // Removed calls that stop current playing sound
        if (shortcuts[i].szSoundOnMouseClicked[0])
        {
          //sndPlaySound(NULL, 0);
          sndPlaySound(shortcuts[i].szSoundOnMouseClicked, SND_ASYNC|SND_NODEFAULT);
        }
        else if (szClickSound[0])
        {
          //sndPlaySound(NULL, 0);
          sndPlaySound(szClickSound, SND_ASYNC|SND_NODEFAULT);
        }
      }
      return 0;

    case WM_LBUTTONUP:
      {
        RECT r;
        int i = GetShortcutByWnd(hwnd);

        if (i == -1)
          return 0;

        shortcuts[i].state = 0;
        GetClientRect(hwnd, &r);
        InvalidateRect(hwnd, &r, TRUE);

        if (shortcuts[i].bmpOff)
        {
          HRGN h;
          h = CreateRectRgn(0, 0, 0, 0);
          CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
          SetWindowRgn(shortcuts[i].hwnd, h, TRUE);
        }

        if (!shortcuts[i].uTimer)
        {
          shortcuts[i].uTimer =  i;
          SetTimer (shortcuts[i].hwnd, i, 5, NULL);
        }

        if (!strcmpi(shortcuts[i].szCommand, ".none"))
          return 0;
        else
          LS_RunCommand(shortcuts[i].szCommand, hwnd);
      }
      return 0;

    case WM_WINDOWPOSCHANGING:
      {
        WINDOWPOS *lpwp = (WINDOWPOS*)lParam;
        lpwp->flags |= SWP_NOZORDER;
      }
      return 0;

    case WM_MOUSEACTIVATE:
      {
        PostMessage(parent, LM_LSSELECT, 0, 0);
        SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
        if (HIWORD(lParam) == WM_LBUTTONDOWN)
          PostMessage(hwnd, WM_LBUTTONDOWN, 0, 0);
        return MA_ACTIVATE;
      }

    case WM_ACTIVATE:
      {
        SendMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
        if (LOWORD(wParam))
          SetActiveWindow(parent);
        return 0;
      }

    case WM_RBUTTONUP: // Switch to move mode
      {
        int i = GetShortcutByWnd(hwnd);

        if (i == -1)
        return 0;

        if ((Shortcutmode == 0) && (ShortcutMenuMode == 0)&& !shortcuts[i].sstatic)
        SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE, 0);
        if (ShortcutMenuMode == 1)
        SendMessage(parent, LM_POPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
        if (ShortcutMenuMode == 2)
        {
        DWORD dw;
        dw = GetMessagePos();
        TrackPopupMenu(ShortCutMenu, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hwnd, NULL);
        }
        return 0;
      }

    case WM_RBUTTONDOWN:
      {
        // if (Shortcutmode == 0) {SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE, 0);}
        return 0;
      }

    case WM_MBUTTONDOWN:
      {
        SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
        return 0;
      }

    case WM_KEYDOWN:
    case WM_KEYUP:
      {
        PostMessage(parent,message,wParam,lParam);
        return 0;
      }

    case WM_MOVE:
      {
        int i = GetShortcutByWnd(hwnd);

        if (i == -1)
        return 0;

        if (shortcuts[i].masterdrag)
        {
          char *pOutput;
          int groups[20];
          int i2=0;
          int i3;
          int xmod = shortcuts[i].x-LOWORD(lParam);
          int ymod = shortcuts[i].y-HIWORD(lParam);

          MoveGroup(shortcuts[i].uGroup, xmod, ymod);

          pOutput = strtok(shortcuts[i].extra_group, ",");
          while (pOutput != NULL)
          {
            groups[i2] = atoi(pOutput);
            pOutput = strtok(NULL, ",");
            i2++;
          }

          for (i3 = 0; i3<i2; i3++)
            MoveGroup(groups[i3], xmod, ymod);
        }
        shortcuts[i].x = LOWORD(lParam);
        shortcuts[i].y = HIWORD(lParam);
        return 0;
      }

    case WM_SYSCOMMAND:
      {
        switch (wParam)
        {
          case SC_MOVE:
          {
            SendMessage(hwnd, WM_KEYDOWN, VK_DOWN, 0);
          }
          break;
        }
      }
      break;

    case WM_COMMAND:
      {
        switch(wParam)
        {
          case 100:
            {
              int i = GetShortcutByWnd(hwnd);
              if (i == -1)
              return 0;
              if ((Shortcutmode == 0) && !shortcuts[i].sstatic)
              SendMessage(hwnd, WM_SYSCOMMAND, SC_MOVE, 0);
              SendMessage(hwnd,WM_KEYDOWN,VK_DOWN,0);
            }
            break;
          case 101:
            {
              BangSnapShot(hwnd,NULL);
            }
            break;
          case 102: // Select Image
            {
              OPENFILENAME ofn;
              char szFileName[MAX_PATH];

              ZeroMemory(&ofn, sizeof(ofn));
              szFileName[0] = 0;

              ofn.lStructSize = sizeof(ofn);
              ofn.hwndOwner = hwnd;
              ofn.lpstrFilter = "Bitmaps (*.bmp)\0*.bmp\0All Files (*.*)\0*.*\0\0";
              ofn.lpstrFile = szFileName;
              ofn.nMaxFile = MAX_PATH;
              ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
              ofn.lpstrDefExt = "bmp";

              if(GetOpenFileName(&ofn))
              {
                HBITMAP hBitmap;
                int i;
                int x,y;
                RECT r;
                HRGN h = CreateRectRgn(0, 0, 0, 0);

                i = GetShortcutByWnd(hwnd);
                hBitmap = LoadPic(szFileName, NULL,i);
                GetBMPSize(hBitmap, &x, &y);
                SetWindowPos(hwnd, HWND_TOP, 0, 0, x, y, SWP_NOMOVE | SWP_NOREPOSITION);
                shortcuts[i].bmpOff   = LoadPic(szFileName, NULL,i);
                shortcuts[i].bmpOn    = LoadPic(szFileName, NULL,i);
                shortcuts[i].bmpClick = LoadPic(szFileName, NULL,i);
                SetShortcutImageSizes(i);
                shortcuts[i].transOnRgn = BitmapToRegion(shortcuts[i].bmpOn, RGB(255,0,255), 0x101010, 0, 0);
                shortcuts[i].transOffRgn = BitmapToRegion(shortcuts[i].bmpOff, RGB(255,0,255), 0x101010, 0, 0);
                shortcuts[i].transClickRgn = BitmapToRegion(shortcuts[i].bmpClick, RGB(255,0,255), 0x101010, 0, 0);

                if (shortcuts[i].bmpOff)
                {
                  CombineRgn(h, shortcuts[i].transOffRgn, NULL, RGN_COPY);
                  SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
                }
                else if (shortcuts[i].bmpOn)
                {
                  CombineRgn(h, shortcuts[i].transOnRgn, NULL, RGN_COPY);
                  SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
                }
                else if (shortcuts[i].bmpClick)
                {
                  CombineRgn(h, shortcuts[i].transClickRgn, NULL, RGN_COPY);
                  SetWindowRgn(shortcuts[i].hwnd, h, FALSE);
                }
                else
                  DeleteObject(h);

                GetWindowRect(hwnd,&r);
              }
            }
            break;
        } // End Switch
        return 0;
      }   // End WM_COMMAND
  }
  return DefWindowProc(hwnd,message,wParam,lParam);
}


void GetBMPSize(HBITMAP hBitmap, int *x, int *y)
{
  BITMAP bm;
  if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
  {
    *x=0;
    *y=0;
  }
  else
  {
    *x = bm.bmWidth;
    *y = bm.bmHeight;
  }
}


