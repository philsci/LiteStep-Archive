/*
  - fixed cursor movement in menu's
  - PopupTextOffset sets also icon.
  - Return open now also subfolders.
*/

/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/****************************************************************************
 12/20/98 - Fahim Farook
			Perfected subfolder pinning via a double-click on the titlebar and
			pinned popup closing via a click on the close button
 12/19/98 - Fahim Farook
			Removed the subList structure and modified popup navigation to use a
			linked list created via parent & child relationships
 12/10/98 - Fahim Farook
			Rewrote most of the popup code so that it used a single popup structure
			and was more object oriented
 12/02/98 - Fahim Farook
			Added fixed width popup menu support via PopupFixedWidth in step.rc
 12/01/98 - Fahim Farook
			Fixed the popups crashing on moving cursor to bottom pic bug
 11/24/98 - Edwin Man
            Changed default PopupNormalColor to A4A0A0; looks better
 11/24/98 - Fahim Farook
			Changed the popup navigation code to use standardized item heights
			so that the code is more readable and faster
 11/23/98 - Fahim Farook
			Streamlined the transparency code and made it setup and load the 
			region at start up then just set the region when a popup is created
 11/21/98 - Fahim Farook
			Added a working close button to the main popup when pinned
			Modified keyboard navigation so that left and right key functionality
			switches when the current folder is to the left of it's parent
 11/19/98 - Fahim Farook
			Modified popup displaying so that if a popup opens on the left all 
			subfolders will keep on opening to the left so as to avoid the
			clutter that resulted in earlier implementations
			Added the ability to specify colours instead of bitmaps for popup
			background via PopupTitleBack, PopupNormBack & PopupSelBack in
			step.rc
 11/18/98 - Fahim Farook
			Modified icon extraction based on code by Johan Redestig to make it
			more efficient and added an icon deletion routine when quitting to 
			free up resources.
 11/14/98 - Fahim Farook
			Added popup icons via ShowPopupIcons in step.rc and allowed customization
			via PopupDefaultIcon and PopupIconSize
 11/12/98 - Fahim Farook
			Added popup pinning functionality to the main popup and changed
			mouse click responses from LBUTTONDOWN to LBUTTONUP
 11/09/98 - Fahim Farook
			Merged in popup transparency code provided by mian and took out the
			old transparentBltLS stuff
 11/08/98 - Fahim Farook
			Added dynamic popup width sizing support & dynamic folder support
			via the !PopupDynamicFolder command
 11/08/98 - J Redestig
			Sets working directory. Added three utility functions for cleaner
			code (paintFolderArrow, paintPopupBevel, executeItem). Removed
			some flicker from displaySingleItem
 10/31/98 - Fahim Farook
			Added support for popup menu navigation via keyboard
 10/29/98 - Cyberian (Fahim Farook)
			Added support for popupmenu height customization. The title bar
			wouldn't change sizes earlier - now takes its value from PopupSubMenuHeight
			in step.rc
 09/11/98 - M. West
    		New popups created, limited functionality, will parse in a simple
    		1 layer popup menu, and run programs from it,
 30/10/98 - B. Kilian
			Fixed Fixed the popups repainting problem, and the setWindowPos 
			in the paint.
 30/10/98 - J Redestig
			Setforegroundwindow, so the popups get focus correctly, and <ESC> exits popups.
 30/10/98 - T Engel
			Environment substitution for !PopupFolders

****************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include <tchar.h>
#include <crtdbg.h>
#include <process.h>
#include "popup.h"

const char rcsRevision[] = "$Revision: 1.152a $"; // Our Version 
const char rcsId[] = "$Id: popup.cpp,v 1.152a 1999/08/18 00:00:00 murphy Exp $"; // The Full RCS ID.
char popupFontFace[256];
char popupMenuName[256];
const char szAppName[] = "PopupMenu"; // Our window class, etc
static char popupSig[4] = {'P', 'O', 'P', 'S'};
static LPCTSTR szClsId[] = {
	/* control panel */ 
	"{21EC2020-3AEA-1069-A2DD-08002B30309D}",
	/* network neighbourhood */
	"{208D2C60-3AEA-1069-A2D7-08002B30309D}",
	/* dial-up network */
	"{992CFFA0-F557-101A-88EC-00DD010CCC48}",
	/* my computer */
	"{20D04FE0-3AEA-1069-A2D8-08002B30309D}",
	/* last entry */
	NULL};
static LPCTSTR szExtToRemove[] = { ".lnk",
	".exe", ".pif", ".com", ".rnk", ".bat", ".cmd", NULL};

// timer data and timers
static timer submenuTimer(MENU_TIMER);
static timer scrollTimer(SCROLL_TIMER);

const cxGap = 4; // min. gap between icon and text
const cxArrow = 7; // width of folder arrow icon
const cyArrow = 7; // height of folder arrow icon

int popupSubHeight = 20;
int popupMinWidth = 100;
int popupIconSize = 20;
int titleHeight = 20;
int popupFixedWidth = 0;
int popupMenuDelay = 0;
int popupFontHeight;
int popupTextOffset;
int popupTop;

HFONT popupFont;
HICON popupDefaultIcon;
HICON taskDefaultIcon;
HICON emptyDefaultIcon;
BOOL useDesktopIni;

Popup popup; //popup class struct

HINSTANCE appInstance;
HWND itemCaller = NULL;
HWND parentWin;
HWND hMainWnd = NULL;
HPEN hpenBlack = NULL;
HPEN hpenWhite = NULL;
HPEN hpenGray = NULL;
HBRUSH hbrBlack = NULL;
HBRUSH hbrGray = NULL;

BOOL wentRight[255];
BOOL noPopupBevel;
BOOL noBottomBMP = FALSE;
BOOL transBlt=TRUE;
BOOL popupFolderIcon=TRUE;
BOOL showPopupIcons = FALSE;
BOOL isFixedWidth = FALSE;
BOOL shrinkPopupBar = FALSE;

BitMP popBMP;
BitMP backBMP;
BitMP titleBMP;
BitMP selectBMP;
BitMP bottomBMP;

enum Style {ps_colors, ps_itempic, ps_desktop, ps_fullpic};
Style popStyle;

FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

int fileSort(const void *a, const void *b);
////////////////////////////////////////////////////////////////////////////////
//BEGIN CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
// ** BitMP Class
BitMP::BitMP() {
	bitmap = NULL;
	region = NULL;
	name[0] = '\0';
	x = 0;
	y = 0;
	backColor = RGB(255,255,255);
	foreColor = RGB(255,255,255);
}

void BitMP::destroy() {
	if (bitmap) {
		DeleteObject(bitmap);
		bitmap = NULL;
	}
/*	if (region) {
		DeleteObject(region);
		region = NULL;
	}*/
	x = 0;
	y = 0;
	name[0] = '\0';
	backColor = RGB(255,255,255);
	foreColor = RGB(255,255,255);
}

// ** menuItem Class
menuItem::menuItem() {
	init();
}

menuItem::menuItem(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams, Popup *pop) {
	init();
	strcpy(name, lpszText);
	strcpy(command, lpszCommand);
	if (lpszParams != NULL)
		strcpy(params, lpszParams);
	sub = pop;
}

menuItem::~menuItem() {
	::DeleteObject(hIcon);
}

void menuItem::init() {
	owner = NULL;
	type = mi_basic;
	ZeroMemory(name, sizeof(name));
	ZeroMemory(command, sizeof(command));
	ZeroMemory(params, sizeof(params));
	hIcon = NULL;
	sub = NULL;
}

// ** list Class
template<class T> list<T>::list(int alloc, int inc) {
	allocated = 0;
	count = 0;
	increment = inc;
	data = NULL;
	reallocate(alloc);
}

template<class T> list<T>::~list() {
	if (data)
		delete [] data;
}

template<class T> void list<T>::reallocate(int num) {
	if (num <= 0 && count < allocated )
		return;
	T *pOldList = data;
	int inc = (num > 0) ? num : increment;
	_ASSERT(inc > 0);
	data = new T[allocated + inc];
	allocated += inc;
	// copy items from old list
	// since 'menuItem' class doesn't have any virtual functions,
	// we will use a direct memory copy
	memcpy(data, pOldList, sizeof(T)*count);
	delete [] pOldList;
	//for ( int i = 0; i < m_used; i++ )
	//   *(m_list[i]) = *(pOldList[i]);
}

template<class T> T& list<T>::operator [] (int i) {
	_ASSERT(data);
	_ASSERT(i >= 0);
	_ASSERT(i < count);
	return *(data+i);
}

template<class T> const T& list<T>::operator [] (int i) const {
	_ASSERT(data);
	_ASSERT(i >= 0);
	_ASSERT(i < count);
	return const_cast<const T&>(*(data+i));
}

template<class T> int list<T>::add(const T& t) {
	reallocate(); // allocate only if not enough room
	_ASSERT(data);
	_ASSERT(count >= 0);
	*(data+count) = t;
	count++;
	return(count-1);
}

template<class T> void list<T>::copy(const list<T>& l) {
	int tocopy = l.count;
	reallocate(tocopy);
	memcpy(data+count, l.data, tocopy*sizeof(T));
	count += tocopy;
}

template<class T> void list<T>::clear() {
	delete [] data;
	allocated = count = 0;
}

template<class T> void list<T>::sort(int(__cdecl *compare )(const void *elem1, const void *elem2 )) {
	qsort(data, count, sizeof(T), compare);
}

template<class T> bool list<T>::validIndex(int indx) const {
	if (indx < 0 || indx >= count)
		return false;
	return true;
}

// ** itemList Class
int itemList::add(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams, Popup *lp) {
 menuItem mi(lpszText, lpszCommand, lpszParams, lp);
 return list<menuItem>::add(mi);
}

// ** timer structure
void timer::setTimer(Popup *p, int indx, int interval) {
	killTimer();
	tmPop = p;
	tmNdx  = indx;
	if (tmPop && tmPop->hwnd) {
		::SetTimer(tmPop->hwnd, id, interval, NULL);
		timerSet = true;
	}
}

void timer::killTimer() {
	if (timerSet && tmPop && tmPop->hwnd)
		::KillTimer(tmPop->hwnd, id);
	timerSet = false;
//	tmPop = NULL;
//	tmNdx = -1;
}

bool timer::sameItem(Popup *p, int indx) const {
	if (tmPop == p && tmNdx == indx)
		return true;
	else
		return false;
}

// ** Popup Class
Popup::Popup(Popup *parentMenu) {
	hwnd = NULL;
	parent = parentMenu;
	ZeroMemory(title, sizeof(title));
	current = -1;
	first = last = -1;
	autoMenu = true;
	onLeft = FALSE;
}

Popup::~Popup() {
}

menuItem* Popup::safeItem(int indx) const {
	if (!this || !list.validIndex(indx))
		return NULL;
	return (menuItem*)&list[indx];
}

int Popup::firstVisible() {
	if (first < 0)
		first = 0;
	if (list.count > 0 && first >= list.count)
		first = list.count - 1;
	return first;
}

int Popup::lastVisible() {
	if (last < 0 || (list.count > 0 && last >= list.count))
		last = list.count - 1;
	return last;
}

void Popup::firstVisible(int n) {
	if ((first = n) < 0)
		first = 0;
}

void Popup::lastVisible(int n) { 
	if ((last = n) > list.count - 1)
		last = list.count - 1;
}

void Popup::scroll(bool down) {
	bool scrolled = false;
	if (down && lastVisible() < list.count - 1) {
		first++, last++;
		scrolled = true;
	} else if (firstVisible() > 0) {
		first--, last--;
		scrolled = true;
	}
	if (scrolled) {
	::InvalidateRect(this->hwnd, NULL, FALSE);
	::UpdateWindow(this->hwnd);
	}
}

bool Popup::createWindow() {
	if (hwnd)
		return true; // window already exists

	SIZE s;
	numVisible = calcSize(s);

	HWND hParent = parent? parent->hwnd : GetLitestepWnd();
	_ASSERT(hParent);
	hwnd = ::CreateWindowEx(
		WS_EX_TOPMOST|WS_EX_TOOLWINDOW, // exstyles
		szAppName,						// our window class name
		"LSPopup",								// use description for a window title
		WS_POPUP,						// window styles
		0, 0,							// position
		s.cx, s.cy,						// width & height of window
		hParent,						// parent window
		NULL,							// no menu
		appInstance,					// hInstance of DLL
		NULL);							// no window creation data
	if (hwnd) {
		::SetWindowLong(hwnd, GWL_USERDATA, magicDWord);
		LONG l;
		strncpy((char*)&l, popupSig, 4);
		::SetWindowLong(hwnd, 0, l);
		::SetWindowLong(hwnd, 4, (LONG)this);
		// set first/last visibles
		firstVisible(0);
		lastVisible(numVisible-1);
	} else
		_RPT1(_CRT_ERROR, "Failed to create POPUP window; error '%d'\n", ::GetLastError());
	return (bool)(hwnd != NULL);
}

void Popup::destroyWindow() {
	closeSubmenus();
	if (parent == NULL)  
		showWindow(false);
	else {
		::DestroyWindow(hwnd);
		hwnd = NULL;
	}
	current = -1;
}

void Popup::showWindow(bool show) {
	int nShowCmd = show ? SW_SHOW : SW_HIDE;
	::ShowWindow(hwnd, nShowCmd);
}

void Popup::openSubMenu(int indx) {
	if (!list.validIndex(indx)) {
		_RPT1(_CRT_ERROR, "open_submenu : invalid item index '%d'\n", indx);
		return;
	}
	menuItem& mi = list[indx];
	if (mi.type == menuItem::mi_basic) {
		_RPT1(_CRT_ERROR, "open_submenu : attempt to open non-submenu item '%d'\n", indx);
		return;
	}
	Popup *p = mi.sub;
	if (p) {
		if (p->hwnd != NULL) {
			p->destroyWindow();
		} else {
			p->createWindow();
			moveMenu(p, indx);
		}
	} else
		_RPT1(_CRT_ERROR, "open_submenu : no 'Popup' address at menu item '%d'\n", indx);
}

void Popup::display(int x, int y) {
	int h, w;
	int maxX = GetSystemMetrics(SM_CXSCREEN);
	int maxY = GetSystemMetrics(SM_CYSCREEN);
	RECT r;

	GetClientRect(this->hwnd, &r);
	h = r.bottom - r.top;
	w = r.right - r.left;
	x = (x+w) > maxX ? maxX - w : x;
	y = (y+h) > maxY ? maxY - h : y;
	GetRegion();
	if (transBlt && popStyle == ps_itempic) {
		HRGN tempRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(tempRgn, region, NULL, RGN_COPY);
		SetWindowRgn(hwnd, tempRgn, FALSE);
	}
	::SetWindowPos(hwnd, HWND_TOP, x, y, 0, 0, SWP_SHOWWINDOW | SWP_NOSIZE);
	::InvalidateRect(hwnd, NULL, FALSE);
	::UpdateWindow(hwnd);
}

void Popup::paint() {
	HDC hdc;
	HDC memDC;
	PAINTSTRUCT ps;
	HFONT hfntOld;
	HPEN hpenOld;
	RECT rcWnd, rc, rcTmp;
	POINT poly[3];
	int width, height;

	if (parent)
		strcpy(title, parent->list[parent->current].name);
	hdc = BeginPaint(hwnd, &ps);
	hfntOld = (HFONT)SelectObject(hdc, popupFont);
	SetBkMode(hdc, TRANSPARENT);
	GetClientRect(hwnd, &rcWnd);
	memDC = CreateCompatibleDC(hdc);
	HBITMAP bmpSave = (HBITMAP)GetCurrentObject(memDC, OBJ_BITMAP);
	if (popStyle == ps_desktop || popStyle == ps_fullpic) {
		GetWindowRect(hwnd, &rc);
		width = rcWnd.right - rcWnd.left;
		height = rcWnd.bottom - rcWnd.top;
		if (popStyle == ps_desktop)
			PaintDesktop(hdc);
		else
			paintBMP(hdc, memDC, popBMP, rcWnd);
//			paintBMP2(hdc, popBMP, rcWnd);
		hpenOld = (HPEN)SelectObject(hdc, hpenWhite);
		MoveToEx(hdc, 0, rcWnd.bottom-2, NULL);
		LineTo(hdc, 0, rcWnd.top);
		LineTo(hdc, rcWnd.right, rcWnd.top);
		SelectObject(hdc, hpenBlack);
		MoveToEx(hdc, 0, rcWnd.bottom-1, NULL);
		LineTo(hdc, rcWnd.right-1, rcWnd.bottom-1);
		LineTo(hdc, rcWnd.right-1, rcWnd.top-1);
		SelectObject(hdc, hpenOld);
	}
	if (IsRectEmpty(&ps.rcPaint))
		SetRect(&ps.rcPaint, rcWnd.left, rcWnd.top, rcWnd.right, rcWnd.bottom);
	SetRect(&rc, 0, 0, rcWnd.right, 0);
	// draw the title
	rc.bottom = titleHeight;
	if (IntersectRect(&rcTmp, &ps.rcPaint, &rc)) {
		SetBkColor(hdc, titleBMP.backColor );
		paintBMP(hdc, memDC, titleBMP, rc);
//		paintBMP2(hdc, titleBMP, rc);
		rc.left = popupTextOffset;
		SetTextColor(hdc, titleBMP.foreColor);
		DrawText(hdc, title, _tcslen(title), &rc,
			DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);
		rc.left = 0;
	}
	// draw individual menu items
	for (int indx = firstVisible(); indx <= first+numVisible-1; indx++) {
		const menuItem& mi = list[indx];
		rc.top    = rc.bottom;
		rc.bottom = rc.top + popupSubHeight;
		// check if need to repaint
		if (!IntersectRect(&rcTmp, &ps.rcPaint, &rc))
			continue;
		// determine colors and bitmap to use
		if (indx == current)
			drawItem(mi, hdc, memDC, selectBMP, rc);
		else
			drawItem(mi, hdc, memDC, backBMP, rc);
	}
	// draw the bottom bitmap
	if (bottomBMP.bitmap && !noBottomBMP) {
		GetClientRect(hwnd, &rc);
		rc.top  = rc.bottom - titleHeight;
		if (IntersectRect(&rcTmp, &ps.rcPaint, &rc)) {
			SetBkColor(hdc, bottomBMP.backColor);
			paintBMP(hdc, memDC, bottomBMP, rc);
//			paintBMP2(hdc, bottomBMP, rc);
		}
	}
	// paint scrolling buttons
	hpenOld = (HPEN)SelectObject(hdc, hpenBlack);
	if (firstVisible() > 0) {
		itemRect(firstVisible(), &rc);
		HBRUSH hbrOld = (HBRUSH)SelectObject(hdc, hbrGray);
		Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
		int xmid = rc.left + (rc.right-rc.left)/2;
		int ymid = rc.top + (rc.bottom-rc.top)/2;
		poly[0].x = xmid-4,
		poly[0].y = ymid+5,
		poly[1].x = xmid,
		poly[1].y = ymid-5,
		poly[2].x = xmid+4,
		poly[2].y = ymid+5;
		SelectObject(hdc, hbrBlack);
		Polygon(hdc, poly, 3);
		SelectObject(hdc, hbrOld);
	}
	if (lastVisible() < list.count-1) {
		itemRect(lastVisible(), &rc);
		HBRUSH hbrOld = (HBRUSH)SelectObject(hdc, hbrGray );
		Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
		int xmid = rc.left + (rc.right-rc.left)/2;
		int ymid = rc.top + (rc.bottom-rc.top)/2;
		poly[0].x = xmid-4,
		poly[0].y = ymid-5,
		poly[1].x = xmid,
		poly[1].y = ymid+5,
		poly[2].x = xmid+4,
		poly[2].y = ymid-5;
		SelectObject(hdc, hbrBlack);
		Polygon(hdc, poly, 3);
		SelectObject(hdc,  hbrOld);
	}
	// release resources
	SelectObject(hdc, hfntOld);
	SelectObject(hdc, hpenOld);
	SelectObject(memDC, bmpSave);
	DeleteDC(memDC);
	EndPaint(hwnd, &ps);
}

void Popup::paintBMP(HDC hDC, HDC memDC, BitMP bmp, RECT r) {
	int h = r.bottom - r.top;
	int w = r.right - r.left;

	if (popStyle == ps_colors || !bmp.bitmap) {
		ExtTextOut(hDC, r.left, r.top, ETO_OPAQUE, &r, NULL, 0, NULL);
		return;
	}
	SelectObject(memDC, bmp.bitmap);
	if (shrinkPopupBar) {
		StretchBlt(hDC, r.left, r.top, w, h, memDC, 0, 0, bmp.x, bmp.y, SRCCOPY);
	} else {
		int bW, bH;
		h = r.bottom;
		w = r.right;

		for(int x=r.left; x<w; x+=bmp.x)
			for(int y=r.top; y<h; y+=bmp.y) {
				bW = (x+bmp.x) <= w ? bmp.x : x < w ? w-x : w;
				bH = (y+bmp.y) <= h ? bmp.y : y < h ? h-y : h;
				BitBlt(hDC, x, y, bW, bH, memDC, 0, 0, SRCCOPY);
			}
	}
}

void Popup::paintBMP2(HDC hDC, BitMP bmp, RECT r) {
	HBITMAP oBMP;
	int h = r.bottom - r.top;
	int w = r.right - r.left;

	if (popStyle == ps_colors || !bmp.bitmap) {
		ExtTextOut(hDC, r.left, r.top, ETO_OPAQUE, &r, NULL, 0, NULL);
		return;
	}
	HDC mDC = CreateCompatibleDC(NULL);
	oBMP = (HBITMAP)SelectObject(mDC, bmp.bitmap);
	if (shrinkPopupBar) {
		StretchBlt(hDC, r.left, r.top, w, h, mDC, 0, 0, bmp.x, bmp.y, SRCCOPY);
	} else {
		int bW, bH;
		h = r.bottom;
		w = r.right;

		for(int x=r.left; x<w; x+=bmp.x)
			for(int y=r.top; y<h; y+=bmp.y) {
				bW = (x+bmp.x) <= w ? bmp.x : x < w ? w-x : w;
				bH = (y+bmp.y) <= h ? bmp.y : y < h ? h-y : h;
				BitBlt(hDC, x, y, bW, bH, mDC, 0, 0, SRCCOPY);
			}
	}
	SelectObject(mDC, oBMP);
	DeleteDC(mDC);
}

void Popup::drawItem(const menuItem& mi, HDC hdc, HDC mem, BitMP bmp, RECT rc) {
	COLORREF fg = bmp.foreColor;
	COLORREF bg = bmp.backColor;
	HBITMAP hbmp = bmp.bitmap;
	BOOL paint = (popStyle==ps_colors || popStyle==ps_itempic) ? TRUE : FALSE;

	SetBkColor(hdc, bg);
	if (paint)
		paintBMP(hdc, mem, bmp, rc);
//		paintBMP2(hdc, bmp, rc);
	if (showPopupIcons) {
		HICON hicon;
		//if (mi.type != menuItem::mi_basic)
		if ((mi.hIcon==NULL)&&(mi.type != menuItem::mi_basic))
			hicon = popupDefaultIcon;
		else
			hicon = mi.hIcon;
		if (hicon)
			// start murphy 19990818
			//DrawIconEx(hdc, rc.left+cxGap, (rc.top + rc.bottom - popupIconSize)/2,
			DrawIconEx(hdc, rc.left+popupTextOffset, (rc.top + rc.bottom - popupIconSize)/2,
			// end murphy 19990818
				hicon, popupIconSize, popupIconSize,
				0, NULL, DI_NORMAL);
	}
	// start murphy 19990818
	//int offset = max(popupIconSize + 2*cxGap, popupTextOffset );
	int offset = max(popupIconSize + cxGap+popupTextOffset, popupTextOffset );
	// end murphy 19990818
	rc.left += offset;
	SetTextColor(hdc, fg);
	DrawText(hdc, mi.name, _tcslen(mi.name), &rc,
		DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
	rc.left -= offset;
	// draw bevel
	if (!noPopupBevel && paint) {    
		HPEN hpenOld = (HPEN)::SelectObject(hdc, hpenWhite);
		MoveToEx(hdc, 0, rc.bottom-2, NULL);
		LineTo(hdc, 0, rc.top);
		LineTo(hdc, rc.right, rc.top);
		SelectObject(hdc, hpenBlack);
		MoveToEx(hdc, 0, rc.bottom-1, NULL);
		LineTo(hdc, rc.right-1, rc.bottom-1);
		LineTo(hdc, rc.right-1, rc.top-1);
		SelectObject(hdc, hpenOld);
	}
	// draw folder arrow
	if (popupFolderIcon && mi.type != menuItem::mi_basic) {
		POINT pt[3];
		pt[0].x = rc.right - cxGap - cxArrow,
		pt[0].y = (rc.bottom + rc.top + cyArrow) / 2 + 1,
		pt[1].x = rc.right - cxGap - cxArrow,
		pt[1].y = (rc.bottom + rc.top - cyArrow) / 2 - 1,
		pt[2].x = rc.right - cxGap,
		pt[2].y = (rc.bottom + rc.top) / 2;

		HPEN hpenOld = (HPEN)::SelectObject(hdc, hpenGray);
		MoveToEx(hdc, pt[0].x, pt[0].y, NULL);
		LineTo(hdc, pt[1].x, pt[1].y);
		LineTo(hdc, pt[2].x, pt[2].y);    
		SelectObject(hdc, hpenWhite);
		LineTo(hdc, pt[0].x, pt[0].y);
		SelectObject(hdc, hpenOld);
	}
}

bool Popup::itemRect(int indx, RECT *lpRect) const {
	if (!lpRect)
		return false;
	::SetRectEmpty(lpRect);
	if (!list.validIndex(indx))
		return false;
	if (indx < first || indx > last)
		return false;
	::GetClientRect(hwnd, lpRect);
	// start right below title bitmap
	lpRect->top = titleHeight;
	// skip all preceding menu items
	for (int i = first; i < indx; i++)
		lpRect->top += popupSubHeight;
	// set bottom value
	lpRect->bottom = lpRect->top + popupSubHeight;
	return true;
}

int Popup::calcSize(SIZE& s) const {
	int i, h;
	int n = 0; //number of items to return
	int hmax = GetSystemMetrics(SM_CYSCREEN);
	int wmax = GetSystemMetrics(SM_CXSCREEN);
	HDC hdc;
	HFONT holdFont;
	SIZE ext;

	s.cx = isFixedWidth ? popupFixedWidth : 0;  // accumulated width
	s.cy = 0;									// accumulated height
	h = popupSubHeight;
	s.cy += !noBottomBMP ? titleHeight*2 : titleHeight;
	hdc = CreateDC("DISPLAY", NULL, NULL, NULL);
	holdFont = (HFONT)SelectObject(hdc, popupFont);
	for (i = 0; i < list.count; i++ ) {
		const menuItem& mi = list[i];
		if (!isFixedWidth)
			if (GetTextExtentPoint32(hdc, mi.name, strlen(mi.name), &ext))
				s.cx = max(s.cx, ext.cx);
		if (n == 0) {
			if ((s.cy + h) > hmax)
				n = i; // number of items to fit into the height
			else
				s.cy += h;
		}
	}
	if (n == 0)
		n = i;
	SelectObject(hdc, holdFont);
	DeleteDC(hdc);
	s.cx += max(popupIconSize + 2*cxGap, popupTextOffset);
	s.cx += 2*cxGap + cxArrow;
	if (s.cx > wmax)
		s.cx = wmax;
	if (s.cx < popupMinWidth)
		s.cx = popupMinWidth;
	return n;
}

int Popup::itemAt(POINT pt) const {
	if (!hwnd)
		return -1;
	RECT rc;
	::GetClientRect(hwnd, &rc);
	if (!::PtInRect(&rc, pt))
		return -1;
	// check for title hit
	int h = 0; // total (accumulated) height
	int h2;    // height of individual item
	h += titleHeight;
	if (pt.y < h)
		return -1;
	// scan all items
	for (int i = first; i <= last; i++) {
		h2 = popupSubHeight;
		if (pt.y < h + h2 + 1)
			return i;
		h += h2;
	}
	return -1;
}

bool Popup::highlight(int indx, bool snapCursor) {
	// if indx is out of scope we'll only remove highlight from
	// currently selected item
	RECT rc;
	int old;
	bool valid = true;

	old = current;
	current = indx;
	// if current item out of view, scroll to bring it
	// to view
	if (current >= 0 && current < firstVisible()) {
		firstVisible(current - 1);
		lastVisible(firstVisible() + (numVisible-1));
		::InvalidateRect(hwnd, NULL, FALSE);
	} else
		if (current > lastVisible() && current <= list.count-1) {
			lastVisible(current+1);
			firstVisible(lastVisible() - (numVisible-1));
			::InvalidateRect(hwnd, NULL, FALSE);
		} else {
			if (itemRect(old, &rc))
				::InvalidateRect(hwnd, &rc, FALSE);
			if (true == (valid = itemRect(current, &rc )))
				::InvalidateRect(hwnd, &rc, FALSE );
		}
	if (snapCursor && valid) {
		itemRect(current, &rc);
		rc.top  += 2,
		rc.left += 2;
		::ClientToScreen(hwnd, (POINT*)&rc);
		::SetCursorPos(rc.left, rc.top);
	}
	::UpdateWindow(hwnd);
	return true;
}

int Popup::hittest(POINT pt, int *pindx) const {
	RECT rc;
	::GetClientRect(hwnd, &rc);
	if (!::PtInRect(&rc, pt))
		return HTNOWHERE;
	int indx = -1;
	int h = 0;
	int h2;

	h += titleHeight;
	do {
		if (pt.y < h)
			break;
		if (++indx >= list.count)
			break;
		h2 = popupSubHeight;
		h += h2;
	} while(true);
	if (indx < 0) {
		if (pindx) 
			*pindx = -1;
		return HTCAPTION;
	}
	if (indx >= list.count) {
		if (pindx) 
			*pindx = -1;
		return HTCAPTION;
	}
	if (pindx) 
		*pindx = indx;
	return HTCLIENT;
}

void Popup::moveMenu(Popup *sub, int indx) {
	if (!sub || !sub->hwnd) {
		_RPT1( _CRT_ERROR, "position_submenu : submenu address//handle is invalid\n", indx );
		return;
	}
	if (!list.validIndex(indx)) {
		_RPT1( _CRT_ERROR, "position_submenu : invalid item index '%d'\n", indx );
		return;
	}

	RECT rc;
	RECT rcSub;
	RECT rcThis;
	RECT rcDesk;
	POINT pt = {0, 0};
	bool right = !onLeft;
	int w, h; // submenu width & height
	int lspace, rspace; // free space to left & right of menu

	::GetClientRect(sub->hwnd, &rcSub);
	::GetWindowRect(hwnd, &rcThis);
	::SystemParametersInfo(SPI_GETWORKAREA, 0, (void*)&rcDesk, 0);

	w = rcSub.right - rcSub.left;
	h = rcSub.bottom - rcSub.top;
	lspace = rcThis.left - rcDesk.left;
	rspace = rcDesk.right - rcThis.right;
	enum _dir {dir_undef, dir_left, dir_right} 
		dir = dir_undef;
	switch(right) {
	case true :
		if (rspace >= w) 
			dir = dir_right;
		break;
	case false :
		if (lspace >= w)
			dir = dir_left;
		break;
	}
	if (dir == dir_undef)
	switch((bool)(!right)) {
	case true :
		if (rspace >= w) 
			dir = dir_right;
		break;
	case false :
		if (lspace >= w)
			dir = dir_left;
		break;
	}
	if (dir == dir_undef) {
		if (rspace > lspace) 
			dir = dir_right;
		if (lspace > rspace)
			dir = dir_left;
	}
	if (dir == dir_undef)
		dir = right ? dir_right : dir_left;
	if (itemRect(indx, &rc)) {
		pt.y = rc.top;
		pt.x = dir==dir_right ? rc.right : rc.left - w;
		::ClientToScreen(hwnd, &pt);
		pt.y -= titleHeight;
		if (pt.y + h > rcDesk.bottom)
			pt.y -= pt.y + h - rcDesk.bottom;
		if (pt.y < 0) 
			pt.y = 0;
		if (pt.x < 0) 
			pt.x = 0;
	}
	sub->onLeft = (bool)(dir == dir_left);
	sub->display(pt.x, pt.y);
}

void Popup::closeSubmenus(Popup *stay) {
	if (!stay)
		stay = this;
	for (int i = 0; i < list.count; i++) {
		Popup *p = list[i].sub;
		if (p && p != stay) {
			p->closeSubmenus(stay);
			if (list[i].type == menuItem::mi_dynamic || list[i].type == menuItem::mi_tasks) {
				list[i].sub = NULL;
				delete p;
			}
		}
	}
	if (stay != this)
		destroyWindow();
}

bool Popup::execute(int indx) {
	if (indx < 0)
		indx = current;
	if (!list.validIndex(indx))
		return false;

	const menuItem& mi = list[indx];
	if (mi.type != menuItem::mi_basic) {
		const Popup *pop = mi.sub;
		if (pop && isPopupWnd(pop->hwnd))
			return true;
	}
	bool retval = true;
	switch (mi.type) {
	case menuItem::mi_basic :
		if (!stricmp(mi.command, "t@sk")) {
			windowType *winList;
			HWND hwnd;
			char title[MAX_PATH];
			int maxWin;

			winList = (windowType *)SendMessage(parentWin, LM_WINLIST, 0, 0);
			maxWin = (int) SendMessage(parentWin, LM_WINLIST, 1, 0);
			for (int n = 0; n < maxWin && winList[n].Handle; n++) {
				hwnd = winList[n].Handle;
				GetWindowText(hwnd, (char *)&title, MAX_PATH);
				if (!strcmp(mi.name, (char *)&title)){
					if (IsIconic(hwnd))
						//OpenIcon(hwnd);
						SwitchToThisWindow(hwnd, 1);
					SetForegroundWindow(hwnd);
					break;
				}
			}
		} else if (mi.command[0] != '!') {
			SHELLEXECUTEINFO si;
			char workDirectory[MAX_PATH];
			char drive[_MAX_DRIVE];
			char dir[_MAX_DIR];
			char fname[_MAX_FNAME]; // not used
			char ext[_MAX_EXT]; // not used

			_splitpath(mi.command, drive, dir, fname, ext);
			strcpy(workDirectory, drive);
			strcat(workDirectory, dir);
			memset(&si, 0, sizeof(si));
			si.cbSize = sizeof(SHELLEXECUTEINFO);
			if(stricmp(ext, ".lnk") == 0)
				si.lpDirectory = NULL;
			else
				si.lpDirectory = workDirectory;
			si.lpVerb = NULL;
			si.nShow = 1;
			si.fMask = SEE_MASK_DOENVSUBST;
			si.lpFile = mi.command;
			si.lpParameters = mi.params;

			if (!ShellExecuteEx( &si )) {
				_RPT2(_CRT_ERROR, "Failed to execute item '%d' - error '%d'\n", indx, ::GetLastError());
				retval = false;
			}
		} else
			::ParseBangCommand(hwnd, (char *)mi.command, (char *)mi.params);
		popup.destroyWindow();
		break;
	case menuItem::mi_folder :
	case menuItem::mi_static :
		openSubMenu(indx);
		break;
	case menuItem::mi_dynamic:
		openDynamic(indx);
		break;
	case menuItem::mi_tasks:
		showTasks(indx);
		break;
	default :
		retval = false;
		break;
	}
	return retval;
}

bool Popup::isPopupWnd(HWND hwnd) {
	if (::IsWindow(hwnd)) {
		LONG l = ::GetWindowLong(hwnd, 0);
		if (0 == strncmp((char*)&l, popupSig, 4)) {
			return true;
		}
	}
	return false;
}

void Popup::openDynamic(int indx, bool dynamic) {
	if (!list.validIndex(indx)) {
		_RPT1(_CRT_ERROR, "openDynamic : invalid item index '%d'\n", indx);
		return;
	}

	menuItem& mi = list[indx];
	if (mi.sub) {
		_RPT1(_CRT_ERROR, "openDynamic : menu item data is not NULL at index '%d'\n", indx );
		return;
	}

	char path[MAX_PATH] = {0};
	int n = ::ExpandEnvironmentStrings(mi.command, path, MAX_PATH);
	if (n == 0) {
		_RPT1(_CRT_ERROR, "open_filefolder : failed to expand directory path; error %d\n", ::GetLastError());
		return;
	}
	if (n > MAX_PATH) {
		_RPT1(_CRT_ERROR, "open_filefolder : expansion buffer too small; required %d chars\n", n);
		return;
	}

	WIN32_FIND_DATA fd;
	HANDLE h;
	int i;
	Popup *pop = new Popup(this);

	strcat(path, "\\*");
	h = FindFirstFile(path, &fd);
	if (h == INVALID_HANDLE_VALUE) {
		i = pop->list.add("Invalid", "!none");
		pop->list[i].owner = pop;
		mi.sub = pop;
		return;
	}

	itemList dirs, files;
	char path2[MAX_PATH];
	do {
		if (fd.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)
			continue;
		if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, ".."))
			continue;
		wsprintf(path2, "%s\\%s", mi.command, fd.cFileName);
		if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			if (0 <= (i = dirs.add(fd.cFileName, path2))) {
				dirs[i].type = dynamic ? menuItem::mi_dynamic : menuItem::mi_static;
				if (useDesktopIni) {
					char szFullPath[MAX_PATH];

					strcpy(szFullPath, path2);
					strcat(szFullPath,"\\");
					dirs[i].hIcon= LoadLSIcon(szFullPath,NULL);
				}
			}
		} else {
			for (i = 0; szExtToRemove[i] != NULL; i++) {
				int p = strlen(fd.cFileName) - strlen(szExtToRemove[i]);
				if (!stricmp(fd.cFileName + p, szExtToRemove[i])) {
					fd.cFileName[p] = '\0';
					break;
				}
			}
			if (0 <= (i = files.add(fd.cFileName, path2)))
				getIcon(files[i], gi_shell);
		}
	} while (FindNextFile(h, &fd));
	FindClose(h);
	dirs.sort(fileSort);
	files.sort(fileSort);
	if (dirs.count == 0 && files.count == 0)
	{
		pop->list.add("Empty", "!none");
		pop->list[0].hIcon=emptyDefaultIcon;
	} else {
		pop->list.copy(dirs);
		pop->list.copy(files);
	}
	for (i = 0; i < pop->list.count; i++) {
		pop->list[i].owner = pop;
		if (!dynamic && pop->list[i].type == menuItem::mi_static) {
			pop->openDynamic(i, false);
		}
	}
	mi.sub = pop;
	strcpy(pop->title, mi.name);
	if (dynamic)
		openSubMenu(indx);
}

void Popup::showTasks(int indx) {
	if (!list.validIndex(indx)) {
		_RPT1(_CRT_ERROR, "showTasks : invalid item index '%d'\n", indx);
		return;
	}
	menuItem& mi = list[indx];
	if (mi.sub) {
		_RPT1(_CRT_ERROR, "showTasks : menu item data is not NULL at index '%d'\n", indx );
		return;
	}

	Popup *pop = new Popup(this);
	windowType *winList;
	char title[MAX_PATH];
	BOOL noList = TRUE;
	int n, maxWin, i;

	winList = (windowType *)SendMessage(parentWin, LM_WINLIST, 0, 0);
	maxWin = (int) SendMessage(parentWin, LM_WINLIST, 1, 0);
	for (n = 0; n < maxWin && winList[n].Handle; n++) {
		HICON hIcon = NULL;
		noList = FALSE;

		SendMessageTimeout(winList[n].Handle, WM_GETICON, 1, 0, 0, 250, (unsigned long *)&hIcon);
		if (!hIcon) 
			SendMessageTimeout(winList[n].Handle, WM_QUERYDRAGICON, 0, 0, 0, 1000, (unsigned long *)&hIcon);
		if (!hIcon) 
			hIcon = (HICON)GetClassLong(winList[n].Handle, GCL_HICON);
		if (!hIcon) 
			hIcon = (HICON)GetClassLong(winList[n].Handle, GCL_HICONSM);
		if (!hIcon)
			hIcon = taskDefaultIcon;
		title[0] = 0;
		if (winList[n].Handle != NULL) {
			GetWindowText(winList[n].Handle, (char *)&title, MAX_PATH);
			i = pop->list.add(title, "T@sk");
			pop->list[i].owner = pop;
			pop->list[i].hIcon = hIcon;
			pop->list[i].type = menuItem::mi_basic;
		}
	}
	if (noList) {
		i = pop->list.add("No Tasks", "!none");
		pop->list[i].owner = pop;
		pop->list[i].type = menuItem::mi_basic;
		pop->list[i].hIcon = emptyDefaultIcon;
	}
	mi.sub = pop;
	strcpy(pop->title, mi.name);
	openSubMenu(indx);
}

void Popup::getIcon(menuItem& mi, BYTE flags) {
	if (mi.type != menuItem::mi_basic)
		return;
	if (flags == 0) {
		mi.hIcon = NULL;
 		return;
	}
	
	HICON hicon = NULL;
	char file[MAX_PATH] = { 0 };
	char cmd[MAX_PATH];
	char prm[MAX_PATH];
	int i;

	::ExpandEnvironmentStrings(mi.command, cmd, MAX_TOKEN);
	::ExpandEnvironmentStrings(mi.params, prm, MAX_TOKEN);
	if (flags & gi_clsid) {
		for (i = 0; szClsId[i] != NULL; i++) {
			strcpy(file, prm);
			strupr(file);
			if (strstr(file, szClsId[i])) {
				char szKey[MAX_PATH];
				wsprintf(szKey, "CLSID\\%s\\DefaultIcon", szClsId[i]);
				file[0] = 0; // to retreive default value
				registryLookup(szKey, file);
				break;
			}
		}
		if (file[0] != 0) {
			char icon[MAX_PATH];
			strcpy(icon, ".extract=");
			if (NULL == strchr(file, '\\')) {
				char dir[MAX_PATH];
				if (strstr(file, "explorer"))
					::GetWindowsDirectory(dir, MAX_PATH);
				else
					::GetSystemDirectory(dir, MAX_PATH);
				strcat(icon, dir);
				strcat(icon, "\\");
			}
			strcat(icon, file);
			hicon = ::LoadLSIcon(icon, NULL);
		}
	}
	if (!hicon && (flags & gi_shell)) {
		SHFILEINFO shf;

		::SHGetFileInfo(cmd, NULL, &shf, sizeof(shf), SHGFI_ICON|SHGFI_SMALLICON);
		if ((hicon = shf.hIcon) == NULL) {
			_searchenv(cmd, "PATH", file);
			if (file[0] != 0) {
				::SHGetFileInfo(file, NULL, &shf, sizeof(shf), SHGFI_ICON|SHGFI_SMALLICON);
				hicon = shf.hIcon;
			}
		}
	}
	mi.hIcon = hicon;
}

void Popup::registryLookup(char* subKey, char *value) {
	char regData[256];
	int regSize = 256;
	LONG res;
	HKEY hOpen;

	RegOpenKeyEx(HKEY_CLASSES_ROOT, subKey, 0, KEY_READ, &hOpen);
	res = RegQueryValueEx(hOpen, value, NULL, NULL, (LPBYTE)regData, (LPDWORD)&regSize);
	if (res == ERROR_SUCCESS)
		strcpy(value, regData);
	else
		strcpy(value, "");
	RegCloseKey(hOpen);
}

void Popup::loadValues() {
	char iname[MAX_TEXT];
	BOOL useDeskImage;

    GetRCString("HotListName", popup.title, "", 256);
	useDeskImage = GetRCBool("PopupUseDeskImage", TRUE);
	GetRCString("PopupBackImage", popBMP.name, "", 256);
    GetRCString("PopupTitlePix", titleBMP.name, "", 256);
    GetRCString("PopupEntryPix", backBMP.name, "", 256);
    GetRCString("PopupSelEntryPix", selectBMP.name	, "", 256);
	GetRCString("PopupBottomPix", bottomBMP.name, "", 256);
    GetRCString("PopupFontFace", popupFontFace, "Arial", 256);
	// decide on the Popup style
	if (useDeskImage)
		popStyle = ps_desktop;
	else if (!strlen(popBMP.name)==0)
		popStyle = ps_fullpic;
	else if (!strlen(titleBMP.name)==0 && !strlen(backBMP.name)==0 && !strlen(selectBMP.name)==0)
		popStyle = ps_itempic;
	else
		popStyle = ps_colors;
	popupFolderIcon = GetRCBool("NoPopupFolderIcon", FALSE);
	transBlt = GetRCBool("NoPopupTransparent", FALSE);
    noPopupBevel = GetRCBool("NoPopupBevel", TRUE);
    popupFontHeight = GetRCInt("PopupFontHeight", 16);
    titleBMP.foreColor = GetRCColor("PopupTitleColor", 0xffffff);
    bottomBMP.foreColor = GetRCColor("PopupTitleColor", 0xffffff);
    backBMP.foreColor = GetRCColor("PopupEntryColor", 0x000000);
    selectBMP.foreColor = GetRCColor("PopupSelEntryColor", 0x000000);
	popupMenuDelay = GetRCInt("PopupMenuDelay", 10);
    popupMinWidth = GetRCInt("minpopupwidth", 100);
    popupSubHeight = GetRCInt("PopupSubmenuHeight", 20);
	titleHeight = GetRCInt("PopupSubmenuHeight", 20);
	popupFixedWidth = GetRCInt("PopupFixedWidth", 0);
	isFixedWidth = popupFixedWidth==0?FALSE:TRUE;
	popupTextOffset = GetRCInt("PopupTextOffset", 5);
	showPopupIcons = GetRCBool("ShowPopupIcons", TRUE);
	if (showPopupIcons) {
		popupIconSize = GetRCInt("PopupIconSize", 20);
		GetRCString("PopupDefaultIcon", iname, "default.ico", 256);
		popupDefaultIcon = LoadLSIcon(iname, NULL);
		GetRCString("PopupTaskDefaultIcon", iname, "task.ico", 256);
		taskDefaultIcon = LoadLSIcon(iname, NULL);
		GetRCString("PopupEmptyDefaultIcon", iname, "empty.ico", 256);
		emptyDefaultIcon = LoadLSIcon(iname, NULL);
		useDesktopIni = GetRCBool("PopupUseDesktopIni", TRUE);
		popupIconSize = popupIconSize>popupSubHeight?popupSubHeight:popupIconSize;
		popupTop = (popupSubHeight-popupIconSize)/2;
	} else 
		popupIconSize = 0;
	//Bitmap shrink/tile option
	shrinkPopupBar = GetRCBool("ShrinkPopupBar", TRUE);
	// Bottom bitmap is loaded as there is no setting to indicate whether it is drawn or not - yet ...
	if (strlen(bottomBMP.name) == 0)
		noBottomBMP = TRUE;
	else {
		noBottomBMP = FALSE;
		bottomBMP.bitmap = LoadLSImage(bottomBMP.name, NULL);
		GetLSBitmapSize(bottomBMP.bitmap, &bottomBMP.x, &bottomBMP.y);
		bottomBMP.region = BitmapToRegion(bottomBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0); 
	}
    titleBMP.bitmap = LoadLSImage(titleBMP.name, NULL);
    GetLSBitmapSize(titleBMP.bitmap, &titleBMP.x, &titleBMP.y);
	titleBMP.region = BitmapToRegion(titleBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
	if (popStyle == ps_itempic) {
	    //loads up images i will eventualy seperate this into its own function
		backBMP.bitmap = LoadLSImage(backBMP.name, NULL);
		selectBMP.bitmap = LoadLSImage(selectBMP.name, NULL); 
	    GetLSBitmapSize(selectBMP.bitmap, &selectBMP.x, &selectBMP.y);
		GetLSBitmapSize(backBMP.bitmap, &backBMP.x, &backBMP.y);
		//mian's transparency stuff
		selectBMP.region = BitmapToRegion(selectBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		backBMP.region = BitmapToRegion(backBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
	} else if (popStyle == ps_fullpic) {
		popBMP.bitmap = LoadLSImage(popBMP.name, NULL);
	    GetLSBitmapSize(popBMP.bitmap, &popBMP.x, &popBMP.y);
	}
	titleBMP.backColor = GetRCColor("PopupTitleBack", 0x000000);
	bottomBMP.backColor = GetRCColor("PopupTitleBack", 0x000000);
	backBMP.backColor = GetRCColor("PopupNormalBack", 0xa4a0a0);
	selectBMP.backColor = GetRCColor("PopupSelBack", 0xffffff);
	// Stock objects
	hpenBlack = (HPEN)GetStockObject(BLACK_PEN);
	hpenWhite = (HPEN)GetStockObject(WHITE_PEN);
	hpenGray = (HPEN)CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
	hbrBlack = (HBRUSH)GetStockObject(BLACK_BRUSH);
	hbrGray = (HBRUSH)GetStockObject(GRAY_BRUSH);
    popupFont = CreateFont(popupFontHeight,
    		0, 0, 0, FW_NORMAL,
    		FALSE, FALSE, FALSE,
    		DEFAULT_CHARSET,
    		OUT_DEFAULT_PRECIS,
    		CLIP_DEFAULT_PRECIS,
    		DEFAULT_QUALITY,
    		DEFAULT_PITCH,
    		popupFontFace);
	loadMenus();
}

void Popup::loadMenus() {
    char buffer[MAX_TOKEN];
    char token1[MAX_TOKEN], token2[MAX_TOKEN], token3[MAX_TOKEN];
    char token4[MAX_TOKEN], extra[MAX_TOKEN];
    char* tokens[4];
    int count;
	bool itemOK, folderEnd;
	LPSTR lpszText, lpszCommand, lpszParams;
	int indx;
	Popup *pop = &popup; // address of the menu being currently created
	menuItem *pItem;
	menuItem::itemType mtype;
	char szFullPath[MAX_PATH];
    
    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;
    tokens[3] = token4;

    buffer[0] = '\0';
	FILE *f = LCOpen(NULL);
    
    while (LCReadNextConfig (f, "*popup", buffer, sizeof (buffer)))
    {
    	token1[0] = token2[0] = token3[0] = token4[0] = extra[0] = '\0';
		lpszText = lpszCommand = lpszParams = NULL;
		itemOK = true;
		folderEnd = false;
		
    	count = LCTokenize (buffer, tokens, 4, extra);
		if (strnicmp (token2, ".icon", strlen (".icon")))
    	count = LCTokenize (buffer, tokens, 3, extra);
		else
			strcpy (token2, token2 + strlen (".icon="));
    	// *Popup name action
    	// *Popup name action params
		// *Popup .icon=icon.ico name action params
    	switch (count) {
    	case 4: 
    		lpszText = token3;
    		lpszCommand = token4;
    		lpszParams = extra;
    		break; 

    	case 3:
    		lpszText = token2;
    		lpszCommand = token3;
    		lpszParams = extra;
    		break;

    	case 2:
    		if (!stricmp(token2, "~Folder"))
    			folderEnd = true;
    		break;

    	default:
    		itemOK = false;
    		break;
    	}
		if (!itemOK) {
			_RPT0(_CRT_ERROR, "\tMenu item is invalid!\n");
			continue;
		}
		if (folderEnd) {
			pop = pop->parent;
			if (!pop)
				// No parent?
				break;
			continue;
		}
		mtype = menuItem::mi_basic;
		if (!stricmp(lpszCommand, "Folder"))
			mtype = menuItem::mi_folder;
		else if (!strnicmp(lpszCommand, "!PopupFolder", 12)) {
			mtype = menuItem::mi_static;
			lpszCommand += 13; // "!PopupFolder"+":"
		} else if (!strnicmp(lpszCommand, "!PopupDynamicFolder", 19)) {
			mtype = menuItem::mi_dynamic;
			lpszCommand += 20; // "!PopupDynamicFolder"+":"
		} else if (!strnicmp(lpszCommand, "!PopupTasks", 11)) {
			mtype = menuItem::mi_tasks;
			//lpszCommand += 20;
		}
		indx = pop->list.add(lpszText, lpszCommand, lpszParams);
		pItem = pop->safeItem(indx);
		_ASSERT(pItem);
		pItem->owner = pop;
		pItem->type = mtype;

		switch (mtype) {
		case menuItem::mi_folder :
			pop = new Popup(pop);
			strcpy(pop->title, lpszText);
			pItem->sub = pop;
			break;
		case menuItem::mi_static :
			// static folder generation
			pop->openDynamic(indx, false);
			if (useDesktopIni) {
				strcpy(szFullPath, lpszCommand);
				strcat(szFullPath,"\\");
				pop->list[indx].hIcon= LoadLSIcon(szFullPath,NULL);
			}
			break;
		case menuItem::mi_dynamic :
			if (useDesktopIni) {
				strcpy(szFullPath, lpszCommand);
				strcat(szFullPath,"\\");
				pop->list[indx].hIcon= LoadLSIcon(szFullPath,NULL);
			}
			break;
		case menuItem::mi_tasks :
			// dynamic expansion of items
			break;
		case menuItem::mi_basic :
			getIcon(*pItem);
			break;
		default :
			break;
		}
		if (count==4) {
			if (pItem->hIcon!=NULL)
				::DeleteObject(pItem->hIcon);
			pItem->hIcon = ::LoadLSIcon(token2, NULL);
		}
    }		
    LCClose(f);
}

void Popup::GetRegion() {
	HRGN clipRgn;
	int height = titleHeight;

	region = CreateRectRgn(0, 0, 0, 0);
	CombineRgn(region, region, titleBMP.region, RGN_OR);
	for (int indx = firstVisible(); indx <= first+numVisible-1; indx++) {
//		const menuItem& mi = list[indx];
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, backBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(region, region, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
		height = height + popupSubHeight;
	}
	if (bottomBMP.bitmap) {
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, bottomBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(region, region, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
	}
}

////////////////////////////////////////////////////////////////////////////////
//END CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
// window procedure for our window
LRESULT CALLBACK wndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	Popup *pop = (Popup*)::GetWindowLong(hwnd, 4);

	if (!pop)
		return ::DefWindowProc(hwnd, message, wParam, lParam);

	const menuItem *pItem;
	int indx;
	POINT pt, pts;
	LONG l;
	bool onScroll = false;

	l = ::GetMessagePos();
	pt.x = pts.x = LOWORD(l);
	pt.y = pts.y = HIWORD(l);
	::ScreenToClient(pop->hwnd, &pt);
	indx = pop->itemAt(pt);
	pItem = pop->safeItem(indx);
	if ((indx == pop->firstVisible() && indx > 0) ||
	(indx == pop->lastVisible()  && indx < pop->list.count-1))
		onScroll = true;

	switch (message) {
	case LM_GETREVID: 
	{
		char *buf = (char *) lParam;

		if (wParam == 0) {
			strcpy(buf, "popup.dll: ");
			strcat(buf, &rcsRevision[11]);
			buf[strlen(buf)-1] = '\0';
		} else if (wParam == 1) {
			strcpy(buf, &rcsId[1]);
			buf[strlen(buf)-1] = '\0';
		} else {
			strcpy(buf, "");
		}
		return strlen(buf);
	}

	case LM_POPUP :
		pop->display(pts);
		::SetForegroundWindow(pop->hwnd);
		return 0;

	case WM_PAINT :
		pop->paint();
		return 0;

	case WM_ERASEBKGND :
		return 0;

	case WM_LBUTTONDOWN :
		// scrolling support: set timer
		// have to do it before "execute", 'cause
		// first and last visible may change
		if (onScroll)
			scrollTimer.setTimer(pop, indx, SCROLL_DELAY);
		pop->autoMenu = true;
		break;

	case WM_LBUTTONUP :
		scrollTimer.killTimer();
		if (!onScroll)
			pop->execute(indx);
		break;

	case WM_MOUSEMOVE :
	{
		if (pop->current != indx)
			pop->highlight(indx, false);
		bool other = !submenuTimer.sameItem(pop, indx);
		bool folder = (bool)(pItem && pItem->type != menuItem::mi_basic);
		if (!pItem || other ) {
			submenuTimer.killTimer();
			pop->closeSubmenus();
		}
		if (other)
			if (folder) {
				if (pop->autoMenu)
					submenuTimer.setTimer(pop, indx, popupMenuDelay);
			} else
				submenuTimer.resetIndex();
		break;
	}

	case WM_TIMER :
		switch (wParam) {
		case MENU_TIMER :
		{
			submenuTimer.killTimer();
			pop->execute(indx);
			break;
		}
		case SCROLL_TIMER :
			pop->scroll((bool)(indx == pop->lastVisible()));
			break;
		}
		break;

	case WM_NCHITTEST :
	{
		int ht = pop->hittest(pt);
		return ht;
		break;
	}

	case WM_ACTIVATE :
		if (LOWORD(wParam) == WA_INACTIVE) {
			HWND hwndGetFocus = (HWND)lParam;
			if (!pop->isPopupWnd(hwndGetFocus)) {
				submenuTimer.killTimer();
				popup.destroyWindow();
				return 0;
			}
		}
		break;

	case WM_SYSCOMMAND :
		if (wParam == SC_CLOSE) {
			::PostMessage(GetLitestepWnd(), WM_KEYDOWN, LM_SHUTDOWN, 0);
			return 0;
		}
		break;

	case WM_KEYDOWN :
	switch (wParam) {
	case VK_DOWN :
		// start murphy 19990818
		pop->autoMenu = false;
		// end murphy 19990818
		if ((pop->current) < (pop->list.count-1))
			pop->highlight(pop->current+1, true);
		else 
			pop->highlight(0, true);
		break;

	case VK_UP :
		// start murphy 19990818
		pop->autoMenu = false;
		// end murphy 19990818
		if ((pop->current) > 0)
			pop->highlight(pop->current-1, true);
		else
			pop->highlight(pop->list.count-1, true);
		break;

	case VK_HOME :
		pop->highlight(0, true);
		break;

	case VK_END :
		pop->highlight(pop->list.count-1, true);
		break;

	case VK_NEXT :
	{
		int c = pop->current;
		int lv = pop->lastVisible();
		if ( lv < pop->list.count-1) 
			lv--;
		if (c < lv)
			c = lv;
		else
			if ((c += pop->numVisible-1) > pop->list.count-1)
				c = pop->list.count-1;
		pop->highlight(c, true);
		break;
	}

	case VK_PRIOR :
	{
		int c = pop->current;
		int fv = pop->firstVisible();
		if (fv > 0) 
			fv++;
		if (c > fv)
			c = fv;
		else
			if ((c -= pop->numVisible-1) < 0)
				c = 0;
		pop->highlight(c, true);
		break;
	}

	case VK_RIGHT :
		// start murphy 19990818
		//pop->autoMenu = true;
		// end murphy 19990818
		if (pItem && pItem->type != menuItem::mi_basic)
			if (pop->execute(indx)) {
				Popup *p2 = pop->list[indx].sub;
				if (p2)
					p2->highlight(0, true);
			}
		break;

	case VK_LEFT :
		if ((pop = pop->parent) != NULL) {
			pop->closeSubmenus();
			pop->autoMenu = false;
			pop->highlight(pop->current, true);
		}
		break;

	case VK_RETURN :
		// start murphy 19990818
		if (pItem && pItem->type != menuItem::mi_basic) {
			if (pop->execute(indx)) {
				Popup *p2 = pop->list[indx].sub;
				if (p2)
					p2->highlight(0, true);
			} 
		} else {
			pop->execute();
		}
		// pop->execute();
		// end murphy 19990818
		break;

	case VK_ESCAPE :
		popup.destroyWindow();
		break;

	default:
		int nNewPopup = -1;

		if (pop->current != -1)
			nNewPopup = pop->AlphaNav(wParam, pop->current);
		else
			nNewPopup = pop->AlphaNav(wParam, -1);
		if (-1 != nNewPopup) {
			pop->highlight(nNewPopup, true);
		}
		break;
	}
	break;

	case WM_NCDESTROY:
	case WM_CLOSE:
	case WM_DESTROY:
	case WM_QUIT:
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
	break;
	default:
		return ::DefWindowProc(hwnd, message, wParam, lParam);
	}
	return ::DefWindowProc(hwnd, message, wParam, lParam);
}

//cleanup, not much to do
int quitModule(HINSTANCE dllInst) {
    int Msgs[10];

    Msgs[0] = LM_POPUP;
    Msgs[1] = LM_HIDEPOPUP;
    Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
    SendMessage (parentWin, LM_UNREGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	
	popup.destroyWindow();
	DestroyWindow(popup.hwnd);
    DeleteObject(popupFont);
	DeleteObject(hpenWhite);
	DeleteObject(hpenBlack);
	DeleteObject(hpenGray);
	DeleteObject(hbrBlack);
	DeleteObject(hbrGray);
	if (showPopupIcons) {
		DeleteObject(popupDefaultIcon);
		DeleteObject(taskDefaultIcon);
		DeleteObject(emptyDefaultIcon);
	}
    UnregisterClass(szAppName,dllInst); // unregister window class
    return 1;
}

//now defunct entry point, will take it out if somone complains
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
    return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

//DLL entry point
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	WNDCLASSEX wc;

    appInstance = dllInst;
    parentWin = ParentWnd;
    
    memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(wc);
    wc.style = 0;
    wc.lpfnWndProc = (WNDPROC)wndProc;// our window procedure
    //wc.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wc.hInstance = appInstance;			
	wc.cbWndExtra = 8; // signature + Popup object address
    wc.lpszClassName = szAppName;// our window class name
    if (!RegisterClassEx(&wc)) {
		_RPT1(_CRT_ERROR, "Failed to register POPUP window class; error '%d'\n", GetLastError());
    	return 1;
    }

	popup.loadValues();
	popup.createWindow();
	if (!popup.hwnd) {
		_RPT0(_CRT_ERROR, "Failed to create main POPUP window");
		return 1;
	}

    //create the message id's that popup.dll will use
    int Msgs[10];
    Msgs[0] = LM_POPUP;
    Msgs[1] = LM_HIDEPOPUP;
    Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
    SendMessage (ParentWnd, LM_REGISTERMESSAGE, (WPARAM)popup.hwnd, (LPARAM)Msgs);
	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
    return 0;
}

int fileSort(const void *a, const void *b) {
	const menuItem *i1 = (const menuItem*)a;
	const menuItem *i2 = (const menuItem*)b;

	return stricmp(i1->name, i2->name);
}

int Popup::AlphaNav(char chSearchChar, int nStartPoint) {
	const menuItem* SearchPopup = safeItem(0);
	nStartPoint = (0 > nStartPoint) ? 0 : nStartPoint;
	int nIndex = 0;
	int nFirstMatchIndex = -1;
	if (NULL == SearchPopup)
		return -1;

	//Go through the list once. If we encounter the character 
	//before reaching nStartPoint, then record that occurence 
	//as nFirstMatchIndex.  If the nStartPoint isn't -1, then 
	//we skip that item
	while (SearchPopup != NULL) {
		if (nStartPoint != nIndex) {
			if (SearchPopup->name[0] == chSearchChar) {
				if (nIndex < nStartPoint) {
					if (-1 == nFirstMatchIndex) {  
						//Only grab the first match in the list
						//FirstEarlyMatch = SearchPopup;
						nFirstMatchIndex = nIndex;
					} else
						return nFirstMatchIndex;
				} else
					return nIndex;
			}
		}
		//SearchPopup = SearchPopup->next;
		++nIndex;
		SearchPopup = safeItem(nIndex);
	} //End while loop
	return nFirstMatchIndex; //If we get here, then there were no matches past the starting point.  Either FirstEarlyMatch will be NULL or a menuItem pointer
}

/*
	$Log: popup.cpp,v $
	Revision 1.152  1999/07/23 19:04:39  cyberian
	
	Added a new VC5 project for hook.dll, added Killarny's sysVWM as an option, various changes to Popups, VWM, Wharf and Shortcut to fix some memory leaks
	
	Revision 1.1  1999/01/20 22:51:26  cyberian
	
	The old popups implemented with window classes with pinning, transparency etc.
	
*/
