#ifndef __ACTIVESHORTCUTS_H_
#define __ACTIVESHORTCUTS_H_
#include "../litestep/wharfdata.h"

#define LM_DOCKTRAY          9900

typedef struct {
    char szCommand[1024], szParameters[1024];
    char szName[256];
    char szSoundOnMouseOver[256];
    char szSoundOnMouseClicked[256];
    int x, y, state;
    HBITMAP bmpOff, bmpOn, bmpClick;
    HRGN transOnRgn, transOffRgn, transClickRgn;
    SIZE onSize, offSize, clickSize;
    HWND hwnd;
    UINT uTimer;
    char sz_bmpOn[256], sz_bmpOff[256], sz_bmpClick[256]; // Ender - ADD
    char sz_Group[10]; // ENDER - ADD NEW
    BOOL alwaysontop, mouseover; // Ender - ADD 1.1
    BOOL masterdrag, sstatic; // Ender - ADD 2.1

    int uGroup;    /*Shortcut group*/ // V1.1xxx
    BOOL bVisible;  /*Is window visible at present - Quicker than using IsWindowVisible*/
    } shortcutType;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

__declspec( dllexport ) HINSTANCE ELSExecute(HWND Owner, LPCSTR szCommand, int nShowCmd);
__declspec( dllexport ) HINSTANCE ELSExecuteEx(HWND Owner, LPSTR szOperation, LPSTR szCommand, LPSTR szArgs, LPSTR szDirectory, int nShowCmd);

#ifdef __cplusplus
}
#endif
#endif

