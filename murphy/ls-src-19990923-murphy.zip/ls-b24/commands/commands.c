#include <windows.h>
#include <stdio.h>
#include "commands.h"
#include "..\\lsapi\\lsapi.h"

const char szAppName[] = "Commands"; // Our window class, etc

void BangMIRCToggle(HWND caller ,char* args);	// this function toggles the mIRC32 window
void BangIMToggle(HWND caller ,char* args);		// this function toggles the AOL IM buddy list window

void BangMinimizeCurrent(HWND caller ,char* args);
void BangMaximizeCurrent(HWND caller ,char* args);
void BangRestoreCurrent(HWND caller ,char* args);
void BangSendToBottom(HWND caller ,char* args);
void BangAlwaysOnTop(HWND caller ,char* args);
void BangNotAlwaysOnTop(HWND caller ,char* args);

void RegisterBangCommands(void);

// Startup stuff
// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}


// Actual main function
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	// Calls the function to register the commands
	RegisterBangCommands();
	
	return 0;
}


// actually register the commands with Litestep
void RegisterBangCommands(void)
{
	
	AddBangCommand("!TOGGLE_AIMBUDDYLIST", BangIMToggle);
	AddBangCommand("!TOGGLE_MIRC32", BangMIRCToggle);
	AddBangCommand("!MINIMIZECURRENTWINDOW",BangMinimizeCurrent);
	AddBangCommand("!RESTORECURRENTWINDOW",BangRestoreCurrent);
	AddBangCommand("!MAXIMIZECURRENTWINDOW",BangMaximizeCurrent);
	AddBangCommand("!SENDCURRENTWINDOWTOBOTTOM", BangSendToBottom);
	AddBangCommand("!CURRENTWINDOWALWAYSONTOP", BangAlwaysOnTop);
	AddBangCommand("!CURRENTWINDOWNOTALWAYSONTOP", BangNotAlwaysOnTop);
	
}



void BangSendToBottom(HWND caller ,char* args)
{
	SetWindowPos(GetForegroundWindow(), HWND_BOTTOM, 0, 0,0, 0, SWP_NOSIZE | SWP_NOMOVE );
}
void BangAlwaysOnTop(HWND caller ,char* args)
{
	SetWindowPos(GetForegroundWindow(), HWND_TOPMOST, 0, 0,0, 0, SWP_NOSIZE | SWP_NOMOVE |SWP_SHOWWINDOW);
}
void BangNotAlwaysOnTop(HWND caller ,char* args)
{
	SetWindowPos(GetForegroundWindow(), HWND_NOTOPMOST, 0, 0,0, 0, SWP_NOSIZE | SWP_NOMOVE |SWP_SHOWWINDOW);
}


void BangMIRCToggle(HWND caller ,char* args)
{
	// first we will find the mirc window
	HWND mirc;
	mirc = FindWindow("mIRC32",NULL);
	// then we will detect whether it is the foreground window
	if 	(GetForegroundWindow() == mirc)
	{
		// if so, we will send a message to minimize it.
		SendMessage(mirc, WM_SYSCOMMAND, SC_MINIMIZE, 0);
	}
	else
	{
		// if not, we will send a message to restore it from the tray.
		SendMessage(mirc, WM_SYSCOMMAND, SC_RESTORE,0);
		BringWindowToTop(mirc);
		SetForegroundWindow(mirc);
	}
	// or bring the window to the foreground
	BringWindowToTop(mirc);
}


void BangIMToggle(HWND caller ,char* args)
{
	HWND im;
	im = FindWindow("_Oscar_BuddyListWin",NULL);
	if 	(GetForegroundWindow() == im)
	{
		SendMessage(im, WM_SYSCOMMAND, SC_MINIMIZE, 0);
	}
	else
	{
	SendMessage(im, WM_SYSCOMMAND, SC_RESTORE,0);
	SetForegroundWindow(im);
	BringWindowToTop(im);
	}
	BringWindowToTop(im);
}

void BangMinimizeCurrent(HWND caller ,char* args)
{
	ShowWindow(GetForegroundWindow(), SW_MINIMIZE);
}

void BangMaximizeCurrent(HWND caller ,char* args)
{
	ShowWindow(GetForegroundWindow(), SW_MAXIMIZE);
}

void BangRestoreCurrent(HWND caller ,char* args)
{
		ShowWindow(GetForegroundWindow(), SW_RESTORE);
}



// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
}
