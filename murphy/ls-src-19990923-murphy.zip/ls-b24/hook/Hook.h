#ifndef __HOOK_H
#define __HOOK_H

#include <stdio.h>
#include "../lsapi/lsapi.h"
#include "../litestep/wharfdata.h"

#ifdef HOOK_DLL
	#define HOOK_EXPORT __declspec(dllexport)
#else
	#define HOOK_EXPORT __declspec(dllimport)
#endif

#ifdef __cplusplus
extern "C" {
#endif

HOOK_EXPORT void AttachHookDll(HWND hwndParent);

#ifdef __cplusplus
}
#endif

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam);

#endif
