#include <windows.h>
#include "..\litestep\wharfdata.h"

/*****************************************************************************/
/* maximum number of desktops                                                */
/*****************************************************************************/
#define MAX_DESKS 128
typedef struct deskT {
	HWND parent;
	HWND deskWnd;
	int x,y,w,h;
	HDC dblBuf;
	HBITMAP backImg;
} deskT;

/*****************************************************************************/
/* HOTKEY_UP, HOTKEY_DOWN, HOTKEY_LEFT, HOTKEY_RIGHT, etc are hotkey #s for  */
/* move up, down, left, and right respectively                               */
/*****************************************************************************/
#define HOTKEY_UP 9350
#define HOTKEY_DOWN 9351
#define HOTKEY_LEFT 9352
#define HOTKEY_RIGHT 9353
/*****************************************************************************/
/* HOTKEY_NAV is for bring up the full vdesk navigator                       */
/*****************************************************************************/
#define HOTKEY_NAV 9354
/*****************************************************************************/
/* HOTKEY_DESK + wParam == quickey to given desk                             */
/*****************************************************************************/
#define HOTKEY_DESK 9355
/*****************************************************************************/
/* GOTO_HWND goes to the desk that hwnd wParam is on                         */
/*****************************************************************************/
#define GOTO_HWND 8891



#ifdef	__cplusplus
{
#endif	/* __cplusplus */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dll);
#ifdef	__cplusplus
};
#endif	/* __cplusplus */
