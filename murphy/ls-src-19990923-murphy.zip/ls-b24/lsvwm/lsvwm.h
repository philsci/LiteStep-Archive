/* make sure we dont include multiple times (tho i dont know why we would!) */
#ifndef __LSVWM_H
#define __LSVWM_H

/*****************************************************************************/
/* DUH ^_^                                                                   */
/*****************************************************************************/
#ifndef true
#define true 1
#endif
#ifndef false
#define false 0
#endif
/*****************************************************************************/
/* maximum number of desktops                                                */
/*****************************************************************************/
#define MAX_DESKS 128
/*****************************************************************************/
/* maximum entries in the list (eventually allow for definition in step.rc)  */
/*****************************************************************************/
#define MAX_ENTRIES 1024
/*****************************************************************************/
/* means that we couldnt find a free entry in the list (not good)            */
/*****************************************************************************/
#define NO_FREE_ENTRIES -1
/*****************************************************************************/
/* HOTKEY_UP, HOTKEY_DOWN, HOTKEY_LEFT, HOTKEY_RIGHT, etc are hotkey #s for  */
/* move up, down, left, and right respectively                               */
/*****************************************************************************/
#define HOTKEY_UP 9350
#define HOTKEY_DOWN 9351
#define HOTKEY_LEFT 9352
#define HOTKEY_RIGHT 9353
/*****************************************************************************/
/* HOTKEY_NAV is for bring up the full vdesk navigator                       */
/*****************************************************************************/
#define HOTKEY_NAV 9354
/*****************************************************************************/
/* HOTKEY_DESK + wParam == quickey to given desk                             */
/*****************************************************************************/
#define HOTKEY_DESK 9355
/*****************************************************************************/
/* GOTO_HWND goes to the desk that hwnd wParam is on                         */
/*****************************************************************************/
#define GOTO_HWND 8891

/*****************************************************************************/
/* sticky structure stuff                                                    */
/*****************************************************************************/
typedef struct stickyT {
	char text[256];
	int type;
} stickyT;
#define MAX_STICKIES 256

/* export definitions */
#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif

/* __LSVWM_H */
#endif
