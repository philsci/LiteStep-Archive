#ifndef __POPUP_H
#define __POPUP_H

#include "../litestep/wharfdata.h"
#include "../lsapi/lsapi.h"

//pre-delc 
class Popup;

//simple bitmap struct
typedef struct {
	HBITMAP bitmap;
	HRGN region;
	char name[MAX_PATH];
	int x;
	int y;
} BitMP;

//temp container for data retreved from file
class fileItem
{
public:	
	fileItem();
	~fileItem();
	char itemName[256];
	char bmpName[256];
	int itemHeight;
	char popupCommand[256];
	char commandParam[256];
	fileItem *next;
};

class menuItem 
{
public:
	char bmp[256];
	char name[256];
	char command[256];
	char params[256];
	int ID;
	int itemLevel;
	BOOL isDynamic;
	BYTE isBar;
	HICON hIcon;
	Popup *Menu;
	menuItem *next; //next menu item in the list
	Popup *SMenu; //if this item isn't a submenu accessor, this will be NULL
	menuItem()
	{	
		next= NULL;
		itemLevel = 0;
		isDynamic = FALSE;
		isBar = 0;
		strcpy(params, "\0");
		SMenu = NULL;
		hIcon = NULL;
	}
	~menuItem();
};

//the popup list container
class Popup 
{ 
public:	
	Popup() {
		root = NULL;
		current = root;
		menuWidth = 100;
		region = NULL;
		hmenu = NULL;
	}

	~Popup() {
		if(root != NULL)
			delete root;
	}

	BOOL newMenuItem();
	menuItem *root; //the root list for the popupmenu
	menuItem *current; //the last item in this list
	int menuWidth; //the minimum width of the popupmenu
	HRGN region;
	HMENU hmenu;
};

#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */
__declspec( dllexport ) int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif  /* __LSAPI_H */
