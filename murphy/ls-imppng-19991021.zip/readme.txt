ls-imppng v.1a (the light version of lsimpgfx)
~~~~~~~~~~~~~~
this is an importfilter only for png-files

limitations:
- only newer modules which use loadlsimage can use the imagefilter.
- you need murphy preview build 1999/09/23 or newer.
- at this time (1999/10/21) isn't sysvwm capable of using the imagefilter.

usage in step.rc:
LoadModule [yourlitesteppath]\lsimppng.dll

example:
PopupTitlePix dp_bartitle.png
PopupEntryPix dp_barentry.png
PopupSelEntryPix dp_barsel.png
PopupBottomPix dp_barbottom.png

history
~~~~~~~
1999/10/21 - v.1a
- first release
