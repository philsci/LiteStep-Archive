/*
  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-99 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
09/10/1999 (Ender)
                 - Rearranged code. Removed a lot of obsolete code and made
                   the current code 'neater'. The prototype list following the
                   includes also act's as a sort of 'table of contents' :)
*****************************************************************************/
#include <io.h>
#include <time.h>
#include <tchar.h>
#include <stdio.h>
#include <shlobj.h>
#include <crtdbg.h>
#include <windows.h>
#include <process.h>
#include <winuser.h>

#include "litestep.h"
#include "lsapi.h"
#include "wharfdata.h"

const char rcsRevision[] = "$Revision: 1.72 $"; // Our Version 
const char rcsId[] = "$Id: litestep.c,v 1.72 1999/10/21 20:56:09 maduin Exp $"; // The Full RCS ID.
const char LSRev[] = "0.24.5 ";

// Program Options
const LPCTSTR   szMainWindowClass = _T("TApplication");
const LPCTSTR   szMainWindowTitle = _T("LiteStep");
CHAR szAppPath[256], szRcPath[256];
HINSTANCE hDLLInstance;
BOOL bRunStartup = TRUE;

// Windows
HWND hMainWindow = NULL;
static HWND desktopWnd = NULL, systrayWnd = NULL;
static LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Config/Settings
BOOL ShowWarning = TRUE, isShell = FALSE;
static void initData (void);
static void ReadConfig (void);
void ParseCmdLine(LPSTR lpCmdLine);

// Message Handler
static windowType winList[MAXWIN];
static UINT Messages[MSGNUM];
static msgWinType MSGCallbacks[MSGNUM];
dataStore savedData;
dataStore * dataStoreHead = &savedData;  

BOOL HandlerExists(UINT uMsg);               // Check if this msg is handled
HRESULT passOnMessage(UINT Msg, WPARAM wParam, LPARAM lParam, BOOL wait);
                      // ^-<< Sends msg to everyone who requested it
void addWndMessage(HWND hwnd, UINT Message); // Adds single msg to handler
void addMessages(HWND hwnd, UINT* Msg);      // Adds list of msg's to handler
void removeWndMessage(HWND hwnd, UINT Message); // Del single msg from handler
void removeMessages(HWND hwnd, UINT* Msg);   // Del list of msg's from handler
void clearMessages();                       // Remove all msg's from handler
void ClearDataStore();

// Module Handler
int gNumModules = 0;
ModuleData *gModules = NULL;
static void LoadModules (void);
static void QuitModules (void);
static void AddModule (LPCSTR path);
static int  ErrorBox (HWND hWnd, LPCTSTR pszText, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags);

// Startup Handler
static void RunStartupStuff (void *dummy);
static void RunEntriesIn (HKEY key, LPCTSTR path);
static void DeleteEntriesIn (HKEY key, LPCTSTR path);
static void RunStartupMenu (void);
static void RunFolderContents(LPCSTR szParams);
static void ShutDown(void);

// Misc
BOOL UnderExplorer = FALSE, gRecycle = FALSE, gEndSession = FALSE;
BOOL skipEvents = FALSE;
HRESULT GetRevId(WPARAM wParam, LPARAM lParam);
static trayType *trayData = NULL;
static void DoEvents(HWND hwnd, int n);

//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//
// Code Starts Here

// [Main Litestep Code]
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow) {
 ATOM aClass;
 WNDCLASS wc;
 
 FARPROC (__stdcall *SetShellWindow)(HWND) = NULL;
 FARPROC (__stdcall *GetShellWindow)(HWND) = NULL;
 bRunStartup = TRUE;       
 szAppPath[0] = 0;
 hDLLInstance = hInstance;

 SetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "SetShellWindow");
 GetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "GetShellWindow");

 if (GetModuleFileName (hDLLInstance, szAppPath, sizeof (szAppPath)) > 0) {
  int len = lstrlen (szAppPath);
  while (len && szAppPath[len-1] != _T('\\')) {
   szAppPath[--len] = _T('\0');
  }
                
  if (len) {
   szAppPath[--len] = _T('\0');
  }
 }

 ParseCmdLine(lpCmdLine);
 ReadConfig();
 CloseRC();

 if (FindWindow("Shell_TrayWnd", NULL)) { // Running under Exploder
  if (ShowWarning)
    if (MessageBox(0, "You are currently running another shell, while Litestep b24 allows you\012to run under Explorer, we don't advise it for inexperienced users, and we\012will not support it, so do so at your own risk.\012\012If you continue, some of the advanced features of Litestep will be disabled\012such as the desktop. The wharf, hotkeys, and shortcuts will still work.\012\012To get rid of this message next time, put LSNoShellWarning in your step.rc\012\012Continue?", "WARNING", MB_YESNO|MB_ICONEXCLAMATION) == IDNO)
     exit(0);
  UnderExplorer = TRUE;
 }

 // Register Window Class
 memset (&wc, 0, sizeof (wc));
 memset (dataStoreHead, 0, sizeof(dataStore));
       
 wc.lpfnWndProc = MainWndProc;
 wc.hInstance = hDLLInstance;
 wc.lpszClassName = szMainWindowClass;
 aClass = RegisterClass(&wc);
 if (!aClass) return 0;

 hMainWindow = CreateWindowEx(WS_EX_TOOLWINDOW,
                              szMainWindowClass, szMainWindowTitle, 0,
                              0, 0, 0, 0, NULL, NULL, hDLLInstance, NULL);

 if (hMainWindow) {
  MSG message;
  SetWindowLong (hMainWindow, GWL_USERDATA, magicDWord); 
  if (!UnderExplorer && isShell) SetShellWindow(hMainWindow);

  initData ();

  do {
   ReadConfig();     // Load step.rc
   clearMessages();  // Reset Message Handler
                                
   LoadModules ();  // Load modules
                                
   if (gRecycle && HandlerExists(LM_RESTORESYSTRAY) && trayData) {
     SendMessage(hMainWindow, LM_RESTORESYSTRAY, 0, (LONG)trayData);
     if (trayData) free(trayData);
   }

   if (!gRecycle) {
    // Don't run startup items if the SHIFT key is down
    if(GetAsyncKeyState(VK_SHIFT) & 0x8000) bRunStartup = FALSE;
    if(bRunStartup) {
     _beginthread(RunStartupStuff, 0, NULL);
    }
   }
   gRecycle = FALSE;
                                
   SendMessage(GetDesktopWindow(), 0x400, 0, 0); // Undocumented call: Shell Loading Finished
   while (GetMessage (&message, 0, 0, 0)) {
    TranslateMessage(&message);
    DispatchMessage (&message);
                                        
    if (gRecycle || gEndSession) {break;}
   }
                                
   if (gRecycle && HandlerExists(LM_SAVESYSTRAY)) {
    trayData = (trayType *)calloc(200, sizeof(trayType));
    SendMessage(hMainWindow, LM_SAVESYSTRAY, 0, (LONG)trayData);
   }                                                                

   ClearDataStore();
   QuitModules ();
   clearMessages();
   CloseRC();
  } while (gRecycle && !gEndSession);
                        
  ClearDataStore();
  if (!skipEvents) {
   while (GetMessage (&message, 0, 0, 0)) {
    TranslateMessage(&message);
    DispatchMessage (&message);
   }
  }

  DestroyWindow(hMainWindow);
  hMainWindow = NULL;
 }
 UnregisterClass (szMainWindowClass, hDLLInstance);
 return 0;
}

LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
 switch (uMsg) {
  case WM_KEYDOWN: {
   if (wParam == LM_SHUTDOWN) {ParseBangCommand(hwnd, "!ShutDown", NULL);}
   return 0;
  }

  case WM_SYSCOMMAND: {
   switch (wParam) {
    case SC_CLOSE:
     ParseBangCommand(hwnd, "!ShutDown", NULL);
     return 0;
    default:
     return DefWindowProc(hwnd,uMsg,wParam,lParam);
   }
  }

  case WM_QUERYENDSESSION: {
   return TRUE;
   break;
  }

  case WM_ENDSESSION: {
   gEndSession = TRUE;
   break;
  }

  case LM_SAVEDATA: {
   WORD ident = HIWORD(wParam);
   WORD len = LOWORD(wParam);
   void * data = (void *) lParam;
   dataStore * pos = dataStoreHead;
   dataStore * newdata;

   if (len && ident && gRecycle) {
    while ((pos->next) && (pos->ident != ident)) {
     pos = pos->next;
    }
    if (pos->ident == ident) {
     if (pos->data) free(pos->data);
    } else if (!pos->next) {
     newdata = (dataStore *)malloc(sizeof(dataStore));
     pos->next = newdata;
     newdata->next = NULL;
     pos = newdata;
    }
    pos->ident = ident;
    pos->len = len;
    pos->data = (void *) malloc (len);
    memcpy(pos->data, data, len); 
   }
   return 0;
  }

  case LM_RESTOREDATA: {
   WORD ident = HIWORD(wParam);
   WORD len = LOWORD(wParam);
   void * data = (void *) lParam;
   dataStore * pos = dataStoreHead;
   dataStore * prev = dataStoreHead;

   if (len && ident) {
    while ((pos->next) && (pos->ident != ident)) {
     prev = pos;
     pos = pos->next;
    }
    if (pos->ident == ident) {
     if (pos->data) {
      memcpy(data, pos->data, pos->len);
      free(pos->data);
     }
     prev->next = pos->next;
     free(pos);
    }
   }
   return 0;
  }

  case LM_REGISTERMESSAGE:  {   // Message Handler Message
   addMessages((HWND)wParam, (UINT*)lParam);
   break;
  }

  case LM_UNREGISTERMESSAGE:  { // Message Handler Message
   removeMessages((HWND)wParam, (UINT*)lParam);
   break;
  }

  case LM_WINLIST: {
   switch (wParam) {
    case 0:
     return (LRESULT) &winList[0];
     break;
    case 1:
     return (LRESULT) MAXWIN;
     break;
   }
  }

  case LM_RECYCLE: {
   if (wParam == 0) {
    gRecycle = TRUE;
   } else if (wParam == 1) {
    if (ExitWindowsEx (EWX_LOGOFF, 0))
    gEndSession = TRUE;
   } else if (wParam == 2) {
    gEndSession = TRUE;
    skipEvents = TRUE;
   } else {
    ShutDown();
   }
   break;
  }

  case LM_UNLOADMODULE: {       // Module Handler Message
   if (wParam != 0) {
    int i;
    BOOL unloaded = FALSE;

    for(i = 0; i < gNumModules; i++) {
     if(!unloaded) {
      if(!strcmpi((char*)wParam, gModules[i].szName)) {
       if (gModules[i].pQuit) {
        __try {gModules[i].pQuit (hDLLInstance);}
        __except(1) { }
       }
       FreeLibrary (gModules[i].hInstance);
       unloaded = TRUE;
      }
     } else memcpy(&gModules[i - 1], &gModules[i], sizeof(ModuleData));
    }
    if(unloaded) {
     gModules = realloc (gModules, (gNumModules - 1) * sizeof (ModuleData));
     gNumModules--;
    }
   }
   break;
  }
                                
  case LM_RELOADMODULE: {       // Module Handler Message
   if (wParam != 0) {
    int i;
    BOOL Add = TRUE;

    if (UnderExplorer) {
     if (match("*desktop*", (char*)wParam))
     Add = FALSE;
    }

    for(i = 0; i < gNumModules; i++) {
     if(!strcmpi((char*)wParam, gModules[i].szName)) {
      Add = FALSE;
      MessageBox(hMainWindow, "This Module is already loaded", (char*)wParam, MB_OK);
     }
    }

    if (Add) {
     AddModule ((char*)wParam);
     DoEvents(hMainWindow, 5);
    }
   }
   break;
  }

	case LM_BANGCOMMAND:
	{
		PLMBANGCOMMAND plmbc = (PLMBANGCOMMAND) lParam;

		if( !plmbc )
			return FALSE;

		if( plmbc->cbSize != sizeof(LMBANGCOMMAND) )
			return FALSE;

		ParseBangCommand( plmbc->hWnd, plmbc->szCommand, plmbc->szArgs );
		return TRUE;
	}

	case WM_COPYDATA:
	{
		PCOPYDATASTRUCT pcds = (PCOPYDATASTRUCT) lParam;
		
		switch( pcds->dwData )
		{
			case LM_BANGCOMMAND:

				return SendMessage( hwnd, LM_BANGCOMMAND, 0,
					(LPARAM) pcds->lpData );
		}

		return 0;
	}

  default:
   if (HandlerExists(uMsg))
    return passOnMessage(uMsg, wParam, lParam, TRUE);
   else
    return DefWindowProc (hwnd, uMsg, wParam, lParam);
 }
 return 0;
}

// [Message Handler Code]
BOOL HandlerExists(UINT uMsg) {
 int i=0;
 BOOL found = FALSE;
 while (i < (MSGNUM)) {
  if ((MSGCallbacks[i].Message == uMsg) && (MSGCallbacks[i].Message)) {
   found = TRUE;
   break;
  }
  i++;
 }

 if (found)
  return TRUE;
 else
  return FALSE;
}

HRESULT passOnMessage(UINT Msg, WPARAM wParam, LPARAM lParam, BOOL wait) {
 int i=0, j;
 BOOL found = FALSE;
 HRESULT returnVal = 0;

 if (Msg == LM_GETREVID) return GetRevId(wParam, lParam);

 while ((MSGCallbacks[i].Message) && (i < (MSGNUM))) {
  if (MSGCallbacks[i].Message == Msg) {
   found = TRUE;
   break;
  }
  i++;
 }

 if (found) {
  for (j=0; j<HWNDNUM; j++) {
   if (MSGCallbacks[i].hwnd[j] != NULL) {
    if (wait) {
     returnVal |= SendMessage(MSGCallbacks[i].hwnd[j], Msg, wParam, lParam);
    } else {
     PostMessage(MSGCallbacks[i].hwnd[j], Msg, wParam, lParam);
    }
   }
  }
 }
 return returnVal;
}

void addWndMessage(HWND hwnd, UINT Message) {
 int i=0;
 while (i<MSGNUM) {
  if (MSGCallbacks[i].Message == Message) break;
  i++;
 }

 if (i == MSGNUM) {
  i = 0;
  while ((MSGCallbacks[i].Message)&&(i<MSGNUM)) {
   i++;
  }

  if (i<MSGNUM) {
   MSGCallbacks[i].Message = Message;
  } else {
   return;
  }
 }
 {
  int j=0;
  while ((MSGCallbacks[i].hwnd[j] != NULL) && (MSGCallbacks[i].hwnd[j] != hwnd) && (j<(HWNDNUM))) {
   j++;
  }

  if (j < HWNDNUM) {MSGCallbacks[i].hwnd[j] = hwnd;}
 }
}

void addMessages(HWND hwnd, UINT* Msg) {
 int i = 0;
 while ((Msg[i]) && (i < MSGNUM)) {
  addWndMessage(hwnd, Msg[i]);
  i++;
 }
}

void removeWndMessage(HWND hwnd, UINT Message) {
 int i=0;
 while ((MSGCallbacks[i].Message != 0) && (i<(MSGNUM))) {
  if (MSGCallbacks[i].Message == Message) break;
  i++;
 }

 if (i < (MSGNUM)) {
  int j=0;
  while ((MSGCallbacks[i].hwnd[j] != hwnd) && (j<(HWNDNUM))) {
   j++;
  }

  if (j < HWNDNUM) {
   MSGCallbacks[i].hwnd[j] = NULL;
  }

  j=0;
  while (j<HWNDNUM) {
   if (MSGCallbacks[i].hwnd[j]) {break;}
   j++;
  }

  if (j == HWNDNUM) {
   MSGCallbacks[i].Message = 0;
  }
 }
}

void removeMessages(HWND hwnd, UINT* Msg) {
 int i = 0;
 while ((Msg[i]) && (i < MSGNUM)) {
  removeWndMessage(hwnd, Msg[i]);
  i++;
 }
}

void clearMessages() {
 memset(MSGCallbacks, 0, sizeof(MSGCallbacks));
}

void ClearDataStore(void) {
 dataStore * pos = dataStoreHead->next;
 dataStore * prev = NULL;


 while (pos) {
  prev = pos;
  pos = pos->next;
  if (prev->data)
   free(prev->data);
  if (prev)
   free(prev);
 }
}

// [Config/Settings Code]
void initData (void) {
 int x = 0;
 for (x=0;x<MAXWIN;x++) {
  winList[x].Handle = NULL;
  winList[x].Visible = FALSE;
  winList[x].Desk = 0;
 }
}

void ReadConfig (void) {
 if (SetupRC(szRcPath)) {

  // Modified - Maduin, 10-20-1999
  //   Added "ExplorerNoWarn" and "SetAsShell" again to smooth
  //   the transition to the new style. Eventually these should
  //   be removed, but for now backwards compability is a good
  //   thing.

  ShowWarning = GetRCBool("LSNoShellWarning", FALSE) && GetRCBool("ExplorerNoWarn", FALSE);
  isShell = GetRCBool("LSSetAsShell", TRUE) || GetRCBool("SetAsShell", TRUE);
 }
}

void ParseCmdLine(LPSTR lpCmdLine) {
 char *ptr;
 ptr = lpCmdLine;

 while(1) {
  TCHAR szSwitch[32];
  int n;

  while (*ptr && (*ptr == ' ' || *ptr == '\t')) ptr++;

  if (*ptr && (*ptr == '/' || *ptr == '-')) {
   n = 0;
   ptr++;

   while (*ptr && *ptr != ' ' && *ptr != '\t') {
    if(n < 32) szSwitch[n++] = *ptr;
    ptr++;
   }
   szSwitch[n] = 0;
   if(!lstrcmpi(szSwitch, TEXT("nostartup"))) bRunStartup = FALSE;
  } else break;
 }

 if (*ptr != '\0') {
  BOOL isFullPath = FALSE;
  int i;

  for (i = 0; i < lstrlen(ptr); i++) if (ptr[i] == '\\') isFullPath = TRUE;

  if (!isFullPath) {
   wsprintf(szRcPath, "%s\\%s", szAppPath, ptr);
  } else {
   wsprintf(szRcPath, ptr);
  }

 } else wsprintf(szRcPath, "%s\\STEP.RC", szAppPath);
}

// [Module Handling Code]
void LoadModules (void)
{
 char buffer[4096], path[256];
 FILE *f;
 sprintf (path, "%s\\step.rc", szAppPath);
 f = LCOpen (path);

 if (f) {
  while (LCReadNextCommand (f, buffer, sizeof (buffer))) {
   char *lpszBuffers[2];
   char token1[4096] = {0};
   char token2[4096] = {0};

   lpszBuffers[0] = token1;
   lpszBuffers[1] = token2;

   if (LCTokenize (buffer, lpszBuffers, 2, NULL) == 2) {
    if (!stricmp (token1, "LoadModule")) {
     BOOL Add = TRUE;

     if (UnderExplorer) {
      if (match("*desktop*", token2)) Add = FALSE;
     }

     if (Add) {
      AddModule(token2);
      DoEvents(hMainWindow, 5);
     }
    }
   }
  }
  LCClose (f);
 }
}

void QuitModules (void) {
 while (gNumModules > 0) {
  if (gModules[gNumModules-1].pQuit) {
   __try {gModules[gNumModules-1].pQuit (gModules[gNumModules-1].hInstance);}
   __except(1) { }
  }

  FreeLibrary (gModules[gNumModules-1].hInstance);
  gNumModules--;
 }

 if (gModules) {
  free (gModules);
  gModules = NULL;
 }
}

void AddModule( LPCTSTR pszModulePath )
{
	ModuleData md;
	wharfDataType wd;
	DWORD dwError;
	TCHAR szImagePath[MAX_PATH];

	LSGetImagePath( szImagePath, MAX_PATH );

	memset( &wd, 0, sizeof(wharfDataType) );
	wd.pixmapDir = szImagePath;
	wd.lsPath = szAppPath;
	wd.winList = winList;
	wd.winListSize = MAXWIN;
	
	memset( &md, 0, sizeof(ModuleData) );
	lstrcpyn( md.szName, pszModulePath, 256 );
	md.hInstance = LoadLibrary( md.szName );
	dwError = GetLastError();

	if( md.hInstance )
	{
		md.pInit = (ModuleInitFunc) GetProcAddress( md.hInstance, TEXT("initModule") );
		md.pNewInit = (NewModuleInitFunc) GetProcAddress( md.hInstance, TEXT("initModuleEx") );
		md.pQuit = (ModuleQuitFunc) GetProcAddress( md.hInstance, TEXT("quitModule") );
		
		if( md.pInit || md.pNewInit )
		{
			__try
			{
				if( md.pNewInit )
					md.pNewInit( hMainWindow, md.hInstance, szAppPath );
				else
					md.pInit( hMainWindow, md.hInstance, &wd );
			}
			__except(1)
			{
				FreeLibrary( md.hInstance );
				md.hInstance = NULL;
			}
		}
	}

	if( !md.hInstance )
	{
		TCHAR szMessage[MAX_PATH];

		wsprintf(szMessage, TEXT("An error occured while loading \"%s\"."),
			pszModulePath );

		ErrorBox( hMainWindow, szMessage, dwError, TEXT("Litestep"),
			MB_ICONWARNING | MB_SETFOREGROUND );

		return;
	}

	if( !gModules )
		gModules = (ModuleData *) malloc( sizeof(ModuleData) );
	else
		gModules = (ModuleData *) realloc( gModules, (gNumModules + 1) * sizeof(ModuleData) );

	memcpy( gModules + gNumModules, &md, sizeof(ModuleData) );
	gNumModules++;
}

int ErrorBox( HWND hWnd, LPCTSTR pszText, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags )
{
	TCHAR szMessage[MAX_PATH];
	int nLen;

	lstrcpyn(szMessage, pszText, MAX_PATH - 1);
	lstrcat(szMessage, TEXT(" "));
	nLen = lstrlen(szMessage);

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, dwErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), szMessage + nLen,
		MAX_PATH - nLen, NULL);
	
	return MessageBox( hWnd, szMessage, pszTitle, nFlags );
}

// [Startup Handler Code]
void RunStartupStuff (void *dummy) {
 const LPCTSTR szRunPath = _T("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
 const LPCTSTR szRunOncePath = _T("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce");

 if (!UnderExplorer) {
  // Run 'RunOnce' applications, and delete from register [eg, setup stuff]
  RunEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
  DeleteEntriesIn (HKEY_LOCAL_MACHINE, szRunOncePath);
  RunEntriesIn (HKEY_CURRENT_USER, szRunOncePath);
  DeleteEntriesIn (HKEY_CURRENT_USER, szRunOncePath);

  // Run Regular Perminant Applications
  RunEntriesIn (HKEY_LOCAL_MACHINE, szRunPath);
  RunEntriesIn (HKEY_CURRENT_USER, szRunPath);

  // Lastly run items in the Startup folder of the start menu
  RunStartupMenu ();
 }
}

void RunEntriesIn (HKEY key, LPCTSTR path) {
 HKEY    hKey = NULL;
 LONG    lResult;
        
 lResult = RegOpenKeyEx(key, path, 0, KEY_READ, &hKey);

 if (lResult == ERROR_SUCCESS) {
  TCHAR szNameBuffer[1024], szValueBuffer[1024];
  DWORD dwLoop, dwNameSize, dwValueSize;

  for (dwLoop = 0; ; ++dwLoop) {
   dwNameSize = sizeof (szNameBuffer);
   dwValueSize = sizeof (szValueBuffer);
   lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
                          (LPBYTE) szValueBuffer, &dwValueSize);
   if (lResult == ERROR_NO_MORE_ITEMS) {break;}
   if (lResult == ERROR_SUCCESS) {WinExec (szValueBuffer, SW_SHOW);}
   else {break;}
  }
  RegCloseKey (hKey);
 }
}

void DeleteEntriesIn (HKEY key, LPCTSTR path) {
 HKEY    hKey = NULL;
 LONG    lResult;
        
 lResult = RegOpenKeyEx(key, path, 0, KEY_ALL_ACCESS, &hKey);
 if (lResult == ERROR_SUCCESS) {
  TCHAR szNameBuffer[1024], szValueBuffer[1024];
  DWORD dwLoop, dwNameSize, dwValueSize;

  for (dwLoop = 0; ;) {
   dwNameSize = sizeof (szNameBuffer);
   dwValueSize = sizeof (szValueBuffer);

   lResult = RegEnumValue(hKey, dwLoop, szNameBuffer, &dwNameSize, NULL, NULL,
                          (LPBYTE) szValueBuffer, &dwValueSize);
   if (lResult == ERROR_NO_MORE_ITEMS) {break;}
   if (lResult == ERROR_SUCCESS) {
    lResult = RegDeleteValue(hKey,szNameBuffer);
    if (lResult != ERROR_SUCCESS) {break;}
   }
   else {break;}
  }
  RegCloseKey (hKey);
 }
}

void RunStartupMenu (void) {
 char szPath[256];
 LPITEMIDLIST item;
 SHGetSpecialFolderLocation(NULL, CSIDL_COMMON_STARTUP, &item);
 SHGetPathFromIDList(item, szPath);
 RunFolderContents(szPath);

 SHGetSpecialFolderLocation(NULL,CSIDL_STARTUP,&item);
 SHGetPathFromIDList(item, szPath);
 RunFolderContents(szPath);
}

void RunFolderContents(LPCSTR szParams) {
 char szDir[256], szPath[256];
 struct _finddata_t finddata;
 long search_handle;

 strcpy (szPath, szParams);
 strcpy (szDir, szPath);
 if (szPath[strlen(szPath)-1] != '\\') {strcat(szPath, "\\");}
 strcat(szPath, "*.*");

 if (strcmp(szPath,"\\*.*")!=0) {
  search_handle = _findfirst(szPath, &finddata);
  while (search_handle != -1) {
   if (strcmp (finddata.name, ".") && strcmp (finddata.name, "..")) {
    LSExecuteEx(NULL, NULL, finddata.name, NULL, szDir, SW_SHOWNORMAL );
   }

   if (_findnext(search_handle, &finddata) == -1) {
    _findclose(search_handle);
    search_handle = -1;
   }
  }
 }
}

void ShutDown(void) {
 FARPROC (__stdcall *MSWinShutdown)(HWND) = NULL;

 MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
 MSWinShutdown(hMainWindow);
 return;
}

// [Misc Code]
void DoEvents(HWND hwnd, int n) {
 int i;
 unsigned int b=1;
 MSG msg;

 for (i=0;i<n && b;i++) {
  b = PeekMessage(&msg, hwnd, 0, 0, PM_REMOVE);
  if (b) {
   TranslateMessage(&msg);
   DispatchMessage(&msg);
  }
 }
}

HRESULT GetRevId(WPARAM wParam, LPARAM lParam) {
 int i=0, j;
 int p = 0;
 char *buf = (char *) lParam;
 BOOL found = FALSE;
 HRESULT returnVal = 0;
 int bufLen = wParam >> 4;
 int RetType = wParam & 0x0000f;

 if (RetType == 0) {
  strcpy(buf, "litestep.exe: ");
  strcat(buf, (LPCSTR)&LSRev);
  buf[strlen(buf)-1] = '\0';
 }
 else if (RetType == 1) {
  strcpy(buf, &rcsId[1]);
  buf[strlen(buf)-1] = '\0';
 } else {
  strcpy(buf, "");
 }

 while ((MSGCallbacks[i].Message) && (i < (MSGNUM))) {
  if (MSGCallbacks[i].Message == LM_GETREVID) {
   found = TRUE;
   break;
  }
  i++;
 }

 if (found) {
  char buffer[1024];
  for (j=0; j<HWNDNUM; j++) {
   if (MSGCallbacks[i].hwnd[j] != NULL) {
    strcpy(buffer, "");
    p = SendMessage(MSGCallbacks[i].hwnd[j], LM_GETREVID, (wParam & 0x0f), (LPARAM) buffer);
    if (p && *buffer) {
     strcat(buf, "\n");
     strncat(buf, buffer, bufLen - strlen(buf));
    }
   }
  }
 }
 buf[bufLen -1] = '\0';
 return (HRESULT)strlen(buf);
}

