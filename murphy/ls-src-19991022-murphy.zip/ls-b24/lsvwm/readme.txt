the new litestep virtual window manager (LsVWM) creates 3 windows
LsVWMWnd is created as an invisible (hidden) window for receiving messages such as 
hotkey messages
NavWnd is created as a (when not active) invisible window for navigating the virtual
desktop space.
WharfWnd is created for a mini-nav in the wharf.

LsVWMWnd and NavWnd are created by initModuleEx, and WharfWnd is created by initWharfModule.

NavWnd will have configurable scale and max width/height per pane.
NavWnd will look something like the following for a 4x4 virtual desk area:

^ = windowshade mode, turns into down arrow when windowshaded
* = stay on top button
+ = dont hide (* is ignored when this is not set)
X = close window button (doesnt shut down LsVWM, just hides the NavWnd.)
 _______________________________________
|            LsVWM Navigator        ^*+X|
|=======================================|
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|.........:.........:.........:.........|
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|.........:.........:.........:.........|
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|.........:.........:.........:.........|
|         :         :         :         |
|         :         :         :         |
|         :         :         :         |
|_________:_________:_________:_________|

When initModuleEx is first called, after creating its windows, it checks for the
presence of the wharf nav being loaded. if it is, it tells the wharf that it is alive.

When quitModule is called, it tells the wharf nav, if present, that it is dead.

When initWharfModule is first called, it creates its window, checks for the presence
of the LsVWM module, if it can't find it then it displays the 'dead' icon in the wharf
Otherwise, it creates its mini nav-window and starts operating.

Whenever the mini nav-window receives the WM_HELLO msg it refreshes the window completely,
whether or not it was already alive.

Whenever the mini nav-window receives the WM_GOODBYE msg it shuts down the nav function
and displays the dead icon.

Whenever quitWharfModule is called, it sets itself as nonexistant and dies.