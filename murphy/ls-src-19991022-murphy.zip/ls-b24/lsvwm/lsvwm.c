/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

 15/09/98 - J. Vaughn
            This file contains the source code for virtual window manager
			module.

****************************************************************************/

/*************************************************************************/
/*************************************************************************/
/* TODO: Add navigator window code, mini-nav wharf code, sticky code,    */
/*       config reading code to read hotkey, sticky, nDesks, etc from    */
/*       step.rc                                                         */
/*************************************************************************/
/*************************************************************************/

#include <windows.h>
#include <stdio.h>
#include "lsvwm.h"
#include "lsapi.h"

void ReadConfig();
BOOL OnThisDesk(HWND hWnd);

FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

windowType *winList;
int maxWin;
HWND FindWharfChild(void);

/* Global variables, etc */
HWND parent;
HWND refTopLevel = NULL;
HWND LsVWMWnd = NULL; /* Hidden window to receive messages to for LsVWM */
HWND WharfWnd = NULL; /* Wharf view window handle */
HWND NavWnd = NULL; /* Navigator window handle */

COLORREF borderColor, foreColor, backColor, backSelColor;

char szLitestepPath[256];
char szImagePath[256];
int titleSize = 16;
int DeskInView = 1;
int CurrentDesk = 1; /* indicates the current desk we are on */
int nDesksX = 0; /* indicates the number of desks wide the virtual area is */
int nDesksY = 0; /* indicates the number of desks tall the virtual area is */

HBITMAP titlebarImage = NULL;
HBITMAP navBackpix = NULL;
HBITMAP navImage;
HDC navDC;

char LsVWMClassName[] = "LsVWM Message Window"; /* class name of the msg wnd */
char NavClassName[] = "LsVWM Navigator Window"; /* class name of the nav wnd */
char WharfClassName[] = "LsVWM Wharf Window"; /* class name of the wharf wnd */

BOOL navHide = FALSE;
int wndSize; /* size of the wharf mininav */
int ScreenWidth, ScreenHeight;
int vwmBaseX = 0, vwmBaseY = 0;

stickyT Stickies[MAX_STICKIES];
int nStickies = 0;
/* functions */

void ReadConfig()
{
	char szToken[256], szBuf[256], *tmp;

	ZeroMemory(&Stickies,sizeof(Stickies));
	nStickies = 0;
	GetRCString("PixmapPath", szImagePath, "c:\\litestep\\images\\", 256);
	if (GetRCString("VWMTitlebarPix", szToken, "", 256))
	{
		char szTemp[256];
		wsprintf(szTemp, "%s%s", szImagePath, szToken);
		titlebarImage = LoadLSImage (szTemp, NULL);
	}
	if (GetRCString("VWMNavPix", szToken, "", 256))
	{
		char szTemp[256];
		wsprintf(szTemp, "%s%s", szImagePath, szToken);
		navBackpix = LoadLSImage (szTemp, NULL);
	}

	nDesksX = GetRCInt("VWMDesksX",2);
	nDesksY = GetRCInt("VWMDesksY",2);
	/* if we have too few (0 or less) or too many (more than MAX_DESKS) abort */
	if ((nDesksX*nDesksY) <= 1) 
	{
		nDesksX = 2;
		nDesksY = 2;
	}
{
		FILE *f;
		
		f = LCOpen (NULL);
		if (f)
		{
			char	buffer[4096];
			char	token1[4096], token2[4096], extra_text[4096];
			char*	tokens[2];

			tokens[0] = token1;
			tokens[1] = token2;
			
			buffer[0] = 0;

			while (LCReadNextConfig (f, "*Sticky", buffer, sizeof (buffer)))
			{
				int count;
				
				token1[0] = token2[0] = extra_text[0] = '\0';
				
				count = LCTokenize (buffer, tokens, 2, extra_text);
				
				switch (count)
				{
				case 1:
					{ /* caption match */
						Stickies[nStickies].type = 0;
						strcpy((char*)&Stickies[nStickies].text,tokens[0]);
						nStickies++;
						break;
					}
				case 2: 
					{ /* class match */
						Stickies[nStickies].type = atoi(tokens[1]);
						strcpy((char*)&Stickies[nStickies].text,tokens[0]);
						nStickies++;
						break;
					}
				default: break;
				}
			}
			LCClose(f);
		}
	}
	if ((nDesksX*nDesksY) > MAX_DESKS) 
	{
		nDesksX = 2;
		nDesksY = 2;
	}
	borderColor = GetRCColor("VWMBorderColor", 0x000000);
	backColor = GetRCColor("VWMBackColor", 0x808040);
	foreColor = GetRCColor("VWMForeColor", 0x808080);
	backSelColor = GetRCColor("VWMSelBackColor", 0x404040);

	sprintf (szBuf, "%s\\MODULES.INI", szLitestepPath);
	GetPrivateProfileString("VWM", "Position", "0,0", (char *)&szBuf, sizeof(szBuf), szBuf);
	tmp = strtok(szBuf, ",");
	vwmBaseX = atoi(tmp);
	tmp = strtok(NULL, "");
	vwmBaseY = atoi(tmp);
	if (vwmBaseX < 0)
		vwmBaseX += ScreenWidth;
	if (vwmBaseY < 0)
		vwmBaseY += ScreenHeight;
}

/************************************************************************/
/* returns 1 if sticky, 0 if not                                        */
/************************************************************************/
int Sticky(HWND hWnd)
{
	int i;
	char buf[256];
	GetWindowText(hWnd,buf,255);
	for (i=0;i<MAX_STICKIES;i++)
	{
		if (!strncmp((char*)Stickies[i].text,buf,strlen(buf)))
		{
			return 1;
		}
	}
	return 0;
}

/************************************************************************/
/* hides all windows on specified desktop                               */
/************************************************************************/
int HideDesk(int desk)
{
	int x;

	for (x = 0; x < maxWin; x++)
	{
		if ((IsWindow(winList[x].Handle) && (!Sticky(winList[x].Handle))))
		{
			/* if window hasn't been assigned a desktop yet see if we can do it here */
			if ((winList[x].Desk == 0) || OnThisDesk(winList[x].Handle)) 
			{
					winList[x].Desk = CurrentDesk;
			}
			if (winList[x].Desk == desk)
			{
				winList[x].Position.left += (ScreenWidth*2);
				SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
			}
		}
	}

	return 0;
}

/************************************************************************/
/* unhides all windows on specified desktop                             */
/************************************************************************/
int UnHideDesk(int desk)
{
	int x;

	for (x = 0; x < maxWin; x++) 
	{
		if ((IsWindow(winList[x].Handle) && (!Sticky(winList[x].Handle))))
		{
			/* if window hasn't been assigned a desktop yet see if we can do it here */
			if ((winList[x].Desk == 0) || OnThisDesk(winList[x].Handle))
			{
					winList[x].Desk = CurrentDesk;
			}
			if (winList[x].Desk == desk)
			{
				winList[x].Position.left -= (ScreenWidth*2);
				SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
			}
		}
	}

	return 0;
}

void ShowAll()
{
	int x;

	for (x=0;x< maxWin;x++) 
	{
		if (IsWindow(winList[x].Handle))
		{
			winList[x].Position.left %= ScreenWidth;
			SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
		}
	}
}

BOOL OnThisDesk(HWND hWnd)
{
	RECT r;

	GetWindowRect(hWnd, &r);
	if ((r.left < ScreenWidth) && (r.right > 0)) return TRUE;
	return FALSE;
}

/************************************************************************/
/* gathers windows to desktop                                           */
/************************************************************************/
void GatherWindows(void)
{
	ShowAll();
}

/************************************************************************/
/* goes to specified desktop                                            */
/************************************************************************/
int GotoDesk(int desk)
{
	if (desk < 1) {return 1;}
	if (desk > (nDesksX*nDesksY)) {return 1;}

	HideDesk(CurrentDesk);
	UnHideDesk(desk);
	CurrentDesk = desk;

	return 0;
}

/************************************************************************/
/* moves up one desktop                                                 */
/************************************************************************/
int MoveUp()
{
	if (CurrentDesk > nDesksX) {
		GotoDesk(CurrentDesk-nDesksX);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves down one desktop                                               */
/************************************************************************/
int MoveDown()
{
	if (CurrentDesk <= (nDesksX*(nDesksY-1))) {
		GotoDesk(CurrentDesk+nDesksX);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves left one desktop                                               */
/************************************************************************/
int MoveLeft()
{
	if ((CurrentDesk % nDesksX) != 1) {
		GotoDesk(CurrentDesk-1);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves right one desktop                                              */
/************************************************************************/
int MoveRight()
{
	if ((CurrentDesk % nDesksX) != 0){
		GotoDesk(CurrentDesk+1);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* activates the navigator window                                       */
/************************************************************************/
int ActivateNav()
{
	char tbuf[50];
	itoa(CurrentDesk,(char*)&tbuf,10);
	MessageBox(NULL,(char*)&tbuf,"LsVWM Desk #",MB_OK);

	return 0;
}

/************************************************************************/
/* Window Procedure for the LsVWM message window                        */
/************************************************************************/
LRESULT CALLBACK LsVWMWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case HOTKEY_UP: {MoveUp(); return 0;}
	case HOTKEY_DOWN: {MoveDown(); return 0;}
	case HOTKEY_LEFT: {MoveLeft(); return 0;}
	case HOTKEY_RIGHT: {MoveRight(); return 0;}
	case HOTKEY_NAV: {ActivateNav(); return 0;}
	case HOTKEY_DESK: {GotoDesk(wParam); return 0;}
	case GOTO_HWND:
		{
			if (!wParam)
			{
				int i;

				for (i = 0; i < maxWin; i++)
				{
					if (IsWindow(winList[i].Handle))
					{
						if (winList[i].Handle == (HWND)lParam)
						{
							/* if window hasn't been assigned a desktop yet see if we can do it here */
							if ((winList[i].Desk == 0) || OnThisDesk(winList[i].Handle))
							{
									winList[i].Desk = CurrentDesk;
							}
							if (winList[i].Desk != 0 && winList[i].Desk != CurrentDesk)
								GotoDesk(winList[i].Desk);
						}
					}
				}
				SwitchToThisWindow((HWND)lParam, 1);
			} else {
				GatherWindows();
			}
		}
		return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}


/************************************************************************/
/* Window Procedure for the LsVWM navigator window                      */
/************************************************************************/
LRESULT CALLBACK NavWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_CREATE: return 0;

		case 9354:
			{
				if (!navHide)
				{
					SetWindowPos(hWnd, 0, vwmBaseX, vwmBaseY, 64, titleSize, SWP_NOZORDER);
					navHide = TRUE;
				} else {
					SetWindowPos(hWnd, 0, vwmBaseX, vwmBaseY, 64, (4*48)+titleSize, SWP_NOZORDER);
					navHide = FALSE;
				}
			}
			return 0;

		case WM_NCLBUTTONDBLCLK:
			{
				POINTS pt = MAKEPOINTS(lParam);
				RECT r;

				GetWindowRect(hWnd, &r);
				pt.y -= (short)r.top;
				if (pt.y <= titleSize)
					SendMessage(hWnd, LM_VWMNAV, 0, 0);
			}
			return 0;
	
		case WM_NCHITTEST: 
			{
				POINTS pt = MAKEPOINTS(lParam);
				RECT r;

				GetWindowRect(hWnd, &r);
				pt.y -= (short)r.top;
				if (pt.y <= titleSize)
					return HTCAPTION;
			}
			break;

		case WM_MOVE:
			{
				char szIni[256], szBuf[256];

				vwmBaseX = LOWORD(lParam);
				vwmBaseY = HIWORD(lParam);
				sprintf(szIni, "%s\\MODULES.INI", szLitestepPath);
				sprintf(szBuf, "%d,%d", vwmBaseX, vwmBaseY);
				WritePrivateProfileString("VWM", "Position", szBuf, szIni);
			}
			return 0;

		case WM_PAINT: 
			{
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hWnd,&ps);
				RECT r;

				GetClientRect(hWnd, &r);
				BitBlt(hdc, 0, 0, r.right, r.bottom, navDC, 0, 0, SRCCOPY);
				EndPaint(hWnd,&ps);
			}
			return 0;

		case WM_TIMER:
			{
				char szBuf[12];
				RECT r;
				HBRUSH backBrush, foreBrush, oldBrush;
				HPEN hPen, oldPen; 
				HFONT hFont, oldFont;
				HDC src = CreateCompatibleDC(NULL);
				int i, dsk;

				GetClientRect(hWnd, &r);

				hFont = CreateFont(8, 6, 0,	0, 0,
							FALSE, FALSE, FALSE, ANSI_CHARSET,
							OUT_DEFAULT_PRECIS,	CLIP_DEFAULT_PRECIS,
							DEFAULT_QUALITY, DEFAULT_PITCH,
							0);
				hPen = CreatePen(PS_SOLID, 1, borderColor);
				backBrush = CreateSolidBrush(backColor);
				foreBrush = CreateSolidBrush(foreColor);
				SetBkMode(navDC, TRANSPARENT);
				SetTextColor(navDC, borderColor);
				oldBrush = SelectObject(navDC, backBrush);
				oldPen = SelectObject(navDC, hPen);
				oldFont = SelectObject(navDC, hFont);
				Rectangle(navDC, r.left, r.top, r.right, r.bottom);
				if (navBackpix)
				{
					SelectObject(src, navBackpix);
					BitBlt(navDC, 0, titleSize, 64, 48, src, 0, 0, SRCCOPY);
					BitBlt(navDC, 0, titleSize+48, 64, 48, src, 0, 0, SRCCOPY);
					BitBlt(navDC, 0, titleSize+96, 64, 48, src, 0, 0, SRCCOPY);
					BitBlt(navDC, 0, titleSize+144, 64, 48, src, 0, 0, SRCCOPY);
				}
				MoveToEx(navDC, 0, titleSize+48, NULL);
				LineTo(navDC, r.right, titleSize+48);
				MoveToEx(navDC, 0, titleSize+96, NULL);
				LineTo(navDC, r.right, titleSize+96);
				MoveToEx(navDC, 0, titleSize+144, NULL);
				LineTo(navDC, r.right, titleSize+144);
				SelectObject(navDC, foreBrush);

				if (CurrentDesk > DeskInView+3)  DeskInView = CurrentDesk-3;
				else if (CurrentDesk < DeskInView) DeskInView = CurrentDesk;

				for (i =0; i< maxWin; i++)
				{
					if (IsWindow(winList[i].Handle))
					{
						/* if window hasn't been assigned a desktop yet see if we can do it here */
						if ((winList[i].Desk == 0) || OnThisDesk(winList[i].Handle))
						{
								winList[i].Desk = CurrentDesk;
						}
						for (dsk = 0; dsk < 4; dsk++)
						{
							if (winList[i].Desk == DeskInView+dsk)
							{
								GetWindowRect(winList[i].Handle, &r);
								if (DeskInView+dsk != CurrentDesk)
								{
									r.left -= (ScreenWidth*2);
									r.right -= (ScreenWidth*2);
								}
								r.left /= (ScreenWidth/64);
								r.right /= (ScreenWidth/64);
								r.top /= (ScreenHeight/48);
								r.bottom /= (ScreenHeight/48);
								if (r.bottom > 48) r.bottom = 48;
								if (r.right > 64) r.right = 64;
								Rectangle(navDC, r.left, r.top+titleSize+(48*dsk), r.right, r.bottom+titleSize+(48*dsk));
							}
						}
					}
				}

				wsprintf(szBuf, "%d", DeskInView);
				TextOut(navDC, 2, 38+titleSize, szBuf, strlen(szBuf));
				wsprintf(szBuf, "%d", DeskInView+1);
				TextOut(navDC, 2, 38+48+titleSize, szBuf, strlen(szBuf));
				wsprintf(szBuf, "%d", DeskInView+2);
				TextOut(navDC, 2, 38+96+titleSize, szBuf, strlen(szBuf));
				wsprintf(szBuf, "%d", DeskInView+3);
				TextOut(navDC, 2, 38+144+titleSize, szBuf, strlen(szBuf));

				if (titlebarImage)
				{
					SelectObject(src, titlebarImage);
					BitBlt(navDC, 0, 0, 64, titleSize, src, 0, 0, SRCCOPY);
				}

				SelectObject(navDC, oldBrush);
				SelectObject(navDC, oldPen);
				SelectObject(navDC, oldFont);
				DeleteDC(src);
				DeleteObject(hPen);
				DeleteObject(backBrush);
				DeleteObject(foreBrush);
				DeleteObject(hFont);

				GetClientRect(hWnd, &r);
				InvalidateRect(hWnd, &r, TRUE);
			}
			return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

/************************************************************************/
/* Window Procedure for the LsVWM wharf mini-nav window                 */
/************************************************************************/
LRESULT CALLBACK WharfWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_TIMER:
			{
				RECT r;

				GetClientRect(hWnd, &r);
				InvalidateRect(hWnd, &r, TRUE);
			}
		return 0;

		case WM_PAINT: 
			{
				PAINTSTRUCT ps;
				HDC hdc = BeginPaint(hWnd,&ps);
				HPEN  hPen;
				HBRUSH backBrush, foreBrush;
				RECT r;
				char szText[12];
				HFONT hFont;
				int i;

				GetClientRect(hWnd, &r);

				// Draw the vwm borders
				hPen = CreatePen(PS_SOLID, 1, borderColor);
				backBrush = CreateSolidBrush(backColor);
				foreBrush = CreateSolidBrush(foreColor);
				SetBkMode(hdc, TRANSPARENT);
				SetTextColor(hdc, borderColor);
				SelectObject(hdc, hPen);
				SelectObject(hdc, backBrush);
				Rectangle(hdc, r.left, r.top, r.right, r.bottom);
				SelectObject(hdc, foreBrush);

				for (i = 0; i < maxWin; i++)
				{
					if (IsWindow(winList[i].Handle))
					{
						/* if window hasn't been assigned a desktop yet see if we can do it here */
						if ((winList[i].Desk == 0) || OnThisDesk(winList[i].Handle)) 
						{
								winList[i].Desk = CurrentDesk;
						}
						if (winList[i].Desk == CurrentDesk)
						{
							GetWindowRect(winList[i].Handle, &r);
							r.left /= (ScreenWidth/64);
							r.top /= (ScreenHeight/64);
							r.right /= (ScreenWidth/64);
							r.bottom /= (ScreenHeight/64);
							Rectangle(hdc, r.left, r.top, r.right, r.bottom);
						}
					}
				}

				hFont = CreateFont(
							8,
							6,
							0,
							0,
							0,
							FALSE,
							FALSE,
							FALSE,
							ANSI_CHARSET,
							OUT_DEFAULT_PRECIS,
							CLIP_DEFAULT_PRECIS,
							DEFAULT_QUALITY,
							DEFAULT_PITCH,
							0);

				wsprintf(szText, "%d", CurrentDesk);
				TextOut(hdc, 4, 44, szText, strlen(szText));

				EndPaint(hWnd,&ps);
				DeleteObject(foreBrush);
				DeleteObject(backBrush);
				DeleteObject(hPen);
				DeleteObject(hFont);
			}
			return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

/* exported functions */

/************************************************************************/
/* initModuleEx, sets up the VWM message window etc                     */
/************************************************************************/
int initModuleEx(HWND prnt, HINSTANCE dll, LPCSTR szPath)
{
	WNDCLASS msgWC;
	WNDCLASS navWC;
	HWND vwm;
	UINT Msgs[10];
	RECT r;

	parent = prnt;
	strcpy(szLitestepPath, szPath);
	GetClientRect(GetDesktopWindow(), &r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	ReadConfig();

	winList = (windowType *)SendMessage(parent, LM_WINLIST, 0, 0);
	maxWin = (int) SendMessage(parent, LM_WINLIST, 1, 0);

	/* Register our message window class */
	memset(&msgWC,0,sizeof(WNDCLASS)); /* clear the strucutre */
	msgWC.hInstance = dll;
	msgWC.lpszClassName = (char *)&LsVWMClassName;
	msgWC.lpfnWndProc = (WNDPROC)&LsVWMWndProc;
	RegisterClass(&msgWC);

	/* Register our navigator window class */
	memset(&navWC,0,sizeof(WNDCLASS)); /* clear the strucutre */
	navWC.hInstance = dll;
	navWC.lpszClassName = (char *)&NavClassName;
	navWC.lpfnWndProc = (WNDPROC)&NavWndProc;
	navWC.style = CS_DBLCLKS;
	RegisterClass(&navWC);

	SwitchToThisWindow = (FARPROC (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

	vwm = FindWharfChild();
	if (vwm)
	{
		WNDCLASS wharfWC;

		/* Register our wharf window class */
		memset(&wharfWC,0,sizeof(WNDCLASS)); /* clear the strucutre */
		wharfWC.hInstance = dll;
		wharfWC.lpszClassName = (char *)&WharfClassName;
		wharfWC.lpfnWndProc = (WNDPROC)&WharfWndProc;
		RegisterClass(&wharfWC);

		WharfWnd = CreateWindowEx(
			0,
			(LPCTSTR)&WharfClassName,
			"LSVWMWharf",
			WS_CHILD,
			0,0,
			64,64,
			vwm,
			NULL,
			dll,
			NULL);

		SetWindowLong(WharfWnd,GWL_USERDATA,magicDWord);
		SetTimer(WharfWnd, 0, 500, NULL);
		ShowWindow(WharfWnd, SW_SHOWNORMAL);
	}
	
	/* Create our windows */
	LsVWMWnd = CreateWindowEx(WS_EX_TOOLWINDOW,(LPCTSTR)&LsVWMClassName,
		(LPCTSTR)&LsVWMClassName,WS_BORDER,0,0,0,0,NULL,NULL,dll,NULL);

	NavWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		(LPCTSTR)&NavClassName,
		"LSVWMNav",
		WS_POPUP | WS_CLIPCHILDREN,
		vwmBaseX,vwmBaseY,
		64,(48*4)+titleSize,
		parent,
		NULL,
		dll,
		NULL);

	if (LsVWMWnd != NULL) {SetWindowLong(LsVWMWnd,GWL_USERDATA,magicDWord);}
		else {MessageBox(NULL,"Error Creating Message Window","Error",MB_OK);}

	if (NavWnd != NULL) {SetWindowLong(NavWnd,GWL_USERDATA,magicDWord);}
	else {MessageBox(NULL,"Error Creating Navigator Window","Error",MB_OK);}

	{
		HDC hdc = GetDC(NavWnd);

		navDC = CreateCompatibleDC(NULL);
		GetClientRect(NavWnd, &r);
		navImage = CreateCompatibleBitmap(hdc, r.right, r.bottom);
		ReleaseDC(NavWnd, hdc);
		SelectObject(navDC, navImage);
		SendMessage(NavWnd, WM_TIMER, 0, 0); // update double buffer now
	}

	SetTimer(NavWnd, 0, 500, NULL);
  	ShowWindow(NavWnd, SW_SHOWNORMAL);

	Msgs[0] = LM_BRINGTOFRONT;
 	Msgs[1] = HOTKEY_UP;
	Msgs[2] = HOTKEY_DOWN;
	Msgs[3] = HOTKEY_LEFT;
	Msgs[4] = HOTKEY_RIGHT;
	Msgs[5] = HOTKEY_NAV;
	Msgs[6] = HOTKEY_DESK;
	Msgs[7] = 0;
	SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)LsVWMWnd, (LPARAM) Msgs);
	
	return 0;
};

/************************************************************************/
/* quitModule, destroys the windows etc                                 */
/************************************************************************/
void quitModule(HINSTANCE dll)
{
	UINT Msgs[10];

	KillTimer(NavWnd, 0);
	KillTimer(WharfWnd, 0);
	Msgs[0] = LM_BRINGTOFRONT;
 	Msgs[1] = HOTKEY_UP;
	Msgs[2] = HOTKEY_DOWN;
	Msgs[3] = HOTKEY_LEFT;
	Msgs[4] = HOTKEY_RIGHT;
	Msgs[5] = HOTKEY_NAV;
	Msgs[6] = HOTKEY_DESK;
	Msgs[7] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM)LsVWMWnd, (LPARAM) Msgs);
	/* unregister the hotkeys BEFORE destroying the windows! */
	/* destroy the windows */
	if (LsVWMWnd != NULL) {DestroyWindow(LsVWMWnd);} /* kill the msg window */
	if (NavWnd != NULL) {DestroyWindow(NavWnd);} /* kill the nav window */
	if (WharfWnd != NULL) {DestroyWindow(WharfWnd);} /* kill the wharf window */
	DeleteDC(navDC);
	DeleteObject(titlebarImage);
	DeleteObject(navBackpix);
	DeleteObject(navImage);
	/* unregister our classes */
	UnregisterClass((LPCTSTR)&LsVWMClassName,dll);
	UnregisterClass((LPCTSTR)&NavClassName,dll);	
};

BOOL CALLBACK EnumChildWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (!refTopLevel)
	{
		refTopLevel = hwnd;
		return FALSE;
	}

	return TRUE;
}

HWND FindWharfChild(void)
{
	HWND wharf = FindWindow("TWharfGlobalContainer", NULL);
	HWND prev;
	char capt[256];

	if (!wharf)
		return NULL;

	refTopLevel = NULL;
	EnumChildWindows(wharf, EnumChildWindowsProc, 0);

	for (prev = GetWindow (refTopLevel, GW_HWNDLAST);
		prev;
		prev = GetWindow (prev, GW_HWNDPREV))
	{
		if (GetWindowText(prev, capt, sizeof(capt)) > 0)
		{
			if (!stricmp(capt, "VWM"))
			{
				return prev;
			}
		}
	}
	return NULL;
}