#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <commctrl.h>
#include "vwm.h"
#define VWM_DESKNO 0x11110000;

HWND hMainWnd=NULL;
HWND parent = NULL;
HWND refToplevel;
HWND newW=(HWND)-1;
HWND lastActive=NULL;
HWND photoshop;
HWND eudora;
HWND tapp, desk, winswitch;
HINSTANCE inst;

HDC memDC, bgDC;
HBITMAP	memBM, oldBM, oldBG;
HBITMAP bBGBitmap, sBGBitmap, wBGBitmap, tBGBitmap;
HIMAGELIST hBGList;

RECT *deskRect = NULL;
RECT oldWinPos;
POINT lastPoint;
POINT diff;

UINT Timer=0;
UINT TimerAct=1;
UINT nOffsetX, nOffsetY;
UINT mTimer=2;
UINT mcTimer=3;
UINT autoTimer=4;

BOOL NoGather=FALSE;
BOOL backInit=FALSE;
BOOL moveCursor=FALSE;
BOOL background=FALSE;
BOOL snapshot=FALSE;
BOOL bevel=FALSE;
BOOL rolled=FALSE;
BOOL onTop=FALSE;
BOOL noShow=FALSE;
BOOL noMove=FALSE;
BOOL titlebars=FALSE;
BOOL NeverSwitch=FALSE;
BOOL FocusCenter=FALSE;
BOOL VWMautohide=FALSE;
BOOL autoHidden=FALSE;
BOOL autoswitch=FALSE;
BOOL useIcons=FALSE;
BOOL dockedOnWharf=FALSE;
BOOL useInitialDesk=FALSE;

char szAppName[] = "sysVWM";
char szLitestepPath [256];
char szImagePath [256];
char inipath[256];

int backX, backY, selX, selY, winX, winY, titleX, titleY;
int inFix(HWND hwnd);
int backColor;
int winColor;
int foreColor;
int selBackColor;
int borderColor;
int snapWidth = 3;
int autoHideDistance = 3;
int autoSwitchDistance = 1;
int autoHideFix = 1;
int inchk=0;
int mpos=0;
int mTimeout=50;
int searched=0;
int wndSizeX, wndSizeY, ratioX, ratioY;
int currentScreen=0;
int ScreenWidth = 800;
int ScreenHeight = 600;
int TitlebarHeight;
int titleHeightMod = 16;
int getDesktop(HWND h);
int outsideAnyScreen(RECT r);
int getDesktopByRect(RECT r);
int First = 1;
int ScreensX = 2;
int ScreensY = 2;
int mainX = 0;
int mainY = 0;
int mainWidth = 64;
int mainHeight = 64;
int MaxScreens = 4;
int nWinRect=0;
int movingWin=-1;
int movingMain=0;
int ticksNewW=0;
int iconSize=16;
int initialDesk=0;
int stickyTotal=0;
int mouseLeft=2;
int mouseRight=1;
int mouseMiddle=0;
int borderSize=0;

volatile int lock=0;

ConfigInfoT StickyConfig[256];
winDataType winRect[500];
winFixType winFix[500];

LPTSTR pszWallpapers[256];

void (__stdcall *SwitchToThisWindow)(HWND, int);
void BangGather(HWND caller ,char* args);
void ReadConfig (void);
void prefixWinFix(int s);
void postfixWinFix(int s);
void removeWinFix(HWND hwnd);
void addWinFix(HWND hwnd, int s);
void CreateImageMasks(HWND hwnd);
void createView(void);
void createRecordedView(void);
void switchToDesktop(int desk, BOOL fixFocus);
void gatherAll();
void DoEvents(int n);
void MakeBuffer(HWND hWnd);
void RegisterBangCommands(void);
void UnRegisterBangCommands(void);
void getShifts(int old, int desk, int *addH, int *addV);
void SetDeskWallpaper();

HICON getIconFromWindow(HWND hWnd, BOOL bBigIcon);
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK searchLSVWMproc(HWND hWnd, LPARAM lParam );

int StickyCheck1(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetClassName(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

int StickyCheck0(HWND targetWin, char* matchval)
{
	char tmpbuf[80];
	GetWindowText(targetWin, (char *)&tmpbuf, 79);
	if (match(matchval,(char *)&tmpbuf)) {return 1;}
	return 0;
}

BOOL Sticky(HWND hwnd)
{
	int num = 0;
	int t = 0;
	while (1) {
		num++;
		t = StickyCheck1(hwnd,StickyConfig[num].match);
		if ((t == 0) && (num < stickyTotal)) continue;
		else break;
	}
	if (t == 0) {
		num = 0;
		while (1) {
			num++;
			t = StickyCheck0(hwnd,StickyConfig[num].match);
			if ((t == 0) && (num < stickyTotal)) continue;
			else break;
		}
	}
	if (t == 1) return TRUE;
	else return FALSE;
}

void GetBMPSize(HBITMAP hBitmap, int *x, int *y)
{
	BITMAP bm;
	if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
    {
		*x=0;
		*y=0;
    }
	else
    {
		*x = bm.bmWidth;
		*y = bm.bmHeight;
    }
}

void BangUp(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen > (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen - ScreensX, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDown(HWND caller ,char* args)
{
	RECT r;
	if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
	{
		switchToDesktop(currentScreen+ ScreensX, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangLeft(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) > 0 ) && !lock)
	{
		switchToDesktop(currentScreen-1, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRight(HWND caller ,char* args)
{
	RECT r;
	if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen+1, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDesk(HWND caller ,char* args)
{
	RECT r;
	int i = atoi(args);
	
	if ((currentScreen != i) && (i >= 0) && (i < MaxScreens) && !lock)
	{
		switchToDesktop(i, TRUE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRollUp(HWND caller ,char* args)
{
	if (dockedOnWharf) return;
	if (!rolled)
	{
		rolled = TRUE;
		ShowWindow(hMainWnd,SW_HIDE);
	} else {
		rolled = FALSE;
		ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
}

//statler 990722 begin (snowchyld)
void BangShow(HWND caller ,char* args)
{
	if (dockedOnWharf) return;
	rolled = FALSE;
	ShowWindow(hMainWnd,SW_SHOWNORMAL);
}

void BangHide(HWND caller ,char* args)
{
	if (dockedOnWharf) return;
	rolled = TRUE;
	ShowWindow(hMainWnd,SW_HIDE);
}
//statler 990722 end (snowchyld)


void BangOpen(HWND caller ,char* args)
{
	int deskx = 0;
	int desky = 0;
	int s=0;
	char parm2[MAX_PATH]; /*parm3[MAX_PATH];*/
	char *destptr, *topptr;
	//SHELLEXECUTEINFO si;
	RECT r;

	topptr = args;

	if (topptr != NULL) {
		{		
			char string[2000], seps[2000];
			char *token;
			
			destptr = args;
			
			if (strlen(args) != 0) {
				
				strcpy(string, args);
				
				strcpy(seps, " ");
				token = strtok( string, seps );
				s = atoi(token);
				
				strcpy(seps, "");
				token = strtok( NULL, seps );
				strcpy(parm2, token);
			}
		}

    /*
		destptr = parm2;
		
		if (destptr != NULL)
		{		
			char string[2000], seps[2000];
			char *token;
			
			if (strlen(parm2) != 0) {
				
				strcpy(string, parm2);
				
				if (string[0] == '\"') {
					strcpy(seps, "\"");
					token = strtok( string, seps );
				}
				else {
					strcpy(seps, " ");
					token = strtok( string, seps );
				}
				strcpy(parm2, token);
				
				strcpy(seps, "");
				token = strtok( NULL, seps );
				if (token != NULL) strcpy(parm3, token);
			}
		}
    */
	}
	
	if ((currentScreen != s) && (s >= 0) && (s < MaxScreens) && !lock)
	{
		switchToDesktop(s, FALSE);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
	
	if (parm2)
	{
		LSExecute(NULL, parm2, 0);
    /*
    memset(&si, 0, sizeof(si));
		si.cbSize = sizeof(SHELLEXECUTEINFO);
		si.lpDirectory = NULL;
		si.lpVerb = NULL;
		si.nShow = 1;
		si.fMask = SEE_MASK_DOENVSUBST;
		si.lpFile = parm2;
		si.lpParameters = parm3;
		ShellExecuteEx(&si);
    */
	}
	
	GetClientRect(hMainWnd,&r);
	createView();
	InvalidateRect(hMainWnd, &r, FALSE);
}

void BangReset(HWND caller ,char* args)
{
	if (dockedOnWharf) return;
    if (mpos)
	{
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
	}
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);
	DestroyWindow(hMainWnd);
	
	ReadConfig();
	if (mainX < 0) mainX = ScreenWidth + mainX;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
	
	if (mainY < 0) mainY = ScreenHeight + mainY;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;
	
	hMainWnd = CreateWindowEx(
		WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
		szAppName,
		szAppName,
		WS_POPUP,
		mainX, mainY,
		mainWidth, mainHeight,
		parent,
		NULL,
		inst,
		NULL);
	
	if (!hMainWnd) 
	{						   
		MessageBox(parent,"Error creating window",szAppName,MB_OK);
		PostQuitMessage(0);
	}
	
	if (!onTop) SetParent(hMainWnd, parent);
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 
	DragAcceptFiles(hMainWnd, TRUE);
	
	if (onTop) SetWindowPos(hMainWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	
	if (!noShow) {
		if (VWMautohide) {
			POINT pts;
			GetCursorPos(&pts);
			if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
			{
				if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) {
					rolled = TRUE;
					ShowWindow(hMainWnd,SW_HIDE);
				}
			}
		}
		else ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
	else rolled = TRUE;
	
	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
	SetTimer(hMainWnd, autoTimer, 50, NULL);
	if (autoswitch) SetTimer(hMainWnd, mcTimer, 50, NULL);
}

void BangMoveApp(HWND caller ,char* args)
{
	HWND MoveHwnd = GetForegroundWindow();
	RECT newRect, r;
	int addH = 0, addV = 0;
	
	if (!stricmp (args, "Up")) {
		if (currentScreen > (ScreensX - 1))
			getShifts(currentScreen, currentScreen - ScreensX, &addH, &addV);
	}
	if (!stricmp (args, "Down")) {
		if (currentScreen < (MaxScreens - ScreensX))
			getShifts(currentScreen, currentScreen+ ScreensX, &addH, &addV);
	}
	if (!stricmp (args, "Left")) {
		if ((currentScreen % ScreensX) > 0)
			getShifts(currentScreen, currentScreen-1, &addH, &addV);
	}
	if (!stricmp (args, "Right")) {
		if ((currentScreen % ScreensX) < (ScreensX - 1))
			getShifts(currentScreen, currentScreen+1, &addH, &addV);
	}
	
	GetWindowRect(MoveHwnd, &newRect);
	
	MoveWindow(MoveHwnd, newRect.left + addH, newRect.top + addV, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);
	
	GetClientRect(hMainWnd,&r);
	createView();
	InvalidateRect(hMainWnd, &r, FALSE);
}

void RegisterBangCommands(void)
{
	AddBangCommand("!VWMGATHER", BangGather);
	AddBangCommand("!VWMUP", BangUp);
	AddBangCommand("!VWMDOWN", BangDown);
	AddBangCommand("!VWMLEFT", BangLeft);
	AddBangCommand("!VWMRIGHT", BangRight);
	AddBangCommand("!VWMDESK", BangDesk);
	AddBangCommand("!VWMROLLUP", BangRollUp);
	AddBangCommand("!VWMOPEN", BangOpen);
//statler 990722 start	(snowchyld)
	AddBangCommand("!VWMSHOW", BangShow);
	AddBangCommand("!VWMHIDE", BangHide);
//statler 990722 end    (snowchyld)
	AddBangCommand("!VWMRESET", BangReset);
	AddBangCommand("!VWMMOVEAPP", BangMoveApp);
}

void UnRegisterBangCommands(void)
{
	RemoveBangCommand("!VWMGATHER");
	RemoveBangCommand("!VWMUP");
	RemoveBangCommand("!VWMDOWN");
	RemoveBangCommand("!VWMLEFT");
	RemoveBangCommand("!VWMRIGHT");
	RemoveBangCommand("!VWMDESK");
	RemoveBangCommand("!VWMROLLUP");
	RemoveBangCommand("!VWMOPEN");
	RemoveBangCommand("!VWMRESET");
	RemoveBangCommand("!VWMMOVEAPP");
}

int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	dockedOnWharf = TRUE;
	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

int initModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	RECT r;
	HDC pDC;
	UINT Msgs[10];
	int XPos, YPos;
	int sze;
	
    memset(winFix, 0, sizeof(winFix));
	
	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;
	
	strcpy (szLitestepPath, szPath);
	
	ReadConfig ();
	
	if (dockedOnWharf) {
		mainX = borderSize;
		mainY = borderSize;
		mainWidth = 64-borderSize*2;
		mainHeight = 64-borderSize*2;
	}

	MaxScreens = ScreensX * ScreensY;
	deskRect = malloc(MaxScreens * sizeof(RECT));
	
	for (YPos = 0; YPos < ScreensY; YPos ++) for (XPos = 0; XPos < ScreensX; XPos ++)
	{
		int desk = (YPos * ScreensX) + XPos;
		int top = YPos * (ScreenHeight + 10);
		int left = XPos * (ScreenWidth + 10);
		
		deskRect[desk].top = top;
		deskRect[desk].left = left;
		deskRect[desk].right = left + ScreenWidth;
		deskRect[desk].bottom = top + ScreenHeight;
	}
	
	if (dockedOnWharf) {
		wndSizeX = (64 - borderSize*2) / ScreensX;
		wndSizeY = (64 - borderSize*2) / ScreensY;
		nOffsetX = ((wndSizeX*ScreensX) - 64)+borderSize;
		nOffsetY = ((wndSizeY*ScreensY) - 64)+borderSize;
		ratioX = ScreenWidth/wndSizeX;
		ratioY = ScreenHeight/wndSizeY;
	} else {	
		wndSizeX = mainWidth / ScreensX;
		wndSizeY = mainHeight / ScreensY;
		ratioX = ScreenWidth/wndSizeX;
		ratioY = ScreenHeight/wndSizeY;	
		nOffsetX = (wndSizeX*ScreensX) - mainWidth;
		nOffsetY = (wndSizeY*ScreensY) - mainHeight;
	}
	
	TitlebarHeight = wndSizeY / titleHeightMod;
	
	inst = dllInst;
	
	tapp = GetLitestepWnd();
	
	sze = sizeof(int) | VWM_DESKNO;
	
	SendMessage(tapp, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &currentScreen);

	desk = FindWindow("DesktopBackgroundClass", NULL);
	winswitch = FindWindow("#32771", NULL);
	(long)SwitchToThisWindow = (long)GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");
	
	{
		WNDCLASS wc;
		
		memset(&wc,0,sizeof(wc));
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.lpfnWndProc = WndProc;
		wc.hInstance = dllInst;
		wc.lpszClassName = szAppName;
		wc.style = CS_DBLCLKS;
		
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,"Error registering window class",szAppName,MB_OK);
			PostQuitMessage(0);
			return 1;
		}
	}
	
	if (dockedOnWharf) parent = ParentWnd;
	else {
		parent = FindWindow("DesktopBackgroundClass", NULL);
		if (!parent) parent = GetDesktopWindow();
	}
	
	if (mainX < 0) mainX = ScreenWidth + mainX;
	if (mainX > ScreenWidth-mainWidth) mainX = ScreenWidth - mainWidth;
	
	if (mainY < 0) mainY = ScreenHeight + mainY;
	if (mainY > ScreenHeight-mainHeight) mainY = ScreenHeight - mainHeight;

	hMainWnd = CreateWindowEx(
		dockedOnWharf?WS_EX_TRANSPARENT:WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
		szAppName,
		NULL,
		dockedOnWharf?WS_CHILD:WS_POPUP,
		mainX, mainY,
		mainWidth, mainHeight,
		parent,
		NULL,
		dllInst,
		NULL);
	
	if (!hMainWnd) 
	{						   
		MessageBox(NULL, "Error creating window", szAppName, MB_OK);
		PostQuitMessage(0);
		return 1;
	}
	
	Msgs[0] = 8891;
	Msgs[1] = 9355;
	Msgs[2] = 0;
	
	SendMessage(tapp, 9263, (WPARAM) hMainWnd, (LPARAM) Msgs);
	RegisterBangCommands();
	
	if (!onTop && !dockedOnWharf) SetParent(hMainWnd, parent);
	
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord);
	DragAcceptFiles(hMainWnd, TRUE);
	
	if (onTop) SetWindowPos(hMainWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	
	pDC = GetDC(parent);
	memDC = CreateCompatibleDC(pDC);
	memBM = CreateCompatibleBitmap(pDC, wndSizeX*ScreensX+ScreensX,wndSizeY*ScreensY+ScreensY);
	ReleaseDC(parent, pDC);
	oldBM = SelectObject(memDC,memBM);
	
	if (!dockedOnWharf) {
	if (!noShow) {
		if (VWMautohide) {
			POINT pts;
			GetCursorPos(&pts);
			if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
			{
				if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) {
					rolled = TRUE;
					ShowWindow(hMainWnd,SW_HIDE);
				}
			}
		}
		else ShowWindow(hMainWnd,SW_SHOWNORMAL);
	}
	else rolled = TRUE;
	} else ShowWindow(hMainWnd,SW_SHOWNORMAL);

	if (useInitialDesk)
	{
	if (initialDesk > MaxScreens-1) initialDesk = MaxScreens-1;
	switchToDesktop(initialDesk, FALSE);
	}
	
	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
	if (!dockedOnWharf) SetTimer(hMainWnd, autoTimer, 50, NULL);
	if (autoswitch) SetTimer(hMainWnd, mcTimer, 50, NULL);

	SetDeskWallpaper();
	return 0;
}

int quitWharfModule(HINSTANCE dllInst)
{
	return quitModule(dllInst);
}

int quitModule(HINSTANCE dllInst)
{
	int nDesks;
	int i;

	gatherAll();
	
    if (mpos)
	{
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
	}
	
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);
	KillTimer(hMainWnd, autoTimer);
	
	
	SelectObject(memDC,oldBM);
	SelectObject(bgDC, oldBG);
	DeleteObject(memDC);
	DeleteObject(bgDC);
	DeleteObject(bBGBitmap);
	DeleteObject(sBGBitmap);
	DeleteObject(tBGBitmap);
	DeleteObject(wBGBitmap);
	DeleteObject(memBM);
	ImageList_Remove(hBGList, -1);
	ImageList_Destroy(hBGList);
	
	DestroyWindow(hMainWnd);
	UnRegisterBangCommands();
	UnregisterClass(szAppName,dllInst);
	
	free(deskRect);
	deskRect = NULL;

	nDesks = ScreensX * ScreensY;

	for( i = 0; i < nDesks; i++ )
	{
		if( pszWallpapers[i] )
			free( pszWallpapers[i] );
	}

	return 0;
}

int MouseProc1down(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	if (lock) 
	{
		PostMessage(hwnd, message, wParam, lParam);
		return 0;
	}
	lock = 1;
	{
		POINT pt;
		int deskx = 0;
		int desky = 0;
		int s=0;
		
		if (dockedOnWharf) {
			POINTS pts;
			pts = MAKEPOINTS(lParam);
			pt.x = pts.x;
			pt.y = pts.y;
		} else {
			GetCursorPos(&pt);
		}

		deskx = (pt.x-mainX) / wndSizeX;
		desky = (pt.y-mainY) / wndSizeY;

		s = (desky * ScreensX) + deskx;
		
		{
			RECT r;
			switchToDesktop(s, TRUE);
			GetClientRect(hwnd,&r);
			createView();
			InvalidateRect(hwnd, &r, FALSE);
		}
	}

	lock=0;
  return 1;
}

int MouseProc1up(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

void MouseProc2down(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pts;
	int i;
	int deskX = currentScreen % ScreensX;
	int deskY = currentScreen / ScreensX;
	
	if (dockedOnWharf) {
		POINTS pt;
		pt = MAKEPOINTS(lParam);
		pts.x = pt.x;
		pts.y = pt.y;
	} else {
		GetCursorPos(&pts);
	}

	pts.x = pts.x-mainX;
	pts.y = pts.y-mainY;
	
	for (i=0;winRect[i].valid;i++);
	for (i--; i>=0;i--)
	{
		if ((pts.x-wndSizeX*deskX >= winRect[i].r.left/ratioX) &&
			(pts.x-wndSizeX*deskX <= winRect[i].r.right/ratioX) &&
			(pts.y-wndSizeY*deskY >= winRect[i].r.top/ratioY) &&
			(pts.y-wndSizeY*deskY <= winRect[i].r.bottom/ratioY))
		{
			GetWindowRect(winRect[i].hwnd, &oldWinPos);
			movingWin = i;
			pts.x = pts.x+mainX;
			pts.y = pts.y+mainY;
			lastPoint = pts;
			SetCapture(hMainWnd);
			break;
		}
	}
	if ((!noMove) && (movingWin == -1)) {
		movingMain = 1;
		if (dockedOnWharf) {
			POINTS pt;
			pt = MAKEPOINTS(lParam);
			pts.x = pt.x;
			pts.y = pt.y;
		} else {
			GetCursorPos(&pts);
		}
		diff.x = pts.x - mainX;
		diff.y = pts.y - mainY;
		SetCapture(hMainWnd);
	}
}

void MouseProc2up(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	RECT r;
	int s, deskx, desky;
	
	if (dockedOnWharf) {
		POINTS pts;
		pts = MAKEPOINTS(lParam);
		pt.x = pts.x;
		pt.y = pts.y;
	} else {
		GetCursorPos(&pt);
	}

	if (!movingMain) {
		pt.x = pt.x-mainX;
		pt.y = pt.y-mainY;
	}
	
	deskx = pt.x / wndSizeX;
	desky = pt.y / wndSizeY;
	s = (desky * ScreensX) + deskx;
	ReleaseCapture();
	
	if (movingMain == 1) {
		if (pt.x-diff.x < snapWidth) mainX = 0;
		else mainX = pt.x-diff.x;
		
		if (pt.y-diff.y < snapWidth) mainY = 0;
		else mainY = pt.y-diff.y;
		
		if (mainX+mainWidth+snapWidth > ScreenWidth) mainX = ScreenWidth-mainWidth;
		if (mainY+mainHeight+snapWidth > ScreenHeight) mainY = ScreenHeight-mainHeight;
		
		MoveWindow(hwnd, mainX, mainY, mainWidth, mainHeight, TRUE);
		movingMain = 0;
	} else {
		if (pt.x < 0 || pt.y < 0 || pt.x > mainWidth || pt.y > mainHeight)
			MoveWindow(winRect[movingWin].hwnd, oldWinPos.left, oldWinPos.top, oldWinPos.right-oldWinPos.left, oldWinPos.bottom-oldWinPos.top, TRUE);
		else if (GetWindowLong(winRect[movingWin].hwnd, GWL_STYLE) & WS_MAXIMIZE)
		{
			RECT newRect;
			int oldDesk = getDesktopByRect(oldWinPos);
			int newDesk = s;
			newRect.top = oldWinPos.top + deskRect[newDesk].top - deskRect[oldDesk].top;
			newRect.left = oldWinPos.left + deskRect[newDesk].left - deskRect[oldDesk].left;
			newRect.bottom = oldWinPos.bottom + deskRect[newDesk].top - deskRect[oldDesk].top;
			newRect.right = oldWinPos.right + deskRect[newDesk].left - deskRect[oldDesk].left;
			MoveWindow(winRect[movingWin].hwnd, newRect.left, newRect.top, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);
			GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
		}
		GetClientRect(hwnd,&r);
		createRecordedView();
		InvalidateRect(hwnd, &r, FALSE);
		movingWin=-1;
	}
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_CREATE:		
		return 0;
	case WM_ERASEBKGND:
		return 0;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT r;
			HDC hdc = BeginPaint(hwnd,&ps);
			
			if (First) 
			{
				MakeBuffer(parent);
				CreateImageMasks(parent);
				First = 0;
			}
			
			GetClientRect(hwnd,&r);
			if (!backInit)
			{
				createView();
				backInit = TRUE;
			}
			BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		PostMessage(parent,message,wParam,lParam);
		return 0;
	case WM_RBUTTONDOWN:
		if (mouseRight == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseRight == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_RBUTTONUP:
		if (mouseRight == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseRight == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;
	case WM_LBUTTONDOWN:
		if (mouseLeft == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseLeft == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_LBUTTONUP:
		if (mouseLeft == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseLeft == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;
	case WM_MBUTTONDOWN:
		if (mouseMiddle == 1) MouseProc1down(hwnd, message, wParam, lParam);
		if (mouseMiddle == 2) MouseProc2down(hwnd, message, wParam, lParam);
		return 0;
	case WM_MBUTTONUP:
		if (mouseMiddle == 1) MouseProc1up(hwnd, message, wParam, lParam);
		if (mouseMiddle == 2) MouseProc2up(hwnd, message, wParam, lParam);
		return 0;
	case WM_MOUSEMOVE:
		{ 
			POINT pts;
			POINT thisPt;
			RECT r;
			
			if (dockedOnWharf) {
				POINTS pt;
				pt = MAKEPOINTS(lParam);
				pts.x = pt.x;
				pts.y = pt.y;
			} else {
				GetCursorPos(&pts);
			}

			if (movingMain == 1) {
				if (moveCursor == FALSE) SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_SIZEALL)));
				
				if (pts.x-diff.x < snapWidth) mainX = 0;
				else mainX = pts.x-diff.x;
				
				if (pts.y-diff.y < snapWidth) mainY = 0;
				else mainY = pts.y-diff.y;
				
				if (mainX+mainWidth+snapWidth > ScreenWidth) mainX = ScreenWidth-mainWidth;
				if (mainY+mainHeight+snapWidth > ScreenHeight) mainY = ScreenHeight-mainHeight;
				
				MoveWindow(hwnd, mainX, mainY, mainWidth, mainHeight, TRUE);
				moveCursor = TRUE;
			} else if (movingWin != -1) {
				if (moveCursor == TRUE) {
					SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
					moveCursor = FALSE;
				}
				thisPt = pts;
				
				pts.x -= lastPoint.x;
				pts.y -= lastPoint.y;
				
				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				MoveWindow(winRect[movingWin].hwnd, winRect[movingWin].r.left + pts.x*ratioX, winRect[movingWin].r.top + pts.y * ratioY, winRect[movingWin].r.right + pts.x * ratioX - (winRect[movingWin].r.left + pts.x*ratioX), winRect[movingWin].r.bottom + pts.y * ratioY-(winRect[movingWin].r.top + pts.y*ratioY), TRUE);
				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				lastPoint = thisPt;
				
				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
			} else if (moveCursor == TRUE) {
				SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
				moveCursor = FALSE;
				return 0;
			}
		}
		return 0;
		
	case 9355:
		{
			RECT r;
			int i = wParam;
			
			if ((currentScreen != i) && !lock)
			{
				switchToDesktop(i, FALSE);
				GetClientRect(hMainWnd, &r);
				createView();
				InvalidateRect(hMainWnd, &r, TRUE);
			}
			return TRUE;
		}
		
	case 8891: // Change window focus via message (change desktop if needed)
		if (lock)
		{ // Try later
			PostMessage(hwnd, message, wParam, lParam);
			return TRUE;
		}
		lock = 1;
		{
			int n = getDesktop((HWND)lParam);
			if (n != currentScreen) switchToDesktop(n, TRUE);
			SwitchToThisWindow((HWND)lParam, 1);
		}
		lock=0;
		return TRUE;
		
	case WM_WINDOWPOSCHANGING:
		if (!onTop) {
			WINDOWPOS *lpwp = (WINDOWPOS*)lParam;
			lpwp->flags |= SWP_NOZORDER;
		}
		return 0;
		
	case WM_DROPFILES:
		{
			if (lock) 
			{
				PostMessage(hwnd, message, wParam, lParam);
				return 0;
			}
			lock = 1;
			{
				int numDropped, i;
				int deskx = 0;
				int desky = 0;
				int s=0;
				char szFname[256];
				//SHELLEXECUTEINFO si;
				RECT r;
				POINT pt;
				
				GetCursorPos(&pt);
				deskx = (pt.x-mainX) / wndSizeX;
				desky = (pt.y-mainY) / wndSizeY;
				s = (desky * ScreensX) + deskx;
				
				switchToDesktop(s, FALSE);
				
				numDropped = DragQueryFile((HDROP) wParam, 0xFFFFFFFF, NULL, 0);
				for (i = 0; i < numDropped; i++)
				{
					DragQueryFile((HDROP) wParam, i, (char *)&szFname, sizeof(szFname));
					if (szFname && szFname[0])
					{
            LSExecuteEx(NULL, NULL, szFname, NULL, NULL, SW_SHOWNORMAL);
            /*
						memset(&si, 0, sizeof(si));
						si.cbSize = sizeof(SHELLEXECUTEINFO);
						si.lpDirectory = NULL;
						si.lpVerb = NULL;
						si.nShow = 1;
						si.fMask = SEE_MASK_DOENVSUBST;
						si.lpFile = szFname;
						si.lpParameters = NULL;
						ShellExecuteEx(&si);
            */
					}
				}
				DragFinish((HDROP) wParam);
				
				GetClientRect(hwnd,&r);
				createView();
				InvalidateRect(hwnd, &r, FALSE);
				
				lock=0;
			}
		}
		return 0;
		
	case WM_TIMER:
		{ 
			if (lock)
				return 0;
			if (wParam == autoTimer)
			{
				POINT pts;
				GetCursorPos(&pts);
				if (VWMautohide) {
					if ((mainX == 0) || (mainY == 0) || (mainX+mainWidth == ScreenWidth) || (mainY+mainHeight == ScreenHeight))
					{
            if (movingWin == -1)
            {
              if (FALSE != autoHideFix)
              {
                RECT rcWin;
                GetWindowRect(hMainWnd, &rcWin);

                if (FALSE != autoHidden && FALSE != rolled)
                {
                  if (0 == mainX)
                    rcWin.right = rcWin.left + autoHideDistance;
                  else if (0 == mainY)
                    rcWin.bottom = rcWin.top + autoHideDistance;
                  else if (mainX+mainWidth == ScreenWidth)
                    rcWin.left = rcWin.right - autoHideDistance;
                  else if (mainY+mainHeight == ScreenHeight)
                    rcWin.top = rcWin.bottom - autoHideDistance;
                }

                if (FALSE == PtInRect(&rcWin, pts))
                {
                  if (autoHidden != TRUE)
                  {
                    autoHidden = TRUE;
                    rolled = TRUE;
                    ShowWindow(hMainWnd,SW_HIDE);
                  }
                }
                else
                {
                  if (autoHidden != FALSE)
                  {
                    autoHidden = FALSE;
                    rolled = FALSE;
                    ShowWindow(hMainWnd,SW_SHOWNORMAL);
                  }
                }
              }
              else
              {
							  if ((mainX == 0) && (pts.x <= autoHideDistance) && ((mainY != 0 && mainY + mainHeight != ScreenHeight) || mainWidth < mainHeight)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainY == 0) && (pts.y <= autoHideDistance) && ((mainX != 0 && mainX + mainWidth != ScreenWidth) || mainHeight < mainWidth)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainX+mainWidth == ScreenWidth) && (pts.x >= ScreenWidth-autoHideDistance) && ((mainY != 0 && mainY + mainHeight != ScreenHeight) || mainWidth < mainHeight)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((mainY+mainHeight == ScreenHeight) && (pts.y >= ScreenHeight-autoHideDistance) && ((mainX != 0 && mainX + mainWidth != ScreenWidth) || mainHeight < mainWidth)) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if (((mainX==0 && mainY==0 && (pts.x <= autoHideDistance || pts.y <= autoHideDistance))
										|| (mainX==0 && mainY+mainHeight==ScreenHeight && (pts.x <= autoHideDistance || pts.y >= ScreenHeight-autoHideDistance))
										|| (mainY==0 && mainX+mainWidth==ScreenWidth && (pts.y <= autoHideDistance || pts.x >= ScreenWidth-autoHideDistance))
										|| (mainY+mainHeight==ScreenHeight && mainX+mainWidth==ScreenWidth && (pts.x >= ScreenWidth-autoHideDistance || pts.y >= ScreenHeight-autoHideDistance)))
										&& mainHeight==mainWidth) {
								  if (autoHidden != FALSE) {
									  autoHidden = FALSE;
									  rolled = FALSE;
									  ShowWindow(hMainWnd,SW_SHOWNORMAL);
								  }
							  }
							  else if ((pts.x < mainX) || (pts.x > mainX+mainWidth) || (pts.y < mainY) || (pts.y > mainY+mainHeight)) {
								  if (autoHidden != TRUE) {
									  autoHidden = TRUE;
									  rolled = TRUE;
									  ShowWindow(hMainWnd,SW_HIDE);
								  }
							  }
              }
						}
					}
				}
				return 0;
			}
            if (wParam == mTimer)
            {
				POINTS pts;
				DWORD a = GetMessagePos();
				int nmpos = 0;
				pts = MAKEPOINTS(a);
				
				if ((pts.x) <= autoSwitchDistance) nmpos |= 1;
				if ((pts.y) <= autoSwitchDistance) nmpos |= 2;
				if ((pts.x) >= ScreenWidth-autoSwitchDistance) nmpos |= 4;
				if ((pts.y) >= ScreenHeight-autoSwitchDistance) nmpos |= 8;
				
                if (!nmpos) return 0;
                else
                {
					if (nmpos == 1)
					{
						RECT r;
						if (((currentScreen % ScreensX) > 0 ) && !lock)
						{
							switchToDesktop(currentScreen-1, TRUE);
							SetCursorPos(ScreenWidth-(autoSwitchDistance+1), pts.y);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						}
					}
					if (nmpos == 2)
					{
						RECT r;
						if ((currentScreen > (ScreensX - 1)) && !lock)
						{
							switchToDesktop(currentScreen - ScreensX, TRUE);
							SetCursorPos(pts.x, ScreenHeight-(autoSwitchDistance+1));
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						}
					}
					if (nmpos == 4)
					{
						RECT r;
						if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
						{
							switchToDesktop(currentScreen+1, TRUE);
							SetCursorPos(autoSwitchDistance+1, pts.y);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						}
					}
					if (nmpos == 8)
					{
						RECT r;
						if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
						{
							switchToDesktop(currentScreen+ ScreensX, TRUE);
							SetCursorPos(pts.x, autoSwitchDistance+1);
							GetClientRect(hMainWnd, &r);
							createView();
							InvalidateRect(hMainWnd, &r, FALSE);
						}
					}
                }
                KillTimer(hMainWnd, mTimer);
                return 0;
            }
            else
                if (wParam == mcTimer)
                {
                    POINTS pts;
                    DWORD a = GetMessagePos();
                    int nmpos = 0;
                    pts = MAKEPOINTS(a);
					
                    if ((pts.x) <= autoSwitchDistance) nmpos |= 1;
                    if ((pts.y) <= autoSwitchDistance) nmpos |= 2;
                    if ((pts.x) >= ScreenWidth-autoSwitchDistance) nmpos |= 4;
                    if ((pts.y) >= ScreenHeight-autoSwitchDistance) nmpos |= 8;
					
                    if (!nmpos)
                    {
                        if (mpos)
                        {
                            KillTimer(hMainWnd, mTimer);
                            mpos = 0;
                        }
                    }
                    else
                    {
                        if (!mpos)
                        {
                            mpos = nmpos;
                            SetTimer(hMainWnd, mTimer, mTimeout, NULL);
                        }
                    }
                    return 0;
                }
				
				lock = 1;
				
				if (!wParam)
				{
					RECT r;
					GetClientRect(hwnd,&r);
					createView();
					InvalidateRect(hwnd, &r, FALSE);
				}
				else
				{
					int style=0;
					int a=0;
					RECT r;
					HWND newFGWin = GetForegroundWindow();
					
					if (newFGWin)
					{
						style = GetWindowLong(newFGWin, GWL_STYLE);
						a = GetWindowLong(newFGWin, GWL_USERDATA);
					}
					
					if (newFGWin != lastActive)
					{
						if (newFGWin)
						{
							GetWindowRect(newFGWin, &r);
							if (!outsideAnyScreen(r) && 
								!(a == magicDWord || !newFGWin || (newFGWin && IsIconic(newFGWin)) || 
								!((style & WS_VISIBLE)) || (style & WS_DISABLED) || 
								(lastActive && IsWindow(lastActive) && IsIconic(lastActive)) ||
								(lastActive && !IsWindow(lastActive))
								|| (lastActive && GetWindowLong(lastActive, GWL_USERDATA) == magicDWord))
								)
							{
								int newScr = getDesktop(newFGWin);
								if ((newScr != currentScreen) && !NeverSwitch) switchToDesktop(newScr, FALSE);
							}
						}
						lastActive = newFGWin;
					}
				}
			}
			lock = 0;
			return 0;
			
	}
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void MakeBuffer(HWND hWnd)
// commented out parts are for drawing a duplicate of the entire desktop into the 
// background of the vwm, but since it is not possible to get the bitmaps for the
// non-current desktops (since they don't actually exist) then there is no way to
// have an updated image of each virtual desktop
{
	RECT r;
	POINT p;
	HDC hdc = GetDC(GetDesktopWindow());
	
	GetClientRect(hWnd,&r);
	p.x = r.left-mainX;
	p.y = r.top-mainY;
	
	if (!bBGBitmap)
	{
		HBRUSH oldBrush, hBlueBrush = CreateSolidBrush(backColor);
		HPEN oldpen, pen = CreatePen(PS_SOLID, 1, borderColor);
		
		bBGBitmap = CreateCompatibleBitmap(hdc, mainWidth, mainHeight);
		//bBGBitmap = CreateCompatibleBitmap(hdc, ScreenWidth*3, ScreenHeight);
		GetBMPSize(bBGBitmap, &backX, &backY);
		bgDC = CreateCompatibleDC(NULL);
		oldBG = (HBITMAP)SelectObject(bgDC, bBGBitmap);
		background = TRUE;
		
		oldBrush = SelectObject(bgDC, hBlueBrush);
		oldpen = SelectObject(bgDC, pen);
		Rectangle(bgDC, 0, 0, mainWidth, mainHeight);
		
		SelectObject(bgDC, oldpen);
		SelectObject(bgDC, oldBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(pen);
		
		if (snapshot) {
			//int x, y;
			SelectObject(bgDC, bBGBitmap);
			
			/*for (y = 0; y < ScreensY; y ++) for (x = 0; x < ScreensX; x ++)
			{
				int desk = (y * ScreensX) + x;
				int top = y * (ScreenHeight + 10);
				int left = x * (ScreenWidth + 10);
		
				StretchBlt(bgDC, deskRect[desk].left / ratioX, deskRect[desk].top / ratioY, deskRect[desk].right / ratioX, deskRect[desk].bottom / ratioY, hdc, 0, 0, ScreenWidth*3, ScreenHeight, SRCCOPY);*/
				BitBlt(bgDC, r.left, r.top, r.right, r.bottom, hdc, mainX, mainY, SRCCOPY);
			//}
		}
	} else {
		bgDC = CreateCompatibleDC(NULL);
		oldBG = (HBITMAP)SelectObject(bgDC, bBGBitmap);
		SelectObject(bgDC, bBGBitmap);
	}
	
	ReleaseDC(hWnd, hdc);
}

void getShifts(int old, int desk, int *addH, int *addV)
{
	int oldDeskX = old % ScreensX;
	int oldDeskY = old / ScreensX;
	
	int deskX = desk % ScreensX;
	int deskY = desk / ScreensX;
	
	int shiftX = deskX - oldDeskX;
	int shiftY = deskY - oldDeskY;
	
	*addH = shiftX * (ScreenWidth + 10);
	*addV = shiftY * (ScreenHeight + 10);
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (!refToplevel && !(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
		refToplevel = hwnd;
		return FALSE;
	}
	return TRUE;
}

BOOL CALLBACK EudoraEnumChildProc(HWND hwnd, LPARAM lParam)
{
	HWND owner = GetWindow(hwnd, GW_OWNER);
	
	if (owner != eudora) return TRUE;
	{
		int style = GetWindowLong(hwnd, GWL_STYLE);
		
		if (style & WS_VISIBLE && style & WS_POPUP)
		{
			char txt[25];
			GetWindowText(hwnd, txt, 23);
			if (!strcmp(txt, "Progress") || !strcmp(txt, "No New Mail") || !strcmp(txt, "New Mail!") || !strcmp(txt, "Eudora Network Timeout"))
			{
				RECT r;
				RECT r2;
				RECT r3;
				GetWindowRect(eudora, &r);
				GetWindowRect(hwnd, &r2);
				r3.left = ((r.right-r.left-(r2.right-r2.left)) / 2) + r.left;
				r3.top = ((r.bottom-r.top-(r2.bottom-r2.top)) / 2) + r.top;
				r3.right = r3.left + (r2.right-r2.left);
				r3.bottom = r3.top + (r2.bottom-r2.top);
				MoveWindow(hwnd, r3.left, r3.top, r3.right-r3.left, r3.bottom-r3.top, TRUE);
			}
		}
	}
	
	return TRUE;
}

void createView(void)
{
	int xoff, yoff;
	HWND prev, p;
	RECT r;
	int H=0, V=0;
	static int oldnRects=0;
	int nRects=0;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		hWinBrush,
		oldBrush,
		hTitlebar;
	HPEN pen,oldpen;
	HPEN hiPen, shadPen, winPen;
	
	if (movingWin > -1) return;
	
	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	hWinBrush = CreateSolidBrush(winColor);
	hTitlebar = CreateSolidBrush(borderColor);
	
	StretchBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, backX, backY, SRCCOPY);
	
	hiPen = CreatePen(PS_SOLID, 1, foreColor);
	shadPen = CreatePen(PS_SOLID, 1, borderColor);
	winPen = CreatePen(PS_SOLID, 1, winColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);
	
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
		
		if (background) {
			for (xoff=1; xoff < ScreensX; xoff++)
			{
				MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
				LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
			}
			for (yoff=1; yoff < ScreensY; yoff++)
			{
				MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
				LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
			}
		}
		
		r.left = nOffsetX+wndSizeX*(currentScreen % ScreensX);
		r.top = nOffsetY+wndSizeY*(currentScreen / ScreensX);
		
		if (!sBGBitmap) {
			SelectObject(memDC, hGreyBrush);
			ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
		} else {
			SelectObject(bgDC, sBGBitmap);
			StretchBlt(memDC, r.left, r.top, wndSizeX, wndSizeY, bgDC, 0, 0, selX, selY, SRCCOPY);
		}
		
		getShifts(0, currentScreen, &H, &V);
		
		refToplevel = NULL;
		nWinRect=0;
		EnumWindows(EnumWindowsProc, 0);
		
		prev = GetWindow(refToplevel, GW_HWNDLAST);
		goto inside;
		while (1)
		{ 
			BOOL skipWin = FALSE;
			int WindowHeight;
			int WindowWidth;
			prev = GetWindow(prev, GW_HWNDPREV);
inside:
			if (prev == NULL) break;
			if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
				continue;
			p = GetParent(prev);
			if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
				continue;
			GetWindowRect(prev, &winRect[nWinRect].r);
			nRects+=(int)prev;
			
			WindowHeight = ((winRect[nWinRect].r.bottom + V) / ratioY)-((winRect[nWinRect].r.top + V) / ratioY);
			WindowWidth = ((winRect[nWinRect].r.right + H) / ratioX)-((winRect[nWinRect].r.left + H) / ratioX);
			
			{
				char txt[25];
				GetWindowText(winRect[nWinRect].hwnd, txt, 23);
				if (!strcmp(txt, "Explorer")) skipWin = TRUE;
			}
			
			if (!skipWin) {
				//set drawing rectangle
				r.left = (winRect[nWinRect].r.left + H) / ratioX;
				r.top = (winRect[nWinRect].r.top + V) / ratioY;
				r.right = (winRect[nWinRect].r.right + H) / ratioX;
				r.bottom = (winRect[nWinRect].r.bottom + V) / ratioY;
				
				if ((!titlebars) || (WindowHeight <= TitlebarHeight))
				{
					if (wBGBitmap) {
						SelectObject(bgDC, wBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, r.bottom-r.top, bgDC, 0, 0, winX, winY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.bottom, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top);
							LineTo(memDC, r.right, r.top);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.bottom);
							LineTo(memDC, r.left-1, r.bottom);
							
							//move to top right corner of inner
							MoveToEx(memDC, r.right-1, r.top+1, NULL);
							
							//draw inner shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.right-1, r.bottom-1);
							LineTo(memDC, r.left+1, r.bottom-1);
							
							//draw inner highlight
							SelectObject(memDC, hiPen);
							LineTo(memDC, r.left+1, r.top+1);
							LineTo(memDC, r.right-1, r.top+1);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+2, r.top+2, r.right-1, r.bottom-1);
						} else {
							SelectObject(memDC, hWhiteBrush);
							Rectangle(memDC, r.left, r.top, r.right, r.bottom);
						}
					}
				} else {
					if (tBGBitmap) {
						SelectObject(bgDC, tBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, TitlebarHeight, bgDC, 0, 0, titleX, titleY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.top+TitlebarHeight, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top);
							LineTo(memDC, r.right, r.top);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.top+TitlebarHeight);
							
							//skip outer bottom highlight and move to top right of inner to continue drawing
							MoveToEx(memDC, r.right-1, r.top+1, NULL);
							
							//draw inner shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.right-1, r.top+TitlebarHeight-1);
							LineTo(memDC, r.left+1, r.top+TitlebarHeight-1);
							
							//draw inner highlight
							SelectObject(memDC, hiPen);
							LineTo(memDC, r.left+1, r.top+1);
							LineTo(memDC, r.right-1, r.top+1);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+2, r.top+2, r.right-1, (r.top+TitlebarHeight)-1);
						} else {
							SelectObject(memDC, hTitlebar);
							Rectangle(memDC, r.left, r.top, r.right, r.top+TitlebarHeight);
						}
					}
					if (wBGBitmap) {
						SelectObject(bgDC, wBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, (r.bottom-r.top)+TitlebarHeight, bgDC, 0, 0, winX, winY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.bottom, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top+TitlebarHeight);
							
							//skip top shadow and move to top right to continue drawing
							MoveToEx(memDC, r.right, r.top+TitlebarHeight, NULL);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.bottom);
							LineTo(memDC, r.left-1, r.bottom);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+1, r.top+TitlebarHeight, r.right, r.bottom);
						} else {
							SelectObject(memDC, hWhiteBrush);
							Rectangle(memDC, r.left, r.top+TitlebarHeight, r.right, r.bottom);
						}
					}
				}
				if (useIcons) {
					if (!titlebars)
					{
						if ((WindowWidth-4 > iconSize) || (WindowHeight-4 > iconSize))
						{
							if (iconSize <= 16) winRect[nWinRect].hicon = getIconFromWindow(winRect[nWinRect].hwnd, FALSE);
							if (iconSize > 16) winRect[nWinRect].hicon = getIconFromWindow(winRect[nWinRect].hwnd, TRUE);
							DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), r.top+((WindowHeight/2)-(iconSize/2)), winRect[nWinRect].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						}
					} else {
						if ((WindowWidth-4 > iconSize) || ((WindowHeight-TitlebarHeight)-4 > iconSize))
						{
							if (iconSize <= 16) winRect[nWinRect].hicon = getIconFromWindow(winRect[nWinRect].hwnd, FALSE);
							if (iconSize > 16) winRect[nWinRect].hicon = getIconFromWindow(winRect[nWinRect].hwnd, TRUE);
							DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), (r.top+TitlebarHeight)+((WindowHeight/2)-(iconSize/2)), winRect[nWinRect].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						}
					}
				}
			}
			winRect[nWinRect].hwnd=prev;
			winRect[nWinRect++].valid=1;
		}
		if (nRects != oldnRects) {
			if (! (GetWindowLong(winswitch, GWL_STYLE) & WS_VISIBLE) ) {
				HWND last = GetWindow(desk, GW_HWNDLAST);
				while (last && last != desk) {
					if (GetWindowLong(last, GWL_STYLE) & WS_VISIBLE) {
						SetWindowPos(last, GetWindow(desk, GW_HWNDPREV), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
						last = GetWindow(desk, GW_HWNDLAST);
						continue;
					}
					last = GetWindow(last, GW_HWNDPREV);
				}
			}
			oldnRects = nRects;
			eudora = FindWindow("EudoraMainWindow", NULL);
			if (eudora)
				EnumWindows(EudoraEnumChildProc, 0);
		}
		
		memset(&winRect[nWinRect], 0, sizeof(winDataType));
		SelectObject(memDC, oldpen);
		SelectObject(memDC, oldBrush);
		DeleteObject(hWhiteBrush);
		DeleteObject(hGreyBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(hWinBrush);
		DeleteObject(hTitlebar);
		DeleteObject(pen);
		DeleteObject(hiPen);
		DeleteObject(shadPen);
		DeleteObject(winPen);
}

BOOL CALLBACK FixEnumChildProc(HWND hwnd, LPARAM lParam)
{
	HWND owner = GetWindow(hwnd, GW_OWNER);
	
	if (owner != photoshop) return TRUE;
	
	{
		int style = GetWindowLong(hwnd, GWL_STYLE);
		
		if (style & WS_VISIBLE && style & WS_POPUP)
		{
			if (!inFix(hwnd))
			{
				ShowWindow(hwnd, SW_HIDE);
				addWinFix(hwnd, currentScreen);
			}
		}
	}
	
	return TRUE;
}

void switchToDesktop(int _desk, BOOL fixFocus)
{
	RECT r;
	HWND prev, p;
	HDWP dwp;

	int addH=0, addV=0;
	
	lock = 1;
	if (movingWin > -1) return;
	
	getShifts(currentScreen, _desk, &addH, &addV);
	
	photoshop = FindWindow("Photoshop", NULL);
	if (photoshop) EnumWindows(FixEnumChildProc, 0);
	
	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	
	DoEvents(2);
	
	dwp = BeginDeferWindowPos(nWinRect+16);
	
	goto inside;
	while (1)
	{
		char winText[256];
		prev = GetWindow(prev, GW_HWNDPREV);
inside:
		if (prev == NULL) break;
		
		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))	continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord) continue;
		
		GetWindowText(prev, winText, 255);
		if (Sticky(prev) == TRUE) continue;
		
		GetWindowRect(prev, &r);
		r.left-=addH;
		r.right-=addH;
		r.top -=addV;
		r.bottom-=addV;
		dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
	}
	
	currentScreen = _desk;
	EndDeferWindowPos(dwp);
	
	postfixWinFix(currentScreen);
	SetDeskWallpaper();

	if ((FocusCenter) && (fixFocus))
	{
		POINT p;
		p.x = ScreenWidth/2;
		p.y = ScreenHeight/2;
		SetForegroundWindow(WindowFromPoint(p));
	}
	
	lock = 0;
}

void gatherAll()
{
	RECT r;
	HWND prev, p;
	
	if (NoGather) 
    {
		int sze = sizeof(int) | VWM_DESKNO;
		SendMessage(tapp, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &currentScreen);
		return;
    }
	
	
	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
inside:
		if (prev == NULL) break;
		
		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);
		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			r.right %= (ScreenWidth+10);
		}
		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			r.bottom %= (ScreenHeight+10);
		}
		if (r.left < -10)
		{
			r.right %= (ScreenWidth+10);
			r.right += ScreenWidth;
			r.left %= (ScreenWidth+10);
			r.left += ScreenWidth;
		}
		if (r.top < -10)
		{
			r.bottom %= (ScreenHeight+10);
			r.bottom += ScreenHeight;
			r.top %= (ScreenHeight+10);
			r.top += ScreenHeight;
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
	
	currentScreen = 0;
	SetDeskWallpaper();
}

void createRecordedView(void)
{
	RECT r;
	int H=0, V=0;
	int i, xoff, yoff;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		hWinBrush,
		hTitlebar,
		oldBrush;
	HPEN pen,oldpen;
	HPEN hiPen, shadPen, winPen;
	BOOL skipWin = FALSE;
	
	StretchBlt(memDC, 0, 0, mainWidth, mainHeight, bgDC, 0, 0, backX, backY, SRCCOPY);
	
	hBlueBrush = CreateSolidBrush(backColor);
	hWinBrush = CreateSolidBrush(winColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	hTitlebar = CreateSolidBrush(borderColor);
	
	hiPen = CreatePen(PS_SOLID, 1, foreColor);
	shadPen = CreatePen(PS_SOLID, 1, borderColor);
	winPen = CreatePen(PS_SOLID, 1, winColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);
	
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
		
		if (background) {
			for (xoff=1; xoff < ScreensX; xoff++)
			{
				MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
				LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
			}
			for (yoff=1; yoff < ScreensY; yoff++)
			{
				MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
				LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
			}
		}
		
		r.left = nOffsetX+ wndSizeX*(currentScreen % ScreensX);
		r.top = nOffsetY+ wndSizeY*(currentScreen / ScreensX);
		
		if (!sBGBitmap) {
			SelectObject(memDC, hGreyBrush);
			ImageList_DrawEx(hBGList, currentScreen, memDC, r.left, r.top, wndSizeX, wndSizeY, 0, selBackColor, ILD_BLEND50);
		} else {
			SelectObject(bgDC, sBGBitmap);
			StretchBlt(memDC, r.left, r.top, wndSizeX, wndSizeY, bgDC, 0, 0, selX, selY, SRCCOPY);
		}
		
		SelectObject(memDC, hWhiteBrush);
		
		getShifts(0, currentScreen, &H, &V);
		
		for (i=0;winRect[i].valid;i++)
		{
			int WindowHeight;
			int WindowWidth;
			
			GetWindowRect(winRect[i].hwnd, &winRect[i].r);
			
			WindowHeight = ((winRect[i].r.bottom + V) / ratioY)-((winRect[i].r.top + V) / ratioY);
			WindowWidth = ((winRect[i].r.right + H) / ratioX)-((winRect[i].r.left + H) / ratioX);
			
			{
				char txt[25];
				GetWindowText(winRect[nWinRect].hwnd, txt, 23);
				if (!strcmp(txt, "Explorer"))
				{
					skipWin = TRUE;
				}
			}
			
			if (!skipWin) {
				//set drawing rectangle
				r.left = (winRect[i].r.left + H) / ratioX;
				r.top = (winRect[i].r.top + V) / ratioY;
				r.right = (winRect[i].r.right + H) / ratioX;
				r.bottom = (winRect[i].r.bottom + V) / ratioY;
				
				if ((!titlebars) || (WindowHeight <= TitlebarHeight))
				{
					if (wBGBitmap) {
						SelectObject(bgDC, wBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, r.bottom-r.top, bgDC, 0, 0, winX, winY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.bottom, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top);
							LineTo(memDC, r.right, r.top);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.bottom);
							LineTo(memDC, r.left-1, r.bottom);
							
							//move to top right corner of inner
							MoveToEx(memDC, r.right-1, r.top+1, NULL);
							
							//draw inner shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.right-1, r.bottom-1);
							LineTo(memDC, r.left+1, r.bottom-1);
							
							//draw inner highlight
							SelectObject(memDC, hiPen);
							LineTo(memDC, r.left+1, r.top+1);
							LineTo(memDC, r.right-1, r.top+1);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+2, r.top+2, r.right-1, r.bottom-1);
						} else {
							SelectObject(memDC, hWhiteBrush);
							Rectangle(memDC, r.left, r.top, r.right, r.bottom);
						}
					}
				} else {
					if (tBGBitmap) {
						SelectObject(bgDC, tBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, TitlebarHeight, bgDC, 0, 0, titleX, titleY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.top+TitlebarHeight, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top);
							LineTo(memDC, r.right, r.top);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.top+TitlebarHeight);
							
							//skip outer bottom highlight and move to top right of inner to continue drawing
							MoveToEx(memDC, r.right-1, r.top+1, NULL);
							
							//draw inner shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.right-1, r.top+TitlebarHeight-1);
							LineTo(memDC, r.left+1, r.top+TitlebarHeight-1);
							
							//draw inner highlight
							SelectObject(memDC, hiPen);
							LineTo(memDC, r.left+1, r.top+1);
							LineTo(memDC, r.right-1, r.top+1);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+2, r.top+2, r.right-1, (r.top+TitlebarHeight)-1);
						} else {
							SelectObject(memDC, hTitlebar);
							Rectangle(memDC, r.left, r.top, r.right, r.top+TitlebarHeight);
						}
					}
					if (wBGBitmap) {
						SelectObject(bgDC, wBGBitmap);
						StretchBlt(memDC, r.left, r.top, r.right-r.left, (r.bottom-r.top)+TitlebarHeight, bgDC, 0, 0, winX, winY, SRCCOPY);
					} else {
						if (bevel) {
							//move to bottom left corner of outer
							MoveToEx(memDC, r.left, r.bottom, NULL);
							
							//draw outer shadow
							SelectObject(memDC, shadPen);
							LineTo(memDC, r.left, r.top+TitlebarHeight);
							
							//skip top shadow and move to top right to continue drawing
							MoveToEx(memDC, r.right, r.top+TitlebarHeight, NULL);
							
							//draw outer highlight
							SelectObject(memDC, hiPen);						
							LineTo(memDC, r.right, r.bottom);
							LineTo(memDC, r.left-1, r.bottom);
							
							//draw inside rectangle
							SelectObject(memDC, hWinBrush);
							SelectObject(memDC, winPen);
							Rectangle(memDC, r.left+1, r.top+TitlebarHeight, r.right, r.bottom);
						} else {
							SelectObject(memDC, hWhiteBrush);
							Rectangle(memDC, r.left, r.top+TitlebarHeight, r.right, r.bottom);
						}
					}
				}
				if (useIcons) {
					if (!titlebars)
					{
						if ((WindowWidth-4 > iconSize) || (WindowHeight-4 > iconSize))
						{
							if (iconSize <= 16) winRect[i].hicon = getIconFromWindow(winRect[i].hwnd, FALSE);
							if (iconSize > 16) winRect[i].hicon = getIconFromWindow(winRect[i].hwnd, TRUE);
							DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), r.top+((WindowHeight/2)-(iconSize/2)), winRect[i].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						}
					} else {
						if ((WindowWidth-4 > iconSize) || ((WindowHeight-TitlebarHeight)-4 > iconSize))
						{
							if (iconSize <= 16) winRect[i].hicon = getIconFromWindow(winRect[i].hwnd, FALSE);
							if (iconSize > 16) winRect[i].hicon = getIconFromWindow(winRect[i].hwnd, TRUE);
							DrawIconEx(memDC, r.left+((WindowWidth/2)-(iconSize/2)), (r.top+TitlebarHeight)+((WindowHeight/2)-(iconSize/2)), winRect[i].hicon, iconSize, iconSize, 0, NULL, DI_NORMAL);
						}
					}
				}
			}
		}
		
		SelectObject(memDC, oldpen);
		SelectObject(memDC, oldBrush);
		DeleteObject(hWhiteBrush);
		DeleteObject(hGreyBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(hTitlebar);
		DeleteObject(hWinBrush);
		DeleteObject(pen);
		DeleteObject(hiPen);
		DeleteObject(shadPen);
		DeleteObject(winPen);
}

int getDesktop(HWND h)
{
	RECT r;
	GetWindowRect(h, &r);
	return (getDesktopByRect(r));
}

int getDesktopByRect(RECT r)
{
	
	int offsetx = currentScreen % ScreensX;
	int offsety = currentScreen / ScreensX;
	int desk = 0;
	
	r.left += offsetx * (ScreenWidth + 10);
	r.top += offsety * (ScreenHeight + 10);
	
	offsetx = ((r.left + 10) / (ScreenWidth + 10));
	offsety = ((r.top + 10) / (ScreenHeight + 10));
	
	desk = (offsety * ScreensX) + offsetx;
	
	if (desk < 0 || desk > MaxScreens) desk = 0;
	return desk;
}

int outsideAnyScreen(RECT r)
{
	return (r.left > ScreensX * (ScreenWidth +10) || r.top > ScreensY*(ScreenHeight +10));
}

void addWinFix(HWND hwnd, int s)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd;i++);
	
	if (i >= 500) return;
	winFix[i].hwnd = hwnd;
	winFix[i].screen = s;
}

void removeWinFix(HWND hwnd)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);
	
	if (i >= 500) return;
	winFix[i].hwnd = NULL;
	winFix[i].screen = 0;
}

void postfixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s)
        {
			ShowWindow(winFix[i].hwnd, SW_SHOWNA);
			winFix[i].hwnd = NULL;
			winFix[i].screen = 0;
        }
    }
}

void prefixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s) ShowWindow(winFix[i].hwnd, SW_HIDE);
	}
}

int inFix(HWND hwnd)
{
	int i;
	
	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);
	if (i>=500) return 0;
	return 1;    
}

void DoEvents(int n)
{
	int i;
	BOOL b=TRUE;
	MSG msg;
	
	for (i=0;i<n && b;i++)
    {
		b = GetMessage( &msg, NULL, 0, 0 );
		if (b) 
        {
			TranslateMessage( &msg );
			DispatchMessage( &msg ); 
        }
    }
}

void CreateImageMasks(HWND hwnd)
{
	HBITMAP bPane, bOld;
	HDC	hdc = GetDC(hwnd), TempDC;
	int xoff, yoff;
	
	hBGList = ImageList_Create(wndSizeX, wndSizeY, ILC_COLOR32, 0, ScreensX);
	
	TempDC = CreateCompatibleDC(hdc);
	bPane = CreateCompatibleBitmap(hdc, wndSizeX, wndSizeY);
	
	for (yoff = 0; yoff < ScreensY; yoff++)
		for (xoff = 0; xoff < ScreensX; xoff++)
		{
			bOld = (HBITMAP)SelectObject(TempDC, bPane);
			
			if (!BitBlt(TempDC, 0, 0, wndSizeX, wndSizeX, bgDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), SRCCOPY))
				MessageBox(hMainWnd, "BitBlt failed", "Error", MB_OK);
			SelectObject(TempDC, bOld);
			
			if (ImageList_Add(hBGList, bPane, NULL) == -1)
				MessageBox(hMainWnd, "Could not add image...", "Error", MB_OK);
		}
		
		ReleaseDC(hwnd, hdc);
		DeleteDC(TempDC);
		DeleteObject(bPane);
		DeleteObject(bOld);
}

void ReadConfig (void)
{
	char szTemp[256], szBuf[256];
	int nDesks;
	int i;

	NoGather = GetRCBool("VwmNoGathering", TRUE);
	NeverSwitch = GetRCBool("VWMNoSwitchOnFocus", TRUE);
	FocusCenter = GetRCBool("VWMFocusCenter", TRUE);
	noShow = GetRCBool("VWMNoShow", TRUE);
	snapWidth = GetRCInt("VWMSnapWidth", snapWidth);
	onTop = GetRCBool("VWMAlwaysOnTop", TRUE);
	noMove = GetRCBool("VWMNoMove", TRUE);
	VWMautohide = GetRCBool("VWMAutohide", TRUE);
	autoHideDistance = GetRCInt("VWMAutohideDistance", autoHideDistance);
  autoHideFix = GetRCBool("VWMAutohideFix", autoHideFix);
	titlebars = GetRCBool("VWMTitlebars", TRUE);
	titleHeightMod = GetRCInt("VWMTitlebarMod", titleHeightMod);
	bevel = GetRCBool("VWMBevel", TRUE);
	autoswitch = GetRCBool("VWMAutoSwitch", TRUE);
	autoSwitchDistance = GetRCInt("VWMAutoSwitchDistance", autoSwitchDistance);
	useIcons = GetRCBool("VWMShowIcons", TRUE);
	iconSize = GetRCInt("VWMIconSize", iconSize);
	useInitialDesk = GetRCBool("VWMUseInitialDesk", TRUE);
	initialDesk = GetRCInt("VWMInitialDesk", initialDesk);
	mouseLeft = GetRCInt("VWMMouseLeft", mouseLeft);
	mouseRight = GetRCInt("VWMMouseRight", mouseRight);
	mouseMiddle = GetRCInt("VWMMouseMiddle", mouseMiddle);
	
	backColor = GetRCColor("vwmBackColor", 0x808080);
	winColor = GetRCColor("vwmWinColor", 0x808080);
	selBackColor = GetRCColor("vwmSelBackColor", 0x404040);
	foreColor = GetRCColor("VWMForeColor", 0xFFFFFF);
	borderColor = GetRCColor("VWMBorderColor", 0x000000);
	
	borderSize = GetRCInt("WharfBevelWidth", 1);

	ScreensX = GetRCInt("VWMDesksX", ScreensX);
	ScreensY = GetRCInt("VWMDesksY", ScreensY);
	
	mTimeout = GetRCInt("VWMAutoSwitchDelay", mTimeout);
	
	// Modified - Maduin, 10-20-1999
	//   Changed to use new API LSGetImagePath rather than
	//   access the step.rc directly.

	LSGetImagePath( szImagePath, 256 );

	mainX = GetRCInt("VWMx", mainX);
	mainY = GetRCInt("VWMy", mainY);
	mainWidth = GetRCInt("VWMwidth", mainWidth);
	mainHeight = GetRCInt("VWMheight", mainHeight);
	if (mainX+mainWidth > ScreenWidth) mainX = ScreenWidth-mainWidth;
	if (mainY+mainHeight > ScreenHeight) mainY = ScreenHeight-mainHeight;
	
	{
		FILE *f;
		char buffer[256];
		int num = 0;

		f = LCOpen(NULL);
		if (f) {
			while (LCReadNextConfig (f, "*VWMSticky", buffer, sizeof (buffer)))
			{
				char *lpszBuffers[2];
				char token1[4096], token2[4096];

				lpszBuffers[0] = token1;
				lpszBuffers[1] = token2;

				LCTokenize (buffer, lpszBuffers, 2, NULL);

				num++;
				strcpy(StickyConfig[num].match, token2);
				if (!strnicmp(StickyConfig[num].match, "", sizeof(""))) num--;
			}
			LCClose(f);
		}
		stickyTotal = num;
	}
	
	GetRCString("VWMBackBmp", szTemp, ".none", 256);
	if (!strnicmp(szTemp, ".snapshot", sizeof(".snapshot"))) {
		snapshot = TRUE;
	} else {
		sprintf(szBuf, "%s%s", szImagePath, szTemp);
		bBGBitmap = LoadImage(inst, szBuf, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
		if (bBGBitmap) GetBMPSize(bBGBitmap, &backX, &backY);
	}
	
	GetRCString("VWMSelBmp", szTemp, ".none", 256);
	sprintf(szBuf, "%s%s", szImagePath, szTemp);
	sBGBitmap = LoadImage(inst, szBuf, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
	if (sBGBitmap) GetBMPSize(sBGBitmap, &selX, &selY);
	
	GetRCString("VWMWinBmp", szTemp, ".none", 256);
	sprintf(szBuf, "%s%s", szImagePath, szTemp);
	wBGBitmap = LoadImage(inst, szBuf, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
	if (wBGBitmap) GetBMPSize(wBGBitmap, &winX, &winY);
	
	GetRCString("VWMTitlebarBmp", szTemp, ".none", 256);
	sprintf(szBuf, "%s%s", szImagePath, szTemp);
	tBGBitmap = LoadImage(inst, szBuf, IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_LOADFROMFILE);
	if (tBGBitmap) GetBMPSize(tBGBitmap, &titleX, &titleY);

	for( i = 0; i < 256; i++ )
		pszWallpapers[i] = NULL;

	nDesks = ScreensX * ScreensY;

	for( i = 0; i < nDesks; i++ )
	{
		TCHAR szConfigLine[32];
		wsprintf( szConfigLine, TEXT("VWMDeskWallpaper%d"), i + 1 );

		pszWallpapers[i] = (LPTSTR) malloc( MAX_PATH );
		GetRCString( szConfigLine, pszWallpapers[i], TEXT(""), MAX_PATH );
	}
}

void BangGather(HWND caller ,char* args)
{
	RECT r;
	HWND prev, p;
	
	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	
	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
inside:
		if (prev == NULL) break;
		
		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		if (GetWindowLong(prev, GWL_STYLE) & WS_MINIMIZE)
			continue;
		
		p = GetParent(prev);
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);
		
		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			if (r.left > ScreenWidth)
				r.left -= (ScreenWidth + 10);
			r.right %= (ScreenWidth+10);
		}
		else if (r.right < 0)
		{
			r.right %= (ScreenWidth+10);
			if (r.right < 0)
				r.right += (ScreenWidth + 10);
			r.left %= (ScreenWidth+10);
			if (r.left < -10)
				r.left += (ScreenWidth + 10);
		}
		
		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			if (r.top > ScreenHeight)
				r.top -= (ScreenHeight + 10);
			r.bottom %= (ScreenHeight+10);
		}
		else if (r.bottom < 0)
		{
			r.bottom %= (ScreenHeight+10);
			if (r.bottom < 0)
				r.bottom += (ScreenHeight + 10);
			r.top %= (ScreenHeight+10);
			if (r.top < -10)
				r.top += (ScreenHeight + 10);
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
}

HICON getIconFromWindow(HWND hWnd, BOOL bBigIcon)
{
	HICON hIcon = NULL;
	
	int nBigOrSmall = bBigIcon ? ICON_BIG : ICON_SMALL;
	int nBigOrSmall2 = bBigIcon ? GCL_HICON : GCL_HICONSM;
	
	SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 0, 
		SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);
	if(!hIcon) SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 1, 
		SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);
	if(!hIcon) SendMessageTimeout(hWnd, WM_QUERYDRAGICON, nBigOrSmall, 
		0, SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);
	
	return hIcon;
}

void SetDeskWallpaper()
{
	if( pszWallpapers[currentScreen] && *pszWallpapers[currentScreen] )
	{
		SystemParametersInfo( SPI_SETDESKWALLPAPER, 0,
			(PVOID) pszWallpapers[currentScreen],
			SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
	}
}
