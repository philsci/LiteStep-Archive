#define STRICT
#include <time.h>
#include <windows.h>

#define HOOK_DLL
#include "hook.h"

#pragma data_seg("SHAREDATA")
static HHOOK g_hHook=0;                // HHOOK from SetWindowsHook
static HWND parent=NULL;
#pragma data_seg()
HINSTANCE hInst;

void AttachHookDll(HWND hwndParent) {
    MINIMIZEDMETRICS mm;

	if (hwndParent) {
		parent = hwndParent;
		memset(&mm, 0, sizeof(MINIMIZEDMETRICS));
		mm.cbSize = sizeof(MINIMIZEDMETRICS);
		SystemParametersInfo(SPI_GETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);
		mm.iArrange |= ARW_HIDE; // ARW_HIDE == 8
		SystemParametersInfo(SPI_SETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);
		g_hHook = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellProc, hInst, 0);
		if (!g_hHook)
			MessageBox(parent, "Error creating shell Hook!", "Hook", MB_OK);
	} else {
		UnhookWindowsHookEx(g_hHook);
		g_hHook = 0;
	}
}

LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	HWND hwnd = (HWND)wParam;

	if (0 > nCode)
		return (CallNextHookEx(g_hHook, nCode, wParam, lParam));
	switch (nCode) {
	case HSHELL_ACTIVATESHELLWINDOW:
		break;
	case HSHELL_GETMINRECT:
		PostMessage(parent, LM_MINMAXWIN, (WPARAM)hwnd, 0);
		break;
	case HSHELL_LANGUAGE:
		break;
	case HSHELL_REDRAW:
		break;
	case HSHELL_TASKMAN:
		break;
	case HSHELL_WINDOWACTIVATED:
		PostMessage(parent, LM_ACTIVEWIN, (WPARAM)hwnd, 0);
		break;
	case HSHELL_WINDOWCREATED:
		PostMessage(parent, LM_ADDWINDOW, (WPARAM)hwnd, 0);
		break;
	case HSHELL_WINDOWDESTROYED:
		PostMessage(parent, LM_REMOVEWINDOW, (WPARAM)hwnd, 0);
		break;
	}
	return 0;
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	if (fdwReason == DLL_PROCESS_ATTACH) {
		// We don't need thread notifications for what we're doing.  Thus, get
		// rid of them, thereby eliminating some of the overhead of this DLL,
		// which will end up in nearly every GUI process anyhow.
		DisableThreadLibraryCalls(hinstDLL);
		hInst = hinstDLL;
	}
	return TRUE;
}
