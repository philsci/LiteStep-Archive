/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __command_H
#include "..\lsapi\common.h"
#include <Shlwapi.h>

#include "..\lsapi\safestr.h"
#include "..\lsapi\lswinbasex.h"
#include "..\lsapi\mru.h"

using namespace std;

#ifndef GET_X_LPARAM
#define GET_X_LPARAM(lp)   ((int)(short)LOWORD(lp))
#endif

#ifndef GET_Y_LPARAM
#define GET_Y_LPARAM(lp)   ((int)(short)HIWORD(lp))
#endif

class Command : public WindowX
{
public:
  int height;
  int width;
  int xpos;
  int ypos;
  int borderSize;
  int borderSizeTop;
  int borderSizeLeft;
  int borderSizeBottom;
  int borderSizeRight;

  BOOL hideOnUnfocus;
  BOOL isVisible;
  bool isOnTop;
  BOOL rememberPosition;
  bool mouseState;

  HFONT hFont;
  HBRUSH hBrush;
  HBRUSH hBorderBrush;

  LPTSTR szFontFace;
  int textSize;
  COLORREF colorText;
  COLORREF colorBG;
  COLORREF colorBorder;

  BOOL hasBevel;
  COLORREF bevelLightColor;
  COLORREF bevelDarkColor;
  int bevelSize;

  HWND hEdit;

	BOOL clearEditOnCommand;
  BOOL selectAllOnFocus;

  MRUList mruList;

  _TCHAR* pszCommand;
	_TCHAR* pszArgument;
public:
  Command(HWND parentWnd, int& code);
  ~Command();

  void BangCommandMove(HWND, LPCTSTR);
  void BangCommandToggle(HWND, LPCTSTR);
  void BangCommandHide(HWND, LPCTSTR);
  void BangCommandShow(HWND, LPCTSTR);
  void BangCommandFocus(HWND, LPCTSTR);
  void BangCommandResetPos(HWND, LPCTSTR);
private:

	long getHittest(LPARAM lParam);

  virtual void windowProc(Message& message);

  void onCreate(Message& message);
  void onCtlColorEdit(Message& message);
  void onSetFocus(Message& message);
  void onNCHitTest(Message& message);
  void onSize(Message& message);
  void onEraseBkgnd(Message &message);
  void onCommand(Message &message);
  void onKillFocus(Message &message);
  void onRefresh(Message &message);
  void onMouseButtonDown(Message &message);
  void onMouseButtonUp(Message &message);

  inline LPCTSTR Revision();

  void setupCommand();
  void cleanCommand();

};

void BangCommandMoveFunction(HWND, LPCTSTR);
void BangCommandToggleFunction(HWND, LPCTSTR);
void BangCommandShowFunction(HWND, LPCTSTR);
void BangCommandHideFunction(HWND, LPCTSTR);
void BangCommandFocusFunction(HWND, LPCTSTR);
void BangCommandResetPosFunction(HWND, LPCTSTR);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCTSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
