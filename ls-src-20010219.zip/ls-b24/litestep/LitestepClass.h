/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma warning(disable: 4786)
#include "../core/ifcs.h"
#include <map>
#include <string>

using namespace std;

class Litestep : public ILitestep  
{
	long refCount;
	typedef map<wstring, void*> IFCMap;

	IFCMap WindowListMap;
	IFCMap MessageManagerMap;
	IFCMap ModuleManagerMap;
	IFCMap BangManagerMap;

	ILogDispatch *myLogDispatch;

public:
	Litestep();
	virtual ~Litestep();

	void SetLogDispatch(ILogDispatch *log);

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	/////////////////////////////////////////////////////////////////////////////
	// From ILitestep
    virtual HRESULT STDMETHODCALLTYPE GetWindowList( 
        /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE FindWindowList( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE RegisterWindowList( 
        /* [in] */ BSTR name,
        /* [in] */ IWindowList __RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE UnregisterWindowList( 
        /* [in] */ BSTR name);
    
    virtual HRESULT STDMETHODCALLTYPE GetModuleManager( 
        /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE FindModuleManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE RegisterModuleManager( 
        /* [in] */ BSTR name,
        /* [in] */ IModuleManager __RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE UnregisterModuleManager( 
        /* [in] */ BSTR name);
    
    virtual HRESULT STDMETHODCALLTYPE GetMessageManager( 
        /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE FindMessageManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE RegisterMessageManager( 
        /* [in] */ BSTR name,
        /* [in] */ IMessageManager __RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE UnregisterMessageManager( 
        /* [in] */ BSTR name);
    
    virtual HRESULT STDMETHODCALLTYPE GetBangManager( 
        /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE FindBangManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE RegisterBangManager( 
        /* [in] */ BSTR name,
        /* [in] */ IBangManager __RPC_FAR *winlist);
    
    virtual HRESULT STDMETHODCALLTYPE UnregisterBangManager( 
        /* [in] */ BSTR name);

    virtual HRESULT STDMETHODCALLTYPE GetLogDispatch( 
        /* [retval][out] */ ILogDispatch __RPC_FAR *__RPC_FAR *log_dispatch);
};

