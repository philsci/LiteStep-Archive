/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "common.h"
#include "bangs.h"
#include "safestr.h"

extern _TCHAR szAppPath[256];
extern _TCHAR szRcPath[256];

void setupBangs()
{
  AddBangCommand(_TEXT("!GATHER"), BangGather);
  AddBangCommand(_TEXT("!RECYCLE"), BangRecycle);
  AddBangCommand(_TEXT("!RUN"), BangRun);
  AddBangCommand(_TEXT("!SHUTDOWN"), BangShutdown);
  AddBangCommand(_TEXT("!TOGGLEWHARF"), BangToggleWharf);
  AddBangCommand(_TEXT("!LOGOFF"), BangLogoff);
  AddBangCommand(_TEXT("!QUIT"), BangQuit);
  AddBangCommand(_TEXT("!POPUP"), BangPopup);
  AddBangCommand(_TEXT("!TILEWINDOWSH"), BangTileWindowsH);
  AddBangCommand(_TEXT("!TILEWINDOWSV"), BangTileWindowsV);
  AddBangCommand(_TEXT("!CASCADEWINDOWS"), BangCascadeWindows);
  AddBangCommand(_TEXT("!MINIMIZEWINDOWS"), BangMinimizeWindows);
  AddBangCommand(_TEXT("!RESTOREWINDOWS"), BangRestoreWindows);
  AddBangCommand(_TEXT("!ABOUT"),  BangAbout);
  AddBangCommand(_TEXT("!UNLOADMODULE"), BangUnloadModule);
  AddBangCommand(_TEXT("!RELOADMODULE"), BangReloadModule);
  AddBangCommand(_TEXT("!EXECUTE"), BangExecute);
  AddBangCommand(_TEXT("!REFRESH"), BangRefresh);
  AddBangCommand(_TEXT("!ALERT"), BangAlert);
  AddBangCommand(_TEXT("!CONFIRM"), BangConfirm);
}


ULONG WINAPI AboutBoxThread( void * );

void BangAbout( HWND, LPCTSTR )
{
	HANDLE threadHandle;
	DWORD threadID;

	threadHandle = CreateThread( NULL,
		0,
		AboutBoxThread,
		NULL,
		0,
		&threadID );

	CloseHandle( threadHandle );
}


void BangAlert(HWND caller, LPCTSTR args)
{
	_TCHAR message[MAX_PATH];
	_TCHAR title[MAX_PATH];
	_TCHAR *tokens[] = { message, title };

	int tokenCount = LCTokenize(args, tokens, 2, 0);

	if(tokenCount >= 1)
	{
		if(tokenCount == 1)
			lstrcpy(title, _TEXT("Litestep"));

		MessageBox(caller, message, title, MB_OK | MB_SETFOREGROUND);
	}
}


void BangCascadeWindows(HWND caller, LPCTSTR args)
{
  CascadeWindows(NULL, MDITILE_SKIPDISABLED, NULL, 0, NULL);
}


void BangConfirm(HWND caller, LPCTSTR args)
{
	_TCHAR first[MAX_PATH];
	_TCHAR second[MAX_PATH];
	_TCHAR third[MAX_PATH];
	_TCHAR fourth[MAX_PATH];
	_TCHAR *tokens[] = { first, second, third, fourth };

	int tokenCount = CommandTokenize(args, tokens, 4, 0);

	if(tokenCount >= 3)
	{
		_TCHAR *message;
		_TCHAR *title;
		_TCHAR *yesCommand;
		_TCHAR *noCommand;

		if(tokenCount == 3)
		{
			message = first;
			yesCommand = second;
			noCommand = third;

			lstrcpy(fourth, _TEXT("Litestep"));
			title = fourth;
		}
		else
		{
			message = first;
			title = second;
			yesCommand = third;
			noCommand = fourth;
		}

		if(MessageBox(caller, message, title, MB_YESNO | MB_SETFOREGROUND) == IDYES)
			LSExecute(caller, yesCommand, SW_SHOWNORMAL);
		else
			LSExecute(caller, noCommand, SW_SHOWNORMAL);
	}
}


void BangExecute(HWND caller, LPCTSTR args)
{
  _TCHAR command[MAX_LINE_LENGTH];
  LPCTSTR nextCommand = args;

  if (!StrLen(args))
    return;

  while (GetToken(nextCommand, command, &nextCommand, true))
    LSExecute(caller, command, SW_SHOWDEFAULT);
}


void BangGather(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_BRINGTOFRONT, 1, 0);
}


void BangLogoff(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 1, 0);
}


void BangMinimizeWindows(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;
	HWND *hwnds;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    max = winList->GetWindowCount();
	hwnds = new HWND[max];
	max = winList->GetWindowList(hwnds, max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;
      window = hwnds[i];

      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsWindowVisible(window))
        continue;
      ShowWindow(window, SW_MINIMIZE);
    }

	delete [] hwnds;
  }
}


void BangPopup(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();
  _TCHAR token0[MAX_LINE_LENGTH], token1[MAX_LINE_LENGTH];
  LPTSTR tokens[2];
  POINT p;
  int count = 0;
  tokens[0] = token0;
  tokens[1] = token1;
  token0[0] = token1[0] = '\0';
  if (args)
    count = LCTokenize(args, tokens, 2, NULL);
  if (ls)
  {
    if (GetCursorPos((LPPOINT)&p) == 0)
      p.x = p.y = 0;
    if (count > 1) {
      for (int i = 0; i <= 1; i++)
      {
        if (strnicmp(tokens[i], _TEXT("X="), 2) == 0)
          p.x = _ttol(tokens[i] + 2);
        else if (strnicmp(tokens[i], _TEXT("Y="),2) == 0)
          p.y = _ttol(tokens[i] + 2);
      }
    }
    SendMessage(ls, LM_HIDEPOPUP, 0, 0);
    SendMessage(ls, LM_POPUP, 0, MAKELPARAM(p.x, p.y));
  }
}


void BangQuit(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 2, 0);
}


void BangRecycle(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    PostMessage(ls, LM_RECYCLE, 0, 0);
  }
}


void BangRefresh(HWND caller, LPCTSTR args)
{
  CloseRC();
	setupVars(szAppPath);
  SetupRC(szRcPath);
	SendMessage(GetLitestepWnd(), LM_REFRESH, 0, 0);
}


void BangReloadModule(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCTSTR nextToken = args;
  _TCHAR path[MAX_PATH];

  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_RELOADMODULE, (WPARAM)path, 0);
}


void BangRestoreWindows(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;
	HWND *hwnds;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    max = winList->GetWindowCount();
	hwnds = new HWND[max];
	max = winList->GetWindowList(hwnds, max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;

      window = hwnds[i];
      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsIconic(window))
        continue;
      ShowWindow(window, SW_RESTORE);
    }

	delete [] hwnds;
  }
}


void BangRun(HWND caller, LPCTSTR args)
{
    FARPROC (__stdcall *MSRun)(HWND, int, int, LPTSTR, LPTSTR, int);

    MSRun = (FARPROC (__stdcall *) (HWND, int, int, LPTSTR, LPTSTR, int))GetProcAddress(GetModuleHandle(_TEXT("SHELL32.DLL")), (LPTSTR)((long)0x3D));
    MSRun(NULL, 0, 0, NULL, NULL, 0);
}


void BangShutdown(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd ();
    FARPROC (__stdcall *MSWinShutdown)(HWND);

    MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle(_TEXT("SHELL32.DLL")), (LPTSTR)((long)0x3C));
    MSWinShutdown(ls);
}


void BangTileWindowsH(HWND caller, LPCTSTR args)
{
  TileWindows(NULL, MDITILE_HORIZONTAL, NULL, 0, NULL);
}


void BangTileWindowsV(HWND caller, LPCTSTR args)
{
  TileWindows(NULL, MDITILE_VERTICAL, NULL, 0, NULL);
}


void BangToggleWharf(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_SHADETOGGLE, 0, 0);
}


void BangUnloadModule(HWND caller, LPCTSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCTSTR nextToken = args;
  _TCHAR path[MAX_PATH];
  
  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_UNLOADMODULE, (WPARAM)path, 0);
}

