/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_GRADIENTPAINTER_H__165B6193_7A01_11D2_B6A9_00C0DF466974__INCLUDED_)
#define AFX_GRADIENTPAINTER_H__165B6193_7A01_11D2_B6A9_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Painter.h"

/**
Strategy class for painting gradient items. the painter draws a
gradient from left to right
*/
class GradientPainter : public Painter  
{
public:
	/**
	constructs a gradientpainter object.

	@param nFrom the left color
	@param nTo the right color
	*/
	GradientPainter(COLORREF nFrom, COLORREF nTo);

	/// destroys the gradient object
	virtual ~GradientPainter();

	/**
	Paints a gradient background on the menuitem

	@param m pointer to the menuitem
	@param h handle to the devicecontext to be painted
	*/
	void Paint(MenuItem* m, HDC hDC);

protected:

	/// left color
	COLORREF m_nFrom;

	/// right color
	COLORREF m_nTo;

	/// current height of the cached title
	int m_nBuffHeight;

	/// current width of the cached title
	int m_nBuffWidth;

	/// contans to cached image
	HDC m_hBuffDC;

	/// contans to cached image
	HBITMAP m_hBuffBmp;
};

#endif // !defined(AFX_GRADIENTPAINTER_H__165B6193_7A01_11D2_B6A9_00C0DF466974__INCLUDED_)
