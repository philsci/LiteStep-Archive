/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "commandItem.h"
#include "TitleItem.h"
#include "PopupMenu.h"
#include "../lsapi/lsapi.h"
#include "contextmenu.h"

CommandItem::CommandItem(_TCHAR* pszCommand, _TCHAR* pszArgument, _TCHAR* pszTitle) :
				TitleItem(pszTitle)
{	
	m_pszCommand = pszCommand != NULL ? strdup(pszCommand) : NULL;
	m_pszArgument = pszArgument != NULL ? strdup(pszArgument) : NULL;
}

CommandItem::~CommandItem()
{
	if(m_pszCommand) free(m_pszCommand);
	m_pszCommand = NULL;
	if(m_pszArgument) free(m_pszArgument);
	m_pszArgument = NULL;
}

void CommandItem::Invoke()
{
	m_pParent->Hide(HIDE_PARENTS);

	if(m_pszCommand[0] == '!')
		ParseBangCommand (GetWindow(), m_pszCommand, m_pszArgument);
	else
		this->ShellExecute();
}

UINT CommandItem::GetDrawTextFormat()
{
	if(m_pszCommand != NULL){
		// if it is not a bang command and the command string
		// contains &, then disable prefix. there is a bug here, though...
		if(m_pszCommand[0] != '!' && _tcschr(m_pszCommand, '&'))
			return DT_VCENTER|DT_SINGLELINE|DT_END_ELLIPSIS|DT_NOPREFIX|DT_NOCLIP; 
	}
	
	return TitleItem::GetDrawTextFormat();
}

void CommandItem::ShellExecute()
{
	SHELLEXECUTEINFO si;
	
	_TCHAR working_directory[_MAX_PATH];
	_TCHAR drive[_MAX_DRIVE];
	_TCHAR dir[_MAX_DIR];
	_TCHAR fname[_MAX_FNAME]; // not used
	_TCHAR ext[_MAX_EXT]; // not used
 
	// Call parent
	MenuItem::Invoke();

	// calculate the working directory of the executable. if this is
	// not done the program may not find files that it expects to be
	// there. someone complained that this would make quake not start.
	_tsplitpath(m_pszCommand, drive, dir, fname, ext);
	lstrcpy(working_directory, drive);
	lstrcat(working_directory, dir);

	ZeroMemory(&si, sizeof(si));
	si.cbSize = sizeof(SHELLEXECUTEINFO);

	if(lstrcmpi(ext, ".lnk") == 0)
		// the link files contain theis own directory and
		// we should not force any other directory upon it.
		si.lpDirectory = NULL;
	else
		// .exe, .com, .bat, ... often need to be executed from their
		// directory
		si.lpDirectory = working_directory;
		
	si.lpVerb = NULL;
	si.nShow = 1;
	si.fMask = SEE_MASK_DOENVSUBST | SEE_MASK_FLAG_NO_UI;
	si.lpFile = m_pszCommand;
	si.lpParameters = m_pszArgument;

	// Makes the shell try to execute the item
	ShellExecuteEx(&si);	

	// todo: this is the place to find if there are any errors ..
	// maybe a liteSTEP error console is not that bad an idea...
}

void CommandItem::RInvoke()
{
  PopupContextMenu(m_pszCommand);
}