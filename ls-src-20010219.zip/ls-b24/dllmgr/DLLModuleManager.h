/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma warning(disable: 4786)
#if !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
#define AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "../core/ifcs.h"
#include <map>
#include <string>

#define BAD_MODULE 0
#define BAD_INIT 1
#define BAD_QUIT 2

#define MODULE_THREADED 1
#define MODULE_NOTPUMPED 2

using namespace std;

typedef int (*ModuleInitExFunc) (HWND, HINSTANCE, LPCTSTR);
typedef int (*ModuleQuitFunc) (HINSTANCE);

class DLLModule {
	HINSTANCE hInstance;
	HANDLE hThread;
	wstring location;

	wstring appPath;
	HWND mainWindow;

	ModuleInitExFunc pInitEx;
	ModuleQuitFunc pQuit;

	BOOL threaded;
	BOOL pumped;

public:
	void HandleThreadMessage(MSG &msg);
	DLLModule(BSTR loc, BOOL = false, BOOL = false);
	virtual ~DLLModule();
	void Init(HWND hMainWindow, wstring appPath);
	void Quit();
	static ULONG __stdcall ThreadProc(void* dllModPtr);
	HINSTANCE GetInstance();
	HANDLE GetThread();
	wstring GetLocation();
	ModuleQuitFunc GetQuit();
	ModuleInitExFunc GetInitEx();
	static HRESULT WINAPI ThreadWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	HWND hThreadWnd;

private:
	void WaitForThread(DWORD);
	ULONG CallInit();
};

class DLLModuleManager : public IModuleManager  
{
public:
	static HANDLE thread_event;
	static HANDLE load_quit_event;
	DLLModuleManager(HWND, LPCTSTR);
	virtual ~DLLModuleManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	////////////////////////////////////////////////////////////////////////////
	// From IModuleManager
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModules( 
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE LoadModule( 
        /* [in] */ BSTR location,
        /* [in] */ int flags);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModules( void);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE QuitModule( 
        /* [in] */ BSTR location);
        
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleList( 
        /* [in] */ SAFEARRAY __RPC_FAR * strlist,
        /* [retval][out] */ int __RPC_FAR *count);
    
    /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleCount( 
        /* [retval][out] */ int __RPC_FAR *count);
private:
	typedef std::map<std::wstring, DLLModule*> wstring2module;

	wstring2module dllModuleMap;
	HWND hMainWindow;
	wstring appPath;
	long refCount;
};

#endif // !defined(AFX_DLLMODULEMANAGER_H__90F26AC7_3135_4D55_A5DC_BBAFF1851976__INCLUDED_)
