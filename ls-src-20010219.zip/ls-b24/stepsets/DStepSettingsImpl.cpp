/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#include <windows.h>
#include <comdef.h>
#include "DStepSettingsImpl.h"

DStepSettingsImpl::DStepSettingsImpl(IStepSettings *ss) {
	stepSettings = ss;
	refCount = 0;
}

DStepSettingsImpl::~DStepSettingsImpl() {
	stepSettings->Release();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE DStepSettingsImpl::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IDispatch) {
		*ppv = static_cast<IDispatch*>(this);
	} else if (riid == IID_DStepSettings) {
		*ppv = static_cast<DStepSettings*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE DStepSettingsImpl::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE DStepSettingsImpl::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

/////////////////////////////////////////////////////////////////////
// From IDispatch
HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetTypeInfoCount( 
    /* [out] */ UINT __RPC_FAR *pctinfo) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetTypeInfo( 
    /* [in] */ UINT iTInfo,
    /* [in] */ LCID lcid,
    /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetIDsOfNames( 
    /* [in] */ REFIID riid,
    /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
    /* [in] */ UINT cNames,
    /* [in] */ LCID lcid,
    /* [size_is][out] */ DISPID __RPC_FAR *rgDispId) {
	return E_NOTIMPL;
}

/* [local] */ HRESULT STDMETHODCALLTYPE DStepSettingsImpl::Invoke( 
    /* [in] */ DISPID dispIdMember,
    /* [in] */ REFIID riid,
    /* [in] */ LCID lcid,
    /* [in] */ WORD wFlags,
    /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
    /* [out] */ VARIANT __RPC_FAR *pVarResult,
    /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
    /* [out] */ UINT __RPC_FAR *puArgErr) {
	return E_NOTIMPL;
}

/////////////////////////////////////////////////////
// From DStepSettings
HRESULT STDMETHODCALLTYPE DStepSettingsImpl::VarExpansion( 
    /* [in] */ const BSTR value,
    /* [retval][out] */ BSTR __RPC_FAR *buffer) {

	if (buffer == NULL) {
		return E_FAIL;
	}

	*buffer = stepSettings->VarExpansion(value);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::ParseFile( 
    /* [in] */ const BSTR stepfile,
    /* [retval][out] */ BSTR __RPC_FAR *fullpath) {

	*fullpath = stepSettings->ParseFile(stepfile);

	return S_OK;
}
        
HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetInt( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ int nDefault,
    /* [retval][out] */ int __RPC_FAR *value) {

	if (value == NULL) {
		return E_FAIL;
	}

	*value = stepSettings->GetInt(szKeyName, nDefault);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetBool( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL ifFound,
    /* [retval][out] */ BOOL __RPC_FAR *value) {

	if (value == NULL) {
		return E_FAIL;
	}

	*value = stepSettings->GetBool(szKeyName, ifFound);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetBoolDef( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL bDefault,
    /* [retval][out] */ BOOL __RPC_FAR *value) {

	if (value == NULL) {
		return E_FAIL;
	}

	*value = stepSettings->GetBoolDef(szKeyName, bDefault);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetString( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR defStr,
    /* [retval][out] */ BSTR __RPC_FAR *szValue) {

	if (szValue == NULL) {
		return E_FAIL;
	}

	*szValue = stepSettings->GetString(szKeyName, defStr);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetColor( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ COLORREF colDef,
    /* [retval][out] */ COLORREF __RPC_FAR *value) {

	if (value == NULL) {
		return E_FAIL;
	}

	*value = stepSettings->GetColor(szKeyName, colDef);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetLine( 
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR szDefault,
    /* [retval][out] */ BSTR __RPC_FAR *szBuffer) {

	if (szBuffer == NULL) {
		return E_FAIL;
	}

	*szBuffer = stepSettings->GetLine(szKeyName, szDefault);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::Tokenize( 
    /* [in] */ const BSTR szString,
    /* [in] */ BOOL useBrackets,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *lpszBuffers) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE DStepSettingsImpl::GetIterator( 
    /* [in] */ const BSTR szPath,
    /* [retval][out] */ DStepIterator __RPC_FAR *iter) {

	if (iter == NULL) {
		return E_FAIL;
	}

	DStepIteratorImpl *i = new DStepIteratorImpl(stepSettings->GetIterator(szPath));
	i->QueryInterface(IID_DStepIterator, (void**)iter);

	return S_OK;
}

DStepIteratorImpl::DStepIteratorImpl(IStepIterator *i) {
	stepiter = i;
	refCount = 0;
}

DStepIteratorImpl::~DStepIteratorImpl() {
	stepiter->Release();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE DStepIteratorImpl::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IDispatch) {
		*ppv = static_cast<IDispatch*>(this);
	} else if (riid == IID_DStepIterator) {
		*ppv = static_cast<DStepIterator*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE DStepIteratorImpl::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE DStepIteratorImpl::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

/////////////////////////////////////////////////////////////////////
// From IDispatch
HRESULT STDMETHODCALLTYPE DStepIteratorImpl::GetTypeInfoCount( 
    /* [out] */ UINT __RPC_FAR *pctinfo) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE DStepIteratorImpl::GetTypeInfo( 
    /* [in] */ UINT iTInfo,
    /* [in] */ LCID lcid,
    /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) {
	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE DStepIteratorImpl::GetIDsOfNames( 
    /* [in] */ REFIID riid,
    /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
    /* [in] */ UINT cNames,
    /* [in] */ LCID lcid,
    /* [size_is][out] */ DISPID __RPC_FAR *rgDispId) {
	return E_NOTIMPL;
}

/* [local] */ HRESULT STDMETHODCALLTYPE DStepIteratorImpl::Invoke( 
    /* [in] */ DISPID dispIdMember,
    /* [in] */ REFIID riid,
    /* [in] */ LCID lcid,
    /* [in] */ WORD wFlags,
    /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
    /* [out] */ VARIANT __RPC_FAR *pVarResult,
    /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
    /* [out] */ UINT __RPC_FAR *puArgErr) {
	return E_NOTIMPL;
}

////////////////////////////////////////////////////////////////
// From DStepIterator
HRESULT STDMETHODCALLTYPE DStepIteratorImpl::NextConfig( 
    /* [in] */ const BSTR szPrefix,
    /* [retval][out] */ BSTR *szBuffer) {

	if (szBuffer == NULL) {
		return E_FAIL;
	}

	*szBuffer = stepiter->NextConfig(szPrefix);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DStepIteratorImpl::NextLine( 
    /* [retval][out] */ BSTR *szBuffer) {

	if (szBuffer == NULL) {
		return E_FAIL;
	}

	*szBuffer = stepiter->NextLine();

	return S_OK;
}
