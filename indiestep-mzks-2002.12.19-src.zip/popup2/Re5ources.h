/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __RE5OURCES_H__
#define __RE5OURCES_H__

#ifdef	__cplusplus
extern "C"
{
#endif	/* __cplusplus */

#define RESSTR(S) (LoadStringInplace(g_hResStrInstance, (UINT)(S), g_szResStrBuffer, MAX_PATH))

	extern HINSTANCE g_hResStrInstance;
	extern char g_szResStrBuffer[];

	/**
	returns an icon that is assosiated with the specified path. the path
	may be a file or directory.
	 
	@param pszPath string containing the name of the path theat you want the icon from
	@return handle to the extracted icon
	*/
	//HICON GetIconFromPath(const char* pszPath);

	/**
	Retrieves an icon closest to the given size. Can handle icon locations with
	indeces (ex, "foo.exe,4"), icon files, and arbitrary paths.
	 
	@param pszPath path to icon file, executable, etc
	@param cxDesired desired width
	@param cyDesired desired height
	@return icon handle
	*/
	HICON GetIconFromPathEx(LPCSTR pszPath, int cxDesired, int cyDesired);

	/**
	Returns the icon that is suitable with the window. several different
	strategies for obtaining the icon is used
	 
	@param hWnd hande to the window that you want the icon from
	@param bBigIcon TRUE if you want a big icon, FALSE if you want a small icon
	@return handle to the icon
	*/
	HICON GetIconFromWindow(HWND hWnd, BOOL bBigIcon);

	/**
	determines if a window should be present in taskmanagers or not
	 
	@param hWnd handle to the window to be tested
	@return returns TRUE if it is an App window, FALSE it is not an app window
	*/
	BOOL IsAppWindow(HWND hWnd);

	/**
	converts the time to internet time (0-1000). Example code:
	<code>
	 time_t now;
	 time(&now);
	 printf("@%d", GetInetTime(now));
	</code>
	@param now is the number of seconds since jan 1 1970 (GMT)
	*/
	int GetInetTime(long now);

	/**
	if the window is within nDist of a border it is moved to the border
	 
	@param pwPos current position of the window (obtained from WM_WINDOWPOSCHANGING)
	@param nDist number of pixels to snapp a window
	@param bUseScreenSize TRUE if the screen size should be used. FALSE is the
	                      desktop workarea should be used
	*/
	void SnappWindow(WINDOWPOS* pwPos, int nDist, BOOL bUseScreenSize);

	/**
	Tiles an image horizontally and vertically
	 
	@param hdcDest handle to destination device context
	@param xDest x-coordinate of destination rectangle
	@param yDest y-coordinate of destination rectangle
	@param cxDest width of destination rectangle
	@param cyDest height of destination rectangle
	@param hdcSrc handle to source device context
	@param xSrc x-coordinate of source rectangle
	@param ySrc y-coordinate of source rectangle
	@param cxSrc width of source rectangle
	@param cySrc height of source rectangle
	@param dwROP raster operation code
	*/
	void TileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP);

	/**
	Tiles an image horizontally, stretching it vertically
	 
	@param hdcDest handle to destination device context
	@param xDest x-coordinate of destination rectangle
	@param yDest y-coordinate of destination rectangle
	@param cxDest width of destination rectangle
	@param cyDest height of destination rectangle
	@param hdcSrc handle to source device context
	@param xSrc x-coordinate of source rectangle
	@param ySrc y-coordinate of source rectangle
	@param cxSrc width of source rectangle
	@param cySrc height of source rectangle
	@param dwROP raster operation code
	*/
	void HorizontalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP);

	/**
	Tiles an image vertically, stretching it horizontally
	 
	@param hdcDest handle to destination device context
	@param xDest x-coordinate of destination rectangle
	@param yDest y-coordinate of destination rectangle
	@param cxDest width of destination rectangle
	@param cyDest height of destination rectangle
	@param hdcSrc handle to source device context
	@param xSrc x-coordinate of source rectangle
	@param ySrc y-coordinate of source rectangle
	@param cxSrc width of source rectangle
	@param cySrc height of source rectangle
	@param dwROP raster operation code
	*/
	void VerticalTileBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, DWORD dwROP);

	/**
	Stretches or tiles an image while preserving the edges
	 
	@param hdcDest handle to destination device context
	@param xDest x-coordinate of destination rectangle
	@param yDest y-coordinate of destination rectangle
	@param cxDest width of destination rectangle
	@param cyDest height of destination rectangle
	@param hdcSrc handle to source device context
	@param xSrc x-coordinate of source rectangle
	@param ySrc y-coordinate of source rectangle
	@param cxSrc width of source rectangle
	@param cySrc height of source rectangle
	@param cxLeft number of pixels on the left edge that won't be scaled
	@param cyTop number of pixels on the top edge that won't be scaled
	@param cxRight number of pixels on the right edge that won't be scaled
	@param cyBottom number of pixels on the bottom edge that won't be scaled
	@param nMode scaling mode (MULTIBLT_*)
	@param dwROP raster operation code
	*/
	void MultiBlt(HDC hdcDest, int xDest, int yDest, int cxDest, int cyDest, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc, int cxLeft, int cyTop, int cxRight, int cyBottom, int nMode, DWORD dwROP);

#define MULTIBLT_STRETCH 0
#define MULTIBLT_TILE 1
#define MULTIBLT_TILEHORIZONTAL 2
#define MULTIBLT_TILEVERTICAL 3

	/**
	removes white space characters from the beginning of the string
	*/
	void TrimLeft( char *toTrim );

	LPSTR LoadStringInplace( HINSTANCE hInstance, UINT nID, LPSTR pszBuffer, UINT nLength );


#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif
