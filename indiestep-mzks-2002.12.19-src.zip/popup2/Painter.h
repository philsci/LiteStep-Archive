/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_PAINTER_H__70DDBB43_76FE_11D2_B6A5_00C0DF466974__INCLUDED_)
#define AFX_PAINTER_H__70DDBB43_76FE_11D2_B6A5_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class MenuItem;

/**
Generic baseclass for classes that paint on menuitems. These classes
are used as strategies by MenuItem. 
*/
class Painter
{
public:
	/// constructs a painter object
	Painter();

	/// destroys the painter object
	virtual ~Painter();

	/**
	Paints the specified rectangle in the given DC

	@param hDC handle to the destination device context
	@param prc destination rectangle
	*/
	virtual void Paint(HDC hDC, CONST RECT *prc);

	/**
	Paints a menuitem on the device

	@param m pointer to a menuitem to be painted 
	@param hDC handle to the device contect to be painted
	*/
	virtual void Paint(MenuItem* m, HDC hDC);

	/**
	Sets the font that shall be used when painting

	@param hFont handle to the font 
	@param color the color (COLORREF) that shall be used when drawing strings
	*/
	virtual void SetFont(HFONT hFont, COLORREF color)
	{
		m_hFont = hFont;
		m_FontColor = color;
	};

	/**
	Returns the currently selected font

	@return the selected font handle
	*/
	virtual HFONT GetFont()
	{
		return m_hFont;
	};

	/**
	Sets the shadw depht used when drawing the text

	@param nShadowDepth shadow depth
	@param dwShadowColor shadow color
	*/
	virtual void SetShadow(int nShadowDepht, DWORD dwShadowColor)
	{
		m_nShadowDepth = nShadowDepht;
		m_dwShadowColor = dwShadowColor;
	};

	/**
	Returns the current shadow depth

	@return the shadow depth
	*/
	virtual int GetShadowDepth()
	{
		return m_nShadowDepth;
	};

	/**
	Returns the current shadow color

	@return the shadow color
	*/
	virtual COLORREF GetShadowColor()
	{
		return m_dwShadowColor;
	};

	/**
	Returns the corrently selected font color

	@return COLORREF containing the font color
	*/
	virtual COLORREF GetFontColor()
	{
		return m_FontColor;
	};

	/**
	Computes the region that represents the area that will be painted

	@param hRgn handle of destination region
	@param prc bounding rectangle
	*/
	virtual void GetRegion(HRGN hRgn, CONST RECT *prc);

	/**
	returns the region that the menuitem planns to paint at

	@param hRgn handle to the region to receive the information
	@param pItem pointer to the menu item that is to be covered
	*/
	virtual void GetRegion(HRGN hRgn, MenuItem* pItem);

private:
	HFONT m_hFont;
	COLORREF m_FontColor;
	int m_nShadowDepth;
	DWORD m_dwShadowColor;
};

#endif // !defined(AFX_PAINTER_H__70DDBB43_76FE_11D2_B6A5_00C0DF466974__INCLUDED_)
