/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "DirectoryFolder.h"
#include "PopupMaker.h"
#include "PopupMenu.h"
#include "ContextMenu.h"

#include "HeaderItem.h"

BOOL DirectoryFolder::m_bShowExtension = FALSE;
BOOL DirectoryFolder::m_bAutoSeparator = FALSE;
BOOL DirectoryFolder::m_bPaintFolderIcon = TRUE;

DirectoryFolder::DirectoryFolder(LPSTR pszPath, BOOL bDynamic, PopupMaker* pPopupMaker,
                                 LPSTR pszTitle): FolderItem(NULL, pszTitle)
{
	m_bDynamic = bDynamic;
	m_pszPath = pszPath != NULL ? strdup(pszPath) : NULL;
	m_pPopupMaker = pPopupMaker;

}

DirectoryFolder::~DirectoryFolder()
{
	if (m_pszPath)
		free(m_pszPath);
	m_pszPath = NULL;

	if (m_pSubMenu)
		delete m_pSubMenu;
	m_pSubMenu = NULL;
}

BOOL DirectoryFolder::Active(BOOL bActivate)
{
	if (m_bActive == bActivate && m_pSubMenu)
		if (IsWindowVisible(m_pSubMenu->GetWindow()))
			return bActivate;

    if (bActivate)
    {
        if (m_bDynamic && m_pSubMenu)
        {
            ShowWindow(m_pSubMenu->GetWindow(), SW_HIDE);
            m_pParent->RemoveChild(m_pSubMenu);
            delete m_pSubMenu;
            m_pSubMenu = NULL;
        }
    }
    
    return FolderItem::Active(bActivate);
}

void DirectoryFolder::Attached(PopupMenu* pMenu)
{
	m_pParent = pMenu;
}

void DirectoryFolder::RInvoke()
{

	//For folder merging
	char seps[] = "|";
	char *token = NULL;
	LPSTR tempPath = new char[strlen(m_pszPath) + 1];

	strcpy(tempPath, m_pszPath);
	token = strtok(tempPath, seps );
	if (token != NULL)
	{
        PopupContextMenu(token);
    }
    /* while (token != NULL) {
	   SHELLEXECUTEINFO si;
       
         ZeroMemory(&si, sizeof(si));
         
           si.cbSize = sizeof(SHELLEXECUTEINFO);
           si.lpVerb = NULL;
           si.nShow = 1;
           si.fMask = SEE_MASK_FLAG_NO_UI;
           si.lpFile = token;
           si.lpParameters = NULL;
           
             ShellExecuteEx(&si);
             token = strtok( NULL, seps );
}*/
    
    delete [] tempPath;
}

void DirectoryFolder::ShowSubMenu()
{
    // even lazier loading of folders
    if (m_pSubMenu == NULL)
    {
        // Lazy loading of folders, do not mess with them untill you
        // absolutely need to (this is used strictly for "!DirectoryFolders"
        m_pSubMenu = m_pPopupMaker->LoadFolder(m_pszTitle, m_pszPath);
        m_pParent->AddChild(m_pSubMenu);
        m_pSubMenu->SetParent(m_pParent);
    }

    FolderItem::ShowSubMenu();
}

// folder merging hacks wherever you look
void DirectoryFolder::AddPath(LPCSTR pszNewPath)
{
    LPSTR pszNew = (LPSTR)malloc(strlen(m_pszPath) + strlen(pszNewPath) + 2);
    sprintf(pszNew, "%s|%s", m_pszPath, pszNewPath);

    if (m_pszPath)
        free(m_pszPath);
    m_pszPath = pszNew;
}