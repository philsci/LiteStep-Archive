/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "BmpPainter.h"
#include "MenuItem.h"
#include "../lsapi/lsapi.h"

int BmpPainter::m_nBlt = BMPPAINT_PLAIN;
int BmpPainter::PaintBorderLeft = 0;
int BmpPainter::PaintBorderRight = 0;
int BmpPainter::PaintBorderTop = 0;
int BmpPainter::PaintBorderBottom = 0;

BmpPainter::BmpPainter(HBITMAP hBmp, BOOL bTransparent)
{
	m_bTransparent = bTransparent;

	GetObject(hBmp, sizeof(m_Bmp), &m_Bmp);

	if (m_bTransparent)
		m_hRegion = BitmapToRegion(hBmp, RGB(255, 0, 255), 0x10101010, 0, 0);
	else
		m_hRegion = NULL;

	m_hPicture = CreateCompatibleDC(NULL);
	m_hBmpSaved = (HBITMAP) SelectObject(m_hPicture, hBmp);
	m_hBmp = hBmp;
}

BmpPainter::~BmpPainter()
{
	SelectObject(m_hPicture, m_hBmpSaved);

	DeleteObject(m_hRegion);
    DeleteDC(m_hPicture);
	DeleteObject(m_hBmp);
}

void BmpPainter::Paint(HDC hDC, CONST RECT *prc)
{
	RECT r;
	CopyRect(&r, prc);
	int HorizontalBorder = PaintBorderLeft+PaintBorderRight;
	int VerticalBorder = PaintBorderTop+PaintBorderBottom;
	int RectWidth = r.right - r.left;
	int RectHeight = r.bottom - r.top;

	switch (m_nBlt)
	{
		case BMPPAINT_PLAIN:

		BitBlt(hDC, r.left, r.top, RectWidth, RectHeight, m_hPicture, 0, 0, SRCCOPY);

		break;

		case BMPPAINT_STRETCH:
			if (PaintBorderRight>0 || PaintBorderLeft>0) {
				SetStretchBltMode(hDC, STRETCH_DELETESCANS);
				BitBlt(hDC, r.left, r.top, PaintBorderLeft, PaintBorderTop, m_hPicture, 0, 0, SRCCOPY); // left top corner
				BitBlt(hDC, r.left, r.bottom-PaintBorderBottom, PaintBorderLeft, PaintBorderBottom, m_hPicture, 0, m_Bmp.bmHeight-PaintBorderBottom, SRCCOPY); // left bottom corner
				BitBlt(hDC, r.right-PaintBorderRight, r.top, PaintBorderRight, PaintBorderTop, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, 0, SRCCOPY); // right top corner
				BitBlt(hDC, r.right-PaintBorderRight, r.bottom-PaintBorderBottom, PaintBorderRight, PaintBorderBottom, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, m_Bmp.bmHeight-PaintBorderBottom, SRCCOPY); // right bottom corner

				StretchBlt(hDC, r.left+PaintBorderLeft, r.top, RectWidth-HorizontalBorder, PaintBorderTop, m_hPicture, PaintBorderLeft, 0, m_Bmp.bmWidth-HorizontalBorder, PaintBorderTop, SRCCOPY); // Top
				StretchBlt(hDC, r.left+PaintBorderLeft, r.bottom-PaintBorderBottom, RectWidth-HorizontalBorder, PaintBorderBottom, m_hPicture, PaintBorderLeft, m_Bmp.bmHeight-PaintBorderBottom, m_Bmp.bmWidth-HorizontalBorder, PaintBorderBottom, SRCCOPY); // Bottom
				StretchBlt(hDC, r.left, r.top+PaintBorderTop, PaintBorderLeft, RectHeight-VerticalBorder, m_hPicture, 0, PaintBorderTop, PaintBorderLeft, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Left
				StretchBlt(hDC, r.right-PaintBorderRight, r.top+PaintBorderTop, PaintBorderRight, RectHeight-VerticalBorder, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, PaintBorderTop, PaintBorderRight, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Right
				
				StretchBlt(hDC, r.left+PaintBorderLeft, r.top+PaintBorderTop, RectWidth-HorizontalBorder, RectHeight-VerticalBorder, m_hPicture, PaintBorderLeft, PaintBorderTop, m_Bmp.bmWidth-HorizontalBorder, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Center
			}
			else {
				SetStretchBltMode(hDC, STRETCH_DELETESCANS);
				StretchBlt(hDC, r.left, r.top, RectWidth, RectHeight, m_hPicture, 0, 0, m_Bmp.bmWidth, m_Bmp.bmHeight, SRCCOPY);
			}
		break;

		case BMPPAINT_TILE:
			if (PaintBorderRight>0 || PaintBorderLeft>0) { //  || PaintBorderTop>0 || PaintBorderBottom>0
				BitBlt(hDC, r.left, r.top, PaintBorderLeft, PaintBorderTop, m_hPicture, 0, 0, SRCCOPY); // left top corner
				BitBlt(hDC, r.left, r.bottom-PaintBorderBottom, PaintBorderLeft, PaintBorderBottom, m_hPicture, 0, m_Bmp.bmHeight-PaintBorderBottom, SRCCOPY); // left bottom corner
				BitBlt(hDC, r.right-PaintBorderRight, r.top, PaintBorderRight, PaintBorderTop, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, 0, SRCCOPY); // right top corner
				BitBlt(hDC, r.right-PaintBorderRight, r.bottom-PaintBorderBottom, PaintBorderRight, PaintBorderBottom, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, m_Bmp.bmHeight-PaintBorderBottom, SRCCOPY); // right bottom corner

				TileBlt(hDC, r.left+PaintBorderLeft, r.top, RectWidth-HorizontalBorder, PaintBorderTop, m_hPicture, PaintBorderLeft, 0, m_Bmp.bmWidth-HorizontalBorder, PaintBorderTop, SRCCOPY); // Top
				TileBlt(hDC, r.left+PaintBorderLeft, r.bottom-PaintBorderBottom, RectWidth-HorizontalBorder, PaintBorderBottom, m_hPicture, PaintBorderLeft, m_Bmp.bmHeight-PaintBorderBottom, m_Bmp.bmWidth-HorizontalBorder, PaintBorderBottom, SRCCOPY); // Bottom
				TileBlt(hDC, r.left, r.top+PaintBorderTop, PaintBorderLeft, RectHeight-VerticalBorder, m_hPicture, 0, PaintBorderTop, PaintBorderLeft, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Left
				TileBlt(hDC, r.right-PaintBorderRight, r.top+PaintBorderTop, PaintBorderRight, RectHeight-VerticalBorder, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, PaintBorderTop, PaintBorderRight, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Right
				
				TileBlt(hDC, r.left+PaintBorderLeft, r.top+PaintBorderTop, RectWidth-HorizontalBorder, RectHeight-VerticalBorder, m_hPicture, PaintBorderLeft, PaintBorderTop, m_Bmp.bmWidth-HorizontalBorder, m_Bmp.bmHeight-VerticalBorder, SRCCOPY); // Center

				//BitBlt(hDC, r.left, r.top, PaintBorderLeft, RectHeight, m_hPicture, 0, 0, SRCCOPY);
				//BitBlt(hDC, r.right-PaintBorderRight, r.top, PaintBorderRight, RectHeight, m_hPicture, m_Bmp.bmWidth-PaintBorderRight, 0, SRCCOPY);
				//TileBlt(hDC, r.left+PaintBorderLeft, r.top, RectWidth-HorizontalBorder, RectHeight, m_hPicture, PaintBorderLeft, 0, m_Bmp.bmWidth-HorizontalBorder, m_Bmp.bmHeight, SRCCOPY);
			}
			else {
				TileBlt(hDC, r.left, r.top, RectWidth, RectHeight, m_hPicture, 0, 0, m_Bmp.bmWidth, m_Bmp.bmHeight, SRCCOPY);
			}
		break;
	}
}

/* void BmpPainter::Paint(MenuItem* pMenuItem, HDC hDC)
{
	RECT r;
 
	Painter::Paint(pMenuItem, hDC);
	pMenuItem->GetItemRect(&r);
 
	switch(m_nBlt)
	{
	case BMPPAINT_PLAIN:
		BitBlt(hDC, r.left, r.top, r.right - r.left, r.bottom - r.top, m_hPicture, 0, 0, SRCCOPY);
		break;
	case BMPPAINT_STRETCH:
		SetStretchBltMode(hDC, STRETCH_DELETESCANS);
		StretchBlt(hDC, r.left, r.top, r.right - r.left, r.bottom - r.top, 
			       m_hPicture, 0, 0, m_Bmp.bmWidth,m_Bmp.bmHeight,SRCCOPY);
		break;
	case BMPPAINT_TILE:
		for(int x=r.left; x<pMenuItem->GetWidth(); x+=m_Bmp.bmWidth)
			for(int y=r.top; y<(pMenuItem->GetHeight()+r.top); y+=m_Bmp.bmHeight)
				BitBlt(hDC, x, y, r.right - r.left, r.bottom - r.top, m_hPicture, 0, 0, SRCCOPY);
		break;
	}
	
} */

void BmpPainter::GetRegion(HRGN hRgn, CONST RECT *prc)
{
	if (m_bTransparent)
	{
		int nWidth = prc->right - prc->left;
		int nHeight = prc->bottom - prc->top;

		if (nWidth != m_Bmp.bmWidth || nHeight != m_Bmp.bmHeight)
		{
			RECT rc;
			SetRect(&rc, 0, 0, nWidth, nHeight);

			HDC hdcMem = CreateCompatibleDC(m_hPicture);
			HBITMAP hbmMem = CreateCompatibleBitmap(m_hPicture, nWidth, nHeight);
			HBITMAP hbmOld = (HBITMAP) SelectObject(hdcMem, hbmMem);

			HBRUSH hBrush = CreateSolidBrush(RGB(255, 0, 255));
			FillRect(hdcMem, &rc, hBrush);
			DeleteObject(hBrush);

			Paint(hdcMem, &rc);

			SelectObject(hdcMem, hbmOld);
			DeleteDC(hdcMem);

			HRGN hrgnTemp = BitmapToRegion(hbmMem, RGB(255, 0, 255), 0, 0, 0);
			CombineRgn(hRgn, hrgnTemp, NULL, RGN_COPY);
			DeleteObject(hrgnTemp);

			DeleteObject(hbmMem);
		}
		else
		{
			CombineRgn(hRgn, m_hRegion, NULL, RGN_COPY);
			// OffsetRgn(hRgn, prc->left, prc->top);
		}
	}
	else
	{
		Painter::GetRegion(hRgn, prc);
	}
}

/* void BmpPainter::GetRegion(HRGN hRgn, MenuItem* pItem)
{
	if(m_bTransparent && m_nBlt == BMPPAINT_PLAIN)
	{
		CombineRgn(hRgn, m_hRegion, NULL, RGN_COPY);
	}
	else
	{
		Painter::GetRegion(hRgn, pItem);
	}
} */
