#ifndef  __LOG_H
#define  __LOG_H

#include "windows.h"
#include "lsapi.h"
#include <list>
using namespace std;

#define LOG_BANGS 5

// list or vector?
//typedef LOGLIST list<>;

class LogManager
{
public:
	LogManager();
	~LogManager();

	BOOL LogMessage(const int level, LPCSTR sender, LPCSTR message);
	BOOL AddListener(LogFunction logF);
	BOOL RemoveListener(LogFunction logF);
	BOOL CleanUpListeners();

private:
	// vector f�r att spara lyssnarfunktioner, a la bangmanager
	list<LogFunction> listeners;

};

#endif
