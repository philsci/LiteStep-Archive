/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 19 16:23:05 2002
 */
/* Compiler settings for D:\src\indiestep-mzks-2002.12.21\stepsets\stepsets.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __stepsets_h__
#define __stepsets_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __StepSettings_FWD_DEFINED__
#define __StepSettings_FWD_DEFINED__

#ifdef __cplusplus
typedef class StepSettings StepSettings;
#else
typedef struct StepSettings StepSettings;
#endif /* __cplusplus */

#endif 	/* __StepSettings_FWD_DEFINED__ */


#ifndef __DStepSettingsImpl_FWD_DEFINED__
#define __DStepSettingsImpl_FWD_DEFINED__

#ifdef __cplusplus
typedef class DStepSettingsImpl DStepSettingsImpl;
#else
typedef struct DStepSettingsImpl DStepSettingsImpl;
#endif /* __cplusplus */

#endif 	/* __DStepSettingsImpl_FWD_DEFINED__ */


void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 


#ifndef __LitestepStepSettings_LIBRARY_DEFINED__
#define __LitestepStepSettings_LIBRARY_DEFINED__

/* library LitestepStepSettings */
/* [uuid] */ 


DEFINE_GUID(LIBID_LitestepStepSettings,0xFB7E1DCE,0x36D1,0x4b8d,0x89,0xFC,0x76,0x82,0x7B,0xDC,0xF6,0x4D);

DEFINE_GUID(CLSID_StepSettings,0xD521C62A,0x3904,0x472f,0xB8,0x36,0x62,0x80,0x9E,0x9F,0xDA,0x4F);

#ifdef __cplusplus

class DECLSPEC_UUID("D521C62A-3904-472f-B836-62809E9FDA4F")
StepSettings;
#endif

DEFINE_GUID(CLSID_DStepSettingsImpl,0xD521C62A,0x3904,0x472f,0xB8,0x36,0x62,0x80,0x9E,0x9F,0xDA,0x4E);

#ifdef __cplusplus

class DECLSPEC_UUID("D521C62A-3904-472f-B836-62809E9FDA4E")
DStepSettingsImpl;
#endif
#endif /* __LitestepStepSettings_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
