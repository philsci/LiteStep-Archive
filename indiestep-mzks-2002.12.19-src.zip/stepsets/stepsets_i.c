/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 19 16:23:05 2002
 */
/* Compiler settings for D:\src\indiestep-mzks-2002.12.21\stepsets\stepsets.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_LitestepStepSettings = {0xFB7E1DCE,0x36D1,0x4b8d,{0x89,0xFC,0x76,0x82,0x7B,0xDC,0xF6,0x4D}};


const CLSID CLSID_StepSettings = {0xD521C62A,0x3904,0x472f,{0xB8,0x36,0x62,0x80,0x9E,0x9F,0xDA,0x4F}};


const CLSID CLSID_DStepSettingsImpl = {0xD521C62A,0x3904,0x472f,{0xB8,0x36,0x62,0x80,0x9E,0x9F,0xDA,0x4E}};


#ifdef __cplusplus
}
#endif

