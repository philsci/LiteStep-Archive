// DlgConf.cpp : implementation file
//

#include "stdafx.h"
#include "lscp.h"
#include "DlgConf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgConf dialog


CDlgConf::CDlgConf(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgConf::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgConf)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgConf::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgConf)
	DDX_Control(pDX, IDC_EDIT2, m_wndThemestep);
	DDX_Control(pDX, IDC_EDIT1, m_wndMainstep);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgConf, CDialog)
	//{{AFX_MSG_MAP(CDlgConf)
	ON_BN_CLICKED(IDC_APPLY, OnApply)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgConf message handlers

BOOL CDlgConf::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
 	//leggi il registro 
 	CString strSection       = "Config";
 	CString strStringItem1   = "MainStep";
 	CString strStringItem2	 = "ThemeStep";
	
	CWinApp* pApp = AfxGetApp();
  	
 	szMainstep = pApp->GetProfileString(strSection, strStringItem1, "Step.rc");
 	szThemestep = pApp->GetProfileString(strSection, strStringItem2, "Step.rc");
	
	m_wndMainstep.SetWindowText(szMainstep);
	m_wndThemestep.SetWindowText(szThemestep);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgConf::Apply()
{

	m_wndMainstep.GetWindowText(szMainstep);
	m_wndThemestep.GetWindowText(szThemestep);

	//scrivi il registro
 	CString strSection       = "Config";
 	CString strStringItem1   = "MainStep";
 	CString strStringItem2	 = "ThemeStep";

	CWinApp* pApp = AfxGetApp();

	pApp->WriteProfileString(strSection, strStringItem1, szMainstep);
	pApp->WriteProfileString(strSection, strStringItem2, szThemestep);

}

void CDlgConf::OnApply() 
{

	Apply();
	OnCancel();
}

void CDlgConf::OnOK()
{

}
