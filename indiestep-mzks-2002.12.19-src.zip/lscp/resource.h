//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lscp.rc
//
#define IDD_LSCP_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDB_BITMAP1                     130
#define IDR_MENU2                       132
#define IDR_MENU3                       133
#define IDR_MENU4                       134
#define IDR_MENU5                       136
#define IDD_DIALOGCONF                  137
#define IDR_MENU6                       138
#define IDC_LIST1                       1000
#define IDC_LIST2                       1001
#define IDC_BUTTON1                     1002
#define IDC_CLEARHISTORY                1002
#define IDC_APPLY                       1002
#define IDC_TREE1                       1003
#define IDC_EDIT1                       1004
#define IDC_PTITLE                      1005
#define IDC_CHECK1                      1006
#define IDC_CLOSE                       1007
#define IDC_PLOGO                       1008
#define IDC_SEP                         1009
#define IDC_LABELEX                     1010
#define IDC_COMBO1                      1011
#define IDC_RADIO1                      1012
#define IDC_OTS                         1012
#define IDC_RADIO2                      1013
#define IDC_CUSTOM                      1013
#define IDC_SEP2                        1014
#define IDC_SEP3                        1015
#define IDC_RECYCLE                     1016
#define IDC_QUIT                        1017
#define IDC_RESTART                     1018
#define IDC_PARAM                       1019
#define IDC_LIST3                       1020
#define IDC_LIST4                       1021
#define IDC_EDIT2                       1022
#define IDC_CONFIG                      1023
#define IDC_SWITCH                      1024
#define ID_DUMMY_INTERNALEDITOR         32771
#define ID_DUMMY_DEFAULTEDITOR          32772
#define ID_DUMMY_NOTEPAD                32773
#define ID_DUMMY2_TEST                  32774
#define ID_BANGS_EXEC                   32774
#define ID_DUMMY2_TEST2                 32775
#define ID_BANGS_EXECPARAM              32775
#define ID_BANGS_COPYTOCLIPBOARD        32776
#define ID_BANGS_COPYTOCLIPBOARDWITHPARAMETERS 32777
#define ID_BANGS_COPYTOCOMMANDLINE      32778
#define ID_HELP_COPYTOCLIPBOARD         32779
#define ID_VARS_COPYTOCLIPBOARD         32779
#define ID_MODULES_COPYPATHTOCLIPBOARD  32780
#define ID_MODULES_UNLOADMODULE         32781
#define ID_MODULES_RELOADMODULE         32782
#define ID_SWITCH_SWITCHTHEME           32783
#define ID_SWITCH_SHOWTHEMEINFORMATION  32784
#define ID_VARS_COPYVARIABLETOCOMMANDLINE 32785
#define ID_VARS_COPYTOCLIPBOARD2        32786
#define ID_VARS_COPYVARIABLETOCOMMANDLINE2 32787
#define ID_COPYTOCLIPBOARD              32790
#define ID_COPYTOCOMMANDLINE            32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32793
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
