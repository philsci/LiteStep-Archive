// lscpDlg.h : header file
//

#if !defined(AFX_LSCPDLG_H__AB2589B3_C283_494E_8502_66E78666544B__INCLUDED_)
#define AFX_LSCPDLG_H__AB2589B3_C283_494E_8502_66E78666544B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "cdxCDynamicDialog.h"
#include "HistoryCombo.h"


/////////////////////////////////////////////////////////////////////////////
// ClscpDlg dialog

class ClscpDlg : public cdxCDynamicDialog
{
// Construction
public:
  void LoadFile(const char *,const char *);
  void OnLoadFile(void);
  FILE *m_FileLoading;
  bool m_bFileLoaded;
	void PopCustomVars();
	void PopHotkeys();
	CString createDirectory(CString wsPath);
	CString szThemestep;
	CString szMainstep;
	void AboutLSCPHelp();
	void PopEvars();
	bool CheckLSRunning();
	void ExecBangUp();
	BOOL m_bOTSswitch;
	void AboutThemeCustom();
	bool Copy (CString const &str);
	void ExecBang();
	BOOL m_bComboFocus;
	BOOL m_bDeleteRegEntriesOnClear;
//	void AboutShortcut();
//	void AboutPopup();
//	void AboutDesktop();
//	void AboutCore();
	void AboutTheme();
	void AboutBangs();
	void AboutRevision();
	void AboutModules();
	void OnOK();
	void AboutLog();
	HBRUSH OnCtlColor(CDC *pDC, CWnd *pWnd, UINT nCtlColor);
	void AboutConfig();
	void PopTree2();
	void AboutChanges();
	CString FindLS();
	ClscpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(ClscpDlg)
	enum { IDD = IDD_LSCP_DIALOG };
	CEdit	m_wndReference;
	CListBox	m_wndList4;
	CListBox	m_wndList3;
	CEdit	m_wndParams;
	CButton	m_wndOts;
	CButton	m_wndCustom;
	CHistoryCombo	m_comboHistory;
	CEdit	m_wndEdit;
	CButton	m_wndCheck;
	CTreeCtrl	m_tree;
	CListBox	m_wndList2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(ClscpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CFont m_font;
	CBrush m_bWhite;
	CPoint m_ptMsg;


	// Generated message map functions
	//{{AFX_MSG(ClscpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClose();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnCheck1();
	afx_msg void OnDblclkList2();
	afx_msg void OnClearhistory();
	afx_msg void OnSetfocusCombo1();
	afx_msg void OnKillfocusCombo1();
	afx_msg void OnQuit();
	afx_msg void OnDummyDefaulteditor();
	afx_msg void OnDummyNotepad();
	afx_msg void OnBangsExec();
	afx_msg void OnBangsCopytoclipboard();
	afx_msg void OnBangsCopytocommandline();
	afx_msg void OnModulesCopypathtoclipboard();
	afx_msg void OnModulesReloadmodule();
	afx_msg void OnModulesUnloadmodule();
	afx_msg void OnRecycle();
	afx_msg void OnRestart();
	afx_msg void OnOts();
	afx_msg void OnCustom();
	afx_msg void OnDblclkList3();
	afx_msg void OnSwitchSwitchtheme();
	afx_msg void OnSwitchShowthemeinformation();
	afx_msg void OnSelchangeList4();
	afx_msg void OnVarsCopytoclipboard();
	afx_msg void OnVarsCopyvariabletocommandline();
	afx_msg void OnConfig();
	afx_msg void OnSwitch();
	afx_msg void OnVarsCopytoclipboard2();
	afx_msg void OnVarsCopyvariabletocommandline2();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCopyToClipboard();
	afx_msg void OnCopyToCommandLine();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LSCPDLG_H__AB2589B3_C283_494E_8502_66E78666544B__INCLUDED_)
