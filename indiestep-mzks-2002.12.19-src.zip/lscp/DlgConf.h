#if !defined(AFX_DLGCONF_H__9E49A8D3_4824_4B09_B623_E915FC317F1E__INCLUDED_)
#define AFX_DLGCONF_H__9E49A8D3_4824_4B09_B623_E915FC317F1E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgConf.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgConf dialog

class CDlgConf : public CDialog
{
// Construction
public:
	void OnOK();
	void Apply();
	CString szThemestep;
	CString szMainstep;
	CDlgConf(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgConf)
	enum { IDD = IDD_DIALOGCONF };
	CEdit	m_wndThemestep;
	CEdit	m_wndMainstep;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgConf)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgConf)
	virtual BOOL OnInitDialog();
	afx_msg void OnApply();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCONF_H__9E49A8D3_4824_4B09_B623_E915FC317F1E__INCLUDED_)
