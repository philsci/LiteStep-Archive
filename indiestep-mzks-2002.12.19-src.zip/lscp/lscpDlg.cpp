// lscpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "lscp.h"
#include "lscpDlg.h"
#include "DlgConf.h"
#include "..\lsapi\lsapi.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ClscpDlg dialog

ClscpDlg::ClscpDlg(CWnd* pParent /*=NULL*/)
	: cdxCDynamicDialog(ClscpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(ClscpDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
  m_FileLoading = NULL;
}

void ClscpDlg::DoDataExchange(CDataExchange* pDX)
{
	cdxCDynamicDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ClscpDlg)
	DDX_Control(pDX, IDC_EDIT2, m_wndReference);
	DDX_Control(pDX, IDC_LIST4, m_wndList4);
	DDX_Control(pDX, IDC_LIST3, m_wndList3);
	DDX_Control(pDX, IDC_EDIT1, m_wndParams);
	DDX_Control(pDX, IDC_OTS, m_wndOts);
	DDX_Control(pDX, IDC_CUSTOM, m_wndCustom);
	DDX_Control(pDX, IDC_COMBO1, m_comboHistory);
	DDX_Control(pDX, IDC_CHECK1, m_wndCheck);
	DDX_Control(pDX, IDC_TREE1, m_tree);
	DDX_Control(pDX, IDC_LIST2, m_wndList2);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(ClscpDlg, cdxCDynamicDialog)
	//{{AFX_MSG_MAP(ClscpDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
	ON_BN_CLICKED(IDCANCEL, OnClose)
	ON_WM_CONTEXTMENU()
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_LBN_DBLCLK(IDC_LIST2, OnDblclkList2)
	ON_BN_CLICKED(IDC_CLEARHISTORY, OnClearhistory)
	ON_CBN_SETFOCUS(IDC_COMBO1, OnSetfocusCombo1)
	ON_CBN_KILLFOCUS(IDC_COMBO1, OnKillfocusCombo1)
	ON_BN_CLICKED(IDC_QUIT, OnQuit)
	ON_COMMAND(ID_DUMMY_DEFAULTEDITOR, OnDummyDefaulteditor)
	ON_COMMAND(ID_DUMMY_NOTEPAD, OnDummyNotepad)
	ON_COMMAND(ID_BANGS_EXEC, OnBangsExec)
	ON_COMMAND(ID_BANGS_COPYTOCLIPBOARD, OnBangsCopytoclipboard)
	ON_COMMAND(ID_BANGS_COPYTOCOMMANDLINE, OnBangsCopytocommandline)
	ON_COMMAND(ID_MODULES_COPYPATHTOCLIPBOARD, OnModulesCopypathtoclipboard)
	ON_COMMAND(ID_MODULES_RELOADMODULE, OnModulesReloadmodule)
	ON_COMMAND(ID_MODULES_UNLOADMODULE, OnModulesUnloadmodule)
	ON_BN_CLICKED(IDC_RECYCLE, OnRecycle)
	ON_BN_CLICKED(IDC_RESTART, OnRestart)
	ON_BN_CLICKED(IDC_OTS, OnOts)
	ON_BN_CLICKED(IDC_CUSTOM, OnCustom)
	ON_LBN_DBLCLK(IDC_LIST3, OnDblclkList3)
	ON_COMMAND(ID_SWITCH_SWITCHTHEME, OnSwitchSwitchtheme)
	ON_COMMAND(ID_SWITCH_SHOWTHEMEINFORMATION, OnSwitchShowthemeinformation)
	ON_LBN_SELCHANGE(IDC_LIST4, OnSelchangeList4)
	ON_COMMAND(ID_VARS_COPYTOCLIPBOARD, OnVarsCopytoclipboard)
	ON_COMMAND(ID_VARS_COPYVARIABLETOCOMMANDLINE, OnVarsCopyvariabletocommandline)
	ON_BN_CLICKED(IDC_CONFIG, OnConfig)
	ON_BN_CLICKED(IDC_SWITCH, OnSwitch)
	ON_COMMAND(ID_VARS_COPYTOCLIPBOARD2, OnVarsCopytoclipboard2)
	ON_COMMAND(ID_VARS_COPYVARIABLETOCOMMANDLINE2, OnVarsCopyvariabletocommandline2)
	ON_WM_TIMER()
	ON_WM_CTLCOLOR()
	ON_COMMAND(ID_COPYTOCLIPBOARD, OnCopyToClipboard)
	ON_COMMAND(ID_COPYTOCOMMANDLINE, OnCopyToCommandLine)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// ClscpDlg message handlers

BOOL ClscpDlg::OnInitDialog()
{
	cdxCDynamicDialog::OnInitDialog();


//	CString lsdir = FindLS();
//	CString tmpdir = "\\temp";
//	CString createtmp = lsdir + tmpdir;
//	createDirectory(createtmp);
//
//	WaitForSingleObject(NULL, 5000);

	if (CheckLSRunning() == false)
	{
	
		{

			AfxMessageBox("LiteStep is not running: Litestep Control Panel can't be loaded.\nPlease start LiteStep before starting Lscp.");
			//A previous instance of LiteStep was detected.\nAre you sure you want to continue?
		}

		OnClose();

		return FALSE;

	}
	else
	{

	{
	//add here: load lscp.dll - and unload it in OnClose
	CString szSelection = "!reloadmodule";
	//LS path
	CString szLsPath = FindLS() + "litestep.exe";
	CString parameter = "lscp.dll";
	CString bangparam = szSelection + " " + parameter;

	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(szLsPath), (bangparam), NULL, SW_SHOWNORMAL);
	}


	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	//font and size
	m_font.CreateFont(24,0,0,0,100,FALSE,FALSE,
	0,ANSI_CHARSET,OUT_DEFAULT_PRECIS,
	CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
	FF_SWISS,"Verdana"); 	
	
	CEdit * pEdit;
	pEdit = (CEdit *)GetDlgItem(IDC_PTITLE);
	pEdit->SetFont(&m_font,FALSE);
	//white brush
	//m_bWhite.CreateSolidBrush( RGB(255,255,255) );	
	m_bWhite.CreateSolidBrush( GetSysColor(COLOR_WINDOW) );

	// TODO: Add extra initialization here
	PopTree2();

	m_ptMsg = CPoint(0,0);

	AddSzControl(IDC_PTITLE, mdResize, mdNone );
	AddSzControl(IDC_PLOGO, mdRepos, mdNone);
	AddSzControl(IDC_TREE1, mdNone, mdResize);
	AddSzControl(IDC_LIST2, mdResize, mdResize);
	AddSzControl(IDC_LIST3, mdResize, mdResize);
	AddSzControl(IDC_EDIT1, mdResize, mdRepos);
	AddSzControl(IDC_SEP, mdResize, mdRepos);
	AddSzControl(IDC_SEP2, mdResize, mdRepos);
	AddSzControl(IDC_SEP3, mdResize, mdNone);
	AddSzControl(IDC_LABELEX, mdNone, mdRepos);
	AddSzControl(IDC_COMBO1,mdResize, mdRepos);
//	AddSzControl(IDC_CLOSE, mdRepos, mdRepos);
	AddSzControl(IDC_PARAM, mdNone, mdRepos);
	AddSzControl(IDC_CHECK1,mdNone,mdRepos);
	AddSzControl(IDC_OTS,mdNone,mdRepos);
	AddSzControl(IDC_CUSTOM,mdNone,mdRepos);
	AddSzControl(IDCANCEL,mdRepos,mdRepos);
	AddSzControl(IDC_CLEARHISTORY,mdRepos,mdRepos);
	AddSzControl(IDC_RECYCLE,mdNone,mdRepos);
	AddSzControl(IDC_QUIT,mdNone,mdRepos);
	AddSzControl(IDC_RESTART,mdNone,mdRepos);
	AddSzControl(IDC_LIST4,mdResize,mdResize);
	AddSzControl(IDC_EDIT2,mdResize,mdRepos);
	AddSzControl(IDC_CONFIG, mdRepos, mdRepos);
	AddSzControl(IDC_SWITCH, mdRepos, mdRepos);



	m_comboHistory.LoadHistory("Settings", "HistoryCombo");
	m_bComboFocus = false;
	m_bOTSswitch = true;

	//hide extra-controls
	GetDlgItem(IDC_OTS)->ShowWindow(false);
	GetDlgItem(IDC_CUSTOM)->ShowWindow(false);
	GetDlgItem(IDC_EDIT1)->ShowWindow(false);
	GetDlgItem(IDC_PARAM)->ShowWindow(false);
	GetDlgItem(IDC_LIST3)->ShowWindow(false);
	GetDlgItem(IDC_LIST4)->ShowWindow(false);
	GetDlgItem(IDC_EDIT2)->ShowWindow(false);
	GetDlgItem(IDC_CONFIG)->ShowWindow(false);
	GetDlgItem(IDC_SWITCH)->ShowWindow(false);

	//default: ots-custom
	m_wndOts.SetCheck(1);
	
	//update the text files
	ExecBang();

	m_tree.SetFocus();

	return TRUE;  // return TRUE  unless you set the focus to a control
}
}
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void ClscpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR ClscpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//use the white brush
HBRUSH ClscpDlg::OnCtlColor(CDC *pDC, CWnd *pWnd, UINT nCtlColor)
{

	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	//control ID	
  switch (pWnd->GetDlgCtrlID())
  {
  case IDC_EDIT2:
  case IDC_PTITLE:
		pDC->SetBkColor(GetSysColor(COLOR_WINDOW));		
		return (HBRUSH)m_bWhite.GetSafeHandle();	
  default:
	  return hbr;
  }
}

//FindLS -> get the Litestep Path 
CString ClscpDlg::FindLS()
{
	char LSpath[MAX_PATH];
	LSGetLitestepPath(LSpath, MAX_PATH);
	return LSpath;
}

//copy to clipboard
bool ClscpDlg::Copy(const CString &str)
{

	HGLOBAL glob;

	unsigned length = str.GetLength() + 1;

	glob = GlobalAlloc(GMEM_DDESHARE, length);
	if ( NULL == glob)
		return false;

	memcpy(glob, (LPCSTR)str, length);
	
	if ( !( OpenClipboard() && 
               EmptyClipboard() && 
               SetClipboardData(CF_TEXT, glob)))
	{
		CloseClipboard();
		GlobalFree(glob);
		return false;
	}
	CloseClipboard();
	return true;
}

//on top
void ClscpDlg::OnCheck1() 
{
	if (m_wndCheck.GetCheck())
	{
	//ONTOP
	SetWindowPos(&this->wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);	
	}
	else 
	{
	SetWindowPos(&this->wndNoTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);	
	}
}


//save command line history
void ClscpDlg::OnClose() 
{
  LoadFile(NULL,NULL);

	if (CheckLSRunning() == true)
	//add here unload of lscp.dll
	{
//			AfxMessageBox("Running");

	CString szSelection = "!unloadmodule";
	//LS path
	CString szLsPath = FindLS() + "litestep.exe";
	CString parameter = "lscp.dll";
	CString bangparam = szSelection + " " + parameter;

	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(szLsPath), (bangparam), NULL, SW_SHOWNORMAL);
	}
	else
	{
//			AfxMessageBox("Not Running");

	}

	m_comboHistory.SaveHistory();

	OnCancel();
}

//clear command line history
void ClscpDlg::OnClearhistory() 
{
	UpdateData(TRUE);
	m_comboHistory.ClearHistory(m_bDeleteRegEntriesOnClear);	
}

//command line get focus
void ClscpDlg::OnSetfocusCombo1() 
{
	m_bComboFocus = true;
}

//command line loose focus
void ClscpDlg::OnKillfocusCombo1() 
{
	m_bComboFocus = false;
}

//update the text files
void ClscpDlg::ExecBang()
{

	char pathtot[MAX_PATH];
	LSGetLitestepPath(pathtot, MAX_PATH);
	strcat(pathtot,"litestep.exe");

	CString sCommand1 = "!writebangs";
	CString sCommand2 = "!writercfiles";
	CString sCommand3 = "!writerevids";
	CString sCommand4 = "!writemods";
	CString sCommand5 = "!writeevars";
	CString sCommand6 = "!writehotkeys";


	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand1), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst2 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand2), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst3 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand3), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst4 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand4), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst5 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand5), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst6 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand6), NULL, SW_SHOWNORMAL);

}

//update bangs
void ClscpDlg::ExecBangUp()
{

	char pathtot[MAX_PATH];
	LSGetLitestepPath(pathtot, MAX_PATH);
	strcat(pathtot,"litestep.exe");

	CString sCommand1 = "!writebangs";
	CString sCommand4 = "!writemods";
	CString sCommand5 = "!writeevars";
	CString sCommand6 = "!writehotkeys";


	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand1), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst4 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand4), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst5 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand5), NULL, SW_SHOWNORMAL);
	HINSTANCE hinst6 = ::ShellExecute(m_hWnd, _T("open"), 
		(pathtot), (sCommand6), NULL, SW_SHOWNORMAL);

}

//command line
void ClscpDlg::OnOK()
{
	//only if the command line is selected
	if (m_bComboFocus)
	{
		CString sItem;
		m_comboHistory.GetWindowText(sItem);
		m_comboHistory.AddString(sItem);
		m_comboHistory.SaveHistory();

		//LS path
		CString sLSPath = FindLS() + "litestep.exe";

		// Get the string from the EDIT control
		CString sCommand;
		m_comboHistory.GetWindowText(sCommand);

		// Parse out the Command
		int nCmdLen = sCommand.Find(__TEXT(' '));
		//Check the first character
		CString sCheck;
			sCheck = sCommand[0];
		
		if (nCmdLen == -1) {
			nCmdLen = sCommand.GetLength();
		}
		//It is not a !bang
		if (sCheck != "!")
			{
			// Parse out the parameters to pass to the Command
			CString sParams = sCommand.Mid(nCmdLen);
			sParams.TrimLeft();  // Remove extra white space

			// Have the Shell run our command with its parameters
			HINSTANCE hinst = ::ShellExecute(m_hWnd, NULL, 
			  sCommand.Left(nCmdLen), sParams, NULL, SW_SHOWNORMAL);
   
			if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
				{
				// If the command failed to run, tell the user.
				MessageBox(__TEXT("Unable to execute command"), 
				 _T("Litestep Control Panel"), MB_ICONSTOP | MB_OK);
				}
			}
		
		//It is a !bang
		if (sCheck == "!")
			{
		
			HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
				(sLSPath), (sCommand), NULL, SW_SHOWNORMAL);
			}

	}
}

//option list in tree
void ClscpDlg::PopTree2()
{

	HTREEITEM uno = m_tree.InsertItem("Information");

		m_tree.InsertItem("Configuration Files", uno);
		m_tree.InsertItem("Changes", uno);
		m_tree.InsertItem("Log File", uno);

	uno = m_tree.InsertItem("Modules");

		m_tree.InsertItem("Loaded Modules", uno);
		m_tree.InsertItem("Revision IDs", uno);

	uno = m_tree.InsertItem("Bang Commands");

	uno = m_tree.InsertItem("Hotkeys");
	
	uno = m_tree.InsertItem("Environment variables");
		m_tree.InsertItem("Built-in", uno);
		m_tree.InsertItem("Custom", uno);

	uno = m_tree.InsertItem("Theme Switcher");

//	uno = m_tree.InsertItem("Litestep Configuration");

	uno = m_tree.InsertItem("Help");

		m_tree.InsertItem("LS Docs", uno);
		m_tree.InsertItem("LS Modules", uno);
		m_tree.InsertItem("LS FAQ", uno);
		m_tree.InsertItem("LS Sdk", uno);
		m_tree.InsertItem("LSCP Help", uno);

		
//	uno = m_tree.InsertItem("Help");
//
//	m_tree.InsertItem("Core", uno);
//	m_tree.InsertItem("Desktop2.dll", uno);
//	m_tree.InsertItem("Popup2.dll", uno);
//	m_tree.InsertItem("Shortcut2.dll", uno);
}


//change tree selection
void ClscpDlg::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

  /* stop anything that's loading */ 
  LoadFile(NULL,NULL);

	//update text files
	ExecBangUp();

	CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());

	if (szTreeSel == "Information")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		m_wndList2.AddString("LiteStep 0.24.6 Control Panel");
		m_wndList2.AddString("Requires indie build after 05-22-2002");
	}
	else if (szTreeSel == "Modules")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		m_wndList2.AddString("LiteStep 0.24.6 Control Panel");
		m_wndList2.AddString("Requires indie build after 05-22-2002");
	}
//	else if (szTreeSel == "Help")
//	{
//		m_wndList2.ResetContent();
//		m_wndList2.SetHorizontalExtent(0);
//		m_wndList2.AddString("LiteStep 0.24.6 Control Panel");
//		m_wndList2.AddString("Requires indie build after 05-22-2002");
//	}
	else if (szTreeSel == "Changes")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(500);
		AboutChanges();
	}
	else if (szTreeSel == "Log File")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(500);
		AboutLog();
	}
	else if (szTreeSel == "Configuration Files")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		AboutConfig();
	}
	else if (szTreeSel == "Loaded Modules")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		AboutModules();
	}
	else if (szTreeSel == "Revision IDs")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		AboutRevision();
	}
	else if (szTreeSel == "Bang Commands")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		GetDlgItem(IDC_EDIT1)->ShowWindow(true);
		GetDlgItem(IDC_PARAM)->ShowWindow(true);
		AboutBangs();
	}
	else if (szTreeSel == "Theme Switcher")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		GetDlgItem(IDC_OTS)->ShowWindow(true);
		GetDlgItem(IDC_CUSTOM)->ShowWindow(true);
		GetDlgItem(IDC_CONFIG)->ShowWindow(true);
		GetDlgItem(IDC_CONFIG)->EnableWindow(false);
		GetDlgItem(IDC_SWITCH)->ShowWindow(true);
		GetDlgItem(IDC_LIST2)->ShowWindow(false);
		GetDlgItem(IDC_LIST3)->ShowWindow(true);
		AboutTheme();
	}
	else if (szTreeSel == "Help")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		m_wndList2.AddString("LiteStep 0.24.6 Control Panel");
		m_wndList2.AddString("Requires indie build after 05-22-2002");
	}
	else if (szTreeSel == "LS Docs")
	{
		m_wndList2.ResetContent();
	
		CString szOpen = FindLS() + "help\\LSDocs.chm";

//		AfxMessageBox(szOpen);
		
		HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
			szOpen, NULL, NULL, SW_SHOWNORMAL);

		if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
		{
			m_wndList2.AddString("LSDocs.chm unavailable");
			CString szOpen2 = "Expected location: " + szOpen;
			m_wndList2.AddString(szOpen2);

		}

	}
	else if (szTreeSel == "LS Modules")
	{
		m_wndList2.ResetContent();

		CString szOpen = FindLS() + "help\\LSMods.chm";

//		AfxMessageBox(szOpen);
		
		HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
			szOpen, NULL, NULL, SW_SHOWNORMAL);

		if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
		{
			m_wndList2.AddString("LSMods.chm unavailable");
			CString szOpen2 = "Expected location: " + szOpen;
			m_wndList2.AddString(szOpen2);

		}

	}
	else if (szTreeSel == "LS FAQ")
	{
		m_wndList2.ResetContent();

		CString szOpen = FindLS() + "help\\LSFaq.chm";

//		AfxMessageBox(szOpen);
		
		HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
			szOpen, NULL, NULL, SW_SHOWNORMAL);

		if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
		{
			m_wndList2.AddString("LSFaq.chm unavailable");
			CString szOpen2 = "Expected location: " + szOpen;
			m_wndList2.AddString(szOpen2);

		}

	}
	else if (szTreeSel == "LS Sdk")
	{
		m_wndList2.ResetContent();

		CString szOpen = FindLS() + "help\\LSsdk.chm";

//		AfxMessageBox(szOpen);
		
		HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
			szOpen, NULL, NULL, SW_SHOWNORMAL);

		if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
		{
			m_wndList2.AddString("LSsdk.chm unavailable");
			CString szOpen2 = "Expected location: " + szOpen;
			m_wndList2.AddString(szOpen2);

		}

	}
	else if (szTreeSel == "LSCP Help")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(500);
		AboutLSCPHelp();
	}
	else if (szTreeSel == "Environment variables")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
		m_wndList2.AddString("LiteStep 0.24.6 Control Panel");
		m_wndList2.AddString("Requires indie build after 05-22-2002");
	}
	else if (szTreeSel == "Built-in")
	{
		m_wndList4.ResetContent();
		m_wndList4.SetHorizontalExtent(0);
		PopEvars();
		GetDlgItem(IDC_LIST2)->ShowWindow(false);
		GetDlgItem(IDC_LIST3)->ShowWindow(false);
		GetDlgItem(IDC_LIST4)->ShowWindow(true);
		GetDlgItem(IDC_EDIT2)->ShowWindow(true);

	}
	else if (szTreeSel == "Custom")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
//		m_wndList2.AddString("Not ready yet");
		PopCustomVars();
	}
	else if (szTreeSel == "Hotkeys")
	{
		m_wndList2.ResetContent();
		m_wndList2.SetHorizontalExtent(0);
//		m_wndList2.AddString("Not ready yet");
		PopHotkeys();
	}
//	maybe later...
//	else if (szTreeSel == "Litestep Configuration")
//	{
//		m_wndList2.ResetContent();
//
//		CString szOpen = FindLS() + "lsconf.exe";
//
////		AfxMessageBox(szOpen);
//		
//		HINSTANCE hinst = ::ShellExecute(m_hWnd, _T("open"), 
//			szOpen, NULL, NULL, SW_SHOWNORMAL);
//
//		if (hinst < (HINSTANCE) HINSTANCE_ERROR) 
//		{
//			m_wndList2.AddString("LSConf.exe unavailable");
//			CString szOpen2 = "Expected location: " + szOpen;
//			m_wndList2.AddString(szOpen2);
//
//		}
//
//	}


	
//	else if (szTreeSel == "Core")
//	{
//		m_wndList2.ResetContent();
//		m_wndList2.SetHorizontalExtent(500);
//		AboutCore();
//	}
//	else if (szTreeSel == "Desktop2.dll")
//	{
//		m_wndList2.ResetContent();
//		m_wndList2.SetHorizontalExtent(500);
//		AboutDesktop();
//	}
//	else if (szTreeSel == "Popup2.dll")
//	{
//		m_wndList2.ResetContent();
//		m_wndList2.SetHorizontalExtent(500);
//		AboutPopup();
//	}
//	else if (szTreeSel == "Shortcut2.dll")
//	{
//		m_wndList2.ResetContent();
//		m_wndList2.SetHorizontalExtent(500);
//		AboutShortcut();
//	}

	//hide buttons
	if (szTreeSel != "Theme Switcher")
	{
		GetDlgItem(IDC_OTS)->ShowWindow(false);
		GetDlgItem(IDC_CUSTOM)->ShowWindow(false);
		GetDlgItem(IDC_LIST3)->ShowWindow(false);
		//GetDlgItem(IDC_LIST2)->ShowWindow(true);
		GetDlgItem(IDC_CONFIG)->ShowWindow(false);
		GetDlgItem(IDC_SWITCH)->ShowWindow(false);

	}
	if (szTreeSel != "Bang Commands")
	{
		GetDlgItem(IDC_EDIT1)->ShowWindow(false);
		GetDlgItem(IDC_PARAM)->ShowWindow(false);
	}
	if (szTreeSel != "Built-in")
	{
		GetDlgItem(IDC_LIST4)->ShowWindow(false);
		GetDlgItem(IDC_EDIT2)->ShowWindow(false);
		
		if (szTreeSel != "Theme Switcher")
			GetDlgItem(IDC_LIST2)->ShowWindow(true);
	}

	*pResult = 0;
}

/////////////////////////////
//fill the listbox with info
//changes.txt
void ClscpDlg::AboutChanges()
{
	CString szChangesTxtPath = FindLS() + "changes.txt";
  LoadFile(szChangesTxtPath,"Changes.txt");
}	

/////////////////////////////////////////////
//aboutlog - ok with hardcoded litestep.log//
/////////////////////////////////////////////
void ClscpDlg::AboutLog()
{
	CString szLogFile = FindLS() + "litestep.log";
  LoadFile(szLogFile,"Log File");
}

//configuration files
void ClscpDlg::AboutConfig()
{
	CString szConfigTxtPath = FindLS() + "lscprcfiles.txt";
  LoadFile(szConfigTxtPath,"lscprcfiles.txt");
}

//modules
void ClscpDlg::AboutModules()
{
	CString szModulesTxtPath = FindLS() + "lscpmods.txt";
  LoadFile(szModulesTxtPath,"lscpmods.txt");
}

//revision ids
void ClscpDlg::AboutRevision()
{
	CString szRevidsTxtPath = FindLS() + "lscprevids.txt";
  LoadFile(szRevidsTxtPath,"lscprevids.txt");
}

//bangs
void ClscpDlg::AboutBangs()
{
	CString szBangsTxtPath = FindLS() + "lscpbangs.txt";
  LoadFile(szBangsTxtPath,"lscpbangs.txt");
}

void ClscpDlg::AboutLSCPHelp()
{
	CString szLscpHelpTxtPath = FindLS() + "help\\lscphelp.txt";
  LoadFile(szLscpHelpTxtPath,"LscpHelp.txt");
}

#define TIMER_LOADFILE 504

void ClscpDlg::LoadFile(const char *path, const char *description)
{
  if (m_FileLoading) fclose(m_FileLoading);

  /* stop loading any current file */ 
  if (path==NULL)
  {
    m_FileLoading = NULL;
    m_bFileLoaded = false;
    return;
  }

  /* start loading the file */ 
	m_FileLoading = fopen(path, "r");

  if (!m_FileLoading)
	{
    char buf[1024];
    LPSTR values[1];
    
    values[0] = const_cast<LPSTR>(description);
    FormatMessage(
      FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ARGUMENT_ARRAY,
      "%1 unavailable.",
      NULL,NULL,buf,1024,values);
		m_wndList2.AddString(buf);

    values[0] = const_cast<LPSTR>(path);
    FormatMessage(
      FORMAT_MESSAGE_FROM_STRING|FORMAT_MESSAGE_ARGUMENT_ARRAY,
      "Expected location: %1",
      NULL,NULL,buf,1024,values);
		m_wndList2.AddString(buf);

    m_bFileLoaded = false;
    return;
	}

  /* post the message so we don't hold up the ui    */ 
  /* timers sink to the bottom of the message queue */ 
  SetTimer(TIMER_LOADFILE,0,NULL);
}

void ClscpDlg::OnLoadFile(void)
{
  KillTimer(TIMER_LOADFILE);

  /* stop if there's nothing to load */ 
  if (m_FileLoading==NULL) return;
  if (feof(m_FileLoading))
  {
    fclose(m_FileLoading);
    m_FileLoading = NULL;
    return;
  }

	static char szTempBuffer[MAX_LINE_LENGTH];

  /* do 10 lines at a time */ 
  int i=10;
  while (i--)
  {
    /* read the next line */ 
	  if (!fgets (szTempBuffer, MAX_LINE_LENGTH, m_FileLoading))
	  {
      fclose(m_FileLoading);
      m_FileLoading = NULL;
      return;
    }

    /* fgets preserves the ending newline, remove it */ 
    if (*szTempBuffer)
      szTempBuffer[strlen(szTempBuffer)-1] = 0;

    /* add it to the control */ 
    m_wndList2.AddString(szTempBuffer);
  }

  m_bFileLoaded = true;

  /* post the message again */ 
  SetTimer(TIMER_LOADFILE,0,NULL);
}


void ClscpDlg::OnTimer(UINT nIDEvent) 
{
  if (nIDEvent==TIMER_LOADFILE) OnLoadFile();
	cdxCDynamicDialog::OnTimer(nIDEvent);
}

//theme switch
void ClscpDlg::AboutTheme()
{

	m_wndList3.ResetContent();
	//search projects directory and list projects
	HANDLE hFind;
	WIN32_FIND_DATA dataFind;
	BOOL bMoreFiles = TRUE;

	//set directory for projects
	//LS path
	CString path = FindLS() + "themes\\*.*";
	
	//find first file in the directory
//	hFind = FindFirstFile(path + "\\*.*", &dataFind);
	hFind = FindFirstFile(path, &dataFind);

	while(hFind != INVALID_HANDLE_VALUE && bMoreFiles == TRUE){
	//if(dataFind.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY || /*dataFind.dwFileAttributes ==*/ FILE_ATTRIBUTE_ARCHIVE  ){
	if(dataFind.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY || ( dataFind.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY && dataFind.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE ) ){
	if(strcmp(dataFind.cFileName, "."))
	if(strcmp(dataFind.cFileName, ".."))
	m_wndList3.AddString(dataFind.cFileName);
	}
	bMoreFiles = FindNextFile(hFind, &dataFind);
	}
	FindClose(hFind);

}

///////////////////////////
////help files
//void ClscpDlg::AboutCore()
//{
//	//LS path
//	CString szCoreTxtPath = FindLS() + "help\\core.txt";
//
//	FILE *f;
//
//	f = fopen (szCoreTxtPath, "r");
//
//	if (f)
//	{
//		fseek (f, 0, SEEK_SET);
//
//		char szTempBuffer[MAX_LINE_LENGTH];
//		int i = 0;
//		int j = 0;
//
//		while (f && !feof (f))
//		{
//
//			if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
//				break;
//
//			j = 0;
//			while (szTempBuffer[j] != 0)
//			j++;
//			szTempBuffer[j - 1] = 0;
//
//			m_wndList2.AddString(szTempBuffer);
//
//		}
//
//		fclose(f);
//
//	}
//	else
//	{
//		m_wndList2.AddString("core.txt unavailable");
//		char expectedloc[MAX_PATH] = "Expected location: ";
//		strcat(expectedloc, szCoreTxtPath);
//		m_wndList2.AddString(expectedloc);
//	}
//}
//
//
//void ClscpDlg::AboutDesktop()
//{
//	//LS path
//	CString szDesktopTxtPath = FindLS() + "help\\desktop2.txt";
//
//	FILE *f;
//
//	f = fopen (szDesktopTxtPath, "r");
//
//	if (f)
//	{
//		fseek (f, 0, SEEK_SET);
//
//		char szTempBuffer[MAX_LINE_LENGTH];
//		int i = 0;
//		int j = 0;
//
//		while (f && !feof (f))
//		{
//
//			if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
//				break;
//
//			j = 0;
//			while (szTempBuffer[j] != 0)
//			j++;
//			szTempBuffer[j - 1] = 0;
//
//			m_wndList2.AddString(szTempBuffer);
//
//		}
//
//		fclose(f);
//
//	}
//	else
//	{
//		m_wndList2.AddString("desktop2.txt unavailable");
//		char expectedloc[MAX_PATH] = "Expected location: ";
//		strcat(expectedloc, szDesktopTxtPath);
//		m_wndList2.AddString(expectedloc);
//	}
//
//}
//
//
//void ClscpDlg::AboutPopup()
//{
//	//LS path
//	CString szPopupTxtPath = FindLS() + "help\\popup2.txt";
//
//	FILE *f;
//
//	f = fopen (szPopupTxtPath, "r");
//
//	if (f)
//	{
//		fseek (f, 0, SEEK_SET);
//
//		char szTempBuffer[MAX_LINE_LENGTH];
//		int i = 0;
//		int j = 0;
//
//		while (f && !feof (f))
//		{
//
//			if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
//				break;
//
//			j = 0;
//			while (szTempBuffer[j] != 0)
//			j++;
//			szTempBuffer[j - 1] = 0;
//
//			m_wndList2.AddString(szTempBuffer);
//
//		}
//
//		fclose(f);
//
//	}
//	else
//	{
//		m_wndList2.AddString("popup2.txt unavailable");
//		char expectedloc[MAX_PATH] = "Expected location: ";
//		strcat(expectedloc, szPopupTxtPath);
//		m_wndList2.AddString(expectedloc);
//	}
//}
//
//
//void ClscpDlg::AboutShortcut()
//{
//	//LS path
//	CString szShortcutTxtPath = FindLS() + "help\\shortcut2.txt";
//
//	FILE *f;
//
//	f = fopen (szShortcutTxtPath, "r");
//
//	if (f)
//	{
//		fseek (f, 0, SEEK_SET);
//
//		char szTempBuffer[MAX_LINE_LENGTH];
//		int i = 0;
//		int j = 0;
//
//		while (f && !feof (f))
//		{
//
//			if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
//				break;
//
//			j = 0;
//			while (szTempBuffer[j] != 0)
//			j++;
//			szTempBuffer[j - 1] = 0;
//
//			m_wndList2.AddString(szTempBuffer);
//
//		}
//
//		fclose(f);
//
//	}
//	else
//	{
//		m_wndList2.AddString("shortcut2.txt unavailable");
//		char expectedloc[MAX_PATH] = "Expected location: ";
//		strcat(expectedloc, szShortcutTxtPath);
//		m_wndList2.AddString(expectedloc);
//	}
//}


//////////////////////
//right-click commands
void ClscpDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	CMenu *pMenu=new CMenu();
	CMenu *pSubMenu;
  CRect area;

  if (m_wndList2.IsWindowVisible())
  {
    if (m_bFileLoaded)
    {
      m_wndList2.GetClientRect(&area);
      BOOL bOutside;
      CPoint cpt = point;
      m_wndList2.ScreenToClient(&cpt);
      if (!area.PtInRect(cpt)) return;
      int item = m_wndList2.ItemFromPoint(cpt,bOutside);

      /* make sure item under cursor is selected */ 
      if (m_wndList2.GetSel(item)<=0)
      {
        if (item==-1 || bOutside)
        {
          m_wndList2.SelItemRange(TRUE,0,m_wndList2.GetCount());
        }
        else
        {
          m_wndList2.SelItemRange(FALSE,0,m_wndList2.GetCount());
          m_wndList2.SetSel(item);
        }
      }
	    CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());

      int nSel = m_wndList2.GetSelCount();

	    if (szTreeSel == "Configuration Files")
	    {
		    pMenu->LoadMenu(IDR_MENU1);	
		    pSubMenu = pMenu->GetSubMenu(0);
        if (nSel!=1) pSubMenu->EnableMenuItem(ID_COPYTOCOMMANDLINE,MF_GRAYED|MF_BYCOMMAND);
		    pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		    pMenu->DestroyMenu();
	    }
	    else if (szTreeSel == "Bang Commands")
	    {
		    pMenu->LoadMenu(IDR_MENU1);	
		    pSubMenu = pMenu->GetSubMenu(1);	
        if (nSel!=1) pSubMenu->EnableMenuItem(ID_BANGS_COPYTOCOMMANDLINE,MF_GRAYED|MF_BYCOMMAND);
		    pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		    pMenu->DestroyMenu();
	    }
	    else if ((szTreeSel == "Changes")
            || (szTreeSel == "Revision IDs")
            || (szTreeSel == "Information")
	          || (szTreeSel == "Log File")
            || (szTreeSel == "Custom")
            || (szTreeSel == "Hotkeys"))
	    {
		    pMenu->LoadMenu(IDR_MENU1);	
		    pSubMenu = pMenu->GetSubMenu(2);	
        if (nSel!=1) pSubMenu->EnableMenuItem(ID_COPYTOCOMMANDLINE,MF_GRAYED|MF_BYCOMMAND);
		    pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		    pMenu->DestroyMenu();
      }
	    //else if (szTreeSel == "Modules")
	    //{}
    //	else if (szTreeSel == "Help")
    //	{}
	    else if (szTreeSel == "Loaded Modules")
	    {
		    pMenu->LoadMenu(IDR_MENU1);	
		    pSubMenu = pMenu->GetSubMenu(3);	
        if (nSel!=1) pSubMenu->EnableMenuItem(ID_COPYTOCOMMANDLINE,MF_GRAYED|MF_BYCOMMAND);
		    pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		    pMenu->DestroyMenu();
	    }
    //	else //help files
    //	{
    //		pMenu->LoadMenu(IDR_MENU3);	
    //		pSubMenu = pMenu->GetSubMenu(0);	
    //		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
    //		pMenu->DestroyMenu();
    //	}
    }
  }
  else if (m_wndList3.IsWindowVisible())
  {
    m_wndList3.GetClientRect(&area);
    /* select item under cursor */ 
    BOOL bOutside;
    CPoint cpt = point;
    m_wndList3.ScreenToClient(&cpt);
    if (!area.PtInRect(cpt)) return;
    int item = m_wndList3.ItemFromPoint(cpt,bOutside);
    if (m_wndList3.GetCurSel()!=item)
    {
      m_wndList3.SetCurSel(item);
    }

    if (!bOutside && item!=-1)
    {
	    CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());

      if (szTreeSel == "Theme Switcher")
	    {
		    pMenu->LoadMenu(IDR_MENU1);	
		    pSubMenu = pMenu->GetSubMenu(4);	
		    pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		    pMenu->DestroyMenu();
	    }
    }
  }

//
//  I think I got all of these covered, but not sure.
/*
  CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());


	if (szTreeSel == "Configuration Files")
	{
		pMenu->LoadMenu(IDR_MENU1);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();
	}
	else if (szTreeSel == "Bang Commands")
	{
		pMenu->LoadMenu(IDR_MENU2);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();
	}
	else if (szTreeSel == "Theme Switcher")
	{
		pMenu->LoadMenu(IDR_MENU5);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();

	}
	else if (szTreeSel == "Changes")
	{}
	else if (szTreeSel == "Log File")
	{}
	else if (szTreeSel == "Revision IDs")
	{}
	else if (szTreeSel == "Information")
	{}
	else if (szTreeSel == "Modules")
	{}
	else if (szTreeSel == "LSCP Help")
	{}
	else if (szTreeSel == "Loaded Modules")
	{
		pMenu->LoadMenu(IDR_MENU4);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();
	}
	else if (szTreeSel == "Built-in")
	{
		pMenu->LoadMenu(IDR_MENU3);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();
	}
	else if (szTreeSel == "Custom"||"Hotkeys")
	{
		pMenu->LoadMenu(IDR_MENU6);	
		pSubMenu = pMenu->GetSubMenu(0);	
		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
		pMenu->DestroyMenu();
	}

//	else //help files
//	{
//		pMenu->LoadMenu(IDR_MENU3);	
//		pSubMenu = pMenu->GetSubMenu(0);	
//		pSubMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);	
//		pMenu->DestroyMenu();
//	}
*/
}

///////////////////////
//double click commands
void ClscpDlg::OnDblclkList2() 
{
	CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());

//		if (szTreeSel == "Theme Switcher")
//		{
//	
//			int nSelection = m_wndList2.GetCurSel();
//			if (nSelection !=LB_ERR)
//			{
//				if (m_bOTSswitch)
//				{
//					CString szSelection;
//					m_wndList2.GetText(nSelection, szSelection);
//					
//					CString uno = "rcStep \"step.rc\";\n";
//					CString due = "dirTheme \"$LitestepDir$themes\\";
//					CString dueb = "\\\";";
//					CString tre = "\ninclude \"$dirTheme$$rcStep$\";";
//					CString tot = uno + due + szSelection + dueb + tre;
//					
//					CString szMessage = "Selected theme: " + szSelection + "\nSwitch to the selected theme?";
//					int nChoice = AfxMessageBox(szMessage, MB_YESNO | MB_ICONQUESTION);
//					if (nChoice == IDYES)
//					{
//	
//					//LS path
//					CString szStepRc = FindLS() + "step.rc";
//
//					FILE* file = fopen(szStepRc, "wb");
//								
//						if(!file) //f does not exists
//						{	
//							AfxMessageBox("Can't find step.rc");
//						}
//						else
//						{
//							fwrite( tot, strlen(tot), 1, file);
//						}
//								
//						fclose(file);
//
//					//recycle LS
//					OnRecycle();
//
//					OnClose();
//					}
//				}
//				else
//				{
//					CString szSelection;
//					m_wndList2.GetText(nSelection, szSelection);
//					
//					CString uno = "rcStep \"step.rc\";\n";
//					CString due = "dirTheme \"";
//					CString dueb = "\\\";";
//					CString tre = "\ninclude \"$dirTheme$$rcStep$\";";
//					CString tot = uno + due + szSelection + dueb + tre;
//					
//					CString szMessage = "Selected theme: " + szSelection + "\nSwitch to the selected theme?";
//					int nChoice = AfxMessageBox(szMessage, MB_YESNO | MB_ICONQUESTION);
//					if (nChoice == IDYES)
//					{
//					//LS path
//					CString szStepRc = FindLS() + "step.rc";
//
//					FILE* file = fopen(szStepRc, "wb");
//								
//						if(!file) //f does not exists
//						{	
//							AfxMessageBox("Can't find step.rc");
//						}
//						else
//						{
//							fwrite( tot, strlen(tot), 1, file);
//						}
//								
//						fclose(file);
//
//					//recycle LS
//					OnRecycle();
//
//					OnClose();
//					}
//				}
//			}
//		}
		if (szTreeSel == "Configuration Files")
		{
			OnDummyDefaulteditor();
		}
		else if (szTreeSel == "Bang Commands")
		{
			OnBangsExec();
		}
		else 
		{}
}

//theme switching
void ClscpDlg::OnDblclkList3() 
{
	CString szTreeSel = m_tree.GetItemText(m_tree.GetSelectedItem());

		if (szTreeSel == "Theme Switcher")
		{
	
			int nSelection = m_wndList3.GetCurSel();
			if (nSelection !=LB_ERR)
			{
				CString tot;
				CString szSelection;
				CString duea;
				m_wndList3.GetText(nSelection, szSelection);

				if (m_bOTSswitch)
				{
					szMainstep = "step.rc";
					szThemestep = "step.rc";
					duea = "dirTheme \"$LitestepDir$themes\\";
				}
				else
				{
					//registro
					CString strSection       = "Config";
 					CString strStringItem1   = "MainStep";
 					CString strStringItem2	 = "ThemeStep";
					
					CWinApp* pApp = AfxGetApp();
  					
 					szMainstep = pApp->GetProfileString(strSection, strStringItem1, "Step.rc");
 					szThemestep = pApp->GetProfileString(strSection, strStringItem2, "Step.rc");	

					// custom ?
					duea = "dirTheme \"";
				}
				CString unoa = "rcStep \"";
				CString unob = "\";\r\n";
				CString uno = unoa + szThemestep + unob;
				
				// ots/custom duea string made in if/else
				CString dueb = "\\\";\r\n";
				CString due = duea + szSelection + dueb;

				CString tre = "include \"$dirTheme$$rcStep$\";";
				tot = uno + due + tre;
				//AfxMessageBox(tot);

				// common theme switch
				CString szMessage = "Selected theme: " + szSelection + "\nSwitch to the selected theme?";
				int nChoice = AfxMessageBox(szMessage, MB_YESNO | MB_ICONQUESTION);

				if (nChoice == IDYES)
				{
					CString szThemeRc = FindLS() + "themes\\" + szSelection + "\\" + szThemestep;
					FILE* thm_rc = fopen(szThemeRc, "r"); 

					if (thm_rc)
					{
						//LS path
						CString szStepRc = FindLS() + szMainstep;

						//AfxMessageBox(szStepRc);

						FILE* ls_rc = fopen(szStepRc, "wb");
									
						if (!ls_rc) //f does not exists
						{
							CString ErrorMsg = "Can't open main ls .rc file:\n" + szStepRc;
							AfxMessageBox(ErrorMsg);
						}
						else
						{
							fwrite( tot, strlen(tot), 1, ls_rc);
							fclose(ls_rc);
						}
						fclose(thm_rc);

						//recycle LS
						OnRecycle();

						OnClose();
					}
					else
					{
						// look for other .rc file and ask to load that instead?

						// do not load if no file found...
						CString ErrorMsg = "Couldn't find a .rc file in theme \"" + szSelection + "\"";
						ErrorMsg = ErrorMsg + "\nLooked for file: " + szThemeRc;
						AfxMessageBox(ErrorMsg);
					}
				}
			}

			//prova
			else
				
				//AfxMessageBox("Please select a theme");
				MessageBox(__TEXT("Please select a theme"), 
				 _T("Litestep Control Panel"), MB_ICONWARNING | MB_OK);

		}
	
}

//right click - rcfiles
void ClscpDlg::OnDummyDefaulteditor() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);

		HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
			szSelection, NULL, NULL, SW_SHOWNORMAL);
	}
	
}

void ClscpDlg::OnDummyNotepad() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);

		HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
			"notepad", szSelection, NULL, SW_SHOWNORMAL);
	}
	
}

//right click - bangs
void ClscpDlg::OnBangsExec() 
{
  int nSel = m_wndList2.GetSelCount();
	if (nSel)
	{
    /* get list of selected items */ 
    int *pItems = new int[nSel];
    m_wndList2.GetSelItems(nSel,pItems);
		CString szItem;
		CString parameter;
    int iSel;
		//LS path
		CString szLsPath = FindLS() + "litestep.exe";
		m_wndParams.GetWindowText(parameter);
    for (iSel=0;iSel<nSel;++iSel)
    {
		  m_wndList2.GetText(pItems[iSel], szItem);
      szItem += " ";
      szItem += parameter;

		  HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
			  (szLsPath), (szItem), NULL, SW_SHOWNORMAL);
    }
    delete[] pItems;
	}
}

// copy bang(s) to clipboard with parameters appended to each
void ClscpDlg::OnBangsCopytoclipboard() 
{
  int nSel = m_wndList2.GetSelCount();
	if (nSel)
	{
    /* get list of selected items */ 
    int *pItems = new int[nSel];
    m_wndList2.GetSelItems(nSel,pItems);
		CString szSelection,szItem;
		CString parameter;
    int iSel;
    /* get first (or only) item */ 
		m_wndList2.GetText(pItems[0], szSelection);
		m_wndParams.GetWindowText(parameter);
    szSelection += " ";
    szSelection += parameter;
    for (iSel=1;iSel<nSel;++iSel)
    {
      /* get the rest, separated by newlines */ 
		  m_wndList2.GetText(pItems[iSel], szItem);
      szSelection += "\x0d\x0a";
      szSelection += szItem;
      szSelection += " ";
      szSelection += parameter;
    }
    delete[] pItems;
    /* send to clipboard */ 
		Copy(szSelection);
	}
}

void ClscpDlg::OnBangsCopytocommandline() 
{
  /* command line can only hold one line */ 
	int iSel = m_wndList2.GetSelCount();
	if (iSel==1)
	{
    /* get text for selected item */ 
    m_wndList2.GetSelItems(1,&iSel);
		CString szSelection;
    CString parameter;
		m_wndList2.GetText(iSel, szSelection);

    /* replace selected or paste at cursor pos */ 
		m_wndParams.GetWindowText(parameter);
    szSelection += " ";
    szSelection += parameter;
		m_comboHistory.AddString(szSelection);
	}
}

//right click - evars
void ClscpDlg::OnVarsCopytoclipboard() 
{
	int nSelection = m_wndList4.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList4.GetText(nSelection, szSelection);

		Copy(szSelection);
	}
	
}

void ClscpDlg::OnVarsCopyvariabletocommandline() 
{
	int nSelection = m_wndList4.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList4.GetText(nSelection, szSelection);

		m_comboHistory.AddString(szSelection);
	}
	
}

////right click - help
//void ClscpDlg::OnHelpCopytoclipboard() 
//{
//	int nSelection = m_wndList2.GetCurSel();
//	if (nSelection !=LB_ERR)
//	{
//		CString szSelection;
//		m_wndList2.GetText(nSelection, szSelection);
//		Copy(szSelection);
//	}
//	
//}

void ClscpDlg::OnCopyToClipboard() 
{
  int nSel = m_wndList2.GetSelCount();
	if (nSel)
	{
    /* get list of selected items */ 
    int *pItems = new int[nSel];
    m_wndList2.GetSelItems(nSel,pItems);
		CString szSelection,szItem;
    int iSel;
    /* get first (or only) item */ 
		m_wndList2.GetText(pItems[0], szSelection);
    for (iSel=1;iSel<nSel;++iSel)
    {
      /* get the rest, separated by newlines */ 
		  m_wndList2.GetText(pItems[iSel], szItem);
      szSelection += "\x0d\x0a";
      szSelection += szItem;
    }
    delete[] pItems;
    /* send to clipboard */ 
		Copy(szSelection);
	}
}

void ClscpDlg::OnCopyToCommandLine() 
{
  /* command line can only hold one line */ 
	int iSel = m_wndList2.GetSelCount();
  DWORD dwEditSel;
	if (iSel==1)
	{
    /* get text for selected item */ 
    m_wndList2.GetSelItems(1,&iSel);
		CString szSelection,szLine;
		m_wndList2.GetText(iSel, szSelection);

    /* replace selected or paste at cursor pos */ 
    dwEditSel = m_comboHistory.GetEditSel();
    m_comboHistory.GetWindowText(szLine);
    szLine = szLine.Mid(0,LOWORD(dwEditSel)) + szSelection + szLine.Mid(HIWORD(dwEditSel));
		m_comboHistory.AddString(szLine);
	}
}

//right click - modules
void ClscpDlg::OnModulesCopypathtoclipboard() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);
		Copy(szSelection);
	}
	
}

void ClscpDlg::OnModulesReloadmodule() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);
	
		//LS path
		CString szLsPath = FindLS() + "litestep.exe";
	
		CString bangparam = "!Reloadmodule \"" + szSelection + "\"";

		HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
			(szLsPath), (bangparam), NULL, SW_SHOWNORMAL);
	}
	
}

void ClscpDlg::OnModulesUnloadmodule() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);
		
		//LS path
		CString szLsPath = FindLS() + "litestep.exe";
	
		CString bangparam = "!Unloadmodule \"" + szSelection + "\"";

		HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
			(szLsPath), (bangparam), NULL, SW_SHOWNORMAL);

		m_wndList2.DeleteString(nSelection);
	}
	
	
}

//buttons 
void ClscpDlg::OnRecycle() 
{
	//LS path
	CString szLsPath = FindLS() + "litestep.exe";

	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(szLsPath), "!recycle", NULL, SW_SHOWNORMAL);
}

void ClscpDlg::OnQuit() 
{
	//LS path
	CString szLsPath = FindLS() + "litestep.exe";

	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(szLsPath), "!quit", NULL, SW_SHOWNORMAL);
}

void ClscpDlg::OnRestart() 
{
	//LS path
	CString szLsPath = FindLS() + "litestep.exe";

//	AfxMessageBox(szLsPath);
	
	HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
		(szLsPath), "-nostartup", NULL, SW_SHOWNORMAL);
	
}

void ClscpDlg::OnOts() 
{
	m_wndOts.SetCheck(1);
	m_bOTSswitch = true;
	m_wndList2.ResetContent();
	GetDlgItem(IDC_CONFIG)->EnableWindow(false);
	AboutTheme();
		
}

void ClscpDlg::OnCustom() 
{
	m_wndCustom.SetCheck(1);
	m_bOTSswitch = false;
	m_wndList2.ResetContent();
	GetDlgItem(IDC_CONFIG)->EnableWindow(true);
	AboutThemeCustom();

}


void ClscpDlg::AboutThemeCustom()
{

	m_wndList3.ResetContent();
	
	//LS path
	CString szSwitchFile = FindLS() + "themeswitch.rc";

	FILE *f;

	f = fopen (szSwitchFile, "r");

	if (f)
	{
		fseek (f, 0, SEEK_SET);
		
		char szTempBuffer[MAX_LINE_LENGTH];
		int i = 0;
		int j = 0;

		while (f && !feof (f))
		{

		if (!fgets (szTempBuffer, MAX_LINE_LENGTH, f))
			break;

			{
		
			j = 0;
			while (szTempBuffer[j] != 0)
			j++;
			szTempBuffer[j - 1] = 0;

			m_wndList3.AddString(szTempBuffer);

			}

		}	
	if (f)

	fclose(f);

	}
		
	else
	{
		m_wndList3.AddString("themeswitch.rc unavailable");
		char expectedloc[MAX_PATH] = "Expected location: ";
		strcat(expectedloc, szSwitchFile);
		m_wndList3.AddString(expectedloc);
	}

}


void ClscpDlg::OnSwitchSwitchtheme() 
{

	OnDblclkList3();	
}

void ClscpDlg::OnSwitchShowthemeinformation() 
{
	int nSelection = m_wndList3.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList3.GetText(nSelection, szSelection);
		
		//LS path
		CString szLsPath = FindLS();

		if (m_bOTSswitch)

		{
			CString szInfo = szLsPath + "themes\\" + szSelection +"\\" + "readme.htm";
			
			HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
				(szInfo), NULL, NULL, SW_SHOWNORMAL);

			if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
			{
				CString szInfo = szLsPath + "themes\\" + szSelection +"\\" + "readme.chm";
				
				HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
					(szInfo), NULL, NULL, SW_SHOWNORMAL);
			
					if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
					{
						CString szInfo = szLsPath + "themes\\" + szSelection +"\\" + "readme.txt";
					
						HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
							(szInfo), NULL, NULL, SW_SHOWNORMAL);

						if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
						{
							AfxMessageBox("The Readme file is not available.\nPlease contact the author and\ntell him he should have included:\n- Readme.txt \n or \n- Readme.htm\nto be fully OTS-compliant");
						}

					}

			}
	
		}
		else
		{
			CString szInfo = szSelection +"\\" + "readme.htm";

			HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
				(szInfo), NULL, NULL, SW_SHOWNORMAL);

					if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
			{
				CString szInfo = szLsPath + "themes\\" + szSelection +"\\" + "readme.chm";
				
				HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
					(szInfo), NULL, NULL, SW_SHOWNORMAL);
			
					if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
					{
						CString szInfo = szLsPath + "themes\\" + szSelection +"\\" + "readme.txt";
					
						HINSTANCE hinst1 = ::ShellExecute(m_hWnd, _T("open"), 
							(szInfo), NULL, NULL, SW_SHOWNORMAL);

						if (hinst1 < (HINSTANCE) HINSTANCE_ERROR) 			
						{
							AfxMessageBox("The Readme file is not available.");
						}

					}

			}

		}
	}		
}


bool ClscpDlg::CheckLSRunning()
{
CWnd* ptWin = FindWindow("TApplication", "LiteStep");
	if(ptWin)
////if ((pWndPrev = CWnd::FindWindow(_T("LITESTEP"),NULL))) 
return TRUE;
else
return FALSE;

}

void ClscpDlg::PopEvars()
{
	m_wndList4.AddString("$LitestepDir$");
	m_wndList4.AddString("$AdminTools$");
	m_wndList4.AddString("$AdminToolsDir$");
	m_wndList4.AddString("$BitBucket$");
	m_wndList4.AddString("$CommonAdminToolsDir$");
	m_wndList4.AddString("$CommonDesktopDir$");
	m_wndList4.AddString("$CommonDocuments$");
	m_wndList4.AddString("$CommonFavorites$");
	m_wndList4.AddString("$CommonPrograms$");
	m_wndList4.AddString("$CommonStartMenu$");
	m_wndList4.AddString("$CommonStartUp$");
	m_wndList4.AddString("$CompileDate$");
	m_wndList4.AddString("$Controls$");
	m_wndList4.AddString("$Cookies$");
	m_wndList4.AddString("$Desktop$");
	m_wndList4.AddString("$DesktopDir$");
	m_wndList4.AddString("$Dialup$");
	m_wndList4.AddString("$Documents$");
	m_wndList4.AddString("$Drives$");
	m_wndList4.AddString("$Favorites$");
	m_wndList4.AddString("$Fonts$");
	m_wndList4.AddString("$History$");
	m_wndList4.AddString("$InternetCache$");
	m_wndList4.AddString("$NetHood$");
	m_wndList4.AddString("$Network$");
	m_wndList4.AddString("$NetworkAndDialup$");
	m_wndList4.AddString("$OS-Name$");
	m_wndList4.AddString("$OS-Version$");
	m_wndList4.AddString("$OS-MajorVersion$");
	m_wndList4.AddString("$OS-MinorVersion$");
	m_wndList4.AddString("$Printers$");
	m_wndList4.AddString("$Programs$");
	m_wndList4.AddString("$QuickLaunch$");
	m_wndList4.AddString("$Recent$");
	m_wndList4.AddString("$ResolutionX$");
	m_wndList4.AddString("$ResolutionY$");
	m_wndList4.AddString("$Scheduled$");
	m_wndList4.AddString("$SendTo$");
	m_wndList4.AddString("$StartMenu$");
	m_wndList4.AddString("$StartUp$");
	m_wndList4.AddString("$Templates$");
	m_wndList4.AddString("$Username$");
	m_wndList4.AddString("$WinDir$");
	m_wndList4.AddString("$WinME$");
	m_wndList4.AddString("$Win98$");
	m_wndList4.AddString("$Win95$");
	m_wndList4.AddString("$Win9x$");
	m_wndList4.AddString("$Win2000$");
	m_wndList4.AddString("$WinNT4$");
	m_wndList4.AddString("$WinNT$");
	m_wndList4.AddString("$WinXP$");
}
  

void ClscpDlg::OnSelchangeList4() 
{

	m_wndReference.SetWindowText("");
	CString m_strList;
	int nSelection = m_wndList4.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		//CString szSelection;
		m_wndList4.GetText(nSelection, m_strList);

		if (m_strList == "$LitestepDir$")
		m_wndReference.SetWindowText("References the directory where the LiteStep executable is found.");
		
		else if (m_strList == "$AdminTools$")
		m_wndReference.SetWindowText("References the Administrative Tools folder in Windows NT/2K\r\n"
									 "via the Windows Explorer interface.\r\n" 
									 "Note: This does not work when used in a Popup,\r\n"
									 "please use $AdminToolsDir$ instead.");
		
		else if (m_strList == "$AdminToolsDir$")
		m_wndReference.SetWindowText("References the Administrative Tools directory in Windows NT/2K.");

		else if (m_strList == "$BitBucket$")
		m_wndReference.SetWindowText("References the \"Recycle Bin\", which is normally found\r\n"
									 "on the Explorer Desktop.");

		else if (m_strList == "$CommonAdminToolsDir$")
		m_wndReference.SetWindowText("References the Admin Tools for All Users for Windows NT/2K.");

		else if (m_strList == "$CommonDesktopDir$")
		m_wndReference.SetWindowText("References the Desktop folder that is shared with all users\r\n"
								     "in Windows NT/2K.");

		else if (m_strList == "$CommonDocuments$")
		m_wndReference.SetWindowText("References the My Documents directory that is shared\r\n"
									 "with all users in Windows NT/2K.");
		
		else if (m_strList == "$CommonFavorites$")
		m_wndReference.SetWindowText("References the Internet Explorer Favorites folder shared\r\n"
									 "with all users in Windows NT/2K.");

		else if (m_strList == "$CommonPrograms$")
		m_wndReference.SetWindowText("References the Programs directory in the Start Menu\r\n"
									 "shared with all users in Windows NT/2K.");
		
		else if (m_strList == "$CommonStartMenu$")
		m_wndReference.SetWindowText("References the Start Menu shared with all users\r\n"
									 "in Windows NT/2K.");

		else if (m_strList == "$CommonStartUp$")
		m_wndReference.SetWindowText("References the Start Up folder in the Start Menu\r\n"
									 "that auto-runs programs at startup for all users.");

		else if (m_strList == "$CompileDate$")
		m_wndReference.SetWindowText("References the compile date of the LiteStep build.");

		else if (m_strList == "$Controls$")
		m_wndReference.SetWindowText("References the \"Control Panel\", which is normally\r\n"
									 "in \"My Computer\".");

		else if (m_strList == "$Cookies$")
		m_wndReference.SetWindowText("References the directory where your Internet Explorer cookies\r\n"
									 "are stored.");

		else if (m_strList == "$Desktop$")
		m_wndReference.SetWindowText("References the directory in which your files on your\r\n" 
									 "Windows 95/98/ME Explorer Desktop are stored.");

		else if (m_strList == "$DesktopDir$")
		m_wndReference.SetWindowText("References the directory in which the current user's files\r\n" 
									 "on the Windows 95/98/ME Explorer Desktop icons are stored,\r\n" 
									 "if multiple users are configured.");

		else if (m_strList == "$Dialup$")
		m_wndReference.SetWindowText("References the Dial-Up Networking/Connections folder that\r\n"
									 "is found in your Windows 95/98/ME My Computer.");

		else if (m_strList == "$Documents$")
		m_wndReference.SetWindowText("References the directory named \"My Documents\"\r\n"
									 "on your Hard Drive.");

		else if (m_strList == "$Drives$")
		m_wndReference.SetWindowText("References the \"My Computer\" folder that is found\r\n"
									 "on your Explorer Desktop.");

		else if (m_strList == "$Favorites$")
		m_wndReference.SetWindowText("References the folder that contains your\r\n"
									 "Internet Explorer Favorites.");

		else if (m_strList == "$Fonts$")
		m_wndReference.SetWindowText("References the folder that contains all of the Fonts\r\n"
									 "installed in Windows.");

		else if (m_strList == "$History$")
		m_wndReference.SetWindowText("References the folder containing your Internet Explorer History.");

		else if (m_strList == "$InternetCache$")
		m_wndReference.SetWindowText("References the folder that contains all of your\r\n"
									 "Temporary Internet Files.");

		else if (m_strList == "$NetHood$")
		m_wndReference.SetWindowText("References the \"My Network Places\" in Windows 2000.");

		else if (m_strList == "$Network$")
		m_wndReference.SetWindowText("References the Network Neighborhood folder found\r\n"
									 "on the Explorer Desktop.");

		else if (m_strList == "$NetworkAndDialup$")
		m_wndReference.SetWindowText("References the Network and Dialup folder for Windows 2K.");

		else if (m_strList == "$OS-Name$")
		m_wndReference.SetWindowText("References the OS name.");

		else if (m_strList == "$OS-Version$")
		m_wndReference.SetWindowText("References the OS version (major.minor).");

		else if (m_strList == "$OS-MajorVersion$")
		m_wndReference.SetWindowText("References the OS major version number.");

		else if (m_strList == "$OS-MinorVersion$")
		m_wndReference.SetWindowText("References the OS minor version number.");

		else if (m_strList == "$Printers$")
		m_wndReference.SetWindowText("References the Printers folder that is found in both\r\n"
									 "your \"Control Panel\" and \"My Computer\".");

		else if (m_strList == "$Programs$")
		m_wndReference.SetWindowText("References the Programs directory inside the Start Menu.\r\n"
									"(For those using NT/2K, it is the current user's\r\n" 
									"Programs directory.)");

		else if (m_strList == "$QuickLaunch$")
		m_wndReference.SetWindowText("References the directory of the Quick Launch Bar.");

		else if (m_strList == "$Recent$")
		m_wndReference.SetWindowText("References the Recent Documents directory which is\r\n"
									 "commonly found in the Start Menu.");

		else if (m_strList == "$ResolutionX$")
		m_wndReference.SetWindowText("References the Width of the display in Pixels.");

		else if (m_strList == "$ResolutionY$")
		m_wndReference.SetWindowText("References the Height of the display in Pixels.");

		else if (m_strList == "$Scheduled$")
		m_wndReference.SetWindowText("References the folder that contains Scheduled Tasks\r\n"
									 "used by the Windows Task Scheduler.");

		else if (m_strList == "$SendTo$")
		m_wndReference.SetWindowText("References the \"Send To\" folder that is found\r\n" 
									 "in right-click context menus.");

		else if (m_strList == "$StartMenu$")
		m_wndReference.SetWindowText("References the Start Menu folder, not to be confused with\r\n"
									 "$Programs$. For NT/2k, it is the current user's\r\n"
									 "Start Menu directory.");

		else if (m_strList == "$StartUp$")
		m_wndReference.SetWindowText("References that StartUp folder in your $Programs$,\r\n"
									 "this is the directory in your Start Menu that\r\n"
									 "auto-runs programs at startup.");

		else if (m_strList == "$Templates$")
		m_wndReference.SetWindowText("References the Templates folder.");

		else if (m_strList == "$Username$")
		m_wndReference.SetWindowText("References the current username.");

		else if (m_strList == "$WinDir$")
		m_wndReference.SetWindowText("References the installation directory of Windows.");

		else if (m_strList == "$WinME$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$Win98$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$Win95$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$Win9x$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$Win2000$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$WinNT4$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$WinNT$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

		else if (m_strList == "$WinXP$")
		m_wndReference.SetWindowText("References what Operating System you are using\r\n"
									 "and sets the variable to the [BOOL] value of TRUE.");

	}
}


//configuration dialog for custom theme switcher
void ClscpDlg::OnConfig() 
{
	CDlgConf dlgconf;
	dlgconf.DoModal();
	
}

//switch theme button
void ClscpDlg::OnSwitch() 
{
	
	OnDblclkList3();
}

//create a $lsdir$temp directory
CString ClscpDlg::createDirectory(CString wsPath)
{
	char SLASH='\\'; 
	DWORD attr; 
	int pos; 
	bool result = true; 

	// Check for trailing slash: 
	pos = wsPath.ReverseFind(SLASH); 

	if (wsPath.GetLength() == pos + 1) // last character is "\" 
	{ 
		wsPath = wsPath.Left(pos); 
	} 

	// Look for existing object: 
	attr = GetFileAttributes(LPCTSTR(wsPath)); 
	if (0xFFFFFFFF == attr) // doesn't exist yet - create it! 
	{ 
		pos = wsPath.ReverseFind(SLASH); 
		if (0 < pos) 
		{ 
			// Create parent dirs: 
      result = createDirectory(wsPath.Left(pos))?true:false;
		} 
		// Create node: 
    result = result && CreateDirectory(LPCTSTR(wsPath), NULL)?true:false; 
		//result = result; 
	} 
	else if (! (GetFileAttributes(LPCTSTR(wsPath)) & FILE_ATTRIBUTE_DIRECTORY)) 
	{ // object already exists, but is not a dir 
		SetLastError(ERROR_FILE_EXISTS); 
		result = false; 
	} 
	return result; 
}

void ClscpDlg::PopHotkeys()
{
	//LS path
	CString szHotkeysTxtPath = FindLS() + "lscphotkeys.txt";
  LoadFile(szHotkeysTxtPath,"lscphotkeys.txt");
}

void ClscpDlg::PopCustomVars()
{
	//LS path
	CString szCustomVarsTxtPath = FindLS() + "lscpevars.txt";
  LoadFile(szCustomVarsTxtPath,"lscpevars.txt");
}

void ClscpDlg::OnVarsCopytoclipboard2() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);

		Copy(szSelection);
	}
	
}

void ClscpDlg::OnVarsCopyvariabletocommandline2() 
{
	int nSelection = m_wndList2.GetCurSel();
	if (nSelection !=LB_ERR)
	{
		CString szSelection;
		m_wndList2.GetText(nSelection, szSelection);

		m_comboHistory.AddString(szSelection);
	}
	
}
