// PropertyPage.h: interface for the CMyPropertyPage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPERTYPAGE_H__7A0B7EBD_5CDA_4A6D_917B_60F516445B75__INCLUDED_)
#define AFX_PROPERTYPAGE_H__7A0B7EBD_5CDA_4A6D_917B_60F516445B75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include <map>

#include <atlbase.h>
#include <atlwin.h>
#include <atlapp.h>
#include <atlframe.h>
#include <atlgdi.h>
#include <atlctrls.h>
#include <atldlgs.h>
#include <atlcrack.h>

#include "IConfigurationItem.h"

#include "ConfigurationDialogTemplateImpl.h"
#define CTL_TREE_ID 1
#define CTL_HELPTEXT_ID 2



class CMyPropertyPage : public CPropertyPageImpl<CMyPropertyPage>, public CConfigurationHandlerImpl
{
private:
	typedef list<IConfigurationItem*> T_LST_ICI;
public:
	enum { IDD = IDD_PROPPAGE_MEDIUM };

	// chain both inherited message maps
	BEGIN_MSG_MAP(CMyPropertyPage)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_CTLCOLORSTATIC, OnCtlColor)
		NOTIFY_HANDLER(CTL_TREE_ID, TVN_SELCHANGED, OnSelChanged);
		NOTIFY_HANDLER(CTL_TREE_ID, NM_RCLICK, OnRightClick);
		NOTIFY_HANDLER(CTL_TREE_ID, TVN_BEGINLABELEDIT, OnBeginLableEdit);
		NOTIFY_HANDLER(CTL_TREE_ID, TVN_ENDLABELEDIT, OnEndLableEdit);
		NOTIFY_HANDLER(CTL_TREE_ID, NM_SETFOCUS, OnSetFocus);
		NOTIFY_HANDLER(CTL_TREE_ID, NM_KILLFOCUS, OnKillFocus);
		CHAIN_MSG_MAP(CPropertyPageImpl<CMyPropertyPage>)
	END_MSG_MAP()


	LRESULT OnCtlColor(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		HDC hDC = (HDC)wParam;
		HWND hWnd = (HWND)lParam;
		if (hWnd == m_helptext.m_hWnd) {
			::SetTextColor(hDC, RGB(0,0,0));
			::SetBkColor(hDC, RGB(252,252,204));
			::SelectObject(hDC, m_font);
			return (LRESULT)m_hBrush;
		}
		bHandled = FALSE;
		return 0;
	}

public:
	BOOL OnApply();
	BOOL OnOK();
	bool addDialogItem(RECT rTree, IConfigurationDlgItem *itm);
	void parse(IConfigurationItem *item, HTREEITEM hParent);
	CMyPropertyPage(IConfigurationItem *pRootItem);
	virtual ~CMyPropertyPage();
protected:

	virtual LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled);
	virtual LRESULT OnSelChanged(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnRightClick(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnBeginLableEdit(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnEndLableEdit(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnSetFocus(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnKillFocus(int wParam, LPNMHDR lParam, BOOL bHandled);
	virtual LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled);
private:
	bool copyToClipBoard(string str);
	bool hidePage(IConfigurationItem* itm);
	bool showPage(IConfigurationItem* itm);
	void resizeControls();

public:
	//////////////////////////////////////////////////////////////////////////
	// CConfigurationHandlerImplT
	void onItemChanged(IConfigurationItem *pItem)
	{
	}
	int registerIcon(HICON hIcon)
	{
		return -1;
	}
	void unRegisterIcon(int iID)
	{
	}
	void onActiveateTemplate()
	{
		if (CConfigurationHandlerImpl::hasActiveTemplate()) {
			CConfigurationHandlerImpl::getActiveTemplate()->createDialog(*this);
			CConfigurationHandlerImpl::getActiveTemplate()->show();
			CConfigurationHandlerImpl::getActiveTemplate()->move(205, 0);
		}
	}
	void onDeActiveateTemplate()
	{	
		if (CConfigurationHandlerImpl::hasActiveTemplate())
			CConfigurationHandlerImpl::getActiveTemplate()->hide();	
	}
	HWND getParrentHandle()
	{
		return m_hWnd;	
	}
	void onAttach(IConfigurationItem *pItem)
	{
	}
	void onDetach(IConfigurationItem *pItem)
	{
	}

	void setHelpText(string text)
	{
		m_helptext.SetWindowText(_T(text.c_str()));
	}




private:
	bool m_bLableEdit;
	typedef map<int,IConfigurationDlgItem*> MAP_DLGITM;
	MAP_DLGITM m_mapDialogItems;
	unsigned int m_iCtrlIndex;
	CStatic m_helptext;
	CTreeViewCtrl m_tree;
	IConfigurationItem *m_pRootItem;
	IConfigurationItem *m_pCurrentItem;
	int m_iLastSelectedDlgItem;
	T_LST_ICI m_lstItems;

	CFont m_font;
	HBRUSH m_hBrush;

};

#endif // !defined(AFX_PROPERTYPAGE_H__7A0B7EBD_5CDA_4A6D_917B_60F516445B75__INCLUDED_)
