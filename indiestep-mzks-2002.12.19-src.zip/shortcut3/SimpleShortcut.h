// SimpleShortcut.h: interface for the CSimpleShortcut class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLESHORTCUT_H__48985F32_9768_4A29_BBA0_04D713997145__INCLUDED_)
#define AFX_SIMPLESHORTCUT_H__48985F32_9768_4A29_BBA0_04D713997145__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// SC3 Includes
#include "IShortcut.h"
#include "State.h"
#include "IShortcutImpl.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "Bitmap.h"
#include "CFGTemplates.h"

#define SSC_CMD_IMAGE 0
#define SSC_CMD_ALPHA 1
#define SSC_CMD_COUNT 2

class CSimpleShortcut : public IShortcutImpl 
{
public:
	IConfigurationItem* getConfigurationIF();
	void onRefreshShortcut();
	void parseSimpleConfig(string szConfigLine);
	CSimpleShortcut(CShortcutFactory *sf, string configuration);
	virtual ~CSimpleShortcut();
	void createShortcut();
	void execBang(int iCmd, string szArg);
public:
	string getStepRC(bool bRecursive);
	void setBitmap(string bmp);
	string getBitmap() {
		return m_bitmap.getImageFile();
	}
	void setAlphaLevel(int i);
	int getAlphaLevel() {
		return m_bitmap.getAlphaLevel();
	}
private:
	CLSBitmap m_bitmap;
	int m_iCommandArray[SSC_CMD_COUNT];


public:
	///////////////////////////////////////////////////////////////////////
	// IShortcut
	//
	static string getShortName(){ return "simple";	}
	static string getLongName()	{ return "Simple shortcut"; }
	///////////////////////////////////////////////////////////////////////
	// IConfigurationItem
};



class CCISimpleShortcut : public CConfigurationItemImpl {
private:
	CSimpleShortcut *pNormalSC;
public:
	CCISimpleShortcut(CSimpleShortcut *_pNormalSC) : pNormalSC(_pNormalSC) {}
	virtual ~CCISimpleShortcut() {}

	// Properties
	CFG_ITM_SET_TEMPLATE_H(CCISimpleShortcut, CCDTSimpleShortcut);
	CI_SET_VERIFY_ALWAYS(pNormalSC);
	CI_SET_NAME_EX(pNormalSC->getName, pNormalSC->setName);
	CI_SET_DESCRIPTION("This is a normal shortcut...");
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_SET_DELETE_DISABLED();
	CI_CHILD_BEGIN();
	CI_CHILD_ADD(CCIPosition, pNormalSC);
	CCIFlags *pFlags = new CCIFlags(pNormalSC);
	pFlags->addFlag("hide", "Initaly hide shortcut (faster load)", "The shortcut is not created untill it is first visible\nThis will make sure that unnessecary resources are not in use.");
	pFlags->addFlag("alphaMap", "Enable true alpha maps (PNG images).", "Set this to enable PNG alpha maps.\nAlpha maps are true varied transparency.");
	pFlags->addFlag("alphaTrans", "Enable fake alpha transparency (non PNG images).", "Enables fake transparency.\nThis is what was new in w2k and is a semitransparent image.");
	pFlags->addFlag("opaque", "Disable Magic pink. (faster).", "Set this if the image is square. This will improve prefomance.");
	pFlags->addFlag("ontop", "Simpler version of the Z-order handeling. (sc2).", "Sets the shortcut topmost (same as z-order topMost)\nThis is used for simple shortcuts or such, and is just a simplified z-order option)");
	ret.push_back(pFlags);
	CI_CHILD_END();
	CI_SET_STEPRC_RELAY(pNormalSC);

	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CDataSaverFtor<CDataSaverInt, int, CSimpleShortcut>(IDC_ALPHA, pNormalSC, CSimpleShortcut::setAlphaLevel, CSimpleShortcut::getAlphaLevel));
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CSimpleShortcut>(IDC_IMAGE, pNormalSC, CSimpleShortcut::setBitmap, CSimpleShortcut::getBitmap));
	}
};



class CCDTSimpleShortcut : public CConfigurationDialogTemplateImplT<CCDTSimpleShortcut>, public CDialogImpl<CCDTSimpleShortcut>
{
private:
	LPCTSTR lpcstrFilter;
public:
	enum { IDD = IDD_SIMPLE_SC_CFG };
	BEGIN_MSG_MAP(CCDTSimpleShortcut);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	COMMAND_HANDLER(IDC_BROWSE, BN_CLICKED, onBrowse);
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTSimpleShortcut>);
	END_MSG_MAP();
	CCDTSimpleShortcut(CCISimpleShortcut *pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTSimpleShortcut>(pICH),
			lpcstrFilter( 
	_T("All Image Files\0*.png; *.jpg; *.bmp\0")
	_T("PNG (Portable Network Graphic) Files (*.png)\0*.png\0")
	_T("JPEG (Joint P-something) Files (*.jpg, *.jpeg)\0*.jpg; *.jpeg\0")
	_T("BMP (BitMaP) Files (*.bmp)\0*.bmp\0")
	_T("All Files (*.*)\0*.*\0")
	_T(""))
	{}
	virtual ~CCDTSimpleShortcut() {}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		saveData();
		return 0;
	}
	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		SendDlgItemMessage(IDC_ALPHASPIN, UDM_SETRANGE32, 0, 255);
		return 0;
	}
	

	LRESULT onBrowse(UINT uMsg, UINT uID, HWND hWnd, BOOL &bHandled) {
		char *c = new char[1024];
		LSGetImagePath(c, 1023);
		c[strlen(c)-1] = '\0';
		string dir = c;
		delete [] c;
		CFileDialog file(TRUE, NULL, _T(IConfigurationHelpers::GetTextBoxText(m_hWnd, IDC_IMAGE).c_str()), 
			OFN_HIDEREADONLY, lpcstrFilter);
		file.m_ofn.lpstrInitialDir = _T(dir.c_str());

		if (file.DoModal(m_hWnd)==IDCANCEL)
			return 0;
		string str = file.m_szFileName;
		if (str.substr(0, dir.length()) == dir) {
			str = str.substr(dir.length()+1);
		}
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_IMAGE, str);
		saveData();
		return 0;
	}
};

#endif // !defined(AFX_SIMPLESHORTCUT_H__48985F32_9768_4A29_BBA0_04D713997145__INCLUDED_)
