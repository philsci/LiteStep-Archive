// Bitmap.h: interface for the CLSBitmap class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITMAP_H__365D8890_6BAF_4E9E_9709_BDEC036C6384__INCLUDED_)
#define AFX_BITMAP_H__365D8890_6BAF_4E9E_9709_BDEC036C6384__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <string>
#include <windows.h>
#include "IConfigurationItem.h"

using namespace std;
class CLSBitmap  
{
public:
	int getAlphaLevel() const;
	void setAlphaLevel(int level);
	void setImageFile(string file, bool preload = false);
	string getImageFile() const;
	HBITMAP getBitmapHandle();
	HBITMAP getAlphaBitmapHandle();
	HRGN getRegionHandle();
	CLSBitmap();
	CLSBitmap(string file);
	virtual ~CLSBitmap();


protected:
	void loadBitmap();
	void loadAlphaBitmap();

private:
	void PreMultiplyRGBChannels();

private:
	HBITMAP m_hBmp;
	HRGN m_hRgn;
	HBITMAP m_hAlphaBmp;
	string m_sImageFile;
	boolean m_bLoadedImage;
	boolean m_bLoadedAlphaImage;
	int m_iALphaLevel;
};



#endif // !defined(AFX_BITMAP_H__365D8890_6BAF_4E9E_9709_BDEC036C6384__INCLUDED_)
