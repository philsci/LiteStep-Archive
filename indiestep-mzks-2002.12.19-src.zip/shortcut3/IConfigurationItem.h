// IConfigurationItem.h: interface for the IConfigurationItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ICONFIGURATIONITEM_H__2494F18E_0839_4566_828F_A3BCC9FA7101__INCLUDED_)
#define AFX_ICONFIGURATIONITEM_H__2494F18E_0839_4566_828F_A3BCC9FA7101__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning (disable: 4786)

#include <list>
#include <map>
#include <vector>
#include <windows.h>
#include <../lsapi/lsapi.h>
#include "string_util.h"
#include "Messages.h"

using namespace std;
// Forward declarations.

class IConfigurationDialog;
class IConfigurationDlgItem;
class IConfigurationDlgHandler;
class CConfigurationDlgItemCoreHelper;
class IConfigurationHandler;
class IConfigurationDialogTemplate;


#define STD_ICI_ERR(code, pItem) scErrorMessageSimpleParamEx(pItem, code, 0)

/**
 *
 * CFG_ITM_SET_TEMPLATE
 *
 * Description:
 * Macro for defining the temoplkateclass
 *
 * @created	2002-07-20 13:59
 * @author	MickeM <mickem@medin.nu>
 */

#define CFG_ITM_SET_TEMPLATE_CPP(rootClass, templateClass) \
	int rootClass::m_iTemplateID = -1; \
	IConfigurationDialogTemplate* rootClass::getCfgItmTpl(IConfigurationHandler *pICH) { \
	return new templateClass(this, pICH); \
	}

#define CFG_ITM_SET_TEMPLATE_H(rootClass, templateClass) \
	static int m_iTemplateID; \
	IConfigurationDialogTemplate* getCfgItmTpl(IConfigurationHandler *pICH); \
	int getTemplateID() {return m_iTemplateID;	} \
	void setTemplateID(int iTplId) {m_iTemplateID = iTplId;	}

namespace IConfigurationHelpers {
	string itos(int i);
	int stoi(string s);
	string GetTextBoxText(HWND hWnd, UINT uID);
	void SetTextBoxText(HWND hWnd, UINT uID, string str);

	template <class T1, class T2 = IConfigurationDlgItem>
	class reCaster {
		public:
			T1 *itm;
		bool recast(T2* reItm) {
			if (!reItm) {
				scErrorMessageSimpleParam("<unkown>", SCE_BAD_CAST, 0);
				return false;
			}
			itm = NULL;
			try {
				itm = dynamic_cast<T1*>(reItm);
			} catch (bad_cast) {
				scErrorMessageSimpleParam(reItm->getName(), SCE_BAD_CAST, 0);
				return false;
			}
			if (!itm) {
				scErrorMessageSimpleParam(reItm->getName(), SCE_BAD_CAST, 0);
				return false;
			}
			return true;
		}
	};

		
	class CWindowFinder
	{
	private:
		UINT uIDGrabber;
		UINT uIDClass;
		UINT uIDCaption;
		UINT uIDCGrabber;
		HINSTANCE hInstance;
		HWND hLastWnd;
		HPEN hPen;
		bool bIsGrabbing;

	public:
		BOOL ProcessWindowMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, LRESULT& lResult, DWORD dwMsgMapID = 0) {
			BOOL bHandled = TRUE;   hWnd;   uMsg;   wParam;   lParam;   lResult;   bHandled;   
			switch(dwMsgMapID) {
			case 0:
				if(uMsg == WM_COMMAND && uIDGrabber == LOWORD(wParam) && STN_CLICKED == HIWORD(wParam)) {
					bIsGrabbing = true;
					::SetCursor(LoadCursor(hInstance, MAKEINTRESOURCE(uIDCGrabber)));
					::SetCapture(hWnd);
					return TRUE;
				}
				if(uMsg == WM_MOUSEMOVE) {
					bHandled = TRUE;   
					lResult = onMouseMove(hWnd, uMsg, wParam, lParam, bHandled);   
					if(bHandled)   
						return TRUE;   
				}
				if(uMsg == WM_LBUTTONUP) {
					bHandled = TRUE;   
					lResult = onLButtonUp(hWnd, uMsg, wParam, lParam, bHandled);   
					if(bHandled)   
						return TRUE;   
				}
				break;   
			}
			return FALSE;   
		}

		CWindowFinder(HINSTANCE _hInstance, UINT _uIDGrabber, UINT _uIDClass, UINT _uIDCaption, UINT _uIDCGrabber) 
			: hInstance(_hInstance),
			uIDGrabber(_uIDGrabber),
			uIDClass(_uIDClass),
			uIDCaption(_uIDCaption),
			uIDCGrabber(_uIDCGrabber),
			hLastWnd(NULL),
			hPen(NULL),
			bIsGrabbing(false)
		{	hPen = CreatePen(PS_SOLID, 3, RGB(256, 0, 0));	}
		virtual ~CWindowFinder() {
			DeleteObject(hPen);
			hPen = NULL;
		}
		HRESULT onClickGrabber(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		}
		HRESULT onLButtonUp(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
			if (!bIsGrabbing) {
				bHandled = FALSE;
				return 0;
			}
			::SetCursor(LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
			::ReleaseCapture();
			bIsGrabbing = false;
			return 0;
		}
		HRESULT onMouseMove(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
			if (!bIsGrabbing) {
				bHandled = FALSE;
				return 0;
			}
			POINT screenpoint;
			GetCursorPos (&screenpoint);  
			HWND hFoundWnd = WindowFromPoint(screenpoint);
			
			// Check first for validity.
			if ((hFoundWnd) && (::IsWindow(hFoundWnd)) && (hLastWnd!=hFoundWnd)) {

				char *str = new char[1024];
				GetClassName(hFoundWnd, str, 1023);
				::SendDlgItemMessage(hWnd, uIDClass, WM_SETTEXT, (WPARAM)0, (LPARAM)str);
				GetWindowText(hFoundWnd, str, 1023);
				::SendDlgItemMessage(hWnd, uIDCaption, WM_SETTEXT, (WPARAM)0, (LPARAM)str);
				// TODO: add caption here

				if (hLastWnd) {
					::InvalidateRect(hLastWnd, NULL, TRUE);
					::UpdateWindow(hLastWnd);
					::RedrawWindow(hLastWnd, NULL, NULL, RDW_FRAME|RDW_INVALIDATE|RDW_UPDATENOW|RDW_ALLCHILDREN);
				}

				HGDIOBJ hPrevPen = NULL;
				HGDIOBJ hPrevBrush = NULL;
				RECT rect;
				
				::GetWindowRect(hFoundWnd, &rect);
				HDC hWindowDC = ::GetWindowDC(hFoundWnd);
				
				if (hWindowDC) {
					hPrevPen = ::SelectObject(hWindowDC, hPen);
					hPrevBrush = ::SelectObject(hWindowDC, GetStockObject(HOLLOW_BRUSH));
					::Rectangle (hWindowDC, 0, 0, rect.right-rect.left, rect.bottom-rect.top);
					::SelectObject (hWindowDC, hPrevPen);
					::SelectObject (hWindowDC, hPrevBrush);
					::ReleaseDC (hFoundWnd, hWindowDC);
				}

				hLastWnd=hFoundWnd;
			}
			return 0;
		}
	};

}

/**
 *
 * Macros for simplifying IC classes
 *
 * Description:
 * 
 *
 * @created	2002-07-24 18:07
 * @author	MickeM <mickem@medin.nu>
 */

#define CI_SET_VERIFY_DISABLED() \
	inline bool _verifyVariable() { return true; }
#define CI_SET_VERIFY_ALWAYS(var) \
	inline bool _verifyVariable() { return var != NULL; }

#define CI_VERIFY(ret) \
	if (!_verifyVariable()) return ret;

#define CI_SET_NAME_STATIC(static_name) \
	string getName() {	CI_VERIFY(""); return static_name;	} \
	bool setName(string sName) { return false; } \
	bool canRename() {	return false;	}
#define CI_SET_NAME(name) \
	string getName() {	CI_VERIFY(""); return name;	} \
	bool setName(string sName) { CI_VERIFY(false); name = sName; return true; } \
	bool canRename() {	return true; }
#define CI_SET_NAME_EX(getter, setter) \
	string getName() {	CI_VERIFY(""); return getter();	} \
	bool setName(string sName) { CI_VERIFY(false); setter(sName); return true; } \
	bool canRename() {	return true; }

#define CI_SET_DESCRIPTION(descr) \
	string getDescription() {	CI_VERIFY(""); return descr;	}
#define CI_SET_DELETE_DISABLED() \
bool canDeleteItem() {	return false;	} \
	bool deleteItem() {	return false;	}

#define CI_SET_ICON_DISABLED() \
	int getIcon() {	return -1;	}

#define CI_SET_ADDCHILD_DISABLED() \
	LST_STRING getPosibleChildren() {	LST_STRING ret;	return ret;	} \
	IConfigurationItem* addNewChild(string type) {	return NULL;}

#define CI_CHILD_DISABLED() \
	LST_CHILD getChildren() { LST_CHILD ret; return ret;} \
	bool hasChildren() { return false; }

#define CI_CHILD_BEGIN_REFLECT(target) \
	LST_CHILD getChildren() { LST_CHILD ret = target->getChildren(); 

#define CI_CHILD_BEGIN() \
	LST_CHILD getChildren() { LST_CHILD ret; 
#define CI_CHILD_ADD(className, param) \
		ret.push_back(new className(param)); 
#define CI_CHILD_END() \
	return ret;} \
	bool hasChildren() { return true; }

 
#define CI_SET_SAVERC_RELAY(target) \
	bool saveStepRC() {	CI_VERIFY(false); return target->saveStepRC(); }

#define CI_SET_STEPRC_RELAY(target) \
	string getStepRC(bool b) {	CI_VERIFY("");	return target->getStepRC(b); }
#define CI_SET_STEPRC_SIMPLE(target) \
	string getStepRC(bool) {	CI_VERIFY("");	return target; }
#define CI_SET_STEPRC_SIMPLE_EX(nonRecursive, recursive) \
	string getStepRC(bool b) {	CI_VERIFY("");	if (b) return recursive; return nonRecursive;}
#define CI_SET_STEPRC_RELAY_CHILDREN() \
	string getStepRC(bool b) {  CI_VERIFY("");	if (!hasChildren()||!b) return "";\
	string ret; LST_CHILD lst = getChildren(); \
	for (LST_CHILD::iterator it = lst.begin(); it != lst.end();it++) {\
			IConfigurationItem *pItem = (*it); if (pItem) ret += pItem->getStepRC(true); delete pItem;\
	} return ret; }
	
/**
 *  
 * IConfigurationItem
 *
 * Interface for the core configuration items. Everything has de be derived from this.
 *
 */
class IConfigurationItem  
{
public:
	typedef list<IConfigurationItem*> LST_CHILD;
	typedef list<string> LST_STRING;
public:
	IConfigurationItem();
	virtual ~IConfigurationItem();

	// Properties
	virtual string getName() = 0;
	virtual int getIcon() = 0;
	virtual bool setName(string sName) = 0;
	virtual string getDescription() = 0;
	virtual LST_CHILD getChildren() = 0;
	virtual bool hasChildren() = 0;
	virtual bool canRename() = 0;
	virtual LST_STRING getPosibleChildren() = 0;
	virtual string getStepRC(bool bRecursive) = 0;
	virtual bool saveStepRC() = 0;
	virtual bool canDeleteItem() = 0;

	// Methogs
	virtual void initializeNode(IConfigurationHandler *pICH) = 0;
	virtual void unInitializeNode(IConfigurationHandler *pICH) = 0;
	virtual void show() = 0;
	virtual void hide() = 0;
	virtual IConfigurationItem* addNewChild(string type) = 0;
	virtual bool deleteItem() = 0;

};
/**
 *
 * CConfigurationItemImpl (CConfigurationItemImplT)
 *
 * Description:
 * A base implementation for the IConfigurationItem interface.
 *
 * @created	2002-07-17 10:56
 * @author	MickeM <mickem@medin.nu>
 */
#define CConfigurationItemImpl CConfigurationItemImplT<IConfigurationItem>
template <class T>
class CConfigurationItemImplT : public T {
private:
	IConfigurationDialogTemplate *m_pICDT;
protected:
	IConfigurationHandler *m_pICH;
	// Implemenations
public:
	CConfigurationItemImplT() : m_pICH(NULL), m_pICDT(NULL)
	{}

	virtual ~CConfigurationItemImplT()
	{
		if (m_pICDT)
			delete m_pICDT;
		m_pICDT = NULL;
	}
	
	void onChange() {
		if (m_pICH)
			m_pICH->itemChanged(this);
	}

	int registerIcon(HICON hIcon) {
		if (m_pICH)
			return m_pICH->registerIcon((IConfigurationItem*)this, hIcon);
		return -1;
	}

	void initializeNode(IConfigurationHandler *pICH) {
		if (m_pICH)
			m_pICH->detach((IConfigurationItem*)this);
		m_pICH = pICH;
		if (m_pICH)
			m_pICH->attach((IConfigurationItem*)this);
		if ((getTemplateID() == -1) || (!getTemplate())) {
			if (!m_pICDT)
				m_pICDT = getCfgItmTpl(pICH);
			setTemplateID(registerTemplate(m_pICDT));
		} 
		onInitializeNode();
	}

	void unInitializeNode(IConfigurationHandler *pICH) {
		// TODO: add fault handling code here
		// if (m_pICH != pICH)
		onUnInitializeNode();
		if (m_pICH)
			m_pICH->detach((IConfigurationItem*)this);
		m_pICH = NULL;
	}

	// Helpers
	bool isAttached() {
		return m_pICH != NULL;
	}

	IConfigurationHandler* getHandler() {
		return m_pICH;
	}



	virtual string getStepRC(bool bRecursive) {
		return "";
	}
	virtual bool saveStepRC() {
		return false;
	}
	
	virtual void show() {
		activateTemplate(getTemplateID());
		onActivateTemplate(getTemplate());
		if (getTemplate())
			getTemplate()->loadData();
	}
	virtual void hide() {
		if (getTemplate())
			getTemplate()->clearDataHandlers();

		onDeActivateTemplate(getTemplate());
		deActivateTemplate(getTemplateID());
	}
	
	virtual IConfigurationItem* addNewChild(string type) {
		return NULL; 
	}

	virtual bool canRename() {
		return false; 
	}

	virtual bool canDeleteItem() {
		return false; 
	}

	virtual bool deleteItem() {
		return false; 
	}

	virtual void onInitializeNode() {
	}

	virtual void onUnInitializeNode() {
	}

	int getIcon() {
		return -1;
	}

	// TODO: make this pure virtual!!
	virtual int getTemplateID() {return -1; };
	virtual void setTemplateID(int iTplId) {};
	virtual IConfigurationDialogTemplate* getCfgItmTpl(IConfigurationHandler *pICH) {return NULL; };


	//////////////////////////////////////////////////////////////////////////
	// New Virtual functions
	virtual void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {}
	virtual void onDeActivateTemplate(IConfigurationDialogTemplate *pTpl) {}

	//////////////////////////////////////////////////////////////////////////
	// Helper functions

	IConfigurationDialogTemplate *getTemplate() {
		IConfigurationHandler* pICH = getHandler();
		if (!pICH) {
			STD_ICI_ERR(SCE_NO_TEMPLATE, this);
			return NULL;
		}
		return pICH->getTemplate(getTemplateID());
	}

	virtual void activateTemplate(int iTplId) {
		IConfigurationHandler* pICH = getHandler();
		if (!pICH) {
			STD_ICI_ERR(SCE_NO_TEMPLATE, this);
			return;
		}
		pICH->activateTemplate(iTplId);
	}

	virtual void deActivateTemplate(int iTplId) {
		IConfigurationHandler* pICH = getHandler();
		if (!pICH) {
			STD_ICI_ERR(SCE_NO_TEMPLATE, this);
			return;
		}
		pICH->deActivateTemplate(iTplId);
	}

	virtual int registerTemplate(IConfigurationDialogTemplate *pTempl) {
		IConfigurationHandler* pICH = getHandler();
		if (!pICH) {
			STD_ICI_ERR(SCE_NO_TEMPLATE, this);
			return -1;
		}
		return pICH->registerTemplate(pTempl);
	}


};

/**
 *
 * IConfigurationHandler
 *
 * Description:
 * An interface for the dialog handler (register ICONs etc with this IF)
 *
 * @created	2002-07-17 10:51
 * @author	MickeM <mickem@medin.nu>
 */
class IConfigurationHandler {
public:
	IConfigurationHandler() {}
	virtual ~IConfigurationHandler() {}
	virtual void itemChanged(IConfigurationItem *pItem) = 0;
	virtual int registerIcon(IConfigurationItem *pItem, HICON hIcon) = 0;
	virtual bool detach(IConfigurationItem *pItem) = 0;
	virtual bool attach(IConfigurationItem *pItem) = 0;
	virtual int registerTemplate(IConfigurationDialogTemplate *pTempl) = 0;
	virtual IConfigurationDialogTemplate* getTemplate(int iDT) = 0;
	virtual void activateTemplate(int iDT) = 0;
	virtual void deActivateTemplate(int iDT) = 0;
	virtual void setHelpText(string text) = 0;

};

#define CConfigurationHandlerImpl CConfigurationHandlerImplT<IConfigurationHandler>
template <class T>
class CConfigurationHandlerImplT : public T {
private:
	typedef list<IConfigurationItem*> LIST_ICI;
	typedef map<IConfigurationItem*, int> MAP_ICI_I;
	typedef vector<IConfigurationDialogTemplate*> VECTOR_ICDT;
	LIST_ICI m_nodeList;
	MAP_ICI_I m_nodeIconList;
	VECTOR_ICDT m_vectDlgTempl;
	IConfigurationDialogTemplate *m_pActiveTemplate;

public:
	CConfigurationHandlerImplT() : m_pActiveTemplate(NULL) {}
	virtual ~CConfigurationHandlerImplT() {
	}

	virtual void onItemChanged(IConfigurationItem *pItem) = 0;
	virtual int registerIcon(HICON hIcon) = 0;
	virtual void unRegisterIcon(int iID) = 0;
	virtual void onActiveateTemplate() = 0;
	virtual void onDeActiveateTemplate() = 0;
	virtual HWND getParrentHandle() = 0;
	virtual void onAttach(IConfigurationItem *pItem) = 0;
	virtual void onDetach(IConfigurationItem *pItem) = 0;

	void itemChanged(IConfigurationItem *pItem) {
		/*
		LIST_ICI::iterator it = m_nodeList.find(pItem);
		if (it == m_nodeList.end()) {
			STD_ICI_ERR("Item not attached", pItem);
			return;
		}
		*/
		onItemChanged(pItem);
	}

	int registerIcon(IConfigurationItem *pItem, HICON hIcon) {
		int iID = registerIcon(hIcon);
		if (iID == -1) {
			STD_ICI_ERR(SCE_BAD_ICON, pItem);
			return -1;
		}
		MAP_ICI_I::const_iterator it = m_nodeIconList.find(pItem);
		if (it != m_nodeIconList.end()){
			STD_ICI_ERR(SCW_UNSUPPORTED, pItem);
			return -1;
		}
		m_nodeIconList.insert(MAP_ICI_I::value_type(pItem, iID));
		return iID;
	}

	bool attach(IConfigurationItem *pItem) {
		/*
		LIST_ICI::iterator it = m_nodeList.find(pItem);
		if (it != m_nodeList.end()) {
			STD_ICI_ERR("Item already attached", pItem);
			return false;
		}
		*/
		m_nodeList.push_back(LIST_ICI::value_type(pItem));
		onAttach(pItem);
		return true;
	}

	bool detach(IConfigurationItem *pItem) {
		/*
		LIST_ICI::iterator it = m_nodeList.find(pItem);
		if (it == m_nodeList.end()) {
			STD_ICI_ERR("Item not attached", pItem);
			return false;
		}
		*/
		onDetach(pItem);
//		m_nodeList.erase(pItem);

		MAP_ICI_I::iterator it2 = m_nodeIconList.find(pItem);
		if (it2 == m_nodeIconList.end()){
			STD_ICI_ERR(SCE_BAD_ICON, pItem);
		} else {
			unRegisterIcon((*it2).second);
		}
		return true;

		// TODO: add templaets to list, and remove them at detach (also set them to null after remove)
	}

	int registerTemplate(IConfigurationDialogTemplate *pTempl) {
		// TODO: add templaets to list, and remove them at detach (also set them to null after remove)
		if (!pTempl)
			return -1;
		int iDT = m_vectDlgTempl.size();
		m_vectDlgTempl.push_back(pTempl);
		return iDT;
	}

	IConfigurationDialogTemplate* getTemplate(int iDT) {
		if ((iDT < 0)||(iDT >= m_vectDlgTempl.size())) {
			scErrorMessageSimpleNone(SCE_TEMPLATE_OUT_OF_RANGE, iDT);
			return NULL;
		}
		IConfigurationDialogTemplate *pTpl = m_vectDlgTempl[iDT];
		if (!pTpl)
			return NULL;
		pTpl->createDialog(getParrentHandle());
		return pTpl;
	}

	void activateTemplate(int iDT) {
		m_pActiveTemplate = getTemplate(iDT);
		onActiveateTemplate();
	}

	void deActivateTemplate(int iDT) {
		// TODO: add code for error handeling here
		onDeActiveateTemplate();
		m_pActiveTemplate = NULL;
	}

	IConfigurationDialogTemplate* getActiveTemplate() {
		return m_pActiveTemplate;
	}

	bool hasActiveTemplate() {
		return m_pActiveTemplate != NULL;
	}

};


class IDataHandler;
class IConfigurationDialogTemplate {
public:
	IConfigurationDialogTemplate(IConfigurationHandler *pHandler) {}
	virtual ~IConfigurationDialogTemplate() {}

	// Window functions
	virtual void resize(int width, int height) = 0;
	virtual void move(int x, int y) = 0;
	virtual void createDialog(HWND hWndParrent) = 0;
	virtual void destroyDialog() = 0;
	virtual void show() = 0;
	virtual void hide() = 0;
	virtual void onApply() = 0;
	virtual void onOk() = 0;
	virtual void onCancel() = 0;

	virtual bool hasApply() = 0;
	virtual bool hasOk() = 0;
	virtual bool hasCancel() = 0;

	virtual void saveData() = 0;
	virtual void loadData() = 0;
	virtual HWND getHWnd() = 0;

	//////////////////////////////////////////////////////////////////////////
	// DataHandler functions
	virtual void addDataHandler(IDataHandler *pHandler) = 0;
	virtual bool removeDataHandler(IDataHandler *pHandler) = 0;
	virtual void clearDataHandlers() = 0;
};

class IDataHandler {
public:
	IDataHandler() {}
	virtual ~IDataHandler() {}

	virtual void removeTemplteIF(IConfigurationDialogTemplate *pTpl) = 0;
	virtual void addTemplteIF(IConfigurationDialogTemplate *pTpl) = 0;
	virtual void set() = 0;
	virtual void get() = 0;
};

#endif // !defined(AFX_ICONFIGURATIONITEM_H__2494F18E_0839_4566_828F_A3BCC9FA7101__INCLUDED_)



