// IConfigurationItem.cpp: implementation of the IConfigurationItem class.
//
//////////////////////////////////////////////////////////////////////

#include "IConfigurationItem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IConfigurationItem::IConfigurationItem()
{}
IConfigurationItem::~IConfigurationItem()
{}

string IConfigurationHelpers::itos(int i) 
{
	char s[10];
	sprintf(s, "%d", i);
	return (string) s; 
}

int IConfigurationHelpers::stoi(string s) 
{	
	return atoi(s.c_str());	
}



string IConfigurationHelpers::GetTextBoxText(HWND hWnd, UINT uID) {
	if (!IsWindow(hWnd))
		return "";
	HWND hDlgWnd = GetDlgItem(hWnd, uID);
	if (!hDlgWnd)
		return "";
	string ret;
	int len = (WORD) SendMessage(hDlgWnd, EM_LINELENGTH, (WPARAM)0, (LPARAM)0);
	if (len > 0) {
		if (len < 2)
			len = 2;
		char *c = new char[len+1];
		*((LPWORD)c) = len; 
		SendMessage(hDlgWnd, EM_GETLINE, (WPARAM)0, (LPARAM) c);
		c[len] = '\0';
		ret = c;
		delete [] c;
	}
	return ret;
}
void IConfigurationHelpers::SetTextBoxText(HWND hWnd, UINT uID, string str) {
	if (!IsWindow(hWnd))
		return;
	HWND hDlgWnd = GetDlgItem(hWnd, uID);
	if (!hDlgWnd)
		return;
	string ret;
	::SendMessage(hDlgWnd, WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)str.c_str());
}

