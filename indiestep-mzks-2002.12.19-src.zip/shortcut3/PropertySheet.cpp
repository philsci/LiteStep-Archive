// PropertySheet.cpp: implementation of the CMyPropertySheet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdatl.h"
#include <atlbase.h>
#include "PropertySheet.h"
#include "PropertyPage.h"

#define ID_WIZBACK 0x3023
#define ID_APPLY_NOW 0x3021
#define AFX_IDC_TAB_CONTROL 0x3020

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyPropertySheet::CMyPropertySheet()  : 
	m_bInit(false),
	m_fntLogoFont(NULL),
	m_iSizeCount(0)
{
	SetLogoFont("Tahoma",25,FW_BLACK, FALSE, FALSE);
	SetLogoText("Shortcut ]I[");

}

CMyPropertySheet::~CMyPropertySheet()
{
	if (m_fntLogoFont)
		DeleteObject(m_fntLogoFont);
}


void CMyPropertySheet::SetLogoFont(LPCTSTR Name, int nHeight , int nWeight , BYTE bItalic , BYTE bUnderline)
{
	if (m_fntLogoFont)
		DeleteObject(m_fntLogoFont);
	m_fntLogoFont = CreateFont(nHeight, 0, 0, 0, nWeight, bItalic, bUnderline,0,0,0,0,0,0, Name);
}

void CMyPropertySheet::SetLogoText(LPCTSTR lpszText)
{
	m_szLogoText = lpszText;
}

LRESULT CMyPropertySheet::OnPaint(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	PAINTSTRUCT ps;
	HDC dc = ::BeginPaint(m_hWnd, &ps);
	
	RECT rect;
	::GetClientRect(m_hWnd,&rect);
	
	// Get the standard size of the gripper
	rect.left = rect.right-GetSystemMetrics(SM_CXHSCROLL);
	rect.top  = rect.bottom-GetSystemMetrics(SM_CYVSCROLL);
	
	// Draw it
	::DrawFrameControl(dc,&rect, DFC_SCROLL, DFCS_SCROLLSIZEGRIP);
	
	// Save the painted rect so we can invalidate the rect on next OnSize()
	m_rcGripper = rect;
	
	POINT screenOffset = {0, 0};
	::ScreenToClient(m_hWnd,&screenOffset);
	RECT rectTabCtrl;
	::GetWindowRect(::GetDlgItem(m_hWnd, AFX_IDC_TAB_CONTROL), &rectTabCtrl);
	OffsetRect(&rectTabCtrl, screenOffset.x, screenOffset.y);

	RECT rectOk;
	if (::IsWindow(::GetDlgItem(m_hWnd, IDOK)))
		::GetWindowRect(::GetDlgItem(m_hWnd, IDOK), &rectOk);
	else
		::GetWindowRect(::GetDlgItem(m_hWnd, ID_WIZBACK), &rectOk);
	OffsetRect(&rectOk, screenOffset.x, screenOffset.y);
	::SetBkMode(dc,TRANSPARENT);
	
	m_rectText.left = rectTabCtrl.left;
	m_rectText.top = rectOk.top;
	m_rectText.bottom = rectOk.bottom;
	m_rectText.right = rectOk.left;
	HFONT OldFont = (HFONT)::SelectObject(dc,m_fntLogoFont);
	
	// draw text in DC
	COLORREF OldColor = ::SetTextColor(dc,::GetSysColor(COLOR_3DHILIGHT));
	RECT rectShade = m_rectText;
	OffsetRect(&m_rectText, -1, -1);
	int tLen = m_szLogoText.length();
	
	::DrawText(dc, m_szLogoText.c_str(), tLen, &rectShade , DT_SINGLELINE|DT_LEFT|DT_VCENTER);
	::SetTextColor(dc,::GetSysColor(COLOR_3DSHADOW));
	::DrawText(dc, m_szLogoText.c_str(), tLen, &m_rectText, DT_SINGLELINE|DT_LEFT|DT_VCENTER);
	
	// restore old text color
	::SetTextColor(dc, OldColor);
	// restore old font
	::SelectObject(dc,OldFont);
	::EndPaint(m_hWnd,&ps);
	return 0;
}


LRESULT CMyPropertySheet::OnWindowPosChanged(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	static int iCnt = 0;
	LPWINDOWPOS lpWP = (LPWINDOWPOS)lParam;
	HWND hWnd;
	RECT r;
	GetClientRect(&r);
	if (m_iSizeCount++ == 1) {
		::MoveWindow(m_hWnd, m_initRect.left, m_initRect.top, 
			m_initRect.right-m_initRect.left, m_initRect.bottom-m_initRect.top, TRUE);
	}

	int width = (r.right-r.left);
	int height = (r.bottom-r.top);
/*	int width = lpWP->cx;
	int height = lpWP->cy;
*/
	hWnd = GetDlgItem(ID_APPLY_NOW);
	if (hWnd)
		::SetWindowPos(hWnd, NULL,  width-82,  height-34, 75, 23, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
	hWnd = GetDlgItem(IDCANCEL);
	if (hWnd) {
		::SetWindowPos(hWnd, NULL,  width-166,  height-34, 75, 23, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
		::InvalidateRect(hWnd, NULL, NULL);
	}
	hWnd = GetDlgItem(IDOK);
	if (hWnd) {
		::SetWindowPos(hWnd, NULL,  width-247,  height-34, 75, 23, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
		::InvalidateRect(hWnd, NULL, NULL);
	}

	hWnd = GetTabControl();
	if (hWnd)
		::SetWindowPos(hWnd, NULL,  10,  30, width - 12, height - 45, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
	::GetClientRect(hWnd, &r);
	hWnd = (HWND)SendMessage(PSM_GETCURRENTPAGEHWND, (WPARAM)0, (LPARAM)0);
	if (hWnd)
		::SetWindowPos(hWnd, NULL,  0,  0, r.right-r.left-8, r.bottom-r.top-27, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);

	InvalidateRect(&m_rcGripper, TRUE);
	OffsetRect(&m_rectText, -1, -1);
	InflateRect(&m_rectText, 2, 2);
	InvalidateRect(&m_rectText, TRUE);

	return 0;
}

LRESULT CMyPropertySheet::OnNcHitTest(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	DWORD ht = DefWindowProc(UMsg, wParam, lParam);
	if(ht == HTCLIENT) {
		RECT tmp = m_rcGripper;
		POINT pt;pt.x = 0; pt.y=0;
		::ClientToScreen(m_hWnd, &pt);
		OffsetRect(&tmp, pt.x, pt.y);
		pt.x = LOWORD(lParam);
		pt.y = HIWORD(lParam);
        if(::PtInRect(&tmp, pt))
			return HTBOTTOMRIGHT;
	}
	return ht;
}

LRESULT CMyPropertySheet::OnInitDialog(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled)
{
	::MoveWindow(m_hWnd, m_initRect.left, m_initRect.top, 
		m_initRect.right-m_initRect.left, m_initRect.bottom-m_initRect.top, TRUE);
	return 0;
}

// override the callback procedure and add a pre-creation message
// handler so that we can change the window style
int CALLBACK CMyPropertySheet::PropSheetCallback(HWND hWnd, UINT uMsg, LPARAM lParam)
{
	// dialog template is available and changeable pre-creation
	if(uMsg == PSCB_PRECREATE) {
		LPDLGTEMPLATE lpDT = (LPDLGTEMPLATE)lParam;
		lpDT->style |= WS_POPUP|WS_THICKFRAME;
	} else if (uMsg == PSCB_INITIALIZED) {
			ATLASSERT(hWnd != NULL);
			BASE_T* pT = (BASE_T*)_Module.ExtractCreateWndData();
			// subclass the sheet window
			pT->SubclassWindow(hWnd);
			// remove page handles array
			pT->_CleanUpPages();
//			::InvalidateRect(hWnd, NULL, NULL);
			::SendMessage(pT->m_hWnd, WM_INITDIALOG, 0, 0);
		return 0;
	}
	return BASE_T::PropSheetCallback(hWnd, uMsg, lParam);;
}

void CMyPropertySheet::changeWnd()
{
	m_psh.pfnCallback = CMyPropertySheet::PropSheetCallback;
}
void CMyPropertySheet::setApplyEnabled(bool bEnabled)
{
	::EnableWindow(GetDlgItem(ID_APPLY_NOW), bEnabled?TRUE:FALSE);
}
