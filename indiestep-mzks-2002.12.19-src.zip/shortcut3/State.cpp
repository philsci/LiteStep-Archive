// State.cpp: implementation of the CState class.
//
//////////////////////////////////////////////////////////////////////

#include "State.h"
#include "ShortcutFactory.h"
#include "string_util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFG_ITM_SET_TEMPLATE_CPP(CCIState, CCDTState);


CState::CState(CShortcutFactory *sf) 
	: m_currentAction(NULL), 
	m_hover(NULL), 
	m_left(NULL), 
	m_middle(NULL), 
	m_normal(NULL),
	m_drop(NULL),
	m_right(NULL),
	m_pFactory(sf)
{
	m_iCommandArray[S_CMD_ALPHA]	= m_pFactory->getStringID("alphaLevel");
	m_iCommandArray[S_CMD_CMDARG]	= m_pFactory->getStringID("commandArgument");
	m_iCommandArray[S_CMD_COMMAND]	= m_pFactory->getStringID("command");
	m_iCommandArray[S_CMD_ICON]		= m_pFactory->getStringID("icon");
	m_iCommandArray[S_CMD_IMAGE]	= m_pFactory->getStringID("image");
	m_iCommandArray[S_CMD_SOUND]	= m_pFactory->getStringID("sound");
}

CState::~CState()
{
	if (m_hover)
		delete m_hover;
	if (m_normal)
		delete m_normal;
	if (m_right)
		delete m_right;
	if (m_left)
		delete m_left;
	if (m_middle)
		delete m_middle;
	if (m_drop)
		delete m_drop;
}


void CState::exec(ShortcutActions action, HWND hWnd, string commandArguments)
{
	CAction *pAction = getAction(action, false);
	if (!pAction)
		return;
	string buffer;
	if (pAction->getUseDefSound())
		m_pFactory->playSound(action);
	else if (!pAction->getSound().empty())
		::PlaySound(pAction->getSound().c_str(), NULL, SND_FILENAME | SND_ASYNC | SND_NOWAIT);	
		
	if (!pAction->getCommand().empty()) {
		string::size_type pos = pAction->getCommand().find(' ');
		if (pos == pAction->getCommand().npos)
			buffer = "[" + pAction->getCommand() + "] " + commandArguments + " " + pAction->getArgument();
		else
			buffer = "[" + pAction->getCommand().substr(0,pos) + "] " + pAction->getCommand().substr(pos) + commandArguments + " " + pAction->getArgument();
		LSExecute(hWnd, buffer.c_str(), SW_SHOWDEFAULT);
	}
}

CAction* CState::getAction(ShortcutActions newAction, bool bCreate) {
	switch (newAction) {
	case ssNormal:
		if ((!m_normal)&&(bCreate)) {
			m_normal = new CAction(newAction);
			m_currentAction = m_normal;
		}
		return m_normal;
	case ssHover:
		if ((!m_hover)&&(bCreate))
			m_hover = new CAction(newAction);
		return m_hover;
	case ssRight:
		if ((!m_right)&&(bCreate)) 
			m_right = new CAction(newAction);
		return m_right;
	case ssLeft:
		if ((!m_left)&&(bCreate))
			m_left = new CAction(newAction);
		return m_left;
	case ssMiddle:
		if ((!m_middle)&&(bCreate))
			m_middle = new CAction(newAction);
		return m_middle;
	case ssDrop:
		if ((!m_drop)&&(bCreate))
			m_drop = new CAction(newAction);
		return m_drop;
	}
	return NULL;
}

void CState::setCommand(ShortcutActions action, string command, string arguments)
{
	CAction *pAction = getAction(action);
	if (!pAction)
		return;
	if (command == "!none")
		pAction->setCommand("");
	else {
		pAction->setCommand(command);
		if (!arguments.empty())
			pAction->setArgument(arguments);
	}
}

void CState::setImage(ShortcutActions action, string command)
{
	CAction *pAction = getAction(action);
	if (!pAction)
		return;
	if (command == ".none")
		pAction->getBitmap()->setImageFile("");
	else
		pAction->getBitmap()->setImageFile(command);
}

void CState::setSound(ShortcutActions action, string sound)
{
	CAction *pAction = getAction(action);
	if (!pAction)
		return;
	if (sound.find(".def") != string.npos) 
		pAction->setUseDefSound(true);
	else {
		pAction->setUseDefSound(false);
		pAction->setSound(sound);
	}
}

void CState::setCommandArgument(ShortcutActions action, string command)
{
	CAction *pAction = getAction(action);
	if (!pAction)
		return;
	pAction->setArgument(command);
}
void CState::setAlpha(ShortcutActions action, int level)
{
	CAction *pAction = getAction(action);
	if (!pAction)
		return;
	pAction->getBitmap()->setAlphaLevel(level);
}



CState::ShortcutActions CState::getAction(LPCSTR str)
{
	if (stricmp(str, "hover") == 0)
		return CState::ssHover;
	else if (stricmp(str, "left") == 0)
		return CState::ssLeft;
	else if (stricmp(str, "right") == 0)
		return CState::ssRight;
	else if (stricmp(str, "middle") == 0)
		return CState::ssMiddle;
	else if (stricmp(str, "drop") == 0)
		return CState::ssDrop;
	else if (stricmp(str, "drag") == 0)
		return CState::ssDrop;
	else if (stricmp(str, "normal") == 0)
		return CState::ssNormal;
	return CState::ssNone;
}


string CState::getActionName(CState::ShortcutActions action)
{
	if (action==ssNormal)
		return "normal";
	else if (action==ssHover)
		return "hover";
	else if (action==ssLeft)
		return "left";
	else if (action==ssRight)
		return "right";
	else if (action==ssMiddle)
		return "middle";
	else if (action==ssDrop)
		return "drag";
	else 
		return "Unknown";
}


CState::ShortcutActions CState::getAction(string str)
{
	return getAction(str.c_str());
}

bool CState::execBang(int iCmd, string szArg)
{
	ShortcutActions action = CState::getAction(m_pFactory->getIDString(iCmd));
	if (action == ssNone)
		return false;
	iCmd = m_pFactory->getStringID(GetToken(szArg, false));
	if (iCmd == m_iCommandArray[S_CMD_IMAGE]) {
		setImage(action, szArg);
	} else if (iCmd == m_iCommandArray[S_CMD_COMMAND]) {
		string cmd = GetToken(szArg, false);
		setCommand(action, cmd, szArg);
	} else if (iCmd == m_iCommandArray[S_CMD_CMDARG]) {
		setCommand(action, "", szArg);
	} else if (iCmd == m_iCommandArray[S_CMD_SOUND]) {
		setSound(action, GetToken(szArg, false));
	} else if (iCmd == m_iCommandArray[S_CMD_ALPHA]) {
		setAlpha(action, atoi(GetToken(szArg, false).c_str()));
	}
	return true;
}