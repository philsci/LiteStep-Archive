// PropertySheet.h: interface for the CPropertySheet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROPERTYSHEET_H__00D30FEA_584E_4B0A_AA03_0C668FD6FD36__INCLUDED_)
#define AFX_PROPERTYSHEET_H__00D30FEA_584E_4B0A_AA03_0C668FD6FD36__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <list>
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"
//#include "../lsapi/lswinbasex.h"
#include <windows.h>
#include <commctrl.h>

#include <atlbase.h>
#include <atlwin.h>
#include <atlapp.h>
#include <atlframe.h>
#include <atlgdi.h>
#include <atlctrls.h>
#include <atldlgs.h>


using namespace std;
#define BASE_T CPropertySheetImpl<CMyPropertySheet>
class CMyPropertySheet : public BASE_T
{
public:
	
	BEGIN_MSG_MAP(CMyPropertySheet)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	MESSAGE_HANDLER(WM_PAINT, OnPaint)
	MESSAGE_HANDLER(WM_NCHITTEST, OnNcHitTest)
	MESSAGE_HANDLER(WM_WINDOWPOSCHANGED, OnWindowPosChanged)
	CHAIN_MSG_MAP(BASE_T)      
	END_MSG_MAP()

	static int CALLBACK PropSheetCallback(HWND hWnd, UINT uMsg, LPARAM lParam);
	LRESULT OnWindowPosChanged(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	LRESULT OnInitDialog(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	void changeWnd();
	void setApplyEnabled(bool bEnabled);
	LRESULT OnNcHitTest(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	LRESULT OnSize (UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	LRESULT OnPaint(UINT UMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled);
	void SetLogoText(LPCTSTR lpszText);
	void SetLogoFont(LPCTSTR Name, int nHeight = 24, int nWeight = FW_BOLD, BYTE bItalic = true, BYTE bUnderline = false);
	LRESULT WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	CMyPropertySheet();
	virtual ~CMyPropertySheet();

public:
	RECT m_initRect;
protected:
	RECT m_rectText;
	string m_szLogoText;
	HFONT m_fntLogoFont;
	DWORD m_dwStyle;
	PROPSHEETHEADER psh;
	PROPSHEETPAGE *psp;
	RECT m_rcGripper;
	RECT m_rectOK;
	RECT m_rectApply;
	RECT m_rectCancel;
	RECT m_rectTabCtrl;
	bool m_bInit;
	int m_iSizeCount;
};

#endif // !defined(AFX_PROPERTYSHEET_H__00D30FEA_584E_4B0A_AA03_0C668FD6FD36__INCLUDED_)
