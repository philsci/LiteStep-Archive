// SimpleShortcut.cpp: implementation of the CSimpleShortcut class.
//
//////////////////////////////////////////////////////////////////////

#include "SimpleShortcut.h"
#include <string.h>
#include "string_util.h"
#include "ShortcutFactory.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CFG_ITM_SET_TEMPLATE_CPP(CCISimpleShortcut, CCDTSimpleShortcut);

CSimpleShortcut::CSimpleShortcut(CShortcutFactory *sf, string configuration) : IShortcutImpl(sf)
{
	m_iCommandArray[SSC_CMD_IMAGE]	= IShortcut::m_pFactory->getStringID("image");
	m_iCommandArray[SSC_CMD_ALPHA]	= IShortcut::m_pFactory->getStringID("alpha");
	parseSimpleConfig(configuration);
}

/**
 *
 * Parses a "simple config line" 
 *
 * Is implemented in the interface (should not be changed)
 *
 */
void CSimpleShortcut::parseSimpleConfig(string szConfigLine)
{
	string x = GetToken(szConfigLine, false);
	string y = GetToken(szConfigLine, false);
	IShortcut::execBang("pos "  + x + " " + y);
	IShortcut::execBang("image " + GetToken(szConfigLine, false));
	IShortcut::execBang("flags " + GetToken(szConfigLine, false));
	IShortcut::execBang("alpha " + GetToken(szConfigLine, false));
}


CSimpleShortcut::~CSimpleShortcut()
{
}

/**
 *
 * Setup images just prior to first repaint.
 *
 */
void CSimpleShortcut::createShortcut()
{
	setupImage(&m_bitmap);
	IShortcutImpl::createShortcut();
}

/**
 *
 * Configuration handler
 *
 * TODO: Add support for reloading images
 *
 */
void CSimpleShortcut::execBang(int iCmd, string szArg)
{
	if (iCmd == m_iCommandArray[SSC_CMD_IMAGE])
		m_bitmap.setImageFile(szArg);
	else if (iCmd == m_iCommandArray[SSC_CMD_ALPHA])
		m_bitmap.setAlphaLevel(IConfigurationHelpers::stoi(szArg));
	else
		IShortcutImpl::execBang(iCmd, szArg);
}


void CSimpleShortcut::onRefreshShortcut()
{
}

void CSimpleShortcut::setBitmap(string bmp)
{
	m_bitmap.setImageFile(bmp);
	setupImage(&m_bitmap);
	if (IShortcutImpl::isCreated())
		applyImage(true);
}

void CSimpleShortcut::setAlphaLevel(int i)
{
	m_bitmap.setAlphaLevel(i);
	setupImage(&m_bitmap);
	if (IShortcutImpl::isCreated())
		applyImage(true);
}

IConfigurationItem* CSimpleShortcut::getConfigurationIF() {
	return new CCISimpleShortcut(this);
}


string CSimpleShortcut::getStepRC(bool bRecursive) {
	string ret = ";\n";
	// Generate flags
	string flg;
	if (!IShortcutImpl::m_bVisible)
		flg += "hide:";
	if (IShortcutImpl::getZOrder().hWnd == HWND_TOPMOST)
		flg += "ontop:";
	if (IShortcutImpl::m_bUseAlphaMap)
		flg += "alphaMap:";
	if (IShortcutImpl::m_bUseAlphaTrans)
		flg += "alphaTrans:";
	if (IShortcutImpl::m_bOpaque)
		flg += "opaque:";
	if (!flg.empty()) {
		flg = flg.substr(0,flg.length()-1);
	}
	ret += "*shortcutEx~ \"" + CSimpleShortcut::getShortName() + "\" \"" + IShortcut::getName() + "\" " 
		+ IConfigurationHelpers::itos(IShortcutImpl::getPosition().x) + " " 
		+ IConfigurationHelpers::itos(IShortcutImpl::getPosition().y) + " "
		+ "\"" + m_bitmap.getImageFile() + "\" ";
	if (!flg.empty())
		ret += flg + " ";
	else
		ret += "\"\" ";
	ret += IConfigurationHelpers::itos(m_bitmap.getAlphaLevel());
	ret += "\n";
	return ret;
}
