

#define BANG_SETTOP			1	// setTopMost
#define BANG_ADDCFG			2	// addConfig
#define BANG_SETVISIBLE		3	// setVisible
#define BANG_SETSTATE		4	// setState
#define BANG_SETACTION		5	// setAction

