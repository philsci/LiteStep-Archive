// IShortcut.cpp: implementation of the IShortcut class.
//
//////////////////////////////////////////////////////////////////////

#include "IShortcut.h"
#include "ShortcutFactory.h"
#include "global.h"
#include "../lsapi/safestr.h"
#include "bang_cmd.h"
#include "typeinfo.h"
#include "string_util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IShortcut::IShortcut(CShortcutFactory *sf) : m_pFactory(sf)
{
	m_iCommandArray[ISC_CMD_CREATE]	= m_pFactory->getStringID("create");
}

IShortcut::~IShortcut()
{
//	IConfigurationDialogImpl::deleteAllDialogItems();
}

/**
 *
 * parseConfig
 *
 * Description:
 * Parses the initial configuration only used by the loader to allow for reading the configuration 
 * prior to creation of shortcuts.
 *
 * @created	2002-6-29 21:56
 * @author	MickeM
 */
void IShortcut::parseConfig()
{
	for (list<string>::iterator it = m_lstConfig.begin(); it != m_lstConfig.end();it++) {
		execBang((*it));
	}
	m_lstConfig.clear();
}

/**
 *
 * preAddConfig
 *
 * Description:
 * Adds configuration information prior to shortcut creation.
 *
 * @created	2002-06-29 22:09
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcut::preAddConfig(string str)
{
	m_lstConfig.push_back(str);
}

/**
 *
 * execute a bangcommand
 *
 * @param command	The command identifier
 * @param szArg		a (if avalible) string argument
 * @param iArg		a (if pressent) integer argument
 *
 * Is implemented in the interface
 * TODO fix this!!
 */
void IShortcut::execBang(int iCmd, string szAarg)
{
	if (iCmd == m_iCommandArray[ISC_CMD_CREATE]) {
		createShortcut();
	}
}

/**
 *
 * execBang
 *
 * Description:
 * Wrapper for bang commands, extracts the first argument, looks it up and executes the bang.
 *
 * @created	2002-06-29 22:06
 * @author	MickeM <mickem@medin.nu>
 */
void IShortcut::execBang(string szData)
{
	string szCmd = GetToken(szData, false);
	execBang(m_pFactory->getStringID(szCmd), szData);
}

/**
 *
 * setName
 *
 * Description:
 * Rename the shortcut and notify the core that we have been renamed.
 *
 * @created	2002-08-04 13:25
 * @author	MickeM <mickem@medin.nu>
 */
bool IShortcut::setName(string name) 
{	
	if (!m_pFactory)
		return false;
	m_pFactory->renameShortcut(m_sName, name, this);
	m_sName = name;	
	return true;	
}
