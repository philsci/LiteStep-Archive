// Action.cpp: implementation of the CAction class.
//
//////////////////////////////////////////////////////////////////////

#include "Action.h"
#include "State.h"
#include "ShortcutFactory.h"
#include "IShortcutImpl.h"
/*
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
*/
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFG_ITM_SET_TEMPLATE_CPP(CCIAction, CCDTAction);

CAction::CAction(int action)
	: m_action(action),
	m_bUseDefaultSound(false)
{}

CAction::~CAction()
{

}

string CAction::getActionName() {
	return CState::getActionName(static_cast<CState::ShortcutActions>(getAction()));
}

bool CCIAction::hasAlpha() {
	return (pShortcut->getFlagValue("alphaMap")||pShortcut->getFlagValue("alphaTrans"));
}

void CCIAction::refreshImage() {
	pShortcut->applyImage(true);
}
