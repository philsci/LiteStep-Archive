// IShortcutImpl.h: interface for the IShortcutImpl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IShortcutImpl_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_)
#define AFX_IShortcutImpl_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// SC3 Includes
#include "Messages.h"
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"
#include "IShortcut.h"
#include <string>
#include "Bitmap.h"
#include "string_util.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "ShortcutFactory.h"
#include <limits.h>
using namespace std;

#define WM_SC3_RECREATE_WINDOW WM_USER + 1234

#define IS_IF_TOKEN_DO(action, empty) \
if (GetToken(nextToken, token, &nextToken, false)) { \
		if (!StrIPos(token, empty)) \
			action; \
	} else \
		return; 

#ifndef WS_EX_LAYERED
#define WS_EX_COMPOSITED        0x02000000L
#define WS_EX_NOACTIVATE        0x08000000L
#define WS_EX_LAYERED           0x00080000L
#define LWA_COLORKEY            0x00000001L
#define LWA_ALPHA               0x00000002L
#define ULW_ALPHA               0x00000002L
#endif // WS_EX_LAYERED

#ifndef AC_SRC_ALPHA
#define AC_SRC_ALPHA	0x01 
#endif

#define ISCI_CMD_POS		0
#define ISCI_CMD_FLAG		1
#define ISCI_CMD_FLAGS		2
#define ISCI_CMD_PARRENT	3
#define ISCI_CMD_ZORDER		4
#define ISCI_CMD_SHOW		5

#define ISCI_CMD_COUNT		6

class CShortcutFactory;
class IConfigurationDlgItemParrent;
class IConfigurationDlgItemZOrder;
class IShortcutImpl : public IShortcut, public Window
{
friend IConfigurationDlgItemParrent;
friend IConfigurationDlgItemZOrder;
public:
	typedef BOOL (WINAPI *lpfnUpdateLayeredWindow)(HWND hwnd, HDC hdcDst, POINT *pptDst, SIZE *psize, HDC hdcSrc, POINT *pptSrc, COLORREF crKey, BLENDFUNCTION *pblend, DWORD dwFlags);
	typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)(HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags);
	typedef struct SHORTCUTORWINDOW {
		string scName;
		string wndClass;
		string wndTitle;
		HWND hWnd;
		int data;
		bool bData;
		struct SHORTCUTORWINDOW() {
			hWnd = NULL;
			data = 0;
			bData = false;
			scName = "";
			wndClass = "";
			wndTitle = "";
		}
		struct SHORTCUTORWINDOW(const struct SHORTCUTORWINDOW &o) {
			scName = o.scName;
			wndClass = o.wndClass;
			wndTitle = o.wndTitle;
			hWnd = o.hWnd;
			data = o.data;
			bData = o.bData;
		}
		bool operator== (const struct SHORTCUTORWINDOW &o) const
		{
			if (scName != o.scName)
				return false;
			if (wndClass != o.wndClass)
				return false;
			if (wndTitle != o.wndTitle)
				return false;
			if (hWnd != o.hWnd)
				return false;
			if (data != o.data)
				return false;
			if (bData != o.bData)
				return false;
			return true;
		}
	} SHORTCUTORWINDOW;

public:
	void reCreateShortcutRemote();
	bool isCloseTo(int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY);
	virtual const bool isCreated() const;
	int getFlagCount();
	virtual void execBang(int iCms, string szAarg);
	virtual void createShortcut();
	void reCreateShortcut();

	IShortcutImpl(CShortcutFactory *sf);
	virtual ~IShortcutImpl();
	void MoveShortcut(POINT pos);
	void MoveShortcut(POSITION pos);
	void MoveShortcut(int x, int y);
	void MoveShortcutDelta(int x, int y);
	void onShow();
public:
	void setParrentWindow(SHORTCUTORWINDOW parrent);
	SHORTCUTORWINDOW getParrentWindow() {
		return m_parrentWindow;
	}
	void setCaption(bool bCaption);
	void setZOrder(SHORTCUTORWINDOW zOrder);
	SHORTCUTORWINDOW getZOrder() {
		return m_zOrderWindow;
	}
	void setPosition(POSITION pos);
	POSITION getPosition() {
		return m_position;
	}
	void setupImage(CLSBitmap *bmp);
	void applyImage(bool refresh);
	virtual bool getFlagValue(string key) {
		if (key == "hide")
			return (!m_bVisible);
		if (key == "alphaMap")
			return m_bUseAlphaMap;
		if (key == "alphaTrans")
			return m_bUseAlphaTrans;
		if (key == "opaque")
			return m_bOpaque;
		if (key == "ontop")
			return m_zOrderWindow.hWnd == HWND_TOPMOST;
		scErrorMessageSimpleLocal(SCE_UNKNOWN_FLAG, key.c_str());
		return false;
	}
	virtual void setFlagValue(string key, bool b) {
		if (key == "hide")
			m_bVisible = !b;
		else if (key == "alphaMap") {
			if (m_bUseAlphaMap == b)
				return;
			m_bUseAlphaMap = b;
			m_bUseAlphaTrans = false;
			if (isCreated()) 
				reCreateShortcutRemote();
		} else if (key == "alphaTrans") {
			if (m_bUseAlphaTrans == b)
				return;
			m_bUseAlphaTrans = b;
			m_bUseAlphaMap = false;
			if (isCreated()) 
				reCreateShortcutRemote();
		} else if (key == "opaque") {
			if (m_bOpaque == b)
				return;
			m_bOpaque = b;
			if (isCreated()) 
				reCreateShortcutRemote();
		} else if (key == "ontop") {
			SHORTCUTORWINDOW zOrder;
			if (b) {
				if (m_zOrderWindow.hWnd == HWND_TOPMOST)
					return;
				zOrder.hWnd = HWND_TOPMOST;
			} else {
				if (m_zOrderWindow.hWnd != HWND_TOPMOST)
					return;
				zOrder.hWnd = HWND_NOTOPMOST;
			}
			setZOrder(zOrder);
		} 
	}

protected:
	bool findWindow(SHORTCUTORWINDOW &scOrWnd);
	virtual void windowProc(Message& message);
	virtual void onCreate(Message& message);
	virtual void onDisplayChange(Message& message);
	virtual void onEraseBkgnd(Message& message);
	virtual void onEndSession(Message& message);
	virtual void onSysCommand(Message& message);
	virtual void onReCreateWindow(Message& message);

protected:
	POSITION m_position;
	SIZE m_curSize;
	int m_iCommandArray[ISCI_CMD_COUNT];
	bool m_bOpaque;
	bool m_bUseAlphaTrans;
	bool m_bUseAlphaMap;
	bool m_bIsMoving;
	bool m_bCaptioned;
	bool m_bKeepOnDesktop;
	bool m_bVisible;
	bool m_bVisibleSet;

public:
	POINT m_curPos;

protected:
	IConfigurationItem::LST_CHILD m_cachedChildList;
	SHORTCUTORWINDOW m_parrentWindow;
	SHORTCUTORWINDOW m_zOrderWindow;
	lpfnUpdateLayeredWindow UpdateLayeredWindow;
	lpfnSetLayeredWindowAttributes SetLayeredWindowAttributes;
	HDC m_hPaintDC;
private:
	CLSBitmap *m_pBitmap;
public:
	inline const HWND getHWnd() 
	{
		if (!Window::handle())
			createShortcut();
		return Window::handle();
	};
};


//////////////////////////////////////////////////////////////////////////
// 




#endif // !defined(AFX_IShortcutImpl_H__1EAFADE1_94C8_4155_A83A_20D3779F5268__INCLUDED_)
