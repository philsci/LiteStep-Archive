// NormalShortcut.h: interface for the CNormalShortcut class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NORMALSHORTCUT_H__51C27FB8_EB7C_4ABB_9C89_BA763EE89354__INCLUDED_)
#define AFX_NORMALSHORTCUT_H__51C27FB8_EB7C_4ABB_9C89_BA763EE89354__INCLUDED_

// WTL/ATL Includes
#include <AtlCtrls.h>
// STL Includes
#include <map>
#include <list>
#include <string>
// SC3 Includes
#include "IShortcut.h"
#include "State.h"
#include "IShortcutImpl.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "CFGTemplates.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define SC_CMD_TOOLTIP		0
#define SC_CMD_IMAGES		1
#define SC_CMD_COMMANDS		2
#define SC_CMD_SOUNDS		3
#define SC_CMD_SLAVE		4
#define SC_CMD_FLAG			5
#define SC_CMD_MOVEBTN		6
#define SC_CMD_MOVEBTNS		7
#define SC_CMD_SETACTION	8
#define SC_CMD_ALPHAS		9
#define SC_CMD_COUNT		10

class CNormalShortcut : public IShortcutImpl
{
public:
	typedef struct {
		string wndClass;
		string wndCaption;
		string scName;
		IShortcut *sc;
		HWND hWnd;
	} TYPE_SLAVES;
	typedef list<TYPE_SLAVES> LST_SLAVES;
public:
	TYPE_SLAVES recreateSlave(TYPE_SLAVES slave);
	void onRefreshShortcut();
	void AddSlave(string name, string wndClass, string wndTitle);
	void execBang(int iCmd, string szArg);
	void execAction(CState::ShortcutActions action, string arguments = "");
	void setAction(CState::ShortcutActions newAction, bool refresh = true);
	CState* getState();
	string getStepRC(bool bRecursive);
	CNormalShortcut(CShortcutFactory *sf, string configuration);
	virtual ~CNormalShortcut();
public:
	// Properties:
	void setToolTip(string s) {
		// TODO: change the actual tooltip here (not just the string)
		m_sToolTip = s;
	}
	string getToolTip() {
		return m_sToolTip;
	}
	void setMoveButton(int mb) {
		m_iMoveButton = mb;
	}
	int getMoveButton() {
		return m_iMoveButton;
	}
	void setSlaves(LST_SLAVES slaves) {
		m_lstSlaves = slaves;
		for (LST_SLAVES::iterator it = m_lstSlaves.begin(); it != m_lstSlaves.end();it++) {
			(*it) = recreateSlave((*it));
		}
		m_bHaveSlaves = m_lstSlaves.size() > 0;
	}
	LST_SLAVES getSlaves() {
		return m_lstSlaves;
	}
protected:
	virtual void createShortcut();
	void onNotify(Message& message);
	void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onMouseMove(Message& message);
	void onMouseActivate(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onShowWindow(Message& message);

	void onButtonDown(CState::ShortcutActions action, Message& message);
	void onButtonUp(CState::ShortcutActions action);
	void onWindowPosChanging(Message& message);
private:
	bool m_bHaveSlaves;
	LST_SLAVES m_lstSlaves;
	const LEAVE_TIMER_ID;
	string m_sToolTip;
	int m_iMoveButton;
	UINT fLeaveTimer;
	CState::ShortcutActions m_currentAction;
	int m_iCommandArray[SC_CMD_COUNT];
	CState m_state;
	bool m_bNoGrabFocus;

public:
	///////////////////////////////////////////////////////////////////////
	// IShortcut
	//
	static string getShortName(){ return "normal";	}
	static string getLongName()	{ return "Normal shortcut"; }
	virtual IConfigurationItem* getConfigurationIF();
};


/**
 *
 * CNSSlaves
 *
 * Description:
 * Handles the adding/removing of slaves.
 *
 * @created	2002-07-30 11:38
 * @author	MickeM <mickem@medin.nu>
 */
template <class TTarget, class TType>
class CNSSlaves : public IDataHandlerImpl {
private:
	TTarget *pt2Object;
	void (TTarget::*fptSetter)(TType);
	TType (TTarget::*fptGetter)();
public:
	CNSSlaves(TTarget *_pt2Object, void (TTarget::*_fptSetter)(TType), TType (TTarget::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CNSSlaves() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SLAVE_LIST);
		lvCtrl.DeleteAllItems();

		TType sc = (*pt2Object.*fptGetter)();
		for (TType::iterator it = sc.begin(); it != sc.end(); it++) {
			CNormalShortcut::TYPE_SLAVES slv = (*it);
			int id = lvCtrl.AddItem(0, 0, slv.scName.c_str());
			lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, slv.wndClass.c_str(), -1, 0, 0, 0);
			lvCtrl.SetItem(id, 2,LVIF_TEXT|LVIF_DI_SETITEM, slv.wndCaption.c_str(), -1, 0, 0, 0);
		}
		if (!pt2Object)
			return;
		if (!pt2Object->getFactory())
			return;
		CShortcutFactory::T_LST_SC lst = pt2Object->getFactory()->getShortcutList();
		::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
		for (CShortcutFactory::T_LST_SC::iterator sit = lst.begin(); sit!=lst.end();sit++) {
			if (!(*sit)->getName().empty())
				::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_ADDSTRING, (WPARAM)0, (LPARAM)(*sit)->getName().c_str());
		}
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		TType sc;

		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SLAVE_LIST);
		int id = lvCtrl.GetNextItem(-1, LVNI_ALL);
		if (id != -1) {
			do {
				char *c = new char[1024];
				lvCtrl.GetItemText(id, 0, c, 1023);
				CNormalShortcut::TYPE_SLAVES slv;
				slv.scName = c;
				lvCtrl.GetItemText(id, 1, c, 1023);
				slv.wndClass = c;
				lvCtrl.GetItemText(id, 2, c, 1023);
				slv.wndCaption = c;
				id = lvCtrl.GetNextItem(id, LVNI_ALL);
				sc.push_back(slv);
			} while (id != -1);
		}
		(*pt2Object.*fptSetter)(sc);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		// TODO: Implement this
	}
};

class CCISlaves : public CConfigurationItemImpl {
private:
	CNormalShortcut *pSCImpl;
public:
	CCISlaves(CNormalShortcut *_pSCImpl) : pSCImpl(_pSCImpl) {}
	virtual ~CCISlaves() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("Slaves");
	CI_SET_DESCRIPTION("Manage slaves for this shortcut");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();

	string getStepRC(bool bRecursive) {
		return "";
	}

	CFG_ITM_SET_TEMPLATE_H(CCISlaves, CCDTSlaves);
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CNSSlaves<CNormalShortcut, CNormalShortcut::LST_SLAVES>(pSCImpl, CNormalShortcut::setSlaves, CNormalShortcut::getSlaves));
	}
};



class CCDTSlaves : public CConfigurationDialogTemplateImplT<CCDTSlaves>, public CDialogImpl<CCDTSlaves>
{
private:
	IConfigurationHelpers::CWindowFinder finder;
public:
	enum { IDD = IDD_SLAVE_CFG };
	BEGIN_MSG_MAP(CCDTSlaves);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	if (finder.ProcessWindowMessage(hWnd, uMsg, wParam, lParam, lResult))  
		 return TRUE;
	COMMAND_HANDLER(IDC_BTN_ADD, BN_CLICKED, onAdd); 
	COMMAND_HANDLER(IDC_BTN_DEL, BN_CLICKED, onDel); 
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	COMMAND_HANDLER(IDC_SEL_SC, CBN_EDITCHANGE, onRefresh);
	COMMAND_HANDLER(IDC_SEL_SC, CBN_SELCHANGE, onRefresh);
	COMMAND_HANDLER(IDC_SEL_SC, CBN_SELENDOK, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), LVN_ODSTATECHANGED, onRefresh);
	NOTIFY_HANDLER(IDC_SLAVE_LIST, LVN_ODSTATECHANGED, onRefresh);
	NOTIFY_HANDLER(IDC_SLAVE_LIST, NM_CLICK, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTSlaves>);
	END_MSG_MAP();
	CCDTSlaves(CCISlaves *_pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTSlaves>(pICH),
		finder(_Module.GetModuleInstance(), IDC_GRABBER, IDC_WND_CLS, IDC_WND_CAP, IDC_GRABBER)
	{
		addHelpText(IDC_NA, "Shortcut will be its own layer.");
		addHelpText(IDC_DESKTOP, "Put the shortcut on the desktop layer.");
		addHelpText(IDC_SC, "Put the shortcut on the shortcut layer.");
		addHelpText(IDC_USE_SC, "Use another shortcut as a layer.");
		addHelpText(IDC_USE_WND, "Use another window as a layer.");
	}
	virtual ~CCDTSlaves() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SLAVE_LIST);
		lvCtrl.AddColumn("Shortcut", 0);
		lvCtrl.AddColumn("Window Class", 1);
		lvCtrl.AddColumn("Window Caption", 2);
		lvCtrl.m_hWnd = NULL;
		return 0;
	}

	HRESULT onAdd(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SLAVE_LIST);
		char *c = new char[1024];
		SendDlgItemMessage(IDC_SEL_SC,  WM_GETTEXT, 1023,  (LPARAM) c);
		string sc = c;
		delete [] c;
		string wndCls;
		string wndCap;
		if (sc.empty()) {
			wndCls = IConfigurationHelpers::GetTextBoxText(m_hWnd, IDC_WND_CLS);
			wndCap = IConfigurationHelpers::GetTextBoxText(m_hWnd, IDC_WND_CAP);
		}
		int id = lvCtrl.AddItem(0, 0, sc.c_str());
		lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, wndCls.c_str(), -1, 0, 0, 0);
		lvCtrl.SetItem(id, 2,LVIF_TEXT|LVIF_DI_SETITEM, wndCap.c_str(), -1, 0, 0, 0);
		lvCtrl.m_hWnd = NULL;
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_SEL_SC, "");
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_WND_CLS, "");
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_WND_CAP, "");
		onRefresh();
		saveData();
		return 0;
	}
	HRESULT onDel(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;

		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SLAVE_LIST);
		if (lvCtrl.GetSelectedCount() == 0) 
			return 0;

		int id = lvCtrl.GetSelectedIndex();
		char *c = new char[1024];
		lvCtrl.GetItemText(id, 0, c, 1023);
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_SEL_SC, c);
		lvCtrl.GetItemText(id, 1, c, 1023);
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_WND_CAP, c);
		lvCtrl.GetItemText(id, 2, c, 1023);
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_WND_CLS, c);

		lvCtrl.DeleteItem(id);


		onRefresh();
		saveData();
		return 0;
	}
	HRESULT onRefresh(int idCtrl, NMHDR *pnmh, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		return 0;
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		return 0;
	}
	void onRefresh() {
		char *c = new char[1024];
		SendDlgItemMessage(IDC_SEL_SC,  WM_GETTEXT, 1023,  (LPARAM) c);
		BOOL bSc = (strlen(c) > 0);
		delete [] c;
		::EnableWindow(GetDlgItem(IDC_WND_CLS), !bSc);
		::EnableWindow(GetDlgItem(IDC_WND_CAP), !bSc);
		::EnableWindow(GetDlgItem(IDC_GRABBER), !bSc);
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SLAVE_LIST);
		if (lvCtrl.GetSelectedCount() > 0)
			::EnableWindow(GetDlgItem(IDC_BTN_DEL), TRUE);
		else
			::EnableWindow(GetDlgItem(IDC_BTN_DEL), FALSE);
		lvCtrl.m_hWnd = NULL;
	}

};


template <class TTarget, class TType>
class CNSMoveButton : public IDataHandlerImpl {
private:
	TTarget *pt2Object;
	void (TTarget::*fptSetter)(TType);
	TType (TTarget::*fptGetter)();
public:
	CNSMoveButton(TTarget *_pt2Object, void (TTarget::*_fptSetter)(TType), TType (TTarget::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CNSMoveButton() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		TType sc = (*pt2Object.*fptGetter)();
		if (sc&MK_RBUTTON) 
			::SendMessage(GetDlgItem(hWnd, IDC_BTN_R), BM_SETCHECK, BST_CHECKED, 0);
		if (sc&MK_LBUTTON) 
			::SendMessage(GetDlgItem(hWnd, IDC_BTN_L), BM_SETCHECK, BST_CHECKED, 0);
		if (sc&MK_MBUTTON) 
			::SendMessage(GetDlgItem(hWnd, IDC_BTN_M), BM_SETCHECK, BST_CHECKED, 0);
		if (sc&MK_CONTROL) 
			::SendMessage(GetDlgItem(hWnd, IDC_KEY_C), BM_SETCHECK, BST_CHECKED, 0);
		if (sc&MK_SHIFT) 
			::SendMessage(GetDlgItem(hWnd, IDC_KEY_S), BM_SETCHECK, BST_CHECKED, 0);
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		TType sc = 0;

		if (::SendMessage(GetDlgItem(hWnd, IDC_BTN_L), BM_GETCHECK, 0, 0) == BST_CHECKED)  
			sc |= MK_LBUTTON;
		if (::SendMessage(GetDlgItem(hWnd, IDC_BTN_M), BM_GETCHECK, 0, 0) == BST_CHECKED) 
			sc |= MK_MBUTTON;
		if (::SendMessage(GetDlgItem(hWnd, IDC_BTN_R), BM_GETCHECK, 0, 0) == BST_CHECKED) 
			sc |= MK_RBUTTON;
		if (::SendMessage(GetDlgItem(hWnd, IDC_KEY_C), BM_GETCHECK, 0, 0) == BST_CHECKED) 
			sc |= MK_CONTROL;
		if (::SendMessage(GetDlgItem(hWnd, IDC_KEY_S), BM_GETCHECK, 0, 0) == BST_CHECKED) 
			sc |= MK_SHIFT;
		(*pt2Object.*fptSetter)(sc);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl) return;
		HWND hWnd = pTpl->getHWnd();
		::SendMessage(GetDlgItem(hWnd, IDC_BTN_L), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_BTN_R), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_BTN_M), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_KEY_C), BM_SETCHECK, BST_UNCHECKED, 0);
		::SendMessage(GetDlgItem(hWnd, IDC_KEY_S), BM_SETCHECK, BST_UNCHECKED, 0);
	}
};

class CCINormalShortcut : public CConfigurationItemImpl {
private:
	CNormalShortcut *pNormalSC;
public:
	CCINormalShortcut(CNormalShortcut *_pNormalSC) : pNormalSC(_pNormalSC) {}
	virtual ~CCINormalShortcut() {}

	// Properties
	CFG_ITM_SET_TEMPLATE_H(CCINormalShortcut, CCDTNormalShortcut);
	CI_SET_VERIFY_ALWAYS(pNormalSC);
	CI_SET_NAME_EX(pNormalSC->getName, pNormalSC->setName);
	CI_SET_DESCRIPTION("This is a normal shortcut...");
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_SET_DELETE_DISABLED();
	CI_CHILD_BEGIN();
	ret.push_back(new CCIState(pNormalSC->getState(), pNormalSC));
	 /*
	CI_CHILD_ADD(CCIState, pNormalSC->getState());
	*/
	CI_CHILD_ADD(CCISlaves, pNormalSC);
	CI_CHILD_ADD(CCIPosition, pNormalSC);
	CI_CHILD_ADD(CCIZOrder, pNormalSC);
	CI_CHILD_ADD(CCIParrent, pNormalSC);
	CCIFlags *pFlags = new CCIFlags(pNormalSC);
	pFlags->addFlag("hide", "Initaly hide shortcut (faster load)", "The shortcut is not created untill it is first visible\nThis will make sure that unnessecary resources are not in use.");
	pFlags->addFlag("alphaMap", "Enable true alpha maps (PNG images).", "Set this to enable PNG alpha maps.\nAlpha maps are true varied transparency.");
	pFlags->addFlag("alphaTrans", "Enable fake alpha transparency (non PNG images).", "Enables fake transparency.\nThis is what was new in w2k and is a semitransparent image.");
	pFlags->addFlag("opaque", "Disable Magic pink. (faster).", "Set this if the image is square. This will improve prefomance.");
	pFlags->addFlag("ontop", "Simpler version of the Z-order handeling. (sc2).", "Sets the shortcut topmost (same as z-order topMost)\nThis is used for simple shortcuts or such, and is just a simplified z-order option)");
	ret.push_back(pFlags);
	CI_CHILD_END();
	CI_SET_STEPRC_RELAY(pNormalSC);

	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CNormalShortcut>(IDC_TOOLTIP, pNormalSC, CNormalShortcut::setToolTip, CNormalShortcut::getToolTip));
		pTpl->addDataHandler(new CNSMoveButton<CNormalShortcut, int>(pNormalSC, CNormalShortcut::setMoveButton, CNormalShortcut::getMoveButton));
	}
};



class CCDTNormalShortcut : public CConfigurationDialogTemplateImplT<CCDTNormalShortcut>, public CDialogImpl<CCDTNormalShortcut>
{
public:
	enum { IDD = IDD_NORMAL_SC_CFG };
	BEGIN_MSG_MAP(CCDTNormalShortcut);
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTNormalShortcut>);
	END_MSG_MAP();
	CCDTNormalShortcut(CCINormalShortcut *pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTNormalShortcut>(pICH)	{}
	virtual ~CCDTNormalShortcut() {}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		saveData();
		return 0;
	}
};


#endif // !defined(AFX_NORMALSHORTCUT_H__51C27FB8_EB7C_4ABB_9C89_BA763EE89354__INCLUDED_)
