// ShortcutGroup.h: interface for the ShortcutGroup class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHORTCUTGROUP_H__B0D7865E_28D7_4F95_9523_EE33A2069AEF__INCLUDED_)
#define AFX_SHORTCUTGROUP_H__B0D7865E_28D7_4F95_9523_EE33A2069AEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IShortcut.h"
#include <list>
#include "ConfigurationDialogTemplateImpl.h"
#include <AtlCtrls.h>

#define SCG_CMD_ADDSC	0
#define SCG_CMD_COUNT	1


class CShortcutFactory;
class CShortcutGroup : public IShortcut  
{
public:
	typedef struct {
		string name;
		IShortcut *pSC;
	} TYPE_SHORTCUT;
	typedef list<TYPE_SHORTCUT> SC_LST;
public:
	void preAddConfig(string str);
	bool isCloseTo(int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY);
	void MoveShortcut(int x, int y);
	void MoveShortcutDelta(int x, int y);

	void addShortcut(string name);
	CShortcutGroup(CShortcutFactory *pSf, string configLine);
	virtual ~CShortcutGroup();
	void createShortcut();
	// Properties
public:
	SC_LST getItems() {
		return m_lstShortcuts;
	}
	void setItems(SC_LST items);
	string getContainedStepRC() {
		return m_sContainedStepRC;
	}
	void setContainedStepRC(string s) {
		m_sContainedStepRC = s;
	}
	string getStepRC(bool bRecursive);

protected:
	void execBang(int iCmd, string szAarg);

	
private:
	string m_sContainedStepRC;
	SC_LST m_lstShortcuts;
	int m_iCommandArray[SCG_CMD_COUNT];
public:
	///////////////////////////////////////////////////////////////////////
	// IShortcut
	//
	static string getShortName(){ return "group";	}
	static string getLongName()	{ return "Shortcut group"; }

	///////////////////////////////////////////////////////////////////////
	// IConfigurationItem
	IConfigurationItem* getConfigurationIF();


};

/**
 *
 * Step.RC configuration dialog
 *
 * Description:
 * 
 *
 * @created	2002-08-04 12:41
 * @author	MickeM <mickem@medin.nu>
 */

class CCIStepRC : public CConfigurationItemImpl {
private:
	CShortcutGroup *pTarget;
public:
	CCIStepRC(CShortcutGroup *_pTarget) : pTarget(_pTarget) {}
	virtual ~CCIStepRC() {}

	// Properties
	CFG_ITM_SET_TEMPLATE_H(CCIStepRC, CCDTStepRC);
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC("StepRC Commands");
	CI_SET_DESCRIPTION("Here you can enter various step.rc commands to be executed.");
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_SET_DELETE_DISABLED();
	CI_CHILD_DISABLED();
	// TODO: fix this
	CI_SET_STEPRC_SIMPLE("");

	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverMLString, string, CShortcutGroup>(IDC_STEP_RC, pTarget, CShortcutGroup::setContainedStepRC, CShortcutGroup::getContainedStepRC));
	}
};



class CCDTStepRC : public CConfigurationDialogTemplateImplT<CCDTStepRC>, public CDialogImpl<CCDTStepRC>
{
public:
	enum { IDD = IDD_STEPRC_CFG };
	BEGIN_MSG_MAP(CCDTStepRC);
	MESSAGE_HANDLER(WM_SIZE, onSize);
	COMMAND_HANDLER(IDC_STEP_RC, EN_CHANGE, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTStepRC>);
	END_MSG_MAP();
	CCDTStepRC(CCIStepRC *pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTStepRC>(pICH)	{}
	virtual ~CCDTStepRC() {}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		saveData();
		return 0;
	}
	LRESULT onSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL bHandled) {
		::SetWindowPos(GetDlgItem(IDC_STEP_RC), NULL, 0, 0, LOWORD(lParam), HIWORD(lParam), SWP_NOZORDER);
		return 0;
	}

};


/**
 *
 * CNSGrpItems
 *
 * Description:
 * Handles the adding/removing of GrpItems.
 *
 * @created	2002-07-30 11:38
 * @author	MickeM <mickem@medin.nu>
 */
template <class TTarget, class TType>
class CNSGrpItems : public IDataHandlerImpl {
private:
	TTarget *pt2Object;
	void (TTarget::*fptSetter)(TType);
	TType (TTarget::*fptGetter)();
public:
	CNSGrpItems(TTarget *_pt2Object, void (TTarget::*_fptSetter)(TType), TType (TTarget::*_fptGetter)()) 
		: pt2Object(_pt2Object),
		fptSetter(_fptSetter),
		fptGetter(_fptGetter)
	{}
	virtual ~CNSGrpItems() {}

	void iSet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SC_LIST);
		lvCtrl.DeleteAllItems();

		TType sc = (*pt2Object.*fptGetter)();
		for (TType::iterator it = sc.begin(); it != sc.end(); it++) {
			if ((*it).pSC) {
				if ((*it).pSC->getName() == (*it).name) {
					int id = lvCtrl.AddItem(0, 0, (*it).pSC->getName().c_str());
					lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, "Ok", -1, 0, 0, 0);
				} else {
					int id = lvCtrl.AddItem(0, 0, (*it).pSC->getName().c_str());
					lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, "Renamed", -1, 0, 0, 0);
				}
			} else {
				int id = lvCtrl.AddItem(0, 0, (*it).name.c_str());
				lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, "Not found", -1, 0, 0, 0);
			}
		}
		if (!pt2Object)
			return;
		if (!pt2Object->getFactory())
			return;
		CShortcutFactory::T_LST_SC lst = pt2Object->getFactory()->getShortcutList();
		::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_RESETCONTENT, (WPARAM)0, (LPARAM)0);
		for (CShortcutFactory::T_LST_SC::iterator sit = lst.begin(); sit!=lst.end();sit++) {
			if (!(*sit)->getName().empty())
				::SendMessage(GetDlgItem(hWnd, IDC_SEL_SC), CB_ADDSTRING, (WPARAM)0, (LPARAM)(*sit)->getName().c_str());
		}
	}
	void iGet(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		TType sc;

		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SC_LIST);
		int id = lvCtrl.GetNextItem(-1, LVNI_ALL);
		if (id != -1) {
			do {
				char *c = new char[1024];
				lvCtrl.GetItemText(id, 0, c, 1023);
				CShortcutGroup::TYPE_SHORTCUT itm;
				itm.name = c;
				itm.pSC = NULL;
				sc.push_back(itm);
				id = lvCtrl.GetNextItem(id, LVNI_ALL);
			} while (id != -1);
		}
		(*pt2Object.*fptSetter)(sc);
	}
	void onRemove(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)	return;
		HWND hWnd = pTpl->getHWnd();
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = ::GetDlgItem(hWnd, IDC_SC_LIST);
		lvCtrl.DeleteAllItems();
		lvCtrl.m_hWnd = NULL;
	}
};



class CCIShortcutGroup : public CConfigurationItemImpl {
private:
	CShortcutGroup *pTarget;
public:
	CCIShortcutGroup(CShortcutGroup *_pTarget) : pTarget(_pTarget) {}
	virtual ~CCIShortcutGroup() {}

	// Properties
	CFG_ITM_SET_TEMPLATE_H(CCIShortcutGroup, CCDTShortcutGroup);
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_EX(pTarget->getName, pTarget->setName);
	CI_SET_DESCRIPTION("A group containes one or more shortcuts.");
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_SET_DELETE_DISABLED();
	CI_CHILD_BEGIN();
	CI_CHILD_ADD(CCIStepRC, pTarget);
	CI_CHILD_END();
	CI_SET_STEPRC_RELAY(pTarget);

	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CNSGrpItems<CShortcutGroup, CShortcutGroup::SC_LST>(pTarget, CShortcutGroup::setItems, CShortcutGroup::getItems));
	}
};

class CCDTShortcutGroup : public CConfigurationDialogTemplateImplT<CCDTShortcutGroup>, public CDialogImpl<CCDTShortcutGroup>
{
public:
	enum { IDD = IDD_SCGROUP_CFG };
	BEGIN_MSG_MAP(CCDTShortcutGroup);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	COMMAND_HANDLER(IDC_BTN_ADD, BN_CLICKED, onAdd); 
	COMMAND_HANDLER(IDC_BTN_DEL, BN_CLICKED, onDel); 
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	COMMAND_HANDLER(IDC_SEL_SC, CBN_EDITCHANGE, onRefresh);
	COMMAND_HANDLER(IDC_SEL_SC, CBN_SELCHANGE, onRefresh);
	NOTIFY_HANDLER(IDC_SLAVE_LIST, NM_CLICK, onRefresh);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTShortcutGroup>);
	END_MSG_MAP();
	CCDTShortcutGroup(CCIShortcutGroup *_pSC, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTShortcutGroup>(pICH)
	{
		addHelpText(IDC_BTN_ADD, "Add shortcut to group.");
		addHelpText(IDC_BTN_DEL, "Remove shortcut from group.");
		addHelpText(IDC_SEL_SC, "Enter shortcut name here.");
	}
	virtual ~CCDTShortcutGroup() {}
	void onLoadData() {
		onRefresh();
	}
	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SC_LIST);
		lvCtrl.AddColumn("Shortcut", 0);
		lvCtrl.AddColumn("Status", 1);
		lvCtrl.m_hWnd = NULL;
		return 0;
	}

	HRESULT onAdd(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SC_LIST);
		char *c = new char[1024];
		SendDlgItemMessage(IDC_SEL_SC,  WM_GETTEXT, 1023,  (LPARAM) c);
		string sc = c;
		delete [] c;
		int id = lvCtrl.AddItem(0, 0, sc.c_str());
		lvCtrl.SetItem(id, 1,LVIF_TEXT|LVIF_DI_SETITEM, "New", -1, 0, 0, 0);
		lvCtrl.m_hWnd = NULL;
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_SEL_SC, "");
		onRefresh();
		saveData();
		return 0;
	}
	HRESULT onDel(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;

		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SC_LIST);
		if (lvCtrl.GetSelectedCount() == 0) {
			LSLogPrintf(LOG_ERROR, __FILE__, "No selection was made. (ie. cat remove things stupid :)");
			return 0;
		}

		int id = lvCtrl.GetSelectedIndex();
		char *c = new char[1024];
		lvCtrl.GetItemText(id, 0, c, 1023);
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_SEL_SC, c);
		lvCtrl.DeleteItem(id);
		onRefresh();
		saveData();
		return 0;
	}
	HRESULT onRefresh(int idCtrl, NMHDR *pnmh, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		return 0;
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		if (!hasLoaded())
			return 0;
		onRefresh();
		return 0;
	}
	void onRefresh() {
		CListViewCtrl lvCtrl;
		lvCtrl.m_hWnd = GetDlgItem(IDC_SC_LIST);
		lvCtrl.SetColumnWidth(0, LVSCW_AUTOSIZE);
		lvCtrl.SetColumnWidth(1, LVSCW_AUTOSIZE);
		if (lvCtrl.GetSelectedCount() > 0)
			::EnableWindow(GetDlgItem(IDC_BTN_DEL), TRUE);
		else
			::EnableWindow(GetDlgItem(IDC_BTN_DEL), FALSE);
		lvCtrl.m_hWnd = NULL;
	}

};



#endif // !defined(AFX_SHORTCUTGROUP_H__B0D7865E_28D7_4F95_9523_EE33A2069AEF__INCLUDED_)
