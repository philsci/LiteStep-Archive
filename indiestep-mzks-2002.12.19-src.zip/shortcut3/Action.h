// Action.h: interface for the CAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACTION_H__6A5F0767_F74F_4556_BBF0_A243758C4952__INCLUDED_)
#define AFX_ACTION_H__6A5F0767_F74F_4556_BBF0_A243758C4952__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <string>
using namespace std;

#include "IConfigurationItem.h"
#include "ConfigurationDialogTemplateImpl.h"
#include "Bitmap.h"
#include <AtlDlgs.h>
class CAction  
{
public:
	CAction(int action);
	virtual ~CAction();
	//////////////////////////////////////////////////////////////////////////
	// Properties
	void setUseDefSound(bool b) {
		m_bUseDefaultSound = b;
	}
	bool getUseDefSound() {
		return m_bUseDefaultSound;
	}
	void setSound(string file) {
		m_sSound = file;
	}
	string getSound() {
		return m_sSound;
	}
	void setImage(string file) {
		if (file == ".none")
			m_bmp.setImageFile("", m_bPreload);
		else
			m_bmp.setImageFile(file, m_bPreload);
	}
	void setImageAndRefresh(string file) {
		if (file == ".none")
			m_bmp.setImageFile("", m_bPreload);
		else
			m_bmp.setImageFile(file, m_bPreload);
		/*::InvalidateRect(m_hTargetWnd, NULL, NULL);*/
	}
	string getImage() {
		return m_bmp.getImageFile();
	}
	void setCommand(string cmd, string arg) {
		m_sCommand = cmd;
		m_sArgument = arg;
	}
	void setCommand(string cmd) {
		m_sCommand = cmd;
	}
	string getCommand() {
		return m_sCommand;
	}
	void setArgument(string arg) {
		m_sArgument = arg;
	}
	string getArgument() {
		return m_sArgument;
	}
	CLSBitmap* getBitmap() {
		return &m_bmp;
	}
	int getAction() {
		return m_action;
	}
	int getAlpha() {
		return m_bmp.getAlphaLevel();
	}
	void setAlpha(int v) {
		m_bmp.setAlphaLevel(v);
	}
	string getActionName();
	string getStepRC(bool b) {
		string ret;
		string s = "*shortcutEx " + getActionName() + " ";
		if (!getImage().empty()) 
			ret += s + "image " + getImage() + "\n";
		if (getUseDefSound()) 
			ret += s + "sound .def\n";
		else if (!getSound().empty()) 
			ret += s + "sound " + getSound() + "\n";
		if (!getCommand().empty()) 
			ret += s + "command " + getCommand() + " " + getArgument() + "\n";
		else if (!getArgument().empty()) 
			ret += s + "commandArgument " + getArgument() + "\n";
		return ret;
	}



private:
	const int m_action;
	CLSBitmap m_bmp;
	string m_sSound;
	bool m_bUseDefaultSound;
	bool m_bPreload;
	string m_sCommand;
	string m_sArgument;
};

class IShortcutImpl;
class CCIAction : public CConfigurationItemImpl {
private:
	IShortcutImpl *pShortcut;
	CAction *pAction;
public:
	CCIAction(CAction *_pAction, IShortcutImpl *_pShortcut) : pAction(_pAction), pShortcut(_pShortcut) {}
	virtual ~CCIAction() {}

	// Properties
	CI_SET_VERIFY_DISABLED();
	CI_SET_NAME_STATIC(pAction->getActionName());
	CI_SET_DESCRIPTION("This is an action...");
	CI_SET_DELETE_DISABLED();
	CI_SET_ICON_DISABLED();
	CI_SET_ADDCHILD_DISABLED();
	CI_CHILD_DISABLED();
	CI_SET_STEPRC_RELAY(pAction);

	// Methogs
	//////////////////////////////////////////////////////////////////////////
	// CConfigurationItemImpl
	CFG_ITM_SET_TEMPLATE_H(CCIAction, CCDTAction);
	void onActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CAction>(IDC_COMMAND, pAction, CAction::setCommand, CAction::getCommand));
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CAction>(IDC_ARGUMENT, pAction, CAction::setArgument, CAction::getArgument));
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CAction>(IDC_SOUND, pAction, CAction::setSound, CAction::getSound));
		pTpl->addDataHandler(new CDataSaverFtor<CDataSaverBool, bool, CAction>(IDC_SOUND_DEFAULT, pAction, CAction::setUseDefSound, CAction::getUseDefSound));
		pTpl->addDataHandler(new CDataSaverFtor<IDataSaverString, string, CAction>(IDC_IMAGE, pAction, CAction::setImage, CAction::getImage));
		pTpl->addDataHandler(new CDataSaverFtor<CDataSaverInt, int, CAction>(IDC_ALPHA, pAction, CAction::setAlpha, CAction::getAlpha));
	}
	void onDeActivateTemplate(IConfigurationDialogTemplate *pTpl) {
		if (!pTpl)
			return;
		pTpl->clearDataHandlers();
	}
	bool hasAlpha();
	void refreshImage();
};



class CCDTAction : public CConfigurationDialogTemplateImplT<CCDTAction>, public CDialogImpl<CCDTAction>
{
private:
LPCTSTR lpcstrFilter;
CCIAction *pCItem;
public:
	enum { IDD = IDD_STATE_CFG };
	BEGIN_MSG_MAP(CCDTAction);
	COMMAND_HANDLER(LOWORD(wParam), BN_CLICKED, onRefresh);
	COMMAND_HANDLER(LOWORD(wParam), EN_CHANGE, onRefresh);
	MESSAGE_HANDLER(WM_INITDIALOG, onInitDialog);
	COMMAND_HANDLER(IDC_BROWSE, BN_CLICKED, onBrowse);
	CHAIN_MSG_MAP(CConfigurationDialogTemplateImplT<CCDTAction>);
	END_MSG_MAP();
	CCDTAction(CCIAction *_pCItem, IConfigurationHandler *pICH) : 
		CConfigurationDialogTemplateImplT<CCDTAction>(pICH),
			lpcstrFilter( 
	_T("All Image Files\0*.png; *.jpg; *.bmp\0")
	_T("PNG (Portable Network Graphic) Files (*.png)\0*.png\0")
	_T("JPEG (Joint P-something) Files (*.jpg, *.jpeg)\0*.jpg; *.jpeg\0")
	_T("BMP (BitMaP) Files (*.bmp)\0*.bmp\0")
	_T("All Files (*.*)\0*.*\0")
	_T("")), pCItem(_pCItem)
	{
		addHelpText(IDC_COMMAND, "Command to execute.");
		addHelpText(IDC_ARGUMENT, "Argument for the command.");
		addHelpText(IDC_SOUND, "Soundfile to use.");
		addHelpText(IDC_SOUND_DEFAULT, "Use the default sound instead.");
		addHelpText(IDC_IMAGE, "Imagefile to use.");
	}
	virtual ~CCDTAction() {}

	void onLoadData() {
		onRefresh();
	}
	HRESULT onRefresh(UINT uCode, UINT uID, HWND hWnd, BOOL &bHandled) {
		bHandled = FALSE;
		if (!hasLoaded())
			return 0;
		onRefresh();
		saveData();
		return 0;
	}
	void onRefresh() {
		::EnableWindow(GetDlgItem(IDC_SOUND), (::SendMessage(GetDlgItem(IDC_SOUND_DEFAULT), BM_GETCHECK, 0, 0)==BST_UNCHECKED)?TRUE:FALSE);
		if (!pCItem)
			return;
		::EnableWindow(GetDlgItem(IDC_ALPHA), pCItem->hasAlpha()?TRUE:FALSE);
		::EnableWindow(GetDlgItem(IDC_ALPHA_SPIN), pCItem->hasAlpha()?TRUE:FALSE);
		pCItem->refreshImage();
	}

	HRESULT onInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL &bHandled) {
		SendDlgItemMessage(IDC_ALPHA_SPIN, UDM_SETRANGE32, 0, 255);
		return 0;
	}

	LRESULT onBrowse(UINT uMsg, UINT uID, HWND hWnd, BOOL &bHandled) {
		char *c = new char[1024];
		LSGetImagePath(c, 1023);
		c[strlen(c)-1] = '\0';
		string dir = c;
		delete [] c;

		CFileDialog file(TRUE, NULL, _T(IConfigurationHelpers::GetTextBoxText(m_hWnd, IDC_IMAGE).c_str()), 
			OFN_HIDEREADONLY, lpcstrFilter);
		file.m_ofn.lpstrInitialDir = _T(dir.c_str());
		if (file.DoModal(m_hWnd)==IDCANCEL)
			return 0;
		string str = file.m_szFileName;
		if (str.substr(0, dir.length()) == dir) {
			str = str.substr(dir.length()+1);
		}
		IConfigurationHelpers::SetTextBoxText(m_hWnd, IDC_IMAGE, str);
		if (!hasLoaded())
			return 0;
		onRefresh();
		saveData();
		return 0;
	}
};

#endif // !defined(AFX_ACTION_H__6A5F0767_F74F_4556_BBF0_A243758C4952__INCLUDED_)
