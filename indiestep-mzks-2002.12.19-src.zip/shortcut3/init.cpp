#include "Init.h"
#include "ShortcutFactory.h"

//---------------------------------------------------------
// Global defs and vars
//---------------------------------------------------------
CShortcutFactory* shortcutFactory;


//---------------------------------------------------------
// Module startup and shutdown
//---------------------------------------------------------

int initModuleEx(HWND parentWnd, HINSTANCE hInst, LPCSTR)
{
	int code;
	HWND desktopWnd;

	desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
	if (!desktopWnd)
		desktopWnd = GetDesktopWindow();

	Window::init(hInst);

	shortcutFactory = new CShortcutFactory(parentWnd, code, desktopWnd);

	return code;
}


void quitModule(HINSTANCE hInst)
{
	delete shortcutFactory;
}
