#include "string_util.h"
#include "../lsapi/common.h"
std::string GetToken(std::string &szString, BOOL useBrackets)
{
	std::string token;
	GetToken(token, szString, useBrackets);
	return token;
}

boolean GetToken(std::string &szToken, std::string &szString, BOOL useBrackets)
{
	boolean ret = true;
	if (szString.empty())
		return false;
	char token[MAX_LINE_LENGTH];
	char *nextToken = new char[szString.length()+1];
	char *oldToken = nextToken;
	strcpy(nextToken, szString.c_str());
	ret = GetToken(nextToken, token, (const char**)&nextToken, useBrackets);
	if (!nextToken)
		szString = "";
	else
		szString = nextToken;
	szToken = token;
	delete [] oldToken;
	return ret;
}

POSITION GetPosition(std::string &szArg)
{
	std::string x = GetToken(szArg, false);
	std::string y = GetToken(szArg, false);
	return GetPosition(x, y);
}


POSITION GetPosition(std::string x, std::string y)
{
	POSITION ret;
	static int lastLeft = 0;
	static int lastTop = 0;
	ret.x = atoi(x.c_str());
	ret.centerd.x = (x.find_first_of("cC") != x.npos);
	if (x.find_first_of("rR") != x.npos) {
		ret.relative.x = true;
		ret.x += lastLeft;
	} else {
		ret.relative.x = false;
	}

	ret.y = atoi(y.c_str());
	ret.centerd.y = (y.find_first_of("cC") != y.npos);
	if (y.find_first_of("rR") != y.npos) {
		ret.relative.y = true;
		ret.y += lastTop;
	} else {
		ret.relative.y = false;
	}

	lastLeft = ret.x;
	lastTop = ret.y;
	return ret;
}

POINT readjustCoords(POSITION pos) 
{
	POINT ret;
	if (pos.centerd.x)
		ret.x = (SCREEN_WIDTH / 2) + pos.x;
	else
		ret.x = CONVERT_COORDINATE_X(pos.x);

	if (pos.centerd.y)
		ret.y = (SCREEN_HEIGHT / 2) + pos.y;
	else
		ret.y = CONVERT_COORDINATE_Y(pos.y);

	if (!MonitorFromPoint(ret, MONITOR_DEFAULTTONULL))
	{
		RECT rcMon;
		MONITORINFO mi;
		mi.cbSize = sizeof(mi);

		GetMonitorInfo(MonitorFromPoint(ret, MONITOR_DEFAULTTONEAREST), &mi);
		rcMon = mi.rcMonitor;
		if (ret.x < rcMon.left)
			ret.x = rcMon.left;
		else if (ret.x > rcMon.right)
			ret.x = rcMon.right;
		if (ret.y < rcMon.top)
			ret.y = rcMon.top;
		else if (ret.y > rcMon.bottom)
			ret.y = rcMon.bottom;
	}
	return ret;
}



bool isCloseTo(const POINT pos, const POINT size, int &x, int &y, const int cx, const int cy, const int span, bool &matchX, bool &matchY)
{
	if (!matchX) {
		if ((pos.x+span > x) && (pos.x-span < x)
			&& (pos.y+span > y) && (pos.y-span < y)) {
			x = pos.x;
			matchX = true;
		} else if ((pos.x+size.x+span > x) && (pos.x+size.x-span < x)
			&& (pos.y+span > y) && (pos.y-span < y)) {
			x = pos.x+size.x;
			matchX = true;
		} 
		if ((pos.x+span > x+cx) && (pos.x-span < x+cx)
			&& (pos.y+span > y) && (pos.y-span < y)) {
			x = pos.x-cx;
			matchX = true;
		} else if ((pos.x+size.x+span > x+cx) && (pos.x+size.x-span < x+cx)
			&& (pos.y+span > y) && (pos.y-span < y)) {
			x = pos.x+size.x-cx;
			matchX = true;
		}
	}
	if (!matchY) {
		if ((pos.y+span > y) && (pos.y-span < y)
			&& (pos.x+span > x) && (pos.x-span < x)) {
			y = pos.y;
			matchY = true;
		} else if ((pos.y+size.y+span > y) && (pos.y+size.y-span < y)
			&& (pos.x+span > x) && (pos.x-span < x)) {
			y = pos.y+size.y;
			matchY = true;
		} 
		if ((pos.y+span > y+cy) && (pos.y-span < y+cy)
			&& (pos.x+span > x) && (pos.x-span < x)) {
			y = pos.y-cy;
			matchY = true;
		} else if ((pos.y+size.y+span > y+cy) && (pos.y+size.y-span < y+cy)
			&& (pos.x+span > x) && (pos.x-span < x)) {
			y = pos.y+size.y-cy;
			matchY = true;
		}
	}
	return matchX&&matchY;
}


std::string GetWindowText(HWND hWnd)
{
	std::string ret;
	int len = GetWindowTextLength(hWnd);
	char *c = new char[len+1];
	GetWindowText(hWnd, c, len);
	ret = c;
	delete [] c;
	return ret;
}


std::string itos(int i) 
{
	char s[10];
	sprintf(s, "%d", i);
	return (std::string) s; 
}

int stoi(std::string s) 
{	
	return atoi(s.c_str());	
}