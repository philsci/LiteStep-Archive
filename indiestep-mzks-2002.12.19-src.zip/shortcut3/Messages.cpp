// Messages.cpp: implementation of the Messages class.
//
//////////////////////////////////////////////////////////////////////

// SC3 Includes
#include "Messages.h"
#include "string_util.h"
// LS Includes
#include "../lsapi/common.h"
#include "../lsapi/lswinbase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//#define NO_STRS

#define _START_CODE(id) \
	switch (id) {
#ifdef NO_STRS
#define _ADD_CODE_DEF(code, str) void();
#define _ADD_CODE(code, str) void();
#else
#define _ADD_CODE_DEF(code, str) \
	case code: msg = str + def; break;
#define _ADD_CODE(code, str) \
	case code: msg = str; break;
#endif
#define _END_CODE_DEF(str) \
		msg = str + def;	}

void scLogMessage(string sFile, int sLine, string sModule, int iLogCode, int iTextId, string sName, int iErrorCode) 
{
	string msg;
	string def = " in shortcut '%s': %d (0x%x)";
	_START_CODE(iTextId);
	_ADD_CODE_DEF(SCE_UNKNOWN, "Unknown error");
	_ADD_CODE_DEF(SCE_CANT_DESTROY, "Could not destroy window");
	_ADD_CODE_DEF(SCW_NO_PARRENT_REORDER, "ParrentWindow has not been created");
	_ADD_CODE_DEF(SCW_NO_ZORDER_REORDER, "ZorderWindow has not been created");
	_ADD_CODE_DEF(SCW_UNSUPPORTED, "Use of unsupported feature");
	_ADD_CODE_DEF(SCE_MISCONFIGURATION, "Something is badly configured");
	_ADD_CODE_DEF(SCE_MISSING_IMAGE, "Imagedata is missing or maleformed when we tried to apply it");
	_ADD_CODE_DEF(SCE_SETLAYERD_FAILED, "SetLayeredWindowAttributes failed");
	_ADD_CODE_DEF(SCE_BAD_ALPHA_MAP, "Alpha mask is bad or missing");
	_ADD_CODE_DEF(SCE_SHORTCUT_NOT_CREATED, "Shortcut not created");
	_ADD_CODE_DEF(SCE_SHORTCUT_HAS_NO_WINDOW, "Shortcut has no window");
	_ADD_CODE_DEF(SCE_SHORTCUT_NOT_FOUND, "Shortcut not found");
	_ADD_CODE_DEF(SCE_WINDOW_NOT_FOUND, "Window not found");
	_ADD_CODE_DEF(SCE_UNKNOWN_SLAVE, "Unknown slave assigned");
	_ADD_CODE_DEF(SCE_TEMPLATE_OUT_OF_RANGE, "Template ID is out of range");
	_ADD_CODE_DEF(SCE_NO_TEMPLATE, "Template is bad or not defined");
	_ADD_CODE_DEF(SCE_BAD_ICON, "Icon handle is bad");
	_ADD_CODE_DEF(SCE_BAD_HANDLE, "A generic arbitary handle was bad");
	_ADD_CODE_DEF(SCE_CANT_ADD_CHILD, "Cant add child");
	_ADD_CODE_DEF(SCE_BAD_ACTION_ID, "Bad action ID");
//	_ADD_CODE_DEF(, "");
//	_ADD_CODE_DEF(, "");
	_END_CODE_DEF("Undefined error");
	string file = sModule + ":" + sFile + ":" + itos(sLine);
	LSLogPrintf(iLogCode, file.c_str(), msg.c_str(), sName.c_str(), iErrorCode, iErrorCode);
}

void scLogMessage(string sFile, int sLine, string sModule, int iLogCode, int iTextId, string sName, string sErrorMsg) 
{
	string msg;
	string def = " in shortcut '%s': %s";
	_START_CODE(iTextId);
	_ADD_CODE_DEF(SCE_UNKNOWN, "Unknown error");
	_ADD_CODE_DEF(SCE_UNKNOWN_FLAG, "Unknown flag");
	_ADD_CODE_DEF(SCE_BAD_CAST, "Bad cast");
//	_ADD_CODE_DEF(, "");
//	_ADD_CODE_DEF(, "");
//	_ADD_CODE_DEF(, "");
//	_ADD_CODE_DEF(, "");
	_END_CODE_DEF("Undefined error");
	string file = sModule + ":" + sFile + ":" + itos(sLine);
	LSLogPrintf(iLogCode, file.c_str(), msg.c_str(), sName.c_str(), sErrorMsg.c_str());
}
