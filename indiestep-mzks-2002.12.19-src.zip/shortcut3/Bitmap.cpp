// Bitmap.cpp: implementation of the CLSBitmap class.
//
//////////////////////////////////////////////////////////////////////

#include "Bitmap.h"
#include "../lsapi/lsapi.h"
//#include "mmsystem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLSBitmap::CLSBitmap() : 
	m_hBmp(NULL), 
	m_hRgn(NULL), 
	m_hAlphaBmp(NULL),
	m_bLoadedAlphaImage(false),
	m_iALphaLevel(255),
	m_bLoadedImage(false)
{

}

CLSBitmap::~CLSBitmap()
{
	if (m_hBmp)
		::DeleteObject(m_hBmp);
	if (m_hRgn)
		::DeleteObject(m_hRgn);
	if (m_hAlphaBmp)
		::DeleteObject(m_hAlphaBmp);
}

void CLSBitmap::loadBitmap()
{
	m_bLoadedImage = true;
	if (m_hBmp)
		::DeleteObject(m_hBmp);
	if (m_sImageFile.empty()) {
		m_hBmp = NULL;
		return;
	}
	m_hBmp = LoadLSImage(m_sImageFile.c_str(), NULL);
	if (!m_hBmp)
		LSLogPrintf(LOG_ERROR, __FILE__, "Could not load image: %s", m_sImageFile.c_str());
	if (!m_hBmp)
		return;
	if (m_hRgn)
		::DeleteObject(m_hRgn);
	m_hRgn = BitmapToRegion(m_hBmp, RGB(255, 0, 255), 0x101010, 0, 0);
}

void CLSBitmap::loadAlphaBitmap()
{
	m_bLoadedAlphaImage = true;
	if (m_hAlphaBmp)
		::DeleteObject(m_hAlphaBmp);
	if (m_sImageFile.empty()) {
		m_hAlphaBmp = NULL;
		return;
	}
	m_hAlphaBmp = LoadLSImage(m_sImageFile.c_str(), NULL);
	PreMultiplyRGBChannels();
}

HRGN CLSBitmap::getRegionHandle()
{
	if (!m_bLoadedImage)
		loadBitmap();
	return m_hRgn;
}

HBITMAP CLSBitmap::getBitmapHandle()
{
	if (!m_bLoadedImage)
		loadBitmap();
	return m_hBmp;
}

HBITMAP CLSBitmap::getAlphaBitmapHandle()
{
	if (!m_bLoadedAlphaImage)
		loadAlphaBitmap();
	return m_hAlphaBmp;
}


void CLSBitmap::setImageFile(string file, bool preload)
{
	m_sImageFile = file;
	if (preload) {
		loadBitmap();
		loadAlphaBitmap();
	} else {
		m_bLoadedAlphaImage = false;
		m_bLoadedImage = false;
	}
}


void CLSBitmap::PreMultiplyRGBChannels()
{
	if (!m_hAlphaBmp)
		return;
	BITMAP bm;
	GetObject(m_hAlphaBmp, sizeof(BITMAP), &bm);
	BYTE *pPixel = (LPBYTE)bm.bmBits;
	if (!pPixel) {
		LSLogPrintf(LOG_ERROR, __FILE__, "No data in the bitmap, cant generate alpha premultiplication table.");
		return;
	}
	for (int i = 0; i < bm.bmHeight * bm.bmWidth; ++i)
	{
		pPixel[0] = pPixel[0] * pPixel[3] / 255;
		pPixel[1] = pPixel[1] * pPixel[3] / 255;
		pPixel[2] = pPixel[2] * pPixel[3] / 255;
		pPixel+= 4;
	}
}

void CLSBitmap::setAlphaLevel(int level)
{
	m_iALphaLevel = level;
}

int CLSBitmap::getAlphaLevel() const
{
	return m_iALphaLevel;
}

string CLSBitmap::getImageFile() const
{
	return m_sImageFile;
}