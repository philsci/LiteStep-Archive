/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/

#include "lscp_dll.h"
#include "StdString.h"


// Module Information
#define V_NAME "lscp-dll"


//===========================================================================
// LoadModule functions
//===========================================================================

int initModuleEx(HWND parent, HINSTANCE dllInst, LPCSTR szPath)
{
	
	LSLog(LOG_DEBUG, V_NAME, "initModuleEx called");
	
	int code = 0;

	code += AddBangCommand("!WRITEBANGS", bangWriteBangs);
	code += AddBangCommand("!WRITEMODS", bangWriteMods);
	code += AddBangCommand("!WRITEREVIDS", bangWriteRevids);
	code += AddBangCommand("!WRITERCFILES", bangWriteRcfiles);
	code += AddBangCommand("!WRITEEVARS", bangWriteEvars);
	code += AddBangCommand("!WRITEHOTKEYS", bangWriteHotkeys);

	
	if (code!=6) LSLogPrintf(LOG_ERROR, V_NAME, "Error registering %d bang command(s)", 6-code);

	LSLog(LOG_DEBUG, V_NAME, "initModuleEx completed");	
	return code;
}

void quitModule(HINSTANCE dllInst)
{

	LSLog(LOG_DEBUG, V_NAME, "quitModule called");

	int code = 0;

	code += RemoveBangCommand("!WRITEBANGS");
	code += RemoveBangCommand("!WRITEMODS");
	code += RemoveBangCommand("!WRITEREVIDS");
	code += RemoveBangCommand("!WRITERCFILES");
	code += RemoveBangCommand("!WRITEEVARS");
	code += RemoveBangCommand("!WRITEHOTKEYS");

	
	if (code!=6) LSLogPrintf(LOG_ERROR, V_NAME, "Error removing %d bang command(s)", 6-code);
	
	LSLog(LOG_DEBUG, V_NAME, "quitModule completed");
}


//===========================================================================
// !bang commands
//===========================================================================

void bangWriteBangs(HWND caller, LPCSTR args)
{

	// get bang command names from bang manager
	ILitestep *litestep;
	IBangManager *bangMgr;

	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
	litestep->GetBangManager( &bangMgr );

	if ( !bangMgr )
		return ;

	long count = bangMgr->GetBangCommandCount(), total = 0;
	BSTR *array = new BSTR[count];
	if ( !array )
		return ;

	total = bangMgr->GetBangCommandNames(count, array);

	if ( !total )
		return ;
	
	char szWriteBangsTxt[MAX_PATH];
	LSGetLitestepPath(szWriteBangsTxt, MAX_PATH-13);
	strcat(szWriteBangsTxt, "\\lscpbangs.txt");


	//write to file
	FILE* file = fopen(szWriteBangsTxt, "wb");

	for ( int i = 0; i < count; i++ )
	{
		char buffer[64];

		WideCharToMultiByte( CP_ACP,
		                     0,
		                     array[i],
		                     -1,
		                     buffer,
		                     64,
		                     NULL,
		                     NULL );

		SysFreeString(array[i]);

		if(!file)
			{
				return;
			}
		strcat(buffer, "\r\n");
		fputs(buffer, file);

	}
		fclose(file);

	// free up array damnit, done right this time
	delete [] array;
}


void bangWriteMods(HWND caller, LPCSTR args)
{

	// get module names from module manager
	ILitestep *litestep;
	IModuleManager *moduleMgr;

	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
	litestep->GetModuleManager( &moduleMgr );

	if ( !moduleMgr )
		return ;

	int count = 0;
	moduleMgr->GetModuleCount( &count );

	if ( count == 0 )
		return ;

	SAFEARRAY *array = SafeArrayCreateVector( VT_BSTR, 0, count );
	moduleMgr->GetModuleList( array, &count );

	BSTR *arrayData;
	SafeArrayAccessData( array, (void **) &arrayData );
	

	char szWriteModsTxt[MAX_PATH];
	LSGetLitestepPath(szWriteModsTxt, MAX_PATH-13);
	strcat(szWriteModsTxt, "\\lscpmods.txt");

	//write to file
	FILE* file = fopen(szWriteModsTxt, "wb");

	for ( int i = 0; i < count; i++ )
	{
		char buffer[MAX_PATH];

		WideCharToMultiByte( CP_ACP,
		                     0,
		                     arrayData[i],
		                     -1,
		                     buffer,
		                     MAX_PATH,
		                     NULL,
		                     NULL );

		if(!file)
			{
				return;
			}
		strcat(buffer, "\r\n");
		fputs(buffer, file);

	}
		fclose(file);

	
	SafeArrayUnaccessData( array );
	SafeArrayDestroy( array );
}


void bangWriteRevids(HWND caller, LPCSTR args)
{
	int i = 0;
	char buffer[256];
	int itemInfo = 0;

	char szWriteRevidsTxt[MAX_PATH];
	LSGetLitestepPath(szWriteRevidsTxt, MAX_PATH-13);
	strcat(szWriteRevidsTxt, "\\lscprevids.txt");

	//write to file
	FILE* file = fopen(szWriteRevidsTxt, "wb");

	strcpy( buffer, "litestep.exe: 0.24.6" );
			
		if(!file)
			{
				return;
			}
		
		strcat(buffer, "\r\n");
		fputs(buffer, file);

	itemInfo = i++;

	strcpy( buffer, "lsapi.dll: " );
//	strcat( buffer, &rcsRevision[0] );
	strcat( buffer, "1.6.6 " );
	buffer[strlen( buffer ) - 1] = 0;

		if(!file)
			{
				return;
			}
		strcat(buffer, "\r\n");
		fputs(buffer, file);

	// ask message manager which windows handle LM_GETREVID
	ILitestep *litestep;
	IMessageManager *msgMgr;

	litestep = (ILitestep *) SendMessage( GetLitestepWnd(), LM_GETLSOBJECT, 0, 0 );
	litestep->GetMessageManager( &msgMgr );

	if ( !msgMgr )
		return ;

	SAFEARRAY *array = NULL;
	msgMgr->GetWindowsForMessage( LM_GETREVID, &array );

	if ( !array )
		return ;

	long lbound, ubound;

	SafeArrayGetLBound( array, 1, &lbound );
	SafeArrayGetUBound( array, 1, &ubound );

	int count = ubound - lbound + 1;

	HWND *arrayData;
	SafeArrayAccessData( array, (void **) &arrayData );


	for ( int j = 0; j < count; j++ )
	{
		if ( !IsWindow( arrayData[j] ) )
			continue;

		buffer[0] = 0;
		SendMessage( arrayData[j], LM_GETREVID, 0, (LPARAM) buffer );

		if(!file)
			{
				return;
			}
		strcat(buffer, "\r\n");
		fputs(buffer, file);

	}
	fclose(file);
	

	SafeArrayUnaccessData( array );
	SafeArrayDestroy( array );
}


void bangWriteRcfiles(HWND caller, LPCSTR args)

{
	char szWriteRcfilesTxt[MAX_PATH];
	LSGetLitestepPath(szWriteRcfilesTxt, MAX_PATH-13);
	strcat(szWriteRcfilesTxt, "\\lscprcfiles.txt");

	//write to file
	FILE* file = fopen(szWriteRcfilesTxt, "wb");

	FILE *f;
	f = LCOpen(NULL);
	if(f)
	{

//		char* tmp;
//		char* shortname;
		char szRCPath[MAX_PATH];

		char buffer[MAX_LINE_LENGTH];

		// step.rc itself...
		LSGetLitestepPath(szRCPath, MAX_PATH-8);
		strcat(szRCPath, "step.rc");

		if(!file)
			{
				return;
			}
		strcat(szRCPath, "\r\n");
		fputs(szRCPath, file);


		// and all included files

		char* tokens[2];
		char name[MAX_LINE_LENGTH];
		char fullpath[MAX_LINE_LENGTH];

		int i = 1;

		tokens[0] = name;
		tokens[1] = fullpath;
		name[0] = fullpath[0] = 0;
		while(LCReadNextConfig(f, "include", buffer, sizeof(buffer)))
		{
			LCTokenize(buffer, tokens, 2, NULL);

			char* tmp;
			char* shortname;
	
			strcpy(buffer,fullpath);
			tmp = strtok(buffer, "\\");
			do {
				shortname = tmp;
				tmp = strtok(NULL, "\\");
			} while (tmp);

			if(!file)
			{
				return;
			}
		strcat(fullpath, "\r\n");
		fputs(fullpath, file);

		}
	} 

	fclose(file);

}

void bangWriteHotkeys(HWND caller, LPCSTR args)
{
	char szWriteHotkeysTxt[MAX_PATH];
	LSGetLitestepPath(szWriteHotkeysTxt, MAX_PATH-13);
	strcat(szWriteHotkeysTxt, "\\lscphotkeys.txt");

	//write to file
	FILE* file = fopen(szWriteHotkeysTxt, "wb");

	FILE *f;
	f = LCOpen(NULL);
	if(f)
	{

		char buffer[MAX_LINE_LENGTH];

		// all included files

		char* tokens[4];
		char name[MAX_LINE_LENGTH];
		char fullpath[MAX_LINE_LENGTH];
		char full1[MAX_LINE_LENGTH];
		char full2[MAX_LINE_LENGTH];

		int i = 1;

		tokens[0] = name;
		tokens[1] = fullpath;
		tokens[2] = full1;
		tokens[3] =full2;
		name[0] = fullpath[0] = full1[0] = full2[0] = 0;
		while(LCReadNextConfig(f, "*Hotkey", buffer, sizeof(buffer)))
		{
			LCTokenize(buffer, tokens, 4, NULL);

			char* tmp;
			char* shortname;
	
			strcpy(buffer,fullpath);
			tmp = strtok(buffer, "\\");
			do {
				shortname = tmp;
				tmp = strtok(NULL, "\\");
			} while (tmp);

			if(!file)
			{
				return;
			}
		strcat(fullpath, " ");
		strcat(fullpath, full1);
		strcat(fullpath, " = ");
		strcat(fullpath, full2);
		strcat(fullpath, "\r\n");
		fputs(fullpath, file);

		}
		
//		while(LCReadNextConfig(f, "*Desktop", buffer, sizeof(buffer)))
//		{
//			LCTokenize(buffer, tokens, 3, NULL);
//
//			char* tmp;
//			char* shortname;
//	
//			strcpy(buffer,fullpath);
//			tmp = strtok(buffer, "\\");
//			do {
//				shortname = tmp;
//				tmp = strtok(NULL, "\\");
//			} while (tmp);
//
//			if(!file)
//			{
//				return;
//			}
//		strcat(fullpath, "	");
//		strcat(fullpath, full1);
//		strcat(fullpath, "\r\n");
//		fputs(fullpath, file);
//
//		}
	} 

	fclose(file);

}


void bangWriteEvars(HWND caller, LPCSTR args)
{

	char szWriteEvarsTxt[MAX_PATH];
	LSGetLitestepPath(szWriteEvarsTxt, MAX_PATH-13);
	strcat(szWriteEvarsTxt, "\\lscpevars.txt");

	//write to file
	FILE* file = fopen(szWriteEvarsTxt, "wb");

	FILE *f;
	f = LCOpen(NULL);
	if(f)
	{

		char buffer[MAX_LINE_LENGTH];

				// and all included files

		char* tokens[2];
		char name[MAX_LINE_LENGTH];
		char fullpath[MAX_LINE_LENGTH];
		char name1[MAX_LINE_LENGTH];

		int i = 1;

		tokens[0] = name;
		tokens[1] = fullpath;
		name[0] = fullpath[0] = 0;
		while(LCReadNextLine(f, buffer, sizeof(buffer)))
		{
			LCTokenize(buffer, tokens, 2, NULL);
			{
			
/*			char namecopy[MAX_LINE_LENGTH];
			strncpy(namecopy,name,1);
//			MessageBox(NULL, namecopy, NULL, MB_OK);
				
				if (namecopy == "&")
				{
			MessageBox(NULL, "found", NULL, MB_OK);
*/
			CStdString fullline;
			CStdString cutline;
	
			fullline = name;
			cutline = fullline.Left(1);

			if (cutline == "&")
			{
			

					char* tmp;
					char* shortname;
	
					strcpy(buffer,fullpath);
					tmp = strtok(buffer, "\\");
					do {
						shortname = tmp;
						tmp = strtok(NULL, "\\");
					} while (tmp);
				
					if(!file)
					{
						return;
					}
					name1[0] = 0;
					strcat(name1, "$");
					strcat(name1, name);
					strcat(name1, "$");
					strcat(name1, " = ");
					strcat(name1, fullpath);
					strcat(name1, "\r\n");

					fputs(name1, file);

					}

			}
		} 
		
	}
	fclose(file);
}