//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dllmgr.rc
//
#define IDS_DLLMGR_ERROR1                      1
#define IDS_DLLMGR_ERROR2                      2
#define IDS_DLLMGR_ERROR3                      3
#define IDS_DLLMGR_ERROR4                      4
#define IDS_DLLMGR_ERROR5                      5

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
