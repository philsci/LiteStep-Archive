/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef  __SYSTRAY
#define  __SYSTRAY

#include "../lsapi/common.h"

/*#include <vector> // for onadd commands
using namespace std;*/

#include <commctrl.h>
#include <shlobj.h>
#include <time.h> // for timers
#include "resource.h"
#include "../lsapi/lswinbase.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * STRUCTURE: GRDSYSTRAYICON                               * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the structure that is stored for every icon    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

typedef struct ICON_SETTING
{
	int MatchHidePos; // position in config struct, also set if this icon shouldn't hide
	int MatchFlashPos; // -""-
	BOOL canHide;	// set when title is updated & matches defined one in config.
					// checked first in HideIconTimeout, which then checks update time.
} ICON_SETTING;

typedef struct ICON_STATE
{
	time_t updated;	// update time
	int FlashCount; // how many times icon has flashed
	int VisibilityStatus; // different status of visibility
	BOOL isFlashing; // if icon has been updated&matches flash config, is checked for in timer
} ICON_STATE;

typedef struct SYSTRAYICON
{

	// owner window
	HWND hWnd;
	// id
	UINT uID;
	// callback message ( to send to the owner window )
	UINT uCallbackMessage;
	// icon
	HICON hIcon;
	// icon region
	HRGN hRgn;
	// trayicon rectangle
	RECT rc;
	// tooltip text
	PTSTR szTip;
	// tooltip id
	UINT uToolTip;
	// to show or not
	
	// for more advanced features
	struct ICON_STATE state;
	struct ICON_SETTING setting;

	struct SYSTRAYICON *pNext, *pPrev;

}
SYSTRAYICON, *PSYSTRAYICON;

typedef struct ShellServiceObjectList
{
	IOleCommandTarget *object;
	ShellServiceObjectList *next;

	ShellServiceObjectList()
	{
		object = NULL;
		next = NULL;
	}
}
ShellServiceObjectList;

typedef struct LSNOTIFYICONDATA
{
	DWORD cbSize;
	HWND hWnd;
	UINT uID;
	UINT uFlags;
	UINT uCallbackMessage;
	HICON hIcon;
	CHAR szTip[256];
	DWORD dwState;
} LSNOTIFYICONDATA, *PLSNOTIFYICONDATA;

struct IgnoreList
{
	int *timer; // amount of mins to wait before hiding.
	PTSTR classname; // class name
	PTSTR tip; // optional tooltip text
};

struct flashList
{
	PTSTR classname; // class name
	PTSTR tip; // optional tooltip text
	int *maxFlash;
};

struct OnNumCommands
{
	PTSTR command; // command to be executed
};

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdTray                                          * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the _tmain class, which does all the real work   * */
/* *  it initializes a couple of "sub-classes" that are      * */
/* *  that just to make it easier to understand and manage   * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class systray : public Window
{
private:
	// booleans
	BOOL onTop;
	BOOL hideIfEmpty;
	BOOL visible;
	BOOL inWharf;
	BOOL lsboxed;
	BOOL bWinNT5;

	// tray
	int trayX;
	int trayY;
	int trayWidth;
	int trayHeight;

	// autosize
	BOOL autoSize;

	// borders
	int borderTop;
	int borderLeft;
	int borderRight;
	int borderBottom;
	BOOL borderDrag;

	int snapDistance;

	// tray wrapping
	int align;
	int direction;
	int wrapCount;
	int wrapDirection;
	int PaintOffset;
	BOOL PaintNext;

	// icon
	UINT iconSize;
	UINT iconSpacingX;
	UINT iconSpacingY;
	int deltaX;
	int deltaY;

	int firstX;
	int lastX;
	int firstY;
	int lastY;

	// icon effects
	COLORREF clrHue;
	UCHAR hueIntensity;
	UCHAR saturation;
	//for flashing
	COLORREF flashClrHue;
	UCHAR flashHueIntensity;
	UCHAR flashSaturation;
	UCHAR effectFlags;

	BOOL transpBack;
	HBITMAP hbmSkin;
	HBITMAP hbmBack;
	HRGN hrgnBack;
	BOOL skinTiled;
	BOOL transpSkin;

	COLORREF clrBack;
	COLORREF clrBorder;

	HWND liteStep;
	HWND desktop;
	HWND tooltip;
	HWND parentWindow;

	UINT uLastID;

	PSYSTRAYICON pFirst;
	PSYSTRAYICON pLast;

	PSYSTRAYICON hideFirst;
	PSYSTRAYICON hideLast;

	// onadd, wrap, etc commands
	char *OnAddCommand;
	char *OnDelCommand;
	//vector<char*> OnNumList;
	OnNumCommands *OnNumList2;
	//int OnNumCount;
	bool OnNumExe;
	int CommandsRead;

	// hiding lists
	BOOL ClearIconsOnTimer;
	int numFlash;
	flashList *flashTag;
	int numIgnore;
	IgnoreList *ignoreTag;
	UINT HIDE_TIMER;
	UINT SCROLL_TIMER;

	BOOL bScreenSaverRunning;
	BOOL bHover;
	char *OnMouseEnterCommand;
	char *OnMouseLeaveCommand;

	BOOL FlashInSS;
	BOOL TrayFlash;
	BOOL scrollWas;
	BOOL ScrollFlashing;
	BOOL AlwaysFlash;
	int timerScroll;

	BOOL firstAlignDone;

public:
	systray(HWND parentWnd, int& code, BOOL bInWharf);
	~systray();

	// bang handlers
	void AcceptFlash(BOOL flash);
	void IconInfo(void);
	void ShowAllIcons(void);
	void boxhook(LPCSTR szArgs);
	void hide();
	void show();
	void toggle();
	void toggleOnTop();
	void setAlwaysOnTop(BOOL fAlwaysOnTop);
	void move(int x, int y);
	void size(int cx, int cy);
	void ScrollIcons(int Type);

private:
	void paintBackground( HDC hdcDst, HRGN hrgnDst );
	void createBackground();
	void setFirstLast();
	void adjustSize();

	void DeleteWindowLists();
	void ReadWindowLists();
	void DeleteCommands();
	void ReadCommands();
	void ReadSizeAndPos();
	void ReadSizeProps();
	void ReadGUIProps();
	void ExportEvars();

	int copyBlt(HDC hdcDst, int xDst, int yDt, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc);
	int sizeBlt(HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc);

	/* *** * LIST MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconListFind(HWND hWnd, UINT uID);
	PSYSTRAYICON iconListFindPt(POINT pt);
	void iconListCleanup();
	BOOL iconListDelAll();
	void iconListPaint(HDC hdcDest, HRGN hrgnDest);

	/* *** * ICON MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconAdd(PLSNOTIFYICONDATA pnid);
	BOOL iconDel(PLSNOTIFYICONDATA pnid);
	BOOL iconDelGRD(PSYSTRAYICON pSysTrayIcon);
	PSYSTRAYICON iconMod(PLSNOTIFYICONDATA pnid);

	void setIcon(PSYSTRAYICON pSysTrayIcon, HICON hIcon);
	void setToolTip(PSYSTRAYICON pSysTrayIcon, char *tooltip);
	void adjustRect(PSYSTRAYICON pSysTrayIcon);

	virtual void windowProc(Message& message);
	void onRefresh(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onDisplayChange(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onKeyMessage(Message& message);
	void onMouse(Message& message);
	BOOL onMouseIcon(Message& message);
	void onPaint(Message& message);
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onSysTray(Message& message);
	void onTimer(Message& message);
	void onWindowPosChanging(Message& message);

	// onadd commands
	void ReadAddCommands(void);
	void RunCommandAdd(void);
	void RunCommandDel(void);

	// icon hiding functions
	void ShowIcon(PSYSTRAYICON icon);
	void HideIcon(PSYSTRAYICON icon);
	void ReadSystrayHide(void);
	BOOL HideIconTimeout(PSYSTRAYICON pSysTrayIcon);
	
	// icon flashing
	void ReadSystrayFlash(void);

	int MatchIconClass(PSYSTRAYICON pSysTrayIcon, int matchType);
	BOOL MatchIconTitle(PSYSTRAYICON pSysTrayIcon, PTSTR szTip, int matchType);

	int NrIcons(int Type);

	BOOL IsSaverRunning(void);

	// utility function
	DWORD ModifyStyle(HWND hWnd, DWORD dwRemove, DWORD dwAdd);
};

void bangIconInfo( HWND sender, const char *args );
void bangShowAllIcons( HWND sender, const char *args );
void bangHook( HWND sender, LPCTSTR szArgs);
void bangHide( HWND sender, char *args );
void bangShow( HWND sender, char *args );
void bangToggle( HWND sender, char *args );
void bangOnTop( HWND sender, char *args );
void bangMove( HWND sender, char *args );
void bangSize( HWND sender, char *args );
void bangDisableFlash( HWND sender, const char *args );
void bangEnableFlash( HWND sender, const char *args );
void bangScrollIcons( HWND sender, const char *args );

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
	__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif// __SYSTRAY
