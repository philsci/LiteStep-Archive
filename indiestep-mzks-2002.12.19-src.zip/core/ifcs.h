/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 19 16:03:06 2002
 */
/* Compiler settings for D:\src\indiestep-mzks-2002.12.21\core\ifcs.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ifcs_h__
#define __ifcs_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IWindowList_FWD_DEFINED__
#define __IWindowList_FWD_DEFINED__
typedef interface IWindowList IWindowList;
#endif 	/* __IWindowList_FWD_DEFINED__ */


#ifndef __IBangCommand_FWD_DEFINED__
#define __IBangCommand_FWD_DEFINED__
typedef interface IBangCommand IBangCommand;
#endif 	/* __IBangCommand_FWD_DEFINED__ */


#ifndef __DBangManager_FWD_DEFINED__
#define __DBangManager_FWD_DEFINED__
typedef interface DBangManager DBangManager;
#endif 	/* __DBangManager_FWD_DEFINED__ */


#ifndef __IBangManager_FWD_DEFINED__
#define __IBangManager_FWD_DEFINED__
typedef interface IBangManager IBangManager;
#endif 	/* __IBangManager_FWD_DEFINED__ */


#ifndef __IModuleManager_FWD_DEFINED__
#define __IModuleManager_FWD_DEFINED__
typedef interface IModuleManager IModuleManager;
#endif 	/* __IModuleManager_FWD_DEFINED__ */


#ifndef __IMessageManager_FWD_DEFINED__
#define __IMessageManager_FWD_DEFINED__
typedef interface IMessageManager IMessageManager;
#endif 	/* __IMessageManager_FWD_DEFINED__ */


#ifndef __IStepIterator_FWD_DEFINED__
#define __IStepIterator_FWD_DEFINED__
typedef interface IStepIterator IStepIterator;
#endif 	/* __IStepIterator_FWD_DEFINED__ */


#ifndef __IStepSettings_FWD_DEFINED__
#define __IStepSettings_FWD_DEFINED__
typedef interface IStepSettings IStepSettings;
#endif 	/* __IStepSettings_FWD_DEFINED__ */


#ifndef __ILitestep_FWD_DEFINED__
#define __ILitestep_FWD_DEFINED__
typedef interface ILitestep ILitestep;
#endif 	/* __ILitestep_FWD_DEFINED__ */


#ifndef __DWindowList_FWD_DEFINED__
#define __DWindowList_FWD_DEFINED__
typedef interface DWindowList DWindowList;
#endif 	/* __DWindowList_FWD_DEFINED__ */


#ifndef __DStepIterator_FWD_DEFINED__
#define __DStepIterator_FWD_DEFINED__
typedef interface DStepIterator DStepIterator;
#endif 	/* __DStepIterator_FWD_DEFINED__ */


#ifndef __DStepSettings_FWD_DEFINED__
#define __DStepSettings_FWD_DEFINED__
typedef interface DStepSettings DStepSettings;
#endif 	/* __DStepSettings_FWD_DEFINED__ */


#ifndef __DModuleManager_FWD_DEFINED__
#define __DModuleManager_FWD_DEFINED__
typedef interface DModuleManager DModuleManager;
#endif 	/* __DModuleManager_FWD_DEFINED__ */


#ifndef __DLitestep_FWD_DEFINED__
#define __DLitestep_FWD_DEFINED__
typedef interface DLitestep DLitestep;
#endif 	/* __DLitestep_FWD_DEFINED__ */


#ifndef __IDataStore_FWD_DEFINED__
#define __IDataStore_FWD_DEFINED__
typedef interface IDataStore IDataStore;
#endif 	/* __IDataStore_FWD_DEFINED__ */


#ifndef __ILitestep_FWD_DEFINED__
#define __ILitestep_FWD_DEFINED__
typedef interface ILitestep ILitestep;
#endif 	/* __ILitestep_FWD_DEFINED__ */


#ifndef __IWindowList_FWD_DEFINED__
#define __IWindowList_FWD_DEFINED__
typedef interface IWindowList IWindowList;
#endif 	/* __IWindowList_FWD_DEFINED__ */


#ifndef __IModuleManager_FWD_DEFINED__
#define __IModuleManager_FWD_DEFINED__
typedef interface IModuleManager IModuleManager;
#endif 	/* __IModuleManager_FWD_DEFINED__ */


#ifndef __IMessageManager_FWD_DEFINED__
#define __IMessageManager_FWD_DEFINED__
typedef interface IMessageManager IMessageManager;
#endif 	/* __IMessageManager_FWD_DEFINED__ */


#ifndef __IBangManager_FWD_DEFINED__
#define __IBangManager_FWD_DEFINED__
typedef interface IBangManager IBangManager;
#endif 	/* __IBangManager_FWD_DEFINED__ */


#ifndef __IBangCommand_FWD_DEFINED__
#define __IBangCommand_FWD_DEFINED__
typedef interface IBangCommand IBangCommand;
#endif 	/* __IBangCommand_FWD_DEFINED__ */


#ifndef __DBangManager_FWD_DEFINED__
#define __DBangManager_FWD_DEFINED__
typedef interface DBangManager DBangManager;
#endif 	/* __DBangManager_FWD_DEFINED__ */


#ifndef __IStepSettings_FWD_DEFINED__
#define __IStepSettings_FWD_DEFINED__
typedef interface IStepSettings IStepSettings;
#endif 	/* __IStepSettings_FWD_DEFINED__ */


#ifndef __DStepSettings_FWD_DEFINED__
#define __DStepSettings_FWD_DEFINED__
typedef interface DStepSettings DStepSettings;
#endif 	/* __DStepSettings_FWD_DEFINED__ */


#ifndef __Litestep_FWD_DEFINED__
#define __Litestep_FWD_DEFINED__

#ifdef __cplusplus
typedef class Litestep Litestep;
#else
typedef struct Litestep Litestep;
#endif /* __cplusplus */

#endif 	/* __Litestep_FWD_DEFINED__ */


#ifndef __StandardWindowList_FWD_DEFINED__
#define __StandardWindowList_FWD_DEFINED__

#ifdef __cplusplus
typedef class StandardWindowList StandardWindowList;
#else
typedef struct StandardWindowList StandardWindowList;
#endif /* __cplusplus */

#endif 	/* __StandardWindowList_FWD_DEFINED__ */


#ifndef __DLLModuleManager_FWD_DEFINED__
#define __DLLModuleManager_FWD_DEFINED__

#ifdef __cplusplus
typedef class DLLModuleManager DLLModuleManager;
#else
typedef struct DLLModuleManager DLLModuleManager;
#endif /* __cplusplus */

#endif 	/* __DLLModuleManager_FWD_DEFINED__ */


#ifndef __StandardMessageManager_FWD_DEFINED__
#define __StandardMessageManager_FWD_DEFINED__

#ifdef __cplusplus
typedef class StandardMessageManager StandardMessageManager;
#else
typedef struct StandardMessageManager StandardMessageManager;
#endif /* __cplusplus */

#endif 	/* __StandardMessageManager_FWD_DEFINED__ */


/* header files for imported files */
#include "dispex.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_ifcs_0000 */
/* [local] */ 

typedef BOOL ( __stdcall __RPC_FAR *WINDOWLISTENUMPROC )( 
    HWND hwnd,
    LPARAM param);



extern RPC_IF_HANDLE __MIDL_itf_ifcs_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ifcs_0000_v0_0_s_ifspec;

#ifndef __IWindowList_INTERFACE_DEFINED__
#define __IWindowList_INTERFACE_DEFINED__

/* interface IWindowList */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IWindowList;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("753B377F-A320-48ea-BF8E-2F7FBEBE082E")
    IWindowList : public IUnknown
    {
    public:
        virtual HWND STDMETHODCALLTYPE GetWindow( 
            /* [in] */ long index) = 0;
        
        virtual long STDMETHODCALLTYPE FindWindow( 
            /* [in] */ HWND hwnd) = 0;
        
        virtual long STDMETHODCALLTYPE GetWindowList( 
            /* [out] */ HWND __RPC_FAR *wlist,
            /* [in] */ long cNumSlots) = 0;
        
        virtual long STDMETHODCALLTYPE GetWindowCount( void) = 0;
        
        virtual long STDMETHODCALLTYPE EnumerateWindows( 
            /* [in] */ WINDOWLISTENUMPROC enumProc,
            /* [in] */ LPARAM lParam) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IWindowListVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IWindowList __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IWindowList __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IWindowList __RPC_FAR * This);
        
        HWND ( STDMETHODCALLTYPE __RPC_FAR *GetWindow )( 
            IWindowList __RPC_FAR * This,
            /* [in] */ long index);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *FindWindow )( 
            IWindowList __RPC_FAR * This,
            /* [in] */ HWND hwnd);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *GetWindowList )( 
            IWindowList __RPC_FAR * This,
            /* [out] */ HWND __RPC_FAR *wlist,
            /* [in] */ long cNumSlots);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *GetWindowCount )( 
            IWindowList __RPC_FAR * This);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *EnumerateWindows )( 
            IWindowList __RPC_FAR * This,
            /* [in] */ WINDOWLISTENUMPROC enumProc,
            /* [in] */ LPARAM lParam);
        
        END_INTERFACE
    } IWindowListVtbl;

    interface IWindowList
    {
        CONST_VTBL struct IWindowListVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IWindowList_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IWindowList_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IWindowList_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IWindowList_GetWindow(This,index)	\
    (This)->lpVtbl -> GetWindow(This,index)

#define IWindowList_FindWindow(This,hwnd)	\
    (This)->lpVtbl -> FindWindow(This,hwnd)

#define IWindowList_GetWindowList(This,wlist,cNumSlots)	\
    (This)->lpVtbl -> GetWindowList(This,wlist,cNumSlots)

#define IWindowList_GetWindowCount(This)	\
    (This)->lpVtbl -> GetWindowCount(This)

#define IWindowList_EnumerateWindows(This,enumProc,lParam)	\
    (This)->lpVtbl -> EnumerateWindows(This,enumProc,lParam)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HWND STDMETHODCALLTYPE IWindowList_GetWindow_Proxy( 
    IWindowList __RPC_FAR * This,
    /* [in] */ long index);


void __RPC_STUB IWindowList_GetWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IWindowList_FindWindow_Proxy( 
    IWindowList __RPC_FAR * This,
    /* [in] */ HWND hwnd);


void __RPC_STUB IWindowList_FindWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IWindowList_GetWindowList_Proxy( 
    IWindowList __RPC_FAR * This,
    /* [out] */ HWND __RPC_FAR *wlist,
    /* [in] */ long cNumSlots);


void __RPC_STUB IWindowList_GetWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IWindowList_GetWindowCount_Proxy( 
    IWindowList __RPC_FAR * This);


void __RPC_STUB IWindowList_GetWindowCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IWindowList_EnumerateWindows_Proxy( 
    IWindowList __RPC_FAR * This,
    /* [in] */ WINDOWLISTENUMPROC enumProc,
    /* [in] */ LPARAM lParam);


void __RPC_STUB IWindowList_EnumerateWindows_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IWindowList_INTERFACE_DEFINED__ */


#ifndef __IBangCommand_INTERFACE_DEFINED__
#define __IBangCommand_INTERFACE_DEFINED__

/* interface IBangCommand */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IBangCommand;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("93825A2B-4CEE-461e-BABC-8D3D43C20F58")
    IBangCommand : public IUnknown
    {
    public:
        virtual void STDMETHODCALLTYPE Execute( 
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBangCommandVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBangCommand __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBangCommand __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBangCommand __RPC_FAR * This);
        
        void ( STDMETHODCALLTYPE __RPC_FAR *Execute )( 
            IBangCommand __RPC_FAR * This,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params);
        
        END_INTERFACE
    } IBangCommandVtbl;

    interface IBangCommand
    {
        CONST_VTBL struct IBangCommandVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBangCommand_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBangCommand_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBangCommand_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBangCommand_Execute(This,caller,params)	\
    (This)->lpVtbl -> Execute(This,caller,params)

#endif /* COBJMACROS */


#endif 	/* C style interface */



void STDMETHODCALLTYPE IBangCommand_Execute_Proxy( 
    IBangCommand __RPC_FAR * This,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params);


void __RPC_STUB IBangCommand_Execute_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBangCommand_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_ifcs_0217 */
/* [local] */ 

struct  BangCommandInfo
    {
    IBangCommand __RPC_FAR *bang;
    OLE_HANDLE caller;
    BSTR params;
    };


extern RPC_IF_HANDLE __MIDL_itf_ifcs_0217_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ifcs_0217_v0_0_s_ifspec;

#ifndef __DBangManager_INTERFACE_DEFINED__
#define __DBangManager_INTERFACE_DEFINED__

/* interface DBangManager */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DBangManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B7155DF6-1D37-4302-B1BD-8F2DDADBEC2E")
    DBangManager : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE ExecuteBangCommand( 
            /* [in] */ BSTR name,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ExecuteBangCommands( 
            /* [in] */ SAFEARRAY __RPC_FAR * names,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ SAFEARRAY __RPC_FAR * params,
            /* [retval][out] */ long __RPC_FAR *number) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBangCommandNames( 
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DBangManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DBangManager __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DBangManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DBangManager __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ExecuteBangCommand )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ExecuteBangCommands )( 
            DBangManager __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * names,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ SAFEARRAY __RPC_FAR * params,
            /* [retval][out] */ long __RPC_FAR *number);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBangCommandNames )( 
            DBangManager __RPC_FAR * This,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);
        
        END_INTERFACE
    } DBangManagerVtbl;

    interface DBangManager
    {
        CONST_VTBL struct DBangManagerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DBangManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DBangManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DBangManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DBangManager_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DBangManager_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DBangManager_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DBangManager_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DBangManager_ExecuteBangCommand(This,name,caller,params)	\
    (This)->lpVtbl -> ExecuteBangCommand(This,name,caller,params)

#define DBangManager_ExecuteBangCommands(This,names,caller,params,number)	\
    (This)->lpVtbl -> ExecuteBangCommands(This,names,caller,params,number)

#define DBangManager_GetBangCommandNames(This,retval)	\
    (This)->lpVtbl -> GetBangCommandNames(This,retval)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE DBangManager_ExecuteBangCommand_Proxy( 
    DBangManager __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params);


void __RPC_STUB DBangManager_ExecuteBangCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DBangManager_ExecuteBangCommands_Proxy( 
    DBangManager __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * names,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ SAFEARRAY __RPC_FAR * params,
    /* [retval][out] */ long __RPC_FAR *number);


void __RPC_STUB DBangManager_ExecuteBangCommands_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DBangManager_GetBangCommandNames_Proxy( 
    DBangManager __RPC_FAR * This,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);


void __RPC_STUB DBangManager_GetBangCommandNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DBangManager_INTERFACE_DEFINED__ */


#ifndef __IBangManager_INTERFACE_DEFINED__
#define __IBangManager_INTERFACE_DEFINED__

/* interface IBangManager */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IBangManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CDC70A77-7F9B-4fe9-8BA0-65C8E9987933")
    IBangManager : public IUnknown
    {
    public:
        virtual BOOL STDMETHODCALLTYPE AddBangCommand( 
            /* [in] */ BSTR name,
            /* [in] */ IBangCommand __RPC_FAR *command) = 0;
        
        virtual BOOL STDMETHODCALLTYPE RemoveBangCommand( 
            /* [in] */ BSTR name) = 0;
        
        virtual IBangCommand __RPC_FAR *STDMETHODCALLTYPE GetBangCommand( 
            /* [in] */ BSTR name) = 0;
        
        virtual void STDMETHODCALLTYPE ClearBangCommands( void) = 0;
        
        virtual BOOL STDMETHODCALLTYPE ExecuteBangCommand( 
            /* [in] */ BSTR name,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params) = 0;
        
        virtual long STDMETHODCALLTYPE ExecuteBangCommands( 
            /* [in] */ long count,
            /* [size_is][in] */ BSTR __RPC_FAR names[  ],
            /* [in] */ OLE_HANDLE caller,
            /* [size_is][in] */ BSTR __RPC_FAR params[  ]) = 0;
        
        virtual long STDMETHODCALLTYPE GetBangCommandNames( 
            /* [in] */ long count,
            /* [size_is][out] */ BSTR __RPC_FAR names[  ]) = 0;
        
        virtual long STDMETHODCALLTYPE GetBangCommandCount( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IBangManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IBangManager __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IBangManager __RPC_FAR * This);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *AddBangCommand )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ IBangCommand __RPC_FAR *command);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *RemoveBangCommand )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        IBangCommand __RPC_FAR *( STDMETHODCALLTYPE __RPC_FAR *GetBangCommand )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        void ( STDMETHODCALLTYPE __RPC_FAR *ClearBangCommands )( 
            IBangManager __RPC_FAR * This);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *ExecuteBangCommand )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ OLE_HANDLE caller,
            /* [in] */ BSTR params);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *ExecuteBangCommands )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ long count,
            /* [size_is][in] */ BSTR __RPC_FAR names[  ],
            /* [in] */ OLE_HANDLE caller,
            /* [size_is][in] */ BSTR __RPC_FAR params[  ]);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *GetBangCommandNames )( 
            IBangManager __RPC_FAR * This,
            /* [in] */ long count,
            /* [size_is][out] */ BSTR __RPC_FAR names[  ]);
        
        long ( STDMETHODCALLTYPE __RPC_FAR *GetBangCommandCount )( 
            IBangManager __RPC_FAR * This);
        
        END_INTERFACE
    } IBangManagerVtbl;

    interface IBangManager
    {
        CONST_VTBL struct IBangManagerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IBangManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IBangManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IBangManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IBangManager_AddBangCommand(This,name,command)	\
    (This)->lpVtbl -> AddBangCommand(This,name,command)

#define IBangManager_RemoveBangCommand(This,name)	\
    (This)->lpVtbl -> RemoveBangCommand(This,name)

#define IBangManager_GetBangCommand(This,name)	\
    (This)->lpVtbl -> GetBangCommand(This,name)

#define IBangManager_ClearBangCommands(This)	\
    (This)->lpVtbl -> ClearBangCommands(This)

#define IBangManager_ExecuteBangCommand(This,name,caller,params)	\
    (This)->lpVtbl -> ExecuteBangCommand(This,name,caller,params)

#define IBangManager_ExecuteBangCommands(This,count,names,caller,params)	\
    (This)->lpVtbl -> ExecuteBangCommands(This,count,names,caller,params)

#define IBangManager_GetBangCommandNames(This,count,names)	\
    (This)->lpVtbl -> GetBangCommandNames(This,count,names)

#define IBangManager_GetBangCommandCount(This)	\
    (This)->lpVtbl -> GetBangCommandCount(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



BOOL STDMETHODCALLTYPE IBangManager_AddBangCommand_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ IBangCommand __RPC_FAR *command);


void __RPC_STUB IBangManager_AddBangCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BOOL STDMETHODCALLTYPE IBangManager_RemoveBangCommand_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB IBangManager_RemoveBangCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


IBangCommand __RPC_FAR *STDMETHODCALLTYPE IBangManager_GetBangCommand_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB IBangManager_GetBangCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


void STDMETHODCALLTYPE IBangManager_ClearBangCommands_Proxy( 
    IBangManager __RPC_FAR * This);


void __RPC_STUB IBangManager_ClearBangCommands_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BOOL STDMETHODCALLTYPE IBangManager_ExecuteBangCommand_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params);


void __RPC_STUB IBangManager_ExecuteBangCommand_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IBangManager_ExecuteBangCommands_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ long count,
    /* [size_is][in] */ BSTR __RPC_FAR names[  ],
    /* [in] */ OLE_HANDLE caller,
    /* [size_is][in] */ BSTR __RPC_FAR params[  ]);


void __RPC_STUB IBangManager_ExecuteBangCommands_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IBangManager_GetBangCommandNames_Proxy( 
    IBangManager __RPC_FAR * This,
    /* [in] */ long count,
    /* [size_is][out] */ BSTR __RPC_FAR names[  ]);


void __RPC_STUB IBangManager_GetBangCommandNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


long STDMETHODCALLTYPE IBangManager_GetBangCommandCount_Proxy( 
    IBangManager __RPC_FAR * This);


void __RPC_STUB IBangManager_GetBangCommandCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IBangManager_INTERFACE_DEFINED__ */


#ifndef __IModuleManager_INTERFACE_DEFINED__
#define __IModuleManager_INTERFACE_DEFINED__

/* interface IModuleManager */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IModuleManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A1D512D1-F7CB-461c-BAF8-723092E54437")
    IModuleManager : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE LoadModules( 
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE LoadModule( 
            /* [in] */ BSTR location,
            /* [in] */ int flags) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE QuitModules( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE QuitModule( 
            /* [in] */ BSTR location) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetModuleList( 
            /* [in] */ SAFEARRAY __RPC_FAR * strlist,
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetModuleCount( 
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IModuleManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IModuleManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IModuleManager __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IModuleManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadModules )( 
            IModuleManager __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *count);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadModule )( 
            IModuleManager __RPC_FAR * This,
            /* [in] */ BSTR location,
            /* [in] */ int flags);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QuitModules )( 
            IModuleManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QuitModule )( 
            IModuleManager __RPC_FAR * This,
            /* [in] */ BSTR location);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetModuleList )( 
            IModuleManager __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * strlist,
            /* [retval][out] */ int __RPC_FAR *count);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetModuleCount )( 
            IModuleManager __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *count);
        
        END_INTERFACE
    } IModuleManagerVtbl;

    interface IModuleManager
    {
        CONST_VTBL struct IModuleManagerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IModuleManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IModuleManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IModuleManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IModuleManager_LoadModules(This,count)	\
    (This)->lpVtbl -> LoadModules(This,count)

#define IModuleManager_LoadModule(This,location,flags)	\
    (This)->lpVtbl -> LoadModule(This,location,flags)

#define IModuleManager_QuitModules(This)	\
    (This)->lpVtbl -> QuitModules(This)

#define IModuleManager_QuitModule(This,location)	\
    (This)->lpVtbl -> QuitModule(This,location)

#define IModuleManager_GetModuleList(This,strlist,count)	\
    (This)->lpVtbl -> GetModuleList(This,strlist,count)

#define IModuleManager_GetModuleCount(This,count)	\
    (This)->lpVtbl -> GetModuleCount(This,count)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IModuleManager_LoadModules_Proxy( 
    IModuleManager __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB IModuleManager_LoadModules_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IModuleManager_LoadModule_Proxy( 
    IModuleManager __RPC_FAR * This,
    /* [in] */ BSTR location,
    /* [in] */ int flags);


void __RPC_STUB IModuleManager_LoadModule_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IModuleManager_QuitModules_Proxy( 
    IModuleManager __RPC_FAR * This);


void __RPC_STUB IModuleManager_QuitModules_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IModuleManager_QuitModule_Proxy( 
    IModuleManager __RPC_FAR * This,
    /* [in] */ BSTR location);


void __RPC_STUB IModuleManager_QuitModule_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IModuleManager_GetModuleList_Proxy( 
    IModuleManager __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * strlist,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB IModuleManager_GetModuleList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IModuleManager_GetModuleCount_Proxy( 
    IModuleManager __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB IModuleManager_GetModuleCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IModuleManager_INTERFACE_DEFINED__ */


#ifndef __IMessageManager_INTERFACE_DEFINED__
#define __IMessageManager_INTERFACE_DEFINED__

/* interface IMessageManager */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IMessageManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6DBB9F7E-EA30-11d3-8EBE-0008C75CA3DB")
    IMessageManager : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE AddMessage( 
            /* [in] */ OLE_HANDLE window,
            /* [in] */ UINT message) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddMessages( 
            /* [in] */ OLE_HANDLE window,
            /* [in] */ SAFEARRAY __RPC_FAR * messages) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RemoveMessage( 
            /* [in] */ OLE_HANDLE window,
            /* [in] */ UINT message) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RemoveMessages( 
            /* [in] */ OLE_HANDLE window,
            /* [in] */ SAFEARRAY __RPC_FAR * messages) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ClearMessages( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SendMessage( 
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam,
            /* [retval][out] */ LRESULT __RPC_FAR *retval) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE PostMessage( 
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE HandlerExists( 
            /* [in] */ UINT message,
            /* [retval][out] */ BOOL __RPC_FAR *exists) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetRevID( 
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetWindowsForMessage( 
            /* [in] */ UINT message,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMessagesForWindow( 
            /* [in] */ OLE_HANDLE hWnd,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IMessageManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IMessageManager __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IMessageManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddMessage )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ OLE_HANDLE window,
            /* [in] */ UINT message);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddMessages )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ OLE_HANDLE window,
            /* [in] */ SAFEARRAY __RPC_FAR * messages);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveMessage )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ OLE_HANDLE window,
            /* [in] */ UINT message);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveMessages )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ OLE_HANDLE window,
            /* [in] */ SAFEARRAY __RPC_FAR * messages);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearMessages )( 
            IMessageManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendMessage )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam,
            /* [retval][out] */ LRESULT __RPC_FAR *retval);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PostMessage )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *HandlerExists )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ UINT message,
            /* [retval][out] */ BOOL __RPC_FAR *exists);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRevID )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ UINT message,
            /* [in] */ WPARAM wparam,
            /* [in] */ LPARAM lparam);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetWindowsForMessage )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ UINT message,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMessagesForWindow )( 
            IMessageManager __RPC_FAR * This,
            /* [in] */ OLE_HANDLE hWnd,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);
        
        END_INTERFACE
    } IMessageManagerVtbl;

    interface IMessageManager
    {
        CONST_VTBL struct IMessageManagerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IMessageManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IMessageManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IMessageManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IMessageManager_AddMessage(This,window,message)	\
    (This)->lpVtbl -> AddMessage(This,window,message)

#define IMessageManager_AddMessages(This,window,messages)	\
    (This)->lpVtbl -> AddMessages(This,window,messages)

#define IMessageManager_RemoveMessage(This,window,message)	\
    (This)->lpVtbl -> RemoveMessage(This,window,message)

#define IMessageManager_RemoveMessages(This,window,messages)	\
    (This)->lpVtbl -> RemoveMessages(This,window,messages)

#define IMessageManager_ClearMessages(This)	\
    (This)->lpVtbl -> ClearMessages(This)

#define IMessageManager_SendMessage(This,message,wparam,lparam,retval)	\
    (This)->lpVtbl -> SendMessage(This,message,wparam,lparam,retval)

#define IMessageManager_PostMessage(This,message,wparam,lparam)	\
    (This)->lpVtbl -> PostMessage(This,message,wparam,lparam)

#define IMessageManager_HandlerExists(This,message,exists)	\
    (This)->lpVtbl -> HandlerExists(This,message,exists)

#define IMessageManager_GetRevID(This,message,wparam,lparam)	\
    (This)->lpVtbl -> GetRevID(This,message,wparam,lparam)

#define IMessageManager_GetWindowsForMessage(This,message,retval)	\
    (This)->lpVtbl -> GetWindowsForMessage(This,message,retval)

#define IMessageManager_GetMessagesForWindow(This,hWnd,retval)	\
    (This)->lpVtbl -> GetMessagesForWindow(This,hWnd,retval)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE IMessageManager_AddMessage_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ OLE_HANDLE window,
    /* [in] */ UINT message);


void __RPC_STUB IMessageManager_AddMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_AddMessages_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ OLE_HANDLE window,
    /* [in] */ SAFEARRAY __RPC_FAR * messages);


void __RPC_STUB IMessageManager_AddMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_RemoveMessage_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ OLE_HANDLE window,
    /* [in] */ UINT message);


void __RPC_STUB IMessageManager_RemoveMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_RemoveMessages_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ OLE_HANDLE window,
    /* [in] */ SAFEARRAY __RPC_FAR * messages);


void __RPC_STUB IMessageManager_RemoveMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_ClearMessages_Proxy( 
    IMessageManager __RPC_FAR * This);


void __RPC_STUB IMessageManager_ClearMessages_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_SendMessage_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam,
    /* [retval][out] */ LRESULT __RPC_FAR *retval);


void __RPC_STUB IMessageManager_SendMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_PostMessage_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam);


void __RPC_STUB IMessageManager_PostMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_HandlerExists_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ UINT message,
    /* [retval][out] */ BOOL __RPC_FAR *exists);


void __RPC_STUB IMessageManager_HandlerExists_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_GetRevID_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ UINT message,
    /* [in] */ WPARAM wparam,
    /* [in] */ LPARAM lparam);


void __RPC_STUB IMessageManager_GetRevID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_GetWindowsForMessage_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ UINT message,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);


void __RPC_STUB IMessageManager_GetWindowsForMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IMessageManager_GetMessagesForWindow_Proxy( 
    IMessageManager __RPC_FAR * This,
    /* [in] */ OLE_HANDLE hWnd,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);


void __RPC_STUB IMessageManager_GetMessagesForWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IMessageManager_INTERFACE_DEFINED__ */


/* interface __MIDL_itf_ifcs_0221 */
/* [local] */ 




extern RPC_IF_HANDLE __MIDL_itf_ifcs_0221_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ifcs_0221_v0_0_s_ifspec;

#ifndef __IStepIterator_INTERFACE_DEFINED__
#define __IStepIterator_INTERFACE_DEFINED__

/* interface IStepIterator */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IStepIterator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1FBE20B7-CA75-4cd0-BD7A-470351DE5ACA")
    IStepIterator : public IUnknown
    {
    public:
        virtual BSTR STDMETHODCALLTYPE NextConfig( 
            /* [in] */ const BSTR szPrefix) = 0;
        
        virtual BSTR STDMETHODCALLTYPE NextLine( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStepIteratorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStepIterator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStepIterator __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStepIterator __RPC_FAR * This);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *NextConfig )( 
            IStepIterator __RPC_FAR * This,
            /* [in] */ const BSTR szPrefix);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *NextLine )( 
            IStepIterator __RPC_FAR * This);
        
        END_INTERFACE
    } IStepIteratorVtbl;

    interface IStepIterator
    {
        CONST_VTBL struct IStepIteratorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStepIterator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStepIterator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStepIterator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStepIterator_NextConfig(This,szPrefix)	\
    (This)->lpVtbl -> NextConfig(This,szPrefix)

#define IStepIterator_NextLine(This)	\
    (This)->lpVtbl -> NextLine(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



BSTR STDMETHODCALLTYPE IStepIterator_NextConfig_Proxy( 
    IStepIterator __RPC_FAR * This,
    /* [in] */ const BSTR szPrefix);


void __RPC_STUB IStepIterator_NextConfig_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BSTR STDMETHODCALLTYPE IStepIterator_NextLine_Proxy( 
    IStepIterator __RPC_FAR * This);


void __RPC_STUB IStepIterator_NextLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStepIterator_INTERFACE_DEFINED__ */


#ifndef __IStepSettings_INTERFACE_DEFINED__
#define __IStepSettings_INTERFACE_DEFINED__

/* interface IStepSettings */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_IStepSettings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("1FBE20B7-CA75-4cd0-BD7A-470351DE5AC9")
    IStepSettings : public IUnknown
    {
    public:
        virtual void STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual BSTR STDMETHODCALLTYPE VarExpansion( 
            /* [in] */ const BSTR value) = 0;
        
        virtual BSTR STDMETHODCALLTYPE ParseFile( 
            /* [in] */ const BSTR stepfile) = 0;
        
        virtual void STDMETHODCALLTYPE SetVariable( 
            /* [in] */ const BSTR name,
            /* [in] */ const BSTR value) = 0;
        
        virtual void STDMETHODCALLTYPE ClearVariable( 
            /* [in] */ const BSTR name) = 0;
        
        virtual int STDMETHODCALLTYPE GetInt( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ int nDefault) = 0;
        
        virtual BOOL STDMETHODCALLTYPE GetBool( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL ifFound) = 0;
        
        virtual BOOL STDMETHODCALLTYPE GetBoolDef( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL bDefault) = 0;
        
        virtual BSTR STDMETHODCALLTYPE GetString( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR defStr) = 0;
        
        virtual COLORREF STDMETHODCALLTYPE GetColor( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ COLORREF colDef) = 0;
        
        virtual BSTR STDMETHODCALLTYPE GetLine( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR szDefault) = 0;
        
        virtual BOOL STDMETHODCALLTYPE Token( 
            /* [in] */ const BSTR szString,
            /* [out] */ BSTR __RPC_FAR *szToken,
            /* [out] */ int __RPC_FAR *iNextToken,
            /* [in] */ BOOL useBrackets) = 0;
        
        virtual int STDMETHODCALLTYPE Tokenize( 
            /* [in] */ const BSTR szString,
            /* [in] */ int count,
            /* [size_is][out] */ BSTR __RPC_FAR tokens[  ],
            /* [out] */ BSTR __RPC_FAR *remainder,
            /* [in] */ BOOL useBrackets) = 0;
        
        virtual IStepIterator __RPC_FAR *STDMETHODCALLTYPE GetIterator( 
            /* [in] */ const BSTR szPath) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStepSettingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStepSettings __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStepSettings __RPC_FAR * This);
        
        void ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IStepSettings __RPC_FAR * This);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *VarExpansion )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR value);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *ParseFile )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR stepfile);
        
        void ( STDMETHODCALLTYPE __RPC_FAR *SetVariable )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR name,
            /* [in] */ const BSTR value);
        
        void ( STDMETHODCALLTYPE __RPC_FAR *ClearVariable )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR name);
        
        int ( STDMETHODCALLTYPE __RPC_FAR *GetInt )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ int nDefault);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *GetBool )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL ifFound);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *GetBoolDef )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL bDefault);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *GetString )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR defStr);
        
        COLORREF ( STDMETHODCALLTYPE __RPC_FAR *GetColor )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ COLORREF colDef);
        
        BSTR ( STDMETHODCALLTYPE __RPC_FAR *GetLine )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR szDefault);
        
        BOOL ( STDMETHODCALLTYPE __RPC_FAR *Token )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szString,
            /* [out] */ BSTR __RPC_FAR *szToken,
            /* [out] */ int __RPC_FAR *iNextToken,
            /* [in] */ BOOL useBrackets);
        
        int ( STDMETHODCALLTYPE __RPC_FAR *Tokenize )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szString,
            /* [in] */ int count,
            /* [size_is][out] */ BSTR __RPC_FAR tokens[  ],
            /* [out] */ BSTR __RPC_FAR *remainder,
            /* [in] */ BOOL useBrackets);
        
        IStepIterator __RPC_FAR *( STDMETHODCALLTYPE __RPC_FAR *GetIterator )( 
            IStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szPath);
        
        END_INTERFACE
    } IStepSettingsVtbl;

    interface IStepSettings
    {
        CONST_VTBL struct IStepSettingsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStepSettings_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStepSettings_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStepSettings_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStepSettings_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define IStepSettings_VarExpansion(This,value)	\
    (This)->lpVtbl -> VarExpansion(This,value)

#define IStepSettings_ParseFile(This,stepfile)	\
    (This)->lpVtbl -> ParseFile(This,stepfile)

#define IStepSettings_SetVariable(This,name,value)	\
    (This)->lpVtbl -> SetVariable(This,name,value)

#define IStepSettings_ClearVariable(This,name)	\
    (This)->lpVtbl -> ClearVariable(This,name)

#define IStepSettings_GetInt(This,szKeyName,nDefault)	\
    (This)->lpVtbl -> GetInt(This,szKeyName,nDefault)

#define IStepSettings_GetBool(This,szKeyName,ifFound)	\
    (This)->lpVtbl -> GetBool(This,szKeyName,ifFound)

#define IStepSettings_GetBoolDef(This,szKeyName,bDefault)	\
    (This)->lpVtbl -> GetBoolDef(This,szKeyName,bDefault)

#define IStepSettings_GetString(This,szKeyName,defStr)	\
    (This)->lpVtbl -> GetString(This,szKeyName,defStr)

#define IStepSettings_GetColor(This,szKeyName,colDef)	\
    (This)->lpVtbl -> GetColor(This,szKeyName,colDef)

#define IStepSettings_GetLine(This,szKeyName,szDefault)	\
    (This)->lpVtbl -> GetLine(This,szKeyName,szDefault)

#define IStepSettings_Token(This,szString,szToken,iNextToken,useBrackets)	\
    (This)->lpVtbl -> Token(This,szString,szToken,iNextToken,useBrackets)

#define IStepSettings_Tokenize(This,szString,count,tokens,remainder,useBrackets)	\
    (This)->lpVtbl -> Tokenize(This,szString,count,tokens,remainder,useBrackets)

#define IStepSettings_GetIterator(This,szPath)	\
    (This)->lpVtbl -> GetIterator(This,szPath)

#endif /* COBJMACROS */


#endif 	/* C style interface */



void STDMETHODCALLTYPE IStepSettings_Clear_Proxy( 
    IStepSettings __RPC_FAR * This);


void __RPC_STUB IStepSettings_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BSTR STDMETHODCALLTYPE IStepSettings_VarExpansion_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR value);


void __RPC_STUB IStepSettings_VarExpansion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BSTR STDMETHODCALLTYPE IStepSettings_ParseFile_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR stepfile);


void __RPC_STUB IStepSettings_ParseFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


void STDMETHODCALLTYPE IStepSettings_SetVariable_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR name,
    /* [in] */ const BSTR value);


void __RPC_STUB IStepSettings_SetVariable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


void STDMETHODCALLTYPE IStepSettings_ClearVariable_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR name);


void __RPC_STUB IStepSettings_ClearVariable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


int STDMETHODCALLTYPE IStepSettings_GetInt_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ int nDefault);


void __RPC_STUB IStepSettings_GetInt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BOOL STDMETHODCALLTYPE IStepSettings_GetBool_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL ifFound);


void __RPC_STUB IStepSettings_GetBool_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BOOL STDMETHODCALLTYPE IStepSettings_GetBoolDef_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL bDefault);


void __RPC_STUB IStepSettings_GetBoolDef_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BSTR STDMETHODCALLTYPE IStepSettings_GetString_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR defStr);


void __RPC_STUB IStepSettings_GetString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


COLORREF STDMETHODCALLTYPE IStepSettings_GetColor_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ COLORREF colDef);


void __RPC_STUB IStepSettings_GetColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BSTR STDMETHODCALLTYPE IStepSettings_GetLine_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR szDefault);


void __RPC_STUB IStepSettings_GetLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


BOOL STDMETHODCALLTYPE IStepSettings_Token_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szString,
    /* [out] */ BSTR __RPC_FAR *szToken,
    /* [out] */ int __RPC_FAR *iNextToken,
    /* [in] */ BOOL useBrackets);


void __RPC_STUB IStepSettings_Token_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


int STDMETHODCALLTYPE IStepSettings_Tokenize_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szString,
    /* [in] */ int count,
    /* [size_is][out] */ BSTR __RPC_FAR tokens[  ],
    /* [out] */ BSTR __RPC_FAR *remainder,
    /* [in] */ BOOL useBrackets);


void __RPC_STUB IStepSettings_Tokenize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


IStepIterator __RPC_FAR *STDMETHODCALLTYPE IStepSettings_GetIterator_Proxy( 
    IStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szPath);


void __RPC_STUB IStepSettings_GetIterator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStepSettings_INTERFACE_DEFINED__ */


#ifndef __ILitestep_INTERFACE_DEFINED__
#define __ILitestep_INTERFACE_DEFINED__

/* interface ILitestep */
/* [local][uuid][object] */ 


EXTERN_C const IID IID_ILitestep;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("41A26254-50F9-4f02-B4C7-4A535392E6EA")
    ILitestep : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetWindowList( 
            /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FindWindowList( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterWindowList( 
            /* [in] */ BSTR name,
            /* [in] */ IWindowList __RPC_FAR *winlist) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterWindowList( 
            /* [in] */ BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetModuleManager( 
            /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FindModuleManager( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterModuleManager( 
            /* [in] */ BSTR name,
            /* [in] */ IModuleManager __RPC_FAR *module_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterModuleManager( 
            /* [in] */ BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetMessageManager( 
            /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FindMessageManager( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterMessageManager( 
            /* [in] */ BSTR name,
            /* [in] */ IMessageManager __RPC_FAR *message_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterMessageManager( 
            /* [in] */ BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBangManager( 
            /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE FindBangManager( 
            /* [in] */ BSTR name,
            /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterBangManager( 
            /* [in] */ BSTR name,
            /* [in] */ IBangManager __RPC_FAR *bang_manager) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterBangManager( 
            /* [in] */ BSTR name) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ILitestepVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ILitestep __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ILitestep __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetWindowList )( 
            ILitestep __RPC_FAR * This,
            /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindWindowList )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RegisterWindowList )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ IWindowList __RPC_FAR *winlist);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UnregisterWindowList )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetModuleManager )( 
            ILitestep __RPC_FAR * This,
            /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindModuleManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RegisterModuleManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ IModuleManager __RPC_FAR *module_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UnregisterModuleManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMessageManager )( 
            ILitestep __RPC_FAR * This,
            /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindMessageManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RegisterMessageManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ IMessageManager __RPC_FAR *message_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UnregisterMessageManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBangManager )( 
            ILitestep __RPC_FAR * This,
            /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindBangManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RegisterBangManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [in] */ IBangManager __RPC_FAR *bang_manager);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *UnregisterBangManager )( 
            ILitestep __RPC_FAR * This,
            /* [in] */ BSTR name);
        
        END_INTERFACE
    } ILitestepVtbl;

    interface ILitestep
    {
        CONST_VTBL struct ILitestepVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ILitestep_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ILitestep_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ILitestep_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ILitestep_GetWindowList(This,winlist)	\
    (This)->lpVtbl -> GetWindowList(This,winlist)

#define ILitestep_FindWindowList(This,name,winlist)	\
    (This)->lpVtbl -> FindWindowList(This,name,winlist)

#define ILitestep_RegisterWindowList(This,name,winlist)	\
    (This)->lpVtbl -> RegisterWindowList(This,name,winlist)

#define ILitestep_UnregisterWindowList(This,name)	\
    (This)->lpVtbl -> UnregisterWindowList(This,name)

#define ILitestep_GetModuleManager(This,module_manager)	\
    (This)->lpVtbl -> GetModuleManager(This,module_manager)

#define ILitestep_FindModuleManager(This,name,module_manager)	\
    (This)->lpVtbl -> FindModuleManager(This,name,module_manager)

#define ILitestep_RegisterModuleManager(This,name,module_manager)	\
    (This)->lpVtbl -> RegisterModuleManager(This,name,module_manager)

#define ILitestep_UnregisterModuleManager(This,name)	\
    (This)->lpVtbl -> UnregisterModuleManager(This,name)

#define ILitestep_GetMessageManager(This,message_manager)	\
    (This)->lpVtbl -> GetMessageManager(This,message_manager)

#define ILitestep_FindMessageManager(This,name,message_manager)	\
    (This)->lpVtbl -> FindMessageManager(This,name,message_manager)

#define ILitestep_RegisterMessageManager(This,name,message_manager)	\
    (This)->lpVtbl -> RegisterMessageManager(This,name,message_manager)

#define ILitestep_UnregisterMessageManager(This,name)	\
    (This)->lpVtbl -> UnregisterMessageManager(This,name)

#define ILitestep_GetBangManager(This,bang_manager)	\
    (This)->lpVtbl -> GetBangManager(This,bang_manager)

#define ILitestep_FindBangManager(This,name,bang_manager)	\
    (This)->lpVtbl -> FindBangManager(This,name,bang_manager)

#define ILitestep_RegisterBangManager(This,name,bang_manager)	\
    (This)->lpVtbl -> RegisterBangManager(This,name,bang_manager)

#define ILitestep_UnregisterBangManager(This,name)	\
    (This)->lpVtbl -> UnregisterBangManager(This,name)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE ILitestep_GetWindowList_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB ILitestep_GetWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_FindWindowList_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB ILitestep_FindWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_RegisterWindowList_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ IWindowList __RPC_FAR *winlist);


void __RPC_STUB ILitestep_RegisterWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_UnregisterWindowList_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB ILitestep_UnregisterWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_GetModuleManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager);


void __RPC_STUB ILitestep_GetModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_FindModuleManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *module_manager);


void __RPC_STUB ILitestep_FindModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_RegisterModuleManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ IModuleManager __RPC_FAR *module_manager);


void __RPC_STUB ILitestep_RegisterModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_UnregisterModuleManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB ILitestep_UnregisterModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_GetMessageManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager);


void __RPC_STUB ILitestep_GetMessageManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_FindMessageManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *message_manager);


void __RPC_STUB ILitestep_FindMessageManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_RegisterMessageManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ IMessageManager __RPC_FAR *message_manager);


void __RPC_STUB ILitestep_RegisterMessageManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_UnregisterMessageManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB ILitestep_UnregisterMessageManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_GetBangManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager);


void __RPC_STUB ILitestep_GetBangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_FindBangManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *bang_manager);


void __RPC_STUB ILitestep_FindBangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_RegisterBangManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [in] */ IBangManager __RPC_FAR *bang_manager);


void __RPC_STUB ILitestep_RegisterBangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE ILitestep_UnregisterBangManager_Proxy( 
    ILitestep __RPC_FAR * This,
    /* [in] */ BSTR name);


void __RPC_STUB ILitestep_UnregisterBangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ILitestep_INTERFACE_DEFINED__ */


#ifndef __DWindowList_INTERFACE_DEFINED__
#define __DWindowList_INTERFACE_DEFINED__

/* interface DWindowList */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DWindowList;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("19DCF471-33E9-4252-B25A-F6E047F8BB77")
    DWindowList : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetWindow( 
            /* [in] */ long index,
            /* [retval][out] */ OLE_HANDLE __RPC_FAR *hwnd) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE FindWindow( 
            /* [in] */ OLE_HANDLE hwnd,
            /* [retval][out] */ long __RPC_FAR *index) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetWindowList( 
            /* [out] */ SAFEARRAY __RPC_FAR * wlist,
            /* [retval][out] */ long __RPC_FAR *count) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetWindowCount( 
            /* [retval][out] */ long __RPC_FAR *count) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DWindowListVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DWindowList __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DWindowList __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DWindowList __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetWindow )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ long index,
            /* [retval][out] */ OLE_HANDLE __RPC_FAR *hwnd);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindWindow )( 
            DWindowList __RPC_FAR * This,
            /* [in] */ OLE_HANDLE hwnd,
            /* [retval][out] */ long __RPC_FAR *index);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetWindowList )( 
            DWindowList __RPC_FAR * This,
            /* [out] */ SAFEARRAY __RPC_FAR * wlist,
            /* [retval][out] */ long __RPC_FAR *count);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetWindowCount )( 
            DWindowList __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *count);
        
        END_INTERFACE
    } DWindowListVtbl;

    interface DWindowList
    {
        CONST_VTBL struct DWindowListVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DWindowList_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DWindowList_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DWindowList_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DWindowList_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DWindowList_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DWindowList_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DWindowList_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DWindowList_GetWindow(This,index,hwnd)	\
    (This)->lpVtbl -> GetWindow(This,index,hwnd)

#define DWindowList_FindWindow(This,hwnd,index)	\
    (This)->lpVtbl -> FindWindow(This,hwnd,index)

#define DWindowList_GetWindowList(This,wlist,count)	\
    (This)->lpVtbl -> GetWindowList(This,wlist,count)

#define DWindowList_GetWindowCount(This,count)	\
    (This)->lpVtbl -> GetWindowCount(This,count)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE DWindowList_GetWindow_Proxy( 
    DWindowList __RPC_FAR * This,
    /* [in] */ long index,
    /* [retval][out] */ OLE_HANDLE __RPC_FAR *hwnd);


void __RPC_STUB DWindowList_GetWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DWindowList_FindWindow_Proxy( 
    DWindowList __RPC_FAR * This,
    /* [in] */ OLE_HANDLE hwnd,
    /* [retval][out] */ long __RPC_FAR *index);


void __RPC_STUB DWindowList_FindWindow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DWindowList_GetWindowList_Proxy( 
    DWindowList __RPC_FAR * This,
    /* [out] */ SAFEARRAY __RPC_FAR * wlist,
    /* [retval][out] */ long __RPC_FAR *count);


void __RPC_STUB DWindowList_GetWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DWindowList_GetWindowCount_Proxy( 
    DWindowList __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *count);


void __RPC_STUB DWindowList_GetWindowCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DWindowList_INTERFACE_DEFINED__ */


#ifndef __DStepIterator_INTERFACE_DEFINED__
#define __DStepIterator_INTERFACE_DEFINED__

/* interface DStepIterator */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DStepIterator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3D3B9190-4956-4da9-A6B1-9FB94210E4B4")
    DStepIterator : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE NextConfig( 
            /* [in] */ const BSTR szPrefix,
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE NextLine( 
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DStepIteratorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DStepIterator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DStepIterator __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DStepIterator __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DStepIterator __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DStepIterator __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DStepIterator __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DStepIterator __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextConfig )( 
            DStepIterator __RPC_FAR * This,
            /* [in] */ const BSTR szPrefix,
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *NextLine )( 
            DStepIterator __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer);
        
        END_INTERFACE
    } DStepIteratorVtbl;

    interface DStepIterator
    {
        CONST_VTBL struct DStepIteratorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DStepIterator_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DStepIterator_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DStepIterator_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DStepIterator_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DStepIterator_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DStepIterator_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DStepIterator_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DStepIterator_NextConfig(This,szPrefix,szBuffer)	\
    (This)->lpVtbl -> NextConfig(This,szPrefix,szBuffer)

#define DStepIterator_NextLine(This,szBuffer)	\
    (This)->lpVtbl -> NextLine(This,szBuffer)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE DStepIterator_NextConfig_Proxy( 
    DStepIterator __RPC_FAR * This,
    /* [in] */ const BSTR szPrefix,
    /* [retval][out] */ BSTR __RPC_FAR *szBuffer);


void __RPC_STUB DStepIterator_NextConfig_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepIterator_NextLine_Proxy( 
    DStepIterator __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *szBuffer);


void __RPC_STUB DStepIterator_NextLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DStepIterator_INTERFACE_DEFINED__ */


#ifndef __DStepSettings_INTERFACE_DEFINED__
#define __DStepSettings_INTERFACE_DEFINED__

/* interface DStepSettings */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DStepSettings;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3D3B9190-4956-4da9-A6B1-9FB94210E4B3")
    DStepSettings : public IDispatch
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE VarExpansion( 
            /* [in] */ const BSTR value,
            /* [retval][out] */ BSTR __RPC_FAR *buffer) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ParseFile( 
            /* [in] */ const BSTR stepfile,
            /* [retval][out] */ BSTR __RPC_FAR *fullpath) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetVariable( 
            /* [in] */ const BSTR name,
            /* [in] */ const BSTR value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ClearVariable( 
            /* [in] */ const BSTR name) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetInt( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ int nDefault,
            /* [retval][out] */ int __RPC_FAR *value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBool( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL ifFound,
            /* [retval][out] */ BOOL __RPC_FAR *value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetBoolDef( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL bDefault,
            /* [retval][out] */ BOOL __RPC_FAR *value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetString( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR defStr,
            /* [retval][out] */ BSTR __RPC_FAR *szValue) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetColor( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ COLORREF colDef,
            /* [retval][out] */ COLORREF __RPC_FAR *value) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetLine( 
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR szDefault,
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Tokenize( 
            /* [in] */ const BSTR szString,
            /* [in] */ BOOL useBrackets,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *lpszBuffers) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetIterator( 
            /* [in] */ const BSTR szPath,
            /* [retval][out] */ DStepIterator __RPC_FAR *iter) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DStepSettingsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DStepSettings __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DStepSettings __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DStepSettings __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            DStepSettings __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *VarExpansion )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR value,
            /* [retval][out] */ BSTR __RPC_FAR *buffer);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ParseFile )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR stepfile,
            /* [retval][out] */ BSTR __RPC_FAR *fullpath);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVariable )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR name,
            /* [in] */ const BSTR value);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearVariable )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR name);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetInt )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ int nDefault,
            /* [retval][out] */ int __RPC_FAR *value);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBool )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL ifFound,
            /* [retval][out] */ BOOL __RPC_FAR *value);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetBoolDef )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ BOOL bDefault,
            /* [retval][out] */ BOOL __RPC_FAR *value);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetString )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR defStr,
            /* [retval][out] */ BSTR __RPC_FAR *szValue);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetColor )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ COLORREF colDef,
            /* [retval][out] */ COLORREF __RPC_FAR *value);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLine )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szKeyName,
            /* [in] */ const BSTR szDefault,
            /* [retval][out] */ BSTR __RPC_FAR *szBuffer);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Tokenize )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szString,
            /* [in] */ BOOL useBrackets,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *lpszBuffers);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIterator )( 
            DStepSettings __RPC_FAR * This,
            /* [in] */ const BSTR szPath,
            /* [retval][out] */ DStepIterator __RPC_FAR *iter);
        
        END_INTERFACE
    } DStepSettingsVtbl;

    interface DStepSettings
    {
        CONST_VTBL struct DStepSettingsVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DStepSettings_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DStepSettings_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DStepSettings_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DStepSettings_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DStepSettings_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DStepSettings_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DStepSettings_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DStepSettings_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#define DStepSettings_VarExpansion(This,value,buffer)	\
    (This)->lpVtbl -> VarExpansion(This,value,buffer)

#define DStepSettings_ParseFile(This,stepfile,fullpath)	\
    (This)->lpVtbl -> ParseFile(This,stepfile,fullpath)

#define DStepSettings_SetVariable(This,name,value)	\
    (This)->lpVtbl -> SetVariable(This,name,value)

#define DStepSettings_ClearVariable(This,name)	\
    (This)->lpVtbl -> ClearVariable(This,name)

#define DStepSettings_GetInt(This,szKeyName,nDefault,value)	\
    (This)->lpVtbl -> GetInt(This,szKeyName,nDefault,value)

#define DStepSettings_GetBool(This,szKeyName,ifFound,value)	\
    (This)->lpVtbl -> GetBool(This,szKeyName,ifFound,value)

#define DStepSettings_GetBoolDef(This,szKeyName,bDefault,value)	\
    (This)->lpVtbl -> GetBoolDef(This,szKeyName,bDefault,value)

#define DStepSettings_GetString(This,szKeyName,defStr,szValue)	\
    (This)->lpVtbl -> GetString(This,szKeyName,defStr,szValue)

#define DStepSettings_GetColor(This,szKeyName,colDef,value)	\
    (This)->lpVtbl -> GetColor(This,szKeyName,colDef,value)

#define DStepSettings_GetLine(This,szKeyName,szDefault,szBuffer)	\
    (This)->lpVtbl -> GetLine(This,szKeyName,szDefault,szBuffer)

#define DStepSettings_Tokenize(This,szString,useBrackets,lpszBuffers)	\
    (This)->lpVtbl -> Tokenize(This,szString,useBrackets,lpszBuffers)

#define DStepSettings_GetIterator(This,szPath,iter)	\
    (This)->lpVtbl -> GetIterator(This,szPath,iter)

#endif /* COBJMACROS */


#endif 	/* C style interface */



HRESULT STDMETHODCALLTYPE DStepSettings_Clear_Proxy( 
    DStepSettings __RPC_FAR * This);


void __RPC_STUB DStepSettings_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_VarExpansion_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR value,
    /* [retval][out] */ BSTR __RPC_FAR *buffer);


void __RPC_STUB DStepSettings_VarExpansion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_ParseFile_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR stepfile,
    /* [retval][out] */ BSTR __RPC_FAR *fullpath);


void __RPC_STUB DStepSettings_ParseFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_SetVariable_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR name,
    /* [in] */ const BSTR value);


void __RPC_STUB DStepSettings_SetVariable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_ClearVariable_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR name);


void __RPC_STUB DStepSettings_ClearVariable_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetInt_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ int nDefault,
    /* [retval][out] */ int __RPC_FAR *value);


void __RPC_STUB DStepSettings_GetInt_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetBool_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL ifFound,
    /* [retval][out] */ BOOL __RPC_FAR *value);


void __RPC_STUB DStepSettings_GetBool_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetBoolDef_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ BOOL bDefault,
    /* [retval][out] */ BOOL __RPC_FAR *value);


void __RPC_STUB DStepSettings_GetBoolDef_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetString_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR defStr,
    /* [retval][out] */ BSTR __RPC_FAR *szValue);


void __RPC_STUB DStepSettings_GetString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetColor_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ COLORREF colDef,
    /* [retval][out] */ COLORREF __RPC_FAR *value);


void __RPC_STUB DStepSettings_GetColor_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetLine_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szKeyName,
    /* [in] */ const BSTR szDefault,
    /* [retval][out] */ BSTR __RPC_FAR *szBuffer);


void __RPC_STUB DStepSettings_GetLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_Tokenize_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szString,
    /* [in] */ BOOL useBrackets,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *lpszBuffers);


void __RPC_STUB DStepSettings_Tokenize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE DStepSettings_GetIterator_Proxy( 
    DStepSettings __RPC_FAR * This,
    /* [in] */ const BSTR szPath,
    /* [retval][out] */ DStepIterator __RPC_FAR *iter);


void __RPC_STUB DStepSettings_GetIterator_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DStepSettings_INTERFACE_DEFINED__ */


#ifndef __DModuleManager_INTERFACE_DEFINED__
#define __DModuleManager_INTERFACE_DEFINED__

/* interface DModuleManager */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DModuleManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C2D0052F-98A1-47e6-B0B3-37024F45B8C8")
    DModuleManager : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE LoadModules( 
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE LoadModule( 
            /* [in] */ BSTR location,
            /* [in] */ int flags) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE QuitModules( void) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE QuitModule( 
            /* [in] */ BSTR location) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleList( 
            /* [in] */ SAFEARRAY __RPC_FAR * strlist,
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetModuleCount( 
            /* [retval][out] */ int __RPC_FAR *count) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DModuleManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DModuleManager __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DModuleManager __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DModuleManager __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadModules )( 
            DModuleManager __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *count);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LoadModule )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ BSTR location,
            /* [in] */ int flags);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QuitModules )( 
            DModuleManager __RPC_FAR * This);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QuitModule )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ BSTR location);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetModuleList )( 
            DModuleManager __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * strlist,
            /* [retval][out] */ int __RPC_FAR *count);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetModuleCount )( 
            DModuleManager __RPC_FAR * This,
            /* [retval][out] */ int __RPC_FAR *count);
        
        END_INTERFACE
    } DModuleManagerVtbl;

    interface DModuleManager
    {
        CONST_VTBL struct DModuleManagerVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DModuleManager_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DModuleManager_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DModuleManager_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DModuleManager_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DModuleManager_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DModuleManager_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DModuleManager_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DModuleManager_LoadModules(This,count)	\
    (This)->lpVtbl -> LoadModules(This,count)

#define DModuleManager_LoadModule(This,location,flags)	\
    (This)->lpVtbl -> LoadModule(This,location,flags)

#define DModuleManager_QuitModules(This)	\
    (This)->lpVtbl -> QuitModules(This)

#define DModuleManager_QuitModule(This,location)	\
    (This)->lpVtbl -> QuitModule(This,location)

#define DModuleManager_GetModuleList(This,strlist,count)	\
    (This)->lpVtbl -> GetModuleList(This,strlist,count)

#define DModuleManager_GetModuleCount(This,count)	\
    (This)->lpVtbl -> GetModuleCount(This,count)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_LoadModules_Proxy( 
    DModuleManager __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB DModuleManager_LoadModules_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_LoadModule_Proxy( 
    DModuleManager __RPC_FAR * This,
    /* [in] */ BSTR location,
    /* [in] */ int flags);


void __RPC_STUB DModuleManager_LoadModule_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_QuitModules_Proxy( 
    DModuleManager __RPC_FAR * This);


void __RPC_STUB DModuleManager_QuitModules_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_QuitModule_Proxy( 
    DModuleManager __RPC_FAR * This,
    /* [in] */ BSTR location);


void __RPC_STUB DModuleManager_QuitModule_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_GetModuleList_Proxy( 
    DModuleManager __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * strlist,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB DModuleManager_GetModuleList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DModuleManager_GetModuleCount_Proxy( 
    DModuleManager __RPC_FAR * This,
    /* [retval][out] */ int __RPC_FAR *count);


void __RPC_STUB DModuleManager_GetModuleCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DModuleManager_INTERFACE_DEFINED__ */


#ifndef __DLitestep_INTERFACE_DEFINED__
#define __DLitestep_INTERFACE_DEFINED__

/* interface DLitestep */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_DLitestep;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("83B9306F-9C64-4a17-AACF-868ED944A223")
    DLitestep : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE WindowList( 
            /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE FindWindowList( 
            /* [in] */ BSTR name,
            /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ModuleManager( 
            /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE FindModuleManager( 
            /* [in] */ BSTR name,
            /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE BangManager( 
            /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE FindBangManager( 
            /* [in] */ BSTR name,
            /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct DLitestepVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            DLitestep __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            DLitestep __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            DLitestep __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WindowList )( 
            DLitestep __RPC_FAR * This,
            /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindWindowList )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ModuleManager )( 
            DLitestep __RPC_FAR * This,
            /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindModuleManager )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BangManager )( 
            DLitestep __RPC_FAR * This,
            /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindBangManager )( 
            DLitestep __RPC_FAR * This,
            /* [in] */ BSTR name,
            /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist);
        
        END_INTERFACE
    } DLitestepVtbl;

    interface DLitestep
    {
        CONST_VTBL struct DLitestepVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define DLitestep_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define DLitestep_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define DLitestep_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define DLitestep_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define DLitestep_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define DLitestep_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define DLitestep_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define DLitestep_WindowList(This,winlist)	\
    (This)->lpVtbl -> WindowList(This,winlist)

#define DLitestep_FindWindowList(This,name,winlist)	\
    (This)->lpVtbl -> FindWindowList(This,name,winlist)

#define DLitestep_ModuleManager(This,winlist)	\
    (This)->lpVtbl -> ModuleManager(This,winlist)

#define DLitestep_FindModuleManager(This,name,winlist)	\
    (This)->lpVtbl -> FindModuleManager(This,name,winlist)

#define DLitestep_BangManager(This,winlist)	\
    (This)->lpVtbl -> BangManager(This,winlist)

#define DLitestep_FindBangManager(This,name,winlist)	\
    (This)->lpVtbl -> FindBangManager(This,name,winlist)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_WindowList_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_WindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_FindWindowList_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ DWindowList __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_FindWindowList_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_ModuleManager_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_ModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_FindModuleManager_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ DModuleManager __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_FindModuleManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_BangManager_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_BangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE DLitestep_FindBangManager_Proxy( 
    DLitestep __RPC_FAR * This,
    /* [in] */ BSTR name,
    /* [retval][out] */ DBangManager __RPC_FAR *__RPC_FAR *winlist);


void __RPC_STUB DLitestep_FindBangManager_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __DLitestep_INTERFACE_DEFINED__ */


#ifndef __IDataStore_INTERFACE_DEFINED__
#define __IDataStore_INTERFACE_DEFINED__

/* interface IDataStore */
/* [local][dual][uuid][object] */ 


EXTERN_C const IID IID_IDataStore;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6DBB9F7F-EA30-11d3-8EBE-0008C75CA3DB")
    IDataStore : public IDispatch
    {
    public:
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE StoreData( 
            /* [in] */ WORD ident,
            /* [in] */ SAFEARRAY __RPC_FAR * data) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetData( 
            /* [in] */ WORD ident,
            /* [out] */ SAFEARRAY __RPC_FAR * data) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE ReleaseData( 
            /* [in] */ WORD ident,
            /* [out] */ SAFEARRAY __RPC_FAR * data) = 0;
        
        virtual /* [id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDataStoreVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDataStore __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDataStore __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDataStore __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *StoreData )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ WORD ident,
            /* [in] */ SAFEARRAY __RPC_FAR * data);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetData )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ WORD ident,
            /* [out] */ SAFEARRAY __RPC_FAR * data);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReleaseData )( 
            IDataStore __RPC_FAR * This,
            /* [in] */ WORD ident,
            /* [out] */ SAFEARRAY __RPC_FAR * data);
        
        /* [id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IDataStore __RPC_FAR * This);
        
        END_INTERFACE
    } IDataStoreVtbl;

    interface IDataStore
    {
        CONST_VTBL struct IDataStoreVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDataStore_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDataStore_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDataStore_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDataStore_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDataStore_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDataStore_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDataStore_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDataStore_StoreData(This,ident,data)	\
    (This)->lpVtbl -> StoreData(This,ident,data)

#define IDataStore_GetData(This,ident,data)	\
    (This)->lpVtbl -> GetData(This,ident,data)

#define IDataStore_ReleaseData(This,ident,data)	\
    (This)->lpVtbl -> ReleaseData(This,ident,data)

#define IDataStore_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [id] */ HRESULT STDMETHODCALLTYPE IDataStore_StoreData_Proxy( 
    IDataStore __RPC_FAR * This,
    /* [in] */ WORD ident,
    /* [in] */ SAFEARRAY __RPC_FAR * data);


void __RPC_STUB IDataStore_StoreData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IDataStore_GetData_Proxy( 
    IDataStore __RPC_FAR * This,
    /* [in] */ WORD ident,
    /* [out] */ SAFEARRAY __RPC_FAR * data);


void __RPC_STUB IDataStore_GetData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IDataStore_ReleaseData_Proxy( 
    IDataStore __RPC_FAR * This,
    /* [in] */ WORD ident,
    /* [out] */ SAFEARRAY __RPC_FAR * data);


void __RPC_STUB IDataStore_ReleaseData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [id] */ HRESULT STDMETHODCALLTYPE IDataStore_Clear_Proxy( 
    IDataStore __RPC_FAR * This);


void __RPC_STUB IDataStore_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDataStore_INTERFACE_DEFINED__ */



#ifndef __LitestepCore_LIBRARY_DEFINED__
#define __LitestepCore_LIBRARY_DEFINED__

/* library LitestepCore */
/* [uuid] */ 











EXTERN_C const IID LIBID_LitestepCore;

EXTERN_C const CLSID CLSID_Litestep;

#ifdef __cplusplus

class DECLSPEC_UUID("3C7405E7-E0F6-4435-B87B-B7A6225BE0F4")
Litestep;
#endif

EXTERN_C const CLSID CLSID_StandardWindowList;

#ifdef __cplusplus

class DECLSPEC_UUID("CFF3DA90-ABC0-47fb-A78A-D7144CD4BBEA")
StandardWindowList;
#endif

EXTERN_C const CLSID CLSID_DLLModuleManager;

#ifdef __cplusplus

class DECLSPEC_UUID("2C5A2634-054F-4feb-844D-D7AE3CC844B7")
DLLModuleManager;
#endif

EXTERN_C const CLSID CLSID_StandardMessageManager;

#ifdef __cplusplus

class DECLSPEC_UUID("259E4CD2-47B0-459d-87C5-5E2120D25054")
StandardMessageManager;
#endif
#endif /* __LitestepCore_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
