#ifndef __ACTIVESHORTCUTS_H_
#define __ACTIVESHORTCUTS_H_
#include "../litestep/wharfdata.h"

#define LM_DOCKTRAY          9900

struct shortcutType
{
    char szCommand[1024], szParameters[1024];
    char szName[256];
    char szSoundOnMouseOver[256];
    char szSoundOnMouseClicked[256];
    int x, y, state;
    HBITMAP bmpOff, bmpOn, bmpClick;
    HRGN transOnRgn, transOffRgn, transClickRgn;
    SIZE onSize, offSize, clickSize;
    HWND hwnd;
    UINT uTimer;
    char sz_bmpOn[256], sz_bmpOff[256], sz_bmpClick[256]; // Ender - ADD
    char sz_Group[10]; // ENDER - ADD NEW
    BOOL alwaysontop, mouseover; // Ender - ADD 1.1
    BOOL masterdrag, sstatic; // Ender - ADD 2.1

    char extra_group[10];
  int uGroup;    /*Shortcut group*/ // V1.1xxx
    BOOL bVisible;  /*Is window visible at present - Quicker than using IsWindowVisible*/
};

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif

