#ifndef __MODULE_H
#define __MODULE_H

#include <windows.h>
#include "../lsapi/lsapi.h"

#define BEGIN_MESSAGEPROC switch (message.uMsg) {
#define MESSAGE(handler, msg) case msg: handler(message); break;
#define END_MESSAGEPROC default: message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam); }


extern const HINSTANCE hInstance;

class Window
{
protected:
  static WNDCLASSEX windowClass;
  static DWORD instanceCount;
  HWND hWnd;
  HWND hParent;

public:
  Window(LPCSTR className);
  ~Window();

protected:
  bool createWindow(DWORD dwExStyle, LPCTSTR lpWindowName, DWORD dwStyle,
                    int x, int y, int nWidth, int nHeight, HWND hWndParent);
  bool destroyWindow();

  static CALLBACK LRESULT wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  virtual void windowProc(Message& message);
};



#endif