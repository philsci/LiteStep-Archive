/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/19/00 - Joachim Calvert (NeXTer)
  - First revision, it's working nicely, and I don't think we want any more
    features built in, perhaps smooth out a few bumps, but nothing major.
****************************************************************************/

#include "../lsapi/lswinbase.h"

#define GWL_CLASSPOINTER 0

struct CreationData
{
  SHORT cbExtra;
  Window* window;
};


const char defaultClassName[] = "AutoWindowClass";

LPCSTR persistentClassName = defaultClassName;

const HINSTANCE hInstance = 0;

DWORD Window::instanceCount = 0;
WNDCLASSEX Window::windowClass;

//---------------------------------------------------------
// Constructor
//---------------------------------------------------------
Window::Window(LPCSTR className):
hWnd(NULL),
hParent(NULL)
{
  if (instanceCount == 0)
  {
    WNDCLASSEX& wc = windowClass;

    if (persistentClassName != defaultClassName)
    {
      delete[] persistentClassName;
      persistentClassName = defaultClassName;
    }

    if (className)
    {
      persistentClassName = new char[strlen(className) + 1];
      strcpy((LPSTR)persistentClassName, className);
    }


    memset(&wc, 0, sizeof(WNDCLASSEX));
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.cbWndExtra = sizeof(Window*);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpfnWndProc = Window::wndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = persistentClassName;

    if (!RegisterClassEx(&wc))
    {
      MessageBox(NULL, "Unable to register window class.", "Error", MB_ICONEXCLAMATION | MB_TOPMOST);
      throw;
    }
  }
  instanceCount++;
}


//---------------------------------------------------------
// Destructor
//---------------------------------------------------------
Window::~Window()
{
  destroyWindow();
  if (instanceCount)
    instanceCount--;
  if (instanceCount == 0)
  {
    UnregisterClass(persistentClassName, GetModuleHandle(NULL));
    if (persistentClassName != defaultClassName)
      delete[] persistentClassName;
  }
}


//---------------------------------------------------------
// Associate the class with the window structure for easy
// message handling
//---------------------------------------------------------
bool Window::createWindow(DWORD dwExStyle, LPCTSTR lpWindowName, DWORD dwStyle,
                          int x, int y, int nWidth, int nHeight, HWND hWndParent)
{
  UNALIGNED CreationData creationData = {
    sizeof(UNALIGNED CreationData),
    this
  };

  hParent = hWndParent;

  hWnd = CreateWindowEx(dwExStyle, persistentClassName, lpWindowName, dwStyle,
                        x, y, nWidth, nHeight, hParent, NULL, hInstance, &creationData);

  if (!hWnd)
    return false;

  SetWindowLong(hWnd, GWL_CLASSPOINTER, (LONG)this);

  return true;
}


bool Window::destroyWindow()
{
  if (hWnd)
  {
    if (DestroyWindow(hWnd))
    {
      hWnd = NULL;
      return true;
    }
  }
  return false;
}


//---------------------------------------------------------
// If the window is associated with a class, call the
// messsage handler of the class
//---------------------------------------------------------
LRESULT CALLBACK Window::wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  Window* window;
  Message message;

  if (uMsg == WM_CREATE)
    window = ((UNALIGNED CreationData*)(((LPCREATESTRUCT)lParam)->lpCreateParams))->window;
  else
    window = (Window*)::GetWindowLong(hWnd, LS_GWL_CLASSPOINTER);

  message.uMsg = uMsg;
  message.wParam = wParam;
  message.lParam = lParam;
  message.lResult = 0;

  if (window)
  {
    window->windowProc(message);
    return message.lResult;
  }
  else
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


//---------------------------------------------------------
// Empty skeleton for messsage handling
//---------------------------------------------------------
void Window::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC;
  END_MESSAGEPROC;
}

int WINAPI DllEntryPoint(HINSTANCE hInst, unsigned long reason, void* lpReserved)
{
  (HINSTANCE)hInstance = hInst;
  return 1;
}

