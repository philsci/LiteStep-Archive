/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team
  
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/14/00 - Bobby G. Vinyard (Message)
  Made right click default to !popup
04/14/00 - Joachim Calvert (NeXTer)
  The desktop area is now dynamically set on resolution changes.
04/13/00 - Bobby G. Vinyard (Message)
  Reimplemented desktop clicks to use a function for setting their variables
    (Thanks MrJukes and Dem0sh for your help)
  Added three new bang commands:
    !SetDesktopLeftClick
    !SetDesktopRightClick
    !SetDesktopMiddleClick
    These allow you to change what the mouse clicks do on the fly
    e.g. !SetDesktopLeftClick !popup x=0 y=0
04/10/00 Bobby G. Vinyard (Message)
  Remove autorun functionality (was our understanding that this was flakey
    and that a 3rd party module is available that better provides this
    functionality, may be reimplemented in the future, but I see no reason
    for it to be a desktop function)
  Did some more house cleaning (i.e. removed unused variables, added proper
    headers, proper format)
04/06/00 Bobby G. Vinyard (Message) & noodge
  Went ahead and added a basic implementation of DesktopLeftClick <command>,
  DesktopMiddleClick <command>, DesktopRightClick <command> (Might look into 
    streamling the functions soon when I finish streamling desktop2)
04/01/00 Bobby G. Vinyard (Message)
  Removed some unused variable (ok, well really just commented them out until
    this build is throughly tested)
  Did some more work on setting the desktop area, hopefully this is fixed now
****************************************************************************/

#include "Desktop.h"

const char szAppName[] = "DesktopBackgroundClass"; // Our window class, etc

const char rcsRevision[] = "$Revision: 1.10 $"; // Our Version
const char rcsId[] = "$Id: Desktop.cpp,v 1.10 2000/04/14 22:05:19 nexter Exp $"; // The Full RCS ID.

void BangSetLeftClick(HWND caller, char *args);
void BangSetRightClick(HWND caller, char *args);
void BangSetMiddleClick(HWND caller, char *args);

Desktop *myDesktop;

Desktop::Desktop(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {

  
  setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
  sdaLeft = GetRCInt("SDALeft", 0);
  sdaRight = GetRCInt("SDARight", 0);
  sdaTop = GetRCInt("SDATop", 0);
  sdaBottom = GetRCInt("SDABottom", 0);
  GetRCString("DesktopLeftClick",bangLeftClick,"!None",sizeof(bangLeftClick));
  setDesktopClick(bangLeftClick, bangLeftClickCommand, bangLeftClickOption);
  GetRCString("DesktopRightClick",bangRightClick,"!Popup",sizeof(bangRightClick));
  setDesktopClick(bangRightClick, bangRightClickCommand, bangRightClickOption);
  GetRCString("DesktopMiddleClick",bangMiddleClick,"!None",sizeof(bangMiddleClick));
  setDesktopClick(bangMiddleClick, bangMiddleClickCommand, bangMiddleClickOption);
}

// -------------------------------------------------------------------------------------------------------
// Initialization of the module
// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
  myDesktop = new Desktop(ParentWnd, dllInst, szPath);
  
  myDesktop->initModule(ParentWnd, dllInst, szPath);

  AddBangCommand("!SetDesktopLeftClick", BangSetLeftClick);
  AddBangCommand("!SetDesktopRightClick", BangSetRightClick);
  AddBangCommand("!SetDesktopMiddleClick", BangSetMiddleClick);
  return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
// -------------------------------------------------------------------------------------------------------
void quitModule(HINSTANCE dllInst) {
  myDesktop->quitModule(dllInst);
  delete myDesktop;
  RemoveBangCommand("!SetDesktopLeftClick");
  RemoveBangCommand("!SetDesktopRightClick");
  RemoveBangCommand("!SetDesktopMiddleClick");
}

// window procedure for our window
LRESULT CALLBACK Desktop::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  Desktop *theDesktop = (Desktop*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
  
  if (theDesktop) {
    return theDesktop->WindowProc(hwnd, message, wParam, lParam);
  } else {
    return DefWindowProc(hwnd, message, wParam, lParam);
  }
}


int Desktop::initModule(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{

  WNDCLASSEX wc;
  
  parent = ParentWnd;
  
  // set up screen sizes
  ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
  ScreenHeight = GetSystemMetrics(SM_CYSCREEN);

  // Register Desktop window class
  memset(&wc,0,sizeof(wc));
  wc.cbSize = sizeof(WNDCLASSEX);
  wc.cbWndExtra = 4;
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.lpfnWndProc = Desktop::WndProc;				// our window procedure
  wc.hInstance = dllInst;					// hInstance of DLL
  wc.lpszClassName = szAppName;			// our window class name
  wc.style = 0;
  
  if (!RegisterClassEx(&wc)) {
    MessageBox(parent,"Error registering window class","Desktop",MB_OK);
    return 1;
  }
  
  // Find the litestep main window
  HWND hContWnd = GetLitestepWnd();
  
  // Desktop Window (main window)
  hMainWnd = CreateWindowEx(
    WS_EX_TOOLWINDOW,							// exstyles 
    szAppName,									// our window class name
    "LSDesktop",								// use description for a window title
    WS_POPUP|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,	// styles
    0, 0,										// position 
    ScreenWidth,ScreenHeight,					// width & height of window
    hContWnd,									// parent window 
    NULL,										// no menu
    dllInst,									// hInstance of DLL
    NULL);										// no window creation data
  if (!hMainWnd) {						   
    MessageBox(parent,"Error creating window","Desktop",MB_OK);
    return 1;
  }
  
  // Set class pointer into window for access later
  SetWindowLong(hMainWnd, LS_GWL_CLASSPOINTER, (LONG)this);
  SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
  
  // show the main window
  SetCursor(LoadCursor(NULL,IDC_ARROW));
  SetWindowPos(hMainWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
  ShowWindow(hMainWnd,SW_SHOWNORMAL);
  
  setMinMax();
  
  return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void Desktop::quitModule(HINSTANCE dllInst) {
  int Msgs[6];
  
  DestroyWindow(hMainWnd); // delete our window
  
  Msgs[0] = LM_GETREVID;
  Msgs[1] = LM_CHECKFORAPPBAR;
  Msgs[2] = LM_REPAINT;
  Msgs[3] = LM_ADDWINDOW;
  Msgs[4] = LM_REMOVEWINDOW;
  Msgs[5] = 0;
  SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

  resetMinMax();

  UnregisterClass(szAppName,dllInst); // unregister window class
}

LRESULT Desktop::WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message)
  {
    case LM_GETREVID:
      {
        char *buf = (char *) lParam;

        if (wParam == 0) {
          strcpy(buf, "desktop.dll: ");
          strcat(buf, &rcsRevision[11]);
          buf[strlen(buf)-1] = '\0';
        } else if (wParam == 1) {
          strcpy(buf, &rcsId[1]);
          buf[strlen(buf)-1] = '\0';
        } else {
          strcpy(buf, "");
        }
        return strlen(buf);
      }

    case WM_DISPLAYCHANGE:
      {
        // Screen resolution has changed. Change things accordingly
        ScreenWidth = LOWORD(lParam);
        ScreenHeight = HIWORD(lParam);
        setMinMax();
      }
      return 0;

    case WM_MOUSEACTIVATE:
      PostMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
      SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam)); // Close any popup open
      return MA_ACTIVATE;

    case WM_ACTIVATE:
      SendMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
      if (LOWORD(wParam)) SetActiveWindow(parent);
      return 0;

    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
      return SendMessage(parent,message,wParam,lParam);

    case WM_CREATE:
      return 0;

    case WM_ERASEBKGND:
      {
        PaintDesktop( (HDC) wParam );
        return TRUE;
      }

    case LM_REPAINT: // Manually ask for a paint (stupid)
    case WM_PAINT:
      { // update from doublebuffer
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd,&ps);

        PaintDesktop(hdc);

        PostMessage(parent, LM_FIRSTDESKTOPPAINT, 0, 0);
        EndPaint(hwnd,&ps);
      }
      return 0;

    case WM_SYSCOMMAND:
      {
        switch (wParam) {
          case SC_CLOSE: // stupid but works
            PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
            return 0;
        }
        break;
      }

    case WM_KEYDOWN:
    case WM_KEYUP:
    case WM_HOTKEY:
      // Forward these messages
      PostMessage(parent,message,wParam,lParam);
      return 0;

    case WM_WINDOWPOSCHANGING:
      {
        // Trap windowposchanging messages
        WINDOWPOS *c = (WINDOWPOS*)lParam;
        c->hwndInsertAfter = HWND_BOTTOM;
        c->flags |= SWP_NOMOVE | SWP_NOSIZE;
      }
      return 0;

    case WM_NCPAINT: // one more security
      if (!wParam)
        SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
      return 0;

    case WM_RBUTTONUP: // Open popup menu
      ParseBangCommand(NULL,bangRightClickCommand,bangRightClickOption);
      return 0;

    case WM_LBUTTONUP:
      ParseBangCommand(NULL,bangLeftClickCommand, bangLeftClickOption);
      return 0;

    case WM_MBUTTONUP:
      ParseBangCommand(NULL,bangMiddleClickCommand,bangMiddleClickOption);
      return 0;

    case WM_RBUTTONDOWN: // Close popup menu
    case WM_LBUTTONDOWN:
    case WM_MBUTTONDOWN:
      SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
      return 0;
  }
  return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Sets maximized windows size
// -------------------------------------------------------------------------------------------------------
void Desktop::setMinMax(void) {
  RECT r;

  if (setDesktopArea) {
    r.left = sdaLeft;
    r.top = sdaTop;
    r.right = sdaRight <= 0 ? ScreenWidth + sdaRight : sdaRight;
    r.bottom = sdaBottom <= 0 ? ScreenHeight + sdaBottom : sdaBottom;
  }
  else {
    SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)&r, SPIF_SENDCHANGE);
    r.top = 0;
    r.left = 0;
    r.right = ScreenWidth;
    r.bottom = ScreenHeight;
  }
  SetDesktopArea(r.left, r.top, r.right, r.bottom);
}

// --------------------------------------------------------
// Reset to old maximized windows size
// --------------------------------------------------------
void Desktop::resetMinMax(void)
{
  RECT r;

  if (!setDesktopArea)
    return;
  r.top = 0;
  r.left = 0;
  r.bottom = ScreenHeight;
  r.right = ScreenWidth;
  SetDesktopArea(r.left, r.top, r.right, r.bottom);
}

void Desktop::setDesktopClick(char* Click, char* ClickCommand, char* ClickOption)
{
  char* tokens[2];
  tokens[0] = ClickCommand;
  tokens[1] = ClickOption;
  ClickCommand[0] = ClickOption[0] = '\0';
  LCTokenize(Click, tokens, 1, tokens[1]);
}

void Desktop::setLeftClick(char *args) {
  if (args) {
    setDesktopClick(args, bangLeftClickCommand, bangLeftClickOption);
  }
  else {
    setDesktopClick(bangLeftClick, bangLeftClickCommand, bangLeftClickOption);
  }
}

void BangSetLeftClick(HWND caller, char *args) {
  myDesktop->setLeftClick(args);
}

void Desktop::setRightClick(char *args) {
  if (args) {
    setDesktopClick(args, bangRightClickCommand, bangRightClickOption);
  }
  else {
    setDesktopClick(bangRightClick, bangRightClickCommand, bangRightClickOption);
  }
}

void BangSetRightClick(HWND caller, char *args) {
  myDesktop->setRightClick(args);
}

void Desktop::setMiddleClick(char *args) {
  if (args) {
    setDesktopClick(args, bangMiddleClickCommand, bangMiddleClickOption);
  }
  else {
    setDesktopClick(bangMiddleClick, bangMiddleClickCommand, bangMiddleClickOption);
  }
}

void BangSetMiddleClick(HWND caller, char *args) {
  myDesktop->setMiddleClick(args);
}