/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team
  
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
	
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
 	  
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __DESKTOP_H
#define __DESKTOP_H

#include <windows.h>
#include "../lsapi/lsapi.h"

#define LS_GWL_CLASSPOINTER 0
#define MAX_LINE_LENGTH 4096

#ifdef __cplusplus
extern "C" {
#endif
  
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  
#ifdef __cplusplus
}
#endif

class Desktop {
private:
  HWND hMainWnd;
  HWND parent;
  int ScreenWidth, ScreenHeight;

  int sdaLeft, sdaRight, sdaBottom, sdaTop;
  BOOL setDesktopArea;

  char bangLeftClick[MAX_LINE_LENGTH];
  char bangLeftClickCommand[MAX_LINE_LENGTH];
  char bangLeftClickOption[MAX_LINE_LENGTH];
  char bangRightClick[MAX_LINE_LENGTH];
  char bangRightClickCommand[MAX_LINE_LENGTH];
  char bangRightClickOption[MAX_LINE_LENGTH];
  char bangMiddleClick[MAX_LINE_LENGTH];
  char bangMiddleClickCommand[MAX_LINE_LENGTH];
  char bangMiddleClickOption[MAX_LINE_LENGTH];

public:
  // from LSModule
  void quitModule(HINSTANCE dllInst);
  int initModule(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);

  // Various wacked-out callbacks
  static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

  // Local message handling routines
  LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
  Desktop(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
  void setLeftClick(char *args);
  void setRightClick(char *args);
  void setMiddleClick(char *args);

private:
  void setMinMax(void);
  void resetMinMax(void);
  void setDesktopClick(char* Click, char* ClickCommand, char* ClickOption);
public:
};

#endif
