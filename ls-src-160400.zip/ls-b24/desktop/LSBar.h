/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// Standard system module header

#ifndef __DESKTOP_H
#define __DESKTOP_H

#include <vector>
#include <windows.h>
#include "LSToolTips.h"
#include "LSTrayWindowManager.h"
#include "../litestep/wharfdata.h"
#include "../lsapi/lsapi.h"
#include "../lsutil/LSModule.h"
#include "../lsutil/LSBitmap.h"
#include "../lsutil/LSSettings.h"

#define MAXTRAY 200
#define LS_GWL_CLASSPOINTER 0

using namespace std;

typedef struct {
	HWND trayWnd;
	HWND tooltipWnd;
	HWND hWnd;
	int message;
	UINT uID;
	HICON hIcon;
	HICON hOriginalIcon;
	char szTip[256];
	int x,y;
} trayType;

#define APPBAR_MSG WM_USER+1000;
#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) LRESULT CALLBACK WndShellProc(int code, WPARAM wParam, LPARAM lParam);

}

const char rcsRevision[] = "$Revision: 1.2 $"; // Our Version 
const char rcsId[] = "$Id: LSBar.h,v 1.2 2000/02/14 06:02:10 message Exp $"; // The Full RCS ID.
const char szAppName[] = "DesktopBackgroundClass"; // Our window class, etc
//const char szBar[] = "Shell_TrayWnd";
const char szBar[] = "LitestepTaskbar";
const char szTray[] = "TaskbarTrayWindow";
const char szTasks[] = "MSTaskSwWClass"; 
const char szTrayIcon[] = "TrayIconClass"; // Our window class, etc
const char szAppBtn[] = "AppBtnClass"; // Our window class, etc

class LSTaskBar;

class LSBar: public LSModule {
public:
	LSSettings settings;

	HWND hMainWnd;
	HWND hContWnd; // LS window handle
	HWND hBarWnd;
	HWND parent;
	HWND hToolTips;
	
	BOOL backInit;
	UINT htimer;
	int trayIconSize;
	
	int ScreenWidth, ScreenHeight;
	
	int oldWidth, oldHeight;
	

	BOOL blockAppBarRepos;
	char lsPath[256];
	HINSTANCE dll;
	HWND desktopWnd;
	HWND systray;

	BOOL barLeft;

	int TRISIZE;

	HBITMAP bufferBmp, oldbBmp;
	HDC bufferDC;

	int np;

	BOOL barHiden;
	BOOL hideTimerActive;

	BOOL dontReleaseIcons;

	//APPBARDATA userAppBar[50];

	RECT taskBarRect;

	RECT origWorkArea;


	LSTrayWindowManager *trayWnds;


	OSVERSIONINFO os_info;

	BOOL bAudioAutoplay;


public:
	// from LSModule
	void quitModule(HINSTANCE dllInst);
	int initModule(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);

	// Various wacked-out callbacks
	static BOOL CALLBACK EnumChildWindowsProc(HWND hwnd, LPARAM lParam);
	static LRESULT CALLBACK WndProcBar(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

	// Local message handling routines
	LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcBar(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LSBar(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);

private:
	//static void DebugMessages(HWND caller ,char* args);
	void resetManager();
	//void addWindow(HWND hwnd);
	//void integrateWindow(HWND hwnd);
	int rectOk(HWND hwnd);
	void setMinMax(void);
	void resetMinMax(void);
	//void updateTasksView(int force);
	//HICON GetWindowIcon(HWND Hwnd);
	//void destroyAppWnd(int i);
	void HideBar(void);
	void ShowBar(void);
	//int getTxtSum(HWND wnd);
	int reorderWindows(void);
	void autorun(int drive);
	unsigned char *getAutorunDrives(void);
	//void updateAppBar(HWND hwnd);
	//void RemoveWindow(int win);
	void MinMaxWindow(int win);

	//int IsAppBar(HWND hWnd);
	// These functions have been duplicated in the LSTrayWindow or LSTrayWindowManager classes, but not integrated.
	//void Report(LPCSTR strRep);
	//void GetAppsRect(RECT *r, HWND exclude);
	//void appBarQueryPos(APPBARDATA *data, RECT *rm, int force);
	//void UpdateTooltips(HWND hWnd, char *txt, RECT *r);
	/*void addAppBar(APPBARDATA data, RECT *r);
	void removeAppBar(HWND hwnd);
	void checkAppBars(void);*/
	//void organizeAppBars(void);
	/*int getTrayByIcon(HWND trayIcon);
	int getTrayByWnd(HWND trayIcon);
	void removeAllTrays(void);
	int addToTray(HWND trayWnd, HWND hWnd, int message, HICON hIcon, HICON hOriginalIcon, UINT uID, char *tip);
	void removeFromTray(HWND hWnd, UINT uID);*/

public:
	void DoEvents(int n);
	LSTaskBar *taskBar;
	LSToolTips* toolTips;
	// These functions are accessed from a child object and need to be public
	void adjustWndSizes(void);
};

#endif
