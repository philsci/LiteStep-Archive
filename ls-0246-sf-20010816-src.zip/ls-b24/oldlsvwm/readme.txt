================ Update: 7/15/98 by j_edge - b23d.5
the following commands have been added to modules.ini:
[lsvwm]
BgBMP=bgimage.bmp
Hotkey=1

bgimage.bmp is relative to your LS images directory as defined in your step.rc.
Hotkey can be 0, 1 or 2. 0=Win Key (default if this entry is not present), 
1=Alt Key and 2=Ctrl Key. This chooses which key is pressed with the arrow keys
to switch virtual windows.

================ Update: 6/17/98 by Sehnsucht - b23d.4
in modules ini, put the following info:
[lsvwm]
stickies=X
stickyX=Y
stypeX=Y
where X is the total number of stickies (for stickies=) or the sticky being defined,
and Y is the value. for stickyX= Y is the matching text (use expressions including
* and ?), and stypeX= Y is the type of sticky method. method 0 is the default if one
is not specified, and is title-matching method. metho 1 is the class-matching method.
you can find out the classes using something like Spy++ or 007
Some 'classes' of commonly used programs:
Winamp:
main winamp screen:Winamp v1.x
winamp playlist editor:Winamp PE
winamp graphical EQ:Winamp EQ
ICQ:
main ICQ window thingy??:cant figure it out.. just use title matching for your UIN
EGN:
main window thingy: EGN1


=================
 This directory contains the sources of the VWM module.

 There is no magic involved in the virtual desktop management, the virtual
 windows are just the result of a trick:

 Consider the world as a 2-dimentionnal space. ie (for a 800x600 screen):

     Note: this is not the wharf contents, but a representation of the 2D
           world!


         -800,-600         0,-600        800,-600        1600,-600 
                -----------------------------------------
               |             |             |             |
               |             |             |             |
               |             |             |             |
               |             |0,0          |             |
       -800, 0 |-------------+-------------| 800, 0------| 1600, 0
               |             | ######      |             |
               |             | ######      |             |
               |             | ######  ##  <- This is our screen
               |             |         ##  |             |
                -------------+-------------+-------------|
         -800, 600         0,600         800, 600        |1600, 600
               |             |             |             |
               |             |             |             |
               |             |             |             |
                ----------------------------------------- 1600, 1200
          -800, 1200      0, 1200        800, 1200


          Here is the wharf contents:

                ---------------------------
               | ######     1|            2|       Active deskop is 1
               | ######      |             |
               | ######  ##  |             |
               |         ##  |             |
               |-------------+-------------|
               |            3|            4|
               |             |             |
               |             |             |
               |             |             |
                ---------------------------

   Now what if we want to switch to the virtual screen n2, we just need to
   shift every window position in the system by the size of the screen:


         -800,-600         0,-600        800,-600        1600,-600 
                -----------------------------------------
               |             |             |             |
               |             |             |             |
               |             |             |             |
               |             |0,0          |             |
       -800, 0 |-------------+-------------| 800, 0------| 1600, 0
               | ######      | here is a   |             |
      This     | ######      | new clean   |             |
 windows is  --> ######  ##  | desktop     <- This is our screen (visible)
    invisible! |         ##  |             |             |
                -------------+-------------+-------------|
         -800, 600         0,600         800, 600        |1600, 600
               |             |             |             |
               |             |             |             |
               |             |             |             |
                ----------------------------------------- 1600, 1200
          -800, 1200      0, 1200        800, 1200


    All we have to do now is remember we changed virtual desktop so we know
    were to put windows in the report window:


          Here is the wharf contents:

                ---------------------------
               | ######     1|            2|       Active desktop is 2
               | ######      |             |
               | ######  ##  |             |
               |         ##  |             |
               |-------------+-------------|
               |            3|            4|
               |             |             |
               |             |             |
               |             |             |
                ---------------------------

     To switch to desktop 3, we move all the windows up, and then again left
     to switch to desktop 4.

     From desktop 4 to desktop 1, we move the windows down and right.


     That is how its done basically, of course, the real implementation gives
     some more problems. For example, not all application will support
     running outside of the visible space without strange effect(s).

     - photoshop tries to keep all tool windows visible, so it intercepts our
     move order. We can fix that by hiding those windows when they are not
     in the active desktop and show them back when we come back to their
     desktop

     - applications that open many popups (ex: eudora) open them in the active
     desktop, no matter where their window is. To fix that we can recenter
     any popup window on its parent, but again, this won't apply to every
     application. An interresting approach whould be to make a vwm that would
     let the user tell him which applications to monitor for popups. Currently
     only eudora is monitored because it has the bad habbit of remembering all
     its windows positions. So if a window is not in the active desktop when
     its position is saved, it will be re-opened in another desktop upon the
     next session. Redo this some times and the window will be more and more
     shifted until it has no more chance to be open in a visible desktop.

     - Autodetection of window focus (to autoswitch to the appropriate desktop)
     is one more challenge. Although you can detect changes, how to decide
     whether it occured because of a clock on the window, or from a ALT-TAB, or
     even from the fact that you closed the preceeding window in the Zorder.
     Those 3 operations don't requires the same response from the VWM (click &
     alt-tab should be followed by auto-focus follwing, while closing a window
     should not auto-switch to the new focused window's desktop).

     For those reasons, there still are some bugs in the code (hopefully,
     windows are not lost anymore, but rare reports tells the opposite).

