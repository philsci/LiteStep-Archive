/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <time.h>
#include <comdef.h>
#include "resource.h"
#include "../lsapi/lsapi.h"
#include "Console.h"

const _TCHAR rcsRevision[] = "$Revision: 1.1.1.1 $"; // Our Version
const _TCHAR rcsId[] = "$Id: Console.cpp,v 1.1.1.1 2001/05/31 11:57:41 headius Exp $"; // The Full RCS ID.
const _TCHAR szAppName[] = "ConsoleWindow";

Console *console;

//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
  int code = 0;

  Window::init(dllInst);
  console = new Console(parentWnd, code);

  return code;
}


void quitModule(HINSTANCE dllInst)
{
  delete console;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Console::Console(HWND parentWnd, int &code): Window(szAppName)
{
	ReadSettings();

  if (!createWindow(WS_EX_TOOLWINDOW, "LSConsole", WS_VISIBLE,
                    consoleX, consoleY, consoleWidth, consoleHeight, parentWnd))
  {

    RESOURCE_MSGBOX(GetModuleHandle(NULL), IDS_ERROR1, "Error creating window", szAppName);

    code = 1;
    return;
  }

	RECT client;

	GetClientRect(hWnd, &client);

	listbox = CreateWindow("LISTBOX", "Console Listbox", WS_CHILD | WS_VISIBLE, client.left, client.top, client.right, client.bottom, hWnd, NULL, hInstance, NULL);

	if (consoleOnTop) {
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}

	ILitestep *litestep = (ILitestep*)SendMessage(GetLitestepWnd(), LM_GETLSOBJECT, 0, 0);
	if (litestep) {
		litestep->GetLogDispatch(&log);

		if (log) {
			if (logInfo) {
				info = new ConsoleLogHandler(listbox);
				log->RegisterLogHandler(1, info);
			}
			if (logVerbose) {
				verbose = new ConsoleLogHandler(listbox);
				log->RegisterLogHandler(2, verbose);
			}
			if (logWarning) {
				warning = new ConsoleLogHandler(listbox);
				log->RegisterLogHandler(3, warning);
			}
			if (logNonerr) {
				nonerr = new ConsoleLogHandler(listbox);
				log->RegisterLogHandler(4, nonerr);
			}
			if (logFaterr) {
				faterr = new ConsoleLogHandler(listbox);
				log->RegisterLogHandler(5, faterr);
			}
		}
	}

	InvalidateRect(hWnd, NULL, TRUE);

  code = 0;
}

Console::~Console()
{
	if (log) {
		if (logInfo) {
			log->UnregisterLogHandler(1, info);
		}
		if (logVerbose) {
			log->UnregisterLogHandler(2, verbose);
		}
		if (logWarning) {
			log->UnregisterLogHandler(3, warning);
		}
		if (logNonerr) {
			log->UnregisterLogHandler(4, nonerr);
		}
		if (logFaterr) {
			log->UnregisterLogHandler(5, faterr);
		}
	}

	destroyWindow();
}

ConsoleLogHandler::ConsoleLogHandler(HWND listbox) {
	this->listbox = listbox;
	refCount = 0;
}

ConsoleLogHandler::~ConsoleLogHandler() {
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE ConsoleLogHandler::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_ILogHandler) {
		*ppv = static_cast<ILogHandler*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE ConsoleLogHandler::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE ConsoleLogHandler::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

/////////////////////////////////////////////////////////////////////////////////
// From ILogHandler
HRESULT STDMETHODCALLTYPE ConsoleLogHandler::Log( 
    /* [in] */ BSTR message,
    /* [in] */ int timestamp) {

	_TCHAR buffer[8196];
	time_t t = timestamp;

	buffer[0] = 0;
	_tcscat(buffer, "<");
	_tcsncat(buffer, _tctime(&t), 24);
	buffer[25] = 0;
	_tcscat(buffer, "> ");
	_tcscat(buffer, _bstr_t(message));

	SendMessage(listbox, LB_ADDSTRING, NULL, (LPARAM)buffer);

	return S_OK;
}

//=========================================================
// Message handling
//=========================================================

void Console::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onEndSession, WM_ENDSESSION)
    MESSAGE(onEndSession, WM_QUERYENDSESSION)
    REJECT_MESSAGE(WM_ERASEBKGND)
    REJECT_MESSAGE(WM_PAINT)
    MESSAGE(onGetRevId, LM_GETREVID)
    MESSAGE(onRefresh, LM_REFRESH)
    MESSAGE(onSysCommand, WM_SYSCOMMAND)
  END_MESSAGEPROC
}


void Console::onCreate(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);
}


void Console::onDestroy(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
}


void Console::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Console::onGetRevId(Message& message)
{
  _TCHAR* buf = (_TCHAR*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      _stprintf(buf, "console.dll: %s", &rcsRevision[11]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    case 1:
      _tcscpy(buf, &rcsId[1]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    default:
      _tcscpy(buf, "");
  }
  message.lResult = _tcsclen(buf);
}


void Console::onRefresh(Message& message)
{
}

void Console::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void Console::ReadSettings()
{
	logInfo = GetRCBool("ConsoleLogInformation", TRUE);
	logVerbose = GetRCBool("ConsoleLogVerboseInformation", TRUE);
	logWarning = GetRCBool("ConsoleLogWarnings", TRUE);
	logNonerr = GetRCBool("ConsoleLogNonfatalErrors", TRUE);
	logFaterr = GetRCBool("ConsoleLogFatalErrors", TRUE);

	consoleX = GetRCInt("ConsoleX", 0);
	consoleY = GetRCInt("ConsoleY", 0);
	consoleWidth = GetRCInt("ConsoleWidth", 100);
	consoleHeight = GetRCInt("ConsoleHeight", 200);
	consoleOnTop = GetRCBool("ConsoleOnTop", TRUE);
}
