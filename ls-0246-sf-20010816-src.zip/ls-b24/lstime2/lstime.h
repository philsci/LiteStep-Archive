/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __LSTIME2_H
#define __LSTIME2_H

//#define _NTP_SUPPORT // can _tremove this to _tremove ntp support from lstime
                     // will decrease size of the module quite a bit

#include "..\lsapi\common.h"
#include "..\lsapi\lswinbase.h"
#include "..\wharf\wharf.h"

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#ifdef _NTP_SUPPORT
#include "ntp.h"
#endif

#define MAX_LINE_LENGTH 4096
#define ONE_SEC_IN_MS	1000
#ifndef M_PI
#define M_PI			3.14159265359
#endif

//Typedefs
typedef struct {
	int sX;
	int sY;
	int dX;
	int dY;
	int w;
	int h;
} _6PointPos;
typedef struct {
	int sX;
	int sY;
	int w;
	int h;
} _4PointPos;
typedef struct {
	int dX;
	int dY;
	int w;
	int h;
} _4PointPosA;
typedef struct {
	int dX;
	int dY;
} _2PointPos;
typedef struct {
	HBITMAP usePic;
	HBITMAP oldPic;
	HDC picDC;
} LSTimeImage;

class Lstime : public Window
{
private:
  HDC dblBuf;
	HBITMAP dblBufBMP;
  LSTimeImage bkGrnd;
	//bool backInit;
	wharfDataType wharfData;
	//int wndSize;
  LSTimeImage themePic;
  //_TCHAR ThemePicName[256];
  HBITMAP oldBMP1, oldBMP2, oldBMP3;
  bool globCounter;
  bool firstTime;

  /* This used to be the timeThemeType structure
     and was declared as the curTimeTheme varaible,
     as this was the only placed it was used, just
     gonna make it local private variables
  */
	_4PointPos sDateFontPos;
	_4PointPos sDigiFontPos;
	_4PointPos sAnaDayFontPos;
	_4PointPos sAnaMonthFontPos;
	_2PointPos sDigiClockPos;
	bool bDigiClock;
	_2PointPos sDigiDayPos;
	bool bDigiDay;
	_2PointPos sDigiMonthPos;
	bool bDigiMonth;
	_2PointPos sDigiYearPos;
	bool bDigiYear;
	_2PointPos sDigi2dYearPos;
	bool bDigi2dYear;
	_2PointPos sAnaDayPos;
	bool bAnaDay;
	_2PointPos sAnaMonthPos;
	bool bAnaMonth;
	_4PointPosA sAnaClockPos;
	bool bAnaClock;
	_6PointPos sBackground;
	bool bBackground;
	int cHourHandColor;
	bool bHourHandColor;
	int cHourHandShade;
	bool bHourHandShade;
	int cMinHandColor;
	bool bMinHandColor;
	int cMinHandShade;
	bool bMinHandShade;
	int cSecHandColor;
	bool bSecHandColor;
  /* End old timeThemeType structure */

#ifdef _NTP_SUPPORT
  HMENU popup;

  NtpClient *ntpclient;
#endif

public:
  Lstime(HWND parentWnd, int& code, wharfDataType* wd);
  ~Lstime();

private:

  void themeParse(FILE*);
  //HRGN getLSRegion(int, int);
  void makeBuffer(HWND);
  void drawDigiClock();
  void drawAnaClock();

  virtual void windowProc(Message& message);

  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onMouseButtonDown(Message& message);
  void onMouseButtonDBL(Message& message);
  void onPaint(Message& message);
  void onSysCommand(Message& message);
  void onTimer(Message& message);
#ifdef _NTP_SUPPORT
  void onMouseButtonUp(Message& message);
  void onCommand(Message& message);
#endif
};

extern "C"
{
  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dll);
}

#endif
