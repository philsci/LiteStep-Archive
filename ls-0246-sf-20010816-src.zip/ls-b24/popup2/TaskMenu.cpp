/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"

#include "PopupMaker.h"
#include "TaskMenu.h"
#include "TaskItem.h"

#define TASK_MENU_TIMER 4435

TaskMenu::TaskMenu(const _TCHAR *pszTitle, PopupMaker *pPopupMaker)
	: PopupMenu(pPopupMaker->hInst)
{
	m_pPopupMaker = pPopupMaker;
	m_pszTitle = pszTitle ? strdup(pszTitle) : 0;
}

TaskMenu::~TaskMenu()
{
	if(m_pszTitle)
		free(m_pszTitle);
}

void TaskMenu::OnShow(BOOL fShow)
{
	if(fShow)
	{
		UpdateFolder();
		SetTimer(GetWindow(), TASK_MENU_TIMER, 2000, NULL);
	}
	else
	{
		KillTimer(GetWindow(), TASK_MENU_TIMER);
	}
}

void TaskMenu::OnTimer(int nTimer)
{
	if(nTimer == TASK_MENU_TIMER)
		UpdateFolder();
}

void TaskMenu::UpdateFolder()
{
	DeleteMenuItems();

	m_pPopupMaker->AddHeaderItem(this, m_pszTitle, FALSE);
	EnumWindows(EnumWindowsProc, (LPARAM) this);
	m_pPopupMaker->AddBottomItem(this);

	Sort();
	Invalidate();
	Validate();
}

BOOL TaskMenu::EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	if(IsAppWindow(hWnd))
	{
		TaskMenu *menu = (TaskMenu *) lParam;
		TaskItem *item = new TaskItem(hWnd);

		item->SetActivePainter(menu->m_pPopupMaker->m_pSelEntry);
		item->SetPainter(menu->m_pPopupMaker->m_pEntry);
		item->SetHeight(menu->m_pPopupMaker->m_nSubmenuHeight);
		
		if(menu->m_pPopupMaker->m_bIcons)
			item->SetIcon(GetIconFromWindow(hWnd, FALSE));

		menu->AddMenuItem(item);
	}

	return TRUE;
}
