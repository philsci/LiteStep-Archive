/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "TitleItem.h"
#include "MenuItem.h"
#include "PopupMaker.h"
#include "Painter.h"

extern PopupMaker *pPopupMaker;

TitleItem::TitleItem(_TCHAR* pszTitle)
{
	m_pszTitle = NULL;
	m_hIcon = NULL;

	if(pszTitle != NULL)
	{
		m_pszTitle = strdup(pszTitle);

		// search the string for '&', that is keyboard-shortcuts
		int len = lstrlen(m_pszTitle);
		for(int i=0; i<len; i++)
			if(m_pszTitle[i] == '&' && m_pszTitle[i+1] != '\0')
			{
				int c = _istlower(m_pszTitle[i+1]) ? 
						_toupper(m_pszTitle[i+1]) : 
						m_pszTitle[i+1];
				SetShortcut(c);
				break;
			}
	}
}

TitleItem::~TitleItem()
{
	if(m_pszTitle)free(m_pszTitle);
	m_pszTitle = NULL;
}

void TitleItem::GetMinimumSize(HDC hDC, LPSIZE pMinSize)
{
	SIZE sizeText;
	GetTextExtentPoint32(hDC, m_pszTitle, lstrlen(m_pszTitle), &sizeText);

	MenuItem::GetMinimumSize(hDC, pMinSize);
	pMinSize->cx += sizeText.cx;
	pMinSize->cy = max(pMinSize->cy, sizeText.cy);
}

void TitleItem::Paint(HDC hDC)
{
	RECT rcBackground;
	RECT rcIcon;
	RECT rcText;
	RECT rcArrow;

	CalcRects(&rcBackground, NULL, &rcIcon, &rcText, &rcArrow);
	DrawBackground(hDC, &rcBackground);

	if(pPopupMaker->m_bIcons && ShouldPaintIcon() && HasIcon())
		DrawIcon(hDC, &rcIcon);

	if(m_pszTitle && m_pszTitle[0])
		DrawText(hDC, &rcText, m_pszTitle, GetDrawTextFormat());

	if(pPopupMaker->m_bFolderIcon && !IsLeaf())
		DrawArrow(hDC, &rcArrow);

	/*
	RECT r;

	MenuItem::Paint(hDC);

	GetTitleRect(&r);

	// DrawText(hDC, m_pszTitle, lstrlen(m_pszTitle), &r, 
	//	GetDrawTextFormat());

	Painter *pPainter = m_pBackground;

	if(m_pActiveBackground && m_bActive)
		pPainter = m_pActiveBackground;

	if(pPainter)
		pPainter->PaintText(hDC, r, m_pszTitle, GetDrawTextFormat());

	if(m_bDrawBevel)
		PaintBevel(hDC, m_nTop);
	*/
}

void TitleItem::GetTitleRect(RECT* r)
{
	CalcRects(NULL, NULL, NULL, r, NULL);

	/*
	r->top = m_nTop;
	r->left = m_nLeft + GetIndent() + 3;
	r->bottom = m_nTop + GetHeight() - 1;
	r->right = m_nLeft + GetWidth() - GetRightIndent();

	if(pPopupMaker->m_bIcons && ShouldPaintIcon())
		r->left = r->left + m_nIconSpacing + m_nIconSize;

	if(pPopupMaker->m_bFolderIcon)
		r->right = r->right - m_nIconSpacing - 16;
	*/
}
