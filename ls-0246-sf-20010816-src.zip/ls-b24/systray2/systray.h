/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef  __GRDSYSTRAY
#define  __GRDSYSTRAY

#define WIN32_LEAN_AND_MEAN
#define STRICT
	
#pragma warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include <stdlib.h>
#include <map>
#include "resource.h"
#include "shellTray.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * STRUCTURE: GRDSYSTRAYICON                               * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the structure that is stored for every icon    * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

typedef struct SYSTRAYICON {

	// owner window
	HWND hWnd;
	// id
	UINT uID;
	// callback message ( to send to the owner window )
	UINT uCallbackMessage;
	// icon
	HICON hIcon;
	// icon region
	HRGN hRgn;
	// trayicon rectangle
	RECT rc;

	// tooltip text
	_TCHAR *szTip;
	// tooltip id
	UINT uToolTip;

	struct SYSTRAYICON *pNext, *pPrev;

} SYSTRAYICON, *PSYSTRAYICON;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* * CLASS: grdTray                                          * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* *                                                         * */
/* *  this is the _tmain class, which does all the real work   * */
/* *  it initializes a couple of "sub-classes" that are      * */
/* *  that just to make it easier to understand and manage   * */
/* *  other than that grdTray is a really great LoadModule   * */
/* *                                                         * */
/* *                                      // Gustav Munkby   * */
/* *                                                         * */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class systray : public Window
{
private:
	// booleans
	BOOL onTop;
	BOOL hideIfEmpty;
	BOOL visible;
	BOOL inWharf;

	// tray
	int trayX;
	int trayY;
	int trayWidth;
	int trayHeight;

	// autosize
	BOOL autoSize;

	// borders
	int borderTop; 
	int borderLeft;
	int borderRight;
	int borderBottom;
	BOOL borderDrag;

	int snapDistance;

	// tray wrapping
	int direction;
	int wrapCount;
	int wrapDirection;

	// icon
	int iconSize;
	int iconSpacingX;
	int iconSpacingY;
	int deltaX;
	int deltaY;

	int firstX;
	int lastX;
	int firstY;
	int lastY;

	// icon effects
	COLORREF clrHue;
	UCHAR hueIntensity;
	UCHAR saturnation;
	UCHAR effectFlags;

	BOOL transpBack;
	HBITMAP hbmSkin;
	HBITMAP hbmBack;
	HRGN hrgnBack;
	BOOL skinTiled;
	BOOL transpSkin;

	COLORREF clrBack;
	COLORREF clrBorder;

	HWND liteStep;
	HWND desktop;
	HWND tooltip;

	UINT uLastID;

	PSYSTRAYICON pFirst;
	PSYSTRAYICON pLast;

	shellTray *shelltray;

public:
  systray(HWND parentWnd, int& code);
  ~systray();

	// bang handlers
	void hide();
	void show();
	void toggle();
	void toggleOnTop();
	void move(int x, int y);
	void size(int cx, int cy);

private:
	void paintBackground( HDC hdcDst, HRGN hrgnDst );
	void createBackground();
	void setFirstLast();
	void adjustSize();

	int copyBlt(HDC hdcDst, int xDst, int yDt, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc);
	int sizeBlt(HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc);

	/* *** * LIST MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconListFind(HWND hWnd, UINT uID);
	PSYSTRAYICON iconListFindPt(POINT pt);
	int iconListSave(void *dst);
	int iconListLoad(void *src);
	int iconListLoadMaduin();
	void iconListCleanup();
	BOOL iconListDelAll();
	void iconListPaint(HDC hdcDest, HRGN hrgnDest);

	/* *** * ICON MANAGEMENT FUNCTIONS * *** */
	PSYSTRAYICON iconAdd(PNOTIFYICONDATA pnid);
	BOOL       iconDel(PNOTIFYICONDATA pnid);
	BOOL       iconDelGRD(PSYSTRAYICON pSysTrayIcon);
	PSYSTRAYICON iconMod(PNOTIFYICONDATA pnid);

	void       setIcon(PSYSTRAYICON pSysTrayIcon, HICON hIcon);
	void       setToolTip(PSYSTRAYICON pSysTrayIcon, _TCHAR *tooltip);
	void       adjustRect(PSYSTRAYICON pSysTrayIcon);

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onDisplayChange(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onKeyMessage(Message& message);
  void onMouse(Message& message);
	BOOL onMouseIcon(Message& message);
  void onPaint(Message& message);
  void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onRestoreTray(Message& message);
	void onSaveTray(Message& message);
	void onSysTray(Message& message);
	void onWindowPosChanging(Message& message);
};

void bangHide( HWND sender, _TCHAR *args );
void bangShow( HWND sender, _TCHAR *args );
void bangToggle( HWND sender, _TCHAR *args );
void bangOnTop( HWND sender, _TCHAR *args );
void bangMove( HWND sender, _TCHAR *args );
void bangSize( HWND sender, _TCHAR *args );

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCTSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif// __GRDSYSTRAY