/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/15/02 - Vendicator
  - Now calling GetRCCoordinates to get x,y coordinates (neg&center support).
12/31/00 - Bobby G. Vinyard (Message)
  - Added CommandRememberPosition to allow the module to remember where it was
  last placed
  - Added !CommandResetPos to move the module back to the settings sepecified in
  the step.rc
12/20/00 - Bobby G. Vinyard (Message)
  - Fixed some problems with always on top
  - Added CommandNotMoveable, default is moveable
12/01/00 - Bobby G. Vinyard (Message)
  - Added CommandNotAlwaysOnTop, CommandSelectAllOnFocus
11/28/00 - Bobby G. Vinyard (Message)
  - Added multimonitor support
11/26/00 - Bobby G. Vinyard (Message)
  - Added CommandBevel to put a bevel around the command window
  - Added CommandBevelSize, CommandBevelLightColor, CommandBevelDarkColor
11/25/00 - Bobby G. Vinyard (Message)
  - Added !CommandFocus - will show the command window if it is hidden and
    set focus in the edit control
  - Added response to LM_REFRESH & !Refresh
11/24/00 - Bobby G. Vinyard (Message)
  - Added !CommandShow, !CommandHide, !CommandToggle, CommandHideOnUnfocus,
    CommandHiddenOnStart, CommandNoClearOnCommand (these all function exactly
    like their lsxcommand counterparts)
11/24/00 - Bobby G. Vinyard (Message)
  - Fixed drop files to inclose a path in qoutes if it included spaces
****************************************************************************/
#include <stdio.h>
#include <malloc.h>

#include "command.h"

const char szAppName[] = "Command"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.21 $"; // Our Version

Command *command; // The module

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
WNDPROC pEditWndProc;

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;

	Window::init(dllInst);

	command = new Command(ParentWnd, code);
	return code;
}

void quitModule(HINSTANCE dllInst)
{
	delete command;
}


//=========================================================
// Bang commands
//=========================================================
void BangCommandMoveFunction(HWND caller, LPCSTR args)
{
	command->BangCommandMove(caller, args);
}


void BangCommandToggleFunction(HWND caller, LPCSTR args)
{
	command->BangCommandToggle(caller, args);
}

void BangCommandHideFunction(HWND caller, LPCSTR args)
{
	command->BangCommandHide(caller, args);
}

void BangCommandShowFunction(HWND caller, LPCSTR args)
{
	command->BangCommandShow(caller, args);
}

void BangCommandFocusFunction(HWND caller, LPCSTR args)
{
	command->BangCommandFocus(caller, args);
}

void BangCommandResetPosFunction(HWND caller, LPCSTR args)
{
	command->BangCommandResetPos(caller, args);
}


//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Command::Command(HWND parentWnd, int& code):
		WindowX(szAppName)
{

	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	setupCommand();

	mouseState = false;

	if (!createWindow(WS_EX_TOOLWINDOW,
	                  szAppName,
	                  WS_POPUP | WS_CLIPSIBLINGS,
	                  xpos, ypos, width, height,
	                  GetLitestepWnd()))
	{
		::MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
		code = 1;
		return ;
	}

	onTop(isOnTop);

	SendMessage(GetLitestepWnd(), LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	SetWindowLong(GWL_USERDATA, magicDWord);

	//AddBangCommand("!CommandMove",BangCommandMoveFunction);
	AddBangCommand("!CommandToggle", BangCommandToggleFunction);
	AddBangCommand("!CommandHide", BangCommandHideFunction);
	AddBangCommand("!CommandShow", BangCommandShowFunction);
	AddBangCommand("!CommandFocus", BangCommandFocusFunction);
	AddBangCommand("!CommandResetPos", BangCommandResetPosFunction);

	ShowWindow((isVisible) ? SW_SHOWNORMAL : SW_HIDE);

	UpdateWindow();

	code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Command::~Command()
{

	int msgs[] = {LM_GETREVID, LM_REFRESH, 0};

	SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	//RemoveBangCommand("!CommandMove");
	RemoveBangCommand("!CommandToggle");
	RemoveBangCommand("!CommandHide");
	RemoveBangCommand("!CommandShow");
	RemoveBangCommand("!CommandFocus");
	RemoveBangCommand("!CommandResetPos");

	cleanCommand();

	if (rememberPosition)
	{
		char szKeyName[MAX_LINE_LENGTH];
		WINDOWPLACEMENT wpData;
		HKEY key;
		DWORD result;

		GetWindowPlacement(&wpData);
		strcpy(szKeyName, "Software\\LiteStep\\");
		strcat(szKeyName, szAppName);

		if (RegCreateKeyEx(HKEY_CURRENT_USER, szKeyName, 0,
		                   NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &key, &result) == ERROR_SUCCESS)
		{
			RegSetValueEx(key, "bottom", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.bottom, sizeof(DWORD));
			RegSetValueEx(key, "left", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.left, sizeof(DWORD));
			RegSetValueEx(key, "right", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.right, sizeof(DWORD));
			RegSetValueEx(key, "top", 0, REG_DWORD, (LPBYTE)&wpData.rcNormalPosition.top, sizeof(DWORD));
			RegCloseKey(key);
		}
	}

	destroyWindow();
}

LPCSTR Command::Revision()
{
	return &rcsRevision[11];
}

//=========================================================
// Registered messages
//=========================================================

void Command::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	MESSAGE(onCreate, WM_CREATE)
	MESSAGE(onCtlColorEdit, WM_CTLCOLOREDIT)
	MESSAGE(onSetFocus, WM_SETFOCUS)
	MESSAGE(onNCHitTest, WM_NCHITTEST)
	MESSAGE(onMouseButtonDown, WM_NCLBUTTONDOWN)
	MESSAGE(onMouseButtonDown, WM_NCRBUTTONDOWN)
	MESSAGE(onMouseButtonUp, WM_EXITSIZEMOVE)
	MESSAGE(onSize, WM_SIZING)
	MESSAGE(onEraseBkgnd, WM_ERASEBKGND)
	MESSAGE(onCommand, WM_COMMAND)
	MESSAGE(onKillFocus, WM_USER + 1)
	MESSAGE(onRefresh, LM_REFRESH)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Command::onCreate(Message& message)
{

	hEdit = CreateWindowEx(0L, "EDIT", "", WS_CHILD | ES_LEFT | ES_AUTOHSCROLL,
	                       borderSizeLeft, borderSizeTop,
	                       width - (borderSizeRight + borderSizeLeft),
	                       height - (borderSizeBottom + borderSizeTop),
	                       hWnd, 0, hInstance, 0);

	::DragAcceptFiles(hEdit, TRUE);

	pEditWndProc = (WNDPROC)::SetWindowLong(hEdit, GWL_WNDPROC, (long)EditSubclass);

	SendMessage(hEdit, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(FALSE, 0));

	::ShowWindow(hEdit, SW_SHOW);
}


void Command::onCtlColorEdit(Message& message)
{
	SetBkColor((HDC)message.wParam, colorBG);
	SetTextColor((HDC)message.wParam, colorText);
	message.lResult = (long)hBrush;
}


void Command::onSetFocus(Message& message)
{
	if (selectAllOnFocus)
		SendMessage(hEdit, EM_SETSEL, 0, -1);
}

void Command::onNCHitTest(Message& message)
{
	message.lResult = HTBORDER;
	if (GetAsyncKeyState(VK_MENU))
	{
		message.lResult = getHittest(message.lParam);
	}
}


void Command::onSize(Message& message)
{
	LPRECT rcSize = (LPRECT)message.lParam;
	xpos = rcSize->left;
	ypos = rcSize->top;
	width = rcSize->right - xpos;
	height = rcSize->bottom - ypos;
	::SetWindowPos(hEdit, NULL, borderSizeLeft, borderSizeTop,
	               width - (borderSizeRight + borderSizeLeft),
	               height - (borderSizeBottom + borderSizeTop),
	               SWP_NOZORDER | SWP_NOACTIVATE);
}


void Command::onMouseButtonUp(Message &message)
{
	if (mouseState)
	{
		//  Stop the hack!
		SwapMouseButton(false);

		// W2K Hack to get the mouse set to the correct state
		mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
	}
	mouseState = false;
	Invalidate(true);
}


void Command::onMouseButtonDown(Message &message)
{
	message.wParam = HTNOWHERE;

	if (GetAsyncKeyState(VK_MENU) && (message.uMsg == WM_NCLBUTTONDOWN) && !(mouseState))
	{
		message.wParam = HTCAPTION;
	}
	else if (GetAsyncKeyState(VK_MENU) && (message.uMsg == WM_NCRBUTTONDOWN) && (!mouseState))
	{

		// Hack to stop the resize
		SwapMouseButton(true);
		mouseState = true;

		// W2K Hack to get the mouse set to the correct state
		mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
		mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);

		message.wParam = getHittest(message.lParam);
	}
	DefWindowProc(hWnd, WM_NCLBUTTONDOWN, message.wParam, message.lParam);

}


void Command::onEraseBkgnd(Message &message)
{
	HDC hDC;
	RECT rc;

	hDC = (HDC) message.wParam;
	GetClientRect(&rc);
	FillRect(hDC, &rc, hBorderBrush);

	if (hasBevel)
	{
		Frame3D(hDC, rc, bevelLightColor, bevelDarkColor, bevelSize);
	}

}


void Command::onCommand(Message &message)
{
	switch (message.wParam)
	{
		case IDOK:
		{
			char pszCmd[MAX_PATH];

			::GetWindowText(hEdit, pszCmd, sizeof(pszCmd));

			// trim the string
			PathRemoveBlanks(pszCmd);

			if ((int)LSExecute(hWnd, pszCmd, SW_SHOWNORMAL) > 32)
			{
				mruList.Add((LPCSTR)pszCmd);
			}

			if (clearEditOnCommand)
				::SetWindowText(hEdit, "");
			break;
		}
		// HISTORY PREVIOUS
		case VK_UP:
		{
			char buffer[MAX_LINE_LENGTH];

			mruList.Previous(buffer, sizeof(buffer));
			::SetWindowText(hEdit, buffer);

			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
		// HISTORY NEXT
		case VK_DOWN:
		{
			char buffer[MAX_LINE_LENGTH];

			mruList.Next(buffer, sizeof(buffer));
			::SetWindowText(hEdit, buffer);

			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(buffer));
			break;
		}
	}
}


void Command::onKillFocus(Message& message)
{
	if (hideOnUnfocus && isVisible)
	{
		ShowWindow(SW_HIDE);
		isVisible = (isVisible ? false : true);
	}
}

void Command::onRefresh(Message& message)
{
	cleanCommand();
	setupCommand();
	SetWindowPos(NULL, xpos, ypos, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
	::SetWindowPos(hEdit, NULL, borderSizeLeft, borderSizeTop,
	               width - (borderSizeRight + borderSizeLeft),
	               height - (borderSizeBottom + borderSizeTop),
	               SWP_NOZORDER | SWP_NOACTIVATE);
	SendMessage(hEdit, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(FALSE, 0));
	onTop(isOnTop);
	ShowWindow((isVisible) ? SW_SHOWNORMAL : SW_HIDE);
	UpdateWindow();
}
//=========================================================
// Bang command handling
//=========================================================
void Command::BangCommandMove(HWND caller, LPCSTR args)
{
	/*
	TODO:
	  Add Bang Code Here
	*/
}


void Command::BangCommandToggle(HWND caller, LPCSTR args)
{
	ShowWindow((!isVisible) ? SW_SHOWNORMAL : SW_HIDE);
	isVisible = (isVisible ? false : true);
}

void Command::BangCommandHide(HWND caller, LPCSTR args)
{
	if (isVisible)
	{
		ShowWindow(SW_HIDE);
		isVisible = false;
	}
}

void Command::BangCommandShow(HWND caller, LPCSTR args)
{
	if (!isVisible)
	{
		ShowWindow(SW_SHOWNORMAL);
		isVisible = true;
	}
}

void Command::BangCommandFocus(HWND caller, LPCSTR args)
{
	if (!isVisible)
	{
		ShowWindow(SW_SHOWNORMAL);
		isVisible = true;
	}
	SetForegroundWindow(hEdit);
	::SetFocus(hEdit);
}

void Command::BangCommandResetPos(HWND caller, LPCSTR args)
{
	width = GetRCInt("CommandWidth", 160);
	height = GetRCInt("CommandHeight", 20);
	xpos = GetRCCoordinate("CommandX", 0, GetSystemMetrics(SM_CXSCREEN));
	//xpos = GetRCInt("CommandX", 0);
	//xpos = CONVERT_COORDINATE_X(xpos);
	ypos = GetRCCoordinate("CommandY", 0, GetSystemMetrics(SM_CYSCREEN));
	//ypos = GetRCInt("CommandY", 0);
	//ypos = CONVERT_COORDINATE_Y(ypos);
	SetWindowPos(NULL, xpos, ypos, width, height, SWP_NOZORDER | SWP_NOACTIVATE);
	::SetWindowPos(hEdit, NULL, borderSizeLeft, borderSizeTop,
	               width - (borderSizeRight + borderSizeLeft),
	               height - (borderSizeBottom + borderSizeTop),
	               SWP_NOZORDER | SWP_NOACTIVATE);
}

void Command::setupCommand()
{
	char configLine[MAX_LINE_LENGTH];

	width = GetRCInt("CommandWidth", 160);
	height = GetRCInt("CommandHeight", 20);
	xpos = GetRCInt("CommandX", 0);
	xpos = CONVERT_COORDINATE_X(xpos);
	ypos = GetRCInt("CommandY", 0);
	ypos = CONVERT_COORDINATE_Y(ypos);
	borderSize = GetRCInt("CommandBorderSize", -1);
	if (borderSize == -1)
	{
		borderSizeBottom = GetRCInt("CommandBottomBorderSize", 2);
		borderSizeTop = GetRCInt("CommandTopBorderSize", 2);
		borderSizeLeft = GetRCInt("CommandLeftBorderSize", 2);
		borderSizeRight = GetRCInt("CommandRightBorderSize", 2);
	}
	else
	{
		borderSizeBottom = borderSize;
		borderSizeTop = borderSize;
		borderSizeLeft = borderSize;
		borderSizeRight = borderSize;
	}

	GetRCString("CommandTextFontFace", configLine, "Arial", 256);
	szFontFace = new char[StrLen(configLine) + 1];
	StrCopy(szFontFace, configLine);
	colorBG = GetRCColor("CommandBGColor", RGB(255, 255, 255));
	colorBorder = GetRCColor("CommandBorderColor", RGB(255, 255, 255));
	colorText = GetRCColor("CommandTextColor", RGB(0, 0, 0));
	textSize = GetRCInt("CommandTextSize", 14);

	// 3d decoration colors
	hasBevel = GetRCBool("CommandBevel", true);
	bevelLightColor = GetRCColor("CommandBevelLightColor", GetSysColor(COLOR_3DHILIGHT));
	bevelDarkColor = GetRCColor("CommandBevelDarkColor", GetSysColor(COLOR_3DSHADOW));
	bevelSize = GetRCInt("CommandBevelSize", 1);

	hideOnUnfocus = GetRCBool("CommandHideOnUnfocus", true);
	isVisible = GetRCBool("CommandHiddenOnStart", false);
	isOnTop = GetRCBool("CommandNotAlwaysOnTop", false) != FALSE;
	clearEditOnCommand = GetRCBool("CommandNoClearOnCommand", false);
	selectAllOnFocus = GetRCBool("CommandSelectAllOnFocus", true);
	rememberPosition = GetRCBool("CommandRememberPosition", true);

	if (rememberPosition)
	{
		char szKeyName[MAX_LINE_LENGTH];
		HKEY key;

		strcpy(szKeyName, "Software\\LiteStep\\");
		strcat(szKeyName, szAppName);

		if (RegOpenKeyEx(HKEY_CURRENT_USER, szKeyName, 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
		{
			DWORD nValue;
			unsigned long len = sizeof(DWORD);
			unsigned long tp = REG_DWORD;
			if (RegQueryValueEx(key, "top", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
			{
				ypos = nValue;
			}
			if (RegQueryValueEx(key, "bottom", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
			{
				height = nValue - ypos;
			}
			if (RegQueryValueEx(key, "left", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
			{
				xpos = nValue;
			}
			if (RegQueryValueEx(key, "right", 0, &tp, (LPBYTE)&nValue, &len) == ERROR_SUCCESS)
			{
				width = nValue - xpos;
			}
			RegCloseKey(key);
		}
	}

	hBorderBrush = CreateSolidBrush(colorBorder);
	hFont = CreateFont(textSize, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, szFontFace);
	hBrush = CreateSolidBrush(colorBG);

}

void Command::cleanCommand()
{
	delete[] szFontFace;
	DeleteObject(hFont);
	DeleteObject(hBrush);
	DeleteObject(hBorderBrush);
}


long Command::getHittest(LPARAM lParam)
{
	POINT pt;
	RECT rcRect;

	pt.x = GET_X_LPARAM(lParam);
	pt.y = GET_Y_LPARAM(lParam);
	ScreenToClient(&pt);
	GetClientRect(&rcRect);

	if (pt.x <= (rcRect.left + borderSizeLeft))
	{
		if (pt.y >= (rcRect.bottom - borderSizeBottom))
		{
			return HTBOTTOMLEFT;
		}
		else if (pt.y <= (rcRect.top + borderSizeTop))
		{
			return HTTOPLEFT;
		}
		else
		{
			return HTLEFT;
		}
	}
	else if (pt.x >= (rcRect.right - borderSizeRight))
	{
		if (pt.y >= (rcRect.bottom - borderSizeBottom))
		{
			return HTBOTTOMRIGHT;
		}
		else if (pt.y <= (rcRect.top + borderSizeTop))
		{
			return HTTOPRIGHT;
		}
		else
		{
			return HTRIGHT;
		}
	}
	else if (pt.y <= (rcRect.top + borderSizeTop))
	{
		if (pt.x >= (rcRect.right - borderSizeRight))
		{
			return HTTOPRIGHT;
		}
		else if (pt.x <= (rcRect.left + borderSizeLeft))
		{
			return HTTOPLEFT;
		}
		else
		{
			return HTTOP;
		}
	}
	else if (pt.y >= (rcRect.bottom - borderSizeBottom))
	{
		if (pt.x >= (rcRect.right - borderSizeRight))
		{
			return HTBOTTOMRIGHT;
		}
		else if (pt.x <= (rcRect.left + borderSizeLeft))
		{
			return HTBOTTOMLEFT;
		}
		else
		{
			return HTBOTTOM;
		}
	}
	return HTNOWHERE;
}

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static char pszPattern[MAX_PATH] = {'\0'};
	static HANDLE handle;
	static WIN32_FIND_DATA found;
	BOOL bContinue;

	switch (uMsg)
	{
		case WM_KEYDOWN:
		{
			switch (wParam)
			{
				case VK_RETURN:
				PostMessage(GetParent(hwnd), WM_COMMAND, IDOK, NULL);
				if (lstrlen(pszPattern) > 0)
				{
					FindClose(handle);
					pszPattern[0] = '\0';
				}
				break;
				case VK_ESCAPE:
				/*ShowWindow(hwnd, SW_HIDE);
				SetFocus(GetParent(hwnd));
				if(lstrlen(pszPattern) > 0)
			{
				  FindClose(handle);
				  pszPattern[0] = '\0';
			}*/
				SetWindowText(hwnd, "");
				break;
				case VK_TAB:
				case VK_F2:
				// Auto completion

				if (lstrlen(pszPattern) == 0)
				{
					GetWindowText(hwnd, pszPattern, sizeof(pszPattern));
					strcat(pszPattern, "*");
					handle = FindFirstFile(pszPattern, &found);
					bContinue = (handle != INVALID_HANDLE_VALUE);

					// ignore the . and .. directories
					while (bContinue && (lstrcmp(found.cFileName, ".") == 0 || (lstrcmp(found.cFileName, "..") == 0)))
						bContinue = FindNextFile(handle, &found);
				}
				else
				{
					bContinue = (FindNextFile(handle, &found) != 0);
				}

				// if the last search did find some file then update
				// the editbox
				if (bContinue)
				{
					char path_buffer[_MAX_PATH];
					char drive[_MAX_DRIVE];
					char dir[_MAX_DIR];

					_splitpath(pszPattern, drive, dir, NULL, NULL);
					_makepath(path_buffer, drive, dir, found.cFileName, NULL);
					SetWindowText(hwnd, path_buffer);

					// move the cursor to the end of the line
					CallWindowProc(pEditWndProc, hwnd, WM_KEYDOWN, VK_END, 0);
				}
				else
				{
					FindClose(handle);
					pszPattern[0] = '\0';
				}
				break;
				case VK_UP:
				case VK_DOWN:
				PostMessage(GetParent(hwnd), WM_COMMAND, wParam, NULL);
				break;
				default:
				if (lstrlen(pszPattern) > 0)
				{
					FindClose(handle);
					pszPattern[0] = '\0';
				}
				break;
			}
		}
		break;
		case WM_DROPFILES:
		{
			UINT uSize = DragQueryFile((HDROP)wParam, 0, NULL, 0);
			LPSTR szFileName = new char[uSize + 10];
			DragQueryFile((HDROP)wParam, 0, szFileName, uSize + 1);
			if (strchr(szFileName, ' ') != NULL)
			{
				LPSTR szQoutedPath = new char[uSize + 3];
				sprintf(szQoutedPath, "\"%s\"", szFileName);
				SetWindowText(hwnd, szQoutedPath);
				delete [] szQoutedPath;
			}
			else
			{
				SetWindowText(hwnd, szFileName);
			}
			delete [] szFileName;
			SetFocus(hwnd);
			DragFinish((HDROP)wParam);
		}
		break;
		case WM_KILLFOCUS:
		{
			PostMessage(GetParent(hwnd), WM_USER + 1, wParam, lParam);
		}
		break;
	}
	return CallWindowProc(pEditWndProc, hwnd, uMsg, wParam, lParam);
}

