/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include "TrayManager.h"
#include "..\lsapi\lsapi.h"

TrayManager *theManager;

// TrayManager constructor
TrayManager::TrayManager(HWND lswnd, HINSTANCE lsdll, LPCSTR lspath)
{
	lsWindow = lswnd;
	dll = lsdll;
	lsPath = lspath;

	UINT Msgs[4];

	dontReleaseIcons = FALSE;
	WNDCLASSEX wc;

	// Register tray notification window class
	memset(&wc, 0, sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.cbClsExtra = 0;

	wc.lpfnWndProc = TrayManager::WndProcTray;			// our window procedure
	wc.hInstance = lsdll;							// hInstance of DLL
	wc.lpszClassName = TRAYMANAGER_CLASS;			// our window class name
	wc.style = CS_DBLCLKS;
	if (!RegisterClassEx(&wc))
	{
		MessageBox(lsWindow, "Error registering window class", TRAYMANAGER_CLASS, MB_OK | MB_TOPMOST);
	}

	// Tray Manager Window
	hTrayWnd = CreateWindowEx(
	               WS_EX_TOPMOST | WS_EX_TOOLWINDOW, 				// exstyles
	               TRAYMANAGER_CLASS, 											// our window class name
	               "LSMSSysTray", 									// use description for a window title
	               WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 	// styles
	               0, 0, 		// position
	               10, 10, 				// width & height of window
	               GetLitestepWnd(), 										// parent window
	               NULL, 											// no menu
	               dll, 										// hInstance of DLL
	               NULL);											// no window creation data
	if (!hTrayWnd)
	{
		MessageBox(lsWindow, "Error creating window", TRAYMANAGER_TITLE, MB_OK | MB_TOPMOST);
	}

	SetWindowLong(hTrayWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hTrayWnd, 0, (LONG)this);

	// Register desktop-specific LS messages
	Msgs[0] = LM_GETREVID;
	Msgs[1] = LM_SAVESYSTRAY;
	Msgs[2] = LM_RESTORESYSTRAY;
	Msgs[3] = 0;
	SendMessage(lsWindow, LM_REGISTERMESSAGE, (WPARAM)hTrayWnd, (LPARAM)Msgs);
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for the _tsystem tray window
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK TrayManager::WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	TrayManager *theTrayManager = (TrayManager*)::GetWindowLong(hwnd, 0);

	if (theTrayManager)
	{
		return theTrayManager->WindowProcTray(hwnd, message, wParam, lParam);
	}
	else
	{
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT TrayManager::WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_ENDSESSION:
		case WM_QUERYENDSESSION:
		// forward end session msgs to LS
		return SendMessage(lsWindow, message, wParam, lParam);
		case WM_CREATE:
		return 0;
		case WM_SYSCOMMAND:
		switch (wParam)
		{
			case SC_CLOSE:
			PostMessage(lsWindow, WM_KEYDOWN, LM_SHUTDOWN, 0);
			return 0;
		}
		break;
		case WM_COPYDATA:
		// This is how the _tsystem handles tray icons. It is undocumented API.
		// Tray Manager only informs lightstep that it should broadcast the
		// tray message.
		{
			NOTIFYICONDATA *data;
			COPYDATASTRUCT *d;

			d = (COPYDATASTRUCT *)lParam;

			switch (d->dwData)
			{
				case 1:  // Forward System Tray
				data = (NOTIFYICONDATA*)((LPSTR)(d->lpData) + 8);

				switch (*(int *)((LPSTR)d->lpData + 4))
				{
					case NIM_ADD:
					// Maduin
					// Re-send message to Litestep mains, allows forwarding to other interested modules
					SystrayMessage((PSHELLTRAYDATA)d->lpData);

					addTrayInfo(data);
					break;
					case NIM_DELETE:
					// Maduin
					// Forward message to LS for forwarding to other modules
					SystrayMessage((PSHELLTRAYDATA)d->lpData);

					// Remove icon from tray
					removeTrayInfo(data);
					break;
					case NIM_MODIFY:
					// Maduin
					// Forward message to LS for forwarding to other modules
					SystrayMessage((PSHELLTRAYDATA)d->lpData);

					modifyTrayInfo(data);
					break;
				}
			}
		}
		return TRUE;

		case LM_SAVESYSTRAY:  // Litestep is asking us for a bunch of data about the
		// System Tray contents (save/restore systray upon recycle
		{
			saveTrayIcons((void*)lParam);

			dontReleaseIcons = TRUE;
			return 0;
		}
		case LM_RESTORESYSTRAY:  // Litestep restores the previously saved _tsystem tray
		{
			restoreTrayIcons((void*)lParam);

			return 0;
		}
		case LM_SENDSYSTRAY: 			// a program is requesting the _tsystem tray icons
		{
			/*NOTIFYICONDATA nid;
			COPYDATASTRUCT cds;
			int cIcons=1;

			cds.dwData = wParam;					// provided in case the program needs some kind
			// of tagging (TraySaver does)
			cds.cbData = sizeof(NOTIFYICONDATA);
			cds.lpData = &nid;

			nid.cbSize = sizeof(NOTIFYICONDATA);
			nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;

			while(trayWnds[cIcons-1].hWnd) {
				nid.hWnd = trayWnds[cIcons].hWnd;
				nid.uID = trayWnds[cIcons].uID;
				nid.hIcon = trayWnds[cIcons].hOriginalIcon;
				nid.uCallbackMessage = trayWnds[cIcons].message;
				strcpy(nid.szTip, trayWnds[cIcons].szTip);
				
				SendMessage((HWND) lParam, WM_COPYDATA, (WPARAM) hMainWnd, (LPARAM) &cds );
				
				cIcons++;
		}
			return cIcons;*/
		}
	}

	return DefWindowProc(hwnd, message, wParam, lParam);
}

// -------------------------------------------------------------------------------------------------------
// Add a new icon to _tsystem tray
// -------------------------------------------------------------------------------------------------------
void TrayManager::addTrayInfo(NOTIFYICONDATA *data)
{
	NID_vector::iterator iter;

	iter = trayWnds.begin();
	while (iter != trayWnds.end())
	{
		if (iter->uID == data->uID && iter->hWnd == data->hWnd)
		{
			modifyTrayInfo(data);
			return ;
		}

		iter++;
	}

	trayWnds.push_back(*data);
}

// -------------------------------------------------------------------------------------------------------
// Removes an icon from the _tsystem tray
// -------------------------------------------------------------------------------------------------------
void TrayManager::removeTrayInfo(NOTIFYICONDATA *data)
{
	NID_vector::iterator iter;

	iter = trayWnds.begin();
	while (iter != trayWnds.end())
	{
		if (iter->uID == data->uID && iter->hWnd == data->hWnd)
		{
			trayWnds.erase(iter);
			break;
		}

		iter++;
	}
}

TrayManager::~TrayManager()
{
	DestroyWindow(hTrayWnd); // delete our window

	UnregisterClass(TRAYMANAGER_CLASS, dll); // unregister window class
}

// broadcast LM_SYSTRAY message to all interested
// modules. allows for alternate systray mods. -- Maduin

BOOL TrayManager::SystrayMessage( PSHELLTRAYDATA pstd )
{
	NOTIFYICONDATA nid;

	nid.cbSize = sizeof(NOTIFYICONDATA);
	nid.hWnd = pstd->nid.hWnd;
	nid.uID = pstd->nid.uID;
	nid.uFlags = pstd->nid.uFlags;
	nid.uCallbackMessage = pstd->nid.uCallbackMessage;
	nid.hIcon = pstd->nid.hIcon;
	nid.szTip[0] = 0;

	if ( nid.uFlags & NIF_TIP )
	{
		lstrcpyn( nid.szTip, pstd->nid.szTip, 64 );
	}

	return (BOOL)SendMessage(GetLitestepWnd(), LM_SYSTRAY, pstd->dwMessage, (LPARAM) &nid );
}

void TrayManager::modifyTrayInfo(NOTIFYICONDATA *data)
{
	NID_vector::iterator iter;

	iter = trayWnds.begin();
	while (iter != trayWnds.end())
	{
		if (iter->uID == data->uID && iter->hWnd == data->hWnd)
		{
			*iter = *data;
			break;
		}

		iter++;
	}
}

int initModuleEx(HWND lswnd, HINSTANCE lsdll, LPCSTR lspath)
{
	theManager = new TrayManager(lswnd, lsdll, lspath);

	if (theManager)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

void quitModule(HINSTANCE lsdll)
{
	if (theManager)
	{
		delete theManager;
		theManager = NULL;
	}
}

void TrayManager::saveTrayIcons(void *dest)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)dest;
	NID_vector::iterator trayIter = trayWnds.begin();
	int i = 0;

	while (trayIter != trayWnds.end())
	{
		trayArray[i] = *trayIter;

		i++;
		trayIter++;
	}

	trayArray[i].hWnd = 0;
}

void TrayManager::restoreTrayIcons(void *src)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)src;
	int i = 0;

	while (trayArray[i].hWnd != 0)
	{
		trayWnds.push_back(trayArray[i]);

		SendMessage(GetLitestepWnd(), LM_SYSTRAY, NIM_ADD, (LPARAM)&trayArray[i]);
		i++;
	}
}
