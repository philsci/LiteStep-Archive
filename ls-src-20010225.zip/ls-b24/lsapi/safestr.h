/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __SAFESTR_H
#define __SAFESTR_H
#include <tchar.h>
#include <mapinls.h>
#include <string>

using namespace std;


// Safe version of _tcsclen()
inline size_t StrLen(LPCSTR szString)
{
  return (szString ? strlen(szString) : 0);
}


// Safe version of _tcscpy()
inline LPTSTR StrCopy(LPSTR szDest, LPCSTR szSource)
{
  return (szDest && szSource ? strcpy(szDest, szSource) : NULL);
}


// Checks if chr exists in szString
bool CharInStr(const char chr, LPCSTR szString);

// Returns the first occurrence of s2 in s1, ignoring case
LPCSTR StrIPos(LPCSTR s1, LPCSTR s2);

// Copies at most dwMaxLen chars from the source
LPSTR StrLCopy(LPSTR szDest, LPCSTR szSource, size_t dwMaxLen);

// Safe version of _tcsclen()
inline size_t StrLenW(LPCWSTR szString)
{
  return (szString ? wcslen(szString) : 0);
}


// Safe version of _tcscpy()
inline LPWSTR StrCopyW(LPWSTR szDest, LPCWSTR szSource)
{
  return (szDest && szSource ? wcscpy(szDest, szSource) : NULL);
}


// Checks if chr exists in szString
bool CharInStrW(const wchar_t chr, LPCWSTR szString);

// Returns the first occurrence of s2 in s1, ignoring case
LPCWSTR StrIPosW(LPCWSTR s1, LPCWSTR s2);

// Copies at most dwMaxLen chars from the source
LPWSTR StrLCopyW(LPWSTR szDest, LPCWSTR szSource, size_t dwMaxLen);


#endif
 