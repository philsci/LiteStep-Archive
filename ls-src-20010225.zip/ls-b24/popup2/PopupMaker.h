/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_)
#define AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_RC_STRING 256

#include <vector>

using namespace std;

extern const _TCHAR rcsRevision[];
extern const _TCHAR rcsId[];

class PopupMenu;
class Painter;
class MenuItem;

class PopupMaker
{
public:
	PopupMaker();
	~PopupMaker();

	void Show(int index = 0);
	void Hide(int index = 0);

	void ShowDesktopMenu();
	void ShowTaskMenu();

	void Initialize(HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath);

	void ParseStepRC();
	void ParseFolder(FILE *pStepRC, PopupMenu *pRoot);
	BOOL ParseLine(FILE *pStepRC, PopupMenu *pRoot, _TCHAR *pszLine);

	PopupMenu *LoadFolder(LPTSTR pszTitle, LPTSTR pszFolder, LPTSTR pszFilter);

	Painter* MakePainter(LPTSTR pszImage, DWORD dwColor, DWORD dwGradColor, BOOL bGrad, BOOL bSwap);

	/**
	Returns a new MenuItem according to pszItem with the pszTitle

	@param pszItem name of the menu item to create
	@param pszTitle the title of the menu item
	@return a new menu item, or NULL if none suitable was found
	*/
	MenuItem* MakeBangItem(LPTSTR pszItem, LPTSTR pszTitle);

	/**
	adds the bottom image to the menu item. if m_pBottom is not pointing at NULL
	then nothing happens

	@param pMenu pointer to the menu that shall receive a bottom image
	*/
	void AddBottomItem(PopupMenu* pMenu);

	void AddHeaderItem(PopupMenu* pMenu, LPTSTR pszTitle, BOOL bVeto);

//private:

	vector<PopupMenu *> m_RootMenus;
	vector<Painter*> m_Painters;

	HINSTANCE hInst;
	_TCHAR m_pszTitlePix[MAX_RC_STRING];
	_TCHAR m_pszEntryPix[MAX_RC_STRING];
	_TCHAR m_pszSelEntryPix[MAX_RC_STRING];
	_TCHAR m_pszSeparatorPix[MAX_RC_STRING];
	_TCHAR m_pszBottomPix[MAX_RC_STRING];
	_TCHAR m_pszFontFace[MAX_RC_STRING];
	_TCHAR m_pszEntryFontFace[MAX_RC_STRING];

	_TCHAR m_szHotListName[MAX_RC_STRING];

	BOOL m_bHeader;
	BOOL m_bHeaderText;
	BOOL m_bTransparent;

	BOOL m_bShowExtension;
	BOOL m_bAutoSeparator;
	BOOL m_bFolderIcon;
	BOOL m_bPinnedAlwaysOnTop;

	BOOL m_bGradientTitle;
	DWORD m_nGradientTitle;
	BOOL m_bGradientEntry;
	DWORD m_nGradientEntry;

	_TCHAR m_pszDefaultIcon[MAX_RC_STRING];
	BOOL m_bIcons;
	int m_nIconSpacing;
	int m_nIconSize;

	int m_nTitleHeight;
	int m_nSubmenuHeight;
	int m_nSeparatorHeight;
	int m_nBottomHeight;

	DWORD m_nTitleColor;
	DWORD m_nInActiveTitleColor;
	DWORD m_nEntryColor;
	DWORD m_nSelEntryColor;


	DWORD m_nTitleTextColor;
	DWORD m_nEntryTextColor;
	DWORD m_nSelEntryTextColor;

	DWORD m_nBevelLightColor;
	DWORD m_nBevelDarkColor;
	
	int m_nDateTimeAlignment;

	PopupMenu *m_pRoot;
	PopupMenu *m_pDesktopMenu;
	PopupMenu *m_pTaskMenu;

	HFONT m_hDefaultFont;
	HFONT m_hEntryFont;

	Painter* m_pTitle;
	Painter* m_pInactiveTitle;
	Painter* m_pEntry;
	Painter* m_pSelEntry;
	Painter* m_pSeparator;
	Painter* m_pBottom;
};

#endif // !defined(AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_)
