/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(__SHELLFOLDER_H)
#define __SHELLFOLDER_H

#include "FolderItem.h"
#include "PopupMaker.h"
#include "PopupMenu.h"
#include "ContextMenu.h"

class ShellFolder : public FolderItem
{
public:

	ShellFolder(PopupMaker *pPopupMaker, IShellFolder *pshf, LPITEMIDLIST pidlFull, LPITEMIDLIST pidl, LPTSTR pszTitle, int iIcon, HIMAGELIST hImageList);
	ShellFolder(PopupMaker *pPopupMaker, LPTSTR pszTitle, int csidl);
	virtual ~ShellFolder();

	virtual PopupMenu *GetSubMenu() { return m_pSubMenu; }
	virtual void SetSubMenu(PopupMenu *pSubMenu);

	BOOL Active(BOOL bActivate);
	BOOL IsLeaf();

	void Attached(PopupMenu *pParent);
	void GetTitleRect(RECT *prc);
	void Invoke();
	void RInvoke();
	void Paint(HDC hDC);

	BOOL OnUser(int nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult);

protected:

	void UpdateFolder();

	static bool SortFunction(void *pvSortParam, MenuItem *m1, MenuItem *m2);
	static DWORD WINAPI ThreadProc(void *pvParameter);

	PopupMaker *m_pPopupMaker;
	IShellFolder *m_pshf;
	LPITEMIDLIST m_pidlFull;
	LPITEMIDLIST m_pidl;

	PopupMenu *m_pLoadingFolder;
	HANDLE m_hThread;
	BOOL m_bFolderLoaded;
	HANDLE m_hNotify;
};

LPITEMIDLIST CreateIDList(int);
LPITEMIDLIST DuplicateIDList(LPCITEMIDLIST);
// LPITEMIDLIST DuplicateLastID( LPCITEMIDLIST );
LPITEMIDLIST JoinIDLists(LPCITEMIDLIST, LPCITEMIDLIST);
int GetIDListSize(LPCITEMIDLIST);
LPCITEMIDLIST NextID(LPCITEMIDLIST);
void FreeIDList(LPITEMIDLIST);

struct NOTIFYREGISTER
{
	LPITEMIDLIST pidl;
	BOOL bWatchSubtree;
};

#define SHCNF_ACCEPT_INTERRUPTS 0x0001
#define SHCNF_ACCEPT_NON_INTERRUPTS 0x0002
#define SHCNF_NO_PROXY 0x8000

HANDLE SHChangeNotifyRegister(HWND hWnd, DWORD dwFlags, DWORD dwEventMask, UINT nMessage, UINT cItems, NOTIFYREGISTER *pItems);
BOOL SHChangeNotifyDeregister(HANDLE hNotify);

#endif
