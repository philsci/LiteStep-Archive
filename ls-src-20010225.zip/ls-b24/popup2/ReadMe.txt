===============================================================================
POPUP RELEASE 8
===============================================================================

Popup is a replacement for the popup.dll that is supplied with LiteSTEP.

Johan Redestig, johan@house5.se
http://www.house5.se/litestep

CONTRIBUTORS
============
* Briareos (Tom Dow)

===============================================================================
CONDITIONS OF USE
===============================================================================

This software is licensed under GNU.
The source code of the original popup is available at http://www.litestep.net
Expect this software to be buggy. I take no responsibility of it what so ever!

===============================================================================
INSTALL
===============================================================================
You need to have Litestep in order to use this software. Litestep is available
at http://www.litestep.net

Place the popup.dll file in a directory of you choice and make sure that your
step.rc is pointing at it. I recommend that you keep the old popup.dll. If you
are not satisfied with this then you can always revert.

LoadModule Popup.dll

===============================================================================
FEATURES
===============================================================================

TEAR OFF
========
Use the mouse and drag the caption of a folder away from its parent.
The submenu is now 'pinned' to the desktop. If you wish to remove 
the submenu simply double-click on the X icon in the upper right corner.

How do I pin the root menu to the desktop? - Double click in the upper
right corner of the root menu caption.

KEYBOARD SHORTCUTS
==================
In you step.rc where you define the title of an menu item you can add an &
(ampersand) char before the char that you wish to be the shortcut.
Example:
			*Popup "R&un" !Run
Whenever the popup is active you can hit 'u' and the !Run command will be
executed.


===============================================================================
STEP.RC SETTINGS
===============================================================================
I have just listed the commands that differ from the standard popup. The others
should be supported as well.

PopupGradientTitle
==================
Makes the popup menu gradient, like win98 window captions. The popup uses the 
color that you specify with PopupTitleBg color. 
The default value if this variable is black. It can be defined to any
color of you choice:

; Gradient popup titles (fading to black)
PopupGradientTitle

; Gradient popup titles (fading to AABBCC)
PopupGradientTitle AABBCC


PopupGradientEntry
==================
Makes popup entries gradient. (like win98 ...). used PopupEntryBg Color.
The default value if this variable is black. It can be defined to any
color of you choice:

; Gradient popup entries (fading to black)
PopupGradientEntry

; Gradient popup entries (fading to AABBCC)
PopupGradientEntry AABBCC

PopupIcons
==========
Pains icons in the popup menu (this have impact on performance)


PopupTitleBgColor
=================
If you do not specify any title pix this value will be used to paint the 
title with a solid color. if you do not specify this either then the system 
default color for captions will be used.


PopupEntryBgColor
=================
If you do not specify any entry pix this value will be used to paint the 
entry with a solid color. if you do not specify this either then the system 
default color for popups will be used.


PopupSelEntryBgColor
====================
If you do not specify any sel entry pix this value will be used to paint the 
sel entry with a solid color. if you do not specify this either then the system 
default color for popups will be used.


PopupBevelLightColor
====================
The color used for 3d effects on bevels etc.


PopupBevelDarkColor
===================
The color used for 3d effects on bevels etc.


NoPopupMenuBevel
================
Disables the popup wide bevel

PopupOverlapX PopupOverlapY
===========================
How much you like child popups to overlap their parents. I you like the 
official popup, just set these values to 

PopupOverlapX 0
PopupOverlapY 0

PopupEntryFontFace
==================
The font to be used within the popup menu.

; Use times new roman in the popup
PopupEntryFontFace "Times New Roman"

NoPopupCloseButton
==================
When a popup menu is torn of its parent it will draw a ugly X icon in
the top right corner. if you do not like this just set the
NoPopupCloseButton in your rc.

If NoPopupCloseButton is defined then one can double click anywhere in the
title of a popup to pin/release it.

PinnedPopupNotOnTop
===================
Define PinnedPopupNotOnTop to make pinned popups move to the background.

PopupShowExtension
==================
Define if you like to see the extensions of files.

PopupBlt
========
Controls how bitmaps are painted. The available alternatives 
are Normal, Stretch and Tile

; Normal (default)
PopupBlt 0

; Stretch the images to fill the menuitem (pretty slow)
PopupBlt 1

; Tile the images
PopupBlt 2


!RemoteAmp
==========
Remotecontrol for winamp, apollo and kjofol in the popup menu! 
The item gives you basic access to the play, stop, next, previous buttons. 
The item need an background image. 
(if you are not familiar with apollo, take a look at http://apollo.grooveclub.com/)

*Popup !RemoteAmp remoteamp.bmp

For an example of a background.bmp take a look at:

http://www.house5.se/litestep/remoteamp.jpg


!PopupImage
===========
An image for an menu item. The standard popup menu has a command for bottom image 
or something like that. this command makes an image appear anywhere you want in
the popup menu. the image may have the GREAT PINK(TM) color for transparency.

*Popup !PopupImage name_of_image.bmp


!DateTime
=========
The time and date in a popup menu item!

; Inserts the time formatted according to the default locale in the popup
*Popup !DateTime

The DateTime displays the time and date in the systems default format. If you 
want to display the time in some other way this is fully configurable. 

; Time in the popup like "Time is: 21:36.07"
*Popup "Time is: %H:%M.%S" !DateTime

DATE
%A Weekday name (%a abbreviated)
%B Month name (%b abbreviated)
%c Date and time representation appropriate for locale
%d Day of month
%j Day of year
%m Month
%p Current locale�s A.M./P.M. indicator for 12-hour clock
%U Week of year, with Sunday as first day of week (00 � 53)
%w Weekday (0 � 6; Sunday is 0)
%W Week of year, with Monday as first day of week (00 � 53)
%x Date representation for current locale
%Y Year with century (%y without century)
%z, %Z Time-zone name or abbreviation; no characters if time zone is unknown

TIME
%H  Hour in 24-hour format
%I  Hour in 12-hour format
%M  Minute as decimal number
%S  Second as decimal number
%X  Time representation for current locale
%%@ Internet time

Try this if you like:

*Popup "DateTime" Folder
*Popup "Time:" !DateTime
*Popup "%X" !DateTime
*Popup "Date:" !DateTime
*Popup "%x" !DateTime
*Popup ~Folder

PopupDateTimeAlign
==================
You can control the alignment of the text in the !DateTime with the 
PopupDateTimeAlign variable.

; To left align it
PopupDateTimeAlign 0

; Center it
PopupDateTimeAlign 1

; Right
PopupDateTimeAlign 2

; Vertical center
PopupDateTimeAlign 4


!Separator
==========
Inserts a menu separator in the popup. A menu separator is a horizontal bevel
that is used to make the popup look more organized.

; inserts a separtator
*Popup !Separator

PopupAutoSeparator
==================
If defined then a separator is automagically inserted between the folders and
the files in your folders.

!PopupTasks
===========
A simple taskmanager in the popup. The taskmanager displays your current high
level windows in a folder.
Define PopupTasksWindowCaption if you want the PopupTasks to draw real window captions.

; Default !PopupTasks
*Popup !PopupTasks

; A !PopupTasks with "Workspace" in the caption
*Popup "Workspace" !PopupTasks


!PopupRun
=========
Like the run dialog in explorer. lets you enter a command
and execute it. Litestep bang commands may be executed as
well.

*Popup !PopupRun
*Popup "Exec:" !PopupRun

Use TAB or F2 for auto completion and arrow up/down for history.

===============================================================================
EXAMPLE OF POPUP SETTINGS FROM A STEP.RC
===============================================================================

; fonts/layout
PopupFontHeight 10
PopupTextOffset 4

; submenu overlap
PopupOverlapX 5
PopupOverlapY -15

; popup width configuration
PopupAdaptiveWidth
MinPopupWidth 100
MaxPopupWidth 300

; no bevel on each item
NoPopupBevel

; popup color definitions
PopupBevelLightColor EEEEEE
PopupGradientTitle 666666
PopupTitleBgColor 000000
PopupTitleColor FFFFFF
PopupEntryBgColor B1A1A1
PopupSelEntryColor FFFFFF
PopupTitleBgColor 123456

; misc.
NoPopupTransparent
PopupBlt 0
HotListName "|>Re5ource<|"
PopupTasksWindowCaption

*Popup !DateTime
*Popup "Programs" !PopupFolder:"C:\WINNT\Profiles\jre.000\Start Menu\Programs"
*Popup "All users" !PopupFolder:"C:\WINNT\Profiles\All Users\Start Menu\Programs"
*Popup !Separator
*Popup "Display Properties" control.exe desk.cpl
*Popup "My Computer" explorer /root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}
*Popup "Network Neighborhood" explorer /root,,::{208D2C60-3AEA-1069-A2D7-08002B30309D}
*Popup "Control Panel" explorer /root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\::{21EC2020-3AEA-1069-A2DD-08002B30309D}
	*Popup "Shutdown" Folder
	*Popup "Recycle" !Recycle
	*Popup "Logoff" !Logoff
	*Popup "Shutdown Menu" !Shutdown
		*Popup "WinAMP" Folder
		*Popup !RemoteAmp amp_background.bmp
		*Popup ~Folder
	*Popup ~Folder
	*Popup "DateTime" Folder
	*Popup "Time:" !DateTime
	*Popup "%X" !DateTime
	*Popup "Date:" !DateTime
	*Popup "%x" !DateTime
	*Popup ~Folder
*Popup !Separator
*Popup "Run" !Run
*Popup !PopupImage f:\lsb24\images\popupImage.bmp
*Popup "Execute:" !PopupRun
*Popup "Workspace" !PopupTasks
