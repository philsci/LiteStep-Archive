/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __VWM2_H
#define __VWM2_H

#include "..\lsapi\common.h"
#include "..\lsapi\lswinbase.h"

#include <vector>
#include <map>
#include <string>

#define MAX_LINE_LENGTH 4096

typedef struct wRECT
{
	RECT win;
	RECT vwm;
} wRECT;

using namespace std;

typedef vector<string> stringVector;
typedef map<int, string> deskMap;

typedef stringVector DeskNameT;

typedef vector<HWND> windowVector;
typedef map<HWND, wRECT> wRECTMap;

void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

class VWM : public Window
{
private:

	BOOL inWharf;
	HWND deskTop;
	HWND liteStep;

	BOOL visible;
	BOOL onTop;
	BOOL movable;

	BOOL gatherOnRecycle;

	BOOL switchOnFocus;

	BOOL focusCenter;

	int  autoHideDistance;
	int  snapDistance;
	int  autoSwitchDistance;
	int  autoSwitchDelay;

	//windows dragging
	HWND hSelectedWnd;
	POINT diffPt;

	int  initialDesk;
	int  desksX;
	int  desksY;
	int  desks;
	int  currentDesk;
	int  currentDeskX;
	int  currentDeskY;

	deskMap onSwitch;
	deskMap wallPapers;
	DeskNameT deskNames;

	int  iconSize;
	int  titlebarsMod;
	float modToVWMX;
	float modToVWMY;
	COLORREF clrWin;
	COLORREF clrBack;
	COLORREF clrSel;
	COLORREF clrFore;
	COLORREF clrBorder;

	HBITMAP hbmBack;
	HBITMAP hbmSel;
	HBITMAP hbmWin;
	HBITMAP hbmTitle;

	// memory dc for painting issues
	HDC hdcMem;
	HBITMAP hbmMem;
	HBITMAP hbmMemOld;
	HDC hdcMemBuffer;

	// these will prolly change into something else
	int  mouseLeft;
	int  mouseRight;
	int  mouseMiddle;

	// position
	int  vwmX;
	int  vwmY;
	int  vwmWidth;
	int  vwmHeight;

	// screen size
	int  screenWidth;
	int  screenHeight;

	windowVector winList;
	wRECTMap rectMap;

	// some collections
	stringVector stickyWindows;


public:
	static BOOL CALLBACK enumWindowsProc(HWND hwnd, LPARAM lParam);
	void switchDesk(LPCTSTR deskName);
	VWM(HWND parentWnd, int& code);
	~VWM();

	// bang handlers
	void gather();
	void switchDesk(int newDesk);
	void switchDeskUp();
	void switchDeskDown();
	void switchDeskLeft();
	void switchDeskRight();
	void toggle();
	void show();
	void hide();
	void open(int nDesk, _TCHAR *cmd);
	void open(LPTSTR deskName, _TCHAR *cmd);

	void reset();
	void moveApp(_TCHAR *args);

	void winListInit();
	void winListAdd(HWND hWndList);
	void winListDel(HWND hWndList);
	void winListChnZ(HWND hWndList, HWND hWndInsertAfter);
	void winListChnP(HWND hWndList, int x, int y, int cx, int cy);
	windowVector::iterator VWM::winListFind(HWND hWndList);

private:

	void getVWMRect(RECT srcrc, LPRECT lpdstrc);
	void getWNDRect(RECT srcrc, LPRECT lpdstrc);

	void paintBackground();
	void paintWindowList();

	void setWallpaper(void);
	void onSwitchExec(void);
	void getShifts(int newDesk, int *cx, int *cy);
	void fromVWMPoint(LPPOINT lppt);

	BOOL isDesiredWindow(HWND window);

	// get the desk number from x & y
	int getDeskId(int x, int y);
	int getDeskFromWnd(HWND window);
	
	//return the desktop number by the name assigned or -1 if 
	//it's not found
	int findDeskByName(LPCTSTR deskName);


	// set vars, that inflict on other vars....
	void setCurrentDesk(int id);
	void setScreenSize(int cx, int cy);

	virtual void windowProc(Message& message);
	void onCreate(Message& message);
	void onDestroy(Message& message);
	void onDisplayChange(Message& message);
	void onEndSession(Message& message);
	void onGetRevId(Message& message);
	void onKeyMessage(Message& message);
	void onMouseButtonDown(Message& message);
	void onMouseButtonUp(Message& message);
	void onMouseMove(Message& message);
	void onPaint(Message& message);
	void onSysCommand(Message& message);
	void onWindowActivated(Message& message);
	void onTimer(Message& message);
	void onDropFiles(Message& message);
	void onVWMPosChanging(Message& message);
	void onBringToFront(Message& message);
	void onSwitchToN(Message& message);
	void onListDesktops(Message& message);
	void onGetDesktopOf(Message& message);
};

void bangGather(HWND sender, LPCTSTR args);
void bangUp(HWND sender, LPCTSTR args);
void bangDown(HWND sender, LPCTSTR args);
void bangLeft(HWND sender, LPCTSTR args);
void bangRight(HWND sender, LPCTSTR args);
void bangDesk(HWND sender, LPCTSTR args);
void bangToggle(HWND sender, LPCTSTR args);
void bangShow(HWND sender, LPCTSTR args);
void bangHide(HWND sender, LPCTSTR args);
void bangOpen(HWND sender, LPCTSTR args);
void bangReset(HWND sender, LPCTSTR args);
void bangMoveApp(HWND sender, LPCTSTR args);

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCTSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
	__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, void *wharfData);
	__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);
}

#endif
