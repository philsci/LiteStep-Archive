/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "RunItem.h"
#include "PopupMenu.h"
#include "Painter.h"

#include <shlwapi.h>

#define ID_EDITCHILD 3578
 
WNDPROC pEditWndProc;
LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam);
BOOL RunItem::m_bRememberLast = FALSE;

RunItem::RunItem(char* pszTitle) : CommandItem(NULL,NULL,pszTitle)
{
	m_hEdit=NULL;
	// initialize the history to zero.
	ZeroMemory(m_ppszHistory, MAX_POPRUN_HISTORY*MAX_POPRUN_STRING);
}

RunItem::~RunItem()
{
	if(IsWindow(m_hEdit)) DestroyWindow(m_hEdit);
	m_hEdit = NULL;
}

void RunItem::Attached(PopupMenu* pMenu)
{
	CommandItem::Attached(pMenu);
	
	HWND hParent = pMenu->GetWindow();
	// Create an edit box
	m_hEdit = CreateWindow("EDIT", NULL, WS_CHILD | ES_LEFT | ES_AUTOHSCROLL, 
							0,0,0,0, hParent, (HMENU) ID_EDITCHILD, 
							(HINSTANCE) GetWindowLong(hParent, GWL_HINSTANCE), 
							NULL);
	
	DragAcceptFiles(m_hEdit, TRUE);

	// subclass, to enable us to receive the IDOK that are rightfullt ours
	pEditWndProc = (WNDPROC)GetWindowLong(m_hEdit, GWL_WNDPROC); 
    SetWindowLong(m_hEdit, GWL_WNDPROC, (LONG)EditSubclass); 

	SendMessage(m_hEdit, WM_SETFONT,(WPARAM)m_pBackground->GetFont(),MAKELPARAM(FALSE, 0));
	
	// Loads the history from the registry
	InitializeHistory();
}

void RunItem::InitializeHistory()
{
	// for reading the run mru
	HKEY hKey;
	char pszValueData[MAX_POPRUN_STRING];
	char pszMRUList[27];
	char* pszKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU";
	DWORD nType;
	DWORD nValueLength;
	BOOL bSuccess=TRUE;
	
	// Open the regisgry key
	if(bSuccess)
		bSuccess = RegOpenKey(HKEY_CURRENT_USER, pszKey, &hKey) == ERROR_SUCCESS;

	// open the list of mru entries
	nValueLength = sizeof(pszMRUList);
	if(bSuccess)
		bSuccess = RegQueryValueEx(hKey, "MRUList", NULL, &nType, (PBYTE)pszMRUList, &nValueLength) == ERROR_SUCCESS;

	if(bSuccess)
	{
		char pszName[2];

		m_nHistoryIndex = min(strlen(pszMRUList), MAX_POPRUN_HISTORY);
		ZeroMemory(pszName, sizeof(pszName));

		for(int i=0; i < m_nHistoryIndex; i++)
		{
			// read the mru list backwards
			pszName[0] = pszMRUList[m_nHistoryIndex-i];
			nValueLength = sizeof(pszValueData);
			bSuccess = RegQueryValueEx(hKey, pszName, NULL, &nType, (PBYTE)pszValueData, &nValueLength) == ERROR_SUCCESS;
			if(bSuccess)
			{
				strcpy(m_ppszHistory[i], (char*)pszValueData);

				// remove the trailing '\1'
				if(nValueLength > 2)
					m_ppszHistory[i][nValueLength-3] = '\0';
			}
		}
	}

	if(bSuccess)
		RegCloseKey(hKey);
}

void RunItem::SetPosition(int nLeft, int nTop)
{
	SIZE size;
	HDC hDC;

	CommandItem::SetPosition(nLeft, nTop);

	// Get the width of the title
	hDC = GetDC(GetWindow());
	GetTextExtentPoint32(hDC, GetTitle(), lstrlen(GetTitle()), &size);
	ReleaseDC(GetWindow(), hDC);

	SetWindowPos(m_hEdit, 0, size.cx+GetIndent(), m_nTop, GetWidth()-size.cx-5, GetHeight(), 0);
}

void RunItem::AddToHistory(char* pszCommand)
{
	if(m_nHistoryIndex == MAX_POPRUN_HISTORY)
	{
		for(int x = 1; x < MAX_POPRUN_HISTORY; x++)
			strcpy(m_ppszHistory[x-1], m_ppszHistory[x]);

		m_nHistoryIndex--;
	}
	strcpy(m_ppszHistory[m_nHistoryIndex++], pszCommand);
}

char* RunItem::PreviousHistory()
{
	m_nHistoryIndex--;
	m_nHistoryIndex = max(m_nHistoryIndex, 0);
	return m_ppszHistory[m_nHistoryIndex];
}

char* RunItem::NextHistory()
{
	char* pszText = "";

	// dont advance beond the end of the history buffer
	if(m_nHistoryIndex == MAX_POPRUN_HISTORY)
		pszText = "";
	else if(m_nHistoryIndex == (MAX_POPRUN_HISTORY-1))
		m_nHistoryIndex++;
	// dont advance into unintialized history
	else if(strlen(m_ppszHistory[m_nHistoryIndex]) == 0)
		pszText = "";
	else
	// advance history
		pszText = m_ppszHistory[++m_nHistoryIndex];

	return pszText;
}

LRESULT RunItem::Command(WPARAM wParam, LPARAM lParam)
{
	switch(wParam)
	{
	// EXECUTE
	case IDOK:
		{
			char pszCmd[MAX_PATH];
			char pszArg[MAX_PATH];
			GetWindowText(m_hEdit, pszCmd, sizeof(pszCmd));

			AddToHistory(pszCmd);

			// trim the string
			PathRemoveBlanks(pszCmd);

			// remember the agrument to the command
			strcpy(pszArg, PathGetArgs(pszCmd));

			PathRemoveArgs(pszCmd);
			PathUnquoteSpaces(pszCmd);
			
			m_pszCommand = pszCmd;
			m_pszArgument = pszArg;

			if(m_pszCommand != NULL && m_pszArgument != NULL)
				CommandItem::Invoke();
			
			m_pszCommand = NULL;
			m_pszArgument = NULL;
			
			Active(FALSE);

			if(!m_bRememberLast)
				SetWindowText(m_hEdit, "");
			break;
		}
	// HISTORY PREVIOUS
	case VK_UP:
		{
			char* pszText = PreviousHistory();
			SetWindowText(m_hEdit, pszText);
			CallWindowProc(pEditWndProc, m_hEdit, EM_SETSEL, 0, strlen(pszText));
			break;
		}
	// HISTORY NEXT
	case VK_DOWN:
		{
			char* pszText = NextHistory();			
			SetWindowText(m_hEdit, pszText);
			CallWindowProc(pEditWndProc, m_hEdit, EM_SETSEL, 0, strlen(pszText));
			break;
		}
	}

	return 1;
}

void RunItem::Invoke()
{
	SetFocus(m_hEdit);
	ShowWindow(m_hEdit, SW_SHOW);
	SetCapture(m_hEdit);
}

BOOL RunItem::Active(BOOL bActive)
{
	ShowWindow(m_hEdit, bActive ? SW_SHOW : SW_HIDE);
	if(IsActive() != bActive)
		ReleaseCapture();

	return CommandItem::Active(bActive);
}

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	static char pszPattern[MAX_PATH] = {'\0'};
	static HANDLE handle;
	static WIN32_FIND_DATA found;
	BOOL bContinue;

	if(uMsg == WM_KEYDOWN)
	{
		switch(wParam)
		{
		case VK_RETURN:
			PostMessage(GetParent(hwnd), WM_COMMAND, IDOK, NULL);
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_ESCAPE:
			ShowWindow(hwnd, SW_HIDE);
			SetFocus(GetParent(hwnd));
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_TAB:
		case VK_F2: 
			// Auto completion

			if(lstrlen(pszPattern) == 0)
			{
				GetWindowText(hwnd, pszPattern, sizeof(pszPattern));
				strcat(pszPattern, "*");
				handle = FindFirstFile(pszPattern, &found);
				bContinue = (handle != INVALID_HANDLE_VALUE);

				// ignore the . and .. directories
				while(bContinue && (lstrcmp(found.cFileName, ".") == 0 || (lstrcmp(found.cFileName, "..") == 0)))
					bContinue = FindNextFile(handle, &found);
			}
			else
			{
				bContinue = (FindNextFile(handle, &found) != 0);
			}

			// if the last search did find some file then update
			// the editbox
			if(bContinue)
			{
				char path_buffer[_MAX_PATH];
				char drive[_MAX_DRIVE];
				char dir[_MAX_DIR];

				_splitpath(pszPattern, drive, dir, NULL, NULL);
				_makepath(path_buffer, drive, dir, found.cFileName, NULL);
				SetWindowText(hwnd, path_buffer);

				// move the cursor to the end of the line
				CallWindowProc(pEditWndProc, hwnd, WM_KEYDOWN, VK_END, 0);
			}
			else
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		case VK_UP:
		case VK_DOWN:
			PostMessage(GetParent(hwnd), WM_COMMAND, wParam, NULL);
			break;
		default:
			if(lstrlen(pszPattern) > 0)
			{
				FindClose(handle);
				pszPattern[0] = '\0';
			}
			break;
		}
	}

	if(uMsg == WM_DROPFILES)
	{
		char szFileName[MAX_PATH];
		DragQueryFile((HDROP)wParam, 0, szFileName, sizeof(szFileName));
		SetWindowText(hwnd, szFileName);
		SetFocus(hwnd);
		DragFinish((HDROP)wParam);
	}

	return CallWindowProc(pEditWndProc, hwnd, uMsg, wParam, lParam);
}

