#include "safestr.h"


bool CharInStr(const char chr, const char* szString)
{
  if (!szString)
    return false;

  return strchr(szString, chr) != 0;

  /*for (const char* current = szString; *current; current++)
    if (chr == *current)
      return true;

  return false;*/
}

char* StrLCopy(char* szDest, const char* szSource, size_t dwMaxLen)
{
  size_t maxLen;

  if (!(szDest && szSource))
    return NULL;

  maxLen = StrLen(szSource) < dwMaxLen ? StrLen(szSource) : dwMaxLen;

  strncpy(szDest, szSource, maxLen);
  szDest[maxLen] = '\0';

  return szDest;
}

