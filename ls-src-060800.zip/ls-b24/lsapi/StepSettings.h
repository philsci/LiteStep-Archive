// StepSettings.h: interface for the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#if !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
#define AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <map>
#include <string>

using namespace std;

#define MAX_BANGCOMMAND            64
#define MAX_BANGARGS               256
#define MAX_RCCOMMAND              64
#define MAX_LINE_LENGTH            4096
#define MAX_PATH_LENGTH			   1024
#define MAX_LINE_LENGTH 4096
#define WHITESPACE " \t\n\r"

struct tThemePic
{
  char program[255];
  char bitmap[255];
};

typedef vector<string> StringVector;
typedef vector<tThemePic*> ThemePicVector;

typedef map< string, StringVector > CacheMap;
typedef map< string, CacheMap > CacheMapMap;

struct CacheState {
	string filename;
	bool line_iter_valid;
	bool command_iter_valid;
	bool config_iter_valid;
	StringVector::iterator line_iter;
	CacheMap::iterator command_iter;
	StringVector::iterator config_iter;
};

class StepSettings  
{
	BOOL ThemeInUse;
	string ThemeFile;
	string StepFile;

	CacheMap CommandBuffers;
	CacheMapMap ConfigBuffers;
	//ThemePicVector PicBuffer;

	typedef map<string, string> VarMap;
	VarMap stepVariables;

protected:
	FILE* Open(LPCTSTR szPath);
	BOOL Close (FILE *f);
	BOOL ReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength);
	BOOL ReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength);
	BOOL ReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength);
	char* CleanString(char* szString);
	char* StripComment(char* szString);
	LPCTSTR FindLine(LPCTSTR szKeyName);

public:
	BOOL GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets);
	void Clear();
	string GetThemeFile();
	string GetStepFile();
	void SetThemeFile(string theme_file);
	void SetStepFile(string step_file);
	StepSettings();
	virtual ~StepSettings();

	void VarExpansion(char *buffer, const char * value);
	string CacheRCFile(LPCTSTR szPath);
	int GetRCInt(LPCTSTR szKeyName, int nDefault);
	BOOL GetRCBool(LPCTSTR szKeyName, BOOL ifFound);
	BOOL GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen);
	COLORREF GetRCColor(LPCTSTR szKeyName, COLORREF colDef);
	BOOL GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault);
	bool AddVariable(LPCSTR name, LPCSTR value);
	bool GetVariable(LPCSTR name, string& value);
	int Tokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters, bool useBrackets = false);

	FILE* LCOpen(LPCTSTR szPath);
	BOOL LCClose (FILE *f);
	BOOL LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength);
	BOOL LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength);
	BOOL LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength);

  CacheMap &GetCommandBuffers();
  CacheMapMap &GetConfigBuffers();
};

#endif // !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
