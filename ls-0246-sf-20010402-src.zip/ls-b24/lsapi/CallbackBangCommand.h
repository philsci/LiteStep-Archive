/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma warning(disable: 4786)

#include "../core/ifcs.h"
#include <string>

using namespace std;

typedef void (*BANG)(HWND sender, LPCTSTR args);
typedef void (*BANGEX)(HWND sender, LPCTSTR args, LPCTSTR command);

class CallbackBangCommand : public IBangCommand  
{

public:
	CallbackBangCommand(BANG b);
	CallbackBangCommand(BANGEX b, wchar_t *command);
	virtual ~CallbackBangCommand();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
  ULONG STDMETHODCALLTYPE Release( void);
	
	///////////////////////////////////////////////////////////////////////////
	// From IBangCommand
    virtual void STDMETHODCALLTYPE Execute( 
        /* [in] */ OLE_HANDLE caller,
        /* [in] */ BSTR params);
private:
	bool ex;
	BANG bang;
	BANGEX bangex;
	wstring command;

	long refCount;
};
