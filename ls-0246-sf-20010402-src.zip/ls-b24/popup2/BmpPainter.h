/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#if !defined(AFX_BMPPAINTER_H__70DDBB45_76FE_11D2_B6A5_00C0DF466974__INCLUDED_)
#define AFX_BMPPAINTER_H__70DDBB45_76FE_11D2_B6A5_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Painter.h"

#define BMPPAINT_PLAIN    0
#define BMPPAINT_STRETCH  1
#define BMPPAINT_TILE     2


class MenuItem;

/**
Renders an bitmap on a MenuItem
*/
class BmpPainter : public Painter  
{
public:
	/**
	 Constructs an BmpPainter object.
	 @param hBmp the bitmap to be used when rendering the menuitem
	 @param bTransparent should hBmp be analyzed for transparency
	 */
	BmpPainter(HBITMAP hBmp, BOOL bTansparent);

	// Destroys the BmpPainter object
	virtual ~BmpPainter();

	/**
	Renders a bitmas on the MenuItem and the HDC
	@param pMenuItem pointer to the MenuItem object to be painted
	@param hDC handle to a DC to paint on
	*/
	void Paint(MenuItem* pMenuItem, HDC hDC);

	/**
	Returns the Region that this painter will cover on the menuitem
	@param hRgn handle to a regtion that receives this painters region
	@param pItem pointer to the menuitem that is going to be covered
	*/
	virtual void GetRegion(HRGN hRgn, MenuItem* pItem);

	/**
	Sets what type of blitting that shall be used
	@param nBlt the type of blt operation to be used 0/1/2
	*/
	static void SetBlt(int nBlt) {m_nBlt = nBlt;};

protected:
	HDC m_hPicture;
	BOOL m_bTransparent;
	HRGN m_hRegion;
	BITMAP m_Bmp;
	HBITMAP m_hBmpSaved;
	HBITMAP m_hBmp;
	static int m_nBlt;
};

#endif // !defined(AFX_BMPPAINTER_H__70DDBB45_76FE_11D2_B6A5_00C0DF466974__INCLUDED_)
