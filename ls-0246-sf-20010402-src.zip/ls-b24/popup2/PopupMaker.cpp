/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
12/19/00 - Bobby G. Vinyard (Message)
  - Added !PopupRecycleBin and !PopupRecentDocuments (this works correctly
    under W2K where as !DynamicFolder:$recent$ display everything
11/27/00 - Joachim Calvert (NeXTer)
  - Fixed the RevID so that the right version number is reported
11/15/00 - Kevin Schaffer (Maduin)
  - added PopupDefaultIcon, PopupIconSpacing, and PopupIconSize
  - added PopupTitleAlignment and PopupEntryAlignment
  - fixed a resource leak - MenuItem::~MenuItem() used DeleteObject to destroy an icon
11/12/00 - Bobby G. Vinyard (Message)
  - Removed 2000-10-18 additions to popup2 for right click open
  - Implemented right click context menus for the following items: !PopupFolder,
    !PopupDynamicFolder, !DynamicFolder, !PopupMyComputer, !PopupNetwork, !PopupControlPanel,
    !PopupPrinters (this code is by no means perfect, i.e. sub menus on the context menu
    do not function, i.e. the send to menu)
10/15/00 - Bobby G. Vinyard (Message)
  - Right clicking on a menu item that is a !PopupFolder or !PopupDynamicFolder, or one of
    of their subfolders. will cause the directory to be opened in a single pane explorer
    window
09/21/00 - Kevin Schaffer (Maduin)
  - Added .icon support
  - Added NoPopupTitleText
  - PopupBottomPix can now be a different height than PopupTitlePix
09/18/00 - Kevin Schaffer (Maduin)
  - Added support for some useful shell folders
    - !PopupMyComputer
	- !PopupNetwork
	- !PopupControlPanel
	- !PopupPrinters
08/31/00 - Joachim Calvert (NeXTer)
  - Altered the WM_POPUP message to pass both mouse coords in lParam
08/28/00 - Joachim Calvert (NeXTer)
  - Now handles scrolling of long menus, courtesy of Sylvain Rouquette (Syl)
  - New setting: PopupScrollSpeed <int>, default is 1
  - Errata: PopupTitleBold only works in conjunction with PopupFontFace, due
    to the method for retreiving the default font
08/27/00 - Joachim Calvert (NeXTer)
  - Should now handle gradients gracefully on newer builds, let me know if any
    problems occur
  - Added the settings PopupTitleBold <bool> and PopupEntryFontHeight <int>
  - Made !DynamicFolder menus display the caption of their parent
  - Fixed the vertical alignment of the text, should look better now
08/24/00 - Joachim Calvert (NeXTer)
  - Changed the min width default to 128px
08/17/00 - Joachim Calvert (NeXTer)
  - Hidden files and folders are no longer shown
  - Hides the extensions for .bat and .pif files
08/15/00 - Bobby G. Vinyard (Message)
  - Fixed a bug in !PopupDynamicFolder not showing
08/05/00 - Joachim Calvert (NeXTer)
  - Made the folder arrow static (doesn't resize)
  - Now takes the folder arrow into account when calculating the width of items
07/21/00 - Bobby G. Vinyard (Message)
  - Added !PopupDynamicFolder for compatiability with old Popup
  - Added folder merging capability to !DynamicFolder, !PopupDynamicFolder
    and !PopupFolder
****************************************************************************/
#include "stdafx.h"
#include "PopupMaker.h"
#include <winuser.h>
// menu items
#include "MenuItem.h"
#include "FolderItem.h"
#include "PopupMenu.h"
#include "SeparatorItem.h"
#include "CommandItem.h"
#include "TimeItem.h"
#include "RemoteAmpItem.h"
#include "HeaderItem.h"
#include "DirectoryFolder.h"
#include "RunItem.h"
#include "TaskFolder.h"
#include "TaskItem.h"
#include "DesktopMenu.h"
#include "TaskMenu.h"
#include "ShellFolder.h"
#include "Re5ources.h"

// Painters
#include "SolidPainter.h"
#include "BmpPainter.h"
#include "GradientPainter.h"

#include "../lsapi/lsapi.h"
#include "../lsapi/safestr.h"

#include <io.h>
#include <shlwapi.h>
#include <vector>
#include <algorithm>

extern vector<PopupMenu*> g_PopupMenues;

const _TCHAR rcsRevision[] = _TEXT("$Revision: 1.1.2.44 $"); // Our Version
const _TCHAR rcsId[] = _TEXT("$Id: PopupMaker.cpp,v 1.1.2.44 2001/03/09 19:25:59 maduin Exp $"); // The Full RCS ID.

PopupMaker::PopupMaker()
{
	m_pRoot = NULL;
	m_pSeparator = NULL;
	m_pBottom = NULL;
}

PopupMaker::~PopupMaker()
{
	// unregister LS messages
	if(m_pRoot)
	{
		int msgs[] = {
			LM_POPUP, LM_HIDEPOPUP, LM_GETREVID, 0
		};

		SendMessage(GetLitestepWnd(), LM_UNREGISTERMESSAGE, (WPARAM) m_pRoot->GetWindow(), (LPARAM) msgs);
	}

	DeleteObject(m_hDefaultFont);

	if(lstrlen(m_pszEntryFontFace) > 0)
		DeleteObject(m_hEntryFont);

	delete m_pTitle;
	delete m_pEntry;
	delete m_pSelEntry;
	delete m_pSeparator;
	delete m_pBottom;

	// delete all PopupMenu object, this is important not just only for
	// not leaking memory but (which is important since one recycles
	// litestep from time to time. litestep will crash upon recycle otherwise
	while(!g_PopupMenues.empty())
		delete g_PopupMenues[0];

	// delete the painters that we have allocated.
	for(int i=0; i<m_Painters.size(); i++)
		delete m_Painters[i];
}

void PopupMaker::Show(int index)
{
	m_RootMenus[index]->Show();
	SetFocus(m_RootMenus[index]->GetWindow());
}

void PopupMaker::Hide(int index)
{
	for(int i = 0; i < m_RootMenus.size(); i++)
	{
		m_RootMenus[i]->Hide(HIDE_PARENTS);
		m_RootMenus[i]->Hide(HIDE_CHILDREN);
	}
}

void PopupMaker::ShowDesktopMenu()
{
	m_pDesktopMenu->Show();
	SetFocus(m_pDesktopMenu->GetWindow());
}

void PopupMaker::ShowTaskMenu()
{
	m_pTaskMenu->Show();
	SetFocus(m_pTaskMenu->GetWindow());
}

void PopupMaker::Initialize(HWND hParentWnd, HINSTANCE dllInst, LPCTSTR szPath) 
{
	hInst = dllInst;

	// we are managing the _tsystem errors our seleves. this will prevent
	// the _tsystem to show a error message box if we would try to l
	UINT nErrorMode = SetErrorMode(1);

	m_bTransparent  = GetRCBool(_TEXT("NoPopupTransparent"), FALSE); // draw transparent by default

	m_bHeader = GetRCBool(_TEXT("NoPopupTitles"), FALSE);
	m_bHeaderText = GetRCBool(_TEXT("NoPopupTitleText"), FALSE);

	// Set the painters ...
    GetRCString(_TEXT("PopupTitlePix"), m_pszTitlePix, _TEXT(""), MAX_RC_STRING);
    GetRCString(_TEXT("PopupEntryPix"), m_pszEntryPix, _TEXT(""), MAX_RC_STRING);
    GetRCString(_TEXT("PopupSelEntryPix"), m_pszSelEntryPix, _TEXT(""), MAX_RC_STRING);
	GetRCString(_TEXT("PopupSeparatorPix"), m_pszSeparatorPix, _TEXT(""), MAX_RC_STRING);
	GetRCString(_TEXT("PopupBottomPix"), m_pszBottomPix, _TEXT(""), MAX_RC_STRING);

	// Base colors
	m_nTitleColor   = GetRCColor(_TEXT("PopupTitleBgColor"), GetSysColor(COLOR_ACTIVECAPTION));
	m_nInActiveTitleColor = GetRCColor(_TEXT("PopupInActiveTitleBgColor"), GetSysColor(COLOR_INACTIVECAPTION));
	m_nEntryColor   = GetRCColor(_TEXT("PopupEntryBgColor"), GetSysColor(COLOR_BTNFACE));
	m_nSelEntryColor= GetRCColor(_TEXT("PopupSelEntryBgColor"), GetSysColor(COLOR_HIGHLIGHT));

	// Gradient colors
	m_nGradientTitle = GetRCColor(_TEXT("PopupGradientTitle"), m_nTitleColor);
	m_bGradientTitle = m_nGradientTitle != m_nTitleColor;
	m_nGradientEntry = GetRCColor(_TEXT("PopupGradientEntry"), m_nEntryColor);
	m_bGradientEntry = m_nGradientEntry != m_nEntryColor;

	// Text colors
	m_nTitleTextColor   = GetRCColor(_TEXT("PopupTitleColor"), GetSysColor(COLOR_WINDOWTEXT));
    m_nEntryTextColor   = GetRCColor(_TEXT("PopupEntryColor"), GetSysColor(COLOR_MENUTEXT));
    m_nSelEntryTextColor= GetRCColor(_TEXT("PopupSelEntryColor"), GetSysColor(COLOR_HIGHLIGHTTEXT));

	// 3d decoration colors
	m_nBevelLightColor = GetRCColor(_TEXT("PopupBevelLightColor"), GetSysColor(COLOR_3DHILIGHT));
	m_nBevelDarkColor = GetRCColor(_TEXT("PopupBevelDarkColor"), GetSysColor(COLOR_3DSHADOW)); 

	m_pTitle = MakePainter(m_pszTitlePix, m_nTitleColor, m_nGradientTitle, m_bGradientTitle, FALSE);
	m_pEntry = MakePainter(m_pszEntryPix, m_nEntryColor, m_nGradientEntry, m_bGradientEntry, FALSE);
	m_pSelEntry = MakePainter(m_pszSelEntryPix, m_nSelEntryColor, m_nGradientEntry, m_bGradientEntry, TRUE);

	if(lstrlen(m_pszSeparatorPix) > 0)
	{
		BITMAP bm;
		HBITMAP hbmSeparator = LoadLSImage(m_pszSeparatorPix, NULL);
		GetObject(hbmSeparator, sizeof(BITMAP), &bm);
		m_pSeparator = new BmpPainter(hbmSeparator, m_bTransparent);
		m_nSeparatorHeight = bm.bmHeight;
	}

	if(lstrlen(m_pszBottomPix) > 0)
	{
		BITMAP bm;
		HBITMAP hbmBottom = LoadLSImage(m_pszBottomPix, NULL);
		GetObject(hbmBottom, sizeof(BITMAP), &bm);
		m_pBottom = new BmpPainter(hbmBottom, m_bTransparent);
		m_nBottomHeight = bm.bmHeight;
	}

	GetRCString(_TEXT("PopupDefaultIcon"), m_pszDefaultIcon, _TEXT(""), MAX_RC_STRING);
	m_bIcons = GetRCBool(_TEXT("PopupIcons"), TRUE);
	m_nIconSpacing = GetRCInt(_TEXT("PopupIconSpacing"), 2);
	m_nIconSize = GetRCInt(_TEXT("PopupIconSize"), 16);

	MenuItem::SetIconSpacing(m_nIconSpacing);
	MenuItem::SetIconSize(m_nIconSize);

	m_bAutoSeparator = GetRCBool(_TEXT("PopupAutoSeparator"), TRUE);
	m_bShowExtension = GetRCBool(_TEXT("PopupShowExtension"), TRUE);

	// runitem configuration
	RunItem::SetRememberLast(GetRCBool(_TEXT("PopupRunRememberLast"), TRUE));

	// Header item configuration
	m_bPinnedAlwaysOnTop = GetRCBool(_TEXT("PinnedPopupNotOnTop"), FALSE);
	HeaderItem::SetAlwaysOnTop(m_bPinnedAlwaysOnTop);
	HeaderItem::SetDrawCloseButton(GetRCBool(_TEXT("NoPopupCloseButton"), FALSE));

	// POPUP HEIGHTS
    m_nSubmenuHeight= GetRCInt(_TEXT("PopupSubmenuHeight"), 20);
	m_nTitleHeight = GetRCInt(_TEXT("PopupTitleHeight"), m_nSubmenuHeight);

	// folder item configuration
	int nOverlapX = GetRCInt(_TEXT("PopupOverlapX"), 5);
	int nOverlapY = GetRCInt(_TEXT("PopupOverlapY"), -m_nSubmenuHeight);
	FolderItem::SetOverlap(nOverlapX, nOverlapY);
	m_bFolderIcon = GetRCBool(_TEXT("NoPopupFolderIcon"), FALSE);
	FolderItem::SetDrawArrow(m_bFolderIcon);
	FolderItem::SetDelay(GetRCInt(_TEXT("PopupMenuDelay"), 100));

	// datetime configuration
	m_nDateTimeAlignment = 	GetRCInt(_TEXT("PopupDateTimeAlign"), DT_RIGHT);
    
	// POPUP WIDTHS
	int nMinWidth = GetRCInt(_TEXT("MinPopupWidth"), 128);
	PopupMenu::SetMinWidth(nMinWidth);

	if(!GetRCBool(_TEXT("PopupAdaptiveWidth"), TRUE))
		PopupMenu::SetMaxWidth(nMinWidth);
	else
		PopupMenu::SetMaxWidth(max(nMinWidth, GetRCInt(_TEXT("MaxPopupWidth"), 500)));

	
	BmpPainter::SetBlt(GetRCInt(_TEXT("PopupBlt"), BMPPAINT_PLAIN));
	TaskItem::SetWindowCaption(GetRCBool(_TEXT("PopupTasksWindowCaption"), TRUE));

	// Load the default font face
	int nFontHeight = GetRCInt(_TEXT("PopupFontHeight"), 16);
	int nEntryFontHeight = GetRCInt(_TEXT("PopupEntryFontHeight"), nFontHeight);

	GetRCString(_TEXT("PopupFontFace"), m_pszFontFace, _TEXT(""), MAX_RC_STRING);
	GetRCString(_TEXT("PopupEntryFontFace"), m_pszEntryFontFace, _TEXT(""), MAX_RC_STRING);

	BOOL bTitleBold = GetRCBoolDef(_TEXT("PopupTitleBold"), FALSE);

	if (bTitleBold && !StrLen(m_pszEntryFontFace) || nFontHeight != nEntryFontHeight)
		StrCopy(m_pszEntryFontFace, m_pszFontFace);

	if(lstrlen(m_pszFontFace) > 0)
	{
    m_hDefaultFont = CreateFont(nFontHeight, 0, 0, 0, (bTitleBold ? FW_BOLD : FW_NORMAL), FALSE, FALSE,
          FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
          DEFAULT_QUALITY, DEFAULT_PITCH, m_pszFontFace);
	}
	else
	{
		LOGFONT logFont;
		SystemParametersInfo(SPI_GETICONTITLELOGFONT, 0, &logFont, 0);
		m_hDefaultFont = CreateFontIndirect(&logFont);
	}

	if(lstrlen(m_pszEntryFontFace) > 0)
	{
	    m_hEntryFont = CreateFont(nEntryFontHeight, 0, 0, 0, FW_NORMAL, FALSE, FALSE,
    				FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
    				DEFAULT_QUALITY, DEFAULT_PITCH, m_pszEntryFontFace);
	}
	else
	{
		m_hEntryFont = m_hDefaultFont;
	}

	// Set the font
	m_pTitle->SetFont(m_hDefaultFont, m_nTitleTextColor);
	m_pEntry->SetFont(m_hEntryFont, m_nEntryTextColor);
	m_pSelEntry->SetFont(m_hEntryFont, m_nSelEntryTextColor);

	// shall bevels be drawn
	MenuItem::DrawBevel(!GetRCBool(_TEXT("NoPopupBevel"), TRUE));
	PopupMenu::DrawBevel(!GetRCBool(_TEXT("NoPopupMenuBevel"), TRUE));

	// setup colors to be used for 3d details
	MenuItem::SetLight(m_nBevelLightColor);
	MenuItem::SetDark(m_nBevelDarkColor);

	PopupMenu::SetLight(m_nBevelLightColor);
	PopupMenu::SetDark(m_nBevelDarkColor);

	MenuItem::SetIndent(GetRCInt(_TEXT("PopupTextOffset"), 5));
	MenuItem::SetRightIndent(GetRCInt(_TEXT("PopupRightIndent"), 5));

	_TCHAR szAlignment[32] = { 0 };
	GetRCString(_TEXT("PopupEntryAlignment"), szAlignment, _TEXT(""), 32);

	if(!lstrcmpi(szAlignment, _TEXT("center")))
		MenuItem::SetAlignment(DT_CENTER);
	else if(!lstrcmpi(szAlignment, _TEXT("right")))
		MenuItem::SetAlignment(DT_RIGHT);
	else
		MenuItem::SetAlignment(DT_LEFT);

	GetRCString(_TEXT("PopupTitleAlignment"), szAlignment, _TEXT(""), 32);

	if(!lstrcmpi(szAlignment, _TEXT("center")))
		MenuItem::SetTitleAlignment(DT_CENTER);
	else if(!lstrcmpi(szAlignment, _TEXT("right")))
		MenuItem::SetTitleAlignment(DT_RIGHT);
	else
		MenuItem::SetTitleAlignment(DT_LEFT);

	GetRCString(_TEXT("HotListName"), m_szHotListName, RESSTR(IDS_POPUP_HOTLISTNAME), MAX_RC_STRING);
	PopupMenu::SetScrollSpeed(GetRCInt(_TEXT("PopupScrollSpeed"), 1));

	// parse and process *Popup config lines in step.rc
	ParseStepRC();

	// assign a default root if none explicitly defined
	if(!m_pRoot)
	{
		if(!m_RootMenus.empty())
			m_pRoot = m_RootMenus[0];
	}

	// register for LS messages
	if(m_pRoot)
	{
		int msgs[] = {
			LM_POPUP, LM_HIDEPOPUP, LM_GETREVID, 0
		};

		SendMessage(hParentWnd, LM_REGISTERMESSAGE, (WPARAM) m_pRoot->GetWindow(), (LPARAM) msgs);
	}

	// create menus for desktops and tasks
	m_pDesktopMenu = new DesktopMenu(RESSTR(IDS_POPUP_DESKTOPS), this);
	m_pDesktopMenu->SetBangName(_TEXT("!PopupDesktops"));
	m_RootMenus.push_back(m_pDesktopMenu);

	m_pTaskMenu = new TaskMenu(RESSTR(IDS_POPUP_TASKS), this);
	m_pTaskMenu->SetBangName(_TEXT("!PopupTasks"));
	m_pTaskMenu->SetPinnedOnShow(GetRCBool(_TEXT("PopupTasksStartPinned"), TRUE) ? true : false);
	m_RootMenus.push_back(m_pTaskMenu);

	SetErrorMode(nErrorMode);
}

void PopupMaker::ParseStepRC()
{
	FILE *pStepRC = LCOpen(NULL);
	
	_TCHAR szLineBuffer[MAX_LINE_LENGTH];
	_TCHAR szFirst[MAX_PATH] = { 0 };
	_TCHAR szSecond[MAX_PATH] = { 0 };
	_TCHAR szThird[MAX_PATH] = { 0 };
	_TCHAR szFourth[MAX_PATH] = { 0 };

	_TCHAR *rgszTokens[] = {
		szFirst, szSecond, szThird, szFourth
	};

	if(!LCReadNextConfig(pStepRC, _TEXT("*Popup"), szLineBuffer, MAX_LINE_LENGTH))
		return;

	int nTokens = LCTokenize(szLineBuffer, rgszTokens, 4, NULL);

	if(nTokens >= 2 && (lstrcmpi(szSecond, _TEXT("!New")) == 0 || lstrcmpi(szThird, _TEXT("!New")) == 0))
	{
		// multiple popup mode
		do
		{
			_TCHAR *pszCaption;
			_TCHAR *pszBangCommand;

			if(nTokens <= 3)
			{
				pszCaption = m_szHotListName;
				pszBangCommand = szThird;
			}
			else
			{
				pszCaption = szSecond;
				pszBangCommand = szFourth;
			}

			PopupMenu *pNewPopup = new PopupMenu(hInst);

			if(pszBangCommand[0])
				pNewPopup->SetBangName(pszBangCommand);
			else
				m_pRoot = pNewPopup;

			AddHeaderItem(pNewPopup, pszCaption, TRUE);
			ParseFolder(pStepRC, pNewPopup);

			pNewPopup->Validate();
			m_RootMenus.push_back(pNewPopup);

			if(!LCReadNextConfig(pStepRC, _TEXT("*Popup"), szLineBuffer, MAX_LINE_LENGTH))
				break;

			szFirst[0] = 0;
			szSecond[0] = 0;
			szThird[0] = 0;
			szFourth[0] = 0;

			nTokens = LCTokenize(szLineBuffer, rgszTokens, 4, NULL);
		}
		while(nTokens >= 2 && (lstrcmpi(szSecond, _TEXT("!New")) == 0 || lstrcmpi(szThird, _TEXT("!New")) == 0));
	}
	else
	{
		// compatibility mode
		m_pRoot = new PopupMenu(hInst);

		AddHeaderItem(m_pRoot, m_szHotListName, TRUE);
		ParseLine(pStepRC, m_pRoot, szLineBuffer);
		ParseFolder(pStepRC, m_pRoot);
		AddBottomItem(m_pRoot);

		m_pRoot->Validate();
		m_RootMenus.push_back(m_pRoot);
	}

	LCClose(pStepRC);
}

void PopupMaker::ParseFolder(FILE *pStepRC, PopupMenu *pRoot)
{
	while(true)
	{
		_TCHAR szLineBuffer[MAX_LINE_LENGTH];

		if(!LCReadNextConfig(pStepRC, _TEXT("*Popup"), szLineBuffer, MAX_LINE_LENGTH)) {
			break;
		}

		if(!ParseLine(pStepRC, pRoot, szLineBuffer)) {
			break;
		}
	}
}

BOOL PopupMaker::ParseLine(FILE *pStepRC, PopupMenu *pRoot, _TCHAR *pszLine)
{
    _TCHAR  token1[4096], token2[4096], token3[4096], extra_text[4096];
    LPTSTR tokens[3];

    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;

	Painter* pPainter = m_pEntry;
	MenuItem* pMenuItem = NULL;
	_TCHAR *pszIcon = NULL;
	_TCHAR szExplicitIcon[MAX_PATH] = { 0 };
	int nHeight = m_nSubmenuHeight;
	int nTokens = 0;
	token1[0] = token2[0] = token3[0] = extra_text[0] = '\0';

	nTokens = LCTokenize (pszLine, tokens, 3, extra_text);

	if(!strnicmp(token2, _TEXT(".icon="), 6))
	{
		lstrcpy(szExplicitIcon, token2 + 6);
		
		_TCHAR *rgszTokens[1] = { token3 };
		_TCHAR szBuffer[4096];

		lstrcpy(token2, token3);
		lstrcpy(szBuffer, extra_text);
		LCTokenize(szBuffer, rgszTokens, 1, extra_text);

		if(!szBuffer[0])
			nTokens--;
	}

	if(nTokens == 3)
	{
		// ")*popup _TEXT("Start Menu") 17 default.bmp _TEXT("!PopupFolder:C:\WINDOWS\Start Menu")_TEXT("
		if(_ttoi(token3) > 0)
		{
			_TCHAR pszBmp[4096] = {'\0'};
			_TCHAR pszCmd[4096] = {'\0'};
			LPTSTR ppszExt[3];
			ppszExt[0] = pszBmp;
			ppszExt[1] = pszCmd;

			nHeight = _ttoi(token3);

    		LCTokenize(extra_text, ppszExt, 2, token1);
			pPainter = new BmpPainter(LoadLSImage(pszBmp, NULL),m_bTransparent);
			m_Painters.push_back(pPainter);
			lstrcpy(token3, pszCmd);				
		}

   		if (!lstrcmpi(token3, _TEXT("Folder")))
		{
			// Folder
			PopupMenu* pSub = new PopupMenu(hInst);

			AddHeaderItem(pSub, token2, FALSE);
			ParseFolder(pStepRC, pSub);
			pSub->Validate();

			pMenuItem = new FolderItem(pSub, token2);
		}
		else if(memicmp(token3, _TEXT("!PopupFolder:"), lstrlen(_TEXT("!PopupFolder:"))) == 0)
		{
			// PopupFolder
			_TCHAR pszFolder[_MAX_PATH];
			LPTSTR pszTemp = token3 + lstrlen(_TEXT("!PopupFolder:"));
			ExpandEnvironmentStrings(pszTemp, pszFolder, sizeof(pszFolder));

			PopupMenu* pSub = LoadFolder(token2, pszFolder, extra_text);
			pMenuItem = new FolderItem(pSub, token2);
			pszIcon = "";
		}
		else if(memicmp(token3, _TEXT("!DynamicFolder:"), lstrlen(_TEXT("!DynamicFolder:"))) == 0)
		{
			// PopupFolder
			_TCHAR pszFolder[_MAX_PATH];
			LPTSTR pszTemp = token3 + lstrlen(_TEXT("!DynamicFolder:"));
			ExpandEnvironmentStrings(pszTemp, pszFolder, sizeof(pszFolder));

			//PopupMenu* pSub = LoadFolder(pszFolder);
			pMenuItem = new DirectoryFolder(pszFolder, TRUE, this, token2, extra_text);
			pszIcon = "";
		}
		else if(memicmp(token3, _TEXT("!PopupDynamicFolder:"), lstrlen(_TEXT("!PopupDynamicFolder:"))) == 0)
		{
			// PopupFolder
			_TCHAR pszFolder[_MAX_PATH];
			LPTSTR pszTemp = token3 + lstrlen(_TEXT("!PopupDynamicFolder:"));
			ExpandEnvironmentStrings(pszTemp, pszFolder, sizeof(pszFolder));

			//PopupMenu* pSub = LoadFolder(pszFolder);
			pMenuItem = new DirectoryFolder(pszFolder, TRUE, this, token2, extra_text);
			pszIcon = "";
		}
		// if it is a special menu item that wants a bmp background
		else if(token2[0] == '!')
		{	
			pMenuItem = MakeBangItem(token2, NULL);

			// token2 == token3 then there is the thing with lscp bugs..
			if(pMenuItem != NULL && lstrcmpi(token2, token3) != 0)
			{
				pPainter = new BmpPainter(LoadLSImage(token3, NULL),m_bTransparent);
				m_Painters.push_back(pPainter);
			}
		}
		else
		{
			pMenuItem = MakeBangItem(token3, token2);
			if(pMenuItem == NULL)
			{
				pMenuItem = new CommandItem(token3, extra_text, token2);
				pszIcon = token3[0] == '!' ? NULL : token3;
			}
		}

		if(m_bIcons && pMenuItem)
		{
			HICON hIcon = NULL;

			if(szExplicitIcon[0])
			{
				hIcon = LoadLSIcon(szExplicitIcon, NULL);
			}
			else if(!pMenuItem->HasIcon())
			{
				if(pszIcon)
					hIcon = GetIconFromPath(pszIcon);
				else if(m_pszDefaultIcon[0])
					hIcon = LoadLSIcon(m_pszDefaultIcon, NULL);
			}

			if(hIcon) pMenuItem->SetIcon(hIcon);
		}

		if(pMenuItem != NULL)
		{
			pMenuItem->SetHeight(nHeight);
			pMenuItem->SetPainter(pPainter);
			pMenuItem->SetActivePainter(m_pSelEntry);
			pRoot->AddMenuItem(pMenuItem);
		}
	}
	// *popup !DateTime
	else if(nTokens == 2)
	{
		if(lstrcmpi(token2, _TEXT("~Folder")) == 0 || lstrcmpi(token2, _TEXT("~New")) == 0)
		{
			AddBottomItem(pRoot);
			return FALSE;
		}
		else
		{
			pMenuItem = MakeBangItem(token2, NULL);
		}		
			
		if(pMenuItem != NULL)
		{
			// hack to make the separator the separator size
			if(lstrcmpi(token2, _TEXT("!Separator")) == 0)
			{
				if(m_pSeparator)
				{
					pMenuItem->SetActivePainter(m_pSeparator);
					pMenuItem->SetPainter(m_pSeparator);
					pMenuItem->SetHeight(m_nSeparatorHeight);
				}
				else
				{
					pMenuItem->SetActivePainter(m_pSelEntry);
					pMenuItem->SetPainter(m_pEntry);
					pMenuItem->SetHeight(4);
				}
			}
			else
			{
				pMenuItem->SetActivePainter(m_pSelEntry);
				pMenuItem->SetPainter(m_pEntry);
				pMenuItem->SetHeight(m_nSubmenuHeight);
			}

			if(m_bIcons)
			{
				HICON hIcon = NULL;

				if(szExplicitIcon[0])
					hIcon = LoadLSIcon(szExplicitIcon, NULL);
				else if(m_pszDefaultIcon[0])
					hIcon = LoadLSIcon(m_pszDefaultIcon, NULL);

				if(hIcon) pMenuItem->SetIcon(hIcon);
			}

			pRoot->AddMenuItem(pMenuItem);
		}
	}

	return TRUE;
}

Painter* PopupMaker::MakePainter(LPTSTR pszImage, DWORD dwColor, DWORD dwGradColor, BOOL bGrad, BOOL bSwap)
{
	Painter* pNewPainter = NULL;
	DWORD dwLeft = dwColor;
	DWORD dwRight;

	if(lstrlen(pszImage) > 0)
	{
		pNewPainter = new BmpPainter(LoadLSImage(pszImage, NULL), m_bTransparent);
	}
	else if(dwGradColor != 0x00ff00ff)
	{
		dwRight = dwGradColor;
		if(bSwap) swap(dwLeft, dwRight);
		pNewPainter = new GradientPainter(dwLeft, dwRight);
	}
	else if(bGrad)
	{
		dwRight = 0;
		if(bSwap) swap(dwLeft, dwRight);
		pNewPainter = new GradientPainter(dwLeft, dwRight);
	}
	else
	{
		pNewPainter = new SolidPainter(dwColor);
	}

	return pNewPainter;
}

MenuItem* PopupMaker::MakeBangItem(LPTSTR pszItem, LPTSTR pszTitle)
{
	MenuItem* pMenuItem = NULL;
	if(lstrcmpi(pszItem, _TEXT("!RemoteAmp")) == 0)
		pMenuItem = new RemoteAmpItem();
	else if(lstrcmpi(pszItem, _TEXT("!DateTime")) == 0)
		pMenuItem = new TimeItem(m_nDateTimeAlignment, pszTitle == NULL ? ")%c_TEXT(" : pszTitle);
	else if(lstrcmpi(pszItem, _TEXT("!PopupImage")) == 0)
		pMenuItem = new SeparatorItem(FALSE);
	else if(lstrcmpi(pszItem, _TEXT("!PopupRun")) == 0)
		pMenuItem = new RunItem(pszTitle == NULL ? RESSTR(IDS_POPUP_RUN) : pszTitle);
	else if(lstrcmpi(pszItem, _TEXT("!PopupDesktops")) == 0)
		pMenuItem = new FolderItem(new DesktopMenu(pszTitle ? pszTitle : RESSTR(IDS_POPUP_DESKTOPS), this), pszTitle ? pszTitle : RESSTR(IDS_POPUP_DESKTOPS));
	else if(lstrcmpi(pszItem, _TEXT("!PopupTasks")) == 0)
		pMenuItem = new TaskFolder(this, pszTitle == NULL ? RESSTR(IDS_POPUP_TASKS) : pszTitle);
	else if(lstrcmpi(pszItem, _TEXT("!Separator")) == 0)
		pMenuItem = new SeparatorItem(m_pSeparator ? FALSE : TRUE);
	else if(lstrcmpi(pszItem, _TEXT("!PopupControlPanel")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_CONTROLS);
	else if(lstrcmpi(pszItem, _TEXT("!PopupMyComputer")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_DRIVES);
	else if(lstrcmpi(pszItem, _TEXT("!PopupNetwork")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_NETWORK);
	else if(lstrcmpi(pszItem, _TEXT("!PopupPrinters")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_PRINTERS);
	else if(lstrcmpi(pszItem, _TEXT("!PopupRecentDocuments")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_RECENT);
	else if(lstrcmpi(pszItem, _TEXT("!PopupRecycleBin")) == 0)
		pMenuItem = new ShellFolder(this, pszTitle, CSIDL_BITBUCKET);
	return pMenuItem;
}

void PopupMaker::AddHeaderItem(PopupMenu* pMenu, LPTSTR pszTitle, BOOL bVeto)
{
	if(m_bHeader || bVeto)
	{
		MenuItem* pHead = new HeaderItem(m_bHeaderText ? pszTitle: NULL);
		pHead->SetActivePainter(m_pTitle);
		pHead->SetPainter(m_pTitle);
		pHead->SetHeight(m_nTitleHeight);
		pMenu->AddMenuItem(pHead);
	}
}

void PopupMaker::AddBottomItem(PopupMenu* pMenu)
{
	if(m_pBottom)
	{
		MenuItem* pMenuItem = new SeparatorItem(FALSE);
		pMenuItem->SetPainter(m_pBottom);
		pMenuItem->SetHeight(m_nBottomHeight);
		pMenu->AddMenuItem(pMenuItem);
	}
}

PopupMenu* PopupMaker::LoadFolder(LPTSTR pszTitle, LPTSTR pszFolder, LPTSTR pszFilter)
{
  //For folder merging
  _TCHAR seps[]   = "|";
  _TCHAR *token;
  LPTSTR tempPath = new _TCHAR[_tcsclen(pszFolder)+1];
  _tcscpy(tempPath, pszFolder);
  
  _TCHAR pszPattern[_MAX_PATH];
  long handle;
  _finddata_t found;
  HICON hIcon = NULL;
  MenuItem* pItem = NULL;
  BOOL bFolders = FALSE;
  BOOL bFiles = FALSE;
  
  // create menu objects 
  PopupMenu* pMenu = new PopupMenu(hInst);
  
  AddHeaderItem(pMenu, pszTitle, FALSE);
  
  token = _tcstok(tempPath, seps );
  while (token != NULL) {
    
    // make file search pattern of foldername 
    //lstrcpy(pszPattern, pszFolder);
    lstrcpy(pszPattern, token);
    if(pszPattern[lstrlen(pszPattern)] != '\\')
      lstrcat(pszPattern, _TEXT("\\"));

    // Pattern matching
    if (!pszFilter)
      lstrcat(pszPattern, _TEXT("*"));
    else
    {
      if (_tcsclen(pszFilter) != 0)
        lstrcat(pszPattern, pszFilter);
      else
        lstrcat(pszPattern, _TEXT("*"));
    }
    
    // for all files in the folder, create a CommandItem
    // and add them to the current popupmenu
    handle = _tfindfirst(pszPattern, &found);
    
    if(handle != -1) 
    {
      do{
		if(lstrcmp(found.name, TEXT(".")) == 0 || lstrcmp(found.name, TEXT("..")) == 0 || (found.attrib & _A_HIDDEN))
			continue;
        // if(!(lstrcmp(found.name, _TEXT(".")) && lstrcmp(found.name, _TEXT(".."))) || (found.attrib & _A_HIDDEN))
        //  continue;
        if(found.attrib & _A_SUBDIR) 
        {	
			bFolders = TRUE;
			_TCHAR pszSubFolder[_MAX_PATH];
			lstrcpy(pszSubFolder,token);

			if(pszSubFolder[0] && pszSubFolder[lstrlen(pszSubFolder) - 1] != '\\')
				lstrcat(pszSubFolder, _TEXT("\\"));

			lstrcat(pszSubFolder,found.name);
			pItem = new DirectoryFolder(pszSubFolder, FALSE, this, found.name, pszFilter);

			if(m_bIcons)
				pItem->SetIcon(GetIconFromPath(_TEXT("")));
        }
        else
        {
			_TCHAR pszTitle[_MAX_PATH];
			_TCHAR pszCmd[_MAX_PATH];

			bFiles = TRUE;
			// Assemble command 
			lstrcpy(pszCmd, token);

			if(pszCmd[0] && pszCmd[lstrlen(pszCmd) - 1] != '\\')
				lstrcat(pszCmd, _TEXT("\\"));

			lstrcat(pszCmd, found.name);

			// Fix title (_tremove the extension like .lnk)
			lstrcpy(pszTitle, found.name);
			int nStrLen = lstrlen(pszTitle);
			if(nStrLen > 4 && m_bShowExtension)
			{
				// if we are not to show the extention, just _tremove
				// .lnk or .exe
				LPTSTR pszExt = pszTitle + nStrLen - 4;
				if(lstrcmpi(pszExt, _TEXT(".lnk"))==0 || 
						lstrcmpi(pszExt, _TEXT(".pif"))==0 || 
						lstrcmpi(pszExt, _TEXT(".bat"))==0 || 
						lstrcmpi(pszExt, _TEXT(".exe"))==0 || 
						lstrcmpi(pszExt, _TEXT(".com"))==0)
					pszTitle[nStrLen-4]='\0';
			}
			else
			{
				PathRemoveExtension(pszTitle);
			}

			pItem = new CommandItem(pszCmd, NULL,pszTitle);

			if(m_bIcons)
				pItem->SetIcon(GetIconFromPath(pszCmd));
        }
        
        pItem->SetHeight(m_nSubmenuHeight);
        pItem->SetPainter(m_pEntry);
        pItem->SetActivePainter(m_pSelEntry);
        
        pMenu->AddMenuItem(pItem);
        
      }while(_tfindnext(handle, &found) == 0);
    }
    _findclose(handle);
    token = _tcstok(NULL, seps);
  }
  AddBottomItem(pMenu);
  
  if(m_bAutoSeparator && bFolders && bFiles)
  {
	MenuItem *pMenuItem = new SeparatorItem();
	pMenuItem->SetSortPriority(5);

	if(m_pSeparator)
	{
		pMenuItem->SetActivePainter(m_pSeparator);
		pMenuItem->SetPainter(m_pSeparator);
		pMenuItem->SetHeight(m_nSeparatorHeight);
	}
	else
	{
		pMenuItem->SetActivePainter(m_pSelEntry);
		pMenuItem->SetPainter(m_pEntry);
		pMenuItem->SetHeight(4);
	}

	pMenu->AddMenuItem(pMenuItem);
  }
  
  pMenu->Sort();
  pMenu->Validate();
  
  delete [] tempPath;
  
  return pMenu;
}
