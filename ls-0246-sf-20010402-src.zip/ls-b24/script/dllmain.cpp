/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <tchar.h>
#include "ScriptHost.h"
#include "../lsapi/lsapi.h"

HINSTANCE myInstance;

ScriptHost *globalScriptHost;

void bangScript(HWND, const char*);

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH) {
		myInstance = hInstance;
        DisableThreadLibraryCalls(hInstance);
    } else if (dwReason == DLL_PROCESS_DETACH) {
        myInstance = NULL;
	}

    return TRUE;    // ok
}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
	OleInitialize(NULL);
	globalScriptHost = new ScriptHost();

	AddBangCommand("!Script", bangScript);

	return 0;
}

int quitModule(HINSTANCE dllInst)
{
	OleUninitialize();

	return 1;
}

void bangScript( HWND sender, const char *args )
{
	// executes the script nugget contained in args
	TCHAR *myStr = new TCHAR[_tcsclen(args) + 1];
	_tcscpy(myStr, args);

	globalScriptHost->RunScriptlet(myStr);
}
