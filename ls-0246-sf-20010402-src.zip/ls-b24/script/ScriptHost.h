/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// ScriptHost.h: interface for the ScriptHost class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCRIPTHOST_H__5ECF7C9B_E685_4DB1_917E_BDDBCE4D14F5__INCLUDED_)
#define AFX_SCRIPTHOST_H__5ECF7C9B_E685_4DB1_917E_BDDBCE4D14F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <activscp.h>
#include "../core/ifcs.h"

class ScriptHost : public IActiveScriptSite  
{
private:
	ITypeInfo* dbangmanInfo;
	IActiveScript* activeScript;
	IActiveScriptParse* scriptParse;
	DBangManager* dbangman;
	ILitestep* litestep;
	long refCount;

public:
	void RunScriptlet(LPSTR script);
	ScriptHost();
	virtual ~ScriptHost();

	// From IUnknown
    virtual HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
    
    virtual ULONG STDMETHODCALLTYPE AddRef( void);
    
    virtual ULONG STDMETHODCALLTYPE Release( void);

	// From IActiveScriptSite
    virtual HRESULT STDMETHODCALLTYPE GetLCID( 
        /* [out] */ LCID __RPC_FAR *plcid);
    
    virtual HRESULT STDMETHODCALLTYPE GetItemInfo( 
        /* [in] */ LPCOLESTR pstrName,
        /* [in] */ DWORD dwReturnMask,
        /* [out] */ IUnknown __RPC_FAR *__RPC_FAR *ppiunkItem,
        /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppti);
    
    virtual HRESULT STDMETHODCALLTYPE GetDocVersionString( 
        /* [out] */ BSTR __RPC_FAR *pbstrVersion);
    
    virtual HRESULT STDMETHODCALLTYPE OnScriptTerminate( 
        /* [in] */ const VARIANT __RPC_FAR *pvarResult,
        /* [in] */ const EXCEPINFO __RPC_FAR *pexcepinfo);
    
    virtual HRESULT STDMETHODCALLTYPE OnStateChange( 
        /* [in] */ SCRIPTSTATE ssScriptState);
    
    virtual HRESULT STDMETHODCALLTYPE OnScriptError( 
        /* [in] */ IActiveScriptError __RPC_FAR *pscripterror);
    
    virtual HRESULT STDMETHODCALLTYPE OnEnterScript( void);
    
    virtual HRESULT STDMETHODCALLTYPE OnLeaveScript( void);
};

#endif // !defined(AFX_SCRIPTHOST_H__5ECF7C9B_E685_4DB1_917E_BDDBCE4D14F5__INCLUDED_)
