// StandardLogDispatch.cpp: implementation of the StandardLogDispatch class.
//
//////////////////////////////////////////////////////////////////////

#include <time.h>

#include "StandardLogDispatch.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StandardLogDispatch::StandardLogDispatch()
{
	logHandlers[1];
	logHandlers[2];
	logHandlers[3];
	logHandlers[4];
	logHandlers[5];

	refCount = 0;
}

StandardLogDispatch::~StandardLogDispatch()
{
	for (int i = 1; i <= 5; i++) {
		LogHandlerList::iterator iter = logHandlers[i].begin();

		while (iter != logHandlers[i].end()) {
			(*iter)->Release();
			iter++;
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StandardLogDispatch::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_ILogDispatch) {
		*ppv = static_cast<ILogDispatch*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StandardLogDispatch::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StandardLogDispatch::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

// From ILogDispatch
HRESULT STDMETHODCALLTYPE StandardLogDispatch::Log(int logLevel, BSTR message) {
	
	ILogHandler *logHandler = NULL;

	if (logLevel > 5 || logLevel < 1) {
		return E_FAIL;
	}

	LogHandlerList::iterator iter = logHandlers[logLevel].begin();

	while (iter != logHandlers[logLevel].end()) {
		if (FAILED((*iter)->QueryInterface(IID_ILogHandler, (void**)&logHandler))) {
			iter++;
			continue;
		} else {
			logHandler->Log(message, time(NULL));
			logHandler->Release();
			iter++;
		}
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardLogDispatch::RegisterLogHandler(int logLevel, ILogHandler __RPC_FAR *handler) {

	IUnknown *unknown = NULL;

	if (!handler) {
		return E_FAIL;
	}

	if (FAILED(handler->QueryInterface(IID_IUnknown, (void**)&unknown))) {
		return E_FAIL;
	}

	if (logLevel > 5 || logLevel < 1) {
		return E_FAIL;
	}

	logHandlers[logLevel].push_back(handler);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardLogDispatch::UnregisterLogHandler(int logLevel, ILogHandler __RPC_FAR *handler) {

	IUnknown *unknown = NULL;
	LogHandlerList::iterator iter = logHandlers[logLevel].begin();

	if (!handler) {
		return E_FAIL;
	}

	if (FAILED(handler->QueryInterface(IID_IUnknown, (void**)&unknown))) {
		return E_FAIL;
	}

	if (logLevel > 5 || logLevel < 1) {
		return E_FAIL;
	}

	while (iter != logHandlers[logLevel].end()) {
		if (*iter == unknown) {
			(*iter)->Release();
			logHandlers[logLevel].erase(iter);
			break;
		} else {
			iter++;
		}
	}

	unknown->Release();

	return S_OK;
}