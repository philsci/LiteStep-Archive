/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <stdio.h>
#include <malloc.h>
#include <tchar.h>

#include "command.h"
const char szAppName[] = "Command"; // Our window class, etc
const char rcsRevision[] = "$Revision: 1.1.2.4 $"; // Our Version
const char rcsId[] = "$Id: command.cpp,v 1.1.2.4 2000/10/27 17:33:49 message Exp $"; // The Full RCS ID.
Command *command; // The module

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam);
WNDPROC pEditWndProc;

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  
  Window::init(dllInst);
  
  command = new Command(ParentWnd, code);
  return code;
}

void quitModule(HINSTANCE dllInst)
{
  delete command;
}


//=========================================================
// Bang commands
//=========================================================
void BangCommandMoveFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  command->BangCommandMove(caller, args);
}


void BangCommandToggleFunction(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
  command->BangCommandToggle(caller, args);
}



/*
TODO:
  Add Code for Bang Commands (i.e. void Bang(HWND caller, LPCSTR args)

*/

//=========================================================
// Module code
//=========================================================
/*
TODO:
  Add Code internal to the Class

*/

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Command::Command(HWND parentWnd, int& code):
Window(szAppName)
{

  int msgs[] = {LM_GETREVID, 0};
  char configLine[MAX_LINE_LENGTH];

	width = GetRCInt("CommandWidth",160);
  height = GetRCInt("CommandHeight",20);
	xpos = GetRCInt("CommandX",0);
	ypos = GetRCInt("CommandY",0);
  borderSize = GetRCInt("CommandBorderSize", -1);
  if (borderSize == -1)
  {
    borderSizeBottom = GetRCInt("CommandBottomBorderSize",2);
    borderSizeTop = GetRCInt("CommandTopBorderSize",2);
    borderSizeLeft = GetRCInt("CommandLeftBorderSize",2);
    borderSizeRight = GetRCInt("CommandRightBorderSize",2);   
  }
  else
  {
    borderSizeBottom = borderSize;
    borderSizeTop = borderSize;
    borderSizeLeft = borderSize;
    borderSizeRight = borderSize;
  }

	GetRCString("CommandTextFontFace", configLine,"Arial",256);
  szFontFace = new char[StrLen(configLine) +1];
  StrCopy(szFontFace, configLine);
	colorBG = GetRCColor("CommandBGColor",RGB(255,255,255));
  colorBorder = GetRCColor("CommandBorderColor",RGB(255,255,255));
	colorText = GetRCColor("CommandTextColor",RGB(0,0,0));
	textSize = GetRCInt("CommandTextSize",14);

  hBorderBrush = CreateSolidBrush(colorBorder);

  if (!createWindow(WS_EX_TOPMOST|WS_EX_TOOLWINDOW, szAppName, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
                    xpos, ypos, width, height, parentWnd))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	hFont = CreateFont(textSize,0,0,0,0,0,0,0,0,0,0,0,0,szFontFace);

	hEdit = CreateWindowEx(0L, "EDIT", "", WS_CHILD | ES_LEFT | ES_AUTOHSCROLL, 
							borderSizeLeft, borderSizeTop,
              width - (borderSizeRight + borderSizeLeft),
              height - (borderSizeBottom + borderSizeTop), 
              hWnd, 0, hInstance, 0);

	DragAcceptFiles(hEdit, TRUE);
  hBrush = CreateSolidBrush(colorBG);

	pEditWndProc = (WNDPROC)SetWindowLong(hEdit, GWL_WNDPROC, (long)EditSubclass);

  SendMessage(hEdit, WM_SETFONT,(WPARAM)hFont, MAKELPARAM(FALSE, 0));

  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  AddBangCommand("!CommandMove",BangCommandMoveFunction);
  AddBangCommand("!CommandToggle",BangCommandToggleFunction);

  /*
  TODO:
    Add AddBangCommand() statements

  TODO:
    Add Any other initialization code

  */

  ShowWindow(hWnd,SW_SHOWNORMAL);
   ShowWindow(hEdit, SW_SHOWNORMAL);
   UpdateWindow(hWnd);

  code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
Command::~Command()
{

	mruList.Save();

  int msgs[] = {LM_GETREVID, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  RemoveBangCommand("!CommandMove");
  RemoveBangCommand("!CommandToggle");

  delete[] szFontFace;
  DeleteObject(hFont);
  DeleteObject(hBrush);
  DeleteObject(hBorderBrush);

  destroyWindow();
}


//=========================================================
// Registered messages
//=========================================================

void Command::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,     WM_ENDSESSION)
    MESSAGE(onEndSession,     WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,       LM_GETREVID)
    MESSAGE(onSysCommand,     WM_SYSCOMMAND)
    MESSAGE(onCreate,         WM_CREATE)
    MESSAGE(onCtlColorEdit,   WM_CTLCOLOREDIT)
    MESSAGE(onDropFiles,      WM_DROPFILES)
    MESSAGE(onNCHitTest,      WM_NCHITTEST)
    MESSAGE(onPaint,          WM_PAINT)
    MESSAGE(onEraseBkgnd,     WM_ERASEBKGND)
    MESSAGE(onCommand,        WM_COMMAND)
    /*
    TODO:
      Add Additional Message handlers here

    */
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void Command::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void Command::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "command.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void Command::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Command::onCreate(Message& message) {



}


void Command::onCtlColorEdit(Message& message) {
  SetBkColor((HDC)message.wParam, colorBG);
  SetTextColor((HDC)message.wParam, colorText);
  message.lResult = (long)hBrush;
}


void Command::onDropFiles(Message& message) {
  /*
  TODO:
    Add Message Handling Code

  */
}


void Command::onNCHitTest(Message& message) {
  /*
  TODO:
    Add Message Handling Code

  */
}


void Command::onPaint(Message& message) {
  /*
  TODO:
    Add Message Handling Code

  */
}


void Command::onEraseBkgnd(Message &message) {
  HDC hDC;
  RECT rc;

  hDC = (HDC) message.wParam; 
  GetClientRect(hWnd, &rc);
  FillRect(hDC, &rc, hBorderBrush); 

}


void Command::onCommand(Message &message) {
	switch(message.wParam)
	{
	case IDOK:
		{
			char pszCmd[MAX_PATH];

			GetWindowText(hEdit, pszCmd, sizeof(pszCmd));

			// trim the string
			PathRemoveBlanks(pszCmd);

			mruList.Add(pszCmd);

			LSExecute(hWnd, pszCmd, SW_SHOWNORMAL);

			//if(!bRememberLast)
			//	SetWindowText(hEdit, "");
			break;
		}
	// HISTORY PREVIOUS
	case VK_UP:
		{
			LPCSTR pszText = mruList.Previous();
			SetWindowText(hEdit, pszText);
      _LSDEBUG1(pszText)
			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(pszText));
			break;
		}
	// HISTORY NEXT
	case VK_DOWN:
		{
			LPCSTR pszText = mruList.Next();			
			SetWindowText(hEdit, pszText);
      _LSDEBUG1(pszText)
			CallWindowProc(pEditWndProc, hEdit, EM_SETSEL, 0, strlen(pszText));
			break;
		}
	}
}


//=========================================================
// Bang command handling
//=========================================================
void Command::BangCommandMove(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
}


void Command::BangCommandToggle(HWND caller, LPCSTR args) {
  /*
  TODO:
    Add Bang Code Here
  */
}

/*
void Command::AddToHistory(char* pszCommand)
{
  char szKey[] = "abcdefghijklmnopqrstuvwxyz";
  vecMRUList::iterator it;
  int iKeyIndex;
  int iMRUCount;

  mruList.insert(mruList.begin(), pszCommand);

  iKeyIndex = 0;

  iMRUCount = mruList.size();
  if (iMRUCount < 26)
    iMRUCount = 26;

  for (int i = 0; i < iMRUCount; i++)
  {

  }
}*/

LRESULT CALLBACK EditSubclass(HWND hwnd, UINT uMsg,WPARAM wParam,LPARAM lParam)
{
  static char pszPattern[MAX_PATH] = {'\0'};
  static HANDLE handle;
  static WIN32_FIND_DATA found;
  BOOL bContinue;
  
  switch(uMsg)
  {
  case WM_KEYDOWN:
    {
      switch(wParam)
      {
      case VK_RETURN:
        PostMessage(GetParent(hwnd), WM_COMMAND, IDOK, NULL);
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      case VK_ESCAPE:
        ShowWindow(hwnd, SW_HIDE);
        SetFocus(GetParent(hwnd));
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      case VK_TAB:
      case VK_F2: 
        // Auto completion
        
        if(lstrlen(pszPattern) == 0)
        {
          GetWindowText(hwnd, pszPattern, sizeof(pszPattern));
          strcat(pszPattern, "*");
          handle = FindFirstFile(pszPattern, &found);
          bContinue = (handle != INVALID_HANDLE_VALUE);
          
          // ignore the . and .. directories
          while(bContinue && (lstrcmp(found.cFileName, ".") == 0 || (lstrcmp(found.cFileName, "..") == 0)))
            bContinue = FindNextFile(handle, &found);
        }
        else
        {
          bContinue = (FindNextFile(handle, &found) != 0);
        }
        
        // if the last search did find some file then update
        // the editbox
        if(bContinue)
        {
          char path_buffer[_MAX_PATH];
          char drive[_MAX_DRIVE];
          char dir[_MAX_DIR];
          
          _splitpath(pszPattern, drive, dir, NULL, NULL);
          _makepath(path_buffer, drive, dir, found.cFileName, NULL);
          SetWindowText(hwnd, path_buffer);
          
          // move the cursor to the end of the line
          CallWindowProc(pEditWndProc, hwnd, WM_KEYDOWN, VK_END, 0);
        }
        else
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      case VK_UP:
      case VK_DOWN:
        PostMessage(GetParent(hwnd), WM_COMMAND, wParam, NULL);
        break;
      default:
        if(lstrlen(pszPattern) > 0)
        {
          FindClose(handle);
          pszPattern[0] = '\0';
        }
        break;
      }
    }
    break;
  case WM_DROPFILES:
    {
      char szFileName[MAX_PATH];
      DragQueryFile((HDROP)wParam, 0, szFileName, sizeof(szFileName));
      SetWindowText(hwnd, szFileName);
      SetFocus(hwnd);
      DragFinish((HDROP)wParam);
    }
    break;
  }
  return CallWindowProc(pEditWndProc, hwnd, uMsg, wParam, lParam);
}
