/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __command_H
#define __command_H

#ifdef _DEBUG
#define _LSDEBUG
#endif

#include <windows.h>
#include <Shlwapi.h>

#pragma	warning(disable: 4786) // STL naming warnings
#include <vector>
#include <string>

#include "..\lsapi\lsapi.h"
#include "..\lsapi\safestr.h"
#include "..\lsapi\lswinbase.h"
#include "..\lsapi\lsdebug.h"
#include "..\lsapi\mru.h"

using namespace std;

typedef vector<string> vecMRUList;

#define ID_EDITCHILD 3578
#define MAX_POPRUN_HISTORY 5
#define MAX_POPRUN_STRING 1024

class Command : public Window
{
public:
  int height;
  int width;
  int xpos;
  int ypos;
  int borderSize;
  int borderSizeTop;
  int borderSizeLeft;
  int borderSizeBottom;
  int borderSizeRight;


  HFONT hFont;
  HBRUSH hBrush;
  HBRUSH hBorderBrush;

  LPSTR szFontFace;
  int textSize;
  COLORREF colorText;
  COLORREF colorBG;
  COLORREF colorBorder;

  HWND hEdit;

	static BOOL bRememberLast;

  MRUList mruList;

  char* pszCommand;
	char* pszArgument;
public:
  Command(HWND parentWnd, int& code);
  ~Command();

  void BangCommandMove(HWND, LPCSTR);
  void BangCommandToggle(HWND, LPCSTR);

private:

  virtual void windowProc(Message& message);
  void onEndSession(Message& message);
  void onGetRevId(Message& message);
  void onSysCommand(Message& message);
  void onCreate(Message& message);
  void onCtlColorEdit(Message& message);
  void onDropFiles(Message& message);
  void onNCHitTest(Message& message);
  void onPaint(Message& message);
  void onEraseBkgnd(Message &message);
  void onCommand(Message &message);
  /*
  TODO:
    Add any Message Handlers

  */

};

void BangCommandMoveFunction(HWND, LPCSTR);
void BangCommandToggleFunction(HWND, LPCSTR);

/*
TODO:
  Add any Bang Command Declarations

*/

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
