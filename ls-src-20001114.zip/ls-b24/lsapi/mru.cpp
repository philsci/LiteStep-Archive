/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "mru.h"

#define MRUKEY "Software\\LiteStep\\RunMRU"


MRUList::MRUList(LPCSTR pszKey)
{
	m_pszKey = new char[sizeof(pszKey)+1];
	strcpy(m_pszKey, pszKey);
	m_nIndex = 0;
  m_fSync = rand();
	Load();
}

MRUList::MRUList()
{
	m_pszKey = new char[sizeof(MRUKEY)+1];
	strcpy(m_pszKey, MRUKEY);
	m_nIndex = 0;

	Load();
}

MRUList::~MRUList()
{
	delete[] m_pszKey;
}

LPCSTR MRUList::First()
{
	return m_mruList[m_nIndex = 0].c_str();
}

LPCSTR MRUList::Next()
{
	if (m_nIndex == (MAX_ITEMS - 1))
		return m_mruList[m_nIndex = 0].c_str();

	return m_mruList[++m_nIndex].c_str();
}

LPCSTR MRUList::Previous()
{
	if (m_nIndex == 0)
		return m_mruList[m_nIndex = (MAX_ITEMS - 1)].c_str();

	return m_mruList[--m_nIndex].c_str();
}

LPCSTR MRUList::Current()
{
	return m_mruList[m_nIndex].c_str();
}

void MRUList::Add(LPCSTR pszItem)
{
	mapMRUList::iterator it;
	if ((it = find(m_mruList.begin(), m_mruList.end(), pszItem)) != m_mruList.end())
	{
		m_mruList.erase(it);
	}
	m_mruList.insert(m_mruList.begin(), pszItem);
	if (m_mruList.size() > 26)
	{
		m_mruList.pop_back();
	}
}

void MRUList::Save()
{

}

void MRUList::Clear()
{

}

void MRUList::Load()
{
  // for reading the run mru
  HKEY hKey;
  char szMRUListOrder[ MAX_PATH ];
  DWORD cbMRUListOrderSize = sizeof(szMRUListOrder);
  DWORD type;

	 //Open the regisgry key
  if (RegOpenKeyEx((HKEY)HKEY_CURRENT_USER, m_pszKey, 0,
    KEY_ALL_ACCESS, &hKey) == ERROR_SUCCESS)
  {
    //Get the mrulist order
    if (RegQueryValueEx(hKey, "MRUList", NULL, &type, (LPBYTE)szMRUListOrder, &cbMRUListOrderSize) == ERROR_SUCCESS)
    {
			strncpy(m_szOrder, szMRUListOrder, 26);
      //Read the MRU entries in proper order
      m_nCount = strlen(szMRUListOrder);
      for (int i = 0; i < m_nCount; i++)
      {
        char sztemp[2];
        TCHAR szValue[MAX_PATH];
        DWORD cbValueSize = sizeof(szValue);
        ZeroMemory(sztemp, sizeof(sztemp));
        strncpy(sztemp, &szMRUListOrder[i], 1);

        if (RegQueryValueEx(hKey,(LPCSTR)sztemp, NULL, &type, (LPBYTE)szValue, &cbValueSize) == ERROR_SUCCESS)
        {
          m_mruList.push_back(szValue);
          _LSDEBUG1(szValue)
        }
      }
    }
  }
  RegCloseKey(hKey);
 }
