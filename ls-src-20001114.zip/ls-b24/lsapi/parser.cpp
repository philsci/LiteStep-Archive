// Litestep
// Copyright (C) 2000, The Litestep Development Team
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <stdlib.h>
#include <string>
#include "lsapi.h"
#include "StepSettings.h"
#include "Parser.h"



using namespace std;

// global settings object
extern StepSettings *g_settings;

Parser::Parser()
{
	inputPosition = 0;
	currentChar = 0;
	lookaheadChar = 0;

	currentToken = TT_NONE;
};

// evaluate an expression and pass back the result
bool Parser::evaluate( const char *expr, int *result )
{
	input = expr;
	inputPosition = 0;

	nextChar();
	nextToken();

	int value;
	
	if( !expression( value ) )
		return false;

	if( result )
		*result = value;

	return true;
}

// basic-expression:
//		identifier
//		integer
//		( expression )

bool Parser::basicExpression( int &result )
{
	if( currentToken == TT_ID )
	{
		if( !g_settings->RCLineExists( stringValue.c_str() ) )
		{
			// if the command is nonexistant, it's false
			result = 0;
		}
		else
		{
			char buffer[32];

			// otherwise it's either an integer or boolean
			g_settings->GetRCString( stringValue.c_str(), buffer, "", 32 );
			
			if( isDigit( buffer[0] ) )
				result = g_settings->GetRCInt( stringValue.c_str(), 0 );
			else
				result = g_settings->GetRCBoolDef( stringValue.c_str(), FALSE );
		}

		nextToken();
		return true;
	}
	else if( currentToken == TT_INTEGER )
	{
		result = intValue;

		nextToken();
		return true;
	}
	else if( matchToken( TT_LP ) )
	{
		if( !expression( result ) )
			return false;

		return matchToken( TT_RP );
	}

	return false;
}

// unary-expression
//		"not" unary-expression
//		- unary-expression
//		basic-expression

bool Parser::unaryExpression( int &result )
{
	if( matchToken( TT_NOT ) )
	{
		if( !unaryExpression( result ) )
			return false;

		result = !result;
		return true;
	}
	else if( matchToken( TT_MINUS ) )
	{
		if( !unaryExpression( result ) )
			return false;

		result = -result;
		return true;
	}

	return basicExpression( result );
}

// relational-expression:
//		unary-expression relational-operator unary-expression
//		unary-expression

bool Parser::relationalExpression( int &result )
{
	int subresult;
	int token;

	if( !unaryExpression( result ) )
		return false;

	if( !isRelationalOperator( currentToken ) )
		return true;

	token = currentToken;
	nextToken();

	if( !unaryExpression( subresult ) )
		return false;

	switch( token )
	{
		case TT_EQ: result = (result == subresult); break;
		case TT_NE: result = (result != subresult); break;
		case TT_GT: result = (result >  subresult); break;
		case TT_GE: result = (result >= subresult); break;
		case TT_LT: result = (result <  subresult); break;
		case TT_LE: result = (result <= subresult); break;
	}

	return true;
}

// and-expression
//		and-expression "and" relational-expression
//		relational-expression

bool Parser::andExpression( int &result )
{
	if( !relationalExpression( result ) )
		return false;

	while( true )
	{
		if( matchToken( TT_AND ) )
		{
			int subresult;

			if( !relationalExpression( subresult ) )
				return false;

			result = result && subresult;
			continue;
		}

		break;
	}

	return true;
}

// or-expression:
//		or-expression "or" and-expression
//		and-expression

bool Parser::orExpression( int &result )
{
	if( !andExpression( result ) )
		return false;

	while( true )
	{
		if( matchToken( TT_OR ) )
		{
			int subresult;

			if( !andExpression( subresult ) )
				return false;

			result = result || subresult;
			continue;
		}

		break;
	}

	return true;
}

// expression:
//		or-expression

bool Parser::expression( int &result )
{
	return orExpression( result );
}

// if current token is of type tokenType, consume it
bool Parser::matchToken( int tokenType )
{
	if( currentToken == tokenType )
	{
		nextToken();
		return true;
	}

	return false;
}

// scan next token
bool Parser::nextToken()
{
	// skip whitespace
	while( isWhiteSpace( currentChar ) )
		nextChar();

	// are we at the end of the input?
	if( currentChar == 0 )
		return currentToken = TT_END, true;

	// predict token type based on first char
	if( isLetter( currentChar ) )
	{
		// it's an identifier or keyword
		stringValue.assign( 1, (char) currentChar );
		nextChar();

		while( isLetter( currentChar ) || isDigit( currentChar ) )
		{
			stringValue.append( 1, (char) currentChar );
			nextChar();
		}

		currentToken = TT_ID;

		// is it a keyword?
		if( !stricmp( stringValue.c_str(), "and" ) )
			currentToken = TT_AND, true;
		else if( !stricmp( stringValue.c_str(), "or" ) )
			currentToken = TT_OR, true;
		else if( !stricmp( stringValue.c_str(), "not" ) )
			currentToken = TT_NOT, true;

		return currentToken;
	}
	else if( isDigit( currentChar ) )
	{
		// it's a numeric literal
		stringValue.assign( 1, (char) currentChar );
		nextChar();

		while( isDigit( currentChar ) )
		{
			stringValue.append( 1, (char) currentChar );
			nextChar();
		}

		intValue = atoi( stringValue.c_str() );
		return currentToken = TT_INTEGER, true;
	}
	else
	{
		// assume it's a symbol
		if( matchChar('=') )
			return currentToken = TT_EQ, true;
		else if( matchChars('<', '>') )
			return currentToken = TT_NE, true;
		else if( matchChars('<', '=') )
			return currentToken = TT_LE, true;
		else if( matchChar('<') )
			return currentToken = TT_LT, true;
		else if( matchChars('>', '=') )
			return currentToken = TT_GE, true;
		else if( matchChar('>') )
			return currentToken = TT_GT, true;
		else if( matchChar('+') )
			return currentToken = TT_PLUS, true;
		else if( matchChar('-') )
			return currentToken = TT_MINUS, true;
		else if( matchChar('*') )
			return currentToken = TT_STAR, true;
		else if( matchChar('/') )
			return currentToken = TT_SLASH, true;
		else if( matchChar('(') )
			return currentToken = TT_LP, true;
		else if( matchChar(')') )
			return currentToken = TT_RP, true;
	}
	
	// if we got this far, it's an error
	return currentToken = TT_ERROR, false;
}

// if the next char is ch, consume it
bool Parser::matchChar( int ch )
{
	if( currentChar == ch )
	{
		nextChar();
		return true;
	}

	return false;
}

// if the next two chars are ch1 and ch2, consume both
bool Parser::matchChars( int ch1, int ch2 )
{
	if( currentChar == ch1 && lookaheadChar == ch2 )
	{
		nextChar(); nextChar();
		return true;
	}

	return false;
}

// advance to next input char
bool Parser::nextChar()
{
	// first time?
	if( inputPosition == 0 )
		lookaheadChar = input[inputPosition++];

	// read in char
	currentChar = lookaheadChar;

	if( lookaheadChar != 0 )
		lookaheadChar = input[inputPosition++];

	return true;
}

BOOL Evaluate( const char *expr, int *result )
{
	Parser parser;
	return parser.evaluate( expr, result );
}
