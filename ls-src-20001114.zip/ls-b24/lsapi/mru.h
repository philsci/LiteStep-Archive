/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef __MRU_H
#define __MRU_H

#ifdef _DEBUG
#define _LSDEBUG
#endif

#include <windows.h>
#include "lsapi.h"
#include "lsdebug.h"

#define MAX_ITEMS 26

#pragma	warning(disable: 4786) // STL naming warnings
#include <algorithm>
#include <vector>
#include <string>

using namespace std;

typedef vector<string> mapMRUList;

class MRUList
{
private:
  int m_nSize;
  mapMRUList m_mruList;
	char* m_pszKey;
	int m_nIndex;
  int m_nCount;
  char m_szOrder[27];
	float m_fSync;

public:
  MRUList(LPCSTR pszKey);
	MRUList();
  ~MRUList();

  LPCSTR First();
  LPCSTR Next();
  LPCSTR Previous();
  LPCSTR Current();

  void Add(LPCSTR pszItem);

  void Save();
  void Clear();

private:
	void Load();
};

#endif