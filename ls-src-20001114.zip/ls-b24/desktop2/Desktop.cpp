/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
11/08/00 - Joachim Calvert (NeXTer)
  - Oups... Setting the parent to the desktop made it show up in the task
    list. Back to the drawing board
11/07/00 - Joachim Calvert (NeXTer)
  - Changed the parent window to the desktop and removed the clipping.
    This should (theoretically) make it easier to adapt LS to a multi-monitor
    setup
11/01/00 - Joachim Calvert (NeXTer)
  - Added !DesktopSetArea left top right bottom, the rules are the same as
    for the normal settings
05/21/00 - Joachim Calvert (NeXTer)
  - Removed some superflous code, and fixed some other minor issues.
04/20/00 - Joachim Calvert (NeXTer)
  - Some minor fixes
04/19/00 - Joachim Calvert (NeXTer)
  - Now uses Window (in lswinbase) as base class, should simplify the process
    of writing C++ based modules somewhat
04/17/00 - Joachim Calvert (NeXTer)
  Made the code more or less completely streamlined. The size has suffered
    slightly, but the readability is much improved.
04/16/00 - Bobby G. Vinyard (Message)
  Changed the desktop clicks to use LSExecute instead of ParseBangCommand
    This results in desktop2 not needing to parse the string before calling
    LSExecute, removed some unneeded variables and functions
    Can now do something like DesktopLeftClick cmd.exe to cause the left click
    to open a command window in WinNT
04/14/00 - Bobby G. Vinyard (Message)
  Made right click default to !popup
04/14/00 - Joachim Calvert (NeXTer)
  The desktop area is now dynamically set on resolution changes.
04/13/00 - Bobby G. Vinyard (Message)
  Reimplemented desktop clicks to use a function for setting their variables
    (Thanks MrJukes and Dem0sh for your help)
  Added three new bang commands:
    !SetDesktopLeftClick
    !SetDesktopRightClick
    !SetDesktopMiddleClick
    These allow you to change what the mouse clicks do on the fly
    e.g. !SetDesktopLeftClick !popup x=0 y=0
04/10/00 Bobby G. Vinyard (Message)
  Remove autorun functionality (was our understanding that this was flakey
    and that a 3rd party module is available that better provides this
    functionality, may be reimplemented in the future, but I see no reason
    for it to be a desktop function)
  Did some more house cleaning (i.e. removed unused variables, added proper
    headers, proper format)
04/06/00 Bobby G. Vinyard (Message) & noodge
  Went ahead and added a basic implementation of DesktopLeftClick <command>,
  DesktopMiddleClick <command>, DesktopRightClick <command> (Might look into
    streamling the functions soon when I finish streamling desktop2)
04/01/00 Bobby G. Vinyard (Message)
  Removed some unused variable (ok, well really just commented them out until
    this build is throughly tested)
  Did some more work on setting the desktop area, hopefully this is fixed now
****************************************************************************/

#include "Desktop.h"

const char szAppName[] = "DesktopBackgroundClass"; // Our window class, etc

const char rcsRevision[] = "$Revision: 1.24.2.10 $"; // Our Version
const char rcsId[] = "$Id: Desktop.cpp,v 1.24.2.10 2000/11/08 00:11:12 NeXTer Exp $"; // The Full RCS ID.

Desktop *desktop; // The module


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;

  Window::init(dllInst);

  desktop = new Desktop(ParentWnd, code);

  return code;
}


void quitModule(HINSTANCE dllInst)
{
  delete desktop;
}


//=========================================================
// Bang commands
//=========================================================

void BangSetMiddleClick(HWND caller, LPCSTR args)
{
  desktop->bangSetMiddleClick(args);
}


void BangSetRightClick(HWND caller, LPCSTR args)
{
  desktop->bangSetRightClick(args);
}


void BangSetLeftClick(HWND caller, LPCSTR args)
{
  desktop->bangSetLeftClick(args);
}


void BangSetDesktopArea(HWND caller, LPCSTR args)
{
  desktop->bangSetArea(args);
}


//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Desktop::Desktop(HWND parentWnd, int& code):
Window(szAppName)
{
  screenWidth = GetSystemMetrics(SM_CXSCREEN);
  screenHeight = GetSystemMetrics(SM_CYSCREEN);

  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP,
                    0, 0, screenWidth, screenHeight, parentWnd))
  {
    
    char szText[MAX_LINE_LENGTH+1];

    GetResStr(hInstance, IDS_DESKTOP2_ERROR1, szText, MAX_LINE_LENGTH, "Unable to create window.");
    MessageBox(NULL, szText, szAppName, MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);

    code = 1;
    return;
  }

  SetWindowPos(hWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_NOSENDCHANGING);

  code = 0;
}


Desktop::~Desktop()
{
  destroyWindow();
}


// --------------------------------------------------------
// Sets maximized windows size
// --------------------------------------------------------
void Desktop::setMinMax(void)
{
  RECT r = {0, 0, screenWidth, screenHeight};

  if (setDesktopArea)
  {
    r.left = sdaLeft;
    r.top = sdaTop;
    r.right = sdaRight <= 0 ? screenWidth + sdaRight : sdaRight;
    r.bottom = sdaBottom <= 0 ? screenHeight + sdaBottom : sdaBottom;
  }
  SetDesktopArea(r.left, r.top, r.right, r.bottom);
}


//---------------------------------------------------------
// Reset to old maximized windows size
//---------------------------------------------------------
void Desktop::resetMinMax(void)
{
  RECT r = {0, 0, screenHeight, screenWidth};

  if (!setDesktopArea)
    return;
  SetDesktopArea(r.left, r.top, r.right, r.bottom);
}


//=========================================================
// Registered messages
//=========================================================

void Desktop::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate,            WM_CREATE)
    MESSAGE(onDestroy,           WM_DESTROY)
    MESSAGE(onActivate,          WM_ACTIVATE)
    MESSAGE(onDisplayChange,     WM_DISPLAYCHANGE)
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onEraseBkgnd,        WM_ERASEBKGND)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onKeyMessage,        WM_KEYDOWN)
    MESSAGE(onKeyMessage,        WM_KEYUP)
    MESSAGE(onKeyMessage,        WM_HOTKEY)
    MESSAGE(onMouseActivate,     WM_MOUSEACTIVATE)
    MESSAGE(onMouseButtonDown,   WM_LBUTTONDOWN)
    MESSAGE(onMouseButtonDown,   WM_MBUTTONDOWN)
    MESSAGE(onMouseButtonDown,   WM_RBUTTONDOWN)
    MESSAGE(onMouseButtonUp,     WM_LBUTTONUP)
    MESSAGE(onMouseButtonUp,     WM_MBUTTONUP)
    MESSAGE(onMouseButtonUp,     WM_RBUTTONUP)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
    MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void Desktop::onCreate(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  setDesktopArea = GetRCBool("SetDesktopArea", TRUE);
  sdaLeft = GetRCInt("SDALeft", 0);
  sdaRight = GetRCInt("SDARight", 0);
  sdaTop = GetRCInt("SDATop", 0);
  sdaBottom = GetRCInt("SDABottom", 0);

  GetRCString("DesktopLeftClick", bangLeftClick, "!None", sizeof(bangLeftClick));
  GetRCString("DesktopRightClick", bangRightClick, "!Popup", sizeof(bangRightClick));
  GetRCString("DesktopMiddleClick", bangMiddleClick, "!None", sizeof(bangMiddleClick));

  AddBangCommand("!DesktopSetLeftClick", BangSetLeftClick);
  AddBangCommand("!DesktopSetRightClick", BangSetRightClick);
  AddBangCommand("!DesktopSetMiddleClick", BangSetMiddleClick);
  AddBangCommand("!SetDesktopArea", BangSetMiddleClick);

  setMinMax();
}


void Desktop::onDestroy(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_REPAINT, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  resetMinMax();

  RemoveBangCommand("!DesktopSetLeftClick");
  RemoveBangCommand("!DesktopSetRightClick");
  RemoveBangCommand("!DesktopSetMiddleClick");
  RemoveBangCommand("!DesktopSetArea");
}


void Desktop::onActivate(Message& message)
{
  // Tells litestep it has been selected
  SendMessage(hParent, LM_LSSELECT, 0, 0);
  if (message.wParamLo)
    SetActiveWindow(hParent);
}


void Desktop::onDisplayChange(Message& message)
{
  screenWidth = message.lParamLo;
  screenHeight = message.lParamHi;
  SetWindowPos(hWnd, HWND_BOTTOM, 0, 0, screenWidth, screenHeight, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
  setMinMax();
}


void Desktop::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onEraseBkgnd(Message& message)
{
  PaintDesktop((HDC)(message.wParam));
  message.lResult = TRUE;
}


void Desktop::onGetRevId(Message& message)
{
  LPSTR buf = (LPSTR)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "desktop.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


void Desktop::onKeyMessage(Message& message)
{
  // Forward these messages
  PostMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onMouseActivate(Message& message)
{
  // Tells litestep it has been selected
  PostMessage(hParent, LM_LSSELECT, 0, 0);
  // Close any popup open
  SendMessage(hParent, LM_HIDEPOPUP, (int)(message.lParamHi), (int)(message.lParamLo));
  message.lResult = MA_ACTIVATE;
}


void Desktop::onMouseButtonDown(Message& message)
{
  SendMessage(hParent, LM_HIDEPOPUP, (int)(message.lParamHi), (int)(message.lParamLo));
}


void Desktop::onMouseButtonUp(Message& message)
{
  char* click;

  switch (message.uMsg)
  {
    case WM_LBUTTONUP:
      click = bangLeftClick;
      break;
    case WM_RBUTTONUP:
      click = bangRightClick;
      break;
    case WM_MBUTTONUP:
      click = bangMiddleClick;
      break;
    default:
      return;
  }
  LSExecute(hWnd, click, 0);
}


void Desktop::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onWindowPosChanging(Message& message)
{
  WINDOWPOS *c = (WINDOWPOS*)(message.lParam);

  c->hwndInsertAfter = HWND_BOTTOM;
  c->flags |= SWP_NOMOVE | SWP_NOSIZE;
}


//=========================================================
// Bang command handling
//=========================================================

void Desktop::bangSetLeftClick(LPCSTR args)
{
  if (args)
    strcpy(bangLeftClick,args);
}


void Desktop::bangSetRightClick(LPCSTR args)
{
  if (args)
    strcpy(bangRightClick, args);
}


void Desktop::bangSetMiddleClick(LPCSTR args)
{
  if (args)
    strcpy(bangMiddleClick, args);
}


void Desktop::bangSetArea(LPCSTR args)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR nextToken = args;

  if (GetToken(nextToken, token, &nextToken, FALSE))
    sdaLeft = atoi(token);
  if (GetToken(nextToken, token, &nextToken, FALSE))
    sdaTop = atoi(token);
  if (GetToken(nextToken, token, &nextToken, FALSE))
    sdaRight = atoi(token);
  if (GetToken(nextToken, token, &nextToken, FALSE))
    sdaBottom = atoi(token);
  setMinMax();
}
