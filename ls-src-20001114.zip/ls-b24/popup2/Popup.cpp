/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "PopupMaker.h"
#include "Popup.h"

PopupMaker* pPopupMaker;

//int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
//{
//	return initModuleEx (ParentWnd, dllInst, wd->lsPath);
//}

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	g_hResStrInstance = dllInst;
CoInitialize(NULL);
	pPopupMaker = new PopupMaker();
	pPopupMaker->Initialize(ParentWnd, dllInst, szPath);

	return 0;
}

int quitModule(HINSTANCE dllInst)
{
  CoUninitialize();
	delete pPopupMaker;

	return 1;
}

// Dummy startup routine that does almost nothing.
// This cuts out all of the standard startup code crud that
// bloats the DLL, and makes it take longer to load
BOOL __stdcall _DllMainCRTStartup(HINSTANCE hInst, DWORD fdwReason, LPVOID lpvRes)
{
     // We don't need thread notifications for what we're doing.  Thus, get
     // rid of them, thereby eliminating some of the overhead of this DLL
     DisableThreadLibraryCalls(hInst);
	 
	 return TRUE;
}
