#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>

#ifdef _DEBUG
#define _LSDEBUG
#endif
#include "..\lsapi\lsdebug.h"

BOOL PopupContextMenu(LPCTSTR pszPath); 
UINT GetItemCount (LPITEMIDLIST pidl);
LPITEMIDLIST GetNextItem (LPITEMIDLIST pidl);
LPITEMIDLIST DuplicateItem (LPMALLOC pMalloc, LPITEMIDLIST pidl);