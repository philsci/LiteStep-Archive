/*
  Copyright (C) 1998-1999 Johan Redestig
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#if !defined(AFX_DirectoryFolder_H__8B996E83_7DED_11D2_B6AE_00C0DF466974__INCLUDED_)
#define AFX_DirectoryFolder_H__8B996E83_7DED_11D2_B6AE_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FolderItem.h"

class PopupMaker;

/**
Extension to the FolderItem, this class implements the dynamic popup folder.
it is dynamic in the sense that it reloads the entire file structure when
it is invoked
*/
class DirectoryFolder : public FolderItem  
{
public:
	/**
	constructs a DirectoryFolder object

	@param pszFolderName path to the folder to be loaded
	@param bDynamic should it be reloaded each time
	@param pPopupMaker pointer to the configuration
	@param pszTitle user friendly name of the folder
	*/
	DirectoryFolder(char* pszPath, BOOL bDynamic, PopupMaker* pPopupMaker, char* pszTitle);

	/// destroys the DirectoryFolder object
	virtual ~DirectoryFolder();

	/**
	(de)activate this folder object

	@param bActicate
	*/
	BOOL Active(BOOL bActivate);

	/**
	Attaches this menu item to a popupmenu

	@param pMenu the menu that this item is connected to
	*/
	void Attached(PopupMenu* pMenu);


	static void SetShowExtension(BOOL bShow){m_bShowExtension = bShow;};

	static void SetAutoSeparator(BOOL bAuto){m_bAutoSeparator = bAuto;};

  void RInvoke();

protected:

	void UpdateFolder(PopupMenu* pMenu);

	PopupMenu* LoadFolder();

	/// should we keep the extension of files?
	static BOOL m_bShowExtension;

	/// should we insert a separator between the folders and the files?
	static BOOL m_bAutoSeparator;

	BOOL m_bDynamic;
	char* m_pszPath;
	PopupMaker* m_pPopupMaker;

};

#endif // !defined(AFX_DirectoryFolder_H__8B996E83_7DED_11D2_B6AE_00C0DF466974__INCLUDED_)
