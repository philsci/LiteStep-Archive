/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#pragma warning(disable: 4786)
#include "../core/ifcs.h"
#include <map>
#include <set>

using namespace std;

class StandardMessageManager : public IMessageManager
{
	typedef set<OLE_HANDLE> windowSet;
	typedef map<UINT, windowSet* > messageMap;

	messageMap msgMap;

	long refCount;

public:
	StandardMessageManager();
	virtual ~StandardMessageManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
	HRESULT STDMETHODCALLTYPE QueryInterface(
	    /* [in] */ REFIID riid,
	    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);

	ULONG STDMETHODCALLTYPE AddRef( void);

	ULONG STDMETHODCALLTYPE Release( void);

	///////////////////////////////////////////////////////////////////////////
	// From IMessageManager
	virtual /* [id] */ HRESULT STDMETHODCALLTYPE AddMessage(
	    /* [in] */ OLE_HANDLE window,
	    /* [in] */ UINT message);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE AddMessages(
	    /* [in] */ OLE_HANDLE window,
	    /* [in] */ SAFEARRAY __RPC_FAR * messages);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE RemoveMessage(
	    /* [in] */ OLE_HANDLE window,
	    /* [in] */ UINT message);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE RemoveMessages(
	    /* [in] */ OLE_HANDLE window,
	    /* [in] */ SAFEARRAY __RPC_FAR * messages);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE ClearMessages(void);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE SendMessage(
	    /* [in] */ UINT message,
	    /* [in] */ WPARAM wparam,
	    /* [in] */ LPARAM lparam,
	    /* [retval][out] */ LRESULT __RPC_FAR *retval);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE PostMessage(
	    /* [in] */ UINT message,
	    /* [in] */ WPARAM wparam,
	    /* [in] */ LPARAM lparam);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE HandlerExists(
	    /* [in] */ UINT message,
	    /* [retval][out] */ BOOL __RPC_FAR *exists);

	virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetRevID(
	    /* [in] */ UINT message,
	    /* [in] */ WPARAM wparam,
	    /* [in] */ LPARAM lparam);

	virtual HRESULT STDMETHODCALLTYPE GetWindowsForMessage(
	    /* [in] */ UINT message,
	    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);

	virtual HRESULT STDMETHODCALLTYPE GetMessagesForWindow(
	    /* [in] */ OLE_HANDLE hWnd,
	    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *retval);
};

