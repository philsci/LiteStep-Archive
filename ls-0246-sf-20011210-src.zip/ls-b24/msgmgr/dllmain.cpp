/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <comdef.h>
#include <string>
#include "StandardMessageManager.h"
#include "../lsapi/ClassFactory.h"
#include "../lsapi/common.h"

using namespace std;

HINSTANCE myInstance;
BOOL locked = FALSE;

extern "C"
	BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		myInstance = hInstance;
		DisableThreadLibraryCalls(hInstance);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		myInstance = NULL;
	}
	return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE


STDAPI DllCanUnloadNow(void)
{
	return !locked;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	HRESULT hr = CLASS_E_CLASSNOTAVAILABLE;

	*ppv = NULL;

	ClassFactory<StandardMessageManager> *classFact = new ClassFactory<StandardMessageManager>(IID_IMessageManager, &locked);
	if (classFact != NULL)
	{
		hr = classFact->QueryInterface(riid, ppv);
	}

	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the _tsystem registry

STDAPI DllRegisterServer(void)
{
	HKEY classRootKey, clsidKey, classKey, inprocKey, progidKey;
	LPOLESTR clsidString;

	StringFromCLSID(CLSID_StandardMessageManager, &clsidString);

	// RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Classes", 0, KEY_WRITE, &classRootKey);
	classRootKey = HKEY_CLASSES_ROOT;

	RegCreateKeyEx(classRootKey, "CLSID", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &clsidKey, NULL);
	RegCreateKeyEx(clsidKey, _bstr_t(clsidString), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &classKey, NULL);

	char *progid = "Litestep.MessageManager.1";
	RegSetValueEx(classKey, NULL, 0, REG_SZ, (unsigned char*)progid, strlen(progid));

	char filename[256];
	RegCreateKeyEx(classKey, "InprocServer32", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &inprocKey, NULL);
	GetModuleFileName(myInstance, filename, 256);
	RegSetValueEx(inprocKey, NULL, 0, REG_SZ, (unsigned char*)filename, strlen(filename));
	RegCloseKey(inprocKey);

	RegCreateKeyEx(classKey, "ProgID", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &progidKey, NULL);
	RegSetValueEx(progidKey, NULL, 0, REG_SZ, (unsigned char*)progid, strlen(progid));
	RegCloseKey(progidKey);

	RegCloseKey(classKey);
	RegCloseKey(clsidKey);

	char *fullname = "Litestep Standard Message Manager";
	RegCreateKeyEx(classRootKey, progid, 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &progidKey, NULL);
	RegSetValueEx(progidKey, NULL, 0, REG_SZ, (unsigned char*)fullname, strlen(fullname));
	RegCreateKeyEx(progidKey, "CLSID", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &clsidKey, NULL);
	RegSetValueEx(clsidKey, NULL, 0, REG_SZ, (unsigned char*)(LPSTR)_bstr_t(clsidString), _bstr_t(clsidString).length());

	RegCloseKey(clsidKey);
	RegCloseKey(progidKey);
	// RegCloseKey(classRootKey);

	CoTaskMemFree(clsidString);
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the _tsystem registry

STDAPI DllUnregisterServer(void)
{
	LPOLESTR clsidString;

	StringFromCLSID(CLSID_StandardMessageManager, &clsidString);
	string clsidStr = "CLSID";
	string clsidValue = _bstr_t(clsidString);
	string progid = "Litestep.MessageManager.1";

	RegDeleteKey(HKEY_CLASSES_ROOT, (clsidStr + "\\" + clsidValue + "\\InprocServer32").c_str());
	RegDeleteKey(HKEY_CLASSES_ROOT, (clsidStr + "\\" + clsidValue + "\\ProgID").c_str());
	RegDeleteKey(HKEY_CLASSES_ROOT, (clsidStr + "\\" + clsidValue).c_str());
	RegDeleteKey(HKEY_CLASSES_ROOT, (progid + "\\" + clsidStr).c_str());
	RegDeleteKey(HKEY_CLASSES_ROOT, progid.c_str());

	return NULL;
}

STDAPI CreateMessageManager()
{
	IUnknown *unknown;
	IMessageManager *msgMan;

	unknown = new StandardMessageManager();
	unknown->QueryInterface(IID_IMessageManager, (void**)&msgMan);
	//modMan->Release();

	return (LONG)msgMan;
}
