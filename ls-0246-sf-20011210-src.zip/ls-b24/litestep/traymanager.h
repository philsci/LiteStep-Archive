/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef TRAYMANAGER
#define TRAYMANAGER

#define TRAYMANAGER_CLASS "Shell_TrayWnd"
#define TRAYMANAGER_TITLE "Litestep Tray Manager"

// data sent by shell via Shell_NotifyIcon -- Maduin
typedef struct SHELLTRAYDATA
{
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
}
SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;

typedef struct LSNOTIFYICONDATA
{
	DWORD cbSize;
	HWND hWnd;
	UINT uID;
	UINT uFlags;
	UINT uCallbackMessage;
	HICON hIcon;
	CHAR szTip[256];
	DWORD dwState;
}
LSNOTIFYICONDATA, *PLSNOTIFYICONDATA;

typedef struct SYSTRAYICONDATA
{
	LSNOTIFYICONDATA nid;
	struct SYSTRAYICONDATA *pNext, *pPrev;
}
SYSTRAYICONDATA, *PSYSTRAYICONDATA;

typedef struct ShellServiceObjectList
{
	IOleCommandTarget *object;
	struct ShellServiceObjectList *next;
}
ShellServiceObjectList;


// this is the version of NOTIFYICONDATA that shell32.dll v5 uses
typedef struct _NOTIFYICONDATAV5
{
	DWORD cbSize;
	HWND hWnd;
	UINT uID;
	UINT uFlags;
	UINT uCallbackMessage;
	HICON hIcon;
	WCHAR szTip[128];
	DWORD dwState;
	DWORD dwStateMask;
	WCHAR szInfo[256];
	union {
		UINT uTimeout;
		UINT uVersion;
	} DUMMYUNIONNAME;
	WCHAR szInfoTitle[64];
	DWORD dwInfoFlags;
}
NOTIFYICONDATAV5, *PNOTIFYICONDATAV5;

#ifndef NIF_INFO
#define NIF_INFO        0x00000010
#endif
#ifndef NIS_HIDDEN
#define NIS_HIDDEN		0x00000001
#endif

class TrayManager
{
	HINSTANCE dll;

	HWND hTrayWnd;
	HWND hLiteStep;
	HWND hDUN;

	PSYSTRAYICONDATA pFirst;
	PSYSTRAYICONDATA pLast;

	ShellServiceObjectList *m_ssoList;
	OSVERSIONINFO OsVersionInfo;
	BOOL bWin2000;

public:
	~TrayManager();
	TrayManager(HWND, HINSTANCE, int& code);

	static LRESULT CALLBACK WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

	void SendSystemTray();

private:
	void LoadShellServiceObjects();
	void UnloadShellServiceObjects();
};

#endif //!defined TRAYMANAGER
