/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
11/26/01 - Bobby G. Vinyard (Message)
  - Uses new LSNOTIFYICONDATA structure to support longer
    tooltips. System tray modules will have to be updated before being used with this
    build. System tray must issue the LM_SYSTRAYREADY message when they are ready to
    receive the icons, and must not post the "TaskbarCreated" message.
****************************************************************************/
#include "..\lsapi\common.h"
#include <shlobj.h>
#include "TrayManager.h"

// TrayManager constructor
TrayManager::TrayManager(HWND lswnd, HINSTANCE lsdll, int& code)
{
	hLiteStep = lswnd;
	dll = lsdll;
	code = 0;

	pFirst = NULL;
	pLast = NULL;
	hDUN = NULL;
	m_ssoList = NULL;

	OsVersionInfo.dwOSVersionInfoSize = sizeof(OsVersionInfo);
	GetVersionEx(&OsVersionInfo);
	if ((OsVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) && (OsVersionInfo.dwMajorVersion == 5))
	{
		bWin2000 = true;
	}
	else
	{
		bWin2000 = false;
	}

	WNDCLASSEX wc;

	// Register tray notification window class
	memset(&wc, 0, sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.cbClsExtra = 0;

	wc.lpfnWndProc = TrayManager::WndProcTray;			// our window procedure
	wc.hInstance = lsdll;							// hInstance of DLL
	wc.lpszClassName = TRAYMANAGER_CLASS;			// our window class name
	wc.style = CS_DBLCLKS;

	if (!RegisterClassEx(&wc))
	{
		MessageBox(hLiteStep, "Error registering window class", TRAYMANAGER_CLASS, MB_OK | MB_TOPMOST);
		code = 1;
	}
	else
	{
		// Tray Manager Window
		hTrayWnd = CreateWindowEx(
		               WS_EX_TOPMOST | WS_EX_TOOLWINDOW,      				// exstyles
		               TRAYMANAGER_CLASS,      								// our window class name
		               TRAYMANAGER_TITLE,      								// use description for a window title
		               WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,      	// styles
		               0, 0,      											// position
		               0, 0,      											// width & height of window
		               NULL,      								// parent window
		               NULL,      											// no menu
		               dll,      											// hInstance of DLL
		               NULL);											// no window creation data
		if (!hTrayWnd)
		{
			UnregisterClass(TRAYMANAGER_CLASS, dll); // unregister window class
			code = 1;
			MessageBox(hLiteStep, "Error creating window", TRAYMANAGER_TITLE, MB_OK | MB_TOPMOST);
		}
		else
		{

			SetWindowLong(hTrayWnd, GWL_USERDATA, magicDWord);
			SetWindowLong(hTrayWnd, 0, (LONG)this);

			if (bWin2000)
			{
				LoadShellServiceObjects();
			}

			// Win98/IE4 stuff
			PostMessage( HWND_BROADCAST, RegisterWindowMessage("TaskbarCreated"), 0, 0 );
		}
	}
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for the system tray window
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK TrayManager::WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	TrayManager *theTrayManager = (TrayManager*)::GetWindowLong(hwnd, 0);

	if (theTrayManager)
	{
		return theTrayManager->WindowProcTray(hwnd, message, wParam, lParam);
	}
	else
	{
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT TrayManager::WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_COPYDATA:
		{
			// odd conversion... don't know about this...
			PNOTIFYICONDATAV5 pnid5 = NULL;
			PSYSTRAYICONDATA pnidFound = pFirst;
			PCOPYDATASTRUCT pcds;
			PSHELLTRAYDATA pstd;
			BOOL bNewIcon = TRUE;
			BOOL result = TRUE;

			// Get the WM_COPYDATA structure from the lParam
			pcds = (PCOPYDATASTRUCT) lParam;

			if ( pcds->dwData != 1 )
				return FALSE;

			// Get the shell tray data from the WM_COPYDATA structure
			pstd = (PSHELLTRAYDATA) pcds->lpData;

			// See if the NOTIFYICONDATA already exists in our list
			while (pnidFound)
			{
				if (pnidFound->nid.hWnd == pstd->nid.hWnd)
				{
					bNewIcon = FALSE;
					break;
				}
				pnidFound = pnidFound->pNext;
			}

			if ((pnidFound == NULL) && (pstd->nid.uFlags & ~NIM_DELETE))
			{
				pnidFound = new SYSTRAYICONDATA;
				memset(pnidFound, 0, sizeof(SYSTRAYICONDATA));
				pnidFound->nid.cbSize = sizeof(LSNOTIFYICONDATA);
			}

			switch (pstd->dwMessage)
			{
				case NIM_ADD:
				case NIM_MODIFY:
				{
					// On WinXP, this will actually be v6, so we check to see
					// if it's larger than v5
					// we only really need this for the tooltip info
					if (pstd->nid.cbSize >= sizeof(NOTIFYICONDATAV5))
					{

						pnid5 = (PNOTIFYICONDATAV5) & pstd->nid;

						pnidFound->nid.dwState = pnid5->dwState;

						if ((pnid5->uFlags & NIF_INFO) && (pnid5->szInfo))
						{

							UINT nChars = min( UINT( wcslen( pnid5->szInfo ) + 1 ), UINT(256) );
							::WideCharToMultiByte(CP_ACP, 0, pnid5->szInfo, nChars, pnidFound->nid.szTip, nChars, NULL, NULL);

							// just to ensure last character is a NULL... :P
							pnidFound->nid.szTip[255] = '\0';

							// Add the NIF_TIP flag so modules will know to use this
							pnid5->uFlags |= NIF_TIP;
						}
						else if ((pnid5->uFlags & NIF_TIP) && (pnid5->szTip))
						{
							UINT nChars = min( UINT( wcslen( pnid5->szTip ) + 1 ), UINT(256) );
							::WideCharToMultiByte(CP_ACP, 0, pnid5->szTip, nChars, pnidFound->nid.szTip, nChars, NULL, NULL);

							// just to ensure last character is a NULL... :P
							pnidFound->nid.szTip[255] = '\0';
						}
					}
					else
					{
						if ((pstd->nid.szTip) && (pstd->nid.uFlags & NIF_TIP))
						{
							strncpy(pnidFound->nid.szTip, pstd->nid.szTip, 256);
							pnidFound->nid.szTip[255] = '\0';
						}
					}

					if (bNewIcon)
					{
						pnidFound->nid.hWnd = pstd->nid.hWnd;
						pnidFound->nid.uID	= pstd->nid.uID;

						// Dun hack, the first time the DUN icon is created
						// its uID is 0xFFFFFFFF, after that it becomes 0x00000000
						if (pstd->nid.uID == 0xFFFFFFFF)
						{
							pnidFound->nid.uID = 0;
							hDUN = pnidFound->nid.hWnd;
						}
						pnidFound->nid.uFlags = pstd->nid.uFlags;
						if (pnidFound->nid.uFlags & NIF_MESSAGE)
						{
							pnidFound->nid.uCallbackMessage = pstd->nid.uCallbackMessage;
						}
						if (pnidFound->nid.uFlags & NIF_ICON)
						{
							pnidFound->nid.hIcon = pstd->nid.hIcon;
						}

						// add to last position in the list
						if (!pFirst)
						{
							pFirst = pnidFound;
							pnidFound->pPrev = NULL;
						}
						if (pLast)
						{
							pnidFound->pPrev = pLast;
							pLast->pNext = pnidFound;
						}
						pLast = pnidFound;
						pnidFound->pNext = NULL;

						//PrintCrap(&pnidFound->nid, pstd->dwMessage, NIM_ADD);

						result = SendMessage(hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) & pnidFound->nid);
					}
					else
					{
						DWORD dwFlags = pnidFound->nid.uFlags;

						// Silly DUN hack
						if (pnidFound->nid.hWnd == hDUN)
						{
							pnidFound->nid.uID = 0x00000000;
						}

						if (pstd->nid.uFlags & NIF_MESSAGE)
						{
							pnidFound->nid.uCallbackMessage = pstd->nid.uCallbackMessage;
						}

						if (pstd->nid.uFlags & NIF_ICON)
							pnidFound->nid.hIcon = pstd->nid.hIcon;

						pnidFound->nid.uFlags = pstd->nid.uFlags;

						result = SendMessage(hLiteStep, LM_SYSTRAY, NIM_MODIFY, (LPARAM) & pnidFound->nid);

						// Update the flags, so that if we have to resend this, it's
						// up to date
						pnidFound->nid.uFlags |= dwFlags;
					}
					break;
				}
				case NIM_DELETE:
				{
					if ((pnidFound) && !(bNewIcon))
					{
						// if it's first or last, move those pointers
						if (pFirst == pnidFound)
							pFirst = pnidFound->pNext;
						else
							pnidFound->pPrev->pNext = pnidFound->pNext;

						if (pLast == pnidFound)
							pLast = pnidFound->pPrev;
						else
							pnidFound->pNext->pPrev = pnidFound->pPrev;

						// remove the icon class
						result = SendMessage(hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM) & pnidFound->nid);

						delete pnidFound;

					}
					break;
				}
				default:
				{
					result = FALSE;
					break;
				}
			}

			return result;

		}

	}

	return ::DefWindowProc(hwnd, message, wParam, lParam);
}

TrayManager::~TrayManager()
{
	PSYSTRAYICONDATA pnidFound, pnidNext = NULL;

	if (bWin2000)
	{
		UnloadShellServiceObjects();
	}

	if (hTrayWnd)
	{
		DestroyWindow(hTrayWnd); // delete our window

		UnregisterClass(TRAYMANAGER_CLASS, dll); // unregister window class
	}

	// See if the NOTIFYICONDATA already exists in our list


	pnidFound = pFirst;
	while (pnidFound)
	{
		pnidNext = pnidFound->pNext;
		if (pnidFound)
		{
			// if it's first or last, move those pointers
			if (pFirst == pnidFound)
				pFirst = pnidFound->pNext;
			else
				pnidFound->pPrev->pNext = pnidFound->pNext;

			if (pLast == pnidFound)
				pLast = pnidFound->pPrev;
			else
				pnidFound->pNext->pPrev = pnidFound->pPrev;

			delete pnidFound;
		}
		pnidFound = pnidNext;
	}
}


void TrayManager::SendSystemTray()
{
	PSYSTRAYICONDATA pnidFound = pFirst;

	// See if the NOTIFYICONDATA already exists in our list
	while (pnidFound)
	{
		SendMessage(hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM)&pnidFound->nid);
		pnidFound = pnidFound->pNext;
	}

}

void TrayManager::LoadShellServiceObjects()
{
	HKEY hkeyServices;
	LONG lErrorCode;
	int i = 0;

	lErrorCode = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
	                          "Software\\Microsoft\\Windows\\CurrentVersion\\ShellServiceObjectDelayLoad",
	                          0, KEY_READ, &hkeyServices);


	while (lErrorCode == ERROR_SUCCESS)
	{
		char szValueName[32];
		char szData[40];
		DWORD cbValueName = 32;
		DWORD cbData = 40;
		DWORD dwDataType;

		lErrorCode = RegEnumValue(hkeyServices, i,
		                          szValueName, &cbValueName, 0,
		                          &dwDataType,
		                          (LPBYTE) szData, &cbData);

		if (lErrorCode == ERROR_SUCCESS)
		{
			WCHAR wszCLSID[40];
			CLSID clsid;
			IOleCommandTarget *pCmdTarget = NULL;

			MultiByteToWideChar(CP_ACP, 0, szData, cbData, wszCLSID, 40);

			CLSIDFromString(wszCLSID, &clsid);

			HRESULT hr = CoCreateInstance(clsid, NULL, CLSCTX_INPROC_SERVER | CLSCTX_INPROC_HANDLER,
			                              IID_IOleCommandTarget, (void **) & pCmdTarget);

			if (SUCCEEDED(hr))
			{
				pCmdTarget->Exec(&CGID_ShellServiceObject, 2, 0, NULL, NULL);

				ShellServiceObjectList *entry = new ShellServiceObjectList;
				entry->object = pCmdTarget;
				entry->next = m_ssoList;
				m_ssoList = entry;
			}
		}

		i++;
	}
}

void TrayManager::UnloadShellServiceObjects()
{
	ShellServiceObjectList *current = m_ssoList;
	ShellServiceObjectList *next;

	while (current)
	{
		next = current->next;

		current->object->Exec(&CGID_ShellServiceObject, 3, 0, NULL, NULL);
		current->object->Release();
		delete current;

		current = next;
	}

	m_ssoList = NULL;
}
