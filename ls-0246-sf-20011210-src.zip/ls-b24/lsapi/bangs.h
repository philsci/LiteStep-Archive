/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef _BANGS_H
#define _BANGS_H

void BangAbout(HWND caller, LPCSTR args);
void BangAlert(HWND caller, LPCSTR args);
void BangCascadeWindows(HWND caller, LPCSTR args);
void BangConfirm(HWND caller, LPCSTR args);
void BangExecute(HWND caller, LPCSTR args);
void BangGather(HWND caller, LPCSTR args);
void BangLogoff(HWND caller, LPCSTR args);
void BangMinimizeWindows(HWND caller, LPCSTR args);
void BangPopup(HWND caller, LPCSTR args);
void BangQuit(HWND caller, LPCSTR param);
void BangRecycle (HWND caller, LPCSTR args);
void BangRefresh(HWND caller, LPCSTR args);
void BangReload(HWND caller, LPCSTR args);
void BangReloadModule (HWND caller, LPCSTR args);
void BangRestoreWindows(HWND caller, LPCSTR args);
void BangRun (HWND caller, LPCSTR args);
void BangShutdown(HWND caller, LPCSTR args);
void BangTileWindowsH(HWND caller, LPCSTR args);
void BangTileWindowsV(HWND caller, LPCSTR args);
void BangToggleWharf(HWND caller, LPCSTR args);
void BangUnloadModule (HWND caller, LPCSTR args);

#endif

