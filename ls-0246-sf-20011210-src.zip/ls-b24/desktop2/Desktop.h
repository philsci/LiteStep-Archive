/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __DESKTOP_H
#define __DESKTOP_H

#include "..\lsapi\common.h"
#include "..\lsapi\lswinbase.h"
#include "resource.h"

#include <map>
#include <string>

using namespace std;
typedef map<UINT, string> mapClicks;

// X Button Support
#ifndef WM_XBUTTONDOWN
#define WM_XBUTTONDOWN                  0x020B
#define WM_XBUTTONUP                    0x020C
#define WM_XBUTTONDBLCLK                0x020D
#ifdef WM_MOUSELAST
#undef WM_MOUSELAST
#endif
#define WM_MOUSELAST                    0x020D
#define GET_KEYSTATE_WPARAM(wParam)     (LOWORD(wParam))
#define GET_NCHITTEST_WPARAM(wParam)    ((short)LOWORD(wParam))
#define GET_XBUTTON_WPARAM(wParam)      (HIWORD(wParam))

/* XButton values are WORD flags */
#define XBUTTON1      0x0001
#define XBUTTON2      0x0002

#define MK_XBUTTON1   0x0020
#define MK_XBUTTON2   0x0040
#endif

#define MK_MENU       0x0080
#define MK_LWIN       0x0100
#define MK_RWIN       0x0200
#define MK_APPS       0x0400

#define MOD_LBUTTON  0x1000000
#define MOD_MBUTTON  0x2000000
#define MOD_RBUTTON  0x4000000
#define MOD_XBUTTON1 0x8000000
#define MOD_XBUTTON2 0x0100000
#define MAX_LINE_LENGTH 4096

class Desktop : public Window
{
private:
	int screenLeft;
	int screenTop;
	int screenWidth;
	int screenHeight;

	bool setDesktopArea;
	bool setDesktopAreaMainMonitorOnly;

	mapClicks bangClicks;

	int sdaLeft;
	int sdaRight;
	int sdaBottom;
	int sdaTop;

public:
	Desktop(HWND parentWnd, int& code);
	~Desktop();

	void bangSetClick(LPCSTR args);
	void bangSetArea(LPCSTR args);

	void setupDesktop();
	void cleanDesktop();

	HWND handle()
	{
		return hWnd;
	}

private:
	void setMinMax(void);
	void resetMinMax(void);
	UINT parseLine(LPSTR line);

	virtual void windowProc(Message& message);
	void onActivate(Message& message);
	void onDisplayChange(Message& message);
	void onEndSession(Message& message);
	void onEraseBkgnd(Message& message);
	void onGetRevId(Message& message);
	void onKeyMessage(Message& message);
	void onMouseActivate(Message& message);
	void onMouseButtonDown(Message& message);
	void onMouseButtonUp(Message& message);
	void onSysCommand(Message& message);
	void onWindowPosChanging(Message& message);
	void onRefresh(Message& message);
};

void BangSetClick(HWND caller, LPCSTR args);
void BangSetArea(HWND caller, LPCSTR args);

extern "C"
{
	__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
	__declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
