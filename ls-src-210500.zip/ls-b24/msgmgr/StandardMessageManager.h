#pragma warning(disable: 4786)
#include "../core/ifcs.h"
#include <map>
#include <set>

using namespace std;

class StandardMessageManager : public IMessageManager  
{
	typedef set<OLE_HANDLE> windowSet;
	typedef map<UINT, windowSet* > messageMap;

	messageMap msgMap;

	long refCount;

public:
	StandardMessageManager();
	virtual ~StandardMessageManager();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	////////////////////////////////////////////////////////////////////////////
	// From IDispatch
    HRESULT STDMETHODCALLTYPE GetTypeInfoCount( 
        /* [out] */ UINT __RPC_FAR *pctinfo);
		
	HRESULT STDMETHODCALLTYPE GetTypeInfo( 
		/* [in] */ UINT iTInfo,
		/* [in] */ LCID lcid,
		/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
	
	HRESULT STDMETHODCALLTYPE GetIDsOfNames( 
		/* [in] */ REFIID riid,
		/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
		/* [in] */ UINT cNames,
		/* [in] */ LCID lcid,
		/* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
	
	/* [local] */ HRESULT STDMETHODCALLTYPE Invoke( 
		/* [in] */ DISPID dispIdMember,
		/* [in] */ REFIID riid,
		/* [in] */ LCID lcid,
		/* [in] */ WORD wFlags,
		/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
		/* [out] */ VARIANT __RPC_FAR *pVarResult,
		/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
		/* [out] */ UINT __RPC_FAR *puArgErr);
	
	///////////////////////////////////////////////////////////////////////////
	// From IMessageManager
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE AddMessage( 
        /* [in] */ OLE_HANDLE window,
        /* [in] */ UINT message);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE AddMessages( 
        /* [in] */ OLE_HANDLE window,
        /* [in] */ SAFEARRAY __RPC_FAR * messages);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE RemoveMessage( 
        /* [in] */ OLE_HANDLE window,
        /* [in] */ UINT message);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE RemoveMessages( 
        /* [in] */ OLE_HANDLE window,
        /* [in] */ SAFEARRAY __RPC_FAR * messages);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE ClearMessages(void);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE SendMessage( 
        /* [in] */ UINT message,
        /* [in] */ WPARAM wparam,
        /* [in] */ LPARAM lparam);
    
    virtual /* [id] */ HRESULT STDMETHODCALLTYPE PostMessage( 
        /* [in] */ UINT message,
        /* [in] */ WPARAM wparam,
        /* [in] */ LPARAM lparam);

    virtual /* [id] */ HRESULT STDMETHODCALLTYPE HandlerExists( 
        /* [in] */ UINT message,
        /* [retval][out] */ BOOL __RPC_FAR *exists);

    virtual /* [id] */ HRESULT STDMETHODCALLTYPE GetRevID( 
        /* [in] */ UINT message,
        /* [in] */ WPARAM wparam,
        /* [in] */ LPARAM lparam);
};

