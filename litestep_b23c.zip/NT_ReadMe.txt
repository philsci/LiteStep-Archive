

  NT-specific installation:

  - Use regedit.
  - Go to key HKLM\SOFTWARE\Microsoft\Windows NT\Current Version\Winlogon\
  - Change the data string "Shell" (currently to EXPLORER.EXE) to "yourpath\LITESTEP.exe"
  - Go to key HKLM\SOFTWARE\Microsoft\Windows\Current Version\Explorer\
  - (or HKCU\SOFTWARE\Microsoft\Windows\Current Version\Explorer\ for
    user-specific edition)
  - Create a key of type DWORD named DesktopProcess and give it a value of 1
    (this will allow explorer to run more than one instance in spite of the
    fact that it is not the shell)
  - Check step.rc, there are a couple of documented modifications you have to do for WinNT


  Warning:
  --------

  If you use Microsoft IE4, you'll not be able to open more than one instance
  of explorer, even if you put the registry key DesktopProcess. This is due
  to IE4, it is documented by Microsoft.

  In this case, i suggest you get a replacement for explorer. There are at
  least two excellent replacements:

    - PowerDesk (better than explorer in my opinion, but shareware)
    - Servant Salamander (verry good and freeware)

  Check my homepage at http://litestep.computerheaven.net for links
