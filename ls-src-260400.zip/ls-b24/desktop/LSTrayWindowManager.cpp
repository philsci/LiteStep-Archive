#include <windows.h>
#include "LSTrayWindowManager.h"
#include "LSBar.h"

// LSTrayWindowManager constructor
LSTrayWindowManager::LSTrayWindowManager(LSBar *own) {
	dontReleaseIcons = FALSE;
	paintedYet = false;
	WNDCLASSEX wc;
	int xwidth;
	owner = own;
	
	if (owner->settings.appBar) {
	    parent = owner->hBarWnd;
	} else {
		parent = NULL;
	}

	dllInst = owner->dll;

	// extra window memory for class pointer
	wc.cbWndExtra = 4;

    // Register tray notification window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
   	wc.lpfnWndProc = LSTrayWindowManager::WndProcTray;			// our window procedure
   	wc.hInstance = dllInst;					// hInstance of DLL
   	wc.lpszClassName = szTray;			// our window class name
   	wc.style = CS_DBLCLKS;
   	if (!RegisterClassEx(&wc)) {
		MessageBox(parent,"Error registering window class",szTray,MB_OK);
		//return 1;
   	}

    // Register tray icon class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
   	wc.lpfnWndProc = LSTrayWindowManager::WndProcIcon;			// our window procedure
   	wc.hInstance = dllInst;					// hInstance of DLL
   	wc.lpszClassName = szTrayIcon;			// our window class name
   	wc.style = CS_DBLCLKS;
   	if (!RegisterClassEx(&wc)) {
   	}

	// System Tray
	if (owner->settings.appBar) {
		xwidth = owner->barLeft + 2;
		owner->systray = owner->hBarWnd;
	} else {
		xwidth = 6;
		owner->systray = 0;
		if (owner->settings.dockToWharf) {
			EnumChildWindows(GetDesktopWindow(),LSBar::EnumChildWindowsProc,(LPARAM)&owner->systray);
			if (!owner->systray) {
				MessageBoxA(NULL,"Unable to find LSSysTray wharf","Desktop.dll",MB_OK);
				owner->systray = NULL;
			}
			owner->settings.sysTrayBottom = 0;
			owner->settings.sysTrayRight = 0;
			owner->settings.sysTrayWrap = 3;
			owner->settings.trayIconSize = 16;
			owner->settings.sysTrayOffset = 0;
		} else {
			owner->systray = NULL;
		}
	}

	DWORD style = NULL;

	if (owner->settings.appBar) {
		style = WS_CHILD | WS_CLIPSIBLINGS;
	}

	hTrayWnd = CreateWindowEx(
		0,						                // exstyles 
		szTray,							        // our window class name
		"LSSysTray",										// use description for a window title
		style,				
		//		if (!settings.appBar)
		//			WS_CHILD|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,
		xwidth, 3,									// position 
		6,owner->settings.trayIconSize+6,				        // width & height of window
		owner->systray,								// parent window 
		NULL,									// no menu
		owner->dll,								// hInstance of DLL
		NULL);									// no window creation data
	if (!hTrayWnd) {						   
		MessageBox(parent,"Error creating window",szTray,MB_OK);
		//return 1;
	}

	UINT Msgs[4];
	Msgs[0] = LM_SYSTRAY;
	Msgs[1] = LM_SAVESYSTRAY;
	Msgs[2] = LM_RESTORESYSTRAY;
	Msgs[3] = 0;
	SendMessage(owner->parent, LM_REGISTERMESSAGE, (WPARAM)hTrayWnd, (LPARAM)Msgs);

	SetWindowLong(hTrayWnd, GWL_USERDATA, magicDWord);
	SetWindowLong(hTrayWnd, LS_GWL_CLASSPOINTER, (LONG)this);
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for system tray icons
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK LSTrayWindowManager::WndProcIcon(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LSTrayWindowManager *theTrayWindowManager = (LSTrayWindowManager*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theTrayWindowManager) {
		return theTrayWindowManager->WindowProcIcon(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT LSTrayWindowManager::WindowProcIcon(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_CREATE:		return 0;
	case WM_ERASEBKGND: return 1;
	case WM_PAINT:
		{ // update from doublebuffer
			HICON ico;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
			
			//StretchBlt(owner->bufferDC, 0, 0, 32, 32, hdc, 0, 0, owner->settings.trayIconSize, owner->settings.trayIconSize, SRCCOPY);
			ico = (HICON)GetWindowLong(hwnd, GWL_USERDATA);
			DrawIconEx(hdc, 0, 0, ico, owner->settings.trayIconSize, owner->settings.trayIconSize, 0, NULL, DI_NORMAL);
			//StretchBlt(hdc, 0, 0, owner->settings.trayIconSize, owner->settings.trayIconSize, owner->bufferDC, 0, 0, 32, 32, SRCCOPY);
			
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_MOUSEACTIVATE:
		return MA_NOACTIVATE;
	case WM_LBUTTONDBLCLK: // Forward messages to the application
	case WM_LBUTTONDOWN:
	case WM_LBUTTONUP:
	case WM_MBUTTONDBLCLK:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_RBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONUP:
	case WM_MOUSEMOVE:
		{
			// To do: see why some rare application opens their
			// context menu on top of the screen instead of
			// where the mouse is
			//packScreenTray();
			int i = getTrayByIcon(hwnd);
			MSG TooltipMessage;

			if (!::IsWindow(trayWnds[i].hWnd)) {
				removeFromTray(trayWnds[i].hWnd, trayWnds[i].uID);
				return 0;
			}
			
			if (i >= 0) {
				SendMessage(trayWnds[i].hWnd, trayWnds[i].message, trayWnds[i].uID, message);
				
				TooltipMessage.hwnd=trayWnds[i].trayWnd;
				TooltipMessage.message=message;
				TooltipMessage.wParam=wParam;
				TooltipMessage.lParam=lParam;
				SendMessage(owner->hToolTips,TTM_RELAYEVENT,0,(LPARAM)&TooltipMessage);
				SetWindowPos(owner->hToolTips, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
			}
		}
		
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		PostMessage(parent,message,wParam,lParam);

		return 0;
	case WM_SYSCOMMAND:
		switch (wParam) {
		case SC_CLOSE:
			PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
			return 0;
		default:
			return DefWindowProc(hwnd,message,wParam,lParam);
		}

  }
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for the system tray window
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK LSTrayWindowManager::WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{	
	LSTrayWindowManager *theTrayWindowManager = (LSTrayWindowManager*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theTrayWindowManager) {
		return theTrayWindowManager->WindowProcTray(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT LSTrayWindowManager::WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_CREATE:		return 0;
	case WM_ERASEBKGND: return 0;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
            RECT r;
			HBITMAP oldBMP;
			
            if (!paintedYet) {
				// First time painting
				paintedYet = true;
                //int i;
                SendMessage(hBarWnd, WM_PAINT, 0, 0);
                SendMessage(hTrayWnd, WM_PAINT, 0, 0);
                //SendMessage(hTasksWnd, WM_PAINT, 0, 0);
				//PostMessage(parent, 9184, 0, 0);
			}
			
            if (owner->settings.appBar) {
                GetClientRect(hwnd, &r);
				if (owner->settings.taskBMP.bitmap == NULL) { 
					if (owner->settings.newStyle) {
						HBRUSH brush = CreateSolidBrush(owner->settings.back);
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					} else {
						int tempclr = GetSysColor(COLOR_3DFACE);
						HBRUSH brush = CreateSolidBrush(tempclr);
						FillRect(hdc, &r, brush);
						DeleteObject(brush);
					}
				} else {
					RECT r1; //Taskbar skin
					HDC memDC; 
					
					memDC = CreateCompatibleDC(hdc);
					oldBMP = (HBITMAP)SelectObject(memDC, owner->settings.taskBMP.bitmap);
					GetWindowRect(hwnd, &r1);
					BitBlt(hdc, r.left, r.top, r.right, r.bottom, memDC, r1.left, 3,SRCCOPY);
					SelectObject(memDC, oldBMP);
					DeleteDC(memDC);
				}
			} 
			
			if (owner->settings.tasktrayskinBMP.bitmap == NULL) {
				HPEN old, pen;
				int clr1,clr2;
				
				if (owner->settings.newStyle) clr1 = owner->settings.fore; else clr1 = GetSysColor(COLOR_3DHILIGHT);
				if (owner->settings.newStyle) clr2 = owner->settings.fore2; else clr2 = GetSysColor(COLOR_3DDKSHADOW);
				
				pen = CreatePen(PS_SOLID, 1, clr1);
				old = (HPEN)SelectObject(hdc, pen);
				MoveToEx(hdc, r.right-2, 0, NULL);
				LineTo(hdc, r.right-2, r.bottom-1);
				LineTo(hdc, 0, r.bottom-1);
				SelectObject(hdc, old);
				DeleteObject(pen);
				pen = CreatePen(PS_SOLID, 1, clr2);
				old = (HPEN)SelectObject(hdc, pen);
				LineTo(hdc, 0, 0);
				LineTo(hdc, r.right-2, 0);
				SelectObject(hdc, old);
				DeleteObject(pen);
			} else {
				HDC memDC;
				int xpos = r.left+owner->settings.tasktrayleftBMP.x,
                    ypos = r.top;
				memDC = CreateCompatibleDC(hdc);
				oldBMP = (HBITMAP)SelectObject(memDC, owner->settings.tasktrayskinBMP.bitmap);
				while (ypos < r.bottom) {
					xpos = r.left+owner->settings.tasktrayleftBMP.x;
					while (xpos < r.right-owner->settings.tasktrayrightBMP.x) {
						int bmpx = owner->settings.tasktrayskinBMP.x;
						while (xpos + bmpx > r.right-owner->settings.tasktrayrightBMP.x) bmpx--;
						TransparentBltLS(hdc, xpos, ypos, bmpx, owner->settings.tasktrayskinBMP.y, memDC, 0, 0, RGB(255,0,255));
						xpos += owner->settings.tasktrayskinBMP.x;
					}
					ypos += owner->settings.tasktrayskinBMP.y;
				}
				SelectObject(memDC, oldBMP);
				DeleteDC(memDC);
			}
			if (owner->settings.tasktrayleftBMP.bitmap != NULL)
			{
				HDC memDC;
				int xpos = r.left,
					ypos = r.top;
				memDC = CreateCompatibleDC(hdc);
				oldBMP = (HBITMAP)SelectObject(memDC, owner->settings.tasktrayleftBMP.bitmap);
				while (ypos < r.bottom)
				{
					TransparentBltLS(hdc, xpos, ypos, owner->settings.tasktrayleftBMP.x, owner->settings.tasktrayleftBMP.y, memDC, 0, 0, RGB(255,0,255));
					ypos += owner->settings.tasktrayleftBMP.y;
				}
				SelectObject(memDC, oldBMP);
				DeleteDC(memDC);
			}
			if (owner->settings.tasktrayrightBMP.bitmap != NULL)
			{
				HDC memDC;
				int xpos = r.right-owner->settings.tasktrayrightBMP.x,
					ypos = r.top;
				memDC = CreateCompatibleDC(hdc);
				oldBMP = (HBITMAP)SelectObject(memDC, owner->settings.tasktrayrightBMP.bitmap);
				while (ypos < r.bottom)
				{
					TransparentBltLS(hdc, xpos, ypos, owner->settings.tasktrayrightBMP.x, owner->settings.tasktrayrightBMP.y, memDC, 0, 0, RGB(255,0,255));
					ypos += owner->settings.tasktrayleftBMP.y;
				}
				SelectObject(memDC, oldBMP);
				DeleteDC(memDC);
			}
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		{	
			PostMessage(parent,message,wParam,lParam);
		}
		return 0;
		
	case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
			case SC_CLOSE:
				PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				return DefWindowProc(hwnd,message,wParam,lParam);
			}
		}
	case LM_SYSTRAY:
		// This handles notifications from the tray module via litestep.
		// lParam contains the NOTIFYICONDATA.
		{
			NOTIFYICONDATA *data;
			UINT trayMessage ;

			data = (NOTIFYICONDATA*)lParam;
			trayMessage = wParam;
			
			
			if (!owner) {
				break;
			}
			
			switch (trayMessage) {
			case NIM_ADD:
				addIcon(data);					
				break;
			case NIM_DELETE:
				// stop now if "No Systray"
				if( owner->settings.fNoSystray ) break;
				
				// Remove icon from tray
				removeFromTray(data->hWnd, data->uID);
				break;
			case NIM_MODIFY:
				modifyIcon(data);
				break;
			}
		}
		return 0;
    }
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Get a systray entry from the HWND of its icon
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::getTrayByIcon(HWND trayIcon) {
	TW_vector::iterator iter; 
	int i = 0;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		if (iter->trayWnd == trayIcon) {
			return i;
		}

		i++;
		iter++;
    }
	return -1;
}

// -------------------------------------------------------------------------------------------------------
// Get a systray entry from the HWND of its application
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::getTrayByWnd(HWND hWnd) {
	TW_vector::iterator iter;
	int i = 0;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		if (iter->hWnd == hWnd) {
			return i;
		}

		i++;
		iter++;
    }
	return -1;
}

// -------------------------------------------------------------------------------------------------------
// Get a systray entry from its ID
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::getTrayByUID(UINT uid) {
	TW_vector::iterator iter;
	int i = 0;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		if (iter->uID == uid) {
			return i;
		}

		i++;
		iter++;
    }
	return -1;
}

// -------------------------------------------------------------------------------------------------------
// Get a systray entry from its window and ID
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::getTrayByWndAndUID(HWND hWnd, UINT uID) {
	TW_vector::iterator iter;
	int i = 0;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		if (iter->uID == uID && iter->hWnd == hWnd) {
			return i;
		}

		i++;
		iter++;
    }
	return -1;
}

// -------------------------------------------------------------------------------------------------------
// Reset system tray
// -------------------------------------------------------------------------------------------------------
void LSTrayWindowManager::removeAllTrays(void) {
	TW_vector::iterator iter;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		DestroyWindow(iter->trayWnd); // delete our window
		if (!dontReleaseIcons)
			DestroyIcon(iter->hIcon); // delete our icon

		iter++;
	}

	trayWnds.clear();
}

// -------------------------------------------------------------------------------------------------------
// Add a new icon to system tray
// -------------------------------------------------------------------------------------------------------
const LSTrayWindow &LSTrayWindowManager::addToTray(HWND trayWnd, HWND hWnd, int message, HICON hIcon, HICON hOriginalIcon, UINT uID, char *tip)
{
	RECT r;

	LSTrayWindow trayWindow;
	trayWindow.trayWnd = trayWnd;
	trayWindow.hWnd = hWnd;
	trayWindow.message = message;
	trayWindow.hIcon = hIcon;
	trayWindow.hOriginalIcon = hOriginalIcon; // Not used
	trayWindow.uID = uID;
	if (tip) strcpy(trayWindow.szTip, tip);

	trayWnds.push_back(trayWindow);

	packScreenTray();
	
	GetClientRect(trayWindow.trayWnd, &r);
	owner->toolTips->CreateTooltip(trayWindow.trayWnd, tip, &r);

	return trayWnds.back();
}

// -------------------------------------------------------------------------------------------------------
// Removes an icon from the system tray
// -------------------------------------------------------------------------------------------------------
void LSTrayWindowManager::removeFromTray(HWND hWnd, UINT uID)
{
	int i;

	i = getTrayByWndAndUID(hWnd, uID);

	if (i == -1) {
		return;
	}

	//owner->toolTips->RemoveTooltip(trayWnds[i].trayWnd);
	DestroyWindow(trayWnds[i].trayWnd); // delete our window

	// remove from the vector
	trayWnds.erase(&trayWnds[i]);
	
	packScreenTray();
}

LSTrayWindow &LSTrayWindowManager::operator[](int index) {
	return trayWnds[index];
}

// -------------------------------------------------------------------------------------------------------
// COmpact system tray list (removes unused entries)
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::packScreenTray()
{
	int	j=-1;
	
	TW_vector::iterator iter, oldIter;

	iter = trayWnds.begin();
	while (iter != trayWnds.end()) {
		if (!::IsWindow(iter->hWnd)) {
			DestroyWindow(iter->trayWnd); // delete our window

			// remove from the vector
			oldIter = iter;
			iter++;
			trayWnds.erase(oldIter);
			continue;
		}

		RECT r;

		j++;

		if (!GetClientRect (iter->hWnd, &r)) {
			r.left = r.top = 0;
		}
		
		if (!owner->settings.appBar) {
			// If no app bar, set up tray window according to settings

			if (owner->settings.sysTrayRight) {
				if (owner->settings.sysTrayVertical) {
					// right side, vertical
					iter->x = owner->ScreenWidth -  ((j / owner->settings.sysTrayWrap) + 1) * (owner->settings.trayIconSize + 3);
				} else {
					// right side, normal (horizontal)
					iter->x = owner->ScreenWidth - owner->settings.sysTrayOffset - ((j % owner->settings.sysTrayWrap) + 1) * (owner->settings.trayIconSize + 3);
				}
			} else {
				if (owner->settings.sysTrayVertical) {
					// left side, vertical
					iter->x = 3 + (j / owner->settings.sysTrayWrap) * (owner->settings.trayIconSize + 3);
				} else {
					// left side, normal (horizontal)
					iter->x = owner->settings.sysTrayOffset + 3 + (j % owner->settings.sysTrayWrap) * (owner->settings.trayIconSize + 3);
				}
			}
			
			if (owner->settings.sysTrayBottom) {
				if (owner->settings.sysTrayVertical) {
					// bottom, vertical
					iter->y = owner->ScreenHeight - owner->settings.sysTrayOffset - ((j % owner->settings.sysTrayWrap) + 1) * (owner->settings.trayIconSize + 3);
				} else {
					// bottom, horizontal
					iter->y = owner->ScreenHeight - ((j / owner->settings.sysTrayWrap) + 1) * (owner->settings.trayIconSize + 3);
				}
			} else {
				if (owner->settings.sysTrayVertical) {
					// top, vertical
					iter->y = owner->settings.sysTrayOffset + 3 + (j % owner->settings.sysTrayWrap) * (owner->settings.trayIconSize + 3);
				} else {
					// top, horizontal
					iter->y = 3 + (j / owner->settings.sysTrayWrap) * (owner->settings.trayIconSize + 3);
				}
			}
		} else {
			iter->x = j*(owner->settings.trayIconSize+2)+4;
			iter->y = 3;
		}
		
		if (r.left != iter->x || r.top != iter->y) {
			SetWindowPos(iter->trayWnd, 0, iter->x, iter->y, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
		}

		iter++;
    }
	
	if (trayWnds.size() > 0 && owner->settings.appBar) {
		owner->adjustWndSizes();
    }
	
	return trayWnds.size();
}


LSTrayWindowManager::~LSTrayWindowManager()
{
	DestroyWindow(hTrayWnd); // delete our window
    removeAllTrays();
	UnregisterClass(szTray,dllInst); // unregister window class
	UnregisterClass(szTrayIcon, dllInst);
}

// -------------------------------------------------------------------------------------------------------
// Returns how many icons are in the system tray
// -------------------------------------------------------------------------------------------------------
int LSTrayWindowManager::nTrayIcons(void)
{
	return trayWnds.size();
}

void LSTrayWindowManager::getRectangle(LPRECT r){
	GetClientRect(hTrayWnd, r);
}

int LSTrayWindowManager::addIcon(NOTIFYICONDATA *data) {
	int i;
	HWND iconWnd;
	int targetMsg=-1;
	HICON targetIcon=NULL;
	char targetTip[256]="";

	// Adding a tray icon to the system tray
	
	HWND pTrayWnd;
	
	// If settings say no systray, end this now
	if( owner->settings.fNoSystray ) return 1;
	
	// If there is an app bar, use the tray window we own
	if (owner->settings.appBar) {
		pTrayWnd = hTrayWnd;
	} else {
		pTrayWnd = owner->hMainWnd;
	}
	
	// If we are docking to wharf, use parent's systray
	if (owner->settings.dockToWharf) {
		pTrayWnd = owner->systray;
	}
	
	// If we've already added this icon, skip to modification
	i = getTrayByWnd(data->hWnd);
	if (i >= 0 && data->uID == trayWnds[i].uID) {
		return modifyIcon(data);
	}
	
	// If there is an app-specific callback message, set it appropriately
	if (data->uFlags & NIF_MESSAGE)	targetMsg = data->uCallbackMessage;
	
	// If there is a tip, copy it
	if (data->uFlags & NIF_TIP && data->szTip) {
		memset(targetTip, 0, sizeof(targetTip));
		if (owner->os_info.dwPlatformId == VER_PLATFORM_WIN32_NT) {
			WideCharToMultiByte(
				CP_ACP,
				0,
				(wchar_t *) data->szTip,
				wcslen ((wchar_t *) data->szTip),
				targetTip,
				sizeof (targetTip),
				NULL,
				NULL);
		} else {
			strcpy(targetTip, data->szTip);
		}
	}
	
	// Create icon window
	iconWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,					// exstyles
		szTrayIcon,							// our window class name
		"",									// use description for a window title
		WS_CHILD | WS_VISIBLE,							// Child of TrayManager window
		4, 3,								// position
		owner->settings.trayIconSize,		// width of icon window
		owner->settings.trayIconSize,		// height of icon window
		pTrayWnd,							// parent window
		NULL,								// no menu
		dllInst,							// hInstance of DLL
		NULL);								// no window creation data
	
	if (!iconWnd) {
		// Could not create icon window
		MessageBox(parent, "Error creating window", szTrayIcon, MB_OK);
		return 1;
	}

	SetWindowLong(iconWnd, LS_GWL_CLASSPOINTER, (LONG)this);
	
	// If an icon is provided, copy it for use
	if (data->uFlags & NIF_ICON) {
		targetIcon = CopyIcon(data->hIcon);
	}
	SetWindowLong(iconWnd, GWL_USERDATA, (long)targetIcon);
	
	// add icon to our tray position it appropriately
	const LSTrayWindow &trayWindow =
		addToTray(
		iconWnd,			// icon window handle
		data->hWnd,			// target window handle
		targetMsg,			// callback message
		targetIcon,			// icon
		data->hIcon,		//
		data->uID,
		targetTip);
	SetWindowPos(iconWnd, 0, trayWindow.x, trayWindow.y, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	ShowWindow(iconWnd,SW_SHOWNORMAL);

	return 0;
}

int LSTrayWindowManager::modifyIcon(NOTIFYICONDATA *data)
{
	int i;
	BOOL need_to_pack_tray;
	RECT r;
	int targetMsg;
	HICON targetIcon;
	char targetTip[256]="";
	
	// stop now if "No Systray"
	if(owner->settings.fNoSystray) return 1;
	
	// Get the tray icon
	i = getTrayByWnd(data->hWnd);
	if (i < 0) return 1;

	need_to_pack_tray = FALSE;
	
	targetMsg = trayWnds[i].message;
	targetIcon = trayWnds[i].hIcon;
	
	// copy the tip (should be updated for Multibyte?)
	if (data->uFlags & NIF_TIP && trayWnds[i].szTip)
		strcpy(targetTip, trayWnds[i].szTip);
	
	// Copy callback message
	if (data->uFlags & NIF_MESSAGE && data->uCallbackMessage)
		targetMsg = data->uCallbackMessage;
	
	// Destroy the tray icon's HICON
	if (targetIcon != NULL && data->hIcon && data->uFlags & NIF_ICON)
		DestroyIcon(targetIcon);
	
	if (data->uFlags & NIF_ICON) {
		if ((targetIcon && !data->hIcon) || (!targetIcon && data->hIcon)) {
			// If the icon has been hidden or shown
			need_to_pack_tray = TRUE;
		}
	}
	
	// copy new icon
	if (data->uFlags & NIF_ICON && data->hIcon)
		targetIcon = CopyIcon(data->hIcon);
	
	// Copy new tip
	if (data->uFlags & NIF_TIP && data->szTip) {
		memset(targetTip, 0, sizeof(targetTip));
		if (owner->os_info.dwPlatformId == VER_PLATFORM_WIN32_NT) {
			WideCharToMultiByte (
				CP_ACP,
				0,
				(wchar_t *) data->szTip,
				wcslen ((wchar_t *) data->szTip),
				targetTip,
				sizeof (targetTip),
				NULL,
				NULL);
		} else {
			strcpy(targetTip, data->szTip);
		}
	}
	
	// Restore tray icon data
	trayWnds[i].message = targetMsg;
	/*if (trayWnds[i].hIcon)
	DestroyIcon(trayWnds[i].hIcon);*/
	trayWnds[i].hIcon = targetIcon;
	trayWnds[i].hOriginalIcon = data->hIcon;
	trayWnds[i].uID = data->uID;
	if (targetTip) strcpy(trayWnds[i].szTip, targetTip);
	SetWindowLong(trayWnds[i].trayWnd, GWL_USERDATA, (long)targetIcon);
	
	// pack if neccessary
	if (need_to_pack_tray) {
		i = packScreenTray();
	}
	
	// Invalidate old icon rectangle for repainting
	if (owner->settings.appBar) {
		r.top = trayWnds[i].y; r.bottom = trayWnds[i].y+owner->settings.trayIconSize; r.left = trayWnds[i].x; r.right = trayWnds[i].x+owner->settings.trayIconSize;
		InvalidateRect(hTrayWnd, &r, TRUE);
	} else {
		r.top = trayWnds[i].y; r.bottom = trayWnds[i].y+owner->settings.trayIconSize; r.left = trayWnds[i].x; r.right = trayWnds[i].x+owner->settings.trayIconSize;
		InvalidateRect(owner->hMainWnd, &r, TRUE);
	}
	
	// If there's a tip, have parent update tooltip list
	r.top = 0; r.bottom = owner->settings.trayIconSize; r.left = 0; r.right = owner->settings.trayIconSize;
	if (data->uFlags & NIF_TIP) {
		owner->toolTips->UpdateTooltip(trayWnds[i].trayWnd, trayWnds[i].szTip, &r);
	}
	
	// invalidate new icon rect for repainting
	InvalidateRect(trayWnds[i].trayWnd, &r, TRUE);

	return 0;
	// This part is commented out until we find why it conflicts with ICQ
	/*				case 0: // Forward settings.appBar
	{
	settings.appBarDATA *bDATA = (settings.appBarDATA *)d->lpData;
	int action = *(int*)(((char*)(d->lpData)) + 0x24);
	RECT *rm = (RECT *)*(int*)(((char *)d->lpData) + 0x28);
	switch (action)
	{
	case ABM_ACTIVATE:
	return TRUE;
	break;
	case ABM_GETsettings.autoHideBAR:
	return -1;
	break;
	case ABM_GETSTATE:
	return ABS_ALWAYSONTOP | settings.autoHide ? ABS_settings.autoHide : 0;
	break;
	case ABM_GETTASKBARPOS:
	if (!settings.appBar)
	return FALSE;
	else
	{
	RECT r;
	GetWindowRect(hBarWnd, &r);
	rm->left = 0;
	rm->top = r.top;
	rm->right = ScreenWidth;
	rm->bottom = ScreenHeight;
	return TRUE;
	}
	break;
	case ABM_NEW:
	if (userAppBar[sizeof (userAppBar)/sizeof(settings.appBarDATA)-1].hWnd || Issettings.appBar(bDATA->hWnd))
	return FALSE;
	else
	{
	addsettings.appBar(*bDATA, NULL);
	return TRUE;
	}
	break;
	case ABM_QUERYPOS:
	settings.appBarQueryPos(bDATA, rm, 1);
	return TRUE;
	break;
	case ABM_REMOVE:
	removesettings.appBar(bDATA->hWnd);
	organizesettings.appBars();
	return TRUE;
	break;
	case ABM_SETsettings.autoHideBAR:
	return TRUE;
	break;
	case ABM_SETPOS:
	settings.appBarQueryPos(bDATA, rm, 0);
	addsettings.appBar(*bDATA, rm);
	organizesettings.appBars();
	return TRUE;
	break;
	case ABM_WINDOWPOSCHANGED:
	if (!blocksettings.appBarRepos)
	{
	blocksettings.appBarRepos=TRUE;
	if (reorderWindows())
	DoEvents(2);
	blocksettings.appBarRepos=FALSE;
	}
	organizesettings.appBars();
	return TRUE;
	break;
	}
	}
	return TRUE;*/
}
