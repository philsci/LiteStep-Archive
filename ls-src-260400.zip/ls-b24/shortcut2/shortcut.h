#ifndef __SHORTCUT_H_
#define __SHORTCUT_H_

#pragma warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include <map>
#include "../lsapi/lswinbase.h"

using namespace std;


struct RegionImage
{
  HBITMAP image;
  HRGN region;
};


enum ShortcutState {ssNormal, ssHover, ssClick};


class Shortcut : public Window
{
protected:
  LPSTR caption;
  LPSTR command;
  LPSTR commandArgs;
  RegionImage* riCurrent;
  RegionImage riNormal;
  RegionImage riHover;
  RegionImage riClick;
  int left;
  int top;
  int relLeft;
  int relTop;
  int width;
  int height;
  ShortcutState state;
  Shortcut* next;
  bool changeZOrder;
  bool startHidden;
  bool startTopMost;
  UINT leaveTimer;

public:

  Shortcut(LPCSTR szConfigLine, DWORD& group);
  ~Shortcut();

  void append(Shortcut* shortcut);
  void setVisible(int visible = 0);

protected:
  DWORD parseConfig(LPCSTR szLine);
  void setImage(RegionImage& regionImage);
  void clear();

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onMouseMove(Message& message);
  void onMouseActivate(Message& message);
  void onTimer(Message& message);
  void onLButtonDown(Message& message);
  void onLButtonUp(Message& message);
  void onPaint(Message& message);
  void onDisplayChange(Message& message);
  void onWindowPosChanging(Message& message);
};


typedef map<UINT, Shortcut*> ShortcutMap;


class ShortcutFactory : public Window
{
protected:
  HWND shortcutHints;
  ShortcutMap shortcutGroups;

public:
  ShortcutFactory(ShortcutFactory*& self, HWND parentWnd, int& code);
  ~ShortcutFactory();

  void relayHintMessage(HWND hWnd, Message& message);
  void addHint(HWND hWnd, LPSTR caption);
  void removeHint(HWND hWnd);

protected:
  void createShortcuts();

  void setVisible(LPCSTR groups, int state);

  static void bangToggleGroup(HWND sender, LPCSTR args);
  static void bangShowGroup(HWND sender, LPCSTR args);
  static void bangHideGroup(HWND sender, LPCSTR args);

  virtual void windowProc(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onGetRevId(Message& message);
};


extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif

