// Represents the tray icons and the windows that contain them

#ifndef TRAYMANAGER
#define TRAYMANAGER

#include <vector>
#include <string>

#define TRAYMANAGER_CLASS "Shell_TrayWnd"
#define TRAYMANAGER_TITLE "Litestep Tray Manager"

using namespace std;

// data sent by shell via Shell_NotifyIcon -- Maduin
typedef struct SHELLTRAYDATA {
	DWORD dwUnknown;
	DWORD dwMessage;
	NOTIFYICONDATA nid;
} SHELLTRAYDATA, *PSHELLTRAYDATA, FAR *LPSHELLTRAYDATA;

typedef vector<NOTIFYICONDATA> NID_vector;

class LSBar;

int initModuleEx(HWND, HINSTANCE, LPCTSTR);
void quitModule(HINSTANCE);

class TrayManager {
	HINSTANCE dll;

	HWND hTrayWnd;
	NID_vector trayWnds;
	BOOL dontReleaseIcons;
	HWND lsWindow;
	string lsPath;

public:
	~TrayManager();
	TrayManager(HWND, HINSTANCE, LPCSTR);

	static LRESULT CALLBACK WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	void addTrayInfo(NOTIFYICONDATA*);
	void removeTrayInfo(NOTIFYICONDATA*);
	BOOL SystrayMessage( PSHELLTRAYDATA pstd );
	void modifyTrayInfo(NOTIFYICONDATA *data);
private:
	void restoreTrayIcons(void *src);
	void saveTrayIcons(void *dest);
};

#endif //!defined TRAYMANAGER