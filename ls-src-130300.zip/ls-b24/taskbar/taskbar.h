//   _     _ _           _
//  | |   (_) |_ ___ ___| |_ ___ _ __
//  | |   | | __/ _ Y __| __/ _ \ '_ \
//  | |___| | ||  __|__ \ ||  __/ |_) |
//  |_____|_|\__\___|___/\__\___| .__/
//                              |_|
//
//       module | taskbar
//      version | 1.0
//  description | display and manipulate running tasks
//       author | maduin <maduin@dasoft.org>
//      created | 21 feb 2000
//

#ifndef __TASKBAR_H
#define __TASKBAR_H

#include <vector>
using namespace std;

class Taskbar;
class TaskbarButton;
class TaskbarSkin;

class Taskbar
{
public:

	Taskbar();
	virtual ~Taskbar();

	void OnLoad( HINSTANCE );
	void OnUnload();

	void Invalidate( int, int, int, int );

	TaskbarButton *GetCapture();
	void SetCapture( TaskbarButton * );
	void ReleaseCapture();

	friend class TaskbarButton;

private:  // variables

	HWND hWnd;
	HINSTANCE hInstance;
	HWND hToolTips;

	int edge;
	int height;
	int width;

	int neededHeight;

	int screenHeight;
	int screenWidth;
	RECT prevDeskArea;

	BOOL active;
	BOOL autoHidden;
	BOOL mouseOver;
	TaskbarButton *capture;

	HWND hTray;
	int trayWidth;

	TaskbarSkin *skin;
	TaskbarSkin *buttonSkin;
	TaskbarSkin *activeButtonSkin;
	TaskbarSkin *traySkin;

	HFONT font;

	vector<TaskbarButton *> buttons;

private:  // functions

	TaskbarButton *ButtonAtPoint( int, int );
	void ReadConfig();
	void Layout();
	void SetWindowPosition();

	void Dock( HWND );
	void ApplyTraySkin( HDC, RECT & );

private:  // configuration variables

	BOOL autoHide;
	int autoHideDelay;

	BOOL stripTaskbar;

	BOOL msTaskbar;
	COLORREF foreColor1;
	COLORREF foreColor2;
	COLORREF backColor;
	COLORREF textColor;

	BOOL noSkinShift;
	BOOL noTextShift;

private:  // message handlers

	void OnActivate( BOOL );
	void OnDisplayChange();
	void OnLButtonDown( int, int );
	void OnLButtonUp( int, int );
	void OnMouseMove( int, int );
	void OnPaint( HDC );
	void OnRButtonDown( int, int );
	void OnRButtonUp( int, int );
	void OnSettingChange();
	void OnSize( int, int );
	void OnTimerAutoHide();
	void OnTimerUpdate();
	void OnWindowActivated( HWND );
	void OnWindowCreated( HWND );
	void OnWindowDestroyed( HWND );
	BOOL OnWindowMessage( UINT, WPARAM, LPARAM, LRESULT & );

private:  // statics

	static BOOL WINAPI EnumWindowsProc( HWND, LPARAM );
	static LRESULT WINAPI WndProc( HWND, UINT, WPARAM, LPARAM );
};

class TaskbarButton
{
public:

	TaskbarButton( Taskbar &, HWND );
	virtual ~TaskbarButton();

	BOOL HasPoint( int, int );
	void Move( int, int, int, int );

	void OnLButtonDown( int, int );
	void OnLButtonUp( int, int );
	void OnMouseMove( int, int );
	void OnPaint( HDC );
	void OnRButtonDown( int, int );
	void OnRButtonUp( int, int );
	void OnUpdate();

	inline HWND GetTask() { return hTask; }

private:

	HWND hTask;

	bool active;
	LPTSTR caption;
	HICON icon;

	BOOL mousePressed;
	BOOL mouseOver;

	int x;
	int y;
	int height;
	int width;

	Taskbar &container;

	LPTSTR GetCaption();
	HICON GetIcon();
};

class TaskbarSkin
{
public:

	TaskbarSkin( LPCTSTR, LPCTSTR, LPCTSTR );
	virtual ~TaskbarSkin();

	void Apply( HDC, int, int, int, int );

private:

	HBITMAP hbmLeft;
	int leftH;
	int leftW;

	HBITMAP hbmMiddle;
	int middleH;
	int middleW;

	HBITMAP hbmRight;
	int rightH;
	int rightW;
};

HICON GetIconFromWindow( HWND, BOOL );
BOOL IsAppWindow( HWND );

extern void (WINAPI *SwitchToThisWindow)( HWND, int );

#endif // __TASKBAR_H
