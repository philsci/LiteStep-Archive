//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by install3.rc
//
#define IDD_LICENSE                     106
#define IDD_ALLDONE                     107
#define IDD_INSTALL_SETTINGS            108
#define IDC_EDIT_AGREE                  1000
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_BUTTON3                     1005
#define IDC_BUTTON4                     1006
#define IDC_REBOOT                      1007
#define IDC_NOREBOOT                    1008
#define IDC_FINISH                      1009
#define IDC_EDIT1                       1010
#define IDC_EDIT2                       1011
#define IDC_EDIT3                       1012
#define IDC_COMBO1                      1013
#define IDC_BUTTON5                     1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
