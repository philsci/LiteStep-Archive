/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
06-04-00 Bobby G. Vinyard (Message)
  - Was registering for LM_GETREVID, didn't need to, removed
05/22/00 - Bobby G. Vinyard (Message)
  - Changed LM_ADDWINDOW & LM_REMOVEWINDOW to LM_WINDOWCREATED & 
     LM_WINDOWDESTROYED for compatiability with changes in hook
****************************************************************************/
// StandardWindowList.cpp: implementation of the StandardWindowList class.
//
//////////////////////////////////////////////////////////////////////

#include "StandardWindowList.h"
#include "../lsapi/lsapi.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StandardWindowList::StandardWindowList(HINSTANCE hInstance) {
	refCount = 0;

	//hWndParent = parent;
	this->hInstance = hInstance;

	UINT Msgs[3];
	WNDCLASSEX wc;
	
    // Register window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.cbClsExtra = 0;
   	wc.lpfnWndProc = StandardWindowList::WndProc;			// our window procedure
   	wc.hInstance = hInstance;							// hInstance of DLL
   	wc.lpszClassName = WINDOWLIST_CLASS;				// our window class name

   	if (!RegisterClassEx(&wc)) {
 		MessageBox(hWndParent, "Error registering window class", WINDOWLIST_CLASS, MB_OK | MB_TOPMOST);
   	}

	// Window
   	hWnd = CreateWindowEx(
		NULL,			// exstyles 
		WINDOWLIST_CLASS,			// our window class name
		WINDOWLIST_TITLE,			// use description for a window title
		NULL,					// styles
		0, 0,						// position 
		1, 1,						// width & height of window
		NULL,			// parent window 
		NULL,						// no menu
		hInstance,						// hInstance of DLL
		this);						// no window creation data
	if (!hWnd) {						   
		MessageBox(hWndParent,"Error creating window", WINDOWLIST_TITLE, MB_OK | MB_TOPMOST);
	}

	// Find LS main window
	HWND lsWindow = GetLitestepWnd();

	// Register rev id stuff
	Msgs[0] = LM_WINDOWCREATED;
	Msgs[1] = LM_WINDOWDESTROYED;
	Msgs[2] = 0;
	SendMessage(lsWindow, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)Msgs);

	// Register for shell messages (for LM_ADDWINDOW/LM_DELETEWINDOW)
	//HWND hookManagerWnd = ::FindWindow(TEXT("Hook Manager Window"), NULL);
	//SendMessage(hookManagerWnd, LM_REGISTERMESSAGE, (WPARAM)hWnd, 0);

	EnumWindows(StandardWindowList::EnumProc, (LPARAM)this);
}

StandardWindowList::~StandardWindowList()
{

}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StandardWindowList::QueryInterface(
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IWindowList) {
		*ppv = static_cast<IWindowList*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StandardWindowList::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StandardWindowList::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

/////////////////////////////////////////////////////////////////////////////
// From IWindowList
HRESULT STDMETHODCALLTYPE StandardWindowList::GetWindow( 
    /* [in] */ long index,
    /* [out] */ OLE_HANDLE __RPC_FAR *hwnd) {

	*hwnd = windowList[index];
	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardWindowList::FindWindow( 
    /* [in] */ OLE_HANDLE hwnd,
    /* [out] */ long __RPC_FAR *index) {

	for (size_t i = 0; i < windowList.size(); i++) {
		if (windowList[i] == hwnd) {
			*index = i;
			return S_OK;
		}
	}

	*index = -1;
	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardWindowList::GetWindowList( 
    /* [out] */ SAFEARRAY __RPC_FAR * list,
	/* [out] */ long * count) {

	long lower, upper;
  size_t size;

	if (SafeArrayGetDim(list) != 1) {
		// maybe something more descriptive
		return E_FAIL;
	}

	SafeArrayGetLBound(list, 1, &lower);
	SafeArrayGetUBound(list, 1, &upper);

	size = upper - lower;

	if (size > windowList.size()) {
		size = windowList.size();
	}

	long dim1;

	for (size_t i = 0; i <= size; i++) {
		dim1 = i + lower;
		SafeArrayPutElement(list, &dim1, &windowList[i]);
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardWindowList::GetWindowCount( 
    /* [out] */ long __RPC_FAR *count) {

	*count = windowList.size();
	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardWindowList::EnumerateWindows(ENUMPROC enumProc, LPARAM lParam, long *count) {
	size_t i;

	for (i = 0; i < windowList.size(); i++) {
		if (!enumProc(windowList[i], lParam)) break;
	}

	*count = i;

	return S_OK;
}

int CALLBACK StandardWindowList::EnumProc(HWND hwnd, LPARAM lParam) {
	StandardWindowList *wla = (StandardWindowList*)lParam;

	wla->AddWindow((OLE_HANDLE)hwnd);

	return TRUE;
}

LRESULT CALLBACK StandardWindowList::WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	StandardWindowList *standardWindowList;

	if (message == WM_CREATE) {
		standardWindowList = (StandardWindowList*)((LPCREATESTRUCT)lparam)->lpCreateParams;
		::SetWindowLong(hwnd, GWL_USERDATA, (LONG)standardWindowList);
	} else {
		standardWindowList = (StandardWindowList*)::GetWindowLong(hwnd, GWL_USERDATA);
	}

	if (standardWindowList) {
		return standardWindowList->WindowProc(hwnd, message, wparam, lparam);
	} else {
		return DefWindowProc(hwnd, message, wparam, lparam);
	}
}

LRESULT StandardWindowList::WindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	switch (message) {
  case LM_WINDOWCREATED:
		if (!InWinList((OLE_HANDLE)wparam)) {
			AddWindow((OLE_HANDLE)wparam);
			PostMessage(GetLitestepWnd(), LM_ADDWINDOW, wparam, 0);
		}
		return 0;
  case LM_WINDOWDESTROYED:
		if (InWinList((OLE_HANDLE)wparam)) {
			RemoveWindow((OLE_HANDLE)wparam);
			PostMessage(GetLitestepWnd(), LM_REMOVEWINDOW, wparam, 0);
		}
		return 0;
	default:
		return DefWindowProc(hwnd, message, wparam, lparam);
	}
}

void StandardWindowList::AddWindow(OLE_HANDLE hwnd)
{
	char clName[MAX_PATH];
	
	GetClassName((HWND)hwnd, clName, MAX_PATH);
	if (IsWindowVisible((HWND)hwnd) && !strstr(clName, "TWharfGlobalContainer")) {
		windowList.push_back(hwnd);
	}
}

void StandardWindowList::RemoveWindow(OLE_HANDLE hwnd)
{
	hwndVect::iterator iter;

	iter = windowList.begin();

	while (iter != windowList.end()) {
		if (*iter == hwnd) {
			windowList.erase(iter);
			break;
		}
		
		iter++;
	}
}

BOOL StandardWindowList::InWinList(OLE_HANDLE hwnd) {
	long i;

	FindWindow(hwnd, &i);

	if (i == -1) {
		return FALSE;
	} else {
		return TRUE;
	}
}

