// Desktop.dll - dummy module to inform users they need to load desktop2 instead

#include "../lsapi/lsapi.h"
#include "../core/ifcs.h"

//=========================================================
// Initialization and cleanup
//=========================================================

IModuleManager *g_mod_man;

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	ILitestep *litestep;

	litestep = (ILitestep*)SendMessage(GetLitestepWnd(), LM_GETLSOBJECT, 0, 0);

	MessageBox(NULL, "DESKTOP.DLL is no longer support in LiteStep 24.6.\n\nPlease edit your step.rc file and remove the LoadModule line for Desktop.dll.\nReplace it with LoadModule lines for Desktop2.dll and (optionally) Taskbar.dll and Systray2.dll.", "LiteStep 24.6", MB_OK | MB_TOPMOST | MB_ICONEXCLAMATION);

	litestep->GetModuleManager(&g_mod_man);
	g_mod_man->LoadModule(OLESTR("desktop2.dll"), NULL);

  return 0;
}


void quitModule(HINSTANCE dllInst)
{
  g_mod_man->QuitModule(OLESTR("desktop2.dll"));
}
