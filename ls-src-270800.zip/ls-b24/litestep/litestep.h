#ifndef __LITESTEP_H
#define __LITESTEP_H

#include "wharfdata.h"

void DoEvents(HWND hwnd, int n);

#define MAXWIN 200

typedef struct {
	HWND trayWnd;
	HWND tooltipWnd;
	HWND hWnd;
	int message;
	UINT uID;
	HICON hIcon;
	HICON hOriginalIcon;
	char szTip[256];
	int x,y;
	} trayType;

#endif	/* LITESTEP_H */
