// DLLModuleManager.cpp: implementation of the DLLModuleManager class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <comdef.h>

#include "DLLModuleManager.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/ThreadedBangCommand.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HANDLE DLLModuleManager::thread_event;
HANDLE DLLModuleManager::load_quit_event;

DLLModuleManager::DLLModuleManager(HWND hwnd, LPCTSTR appPath)
{
	thread_event = CreateEvent(NULL, FALSE, TRUE, "ThreadEvent");
	thread_event = CreateEvent(NULL, FALSE, TRUE, "LoadQuitEvent");

	this->appPath = _bstr_t(appPath);
	this->hMainWindow = hwnd;

	refCount = 0;
}

DLLModuleManager::~DLLModuleManager()
{
	QuitModules();
  CloseHandle(DLLModuleManager::thread_event);
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE DLLModuleManager::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IModuleManager) {
		*ppv = static_cast<IModuleManager*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE DLLModuleManager::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE DLLModuleManager::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

#define B24

////////////////////////////////////////////////////////////////////////////
// From IModuleManager
HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModules(int __RPC_FAR *count) {
	int myCount = 0;

#ifdef B24
	char buffer[4096];
	FILE *f;
	f = LCOpen (NULL);
	
	if (f) {
		while (LCReadNextCommand (f, buffer, sizeof (buffer))) {
			char *lpszBuffers[4];
			char token1[4096] = {0};
			char token2[4096] = {0};
			char token3[4096] = {0};
			char token4[4096] = {0};
			
			lpszBuffers[0] = token1;
			lpszBuffers[1] = token2;
			lpszBuffers[2] = token3;
			lpszBuffers[3] = token4;
			
			if (LCTokenize (buffer, lpszBuffers, 4, NULL) >= 2) {
				if (!stricmp (token1, "LoadModule")) {
					BOOL Add = TRUE;
					
					if (Add) {
						BOOL thread = FALSE;
						BOOL nopump = FALSE;
						int flags = 0;
						
						thread = strcmpi(token3, "threaded") == 0;
						if (!thread) {
							thread = strcmpi(token4, "threaded") == 0;
						}
						if (thread) {
							flags |= MODULE_THREADED;
							nopump = strcmpi(token4, "nopump") == 0;
							if (!nopump) {
								nopump = strcmpi(token3, "nopump") == 0;
							}
							if (nopump) {
								flags |= MODULE_NOTPUMPED;
							}
						}

						_bstr_t mystr(token2);
						LoadModule(mystr, flags);
						myCount++;
					}
				}
			}
		}
		LCClose (f);
	}

#else // new version using new settings
	for (int i = 0; i < 6; i++) {
		LoadModule(modules[i]);
	}
#endif // B24

	if (count) {
		*count = myCount;
	}

	return S_OK;
}


HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModule(BSTR location, int flags) {
	// We're in the process of loading all modules,
	// make sure nobody is trying to do the same.
	WaitForSingleObject(DLLModuleManager::load_quit_event, INFINITE);

	DLLModule* dllMod = NULL;
	
	if (dllModuleMap.find(wstring(location)) != dllModuleMap.end()) {
		return E_FAIL; // need message saying already loaded
	}

	try {
		int WARNING; // need to do threading stuff
		dllMod = new DLLModule(location, flags & MODULE_THREADED, !(flags & MODULE_NOTPUMPED));
	} catch (int error) {
		switch (error) {
		case BAD_MODULE:
			MessageBox(NULL, "Error: Could not locate module.\nPlease check your configuration.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			break;
		case BAD_INIT:
			MessageBox(NULL, "Error: Could not find initModuleEx().\n\nPlease confirm that the dll is a Litestep module,\nand check with the author for updates.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			break;
		case BAD_QUIT:
			MessageBox(NULL, "Error: Could not find quitModule().\n\nPlease conirm that the dll is a Litestep module.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			break;
		}

		delete dllMod;
		return E_FAIL;
	}

	dllModuleMap[wstring(location)] = dllMod;
	try {
		dllMod->Init(hMainWindow, appPath);
	} catch (...) {
		MessageBox(NULL, "Error: Exception during module initialization.\n\nPlease contact the module writer.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		dllModuleMap.erase(dllModuleMap.find(wstring(location)));
		return E_FAIL;
	}

	// signal the event
	SetEvent(DLLModuleManager::load_quit_event);

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModules(void) {
	wstring2module::iterator iter;

	iter = dllModuleMap.begin();

	while (iter != dllModuleMap.end()) {
		if (iter->second) {
			try {
				iter->second->Quit();
				delete iter->second;
			} catch (...) {
				// quietly swallow exceptions
				// debugging/logging code should go here
			}
		}

		iter++;
	}

	dllModuleMap.clear();

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModule(BSTR location) {
	// We're in the process of loading all modules,
	// make sure nobody is trying to do the same.
	WaitForSingleObject(DLLModuleManager::load_quit_event, INFINITE);

	DLLModule* dllMod;

	if (location != NULL) {
		wstring newLoc = wstring(location);
		if (dllModuleMap.find(newLoc) != dllModuleMap.end()) {
			dllMod = dllModuleMap[newLoc];

			try {
				dllMod->Quit();
				delete dllMod;
			} catch (...) {
				// Quietly swallow exceptions
				// debugging/logging code should go here
			}

			dllModuleMap.erase(newLoc);
		}
	}

	SetEvent(DLLModuleManager::load_quit_event);

	return S_OK;
}
        
HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleList(SAFEARRAY __RPC_FAR * strlist, int __RPC_FAR *count) {
	long lBound;
	long uBound;
	long size;
  int i;

	BSTR *outList;

	SafeArrayGetLBound(strlist, 1, &lBound);
	SafeArrayGetUBound(strlist, 1, &uBound);

	size = uBound - lBound + 1;

	SafeArrayAccessData(strlist, (void**)&outList);

	wstring2module::iterator iter = dllModuleMap.begin();
	for (i = 0; i < size && iter != dllModuleMap.end(); i++, iter++) {
		outList[i] = SysAllocString(iter->first.c_str());
	}

	SafeArrayUnaccessData(strlist);

	*count = i;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleCount(int __RPC_FAR *count) {
	*count = dllModuleMap.size();

	return S_OK;
}

//////////////////////////////////////////////////////////
// DLLModule class
DLLModule::DLLModule(BSTR loc, BOOL isThreaded, BOOL isPumped) {
	location = loc;
	hThread = NULL;
	pInitEx = NULL;
	pQuit = NULL;
	threaded = isThreaded;
	pumped = isPumped;

	hInstance = LoadLibrary(_bstr_t(location.c_str()));

	if(hInstance) {
		pInitEx = (ModuleInitExFunc)GetProcAddress(hInstance, TEXT("initModuleEx"));
		if (!pInitEx) // Might be a BC module, check for underscore
		  pInitEx = (ModuleInitExFunc)GetProcAddress(hInstance, TEXT("_initModuleEx"));
		  
		pQuit = (ModuleQuitFunc)GetProcAddress(hInstance, TEXT("quitModule"));
		if (!pQuit)   // Might be a BC module, check for underscore
  		pQuit = (ModuleQuitFunc)GetProcAddress(hInstance, TEXT("_quitModule"));

		if (!pInitEx) {
			throw BAD_INIT;
		}

		if (!pQuit) {
			throw BAD_INIT;
		}
	} else {
		throw BAD_MODULE;
	}
}

DLLModule::~DLLModule() {
	if (hInstance) {
		FreeLibrary(hInstance);
		hInstance = 0;
	}
}

void DLLModule::Init(HWND hMainWindow, wstring theAppPath) {
	if (hInstance) {
		if (pInitEx) {
			mainWindow = hMainWindow;
			appPath = theAppPath;

			if (threaded) {
				SECURITY_ATTRIBUTES sa;

				sa.nLength = sizeof(SECURITY_ATTRIBUTES);
				sa.lpSecurityDescriptor = NULL;
				sa.bInheritHandle = FALSE;

				CreateThread(&sa, 0, DLLModule::ThreadProc, this, NULL, (ULONG*)&hThread);
				WaitForThread(LM_THREADREADY);
			} else {
				CallInit();
			}
		}
	}
}

ULONG DLLModule::CallInit() {
	try {
		pInitEx(mainWindow, hInstance, _bstr_t(appPath.c_str()));
	} catch (...) {
		FreeLibrary(hInstance);
		hInstance = NULL;

		return -1;
	}

	return 0;
}

ULONG __stdcall DLLModule::ThreadProc(void* dllModPtr) {
	DLLModule* dllMod = (DLLModule*)dllModPtr;

  // Make sure modules load sequentially, and one at a time, to prevent dependency problems
	//WaitForSingleObject(DLLModuleManager::thread_event, INFINITE);

	dllMod->CallInit();
	PostMessage(GetLitestepWnd(), LM_THREADREADY, NULL, NULL);
	
	//SetEvent(DLLModuleManager::thread_event);

	if (dllMod->pumped) {
		WNDCLASS wndclass;

		memset(&wndclass, 0, sizeof(WNDCLASS));

		wndclass.lpfnWndProc = DLLModule::ThreadWndProc;
		wndclass.hInstance = dllMod->GetInstance();
		wndclass.lpszClassName = "LSThreadWnd";

		RegisterClass(&wndclass);

		// create thread handler window
		dllMod->hThreadWnd = CreateWindow(
			"LSThreadWnd",
			"Litestep Thread Handler Window",
			WS_CHILD,
			0,
			0,
			0,
			0,
			GetLitestepWnd(),
			NULL,
			dllMod->GetInstance(),
			(void*)dllMod);

		MSG msg;

		while (GetMessage(&msg, 0, 0, 0)) {
			try {
				if (msg.hwnd == NULL) {
					// Thread message
					dllMod->HandleThreadMessage(msg);
				} else {
					// Window message
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			} catch (...) {
				// Quietly ignore exceptions?
				int WARNING; // Need stronger exception-handling code here...restart the module or something
			}
		}
	}

	PostMessage(GetLitestepWnd(), LM_THREADFINISHED, 0, 0);

	return 0;
}

HRESULT WINAPI DLLModule::ThreadWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	DLLModule *dll_mod = NULL;

	if (message == WM_CREATE) {
		dll_mod = (DLLModule*)((LPCREATESTRUCT)lParam)->lpCreateParams;
		SetWindowLong(hwnd, GWL_USERDATA, (LONG)dll_mod);
	} else {
		dll_mod = (DLLModule*)GetWindowLong(hwnd, GWL_USERDATA);
	}

	switch (message) {
		case WM_DESTROY:
			try {
				dll_mod->GetQuit()(dll_mod->GetInstance());
			} catch (...) {
				MessageBox(NULL, "Exception while quitting module.", _bstr_t(dll_mod->location.c_str()), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
      }

			PostQuitMessage(0);
			return 0;
	}

	return DefWindowProc(hwnd, message, wParam, lParam);
}

void DLLModule::Quit() {
	if (hInstance) {
		if (hThread) {
			PostMessage(hThreadWnd, WM_DESTROY, 0, 0);
			WaitForThread(LM_THREADFINISHED);
		} else {
			if (pQuit) {
				try {
					pQuit(hInstance);
				} catch (...) {
					MessageBox(NULL, "Exception while quitting module.", _bstr_t(location.c_str()), MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
				}
			}
		}
	}
}

HINSTANCE DLLModule::GetInstance() {
	return hInstance;
}

HANDLE DLLModule::GetThread() {
	return hThread;
}

wstring DLLModule::GetLocation() {
	return location;
}

ModuleInitExFunc DLLModule::GetInitEx() {
	return pInitEx;
}

ModuleQuitFunc DLLModule::GetQuit() {
	return pQuit;
}

void DLLModule::HandleThreadMessage(MSG &msg)
{
	switch (msg.message) {
		case LM_THREAD_BANGCOMMAND:
			BangCommandInfo *bang_info = (BangCommandInfo*)msg.wParam;

			bang_info->bang->Execute(bang_info->caller, bang_info->params, bang_info->result);

		break;
	}
}

void DLLModule::WaitForThread(DWORD thread_msg)
{
	MSG msg;

	while (GetMessage(&msg, 0, 0, 0)) {
		if (msg.message == thread_msg)
			break;

		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}
