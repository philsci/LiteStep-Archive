// MessageManager.h: interface for the MessageManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESSAGEMANAGER_H__F9FA4B17_D0F0_4688_B20A_2186B810544C__INCLUDED_)
#define AFX_MESSAGEMANAGER_H__F9FA4B17_D0F0_4688_B20A_2186B810544C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
#include <set>

using namespace std;

class MessageManager  
{
	typedef set<HWND> windowSet;
	typedef map<UINT, windowSet* > messageMap;

	messageMap msgMap;

public:
	MessageManager();
	virtual ~MessageManager();

	// [Message Handler Code]
	BOOL HandlerExists(UINT uMsg);
	HRESULT PassOnMessage(UINT Msg, WPARAM wParam, LPARAM lParam, BOOL wait);
	void AddMessages(HWND hwnd, UINT* Msg);
	void RemoveMessages(HWND hwnd, UINT* Msg);
	void ClearMessages();

protected:
	void AddWndMessage(HWND hwnd, UINT Message);
	void RemoveWndMessage(HWND hwnd, UINT Message);

};

#endif // !defined(AFX_MESSAGEMANAGER_H__F9FA4B17_D0F0_4688_B20A_2186B810544C__INCLUDED_)
