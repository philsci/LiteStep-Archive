/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05/15/00 Gustav Munkby (grd)
  Started rewriting the Virtual Window Manager from scratch.
****************************************************************************/

#include "vwm.h"

const char szAppName[] = "VirtualWindowManager"; // Our window class, etc

const char rcsRevision[] = "$Revision: 1.1.2.1 $"; // Our Version
const char rcsId[] = "$Id: vwm.cpp,v 1.1.2.1 2000/07/11 15:41:17 grd Exp $"; // The Full RCS ID.

VWM *vwm; // The module


//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  int code;
  Window::init(dllInst);
  vwm = new VWM(ParentWnd, code);
  return code;
}
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, void *wharfData)
{
  int code;
  Window::init(dllInst);
  vwm = new VWM(ParentWnd, code);
  return code;
}
void quitModule(HINSTANCE dllInst)
{
  delete vwm;
}
void quitWharfModule(HINSTANCE dllInst)
{
  delete vwm;
}

//=========================================================
// Bang commands
//=========================================================

void bangGather(HWND caller , LPCSTR args)
{
	vwm->gather();
}
void bangUp(HWND sender, LPCSTR args)
{
	vwm->switchDeskUp();
}
void bangDown(HWND sender, LPCSTR args)
{
	vwm->switchDeskDown();
}
void bangLeft(HWND sender, LPCSTR args)
{
	vwm->switchDeskLeft();
}
void bangRight(HWND sender, LPCSTR args)
{
	vwm->switchDeskRight();
}
void bangDesk(HWND sender, LPCSTR args)
{
	vwm->switchDesk(atoi(args));
}
void bangToggle(HWND sender, LPCSTR args)
{
	vwm->toggle();
}
void bangShow(HWND sender, LPCSTR args)
{
	vwm->show();
}
void bangHide(HWND sender, LPCSTR args)
{
	vwm->hide();
}
void bangOpen(HWND sender, LPCSTR args)
{
	char ndesk[MAX_LINE_LENGTH], cmd[MAX_LINE_LENGTH];
	char *tokens[1] = {ndesk};
	LCTokenize( args, tokens, 1, cmd );
	vwm->open(atoi(ndesk),cmd);
}
void bangReset(HWND sender, LPCSTR args)
{
	vwm->reset();
}
void bangMoveApp(HWND sender, LPCSTR args)
{
	vwm->moveApp((char *)args);
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
VWM::VWM(HWND parentWnd, int& code):
Window(szAppName)
{

	// reading settings for window creation
  // ======================================

  // get ls window handle
  liteStep = GetLitestepWnd();
	deskTop = FindWindow("DesktopBackgroundClass", NULL);
	if (!deskTop)
		deskTop = GetDesktopWindow();

  // if the parent window is not litestep, it must be the wharf
  inWharf  = ( parentWnd != liteStep );

	// get the position and size of the main window
	// using different method if it's docked in the wharf
  if ( inWharf )
  {
		RECT rc;
	  int  wharfBorder;
	  
	  // get the wharf window size
	  GetClientRect( parentWnd, &rc );
	  wharfBorder = GetRCInt( "Wharf???", 0 );

	  vwmX = wharfBorder;
	  vwmY = wharfBorder;
	  vwmWidth = rc.right - 2 * wharfBorder;
	  vwmHeight = rc.bottom - 2 * wharfBorder;
  }
  else
  {
		vwmX = GetRCInt( "vwmX", 0 );
		if ( vwmX < 0 )
			vwmX += GetSystemMetrics(SM_CXSCREEN);
	  vwmY = GetRCInt( "vwmY", 0 );
		if ( vwmY < 0 )
			vwmY += GetSystemMetrics(SM_CYSCREEN);
	  vwmWidth = GetRCInt( "vwmWidth", 64 );
	  vwmHeight = GetRCInt( "vwmHeight", 64 );
  }
  
  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, inWharf ? WS_CHILD : WS_POPUP,
										vwmX, vwmY, vwmWidth, vwmHeight, inWharf ? parentWnd : deskTop))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  code = 0;
}


VWM::~VWM()
{
  destroyWindow();
}

//=========================================================
// various functions
//=========================================================

int VWM::getDeskId( int x, int y )
{
	return (y-1)*desksX + x;
}

void VWM::setCurrentDesk( int id )
{
	currentDesk = id;
	currentDeskX = currentDesk % desksX;
	if ( currentDeskX == 0 )
		currentDeskX = desksX;
	currentDeskY = (currentDesk - currentDeskX) / desksX + 1;
}

void VWM::setScreenSize( int cx, int cy )
{
	screenWidth = cx;
	screenHeight = cy;
	modToVWMX = (float)vwmWidth/((float)(screenWidth+10)*(float)desksX - 10);
	modToVWMY = (float)vwmHeight/((float)(screenHeight+10)*(float)desksY - 10);
}

void VWM::getShifts(int newDesk, int *cx, int *cy)
{
	int newDeskX = newDesk % desksX;
	if ( newDeskX == 0 )
		newDeskX = desksX;
	int deskShiftX = newDeskX - currentDeskX;
	int deskShiftY = (newDesk - currentDesk - deskShiftX) / desksX;
	*cx = deskShiftX * (screenWidth+10);
	*cy = deskShiftY * (screenHeight+10);
}

int VWM::getDeskFromWnd(HWND window)
{
	wRECTMap::iterator it = rectMap.find(window);
	if ( it!=rectMap.end() )
	{
		int x, y;
		POINT pt;
		char buffer2[MAX_LINE_LENGTH];

		// get a hotspot, to find the desktop from...
		pt.x = it->second.win.left + (it->second.win.right - it->second.win.left) / 10;
		pt.y = it->second.win.top + (it->second.win.bottom - it->second.win.top) / 10;

		// get the new desktop
		x = currentDeskX + (int)((float)pt.x/(float)screenWidth);
		y = currentDeskY + (int)((float)pt.y/(float)screenHeight);

		sprintf( buffer2, "id: %d\nx: %d\ny: %d\n",getDeskId(x,y), x, y );
		OutputDebugString( buffer2 );

		return getDeskId(x,y);
	}
	return 0;
}
void VWM::switchDesk(int newDesk)
{
  wRECTMap::iterator it;
	char buffer[256];
	int cx, cy;

	if ( newDesk == currentDesk )
		return;

	getShifts(newDesk, &cx, &cy);

  it = rectMap.begin();
  while (it != rectMap.end())
  {
		if ( GetWindowText(it->first, buffer, 255) )
    {
	    for( int j = 0; j < stickyWindows.size(); j++ )
	    {
		    if (!stricmp(buffer, stickyWindows[j].c_str()))
			    continue;
	    }
    }

    it->second.win.left   -= cx;
    it->second.win.right  -= cx;
    it->second.win.top    -= cy;
    it->second.win.bottom -= cy;

	  SetWindowPos(it->first, NULL, it->second.win.left, it->second.win.top, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);

    it++;
	}
	setCurrentDesk(newDesk);

	onSwitchExec();
	setWallpaper();

	if (focusCenter)
	{
		POINT p;
		p.x = screenWidth/2;
		p.y = screenHeight/2;
		SetForegroundWindow(WindowFromPoint(p));
	}

}

void VWM::setWallpaper(void)
{
	deskMap::iterator it = wallPapers.find(currentDesk);

	if ( it != wallPapers.end() )
		SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, (PVOID)(it->second.c_str()),	SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
}

void VWM::onSwitchExec(void)
{
	deskMap::iterator it = onSwitch.find(currentDesk);

	if ( it != onSwitch.end() )
		LSExecute( NULL, it->second.c_str(), SW_SHOWNORMAL );
}

//=========================================================
// Registered messages
//=========================================================

void VWM::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate,            WM_CREATE)
    MESSAGE(onDestroy,           WM_DESTROY)
    MESSAGE(onDisplayChange,     WM_DISPLAYCHANGE)
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
    MESSAGE(onKeyMessage,        WM_KEYDOWN)
    MESSAGE(onKeyMessage,        WM_KEYUP)
    MESSAGE(onKeyMessage,        WM_HOTKEY)
    MESSAGE(onMouseButtonDown,   WM_LBUTTONDOWN)
    MESSAGE(onMouseButtonDown,   WM_MBUTTONDOWN)
    MESSAGE(onMouseButtonDown,   WM_RBUTTONDOWN)
    MESSAGE(onMouseButtonUp,     WM_LBUTTONUP)
    MESSAGE(onMouseButtonUp,     WM_MBUTTONUP)
    MESSAGE(onMouseButtonUp,     WM_RBUTTONUP)
    MESSAGE(onMouseMove,         WM_MOUSEMOVE)
    MESSAGE(onPaint,             WM_PAINT)
    MESSAGE(onPaint,             LM_REPAINT)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
	  MESSAGE(onWindowActivated,   LM_WINDOWACTIVATED)
    MESSAGE(onTimer,             WM_TIMER)
		MESSAGE(onDropFiles,         WM_DROPFILES)
		MESSAGE(onVWMPosChanging,    WM_WINDOWPOSCHANGING)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void VWM::onCreate(Message& message)
{
  char szTemp[MAX_LINE_LENGTH];
  int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, 0};

	// register messages
  SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// has to be done
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	// load settings here
	// ===========================================
	gatherOnRecycle   = GetRCBool("vwmNoGathering", FALSE);
	switchOnFocus     = GetRCBool("vwmNoSwitchOnFocus", FALSE);
	focusCenter       = GetRCBool("vwmFocusCenter", TRUE);
	visible           = inWharf || GetRCBool("vwmHidden", FALSE); // renamed from vwmNoShow
	onTop             = !inWharf && GetRCBool("vwmNotAlwaysOnTop", FALSE);
	movable           = inWharf && GetRCBool("vwmNoMove", FALSE);
	autoHideDistance  = (inWharf && GetRCBool("vwmAutoHide", TRUE)) ? GetRCInt("vwmAutoHideDistance", 10) : 0;
	snapDistance      = GetRCInt("vwmSnapDistance", 10);
	titlebarsMod      = (GetRCBool("vwmTitlebars", TRUE)) ? GetRCInt("vwmTitlebarMod", 16) : 0;
	autoSwitchDistance= GetRCBool("vwmAutoSwitch", TRUE) ? GetRCInt("vwmAutoSwitchDistance", 10) : 0;
	autoSwitchDelay   = GetRCInt("vwmAutoSwitchDelay", 50);
  // interesting method (for the following two settings )
  iconSize        = (GetRCBool("vwmIcons", TRUE)) ? GetRCInt("vwmIconSize", 16) : 0;
	initialDesk     = GetRCInt("vwmInitialDesk", 1);
 	desksX          = GetRCInt("vwmDesksX", 2);
	desksY          = GetRCInt("vwmDesksY", 2);

  // is this necessary?
  desks           = desksX * desksY;
	
	mouseLeft       = GetRCInt("vwmMouseLeft", 2);
	mouseRight      = GetRCInt("vwmMouseRight", 1);
	mouseMiddle     = GetRCInt("vwmMouseMiddle", 0);

  // layout settings:
  // ================
	clrWin          = GetRCColor("vwmWinColor", 0xffffff);
	clrBack         = GetRCColor("vwmBackColor", 0x808080);
	clrSel          = GetRCColor("vwmSelBackColor", 0x404040);
	clrFore         = GetRCColor("vwmForeColor", 0xffffff);
	clrBorder       = GetRCColor("vwmBorderColor", 0x000000);

  // bitmaps
	// =======
	// hbmBack gets it's content further down, in paint background
	GetRCString("vwmSelBmp", szTemp, ".none", 256);
  hbmSel = LoadLSImage(szTemp, NULL);
	GetRCString("vwmWinBmp", szTemp, ".none", 256);
  hbmWin = LoadLSImage(szTemp, NULL);
	GetRCString("vwmTitlebarBmp", szTemp, ".none", 256);
  hbmTitle = LoadLSImage(szTemp, NULL);

	// get the main window dc ( and preload an compatible dc in memory )
  {
    HDC hdc = GetDC(hWnd);
	  hdcMem = CreateCompatibleDC(hdc);
		hdcMemBuffer = CreateCompatibleDC(hdc);
	  hbmMem = CreateCompatibleBitmap(hdc,vwmWidth,vwmHeight);
	  ReleaseDC(hWnd, hdc);
	  hbmMemOld = (HBITMAP)SelectObject(hdcMem,hbmMem);
  }

	paintBackground();

  // get sticky windows:
  // ===================
	{
		FILE *f;
		char buffer[MAX_LINE_LENGTH];
	
		f = LCOpen(NULL);
		if (f)
    {
			while (LCReadNextConfig (f, "*vwmSticky", buffer, MAX_LINE_LENGTH))
			{
				char token1[MAX_LINE_LENGTH];
        char *tokens[1] = { token1 };

				LCTokenize ((char *)(buffer+11), tokens, 1, NULL);

        if ( token1 && *token1 )
				  stickyWindows.push_back(token1);
			}
			LCClose(f);
		}
	}

  // get commands on switch
  // these will be changed into maps instead...
  for( int i = 1; i <= desks; i++ )
	{
		char config[32];
		char buffer[MAX_LINE_LENGTH];

    // get the exec command
		sprintf( config, "vwmOnSwitchTo%d", i );
		GetRCLine( config, buffer, MAX_LINE_LENGTH, "" );
		if( *buffer )
      onSwitch.insert( deskMap::value_type(i, buffer) );

    // get the wallpaper
		sprintf( config, "vwmDeskWallpaper%d", i );
		GetRCLine( config, buffer, MAX_LINE_LENGTH, "" );
		if( *buffer )
      wallPapers.insert( deskMap::value_type(i, buffer) );
	}

	// add bangs here
	// ============================================
	// gather windows
	AddBangCommand("!vwmGather", bangGather);
	// move to specified desk
	AddBangCommand("!vwmUp",     bangUp);
	AddBangCommand("!vwmDown",   bangDown);
	AddBangCommand("!vwmLeft",   bangLeft);
	AddBangCommand("!vwmRight",  bangRight);
	AddBangCommand("!vwmDesk",   bangDesk);
  // show/hide
	AddBangCommand("!vwmShow",   bangShow);
	AddBangCommand("!vwmHide",   bangHide);
	AddBangCommand("!vwmToggle", bangToggle);
	AddBangCommand("!vwmRollUp", bangToggle);
	// start command on specific desk
	AddBangCommand("!vwmOpen",   bangOpen);
	// reset?
	AddBangCommand("!vwmReset",  bangReset);
	// move (current) app to another desk
	AddBangCommand("!vwmMoveApp",bangMoveApp);


  // finnish of the creation proc here
	// ============================================

  setScreenSize( GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN) );

  setCurrentDesk(1); // this is so that the vars get initialized and nothing is screwed up...

  winListInit();

  // set the initial desk
	switchDesk( min(max(initialDesk,0),desks) );

	// wait with this
	DragAcceptFiles(hWnd, TRUE);
	
	if (onTop)
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
	
  if (visible)
	{
		if (autoHideDistance)
		{
			// if it's at the edge of the screen
			if ((vwmX==0) || (vwmY==0) || (vwmX+vwmWidth==screenWidth) || (vwmY+vwmHeight==screenHeight))
			{
				POINT pt;
				GetCursorPos(&pt);
				if ((pt.x<vwmX) || (pt.x>vwmX+vwmWidth) || (pt.y<vwmY) || (pt.y>vwmY+vwmHeight))
					visible = FALSE;
			}
		}
	}
	ShowWindow( hWnd, (visible)?SW_SHOWNORMAL:SW_HIDE );

	// set a timer??? (would like to replace this with a hook...)
	SetTimer(hWnd, 1, 500, NULL);

  // setting a hook to catch WM_WINDOWPOSCHANGED messages
  /*{
    HWND hHookMgrWnd = FindWindow("HookMgrClass", NULL);
    SendMessage( hHookMgrWnd, LM_REGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)hookWindowPosChangedProc );
  }*/
}


void VWM::onDestroy(Message& message)
{
  int msgs[] = {LM_GETREVID, LM_BRINGTOFRONT, LM_SWITCHTON, LM_WINDOWACTIVATED, 0};

  SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

  //unregister the window hook
  /*{
    HWND hHookMgrWnd = FindWindow("HookMgrClass", NULL);
    SendMessage(hHookMgrWnd, LM_UNREGISTERMESSAGE, (WPARAM)WM_WINDOWPOSCHANGED, (LPARAM)NULL);
  }*/

	// remove bangs here
	// ============================================
	// gather windows
	RemoveBangCommand("!vwmGather");
	// move to specified desk
	RemoveBangCommand("!vwmUp");
	RemoveBangCommand("!vwmDown");
	RemoveBangCommand("!vwmLeft");
	RemoveBangCommand("!vwmRight");
	RemoveBangCommand("!vwmDesk");
  // show/hide
	RemoveBangCommand("!vwmShow");
	RemoveBangCommand("!vwmHide");
	RemoveBangCommand("!vwmToggle");
	RemoveBangCommand("!vwmRollUp");
	// start command on specific desk
	RemoveBangCommand("!vwmOpen");
	// reset?
	RemoveBangCommand("!vwmReset");
	// move (current) app to another desk
	RemoveBangCommand("!vwmMoveApp");

	// change the current window... to now lose window positions
	switchDesk(1);
  // what should be done is that the current window should be saved,
  // so that it'd be possible to use on startup of the module

  destroyWindow();

  winList.clear();
  rectMap.clear();
  
	// finnish of the destruction proc here
	// ============================================
	SelectObject( hdcMem, hbmMemOld );
	DeleteObject( hbmMem );
	DeleteDC( hdcMem );
	DeleteDC( hdcMemBuffer );

	DeleteObject( hbmBack );
	DeleteObject( hbmSel );
	DeleteObject( hbmWin );
	DeleteObject( hbmTitle );
}

void VWM::onDisplayChange(Message& message)
{
	setScreenSize( message.lParamLo, message.lParamHi );
  // adjust the desks to the new window size
}

void VWM::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void VWM::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "vwm.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}

void VWM::onKeyMessage(Message& message)
{
  // Forward these messages
  PostMessage(hParent, message.uMsg, message.wParam, message.lParam);
}

void VWM::onMouseButtonDown(Message& message)
{
  int click = 0;
  switch (message.uMsg)
  {
    case WM_LBUTTONDOWN:
      click = mouseLeft;
      break;
    case WM_MBUTTONDOWN:
      click = mouseMiddle;
      break;
    case WM_RBUTTONDOWN:
      click = mouseRight;
      break;
    default:
      return;
  }
  switch (click)
  {
    case 0:
      break;

    case 1: // select desktop
			{ // get the position in the window, and get the desk from that
				int newDeskX = (desksX * message.lParamLo) / vwmWidth + 1;
				int newDeskY = (desksY * message.lParamHi) / vwmHeight + 1;

				if ( ( newDeskX <= desksX ) && ( newDeskY <= desksY ) ) //&& !( (newDeskX==currentDeskX) && (newDeskY==currentDeskY) ) )
				{
					switchDesk( getDeskId( newDeskX, newDeskY ) );
					InvalidateRect(hWnd, NULL, TRUE );
				}
			}
			break;

    case 2: // move window 
			{ // diffPt && hSelectedWnd needs to be "saved"
				windowVector::iterator it = winList.begin();
				wRECTMap::iterator itMap;
				POINT pt;
				
				// the point on the vwm
				pt.x = message.lParamLo;
				pt.y = message.lParamHi;
      
				// find the window under the pointer
				while ( it!=winList.end() )
				{
					itMap = rectMap.find(*it);
					if ( itMap != rectMap.end() )
					{
						if ( PtInRect( &(itMap->second.vwm), pt ) )
						{
							hSelectedWnd = *it;			    		
							break;
						}
					}
					it++;
				}

				// if no window was found, then the selected window is the main window
				if (!hSelectedWnd)
				{
   				message.lResult = SendMessage(hWnd, WM_SYSCOMMAND, SC_MOVE|2, message.lParam );
					return;
				}

				if (!(GetWindowLong(hSelectedWnd, GWL_STYLE) & WS_MAXIMIZE))
				{
					// get the distance between the "click-mark" and the topleft corner
					diffPt.x = pt.x - itMap->second.vwm.left;
					diffPt.y = pt.y - itMap->second.vwm.top;
				}
				SetCapture(hWnd);
			}
			break;
  }
}

void VWM::onMouseButtonUp(Message& message)
{
  int click = 0;
  switch (message.uMsg)
  {
    case WM_LBUTTONUP:
      click = mouseLeft;
      break;
    case WM_MBUTTONUP:
      click = mouseMiddle;
      break;
    case WM_RBUTTONUP:
      click = mouseRight;
      break;
    default:
      break;
  }
  switch (click)
  {
    case 0:
    case 1: // select desktop
      break;
		case 2:
	  {
			if (hSelectedWnd)
			{
				if (ReleaseCapture())
					hSelectedWnd = NULL;
			}
		}
	}
}

void VWM::onMouseMove(Message& message)
{
  if (hSelectedWnd)
  {
		wRECTMap::iterator it = rectMap.find(hSelectedWnd);
		if ( it!=rectMap.end() )
		{
			int cx = 0, cy = 0;

			if (GetWindowLong(hSelectedWnd, GWL_STYLE) & WS_MAXIMIZE)
			{
				int width = it->second.win.right - it->second.win.left;
				int height = it->second.win.bottom - it->second.win.top;

				int mouseoverDeskX = ( ( desksX * message.lParamLo ) / vwmWidth ) + 1;
				int mouseoverDeskY = ( ( desksY * message.lParamHi ) / vwmHeight ) + 1;
				// we don't want to be able to drag the window outside our window
				mouseoverDeskX = min( max( mouseoverDeskX , 1 ) , desksX );
				mouseoverDeskY = min( max( mouseoverDeskY , 1 ) , desksY );

				while (it->second.win.left + cx > screenWidth)
					cx -= (screenWidth + 10);
				while (it->second.win.left + cx + width < 0)
					cx += (screenWidth + 10);
				while (it->second.win.top + cy > screenHeight)
					cy -= (screenHeight + 10);
				while (it->second.win.top + cy + height < 0)
					cy += (screenHeight + 10);

				cx += ( mouseoverDeskX - currentDeskX )*(screenWidth+10);
				cy += ( mouseoverDeskY - currentDeskY )*(screenHeight+10);
			}
			else
			{
				// get the amount of pixels the window has been moved
				cx = (int)((float)(message.lParamLo - diffPt.x - it->second.vwm.left)/modToVWMX);
				cy = (int)((float)(message.lParamHi - diffPt.y - it->second.vwm.top)/modToVWMY);
			}

			it->second.win.left   += cx;
			it->second.win.right  += cx;
			it->second.win.top    += cy;
			it->second.win.bottom += cy;

			// get the vwm-window rect from the new wnd rect
			getVWMRect( it->second.win, &(it->second.vwm) );

			SetWindowPos(hSelectedWnd,NULL,it->second.win.left,it->second.win.top,0,0,SWP_NOSIZE|SWP_NOACTIVATE|SWP_NOZORDER);

			InvalidateRect(hWnd, NULL, FALSE);
		}
  }
}

void VWM::onPaint(Message& message)
{
  PAINTSTRUCT ps;
  HDC hdc = BeginPaint(hWnd, &ps);

	// blit the background onto the memory dc
	HBITMAP hbmBackOld = (HBITMAP)SelectObject( hdcMemBuffer, hbmBack );

  BitBlt(hdcMem,0,0,vwmWidth,vwmHeight,hdcMemBuffer,0,0,SRCCOPY);

	if (hbmSel)
	{
		int cxSrc, cySrc, cxDst, cyDst;

		GetLSBitmapSize( hbmSel, &cxSrc, &cySrc );
		SelectObject( hdcMemBuffer, hbmSel );

		cxDst = vwmWidth/desksX;
		cyDst = vwmHeight/desksY;
		
		if ( cxDst!=cxSrc || cyDst!=cySrc )
			StretchBlt(hdcMem,cxDst*(currentDeskX-1),cyDst*(currentDeskY-1),cxDst,cyDst,hdcMemBuffer,0,0,cxSrc,cySrc,SRCCOPY);
		else
			BitBlt(hdcMem,cxDst*(currentDeskX-1),cyDst*(currentDeskY-1),cxDst,cyDst,hdcMemBuffer,0,0,SRCCOPY);

	}

	SelectObject( hdcMemBuffer, hbmBackOld );

	// paint the windows onto the memory dc
	paintWindowList();

	// blit the memory dc onto screen
  BitBlt(hdc,0,0,vwmWidth,vwmHeight,hdcMem,0,0,SRCCOPY);

  EndPaint(hWnd, &ps);
}

void VWM::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void VWM::onWindowActivated(Message& message)
{
//	if ( switchOnFocus )
//		switchDesk( getDeskFromWnd( (HWND)message.wParam ) );
}

void VWM::onTimer(Message& message)
{
  winList.clear();
  rectMap.clear();

  winListInit();
  InvalidateRect(hWnd,NULL,FALSE);
}

void VWM::onDropFiles(Message& message)
{
	POINT pt;
	int newDeskX, newDeskY;
	int numFiles;
	int i = 0;
	char szFileName[_MAX_PATH];
		
	DragQueryPoint( (HDROP)message.wParam, &pt );

	newDeskX = (desksX * pt.x) / vwmWidth + 1;
	newDeskY = (desksY * pt.y) / vwmHeight + 1;

	if ( ( newDeskX <= desksX ) && ( newDeskY <= desksY ) ) 
		switchDesk( getDeskId( newDeskX, newDeskY ) );

	numFiles = DragQueryFile( (HDROP)message.wParam, 0xFFFFFFFF, NULL, 0 );
	while ( i<numFiles )
	{
		DragQueryFile( (HDROP)message.wParam, i, szFileName, _MAX_PATH);
		if (szFileName && *szFileName)
			LSExecute(NULL, szFileName, SW_SHOWNORMAL);
		i++;
	}
	DragFinish( (HDROP)message.wParam );
	InvalidateRect(hWnd, NULL, FALSE);
}

void VWM::onVWMPosChanging(Message& message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)message.lParam;

	if ( !( lpwp->flags & SWP_NOSIZE ) )
	{
		vwmWidth = lpwp->cx;
		vwmHeight = lpwp->cy;
	}

	if ( !( lpwp->flags & SWP_NOMOVE ) )
	{
		if (snapDistance)
		{
			if ( abs(lpwp->x) <= snapDistance )
				lpwp->x = 0;
			if ( abs(lpwp->y) <= snapDistance )
				lpwp->y = 0;
			if ( abs(lpwp->x+vwmWidth-screenWidth) <= snapDistance )
				lpwp->x = screenWidth - vwmWidth;
			if ( abs(lpwp->y+vwmHeight-screenHeight) <= snapDistance ) 
				lpwp->y = screenHeight - vwmHeight;
		}
		vwmX = lpwp->x;
		vwmY = lpwp->y;
	}
	message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam); 
}




//=========================================================
// GDI specific code
//=========================================================
void VWM::paintBackground()
{
	// load the file background
	char szTemp[MAX_LINE_LENGTH];
	GetRCString("vwmBackBmp", szTemp, ".none", MAX_LINE_LENGTH);
	HBITMAP hbmFileBack = LoadLSImage(szTemp, NULL);

	if (hbmBack)
	{
		DeleteObject(hbmBack);
		hbmBack = NULL;
	}

	hbmBack = CreateCompatibleBitmap(hdcMem, vwmWidth, vwmHeight);
	HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMemBuffer, hbmBack);

	if (hbmFileBack)
	{
		int cx, cy;
		GetLSBitmapSize( hbmFileBack, &cx, &cy );
		HDC hdcFileBack = CreateCompatibleDC( hdcMemBuffer );
		HBITMAP hbmFileBackOld = (HBITMAP)SelectObject( hdcFileBack, hbmFileBack );

		StretchBlt( hdcMemBuffer, 0, 0, vwmWidth, vwmHeight, hdcFileBack, 0, 0, cx, cy, SRCCOPY );

		SelectObject( hdcFileBack, hbmFileBackOld );
		DeleteDC( hdcFileBack );
		DeleteObject( hbmFileBack );
	}
	else
  {
		HBRUSH hbr = CreateSolidBrush(clrBack);
		HBRUSH hbrOld = (HBRUSH)SelectObject(hdcMemBuffer, hbr);
		HPEN   pen = CreatePen(PS_SOLID, 1, clrBorder);
		HPEN   penOld = (HPEN)SelectObject(hdcMemBuffer, pen);

		Rectangle(hdcMemBuffer, 0, 0, vwmWidth, vwmHeight);

		{
			float wndSizeX = (float)vwmWidth / (float)desksX;
			for (int i = 1; i < desksX; i++)
			{
				MoveToEx(hdcMemBuffer, (int)(wndSizeX*i), 0, NULL);
				LineTo(hdcMemBuffer, (int)(wndSizeX*i), vwmHeight);
			}
		}
		{
			float wndSizeY = (float)vwmHeight / (float)desksY;
			for (int i = 1; i < desksY; i++)
			{
				MoveToEx(hdcMemBuffer, 0, (int)(wndSizeY*i), NULL);
				LineTo(hdcMemBuffer, vwmWidth, (int)(wndSizeY*i));
			}
		}
		
		SelectObject(hdcMemBuffer, penOld);
		SelectObject(hdcMemBuffer, hbrOld);
		DeleteObject(hbr);
		DeleteObject(pen);
	}
	SelectObject( hdcMemBuffer, hbmOld );
}

void VWM::paintWindowList()
{
  windowVector::reverse_iterator it = winList.rbegin();
  wRECTMap::iterator itMap;
  //char buffer2[MAX_LINE_LENGTH];
		
	HBRUSH hbr = CreateSolidBrush(clrWin);
	HBRUSH hbrOld = (HBRUSH)SelectObject(hdcMem, hbr);
	
	HPEN pen = CreatePen(PS_SOLID, 1, clrBorder);
	HPEN penOld = (HPEN)SelectObject(hdcMem, pen);

	// this is done here, so that it's only being done once
	int cxWinBmp, cyWinBmp, cxTitleBmp, cyTitleBmp;
	HDC hdcWinBmp, hdcTitleBmp;
	HBITMAP hbmWinBmpOld, hbmTitleBmpOld;
	if (hbmWin)
	{
		GetLSBitmapSize( hbmWin, &cxWinBmp, &cyWinBmp );
		hdcWinBmp = CreateCompatibleDC( hdcMem );
		hbmWinBmpOld = (HBITMAP)SelectObject( hdcWinBmp, hbmWin );
	}
	if (hbmTitle)
	{
		GetLSBitmapSize( hbmTitle, &cxTitleBmp, &cyTitleBmp );
		hdcTitleBmp = CreateCompatibleDC( hdcMem );
		hbmTitleBmpOld = (HBITMAP)SelectObject( hdcTitleBmp, hbmTitle );
	}
  
	//OutputDebugString("loop{\n");
	while ( it!=winList.rend() )
	{
    itMap = rectMap.find(*it);
    if ( itMap != rectMap.end() )
    {
      //sprintf( buffer2, "hwnd: %d|%d\nrect: {%d,%d,%d,%d}\n", it,*it, ((wRECT)(itMap->second)).win.left, itMap->second.win.top, itMap->second.vwm.right, itMap->second.vwm.bottom );
      //OutputDebugString(buffer2);
			RECT rtitle;
			RECT r = itMap->second.vwm;
			if (titlebarsMod)
			{
				rtitle.left = r.left;
				rtitle.top = r.top;
				rtitle.right = r.right;
				rtitle.bottom = r.top + (r.bottom-r.top)/titlebarsMod;
				// save the bottom of the titlebar as the top of the rest of the window
				r.top = rtitle.bottom;
				if (hbmTitle)
					StretchBlt(hdcMem, rtitle.left, rtitle.top, rtitle.right-rtitle.left, rtitle.bottom-rtitle.top, hdcTitleBmp, 0, 0, cxTitleBmp, cyTitleBmp, SRCCOPY);
				else
	    		Rectangle(hdcMem, rtitle.left, rtitle.top, rtitle.right, rtitle.bottom);
			}
			if (hbmWin)
				StretchBlt(hdcMem, r.left, r.top, r.right-r.left, r.bottom-r.top, hdcWinBmp, 0, 0, cxWinBmp, cyWinBmp, SRCCOPY);
			else
	    	Rectangle(hdcMem, r.left, r.top, r.right, r.bottom);
    }
		it++;
	}
  //OutputDebugString("}\n");
	if (hbmWin)
	{
		SelectObject( hdcWinBmp, hbmWinBmpOld );
		DeleteDC( hdcWinBmp );
	}
	if (hbmTitle)
	{
		SelectObject( hdcTitleBmp, hbmTitleBmpOld );
		DeleteDC( hdcTitleBmp );
	}
	SelectObject(hdcMem, hbrOld);
	DeleteObject(hbr);
	SelectObject(hdcMem, penOld);
	DeleteObject(pen);
}
//=========================================================
// Bang command handling
//=========================================================
void VWM::gather()
{
  wRECTMap::iterator it = rectMap.begin();
	int width, height;

  while ( it!=rectMap.end() )
  {
	  width = it->second.win.right - it->second.win.left;
	  height = it->second.win.bottom - it->second.win.top;
		  
	  while (it->second.win.left > screenWidth)
		  it->second.win.left -= (screenWidth + 10);
	  while (it->second.win.left + width < 0)
		  it->second.win.left += (screenWidth + 10);
	  while (it->second.win.top > screenHeight)
		  it->second.win.top -= (screenHeight + 10);
	  while (it->second.win.top + height < 0)
		  it->second.win.top += (screenHeight + 10);

    getVWMRect(it->second.win, &(it->second.vwm));

		SetWindowPos(it->first, NULL, it->second.win.left, it->second.win.top, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);

		it++;
	}
}

void VWM::switchDeskUp()
{
	int nDeskY = currentDeskY - 1;
	if ( nDeskY >= 1 )
		switchDesk( getDeskId(currentDeskX, nDeskY) );
}

void VWM::switchDeskDown()
{
	int nDeskY = currentDeskY + 1;
	if ( nDeskY <= desksY )
		switchDesk( getDeskId(currentDeskX, nDeskY) );
}

void VWM::switchDeskLeft()
{
	int nDeskX = currentDeskX - 1;
	if ( nDeskX >= 1 )
		switchDesk( getDeskId(nDeskX, currentDeskY) );
}

void VWM::switchDeskRight()
{
	int nDeskX = currentDeskX + 1;
	if ( nDeskX <= desksX )
		switchDesk( getDeskId(nDeskX, currentDeskY) );
}

void VWM::toggle()
{
	visible = !visible;
	ShowWindow( hWnd, (visible)?SW_SHOWNOACTIVATE:SW_HIDE );
}

void VWM::show()
{
	visible = TRUE;
	ShowWindow( hWnd, SW_SHOWNOACTIVATE );
}

void VWM::hide()
{
	visible = FALSE;
	ShowWindow( hWnd, SW_HIDE );
}

void VWM::open(int nDesk, char *cmd)
{
	switchDesk( nDesk );
	LSExecute( NULL, cmd, SW_SHOWNORMAL );
}

void VWM::reset()
{
	// reset settings
}

void VWM::moveApp(char *args)
{
	wRECTMap::iterator it = rectMap.find(GetForegroundWindow());
	if ( it!=rectMap.end() )
	{
		if (!stricmp (args, "up"))
			it->second.win.top -= screenHeight+10;
		else if (!stricmp (args, "down"))
			it->second.win.top += screenHeight+10;
		else if (!stricmp (args, "left"))
			it->second.win.left -= screenWidth+10;
		else if (!stricmp (args, "right"))
			it->second.win.left += screenWidth+10;

		getVWMRect( it->second.win, &(it->second.vwm) );

		SetWindowPos(it->first, NULL, it->second.win.left, it->second.win.top, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
}

void VWM::winListInit()
{
  HWND hItWnd = GetTopWindow(NULL);
  HWND hOwnerWnd = NULL;

  while (hItWnd)
  {
    if( IsWindowVisible(hItWnd) && GetWindowLong(hItWnd, GWL_USERDATA) != magicDWord)
    {
      if( !(GetWindowLong(hItWnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) )
      {
        if( !GetParent(hItWnd) )
        {
          hOwnerWnd = GetWindow(hItWnd,GW_OWNER);
          if( !hOwnerWnd || GetWindowLong(hOwnerWnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW )
          {
            winListAdd(hItWnd);
          }
        }
      }
    }
    hItWnd = GetWindow(hItWnd, GW_HWNDNEXT);
  }
}

void VWM::winListAdd(HWND hWndList)
{
  wRECT rc;
//  char buffer2[MAX_LINE_LENGTH];

  GetWindowRect(hWndList, &(rc.win));

//  sprintf( buffer2, "hwnd: %d\nrect: {%d,%d,%d,%d}\n", hWndList, rc.win.left, rc.win.top, rc.win.right, rc.win.bottom );
//  OutputDebugString(buffer2);

  getVWMRect(rc.win, &(rc.vwm));
//  sprintf( buffer2, "hwnd: %d\nrect: {%d,%d,%d,%d}\n", hWndList, rc.vwm.left, rc.vwm.top, rc.vwm.right, rc.vwm.bottom );
//  OutputDebugString(buffer2);

  winList.push_back(hWndList);
  rectMap.insert(wRECTMap::value_type(hWndList, rc));
}

void VWM::winListDel(HWND hWndList)
{
  // remove from list
  {
    windowVector::iterator it = winListFind(hWndList);

    if ( it != winList.end() )
      winList.erase(it);
  }
  // remove from map
  {
    wRECTMap::iterator it = rectMap.find(hWndList);

    if ( it != rectMap.end() )
      rectMap.erase(it);
  }
}

windowVector::iterator VWM::winListFind(HWND hWndList)
{
  windowVector::iterator it = winList.begin();

  while ( it != winList.end() )
  {
    if (*it==hWndList)
      return it;
    it++;
  }
  return NULL;
}

void VWM::winListChnP(HWND hWndList, int x, int y, int cx, int cy)
{
  wRECTMap::iterator it = rectMap.find(hWndList);

  if ( it != rectMap.end() )
  {
    wRECT rc;

    SetRect(&rc.win, x, y, x+cx, y+cy);
    getVWMRect(rc.win, &rc.vwm);

    it->second = rc;
  }
}

void VWM::winListChnZ(HWND hWndList, HWND hWndInsertAfter)
{
  windowVector::iterator it = winListFind(hWndList);

  if ( it != winList.end() )
  {
    HWND hWndAfter = hWndInsertAfter;
    windowVector::iterator at = NULL;

    do
    {
      at = winListFind(hWndAfter);
      hWndAfter = GetWindow(hWndAfter,GW_HWNDPREV);
    } while (!at);

    at++;

    winList.erase(it);
    winList.insert(at, hWndList);
  }
}

void VWM::getVWMRect(RECT srcrc, LPRECT lpdstrc)
{
	lpdstrc->left   = (int)(modToVWMX*(float)(srcrc.left+(screenWidth+10)*(currentDeskX-1)));
	lpdstrc->right  = lpdstrc->left + modToVWMX*(srcrc.right-srcrc.left+10);
	lpdstrc->top    = (int)(modToVWMY*(float)(srcrc.top+(screenHeight+10)*(currentDeskY-1)));
	lpdstrc->bottom = lpdstrc->top + modToVWMY*(srcrc.bottom-srcrc.top+10);
}

void hookWindowPosChangedProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)lParam;
    char buffer2[MAX_LINE_LENGTH];
    sprintf(buffer2, "a message is being sent to the module; %d\n", uMsg );
    OutputDebugString( buffer2 );

  if ( vwm->winListFind(hWnd) == NULL )
  {
    vwm->winListAdd(hWnd);
  }
  else
  {
	  if ( !(lpwp->flags & SWP_NOSIZE) || !(lpwp->flags & SWP_NOMOVE) )
	  {
      vwm->winListChnP(hWnd,lpwp->x, lpwp->y, lpwp->cx, lpwp->cy);
    }

    if ( !(lpwp->flags & SWP_NOZORDER) )
    {
      vwm->winListChnZ(hWnd,lpwp->hwndInsertAfter);
    }
	}
	//message.lResult = DefWindowProc(hWnd, uMsg, wParam, lParam); 
}
