/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point
#include <windows.h>
#include "DLLModuleManager.h"

HINSTANCE myInstance;

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH) {
		myInstance = hInstance;
        DisableThreadLibraryCalls(hInstance);
    } else if (dwReason == DLL_PROCESS_DETACH) {
        myInstance = NULL;
	}
    return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    //return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    //return _Module.GetClassObject(rclsid, riid, ppv);
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    //return _Module.RegisterServer(TRUE);
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    //return _Module.UnregisterServer(TRUE);
	return NULL;
}

STDAPI CreateModuleManager(HWND hwnd, LPCTSTR appPath)
{
	IUnknown *unknown;
	IModuleManager *modMan;

	unknown = new DLLModuleManager(hwnd, appPath);
	unknown->QueryInterface(IID_IModuleManager, (void**)&modMan);
	//modMan->Release();

	return (LONG)modMan;
}