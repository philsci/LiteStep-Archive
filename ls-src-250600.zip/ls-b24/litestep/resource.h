//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by litestep.rc
//
#define IDI_LS                          101
#define IDD_ABOUT                       102
#define IDI_VER                         103
#define IDD_ABOUTBOX                    104
#define IDI_ICON1                       106
#define IDI_LOGO                        1002
#define IDC_VERSION                     1004
#define IDC_VINFO                       1008
#define IDC_LS                          1009
#define IDC_VER                         1010
#define IDC_HEADER                      1012
#define IDC_TITLE                       1013
#define IDC_LOGO                        1014
#define IDC_COMPILETIME                 1015
#define IDC_COMBOBOX                    1016
#define IDC_LISTVIEW                    1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
