#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include "lsapi.h"

// Maximum length of log message
#define MAX_LOG_MESSAGE_LEN 2048

// Log file
TCHAR szLogFile[MAX_PATH] = { 0 };
int nLogLevel = LOG_WARNING;

// ----------------------------------------------------------------------------
//  LSLog
// ----------------------------------------------------------------------------
//  Adds a message to the log file
// ----------------------------------------------------------------------------

BOOL WINAPI
LSLog(int nLevel, LPCSTR pszModule, LPCSTR pszMessage)
{
	// Has a log file been assigned?
	if(!szLogFile[0])
		return FALSE;

	// Should this message be logged?
	if(nLevel > nLogLevel)
		return FALSE;

	// If so, open it
	HANDLE hLogFile = CreateFile(szLogFile, 
		GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_ALWAYS,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	// Did open succeed?
	if(hLogFile == INVALID_HANDLE_VALUE)
		return FALSE;

	// Move to the end of the file
	SetFilePointer(hLogFile, 0, NULL, FILE_END);

	// Get timestamp
	SYSTEMTIME st;
	GetLocalTime(&st);

	// Add timestamp and module name to message
	TCHAR szLine[MAX_LOG_MESSAGE_LEN];
	int nLen;

	nLen = wsprintf(szLine, "%02d-%02d-%04d %02d:%02d:%02d - %s: %s\r\n",
		st.wMonth, st.wDay, st.wYear, st.wHour, st.wMinute, st.wSecond,
		pszModule, pszMessage);

	// Write it to the log file
	DWORD dwCount;
	WriteFile(hLogFile, szLine, nLen, &dwCount, NULL);

	// Close the log
	CloseHandle(hLogFile);

	return TRUE;
}

// ----------------------------------------------------------------------------
//  LSLogPrintf
// ----------------------------------------------------------------------------
//  Adds a printf-style formatted message to the log file
// ----------------------------------------------------------------------------

BOOL WINAPIV
LSLogPrintf(int nLevel, LPCSTR pszModule, LPCSTR pszFormat, ...)
{
	// Don't waste the effort if this won't get logged
	if(!szLogFile[0] || nLevel > nLogLevel)
		return FALSE;

	// Format the message
	CHAR szMessage[MAX_LOG_MESSAGE_LEN];
	va_list argList;

	va_start(argList, pszFormat);
	wvsprintf(szMessage, pszFormat, argList);
	va_end(argList);

	// Call LSLog to the real work
	return LSLog(nLevel, pszModule, szMessage);
}

// ----------------------------------------------------------------------------
//  SetLSLogFile
// ----------------------------------------------------------------------------
//  Sets the path to the log file
// ----------------------------------------------------------------------------

BOOL WINAPI
SetLSLogFile(LPCSTR pszLogFile)
{
	szLogFile[0] = 0;

	if(pszLogFile)
		lstrcpyn(szLogFile, pszLogFile, MAX_PATH);

	return TRUE;
}

// ----------------------------------------------------------------------------
//  SetLSLogLevel
// ----------------------------------------------------------------------------
//  Sets the maximum logging level
// ----------------------------------------------------------------------------

BOOL WINAPI
SetLSLogLevel(int nMaxLevel)
{
	nLogLevel = max(nMaxLevel, LOG_ERROR);
	return TRUE;
}
