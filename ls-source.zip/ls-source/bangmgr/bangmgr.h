
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0347 */
/* at Mon Apr 22 22:33:52 2002
 */
/* Compiler settings for E:\temp\ls-source\current\bangmgr\bangmgr.idl:
    Os, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __bangmgr_h__
#define __bangmgr_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __StandardBangManager_FWD_DEFINED__
#define __StandardBangManager_FWD_DEFINED__

#ifdef __cplusplus
typedef class StandardBangManager StandardBangManager;
#else
typedef struct StandardBangManager StandardBangManager;
#endif /* __cplusplus */

#endif 	/* __StandardBangManager_FWD_DEFINED__ */


#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 


#ifndef __LitestepBangManager_LIBRARY_DEFINED__
#define __LitestepBangManager_LIBRARY_DEFINED__

/* library LitestepBangManager */
/* [uuid] */ 


EXTERN_C const IID LIBID_LitestepBangManager;

EXTERN_C const CLSID CLSID_StandardBangManager;

#ifdef __cplusplus

class DECLSPEC_UUID("B1ADF126-C4A9-476b-96DC-F7832A40CC09")
StandardBangManager;
#endif
#endif /* __LitestepBangManager_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


