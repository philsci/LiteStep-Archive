/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
11/26/01 - Bobby G. Vinyard (Message)
  - Uses new LSNOTIFYICONDATA structure to support longer
    tooltips. System tray modules will have to be updated before being used with this
    build. System tray must issue the LM_SYSTRAYREADY message when they are ready to
    receive the icons, and must not post the "TaskbarCreated" message.
****************************************************************************/
// NOTES // NOTES // NOTES // NOTES // NOTES // NOTES // NOTES // NOTES //
/****************************************************************************
Note 1:  The offline file sync is sent only with a valid uMessageCallback 
         (NIF_MESSAGE) (W2K)

Note 2:  The DUN/Networking icons sent using the NIS_HIDDEN dwState flags use 
         an invalid uID (usually 0xFFFFFFFF) (W2K/XP)

Note 3:  The window handling the DUN/Networking icons has a class and caption of
         "Connections Tray" (FindWindowEx(NULL, NULL, "Connections Tray, NULL))
		 (W2K/XP)

Note 4:  Tooltip (NIF_TIP) for the DUN/Networking icons isn't created until the tray 
         icon receives its first mouseover event (W2K/XP)

Note 5:  The DUN/Networking Icons appear to use NIS_SHAREDICON with two different
         uIDs. This will cause two icons to display with the same functionality. 
		 One icon will not show a tooltip. Therefore as a work around, find the 
		 "Connections Tray" window, and everytime a notification comes in matching
		 that hwnd and without a NIF_TIP flag, post a WM_MOUSEMOVE message with
		 the uID and uCallbackMessage to the "Connections Tray" window. This will
		 cause a tooltip to be added to the true icon next time it is sent. The other
		 icon will remain with out a tooltip and can be ignored. (XP)

Note 6:  RegisterWindowMessage("TaskbarCreated") should be sent with HWND_BROADCAST
         before the shell service objects are loaded (sending after wards would 
		 result in a Volume icon flicker or loss because the shell service object
		 would delete the icon) Also ensure the "TaskbarCreated" message is sent only
		 once. (W2K/XP)

Note 7:  Volume/DUN/Networking icons are controlled by shell service objects (SSO).
         They are COM servers implementing the IOleCommandTarget interface. 
		 The CLSIDs are listed in 
		 "Software\\Microsoft\\Windows\\CurrentVersion\\ShellServiceObjectDelayLoad" 
         They should be enumerated and created using IID_IOleCOmmandTarget. 
		 Exec each SSO with a group id of CGID_ShellServiceObject and command id 
		 of 2 to start. Exec each SSO with a group id of CGID_ShellServiceObject 
		 and a command id of 3 to stop.

Note 8:  The icons are copied here to prevent the loss of icons that was occuring
         in some instances (msn and icq particularily) A blank spot in the systray
		 would show for the missing icons and the space would respond to mouse events.

****************************************************************************/
#include "..\lsapi\common.h"
#include <shlobj.h>
#include "TrayManager.h"

// TrayManager constructor
TrayManager::TrayManager(HWND lswnd, HINSTANCE lsdll, int& code)
{
	hLiteStep = lswnd;
	dll = lsdll;
	code = 0;

	pFirst = NULL;
	pLast = NULL;
	m_ssoList = NULL;
	hConnectionsTray = NULL;

	OsVersionInfo.dwOSVersionInfoSize = sizeof(OsVersionInfo);
	GetVersionEx(&OsVersionInfo);
	if ((OsVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) && (OsVersionInfo.dwMajorVersion == 5))
	{
		bWin2000 = true;
	}
	else
	{
		bWin2000 = false;
	}

	WNDCLASSEX wc;

	// Register tray notification window class
	memset(&wc, 0, sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.cbClsExtra = 0;

	wc.lpfnWndProc = TrayManager::WndProcTray;			// our window procedure
	wc.hInstance = lsdll;							// hInstance of DLL
	wc.lpszClassName = TRAYMANAGER_CLASS;			// our window class name
	wc.style = CS_DBLCLKS;

	if (!RegisterClassEx(&wc))
	{
		MessageBox(hLiteStep, "Error registering window class", TRAYMANAGER_CLASS, MB_OK | MB_TOPMOST);
		code = 1;
	}
	else
	{
		// Tray Manager Window
		hTrayWnd = CreateWindowEx(
		               WS_EX_TOPMOST | WS_EX_TOOLWINDOW,      				// exstyles
		               TRAYMANAGER_CLASS,      								// our window class name
		               TRAYMANAGER_TITLE,      								// use description for a window title
		               WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,      	// styles
		               0, 0,      											// position
		               0, 0,      											// width & height of window
		               NULL,      								// parent window
		               NULL,      											// no menu
		               dll,      											// hInstance of DLL
		               NULL);											// no window creation data
		if (!hTrayWnd)
		{
			UnregisterClass(TRAYMANAGER_CLASS, dll); // unregister window class
			code = 1;
			MessageBox(hLiteStep, "Error creating window", TRAYMANAGER_TITLE, MB_OK | MB_TOPMOST);
		}
		else
		{

			SetWindowLong(hTrayWnd, GWL_USERDATA, magicDWord);
			SetWindowLong(hTrayWnd, 0, (LONG)this);

			// Win98/IE4 stuff
			PostMessage(HWND_BROADCAST, RegisterWindowMessage("TaskbarCreated"), 0, 0);

			if (bWin2000)
			{
				LoadShellServiceObjects();

				hConnectionsTray = FindWindowEx(NULL, NULL, "Connections Tray", NULL);
			}
		}
	}
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for the system tray window
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK TrayManager::WndProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static TrayManager *theTrayManager;
	
	if (!theTrayManager)
		theTrayManager = (TrayManager*)::GetWindowLong(hwnd, 0);

	if (theTrayManager)
	{
		return theTrayManager->WindowProcTray(hwnd, message, wParam, lParam);
	}
	else
	{
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT TrayManager::WindowProcTray(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_COPYDATA:
		{
			// odd conversion... don't know about this...
			PNOTIFYICONDATAV5 pnid5 = NULL;
			PSYSTRAYICONDATA pnidFound = pFirst;
			PCOPYDATASTRUCT pcds;
			PSHELLTRAYDATA pstd;
			BOOL bNewIcon = TRUE;
			BOOL result = TRUE;

			// Get the WM_COPYDATA structure from the lParam
			pcds = (PCOPYDATASTRUCT) lParam;

			if ( pcds->dwData != 1 )
				return FALSE;

			// Get the shell tray data from the WM_COPYDATA structure
			pstd = (PSHELLTRAYDATA) pcds->lpData;
		
			// New actions for W2K and after, we don't handle these right now
			// so we will just bail out if we receive them
			if ((pstd->dwMessage == NIM_SETFOCUS) && (pstd->dwMessage == NIM_SETVERSION))
				return FALSE;

			// See if the NOTIFYICONDATA already exists in our list
			while (pnidFound)
			{
				if ((pnidFound->nid.hWnd == pstd->nid.hWnd) &&
					(pnidFound->nid.uID == pstd->nid.uID))
				{
					bNewIcon = FALSE;
					break;
				}
				pnidFound = pnidFound->pNext;
			}

			if ((pnidFound == NULL) && (pstd->dwMessage != NIM_DELETE))
			{
				pnidFound = new SYSTRAYICONDATA;
				memset(pnidFound, 0, sizeof(SYSTRAYICONDATA));
				pnidFound->nid.cbSize = sizeof(LSNOTIFYICONDATA);
				pnidFound->bSent = TRUE;
			}

			switch (pstd->dwMessage)
			{
				case NIM_ADD:
				case NIM_MODIFY:
				{
					// On WinXP, this will actually be v6, so we check to see
					// if it's larger than v5
					// we only really need this for the tooltip info
					if (pstd->nid.cbSize >= sizeof(NOTIFYICONDATAV5))
					{

						pnid5 = (PNOTIFYICONDATAV5) & pstd->nid;

						// See Note 2
						if ((bNewIcon) && (pnid5->dwState & NIS_HIDDEN))
						{
							delete pnidFound;
							return TRUE;
						}
						
						pnidFound->nid.dwState = pnid5->dwState;

						if ((pnid5->uFlags & NIF_INFO) && (pnid5->szInfo))
						{

							UINT nChars = min( UINT( wcslen( pnid5->szInfo ) + 1 ), UINT(256) );
							::WideCharToMultiByte(CP_ACP, 0, pnid5->szInfo, nChars, pnidFound->nid.szTip, nChars, NULL, NULL);

							// just to ensure last character is a NULL... :P
							pnidFound->nid.szTip[255] = '\0';

							// Add the NIF_TIP flag so modules will know to use this
							pnid5->uFlags |= NIF_TIP;
						}
						else if ((pnid5->uFlags & NIF_TIP) && (pnid5->szTip))
						{
							UINT nChars = min( UINT( wcslen( pnid5->szTip ) + 1 ), UINT(256) );
							::WideCharToMultiByte(CP_ACP, 0, pnid5->szTip, nChars, pnidFound->nid.szTip, nChars, NULL, NULL);

							// just to ensure last character is a NULL... :P
							pnidFound->nid.szTip[255] = '\0';
						}
					}
					else
					{
						if ((pstd->nid.szTip) && (pstd->nid.uFlags & NIF_TIP))
						{
							strncpy(pnidFound->nid.szTip, pstd->nid.szTip, 256);
							pnidFound->nid.szTip[255] = '\0';
						}
					}

					if (bNewIcon)
					{
						if (bWin2000)
						{
							// See Note 5
							if (!hConnectionsTray)
							{
								hConnectionsTray = FindWindowEx(NULL, NULL, "Connections Tray", NULL);					
							}
							if ((pstd->nid.uFlags & ~NIF_TIP) && (pstd->nid.hWnd == hConnectionsTray))
							{
								PostMessage(pnid5->hWnd, pnid5->uCallbackMessage, pnid5->uID, WM_MOUSEMOVE);
							}
						}
						
						pnidFound->nid.hWnd = pstd->nid.hWnd;
						pnidFound->nid.uID	= pstd->nid.uID;

						pnidFound->nid.uFlags = pstd->nid.uFlags;
						if (pnidFound->nid.uFlags & NIF_MESSAGE)
						{
							pnidFound->nid.uCallbackMessage = pstd->nid.uCallbackMessage;
						}
						if (pnidFound->nid.uFlags & NIF_ICON)
						{
							pnidFound->nid.hIcon = CopyIcon(pstd->nid.hIcon); // Note 8
						}

						// add to last position in the list
						if (!pFirst)
						{
							pFirst = pnidFound;
							pnidFound->pPrev = NULL;
						}
						if (pLast)
						{
							pnidFound->pPrev = pLast;
							pLast->pNext = pnidFound;
						}
						pLast = pnidFound;
						pnidFound->pNext = NULL;

						if (ValidIcon(pnidFound->nid.uFlags))
						{		
							result = SendMessage(hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) & pnidFound->nid);
						}
						else
						{
							pnidFound->bSent = FALSE;
						}

					}
					else
					{
						DWORD dwFlags = pnidFound->nid.uFlags | pstd->nid.uFlags;
						pnidFound->nid.uFlags = pstd->nid.uFlags;

						if (pstd->nid.uFlags & NIF_MESSAGE)
						{
							pnidFound->nid.uCallbackMessage = pstd->nid.uCallbackMessage;
						}

						if (pstd->nid.uFlags & NIF_ICON)
						{
							if (pnidFound->nid.hIcon)
							{
								DestroyIcon(pnidFound->nid.hIcon);
							}
							pnidFound->nid.hIcon = CopyIcon(pstd->nid.hIcon); // Note 8
						}

						if (pnidFound->bSent)
						{
							result = SendMessage(hLiteStep, LM_SYSTRAY, NIM_MODIFY, (LPARAM) & pnidFound->nid);
						}
						else if (ValidIcon(dwFlags))
						{
							pnidFound->nid.uFlags = dwFlags;
							pnidFound->bSent = TRUE;
							result = SendMessage(hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) & pnidFound->nid);
						}

						// Update the flags, so that if we have to resend this, it's
						// up to date
						pnidFound->nid.uFlags = dwFlags;
					}
					break;
				}
				case NIM_DELETE:
				{
					if ((pnidFound) && !(bNewIcon))
					{
						// if it's first or last, move those pointers
						if (pFirst == pnidFound)
							pFirst = pnidFound->pNext;
						else
							pnidFound->pPrev->pNext = pnidFound->pNext;

						if (pLast == pnidFound)
							pLast = pnidFound->pPrev;
						else
							pnidFound->pNext->pPrev = pnidFound->pPrev;

						// remove the icon class
						result = SendMessage(hLiteStep, LM_SYSTRAY, pstd->dwMessage, (LPARAM) & pnidFound->nid);

						if (pnidFound->nid.hIcon)
						{
							DestroyIcon(pnidFound->nid.hIcon);
						}
						delete pnidFound;

					}
					break;
				}
				default:
				{
					result = FALSE;
					break;
				}
			}

			return result;

		}

	}

	return ::DefWindowProc(hwnd, message, wParam, lParam);
}

TrayManager::~TrayManager()
{
	PSYSTRAYICONDATA pnidFound, pnidNext = NULL;

	if (bWin2000)
	{
		UnloadShellServiceObjects();
	}

	if (hTrayWnd)
	{
		DestroyWindow(hTrayWnd); // delete our window

		UnregisterClass(TRAYMANAGER_CLASS, dll); // unregister window class
	}

	pnidFound = pFirst;
	while (pnidFound)
	{
		pnidNext = pnidFound->pNext;
		if (pnidFound)
		{
			// if it's first or last, move those pointers
			if (pFirst == pnidFound)
				pFirst = pnidFound->pNext;
			else
				pnidFound->pPrev->pNext = pnidFound->pNext;

			if (pLast == pnidFound)
				pLast = pnidFound->pPrev;
			else
				pnidFound->pNext->pPrev = pnidFound->pPrev;

			if (pnidFound->nid.hIcon)
			{
				DestroyIcon(pnidFound->nid.hIcon);
			}
			delete pnidFound;
		}
		pnidFound = pnidNext;
	}
}


void TrayManager::SendSystemTray()
{
	PSYSTRAYICONDATA pnidFound = pFirst;

	// See if the NOTIFYICONDATA already exists in our list
	while (pnidFound)
	{
		if (ValidIcon(pnidFound->nid.uFlags))
		{
			SendMessage(hLiteStep, LM_SYSTRAY, NIM_ADD, (LPARAM)&pnidFound->nid);
		}
		pnidFound = pnidFound->pNext;
	}
}

void TrayManager::LoadShellServiceObjects()
{
	HKEY hkeyServices;
	LONG lErrorCode;
	int i = 0;

	lErrorCode = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
	                          "Software\\Microsoft\\Windows\\CurrentVersion\\ShellServiceObjectDelayLoad",
	                          0, KEY_READ, &hkeyServices);


	while (lErrorCode == ERROR_SUCCESS)
	{
		char szValueName[32];
		char szData[40];
		DWORD cbValueName = 32;
		DWORD cbData = 40;
		DWORD dwDataType;

		lErrorCode = RegEnumValue(hkeyServices, i,
		                          szValueName, &cbValueName, 0,
		                          &dwDataType,
		                          (LPBYTE) szData, &cbData);

		if (lErrorCode == ERROR_SUCCESS)
		{
			WCHAR wszCLSID[40];
			CLSID clsid;
			IOleCommandTarget *pCmdTarget = NULL;

			MultiByteToWideChar(CP_ACP, 0, szData, cbData, wszCLSID, 40);

			CLSIDFromString(wszCLSID, &clsid);

			HRESULT hr = CoCreateInstance(clsid, NULL, CLSCTX_INPROC_SERVER | CLSCTX_INPROC_HANDLER,
			                              IID_IOleCommandTarget, (void **) & pCmdTarget);

			if (SUCCEEDED(hr))
			{
				pCmdTarget->Exec(&CGID_ShellServiceObject, 2, 0, NULL, NULL);

				ShellServiceObjectList *entry = new ShellServiceObjectList;
				entry->object = pCmdTarget;
				entry->next = m_ssoList;
				m_ssoList = entry;
			}
		}

		i++;
	}

	RegCloseKey(hkeyServices);
}

void TrayManager::UnloadShellServiceObjects()
{
	ShellServiceObjectList *current = m_ssoList;
	ShellServiceObjectList *next;

	while (current)
	{
		next = current->next;

		current->object->Exec(&CGID_ShellServiceObject, 3, 0, NULL, NULL);
		current->object->Release();
		delete current;

		current = next;
	}

	m_ssoList = NULL;
}
