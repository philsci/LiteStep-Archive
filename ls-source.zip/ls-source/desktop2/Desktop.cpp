/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
01/11/01 - Bobby G. Vinyard (Message)
  - Added four additional modifiers:  alt     alt key
                                      lwin    left win button
                                      rwin    right win button
                                      apps    button next to the right win button
01/10/01 - Bobby G. Vinyard (Message)
  - Removed DesktopLeftClick, DesktopRightClick, DesktopMiddleClick,
    DesktopX1Click, DesktopX2Click, !DesktopSetRightClick, !DesktopSetLeftClick,
    !DesktopSetMiddleClick, !DesktopSetX1Click, !DesktopSetX2Click
  - Fixed desktop getting focus when using xmouse
  - Addednew support for key modifiers used as the following:
    *desktop [_tmain button]+[modifier]+[modifier]+.. command
    Modifiers are:  lbutton     left mouse button up
                    rbutton     right mouse button up
                    mbutton     middle mouse button up
                    x1button    x1 mouse button up
                    x2button    x2 mouse button up
                    ctrl        control key down
                    shift       shift key down
                    
    Examples:
    *desktop rbutton !popup // Right button up displays popup
    *desktop lbutton !about // Left button up displays about box
    *desktop lbutton+ctrl !recycle // Left button up while holding down control key
                                      recycles LiteStep
    *desktop rbutton+ctrl+shift !quit // You can figure it out =]
    
    Note: you can do *desktop rbutton+lbutton !about and it will display the
    about box when you hold down the lbutton and click the rbutton, *but* releasing 
    the lbutton will fire off the command set by *desktop lbutton
  - Added !DesktopSetClick, you use this in the same way as the step.rc config, just
    minus the "*desktop"
    !DesktopSetClick lbutton+ctrl !recycle 
12/08/00 - Bobby G. Vinyard (Message)
  - Added XButton support, DesktopX1Click, DesktopX2Click, !SetDesktopX1Click,
    !SetDesktopX2Click
12/07/00 - Bobby G. Vinyard (Message)
  - Cleaned up the code some, added LM_REFRESH handling
12/06/00 - Bobby G. Vinyard (Message)
  - Added SetDesktopAreaMainMonitorOnly, SetDesktopArea<int>, SDALeft<int>
    SDATop<int>, SDABottom<int>, SDARight<int> see desktop2.tx t for details.
11/28/00 - Bobby G. Vinyard (Message)
  - Added multimonitor support
11/23/00 - Joachim Calvert (NeXTer)
  - The !DesktopSetArea command is finally working, I must have been very
    tired when I wrote that code. Not only did it call the wrong function,
    but also registered the wrong command. That noone hasn't noticed before
    now is pretty remarkable
11/08/00 - Joachim Calvert (NeXTer)
  - Oups... Setting the parent to the desktop made it show up in the task
    list. Back to the drawing board
11/07/00 - Joachim Calvert (NeXTer)
  - Changed the parent window to the desktop and removed the clipping.
    This should (theoretically) make it easier to adapt LS to a multi-monitor
    setup
11/01/00 - Joachim Calvert (NeXTer)
  - Added !DesktopSetArea left top right bottom, the rules are the same as
    for the normal settings
05/21/00 - Joachim Calvert (NeXTer)
  - Removed some superflous code, and fixed some other minor issues.
04/20/00 - Joachim Calvert (NeXTer)
  - Some minor fixes
04/19/00 - Joachim Calvert (NeXTer)
  - Now uses Window (in lswinbase) as base class, should simplify the process
    of writing C++ based modules somewhat
04/17/00 - Joachim Calvert (NeXTer)
  Made the code more or less completely streamlined. The size has suffered
    slightly, but the readability is much improved.
04/16/00 - Bobby G. Vinyard (Message)
  Changed the desktop clicks to use LSExecute instead of ParseBangCommand
    This results in desktop2 not needing to parse the string before calling
    LSExecute, removed some unneeded variables and functions
    Can now do something like DesktopLeftClick cmd.exe to cause the left click
    to open a command window in WinNT
04/14/00 - Bobby G. Vinyard (Message)
  Made right click default to !popup
04/14/00 - Joachim Calvert (NeXTer)
  The desktop area is now dynamically set on resolution changes.
04/13/00 - Bobby G. Vinyard (Message)
  Reimplemented desktop clicks to use a function for setting their variables
    (Thanks MrJukes and Dem0sh for your help)
  Added three new bang commands:
    !SetDesktopLeftClick
    !SetDesktopRightClick
    !SetDesktopMiddleClick
    These allow you to change what the mouse clicks do on the fly
    e.g. !SetDesktopLeftClick !popup x=0 y=0
04/10/00 Bobby G. Vinyard (Message)
  Remove autorun functionality (was our understanding that this was flakey
    and that a 3rd party module is available that better provides this
    functionality, may be reimplemented in the future, but I see no reason
    for it to be a desktop function)
  Did some more house cleaning (i.e. removed unused variables, added proper
    headers, proper format)
04/06/00 Bobby G. Vinyard (Message) & noodge
  Went ahead and added a basic implementation of DesktopLeftClick <command>,
  DesktopMiddleClick <command>, DesktopRightClick <command> (Might look into
    streamling the functions soon when I finish streamling desktop2)
04/01/00 Bobby G. Vinyard (Message)
  Removed some unused variable (ok, well really just commented them out until
    this build is throughly tested)
  Did some more work on setting the desktop area, hopefully this is fixed now
****************************************************************************/

#include "Desktop.h"

const char szAppName[] = "DesktopBackgroundClass"; // Our window class, etc

const char rcsRevision[] = "$Revision: 1.4 $"; // Our Version
const char rcsId[] = "$Id: Desktop.cpp,v 1.4 2002/01/03 15:43:24 message Exp $"; // The Full RCS ID.

Desktop *desktop; // The module
int numMonitors;
bool multipleSDA;

BOOL CALLBACK MultipleDesktopAreaEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam);
BOOL CALLBACK DesktopAreaEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam);
BOOL CALLBACK DesktopAreaResetEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam);

#ifdef _DEBUG
char szdebugBuffer[4096];
#endif // _DEBUG

//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	int code;

	Window::init(dllInst);

	desktop = new Desktop(ParentWnd, code);

	return code;
}


void quitModule(HINSTANCE dllInst)
{
	delete desktop;
}


//=========================================================
// Bang commands
//=========================================================

void BangSetClick(HWND caller, LPCSTR args)
{
	desktop->bangSetClick(args);
}


void BangDesktopSetArea(HWND caller, LPCSTR args)
{
	desktop->bangSetArea(args);
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
Desktop::Desktop(HWND parentWnd, int& code):
		Window(szAppName)
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	screenLeft = SCREEN_LEFT;
	screenTop = SCREEN_TOP;
	screenWidth = SCREEN_WIDTH;
	screenHeight = SCREEN_HEIGHT;

	if (!createWindow(WS_EX_TOOLWINDOW, szAppName, WS_POPUP,
	                  screenLeft, screenTop, screenWidth, screenHeight, parentWnd))
	{

		RESOURCE_MSGBOX(hInstance, IDS_DESKTOP2_ERROR1, "Unable to create window", szAppName)

		code = 1;
		return ;
	}

	SetWindowPos(hWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_NOSENDCHANGING);

	SendMessage(hParent, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);
	SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

	AddBangCommand("!DesktopSetClick", BangSetClick);
	AddBangCommand("!DesktopSetArea", BangDesktopSetArea);

	setupDesktop();

	code = 0;
}


Desktop::~Desktop()
{
	int msgs[] = {LM_GETREVID, LM_REPAINT, LM_REFRESH, 0};

	SendMessage(hParent, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	RemoveBangCommand("!DesktopSetClick");
	RemoveBangCommand("!DesktopSetArea");

	resetMinMax();

	destroyWindow();

	cleanDesktop();
}


// --------------------------------------------------------
// Sets maximized windows size
// --------------------------------------------------------
void Desktop::setMinMax(void)
{
	RECT r = {screenLeft, screenTop, screenWidth, screenHeight};
	multipleSDA = false;

	EnumDisplayMonitors(NULL, NULL, MultipleDesktopAreaEnumProc, 0);
	if (multipleSDA)
	{
		if (setDesktopArea)
		{
			RECT rcMain = {0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)};
			if (sdaRight <= 0)
				r.right = rcMain.right + sdaRight;
			else
				r.right = sdaRight;
			if (sdaBottom <= 0)
				r.bottom = rcMain.bottom + sdaBottom;
			else
				r.bottom = sdaBottom;
			SetDesktopArea(r.left, r.top, r.right, r.bottom);
		}
		return ;
	}

	if (setDesktopArea)
	{
		r.left = sdaLeft;
		r.top = sdaTop;
		if (sdaRight <= 0)
			r.right = r.right + sdaRight;
		else
			r.right = sdaRight;
		if (sdaBottom <= 0)
			r.bottom = r.bottom + sdaBottom;
		else
			r.bottom = sdaBottom;
	}
	if (setDesktopAreaMainMonitorOnly)
	{
		RECT rcMain = {0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)};
		if (sdaRight <= 0)
			r.right = rcMain.right + sdaRight;
		else
			r.right = sdaRight;
		if (sdaBottom <= 0)
			r.bottom = rcMain.bottom + sdaBottom;
		else
			r.bottom = sdaBottom;
		EnumDisplayMonitors(NULL, NULL, DesktopAreaEnumProc, (LPARAM)&rcMain);
	}

#ifdef _DEBUG
	sprintf(szdebugBuffer, "left: %i top: %i right: %i bottom: %i",
	          r.left, r.top, r.right, r.bottom);
	_LSDEBUG2("New Work Area", szdebugBuffer);
#endif // _DEBUG

	SetDesktopArea(r.left, r.top, r.right, r.bottom);
}


//---------------------------------------------------------
// Reset to old maximized windows size
//---------------------------------------------------------
void Desktop::resetMinMax(void)
{
	EnumDisplayMonitors(NULL, NULL, DesktopAreaResetEnumProc, 0);
}


void Desktop::setupDesktop()
{
	FILE* f;
	char szDisplayChange[MAX_LINE_LENGTH+1];

	numMonitors = 1;

	setDesktopArea = GetRCBool("SetDesktopArea", true) != FALSE;
	setDesktopAreaMainMonitorOnly = GetRCBool("SetDesktopAreaMainMonitorOnly", true) != FALSE;
	sdaLeft = GetRCInt("SDALeft", 0);
	sdaRight = GetRCInt("SDARight", 0);
	sdaTop = GetRCInt("SDATop", 0);
	sdaBottom = GetRCInt("SDABottom", 0);
	szDisplayChange[0] = '\0';
	GetRCString("DesktopOnDisplayChange", szDisplayChange, "", MAX_LINE_LENGTH);
	bangDisplayChange = szDisplayChange;

	// Set the default right click to !popup
	bangClicks.insert(mapClicks::value_type((UINT)MOD_RBUTTON, "!popup"));

	f = LCOpen(NULL);
	if (f)
	{
		char	buffer[4096];
		char	token1[4096], token2[4096], extra_text[4096];
		char*	tokens[2];

		tokens[0] = token1;
		tokens[1] = token2;

		buffer[0] = 0;

		while (LCReadNextConfig (f, "*Desktop", buffer, sizeof (buffer)))
		{
			int count;

			token1[0] = token2[0] = extra_text[0] = '\0';

			count = LCTokenize (buffer, tokens, 2, extra_text);

			if (count == 2)
			{

				UINT nModifier = 0;
				nModifier = parseLine(token2);

				mapClicks::iterator itClicks;
				itClicks = bangClicks.find(nModifier);
				if (itClicks != bangClicks.end())
				{
					bangClicks.erase(itClicks);
				}
				bangClicks.insert(mapClicks::value_type(nModifier, extra_text));
			}
		}
	}
	LCClose(f);

	setMinMax();
}

UINT Desktop::parseLine(LPSTR line)
{
	char* tmp;
	UINT nModifier = 0;

	tmp = strtok(line, "+");

	if (!strcmpi(tmp, "lbutton"))
		nModifier |= MOD_LBUTTON;
	if (!strcmpi(tmp, "mbutton"))
		nModifier |= MOD_MBUTTON;
	if (!strcmpi(tmp, "rbutton"))
		nModifier |= MOD_RBUTTON;
	if (!strcmpi(tmp, "x1button"))
		nModifier |= MOD_XBUTTON1;
	if (!strcmpi(tmp, "x2button"))
		nModifier |= MOD_XBUTTON2;

	if (nModifier == 0)
		return 0;

	tmp = strtok(NULL, "+");

	while (tmp)
	{
		if (!strcmpi(tmp, "lbutton"))
			nModifier |= MK_LBUTTON;
		if (!strcmpi(tmp, "mbutton"))
			nModifier |= MK_MBUTTON;
		if (!strcmpi(tmp, "rbutton"))
			nModifier |= MK_RBUTTON;
		if (!strcmpi(tmp, "x1button"))
			nModifier |= MK_XBUTTON1;
		if (!strcmpi(tmp, "x2button"))
			nModifier |= MK_XBUTTON2;
		if (!strcmpi(tmp, "ctrl"))
			nModifier |= MK_CONTROL;
		if (!strcmpi(tmp, "shift"))
			nModifier |= MK_SHIFT;
		if (!strcmpi(tmp, "alt"))
			nModifier |= MK_MENU;
		if (!strcmpi(tmp, "apps"))
			nModifier |= MK_APPS;
		if (!strcmpi(tmp, "lwin"))
			nModifier |= MK_LWIN;
		if (!strcmpi(tmp, "rwin"))
			nModifier |= MK_RWIN;
		tmp = strtok(NULL, "+");
	}

	return nModifier;
}
void Desktop::cleanDesktop()
{
	bangClicks.clear();
}
//=========================================================
// Registered messages
//=========================================================

void Desktop::windowProc(Message& message)
{
	BEGIN_MESSAGEPROC
	//MESSAGE(onCreate,            WM_CREATE)
	//MESSAGE(onDestroy,           WM_DESTROY)
	MESSAGE(onActivate, WM_ACTIVATE)
	MESSAGE(onDisplayChange, WM_DISPLAYCHANGE)
	MESSAGE(onEndSession, WM_ENDSESSION)
	MESSAGE(onEndSession, WM_QUERYENDSESSION)
	MESSAGE(onEraseBkgnd, WM_ERASEBKGND)
	MESSAGE(onGetRevId, LM_GETREVID)
	MESSAGE(onKeyMessage, WM_KEYDOWN)
	MESSAGE(onKeyMessage, WM_KEYUP)
	MESSAGE(onKeyMessage, WM_HOTKEY)
	MESSAGE(onMouseActivate, WM_MOUSEACTIVATE)
	MESSAGE(onMouseButtonDown, WM_LBUTTONDOWN)
	MESSAGE(onMouseButtonDown, WM_MBUTTONDOWN)
	MESSAGE(onMouseButtonDown, WM_RBUTTONDOWN)
	MESSAGE(onMouseButtonDown, WM_XBUTTONDOWN)
	MESSAGE(onMouseButtonUp, WM_LBUTTONUP)
	MESSAGE(onMouseButtonUp, WM_MBUTTONUP)
	MESSAGE(onMouseButtonUp, WM_RBUTTONUP)
	MESSAGE(onMouseButtonUp, WM_XBUTTONUP)
	MESSAGE(onSysCommand, WM_SYSCOMMAND)
	MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
	MESSAGE(onRefresh, LM_REFRESH)
	END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================

void Desktop::onActivate(Message& message)
{
	// Tells litestep it has been selected
	SendMessage(hParent, LM_LSSELECT, 0, 0);
	if (message.wParamLo == WA_ACTIVE || message.wParamLo == WA_CLICKACTIVE)
	{
		SetActiveWindow(hParent);
	}
}


void Desktop::onDisplayChange(Message& message)
{
	SetWindowPos(hWnd, HWND_BOTTOM, SCREEN_LEFT, SCREEN_TOP, SCREEN_WIDTH,
	             SCREEN_HEIGHT, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOSENDCHANGING);
	setMinMax();

	if (bangDisplayChange.length() > 1)
	{
		LSExecute(hWnd, bangDisplayChange.c_str(), 0);
	}
}


void Desktop::onEndSession(Message& message)
{
	message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onEraseBkgnd(Message& message)
{
	PaintDesktop((HDC)(message.wParam));
	message.lResult = TRUE;
}


void Desktop::onGetRevId(Message& message)
{
	LPSTR buf = (LPSTR)(message.lParam);

	switch (message.wParam)
	{
		case 0:
		sprintf(buf, "desktop.dll: %s", &rcsRevision[11]);
		buf[strlen(buf) - 1] = '\0';
		break;
		case 1:
		strcpy(buf, &rcsId[1]);
		buf[strlen(buf) - 1] = '\0';
		break;
		default:
		strcpy(buf, "");
	}
	message.lResult = strlen(buf);
}


void Desktop::onKeyMessage(Message& message)
{
	// Forward these messages
	PostMessage(hParent, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onMouseActivate(Message& message)
{
	// Tells litestep it has been selected
	PostMessage(hParent, LM_LSSELECT, 0, 0);
	// Close any popup open
	//SendMessage(hParent, LM_HIDEPOPUP, (int)(message.lParamHi), (int)(message.lParamLo));
	message.lResult = MA_NOACTIVATE;
}


void Desktop::onMouseButtonDown(Message& message)
{
	SendMessage(hParent, LM_HIDEPOPUP, (int)(message.lParamHi), (int)(message.lParamLo));
}


void Desktop::onMouseButtonUp(Message& message)
{
	UINT nModifier = 0;

	switch (message.uMsg)
	{
		case WM_LBUTTONUP:
		nModifier = MOD_LBUTTON;
		break;
		case WM_RBUTTONUP:
		nModifier = MOD_RBUTTON;
		break;
		case WM_MBUTTONUP:
		nModifier = MOD_MBUTTON;
		break;
		case WM_XBUTTONUP:
		switch (GET_XBUTTON_WPARAM(message.wParam))
		{
			case XBUTTON1:
			nModifier = MOD_XBUTTON1;
			break;
			case XBUTTON2:
			nModifier = MOD_XBUTTON2;
			break;
		}
		message.lResult = true;
		break;
		default:
		return ;
	}
	nModifier |= message.wParam;

	if (GetKeyState(VK_APPS) < 0)
		nModifier |= MK_APPS;
	if (GetKeyState(VK_MENU) < 0)
		nModifier |= MK_MENU;
	if (GetKeyState(VK_LWIN) < 0)
		nModifier |= MK_LWIN;
	if (GetKeyState(VK_RWIN) < 0)
		nModifier |= MK_RWIN;

	mapClicks::iterator itClicks;
	itClicks = bangClicks.find(nModifier);
	if (itClicks != bangClicks.end())
	{
		LSExecute(hWnd, (*itClicks).second.c_str(), 0);
	}
}


void Desktop::onSysCommand(Message& message)
{
	if (message.wParam == SC_CLOSE)
		PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
	else
		message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void Desktop::onWindowPosChanging(Message& message)
{
	WINDOWPOS *c = (WINDOWPOS*)(message.lParam);

	c->hwndInsertAfter = HWND_BOTTOM;
	c->flags |= SWP_NOMOVE | SWP_NOSIZE;
}

void Desktop::onRefresh(Message& message)
{
	cleanDesktop();

	resetMinMax();

	screenLeft = SCREEN_LEFT;
	screenTop = SCREEN_TOP;
	screenWidth = SCREEN_WIDTH;
	screenHeight = SCREEN_HEIGHT;

	SetWindowPos(hWnd, HWND_BOTTOM, SCREEN_LEFT, SCREEN_TOP, SCREEN_WIDTH,
	             SCREEN_HEIGHT, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOSENDCHANGING);

	setupDesktop();
}

//=========================================================
// Bang command handling
//=========================================================

void Desktop::bangSetClick(LPCSTR args)
{
	if (args)
	{
		char	buffer[4096];
		char	token1[4096], extra_text[4096];
		char*	tokens[1];

		tokens[0] = token1;

		strcpy(buffer, args);

		int count;

		token1[0] = extra_text[0] = '\0';

		count = LCTokenize (buffer, tokens, 1, extra_text);

		if (count == 1)
		{

			UINT nModifier = 0;
			nModifier = parseLine(token1);

			mapClicks::iterator itClicks;
			itClicks = bangClicks.find(nModifier);
			if (itClicks != bangClicks.end())
			{
				bangClicks.erase(itClicks);
			}
			bangClicks.insert(mapClicks::value_type(nModifier, extra_text));
		}
	}
}


void Desktop::bangSetArea(LPCSTR args)
{
	char token[MAX_LINE_LENGTH];
	LPCSTR nextToken = args;

	if (GetToken(nextToken, token, &nextToken, FALSE))
		sdaLeft = atoi(token);
	if (GetToken(nextToken, token, &nextToken, FALSE))
		sdaTop = atoi(token);
	if (GetToken(nextToken, token, &nextToken, FALSE))
		sdaRight = atoi(token);
	if (GetToken(nextToken, token, &nextToken, FALSE))
		sdaBottom = atoi(token);
	setMinMax();
}


//Get and set the multiple workareas
BOOL CALLBACK MultipleDesktopAreaEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam)
{
	char config[32];
	bool isFoundSDA = false;
	RECT rcSDA;

	// get the exec command
	sprintf( config, "SetDesktopArea%d", numMonitors );
	isFoundSDA = GetRCBool(config, true) != FALSE;
	if (isFoundSDA)
	{
		multipleSDA = true;
		sprintf( config, "SDALeft%d", numMonitors );
		rcSDA.left = GetRCInt(config, 0);
		sprintf( config, "SDARight%d", numMonitors );
		rcSDA.right = GetRCInt(config, 0);
		sprintf( config, "SDATop%d", numMonitors );
		rcSDA.top = GetRCInt(config, 0);
		sprintf( config, "SDABottom%d", numMonitors );
		rcSDA.bottom = GetRCInt(config, 0);

		prc->left += rcSDA.left;
		prc->top += rcSDA.top;
		if (rcSDA.bottom <= 0)
			prc->bottom += rcSDA.bottom;
		else
			prc->bottom = rcSDA.bottom;
		if (rcSDA.right <= 0)
			prc->right += rcSDA.right;
		else
			prc->right = rcSDA.right;

#ifdef _DEBUG

		sprintf(szdebugBuffer, "left: %i top: %i right: %i bottom: %i",
		        prc->left, prc->top, prc->right, prc->bottom);
		_LSDEBUG2("Multiple SDA", szdebugBuffer);
#endif // _DEBUG

		SystemParametersInfo(SPI_SETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
		//SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
		numMonitors++;
	}

	return true;
}


// Reset the desktop area for each monitor to the max
BOOL CALLBACK DesktopAreaResetEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam)
{
#ifdef _DEBUG
	sprintf(szdebugBuffer, "left: %i top: %i right: %i bottom: %i",
	        prc->left, prc->top, prc->right, prc->bottom);
	_LSDEBUG2("resetMinMax", szdebugBuffer);
#endif // _DEBUG

	SystemParametersInfo(SPI_SETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
	//SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
	return true;
}


// Set the desktop area for everymonitor but the first to the max
BOOL CALLBACK DesktopAreaEnumProc(HMONITOR hMonitor, HDC gdc, LPRECT prc, LPARAM lParam)
{
#ifdef _DEBUG
	sprintf(szdebugBuffer, "left: %i top: %i right: %i bottom: %i",
	        prc->left, prc->top, prc->right, prc->bottom);
	_LSDEBUG2("setMinMax", szdebugBuffer);
#endif // _DEBUG

	PRECT pr = (PRECT)lParam;
	if (!EqualRect(pr, prc))
	{
		SystemParametersInfo(SPI_SETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
	}
	//SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)prc, SPIF_SENDCHANGE);
	return true;
}
