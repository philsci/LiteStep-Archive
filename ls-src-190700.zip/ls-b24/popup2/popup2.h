#ifndef __POPUP2_H
#define __POPUP2_H

#ifndef STRICT
#define STRICT
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _UNICODE // yea! we can define unicode to make an NT version
#define _string wstring // and it will be alot quicker, than the default ansi version
#else // running on NT
#define _string string
#endif


#pragma	warning(disable: 4786) // STL naming warnings
#include <windows.h>
#include "../lsapi/lsapi.h"
#include <vector>
#include <string>

using namespace std;

class Bitmap {
public:
  HBITMAP bitmap;
  HRGN region;
  _string name;
  int x;
  int y;
  COLORREF backColor;
  COLORREF foreColor;

  Bitmap();
  ~Bitmap();
};

class Popup;

class menuItem {
public:
    
  menuItem();
	menuItem(LPCSTR lpszText, LPCSTR lpszCommand, LPCSTR lpszParams = NULL, Popup* pop = NULL);
	~menuItem();

	_string name;
	_string command;
	_string params;

  enum itemType {mi_basic, mi_folder, mi_static, mi_dynamic, mi_tasks};
	itemType type;

  Popup* parent;
  Popup* child;

  HICON hIcon;
};

typedef vector<menuItem> menuItems;

class Popup {
public:
  Popup();
  ~Popup();

private:
  menuItems items;
};

class BasePopup: public Popup {
public:
  _string title;

  Bitmap* popBMP;
  Bitmap* backBMP;
  Bitmap* titleBMP;
  Bitmap* selectBMP;
  Bitmap* bottomBMP;


public:
  BasePopup(LPCSTR name);
  ~BasePopup();
};



#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif  /* __POPUP2_H */
