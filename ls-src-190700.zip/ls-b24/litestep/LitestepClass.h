#pragma warning(disable: 4786)
#include "../core/ifcs.h"
#include <map>
#include <string>

using namespace std;

class Litestep : public ILitestep  
{
	long refCount;
	typedef map<wstring, void*> IFCMap;

	IFCMap WindowListMap;
	IFCMap MessageManagerMap;
	IFCMap ModuleManagerMap;
	IFCMap BangManagerMap;

public:
	Litestep();
	virtual ~Litestep();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	/////////////////////////////////////////////////////////////////////////////
	// From ILitestep
    HRESULT STDMETHODCALLTYPE GetWindowList( 
        /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE FindWindowList( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IWindowList __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE RegisterWindowList( 
        /* [in] */ BSTR name,
        /* [in] */ IWindowList __RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE UnregisterWindowList( 
        /* [in] */ BSTR name);
    
    HRESULT STDMETHODCALLTYPE GetModuleManager( 
        /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE FindModuleManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IModuleManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE RegisterModuleManager( 
        /* [in] */ BSTR name,
        /* [in] */ IModuleManager __RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE UnregisterModuleManager( 
        /* [in] */ BSTR name);
    
    HRESULT STDMETHODCALLTYPE GetMessageManager( 
        /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE FindMessageManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IMessageManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE RegisterMessageManager( 
        /* [in] */ BSTR name,
        /* [in] */ IMessageManager __RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE UnregisterMessageManager( 
        /* [in] */ BSTR name);
    
    HRESULT STDMETHODCALLTYPE GetBangManager( 
        /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE FindBangManager( 
        /* [in] */ BSTR name,
        /* [retval][out] */ IBangManager __RPC_FAR *__RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE RegisterBangManager( 
        /* [in] */ BSTR name,
        /* [in] */ IBangManager __RPC_FAR *winlist);
    
    HRESULT STDMETHODCALLTYPE UnregisterBangManager( 
        /* [in] */ BSTR name);

};

