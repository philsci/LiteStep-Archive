#ifndef __RE5OURCES_H__
#define __RE5OURCES_H__

#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */

/**
returns an icon that is assosiated with the specified path. the path
may be a file or directory.

@param pszPath string containing the name of the path theat you want the icon from
@return handle to the extracted icon
*/
HICON GetIconFromPath(const char* pszPath);

/**
Returns the icon that is suitable with the window. several different
strategies for obtaining the icon is used

@param hWnd hande to the window that you want the icon from
@param bBigIcon TRUE if you want a big icon, FALSE if you want a small icon
@return handle to the icon
*/
HICON GetIconFromWindow(HWND hWnd, BOOL bBigIcon);

/**
determines if a window should be present in taskmanagers or not

@param hWnd handle to the window to be tested
@return returns TRUE if it is an App window, FALSE it is not an app window
*/
BOOL IsAppWindow(HWND hWnd);

/**
converts the time to internet time (0-1000). Example code:
<code>
 time_t now;
 time(&now);
 printf("@%d", GetInetTime(now));
</code>
@param now is the number of seconds since jan 1 1970 (GMT)
*/
int GetInetTime(long now);

/**
if the window is within nDist of a border it is moved to the border

@param pwPos current position of the window (obtained from WM_WINDOWPOSCHANGING)
@param nDist number of pixels to snapp a window
@param bUseScreenSize TRUE if the screen size should be used. FALSE is the
                      desktop workarea should be used
*/
void SnappWindow(WINDOWPOS* pwPos, int nDist, BOOL bUseScreenSize);

#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif