#include "popup2.h"

Bitmap::Bitmap()
{
  bitmap = NULL;
  region = NULL;
  x = 0;
  y = 0;
  backColor = RGB(255,255,255);
  foreColor = RGB(255,255,255);
}

Bitmap::~Bitmap()
{
  if (bitmap) {
    DeleteObject(bitmap);
    bitmap = NULL;
  }
  if (region) {
    DeleteObject(region);
    region = NULL;
  }
  x = 0;
  y = 0;
  backColor = RGB(255,255,255);
  foreColor = RGB(255,255,255);
}


menuItem::menuItem() {
  type = mi_basic;
  parent = NULL;
  child = NULL;
  hIcon = NULL;
}

menuItem::menuItem(LPCSTR lpszText, LPCSTR lpszCommand, LPCSTR lpszParams /* = NULL */, Popup* pop /* = NULL */) {
  type = mi_basic;
  name = lpszText;
  command = lpszCommand;
  params = lpszParams;
  parent = NULL;
  child = pop;
  hIcon = NULL;
}


Popup::Popup() {

}

Popup::~Popup() {

}


BasePopup::BasePopup(LPCSTR name) {
  char tempText[MAX_LINE_LENGTH+1];

  GetRCString("HotListName", tempText, "", MAX_LINE_LENGTH);
  title = tempText;

  // Popup Background Image
  GetRCString("PopupBackImage", tempText, "", MAX_LINE_LENGTH);
  if (strlen(tempText) != 0) {
    popBMP = new Bitmap;
    popBMP->name = tempText;
  }

  // Popup Title
  GetRCString("PopupTitlePix", tempText, "", MAX_LINE_LENGTH);
  if (strlen(tempText) != 0) {
    titleBMP = new Bitmap;
    titleBMP->name = tempText;
    titleBMP->foreColor = GetRCColor("PopupTitleColor", 0xffffff);
  }

  // Popup Entry
  GetRCString("PopupEntryPix", tempText, "", MAX_LINE_LENGTH);
  if (strlen(tempText) != 0) {
    backBMP = new Bitmap;
    backBMP->name = tempText;
    backBMP->foreColor = GetRCColor("PopupEntryColor", 0x000000);
  }

  GetRCString("PopupSelEntryPix", tempText, "", MAX_LINE_LENGTH);
  if (strlen(tempText) != 0) {
    selectBMP = new Bitmap;
    selectBMP->name = tempText;
    selectBMP->foreColor = GetRCColor("PopupSelEntryColor", 0x000000);
  }

  GetRCString("PopupBottomPix", tempText, "", MAX_LINE_LENGTH);
  if (strlen(tempText) != 0) {
    bottomBMP = new Bitmap;
    bottomBMP->name = tempText;
    bottomBMP->foreColor = GetRCColor("PopupTitleColor", 0xffffff);
  }

}

BasePopup::~BasePopup() {
  if (popBMP)
    delete popBMP;
  if (titleBMP)
    delete titleBMP;
  if (backBMP)
    delete backBMP;
  if (selectBMP)
    delete selectBMP;
  if (bottomBMP)
    delete bottomBMP;

}