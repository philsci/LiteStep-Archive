//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by litestep.rc
//
#define IDS_LITESTEP_ERROR1             1
#define IDS_LITESTEP_ERROR2             2
#define IDS_LITESTEP_ERROR3             3
#define IDS_LITESTEP_TITLE_WARNING      4
#define IDS_LITESTEP_ERROR4             5
#define IDS_LITESTEP_TITLE_ERROR        6
#define IDS_LITESTEP_ERROR5             7
#define IDS_LITESTEP_ERROR6             8
#define IDS_LITESTEP_ERROR7             9
#define IDS_LITESTEP_TITLE_FATAL_ERROR  10
#define IDS_LITESTEP_RECYCLELS          11
#define IDS_LITESTEP_QUITLS             12
#define IDS_LITESTEP_TERMINATELS        13
#define IDS_LITESTEP_RUN                14
#define IDS_LITESTEP_SHUTDOWNWIN        15
#define IDS_LITESTEP_UNINSTALLLS        16
#define IDS_MODULEQUIT_ERROR            17
#define IDS_MODULENOTFOUND_ERROR        18
#define IDS_INITMODULEEXNOTFOUND_ERROR  19
#define IDS_QUITMODULENOTFOUND_ERROR    20
#define IDS_MODULEINITEXCEPTION_ERROR   21
#define IDS_LITESTEP_CREATEWINDOW_ERROR 22
#define IDS_HOOKMGR_CREATETHREAD_ERROR  23
#define IDS_HOOKMGR_LOADHOOK_ERROR      24
#define IDS_LITESTEP_BANGEXCEPTION      25
#define IDS_LITESTEP_REGISTERCLASS_ERROR 26
#define IDI_LS                          101
#define IDD_ABOUT                       102
#define IDI_VER                         103
#define IDD_ABOUTBOX                    104
#define IDI_ICON1                       106
#define IDB_LS                          109
#define IDI_LOGO                        1002
#define IDC_VERSION                     1004
#define IDC_VINFO                       1008
#define IDC_LS                          1009
#define IDC_VER                         1010
#define IDC_HEADER                      1012
#define IDC_TITLE                       1013
#define IDC_LOGO                        1014
#define IDC_COMPILETIME                 1015
#define IDC_COMBOBOX                    1016
#define IDC_LISTVIEW                    1017
#define IDC_THEME_INFO                  1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
