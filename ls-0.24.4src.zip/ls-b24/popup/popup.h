#ifndef __POPUP_H
#define __POPUP_H

#include "../litestep/wharfdata.h"
#include "../lsapi/lsapi.h"

//pre-delc 
class subMenu;

//simple bitmap struct
typedef struct {
	HBITMAP bitmap;
	HRGN region;
	char name[MAX_PATH];
	int x;
	int y;
} BitMP;

//for keeping track of which submenu to reference with each open subwindow HWND
typedef struct {
	HWND subMenuHwnd;
	subMenu * subMenu;
} subMenuHWND;

//temp container for data retreved from file
class fileItem
{
public:	
	fileItem();
	~fileItem();
	char itemName[256];
	char bmpName[256];
	int itemHeight;
	char popupCommand[256];
	char commandParam[256];
	fileItem *next;
};

class menuItem 
{
public:
	char bmp[256];
	char name[256];
	char command[256];
	char params[256];
//	int height;
	int itemLevel;
	int itemNo;		//Position on list so that you don't have to keep a height count
	BOOL isDynamic;
	HICON hIcon;
	menuItem *next; //next menu item in the list
	menuItem *prev; //the item in the list before this
	subMenu *SMenu; //if this item isn't a submenu accessor, this will be NULL
	menuItem()
	{	
		itemLevel = 0; //How deep the item is in the menu structure
//		height = 0;
		itemNo = 0;
		next= NULL;
		prev= NULL;
		isDynamic = FALSE;
		strcpy(params, "\0");
		SMenu = NULL;
		hIcon = NULL;
	}
	~menuItem();
};

class subMenu 
{
public:
	subMenu()
	{
		root = NULL;
		current = NULL;
		subMenuWin = NULL;
		totalHeight = 200;
		isSubOpen = FALSE;
		isSelected = NULL;
		onLeft = FALSE;
		pinned = FALSE;
		region = NULL;
	}

	~subMenu()
	{
		if(root != NULL)
			delete root;
		DestroyWindow(subMenuWin);
	}
	BOOL newMenuItem();
	BOOL isSubOpen;
	BOOL onLeft;
	BOOL pinned;
	menuItem *root;
	menuItem *current;
	menuItem *isSelected;
	int totalHeight;
	int subMenuWidth;
	HWND subMenuWin;
	RECT close;
	HRGN region;
};

//the main popup list container
class popupMenu 
{ 
public:	
	popupMenu()
	{
		root = NULL;
		current = root;
		isSelected = NULL;
		menuWidth = 100;
		subMenuDelay = 0;
		pinned = FALSE;
		onLeft = FALSE;
		region = NULL;
	}

	~popupMenu()
	{
		if(root != NULL)
			delete root;
	}

	BOOL newMenuItem();
	int returnMenuWidth();
	int subMenuDelay;
	menuItem *root; //the root list for the popupmenu
	menuItem *current; //the last item in this list
	menuItem *isSelected;
	char menuName[256]; //name of the list
	int menuWidth; //the minimum width of the popupmenu
	int totalHeight;
	BOOL pinned;	//Whether the menu closes when focus is lost or not
	BOOL onLeft;
	RECT close;
	HRGN region;
};

#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */
__declspec( dllexport ) int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif  /* __LSAPI_H */
