 /*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/****************************************************************************
 11/24/98 - Edwin Man
            Changed default PopupNormalColor to A4A0A0; looks better
 11/24/98 - Fahim Farook
			Changed the popup navigation code to use standardized item heights
			so that the code is more readable and faster
 11/23/98 - Fahim Farook
			Streamlined the transparency code and made it setup and load the 
			region at start up then just set the region when a popup is created
 11/21/98 - Fahim Farook
			Added a working close button to the main popup when pinned
			Modified keyboard navigation so that left and right key functionality
			switches when the current folder is to the left of it's parent
 11/19/98 - Fahim Farook
			Modified popup displaying so that if a popup opens on the left all 
			subfolders will keep on opening to the left so as to avoid the
			clutter that resulted in earlier implementations
			Added the ability to specify colours instead of bitmaps for popup
			background via PopupTitleBack, PopupNormBack & PopupSelBack in
			step.rc
 11/18/98 - Fahim Farook
			Modified icon extraction based on code by Johan Redestig to make it
			more efficient and added an icon deletion routine when quitting to 
			free up resources.
 11/14/98 - Fahim Farook
			Added popup icons via ShowPopupIcons in step.rc and allowed customization
			via PopupDefaultIcon and PopupIconSize
 11/12/98 - Fahim Farook
			Added popup pinning functionality to the main popup and changed
			mouse click responses from LBUTTONDOWN to LBUTTONUP
 11/09/98 - Fahim Farook
			Merged in popup transparency code provided by mian and took out the
			old transparentBltLS stuff
 11/08/98 - Fahim Farook
			Added dynamic popup width sizing support & dynamic folder support
			via the !PopupDynamicFolder command
 11/08/98 - J Redestig
			Sets working directory. Added three utility functions for cleaner
			code (paintFolderArrow, paintPopupBevel, executeItem). Removed
			some flicker from displaySingleItem
 10/31/98 - Fahim Farook
			Added support for popup menu navigation via keyboard
 10/29/98 - Cyberian (Fahim Farook)
			Added support for popupmenu height customization. The title bar
			wouldn't change sizes earlier - now takes its value from PopupSubMenuHeight
			in step.rc
 09/11/98 - M. West
    		New popups created, limited functionality, will parse in a simple
    		1 layer popup menu, and run programs from it,
 30/10/98 - B. Kilian
			Fixed Fixed the popups repainting problem, and the setWindowPos 
			in the paint.
 30/10/98 - J Redestig
			Setforegroundwindow, so the popups get focus correctly, and <ESC> exits popups.
 30/10/98 - T Engel
			Environment substitution for !PopupFolders

****************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include <tchar.h>
#include <process.h>
#include "popup.h"

#define WM_SELECTED    9667
#define WM_NOTSELECTED 9666

BOOL isMainWindowHidden = TRUE;

const char rcsRevision[] = "$Revision: 1.103 $"; // Our Version 
const char rcsId[] = "$Id: popup.cpp,v 1.103 1998/11/28 15:07:39 cyberian Exp $"; // The Full RCS ID.

int previousCounter2 = 0;
int counter2 = 0;
int popupSubHeight = 20;
int popupMinWidth = 100;
int popupIconSize = 20;
int titleHeight = 20;

HWND itemCaller = NULL;
menuItem *previousItem = NULL;	

BOOL noPopupBevel;
int popupLevel = 0;
HFONT popupFont;
int popupFontHeight;
char popupFontFace[256];
HICON popupDefaultIcon;
int popupTextOffset;
int popupTop;
COLORREF titleColor, selColor, normColor;
COLORREF titleBack,selBack, normBack;
BOOL noPopupPix = FALSE;
BOOL transBlt=TRUE;
BOOL popupFolderIcon=TRUE;
BOOL showPopupIcons = FALSE;
WNDCLASS wc;
const char szAppName[] = "PopupMenu"; // Our window class, etc

WNDCLASS subM;
const char popupSubName[] = "subPopupMenu"; // Our window class, etc

popupMenu popup; //popup class struct
fileItem *popupFile;  //rc file info holder
subMenuHWND subList[255]; //popup submenu pointer struct

int subEnum = 0; //submenu counter

HINSTANCE appInstance;
int yy;
HWND parent;
HWND hMainWnd = NULL;

BOOL timerIdent = FALSE;
BOOL wentRight[255];

menuItem *timerPointer = NULL;
int timerHeight = 0;

BitMP backBMP;
BitMP titleBMP;
BitMP selectBMP;
BitMP bottomBMP;

BOOL goingToSubMenu = FALSE;
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
int fillDirectory(char *dirName, menuItem *target);
void displaySubMenu(HWND calledFrom, menuItem *item, int height);
LRESULT CALLBACK PopupWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void displaySingleMenuItem(HWND hwnd, menuItem *item, int totalHeight, BOOL selected);
void closePopupSubMenu(HWND subMenu);
void initializePopupMenu();
void displayPopup(HWND hwnd, int x, int y);
void PaintSubMenu(int i);
void PaintPopup(HWND hwnd);
void keyedSubMenu(HWND Menu, menuItem *showItem);
void GetItemIcon(void *item);
void RegistryLookup(char* subKey, char *value);
menuItem *GetItem(menuItem *root, int num);
HRGN GetRegion(menuItem *item);

// Paints the |> icon on a hDC
// hDC - The device context to be painted upon
// item - the menuitem that contains the |> icon
// totalHeight - the y posiiton of the |> icon
void paintFolderArrow(HWND hwnd, menuItem *item, int totalHeight, int width);

// Paints the bevel around a menuitem (maybe the DrawEdge function is better?)
// hDC - the device context to be painted upon
// item - the menuItem that is surounded by the bevel
// totalHeight - the y position of the bevel
void paintPopupBevel(HWND hwnd, menuItem* item, int totalHeight, int width);

// Uses shellexecite to invoke the command that pItem is poining at.
// (sets working folder as well)
// pItem - the menu item that shall be executed
void executeItem(menuItem* pItem);

POINT pt; 
POINT currentRootLocation;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//BEGIN CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

menuItem::~menuItem()
    {
    	if(next != NULL)
    		delete next;
    	if(SMenu != NULL)
    		delete SMenu;
		if (hIcon != NULL)
			DeleteObject(hIcon);
    }

BOOL popupMenu::newMenuItem()
{
    menuItem *temp = root;
	menuItem *tprv = NULL;
    
    while(1) //finds the last node in the list
    {
    	if(temp == NULL)
    		break;
		else if(temp->next == NULL) {
			tprv = temp;
    		break;
		} else {
			tprv = temp;
			temp = temp->next;
		}
    }
    
    if(temp == NULL)
    {
    	root = new menuItem;
    	root->next = NULL;
		root->prev = NULL;
    	current = root;
    }
    
    else 
    {
    	temp->next = new menuItem;
    	current = temp->next;
		current->prev = tprv;
    }
    
    return(TRUE);
}


int popupMenu::returnMenuWidth()
{
    return(menuWidth);
}


fileItem::fileItem()
{
    strcpy(itemName, "\0");
    strcpy(bmpName, " ");
    strcpy(popupCommand, " ");
    next = NULL;
    itemHeight = popupSubHeight;
}

fileItem::~fileItem()
{
    delete next;
}


BOOL subMenu::newMenuItem()
{
    menuItem *temp = root;
	menuItem *tprv = NULL;
    
    while(1) //finds the last node in the list
    {
    	if(temp == NULL)
    		break;
		else if(temp->next == NULL) {
			tprv = temp;
    		break;
		} else {
			tprv = temp;
			temp = temp->next;
		}
    }
    
    if(temp == NULL)
    {
    	root = new menuItem;
    	current = root;
    }
    
    else 
    {
    	temp->next = new menuItem;
    	current = temp->next;
		current->prev = tprv;
    }
    
    return(TRUE);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//END CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

menuItem *GetItem(menuItem *root, int num) {
	menuItem *temp = root;
	while (temp != NULL) {
		if (temp->itemNo == num)
			break;
		temp = temp->next;
	}
	return temp;
}

void destroyCurrentSubMenu()
{
    DestroyWindow((HWND)subList[subEnum].subMenuHwnd);
//	subList[subEnum].subMenu->isSubOpen = FALSE;
	subList[subEnum].subMenu->onLeft = FALSE;
    subList[subEnum].subMenuHwnd = NULL;
    subList[subEnum].subMenu = NULL;
    subEnum--;
}

void destroyAllSubMenus()
{
    for(int i = 0;i <= subEnum; i++) {
		__try {
			DestroyWindow((HWND)subList[i].subMenuHwnd);
//			subList[i].subMenu->isSubOpen = FALSE;
			subList[i].subMenu->onLeft = FALSE;
		 	subList[i].subMenuHwnd = NULL;
			subList[i].subMenu = NULL;
			wentRight[i] = FALSE;
		} __except(GetExceptionCode()==EXCEPTION_ACCESS_VIOLATION) {}
    } 
   	subEnum = 0;
}

//cleanup, not much to do
int quitModule(HINSTANCE dllInst)
{
    destroyAllSubMenus();
    DestroyWindow(hMainWnd);
    DeleteObject(popupFont);
	if (titleBMP.bitmap)
		DeleteObject(titleBMP.bitmap);
	if (backBMP.bitmap)
		DeleteObject(backBMP.bitmap);
	if (selectBMP.bitmap)
		DeleteObject(selectBMP.bitmap);
	if (bottomBMP.bitmap)
		DeleteObject(bottomBMP.bitmap);
	if (showPopupIcons) {
		DeleteObject(popupDefaultIcon);
	}
    UnregisterClass(szAppName,dllInst); // unregister window class
    UnregisterClass(popupSubName,dllInst); // unregister window class
    return 1;
}

//now defunct entry point, will take it out if somone complains
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
    return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

//DLL entry point
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
    appInstance = dllInst;
    parent = ParentWnd;

    //set all menus to NON-selected mode
    //for(int SE = 0; SE < 255; selected[SE] = FALSE, SE++);
    //parse file and fill popup class structure
    initializePopupMenu();
    
    memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc = (WNDPROC)&WndProc;// our window procedure
    //wc.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wc.hInstance = appInstance;			
    wc.lpszClassName = szAppName;// our window class name
    wc.style = 0;

    memset(&subM,0,sizeof(subM));
    subM.lpfnWndProc = (WNDPROC)&PopupWndProc;// our window procedure
    //subM.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    subM.hInstance = appInstance;			
    subM.lpszClassName = popupSubName;// our window class name
    subM.style = 0;

    if (!RegisterClass(&wc)) 
    {
    	MessageBox(NULL,"Error registering window class",szAppName,MB_OK);
    	return 1;
    }

    if (!RegisterClass(&subM)) 
    {
    	MessageBox(NULL,"Error registering window class",szAppName,MB_OK);
    	return 1;
    }

    hMainWnd = CreateWindowEx(
        	WS_EX_TOPMOST|WS_EX_TOOLWINDOW,//WS_EX_TRANSPARENT,									// exstyles 
    		szAppName,								// our window class name
    		"",											// use description for a window title
    		WS_POPUP,				
    		0, 0,									// position 
    		popup.menuWidth,(popup.totalHeight + (titleHeight*2)),				// width & height of window
    		ParentWnd,								// parent window 
    		NULL,									// no menu
    		appInstance,								// hInstance of DLL
    		NULL);									// no window creation data

    SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	if (transBlt && !noPopupPix) {
		SetWindowRgn(hMainWnd, popup.region, FALSE);
	}
    //create the message id's that popup.dll will use
    int Msgs[10];
    Msgs[0] = LM_POPUP;
    Msgs[1] = LM_HIDEPOPUP;
    Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
    SendMessage (ParentWnd, LM_REGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	
	for (int i=0; i<256; i++)
		wentRight[i] = FALSE;
    return 0;
}

// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    POINT pt; RECT r;
    WORD fActive;
    HWND hwndGetFocus;
    int p;
    
    menuItem *temp = NULL;
    //makes a temp pointer to the root of our popup tree, 
    menuItem *item = popup.root;
   	GetCursorPos(&pt);
   	GetWindowRect(hwnd, &r);
   	pt.x -= r.left;
   	pt.y -= r.top;

    switch (message) {
	case LM_GETREVID: {
		char *buf = (char *) lParam;

		if (wParam == 0) {
			strcpy(buf, "popup.dll: ");
			strcat(buf, &rcsRevision[11]);
			buf[strlen(buf)-1] = '\0';
		} else if (wParam == 1) {
			strcpy(buf, &rcsId[1]);
			buf[strlen(buf)-1] = '\0';
		} else {
			strcpy(buf, "");
		}
		return strlen(buf);
	}
    
	case LM_POPUP:
 		GetCursorPos(&pt);
		displayPopup(hwnd, pt.x, pt.y);
		SetForegroundWindow(hwnd);
		return 0;

    case WM_PAINT:
        PaintPopup(hwnd);
		if (popup.pinned) {
			DrawFrameControl(GetDC(hwnd), &popup.close, DFC_CAPTION, DFCS_CAPTIONCLOSE|DFCS_FLAT);
		}
    	return 0;

	case WM_ERASEBKGND:
		return 0;

    case WM_LBUTTONUP:
		if (pt.y > titleHeight) {
			int itemNo = pt.y / popupSubHeight;
			item = GetItem(popup.root, itemNo);
   			if(item->SMenu == NULL) {
    			char temp[256];
   				strcpy(temp, item->command);
   				destroyAllSubMenus();
   				if(item->command[0] != '!')
   				{
					executeItem(item);
   				}
   				else
   					ParseBangCommand (hwnd, item->command, item->params);
   				
   				previousItem = NULL;
   				isMainWindowHidden = TRUE;
				popup.isSelected = NULL;
   				ShowWindow(hwnd, SW_HIDE );
   				break;
			} else if(item->SMenu != subList[subEnum].subMenu) {
   				if(subEnum > 0)
   					destroyAllSubMenus();
   				else {
   					goingToSubMenu = TRUE;
   					displaySubMenu(hwnd,item, item->itemNo*popupSubHeight);
   				}
   				break;
   			}
   			break;
		}
    	break;		

    case WM_TIMER:
    	if(timerPointer == NULL)
    		break;
    	if(timerPointer->SMenu->root->itemLevel == 1 && 
    		timerPointer->SMenu != subList[subEnum].subMenu)
    	{
    		destroyAllSubMenus();
    		displaySubMenu(hwnd, timerPointer, (timerPointer->itemNo*popupSubHeight)+titleHeight);
    		timerPointer = NULL;
    		KillTimer(hwnd, 0);
    	}
    	break;
    case WM_MOUSEMOVE: 
	{
	    int y = HIWORD(lParam); 
		int prevHeight;
		int itemNo = y / popupSubHeight;
		item = GetItem(popup.root, itemNo);

		if (previousItem == item)
			break;
		if(y < titleHeight || previousItem == NULL) {
			// Do nothing
		} else {
			prevHeight = (previousItem->itemNo*popupSubHeight);
			if(y < prevHeight || y > prevHeight || previousItem->itemLevel > 0)
    		{
    			if(previousItem != popup.isSelected && previousItem->itemLevel > 0)
    			{
    				temp = popup.isSelected;
    			}
    			else
    			{
    				temp = previousItem;
    			}
    			displaySingleMenuItem(hwnd, temp, temp->itemNo*popupSubHeight, FALSE);			
    			timerPointer = NULL;
    		}
		}
		if(y < titleHeight) {
			//Do nothing
		} else {
			if(previousItem == NULL) {
				//Do nothing?
			} else if(subEnum != 0 && previousItem->SMenu != subList[subEnum].subMenu) {
				destroyAllSubMenus();
			}
			displaySingleMenuItem(hwnd, item, item->itemNo*popupSubHeight, TRUE);
			popup.isSelected = item;
			previousItem = item;
    		if(item->SMenu != NULL && subList[subEnum].subMenu != item->SMenu)
			{
   				if(timerPointer != item)
   				{
   					SetTimer(hwnd, 0, popup.subMenuDelay, NULL);
   					timerPointer = item;
   				}
   			}
   		}
    	break;
	}
    //so you can move the window around, will implement more here later
    case WM_NCHITTEST:
    	if(pt.y < titleHeight)
    	{
			if(previousItem == NULL) {
				//Do nothing
			}
    		else if(previousItem->itemLevel == 0)
    		{
    			displaySingleMenuItem(hwnd, previousItem, previousItem->itemNo*popupSubHeight, FALSE);			
    			previousItem = NULL;
    			timerPointer = NULL;
    		}
    		else
    		{
    			displaySingleMenuItem(hwnd, popup.isSelected, popup.isSelected->itemNo*popupSubHeight, FALSE);			
    			previousItem = NULL;
    			timerPointer = NULL;
    			}
    			destroyAllSubMenus();
				if (popup.pinned) {
					if (PtInRect(&popup.close, pt)) {
						return (HTCLOSE);
					} else
						return (HTCAPTION);
				} else
    				return (HTCAPTION);
    	}
    	else break;
    case WM_NCLBUTTONDBLCLK:
		if (!popup.pinned) {
			popup.pinned = TRUE;
			InvalidateRect(hwnd, NULL, FALSE);
//			UpdateWindow(hwnd);
		}
		break;
	case WM_NCLBUTTONDOWN:
		if (popup.pinned) {
			if (PtInRect(&popup.close, pt)) {
				popup.pinned = FALSE;
				SendMessage(hwnd, WM_ACTIVATE, MAKEWPARAM(WA_INACTIVE, 0), NULL);
			}
		}
		break;
    case WM_ACTIVATE:
    	fActive = LOWORD(wParam);
    	if(fActive == WA_INACTIVE)
    	{
    		hwndGetFocus = (HWND)lParam; // handle of window receiving focus 
    		
    		if(goingToSubMenu == TRUE)
    			break;
    		p = 1;
    		do
    		{
    			if(subList[p].subMenuHwnd == hwndGetFocus && subList[p].subMenuHwnd !=NULL)
    				return 0;
    			p++;
    		}while(p < (subEnum +1));
			if (!popup.pinned) {
	    		previousItem = NULL;
    			isMainWindowHidden = TRUE;
	    		timerPointer = NULL;
				popup.isSelected = NULL;
    			ShowWindow(hwnd, SW_HIDE );
    			destroyAllSubMenus();
	    		return 0;
			}
    	}
    	break;	

    case WM_SYSCOMMAND:
    	{
    	switch (wParam)
    		{
    		case SC_CLOSE:
    			PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
    			return 0;
    		default:
    			return DefWindowProc(hwnd,message,wParam,lParam);
    		}
    	}

    case WM_NCDESTROY:
    case WM_CLOSE:
    case WM_DESTROY:
    case WM_QUIT:
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
    	break;
    	//		return SendMessage(parent,message,wParam,lParam);

	case WM_KEYDOWN:          
		switch (wParam) {
		case VK_ESCAPE: // Main popup
			// Destroy the popup menu if the user hits ESCAPE
			destroyAllSubMenus();
			isMainWindowHidden = TRUE;
			popup.isSelected = NULL;
			ShowWindow(hwnd, SW_HIDE);
			break;

		case VK_DOWN: // Main popup
			if (subEnum > 0) {
				if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->next);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
				} else {
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->root);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
				}
			} else {
				if (popup.isSelected !=NULL && popup.isSelected->next != NULL)
					keyedSubMenu(hwnd, popup.isSelected->next);
				else
					keyedSubMenu(hwnd, popup.root);
			}
			break;
		case VK_UP: // Main popup
			if (subEnum > 0) 
			{
				if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) 
				{
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->current);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
				} else 
				{
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->prev);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->prev;
				}

			} else 
			{
				if (popup.isSelected == NULL)
				{
					keyedSubMenu(hwnd, popup.current);
				}
				else
				{
					if (popup.isSelected != popup.root) 
					{
						keyedSubMenu(hwnd, popup.isSelected->prev);
					} else 
					{
						keyedSubMenu(hwnd, popup.current);
					}
				}
			}
			break;
		case VK_RIGHT: // Main popup
			if (subEnum > 0) {
				if (subList[subEnum].subMenu->onLeft) {
					wentRight[subEnum] = FALSE;
					subList[subEnum].subMenu->isSelected = NULL;
					if (subList[subEnum].subMenu->root->itemLevel == 1) {
						destroyCurrentSubMenu();
						keyedSubMenu(hMainWnd, popup.isSelected);
					} else { 
						destroyCurrentSubMenu();
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
					}
				}
			}
    		break;
		case VK_LEFT: // Main popup
			if (subEnum > 0) {
				if (!subList[subEnum].subMenu->onLeft) {
					wentRight[subEnum] = FALSE;
					subList[subEnum].subMenu->isSelected = NULL;
					if (subList[subEnum].subMenu->root->itemLevel == 1) {
						destroyCurrentSubMenu();
						keyedSubMenu(hMainWnd, popup.isSelected);
					} else { 
						destroyCurrentSubMenu();
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
					}
				}
			}
    		break;
		case VK_RETURN: // Main popup
			if (previousItem != NULL && previousItem->itemLevel == 0) {
	    		if(previousItem->SMenu == NULL) {
	    			char temp[256];
					strcpy(temp, previousItem->command);
	    			destroyAllSubMenus();
	    			if(previousItem->command[0] != '!') {
						executeItem(previousItem);
					} else
	    				ParseBangCommand (hwnd, previousItem->command, previousItem->params);
	    			previousItem = NULL;
					previousCounter2 =0;
    				counter2 = 0;
    				isMainWindowHidden = TRUE;
					popup.isSelected = NULL;
    				ShowWindow(hwnd, SW_HIDE );
	    			break;
				}
			}
			break;
		}
		break;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}


void displaySingleMenuItem(HWND hwnd, menuItem *item, int totalHeight, BOOL selected)
{
    HDC DC, memDC;
    PAINTSTRUCT ps;
    HFONT oldFont;
	HBRUSH hBrush;
    RECT r;
	static menuItem *paintedLastTime = NULL;
	static BOOL bWasSelected = FALSE;

	// Test if it is the same menu item thet we painted last time
	// is so return, this will reduce flicker.
	if(paintedLastTime == item && bWasSelected == selected)
		return;
	else{
		bWasSelected = selected;
		paintedLastTime = item;
	}
	int minWidth;
	if (item->itemLevel>0)
		minWidth = subList[item->itemLevel].subMenu->subMenuWidth;
	else
		minWidth = popup.menuWidth;

   	DC = BeginPaint(hwnd,&ps);
   	memDC = CreateCompatibleDC(DC);
   	DC = GetDC(hwnd);
   	oldFont = (HFONT) SelectObject(DC, popupFont);

    if(selected) {
		if (!noPopupPix) {
		   	SelectObject(memDC, selectBMP.bitmap);
   			BitBlt(DC,0,totalHeight, selectBMP.x, popupSubHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(selBack);
			SetRect(&r, 0, totalHeight,minWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
    	SetTextColor(DC,  selColor);
	   	SetBkMode(DC, TRANSPARENT);
    	r.right = selectBMP.x-popupTextOffset;
    } else {
		if (!noPopupPix) {
		   	SelectObject(memDC, backBMP.bitmap);
   			BitBlt(DC,0,totalHeight, backBMP.x, popupSubHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(normBack);
			SetRect(&r, 0, totalHeight,minWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
    	SetTextColor(DC,  normColor);
	   	SetBkMode(DC, TRANSPARENT);
    	r.right = backBMP.x-popupTextOffset;
    }
	//Draw Icon
	if (showPopupIcons) {
		if (item->hIcon != NULL)
			DrawIconEx(DC, popupTextOffset, totalHeight+popupTop, item->hIcon, popupIconSize, popupIconSize, 0, NULL, DI_NORMAL); // DI_DEFAULTSIZE
		r.left = popupTextOffset+popupIconSize+4;
	} else
		r.left = popupTextOffset;
   	r.top= totalHeight;
	r.bottom = totalHeight + popupSubHeight;
   	DrawText(DC, item->name, lstrlen(item->name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);

   	if (!noPopupBevel) {
		paintPopupBevel(hwnd, item, totalHeight, minWidth);
    }
   	// Paint little folder arrow thingy
   	if (item->SMenu != NULL && popupFolderIcon) {
		paintFolderArrow(hwnd, item, totalHeight, minWidth);
   	}
   	SelectObject(DC, oldFont);
	DeleteObject(hBrush);
   	ReleaseDC(hwnd, DC);
   	EndPaint(hwnd,&ps);	
   	DeleteDC(memDC);
}

void paintFolderArrow(HWND hwnd, menuItem *item, int totalHeight, int width)
{
	HDC hDC;
	HPEN hOldPen;

	hDC = GetDC(hwnd);
	// First 2 lines are dark gray
    HPEN hPen = CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
    hOldPen = (HPEN) SelectObject(hDC, hPen);
    MoveToEx(hDC, width-12, totalHeight+popupSubHeight-5, NULL);
    LineTo(hDC, width-12, totalHeight+4);
    LineTo(hDC, width-5, totalHeight+(popupSubHeight/2));
    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);

    // Finish it off with a white line
    hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    hOldPen = (HPEN) SelectObject(hDC, hPen);
    LineTo(hDC, width-12, totalHeight+popupSubHeight-5);
    SelectObject(hDC, hOldPen);
    DeleteObject(hPen);
	ReleaseDC(hwnd, hDC);
}

void paintPopupBevel(HWND hwnd, menuItem* item, int totalHeight, int width)
{
	HDC hDC;
	HPEN hPen;
	HPEN hOldPen;

	hDC = GetDC(hwnd);
	// First we draw the white frame on the left/top
	hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
	hOldPen = (HPEN) SelectObject(hDC, hPen);
	MoveToEx(hDC, 0, totalHeight, NULL);
	LineTo(hDC, width, totalHeight);
	MoveToEx(hDC, 0, totalHeight, NULL);
	LineTo(hDC, 0, totalHeight+popupSubHeight-1);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);

	// Now the black frame on the bottom/right
	hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
	hOldPen = (HPEN) SelectObject(hDC, hPen);
	MoveToEx(hDC, width-1, totalHeight, NULL);
	LineTo(hDC, width-1, totalHeight+popupSubHeight-1);
	MoveToEx(hDC, 0, totalHeight+popupSubHeight-1, NULL);
	LineTo(hDC, width-1, totalHeight+popupSubHeight-1);
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
	ReleaseDC(hwnd, hDC);
}

void executeItem(menuItem* pItem)
{
	SHELLEXECUTEINFO si;
	
	char working_directory[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME]; // not used
	char ext[_MAX_EXT]; // not used

	// calculate the working directory of the executable. if this is
	// not done the program may not find files that it expects to be
	// there. someone complained that this would make quake not start.
	_splitpath(pItem->command, drive, dir, fname, ext);
	strcpy(working_directory, drive);
	strcat(working_directory, dir);

	ZeroMemory(&si, sizeof(si));
	si.cbSize = sizeof(SHELLEXECUTEINFO);

	if(stricmp(ext, ".lnk") == 0)
		// the link files contain their own directory and
		// we should not force any other directory upon it.
		si.lpDirectory = NULL;
	else
		// .exe, .com, .bat, ... often need to be executed from their
		// directory
		si.lpDirectory = working_directory;
		
	si.lpVerb = NULL;
	si.nShow = 1;
	si.fMask = SEE_MASK_DOENVSUBST;
	si.lpFile = pItem->command;
	si.lpParameters = pItem->params;
	ShellExecuteEx(&si);
}

void subFolderInit(menuItem *target, fileItem *item)
{
    subMenu *subMenuItem;
    target->SMenu = new subMenu;
    subMenuItem = target->SMenu;
    popupLevel++;

    item = item->next;
	int count = 1;
    while(item != NULL)
    {
    	if(!stricmp(item->popupCommand, "~folder"))
    		break;
    	
    	subMenuItem->newMenuItem();
    	strcpy(subMenuItem->current->name, item->itemName);
    	strcpy(subMenuItem->current->command, item->popupCommand);
    	strcpy(subMenuItem->current->bmp, item->bmpName);
    	strcpy(subMenuItem->current->params, item->commandParam);
//    	subMenuItem->current->height = item->itemHeight;
    	subMenuItem->current->itemLevel = popupLevel;
		subMenuItem->current->itemNo = count;
    	item = item->next;
		count++;
    }
    popupLevel--;

    menuItem *temper = subMenuItem->root;
    int totalHeight = 0;
	int maxWidth = popupMinWidth;
	SIZE name;
	HDC popDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	SelectObject(popDC, popupFont);
    while(temper != NULL)
    {
    	totalHeight = totalHeight + popupSubHeight;
		GetTextExtentPoint32(popDC,(LPCTSTR)&temper->name,strlen(temper->name),&name);
		if (name.cx+(popupTextOffset*2)+popupIconSize+15 > maxWidth)
			maxWidth = name.cx+(popupTextOffset*2)+popupIconSize+15;
    	temper = temper->next;
    }
    subMenuItem->totalHeight = totalHeight;
	subMenuItem->subMenuWidth = maxWidth;
	if (transBlt && !noPopupPix) {
		subMenuItem->region = GetRegion(subMenuItem->root);
	}
	// Set close button area for pinning
	subMenuItem->close.left = subMenuItem->subMenuWidth - 11;
	subMenuItem->close.top = 3;
	subMenuItem->close.right = subMenuItem->subMenuWidth - 3;
	subMenuItem->close.bottom = 11;
	DeleteDC(popDC);
}

void initializePopupMenu() 
{
    FILE *f = NULL;
    char buffer[4096];
    char token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], extra_text[4096];
    char* tokens[5];
	char iname[MAX_PATH];
    fileItem * item = popupFile;
    
    GetRCString("HotListName", popup.menuName, "", 256);
    GetRCString("PopupTitlePix", titleBMP.name	, "", 256);
    GetRCString("PopupEntryPix", backBMP.name	, "", 256);
    GetRCString("PopupSelEntryPix", selectBMP.name	, "", 256);
	GetRCString("PopupBottomPix", bottomBMP.name, "", 256);
    GetRCString("PopupFontFace", popupFontFace, "Arial", 256);
	if (strlen(titleBMP.name)==0 || strlen(backBMP.name)==0 || strlen(selectBMP.name)==0) 
		noPopupPix = TRUE;
	popupFolderIcon = GetRCBool("NoPopupFolderIcon", FALSE);
	transBlt = GetRCBool("NoPopupTransparent", FALSE);
    noPopupBevel = GetRCBool("NoPopupBevel", TRUE);
    popupFontHeight = GetRCInt("PopupFontHeight", 16);
    titleColor = GetRCColor("PopupTitleColor", 0xffffff);
    normColor = GetRCColor("PopupEntryColor", 0x000000);
    selColor = GetRCColor("PopupSelEntryColor", 0x000000);
    popup.subMenuDelay = GetRCInt("PopupMenuDelay",0);
    popupMinWidth = GetRCInt("minpopupwidth", 100);
    popupSubHeight = GetRCInt("PopupSubmenuHeight", 20);
	titleHeight = GetRCInt("PopupSubmenuHeight", 20);
	popupTextOffset = GetRCInt("PopupTextOffset", 5);
	showPopupIcons = GetRCBool("ShowPopupIcons", TRUE);
	if (showPopupIcons) {
		popupIconSize = GetRCInt("PopupIconSize", 20);
		GetRCString("PopupDefaultIcon", iname, "default.ico", 256);
		popupDefaultIcon = LoadLSIcon(iname, NULL);
		popupIconSize = popupIconSize>popupSubHeight?popupSubHeight:popupIconSize;
		popupTop = (popupSubHeight-popupIconSize)/2;
	} else 
		popupIconSize = 0;
	// Bottom bitmap is loaded as there is no setting to indicate whether it is drawn or not - yet ...
	bottomBMP.bitmap = LoadLSImage(bottomBMP.name, NULL);
	if (!noPopupPix) {
	    //loads up images i will eventualy seperate this into its own function
		backBMP.bitmap = LoadLSImage(backBMP.name, NULL);
	    titleBMP.bitmap = LoadLSImage(titleBMP.name, NULL);
		selectBMP.bitmap = LoadLSImage(selectBMP.name, NULL); 

	    GetLSBitmapSize(selectBMP.bitmap, &selectBMP.x, &selectBMP.y);
		GetLSBitmapSize(backBMP.bitmap, &backBMP.x, &backBMP.y);
	    GetLSBitmapSize(titleBMP.bitmap, &titleBMP.x, &titleBMP.y);
		GetLSBitmapSize(bottomBMP.bitmap, &bottomBMP.x, &bottomBMP.y);

		//mian's transparency stuff
		selectBMP.region = BitmapToRegion(selectBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		titleBMP.region = BitmapToRegion(titleBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		backBMP.region = BitmapToRegion(backBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0);
		bottomBMP.region = BitmapToRegion(bottomBMP.bitmap, RGB(255,0,255), 0x10101010, 0, 0); 
	} else {
	    titleBack = GetRCColor("PopupTitleBack", 0x000000);
            normBack = GetRCColor("PopupNormalBack", 0xa4a0a0);
	    selBack = GetRCColor("PopupSelBack", 0xffffff);
	}

    popupFile = new fileItem;
    item = popupFile;

    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;
    tokens[3] = token4;
    tokens[4] = token5;

    buffer[0] = 0;
    f = LCOpen (NULL);
    int keeper = 0;
    
    while (LCReadNextConfig (f, "*popup", buffer, sizeof (buffer)))
    {
     	int count = 0, count2 = 0;
    	char truly_extra_text[4096];
    	if(keeper == 0)
    		keeper = 1;
    	else
    	{
    		item->next = new fileItem;
    		item = item->next;
    	}
    	token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = extra_text[0] = truly_extra_text[0] = '\0';
    	count = LCTokenize (buffer, tokens, 3, extra_text);
    	
    	switch (count)
    	{
    	case 3:											// *Popup
    		strcpy(item->itemName, token2);				// "Name"
    		if (atoi(token3))
    		{
    			item->itemHeight = atoi(token3);			// Height
    			count2 = LCTokenize(extra_text, tokens, 2, truly_extra_text);
    			strcpy(item->bmpName, token1);				// Bitmap.bmp
    			strcpy(item->popupCommand, token2);			// Command.exe
    			strcpy(item->commandParam, truly_extra_text);		// -command_params
    		}
    		else
    		{
    			item->itemHeight = popupSubHeight;
    			strcpy(item->bmpName, backBMP.name);
    			if (!stricmp(token3, "Folder"))
    			{
    				strcpy(item->popupCommand, "!Folder");
    			}
    			else
    			{
    				strcpy(item->popupCommand, token3);
    			}
    			strcpy(item->commandParam, extra_text);
    		}
    		break;

    	case 2:
    		strcpy(item->popupCommand, token2);
    	}
    }		

    //copys the popupFile structure into our popup strucure
    //in later revisions error checking will go here
    LCClose(f);

    item = popupFile;
	int count = 1;
    while(item != NULL)
    {
    	if(!stricmp(item->popupCommand, "~folder"))
    		item = item->next;
    	if(item == NULL)
    		break;
    	
    	popup.newMenuItem();
    	strcpy(popup.current->name, item->itemName);
    	strcpy(popup.current->command, item->popupCommand);
    	strcpy(popup.current->bmp, item->bmpName);
    	strcpy(popup.current->params, item->commandParam);
//    	popup.current->height = item->itemHeight;
    	popup.current->itemLevel = popupLevel;
		popup.current->itemNo = count;
    	if(!strncmp(popup.current->command, "!PopupFolder", 12))
    	{
			// te 10/28/98, expand %UserProfile%, %Home%, etc
			char temp[MAX_PATH], real[MAX_PATH];
			strcpy(temp, popup.current->command+13);
			popupLevel++;
			ExpandEnvironmentStrings(temp, real, sizeof(real));
			fillDirectory(real, popup.current);
			popupLevel--;
			popup.current->hIcon = popupDefaultIcon;
    	}
		else if(!strncmp(popup.current->command, "!PopupDynamicFolder", 19))
		{
			char temp[MAX_PATH];
			strcpy(temp, popup.current->command+20);
			popup.current -> isDynamic = TRUE;
			popup.current->hIcon = popupDefaultIcon;
		}		
    	else if(!stricmp(popup.current->command, "!Folder"))
    	{
    		subFolderInit(popup.current, item);
			popup.current->hIcon = popupDefaultIcon;
    		while(stricmp(item->next->popupCommand, "~folder") && item != NULL)
    			item = item->next;
    		if(item == NULL)
    			break;
		} 
    	item = item->next;
		count++;
    }
    popupFont = CreateFont(
    		popupFontHeight,
    		0,
    		0,
    		0,
    		FW_NORMAL,
    		FALSE,
    		FALSE,
    		FALSE,
    		DEFAULT_CHARSET,
    		OUT_DEFAULT_PRECIS,
    		CLIP_DEFAULT_PRECIS,
    		DEFAULT_QUALITY,
    		DEFAULT_PITCH,
    		popupFontFace);

    menuItem *temper = popup.root;
    int totalHeight = 0;
	int maxWidth = popupMinWidth;
	SIZE name;
	HDC popDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	SelectObject(popDC, popupFont);
	if (showPopupIcons)
		_beginthread(GetItemIcon, 0, temper);
	
    while(temper != NULL)
    {
    	totalHeight = totalHeight + popupSubHeight;
		GetTextExtentPoint32(popDC,(LPCTSTR)&temper->name,strlen(temper->name),&name);
		if (name.cx+(popupTextOffset*2)+popupIconSize+15 > maxWidth)
			maxWidth = name.cx+(popupTextOffset*2)+popupIconSize+15;
    	temper = temper->next;
    }
	if (transBlt && !noPopupPix) {
		popup.region = GetRegion(popup.root);
	}
    popup.totalHeight = totalHeight;
	popup.menuWidth = maxWidth;
	// Set close button area for pinning
	popup.close.left = popup.menuWidth - 11;
	popup.close.top = 3;
	popup.close.right = popup.menuWidth - 3;
	popup.close.bottom = 11;
	DeleteDC(popDC);
}

HRGN GetRegion(menuItem *item) {
	menuItem *temp;
	HRGN mainRgn, clipRgn;
	int height = titleHeight;

	mainRgn = CreateRectRgn(0, 0, 0, 0);
	CombineRgn(mainRgn, mainRgn, titleBMP.region, RGN_OR);
	temp = item;
	while (temp != NULL) {
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, backBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(mainRgn, mainRgn, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
		height = height + popupSubHeight;
		temp = temp->next;
	}
	if (bottomBMP.bitmap) {
		clipRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(clipRgn, bottomBMP.region, NULL, RGN_COPY);
		OffsetRgn(clipRgn, 0, height);
		CombineRgn(mainRgn, mainRgn, clipRgn, RGN_OR);
		DeleteObject(clipRgn);
	}
	return mainRgn;
}

void displayPopup(HWND hwnd, int x, int y)
{
	int height;
	height = bottomBMP.bitmap?titleHeight*2:titleHeight;
	popup.onLeft = FALSE;
	currentRootLocation.x = x;
	currentRootLocation.y = y;
    
    //Get popup coordinates
	if (x + popup.menuWidth > GetSystemMetrics(SM_CXSCREEN)) {
		x -= popup.menuWidth;
		popup.onLeft = TRUE;
	}

	if ((y + popup.totalHeight + titleHeight) > GetSystemMetrics(SM_CYSCREEN))
		y = GetSystemMetrics(SM_CYSCREEN) - (popup.totalHeight + titleHeight);
	SetWindowPos(hwnd, HWND_TOP, x, y, popup.menuWidth,(popup.totalHeight + height), 
    	SWP_SHOWWINDOW);
    
	PaintPopup(hwnd);
    int sdaf =123;
}

void PaintPopup(HWND hwnd)
{
    HDC DC, memDC;
    PAINTSTRUCT ps;
    HFONT oldFont;
	HBRUSH hBrush;
    RECT r;
	char temp[256];

    DC = BeginPaint(hwnd,&ps);
    memDC = CreateCompatibleDC(DC);
    isMainWindowHidden = FALSE;
    
    oldFont = (HFONT) SelectObject(DC, popupFont);
    //blits out title info
	if (!noPopupPix) {
	    SelectObject(memDC, titleBMP.bitmap);
		BitBlt(DC,0,0, titleBMP.x, titleHeight, memDC, 0, 0,SRCCOPY); 
	} else {
		hBrush = CreateSolidBrush(titleBack);
		SetRect(&r, 0, 0, popup.menuWidth, titleHeight);
		FillRect(DC, &r, hBrush);
	}
	SetBkMode(DC, TRANSPARENT);
    SetTextColor(DC,  titleColor);
    r.left = popupTextOffset;
    r.right = titleBMP.x-popupTextOffset;
    r.top= 0;
    r.bottom = titleHeight;
    DrawText(DC, popup.menuName, lstrlen(popup.menuName), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);
    SelectObject(DC, oldFont);
    ReleaseDC(hwnd, DC);
    //creates a list hopper to retrive popup info
    menuItem *item = popup.root;
    int totalHeight = titleHeight;
    
    //blits out each menu item, in order that they where entered into the RC
   	DC = GetDC(hwnd);
   	oldFont = (HFONT) SelectObject(DC, popupFont);
   	SelectObject(memDC, backBMP.bitmap);
    while(item != NULL)
    {
		if ((item -> command[0] == '\0') && (item -> name[0] == '\0')) {
			item = item -> next;
			continue;
		}
		if (item -> isDynamic && subEnum == 0) {
			// go through and delete SMenu's from any other nested menus first?
			delete(item->SMenu);
			strcpy(temp, item -> command + 20);
			popupLevel = item -> itemLevel + 1;
			fillDirectory(temp, item);
			if (showPopupIcons)
				GetItemIcon(item);
		}
		if (!noPopupPix) {
	   		BitBlt(DC,0,totalHeight, backBMP.x, titleHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(normBack);
			SetRect(&r, 0, totalHeight,popup.menuWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
		SetBkMode(DC, TRANSPARENT);
		SetTextColor(DC,  normColor);
		//Draw Icon
		if (showPopupIcons) {
			if (item->hIcon != NULL)
				DrawIconEx(DC, popupTextOffset, totalHeight+popupTop, item->hIcon, popupIconSize, popupIconSize, 0, NULL, DI_NORMAL); //DI_DEFAULTSIZE
    		r.left = popupTextOffset+popupIconSize+4;
		} else
			r.left = popupTextOffset;
    	r.right = backBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + titleHeight;
    	DrawText(DC, item->name, lstrlen(item->name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);

    	if (!noPopupBevel)
    	{
			paintPopupBevel(hwnd, item, totalHeight, popup.menuWidth);
    	}

    	// Paint little folder arrow thingy
    	if (item->SMenu != NULL && popupFolderIcon)
    	{
			paintFolderArrow(hwnd, item, totalHeight, popup.menuWidth);
    	}

    	totalHeight = totalHeight + popupSubHeight;
    	item = item->next;
    }

	if (bottomBMP.bitmap) {
		if (!noPopupPix) {
			SelectObject(memDC, bottomBMP.bitmap);
			BitBlt(DC,0,totalHeight, bottomBMP.x, titleHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(titleBack);
			SetRect(&r, 0, totalHeight,popup.menuWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
	}
    SelectObject(DC, oldFont);
	DeleteObject(hBrush);
   	ReleaseDC(hwnd, DC);
    EndPaint(hwnd,&ps);	
    DeleteDC(memDC);
}

int fillDirectorySortFunc(const void *a, const void *b)
{
    WIN32_FIND_DATA *f1 = (WIN32_FIND_DATA *)a;
    WIN32_FIND_DATA *f2 = (WIN32_FIND_DATA *)b;

    if (f1->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    {
    	if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    		return stricmp(f1->cFileName, f2->cFileName);
    	else
    		return -1;
    }
    if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    	return 1;

    return stricmp(f1->cFileName, f2->cFileName);
}

//parses a directory and fills the popup data structure with the results
int fillDirectory(char *dirName, menuItem *target)
{
    int l=0;	
    int j, k, still=1;

    WIN32_FIND_DATA fd;
    HANDLE h;
    char temp2[MAX_PATH];
    strcpy(temp2, dirName);
    strcat(temp2, "\\*");
    h = FindFirstFile(temp2, &fd);
    if (h == INVALID_HANDLE_VALUE)
    	return 1;
    
    target->SMenu = new subMenu;
    menuItem *walker = target;
    WIN32_FIND_DATA fileTable[255];
    
    for (j=0;j<255 && still;j++)
    {
    	fileTable[j] = fd;
    	still = FindNextFile(h, &fd);
    }

    qsort((void *)fileTable, j, sizeof(WIN32_FIND_DATA), fillDirectorySortFunc);

    for (k=j,j=0;l<255 && j<k;l++,j++)
    {
    	if (fileTable[j].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
    		if (!strcmp(fileTable[j].cFileName, ".") || !strcmp(fileTable[j].cFileName, ".."))
           	{
            	l--;
    		}
    		else
    		{
    			char t[MAX_PATH];
    			walker->SMenu->newMenuItem();// = new menuItem;
    			strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
    			strcpy(t, dirName);
    			strcat(t, "\\");
    			strcat(t, fileTable[j].cFileName);
//    			walker->SMenu->current->height = popupSubHeight;
    			walker->SMenu->current->itemLevel = popupLevel;
    			popupLevel++;
    			int temp2 = fillDirectory(t, walker->SMenu->current);
    			if(temp2)
    			{
    				delete walker->SMenu->current->SMenu;
    				walker->SMenu->current->SMenu = NULL;
    				strcpy(walker->SMenu->current->command, t);
    			}
    			popupLevel--;
    		}
    	}
    	else
    	{
    		char temp[5];
    		
    		//strcpy(temp2, "\"");
    		strcpy(temp2, "");
    	 	strcat(temp2, dirName);
    		strcat(temp2, "\\");
    		strcat(temp2, fileTable[j].cFileName);
    		//strcat(temp2, "\"");
       		
    		walker->SMenu->newMenuItem();			
    		strcpy(walker->SMenu->current->command,temp2);
    		strcpy(temp, fileTable[j].cFileName +(strlen(fileTable[j].cFileName) -4));
    		//stripping unwanted extentions from the name
			if(!stricmp(temp, ".lnk") || !stricmp(temp, ".exe") || !stricmp(temp, ".pif") || !stricmp(temp, ".com") || !stricmp(temp, ".rnk") || !stricmp(temp, ".bat")) 
    		{
    			strncpy(walker->SMenu->current->name, fileTable[j].cFileName, 
    				strlen(fileTable[j].cFileName) -4);
    			walker->SMenu->current->name[strlen(fileTable[j].cFileName) -4] = '\0';
    		}
    		else 
				strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
//    		walker->SMenu->current->height = popupSubHeight;
    		walker->SMenu->current->itemLevel = popupLevel;
		}
    }
    FindClose(h);

    menuItem *counter = target->SMenu->root;
    target->SMenu->totalHeight = 0;
	int maxWidth = popupMinWidth;
	SIZE name;
	HDC popDC = CreateDC("DISPLAY", NULL, NULL, NULL);
	SelectObject(popDC, popupFont);
	int count = 1;
    while(counter != NULL)
    {
    	target->SMenu->totalHeight = popupSubHeight + target->SMenu->totalHeight;
		GetTextExtentPoint32(popDC,(LPCTSTR)&counter->name,strlen(counter->name),&name);
		if (name.cx+(popupTextOffset*2)+popupIconSize+15 > maxWidth)
			maxWidth = name.cx+(popupTextOffset*2)+popupIconSize+15;
		counter->itemNo = count;
		counter = counter->next;
		count++;
    }
	target->SMenu->subMenuWidth = maxWidth;
	if (transBlt && !noPopupPix) {
		target->SMenu->region = GetRegion(target->SMenu->root);
	}
	// Set close button area for pinning
	target->SMenu->close.left = target->SMenu->subMenuWidth - 11;
	target->SMenu->close.top = 3;
	target->SMenu->close.right = target->SMenu->subMenuWidth - 3;
	target->SMenu->close.bottom = 11;
	DeleteDC(popDC);

    if(target->SMenu->root == NULL)
    	return 1;
    return 0;
}
    
void displaySubMenu(HWND calledFrom, menuItem *firstItem, int height)
{
    RECT lpRect;
	int prevWidth, tHeight;
	HRGN tempRgn;
	HWND parent;
	BOOL onLeft;

    if(isMainWindowHidden == TRUE)
    	return;
	tHeight = bottomBMP.bitmap?titleHeight*2:titleHeight;
    GetWindowRect(calledFrom, &lpRect);
    subEnum++;
    subList[subEnum].subMenu = firstItem->SMenu;
    subList[subEnum].subMenu->isSubOpen = TRUE;
	if (subEnum != 1)
		prevWidth = subList[subEnum-1].subMenu->subMenuWidth;
	else
		prevWidth = popup.menuWidth;
	onLeft = (subEnum != 1)?subList[subEnum-1].subMenu->onLeft:popup.onLeft;
	if (!onLeft) {
		if (lpRect.right + subList[subEnum].subMenu->subMenuWidth > GetSystemMetrics(SM_CXSCREEN)) { //|| lpRect.right + subList[subEnum].subMenu->subMenuWidth * subEnum > GetSystemMetrics(SM_CXSCREEN))
    		lpRect.right = lpRect.right - subList[subEnum].subMenu->subMenuWidth - prevWidth;
			subList[subEnum].subMenu->onLeft = TRUE;
		}
	} else {
		if (lpRect.right - subList[subEnum].subMenu->subMenuWidth - prevWidth < 0) {
//    		lpRect.right = lpRect.right + subList[subEnum].subMenu->subMenuWidth;
			subList[subEnum].subMenu->onLeft = FALSE;
		} else {
			lpRect.right = lpRect.right - subList[subEnum].subMenu->subMenuWidth - prevWidth;
			subList[subEnum].subMenu->onLeft = TRUE;
		}
	}

	if (firstItem->SMenu->totalHeight+(lpRect.top+(height-titleHeight)) > GetSystemMetrics(SM_CYSCREEN))
		lpRect.top = GetSystemMetrics(SM_CYSCREEN) - (firstItem->SMenu->totalHeight +(height- titleHeight));

	if (subEnum == 1)
		parent = hMainWnd;
	else
		parent = subList[subEnum-1].subMenuHwnd;
    subList[subEnum].subMenuHwnd = CreateWindowEx(
        	WS_EX_TOPMOST|WS_EX_TOOLWINDOW,				// exstyles 
    		popupSubName,								// our window class name
    		"",											// use description for a window title
    		WS_POPUP,				
			lpRect.right, (lpRect.top+(height-titleHeight)), 							// position 
    		subList[subEnum].subMenu->subMenuWidth,(firstItem->SMenu->totalHeight)+tHeight,	// width & height of window
    		parent,								// parent window 
    		NULL,									// no menu
    		appInstance,								// hInstance of DLL
    		NULL);									// no window creation data
    
    SetWindowLong(subList[subEnum].subMenuHwnd, GWL_USERDATA, magicDWord);
	if (transBlt && !noPopupPix) {
		tempRgn = CreateRectRgn(0, 0, 0, 0);
		CombineRgn(tempRgn, subList[subEnum].subMenu->region, NULL, RGN_COPY);
		SetWindowRgn(subList[subEnum].subMenuHwnd, tempRgn, FALSE);
/*		subList[subEnum].subMenu->region = tempRgn;
		DeleteObject(tempRgn);*/
	}
	BOOL temp2 = SetWindowPos(subList[subEnum].subMenuHwnd, HWND_TOP, lpRect.right, (lpRect.top+(height-(titleHeight*2))), 
    subList[subEnum].subMenu->subMenuWidth,(firstItem->SMenu->totalHeight)+tHeight,
    SWP_SHOWWINDOW);
	PaintSubMenu(subEnum);
    goingToSubMenu = FALSE;
}

void PaintSubMenu(int i)
{
    HFONT oldFont;
    RECT r;
    HDC DC, memDC;
    PAINTSTRUCT ps;
	HBRUSH hBrush;
	char *name;
	int menuWidth;
    
	if (i >  subEnum) return;
	if (i <= 1) {
		name = popup.isSelected->name;
	} else {
		name = subList[i-1].subMenu->isSelected->name;
	}
    menuItem *iTemp = subList[i].subMenu->root;
	menuWidth = subList[i].subMenu->subMenuWidth;

    DC = BeginPaint(subList[i].subMenuHwnd,&ps);
    memDC = CreateCompatibleDC(DC);
    oldFont = (HFONT) SelectObject(DC, popupFont);
	if (!noPopupPix) {
	    //blits out title info
		SelectObject(memDC, titleBMP.bitmap);
		BitBlt(DC,0,0, titleBMP.x, titleHeight, memDC, 0, 0,SRCCOPY);
	} else {
		hBrush = CreateSolidBrush(titleBack);
		SetRect(&r, 0, 0, menuWidth, titleHeight);
		FillRect(DC, &r, hBrush);
	}
    SetBkMode(DC, TRANSPARENT);

    r.left = popupTextOffset;
    r.right = titleBMP.x-popupTextOffset;
    r.top= 0;
    r.bottom = titleHeight;
    SetTextColor(DC,  titleColor);
	DrawText(DC, name, lstrlen(name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);
    SelectObject(DC, oldFont);
    ReleaseDC(subList[i].subMenuHwnd, DC);

    int totalHeight = titleHeight;
    //blits out each menu item, in order that they where entered into the RC
   	DC = GetDC(subList[i].subMenuHwnd);
   	oldFont = (HFONT) SelectObject(DC, popupFont);
   	SelectObject(memDC, backBMP.bitmap);
    while(iTemp != NULL)
    {
		if (!noPopupPix) {
	   		BitBlt(DC,0,totalHeight, backBMP.x, titleHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(normBack);
			SetRect(&r, 0, totalHeight, menuWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
		SetTextColor(DC,  normColor);
    	SetBkMode(DC, TRANSPARENT);
		//Draw Icon
		if (showPopupIcons) {
			if (iTemp->hIcon != NULL)
				DrawIconEx(DC, popupTextOffset, totalHeight+popupTop, iTemp->hIcon, popupIconSize, popupIconSize, 0, NULL, DI_NORMAL); //DI_DEFAULTSIZE
			r.left = popupTextOffset+popupIconSize+4;
		} else
			r.left = popupTextOffset;
    	r.right = backBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + titleHeight;
    	DrawText(DC, iTemp->name, lstrlen(iTemp->name), &r, DT_VCENTER|DT_SINGLELINE|DT_NOCLIP);

    	if (!noPopupBevel)
    	{
			paintPopupBevel(subList[i].subMenuHwnd, iTemp, totalHeight, subList[i].subMenu->subMenuWidth);
    	}
    	// Paint little folder arrow thingy
    	if (iTemp->SMenu != NULL && popupFolderIcon)
    	{
			paintFolderArrow(subList[i].subMenuHwnd, iTemp, totalHeight, subList[i].subMenu->subMenuWidth);
    	}
		totalHeight = totalHeight + popupSubHeight;
    	iTemp = iTemp->next;
    }
	if (bottomBMP.bitmap) {
		if (!noPopupPix) {
			SelectObject(memDC, bottomBMP.bitmap);
			BitBlt(DC,0,totalHeight, bottomBMP.x, titleHeight, memDC, 0, 0,SRCCOPY);
		} else {
			hBrush = CreateSolidBrush(titleBack);
			SetRect(&r, 0, totalHeight, menuWidth, totalHeight+titleHeight);
			FillRect(DC, &r, hBrush);
		}
	}	
	SelectObject(DC, oldFont);
	DeleteObject(hBrush);
   	ReleaseDC(subList[i].subMenuHwnd, DC);
    EndPaint(subList[i].subMenuHwnd,&ps);	

    //displays the window
    DeleteDC(memDC);
}

void closePopupSubMenu(HWND subMenu)
{
    DestroyWindow(subMenu);
}	

// window procedure for our window
LRESULT CALLBACK PopupWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int minWidth;

    BOOL setFlag = FALSE;
	POINT pt;
    RECT r;
    HWND hwndGetFocus;
    int p;
    int tempEnum = 1;
    int tempEnum2 = 0;
    menuItem *item;
    menuItem *temp;
    int goingTo = 1;
    WORD fActive;

   	GetCursorPos(&pt);
   	GetWindowRect(hwnd, &r);
   	pt.x -= r.left;
   	pt.y -= r.top;

    while(hwnd != subList[tempEnum].subMenuHwnd)
    {
    	tempEnum++;
    	if(tempEnum > subEnum)
    		break;
    }
	if (tempEnum> subEnum)
		minWidth = subEnum==0?popup.menuWidth:subList[subEnum].subMenu->subMenuWidth;
	else
	    minWidth = subList[tempEnum].subMenu->subMenuWidth;
    switch (message)
    {
	case WM_PAINT:
		PaintSubMenu(tempEnum);
		break;

	case WM_ERASEBKGND:
		return 0;

    case WM_TIMER:
    	KillTimer(hwnd, 1);
    	if(timerPointer == NULL)
    		break;

    	if(timerPointer->SMenu != subList[subEnum].subMenu && timerPointer != NULL && hwnd == itemCaller)
    	{
			while(timerPointer->itemLevel < subList[subEnum].subMenu->root->itemLevel) {
    			destroyCurrentSubMenu();
			}
    		goingToSubMenu = TRUE;
    		displaySubMenu(hwnd, timerPointer, (timerPointer->itemNo*popupSubHeight)+titleHeight);
    		timerPointer = NULL;			
    	}
    	break;

    case WM_MOUSEMOVE: 
	{
	    int y = HIWORD(lParam); 
		int x = LOWORD(lParam); 
		int itemNo = y/popupSubHeight;
		int prevHeight, height;

		if (previousItem->itemLevel<tempEnum) {
			prevHeight = titleHeight;
		} else {
			prevHeight = (previousItem->itemNo*popupSubHeight);
		}
		if (tempEnum < subEnum) {
			item = GetItem(subList[tempEnum].subMenu->root, itemNo);
		} else {
			item = GetItem(subList[subEnum].subMenu->root, itemNo);
		}
		if (item == previousItem)
			break;
		height = (item->itemNo*popupSubHeight)+titleHeight;
   		if(item->itemLevel > previousItem->itemLevel && setFlag == FALSE)
		{
			timerPointer = NULL;	
			setFlag = TRUE;
			KillTimer(hwnd, 1);
   		}
		if(item->itemLevel < previousItem->itemLevel 
 		&& previousItem->itemLevel > 0 && setFlag == FALSE)
	    {
    		KillTimer(hwnd, 1);
			while(subList[subEnum].subMenu->root->itemLevel != item->itemLevel) 
			{
  				destroyCurrentSubMenu();
			}
   			temp =	subList[tempEnum].subMenu->isSelected;
			displaySingleMenuItem(hwnd, temp, temp->itemNo*popupSubHeight, FALSE);
			setFlag = TRUE;
			timerPointer = NULL;
		} else {
			if(y < prevHeight || y > prevHeight || x < 0 || x > minWidth)
			{
				KillTimer(hwnd, 1);
				if(previousItem->itemLevel != 0 && setFlag == FALSE)
				{
					while(subList[subEnum].subMenu->root->itemLevel != item->itemLevel) 
					{
						destroyCurrentSubMenu();
					}
					displaySingleMenuItem(hwnd, previousItem, previousItem->itemNo*popupSubHeight, FALSE);
					setFlag = TRUE;
    				timerPointer = NULL;
	    		}
			}
		}
		if(y > prevHeight || y < (item->itemNo*popupSubHeight)+titleHeight)
		{
			displaySingleMenuItem(hwnd, item, item->itemNo*popupSubHeight, TRUE);
			subList[tempEnum].subMenu->isSelected = item;
	    	previousItem = item;
	    	if(item->SMenu != NULL && item != timerPointer 
			&& item->SMenu != subList[subEnum].subMenu && subList[tempEnum+1].subMenu != item->SMenu)
			{
				if(timerPointer != item)
				{
    				SetTimer(hwnd, 1, popup.subMenuDelay, NULL);
    				timerPointer = item;
		    		itemCaller = hwnd;
    				break;
    			}
			}
		}
		break;
   }
    case WM_NCHITTEST:
    	if(pt.y < titleHeight ) {
//    		destroyAllSubMenus(); destroy all below?
			if (subList[tempEnum].subMenu->pinned) {
				if (PtInRect(&subList[tempEnum].subMenu->close, pt)) {
					return (HTCLOSE);
				} else
					return (HTCAPTION);
			} else
   				return (HTCAPTION);
	   	}
   		else break;

    case WM_ACTIVATE:
    	fActive = LOWORD(wParam);

    	if(fActive == WA_INACTIVE)
    	{
    		hwndGetFocus = (HWND)lParam; // handle of window receiving focus 
    		if(goingToSubMenu == TRUE || hwndGetFocus == hMainWnd)
    			break;
    		p = 1;
    		do
    		{
    			if(subList[p].subMenuHwnd == hwndGetFocus)
    				return 0;
    			p++;
    		}while(p < (subEnum +1));
			if (!popup.pinned) {
	    		previousItem = NULL;
				isMainWindowHidden = TRUE;
				popup.isSelected = NULL;
    			ShowWindow(hMainWnd, SW_HIDE );
			} else {
			}
    		destroyAllSubMenus();
    		return 0;
    	}
    	break;	
    
    case WM_LBUTTONUP:
  		if(subList[tempEnum].subMenu->isSelected != NULL)
   		{
			item = subList[tempEnum].subMenu->isSelected;
   			if(item->SMenu == NULL )
   			{
   				if(item->command[0] != '!')
   				{
					executeItem(item);
				} else
   					ParseBangCommand (hwnd, item->command, item->params);
   				destroyAllSubMenus();
   				isMainWindowHidden = TRUE;
   				previousItem = NULL;
				popup.isSelected = NULL;
   				ShowWindow(hMainWnd, SW_HIDE );
   				break;
			} else {
   				displaySubMenu(hwnd, item, (item->itemNo*popupSubHeight)+titleHeight);
   				break;
   			}
		}
    	break;
	case WM_KEYDOWN: //Subfolder key navigation
		switch (wParam) {
		case VK_ESCAPE:
			// Destroy the popup menu if the user hits ESCAPE
			destroyAllSubMenus();
			isMainWindowHidden = TRUE;
			popup.isSelected = NULL;
			ShowWindow(hMainWnd, SW_HIDE);
			break;
		case VK_DOWN: //Sub folder
			if (wentRight[subEnum]) {
				if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->isSelected->next);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
				} else {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
				}

			} else {
				if (subEnum == 1) {
					destroyCurrentSubMenu();
				    WndProc(hMainWnd, message, wParam, lParam);
				} else {
					destroyCurrentSubMenu();
					if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->next);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
					} else {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->root);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
					}
				}
			} 
			break;
		case VK_UP: //Sub folder
			if (wentRight[subEnum]) {
				if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->current);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
				} else {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->isSelected->prev);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->prev;
				}
			} else {
				if (subEnum == 1) {
					destroyCurrentSubMenu();
				    WndProc(hMainWnd, message, wParam, lParam);
				} else {
					destroyCurrentSubMenu();
					if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->current);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
					} else {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->prev);
					}

				}
			}
			break;
		case VK_RIGHT: //Sub folder
			if (!subList[subEnum].subMenu->onLeft) {
				if (wentRight[subEnum]) {
					if (subList[subEnum].subMenu->isSelected->SMenu != NULL && subList[subEnum].subMenu->isSelected != NULL) { 
						int totalHeight = titleHeight+popupSubHeight;
						menuItem *temper = subList[subEnum].subMenu->root;
						while (temper != subList[subEnum].subMenu->isSelected) {
							totalHeight = totalHeight + popupSubHeight;
							temper = temper->next;
						}
						displaySubMenu(hwnd, subList[subEnum].subMenu->isSelected, totalHeight);
						keyedSubMenu(subList[subEnum+1].subMenuHwnd, subList[subEnum].subMenu->isSelected->SMenu->root);
					}
				} else {
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
						keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
						wentRight[subEnum] = TRUE;
				}
			} else {
				// Key left functionality for when menu's on the left
				if (wentRight[subEnum]) {
					wentRight[subEnum] = FALSE;
					subList[subEnum].subMenu->isSelected = NULL;
					if (subList[subEnum].subMenu->root->itemLevel == 1) {
						destroyCurrentSubMenu();
						keyedSubMenu(hMainWnd, popup.isSelected);
					} else { 
						destroyCurrentSubMenu();
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
					}
				} else {
					if (subEnum>1) {
						if (subList[subEnum-1].subMenu->isSelected != NULL) {
							if (subList[subEnum-1].subMenu->isSelected->SMenu != NULL) {
								destroyCurrentSubMenu();
								wentRight[subEnum] = FALSE;
								subList[subEnum].subMenu->isSelected = NULL;
								destroyCurrentSubMenu();
								if (subEnum > 0) {
									keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
								} else {
									keyedSubMenu(hMainWnd, popup.isSelected);
								}
							}
						}
					}
				}
			}
			break;
		case VK_LEFT: //Sub folder
			if (!subList[subEnum].subMenu->onLeft) {
				if (wentRight[subEnum]) {
					wentRight[subEnum] = FALSE;
					subList[subEnum].subMenu->isSelected = NULL;
					if (subList[subEnum].subMenu->root->itemLevel == 1) {
						destroyCurrentSubMenu();
						keyedSubMenu(hMainWnd, popup.isSelected);
					} else { 
						destroyCurrentSubMenu();
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
					}
				} else {
					if (subEnum>1) {
						if (subList[subEnum-1].subMenu->isSelected != NULL) {
							if (subList[subEnum-1].subMenu->isSelected->SMenu != NULL) {
								destroyCurrentSubMenu();
								wentRight[subEnum] = FALSE;
								subList[subEnum].subMenu->isSelected = NULL;
								destroyCurrentSubMenu();
								if (subEnum > 0) {
									keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
								} else {
									keyedSubMenu(hMainWnd, popup.isSelected);
								}
							}
						}
					}
				}
			} else {
				// Key right functionality for when menu's on the left
				if (wentRight[subEnum]) {
					if (subList[subEnum].subMenu->isSelected->SMenu != NULL && subList[subEnum].subMenu->isSelected != NULL) { 
						int totalHeight = titleHeight+popupSubHeight;
						menuItem *temper = subList[subEnum].subMenu->root;
						while (temper != subList[subEnum].subMenu->isSelected) {
							totalHeight = totalHeight + popupSubHeight;
							temper = temper->next;
						}
						displaySubMenu(hwnd, subList[subEnum].subMenu->isSelected, totalHeight);
						keyedSubMenu(subList[subEnum+1].subMenuHwnd, subList[subEnum].subMenu->isSelected->SMenu->root);
					}
				} else {
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
						keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
						wentRight[subEnum] = TRUE;
				}
			}
			break;
		case VK_RETURN: //Sub folder
			if (subList[subEnum].subMenu->isSelected != NULL) {
	    		if(subList[subEnum].subMenu->isSelected->SMenu == NULL) {
	    			char temp[256];
					strcpy(temp, subList[subEnum].subMenu->isSelected->command);
	    			if(subList[subEnum].subMenu->isSelected->command[0] != '!') {
						executeItem(subList[subEnum].subMenu->isSelected);
					} else
	    				ParseBangCommand (hwnd, subList[subEnum].subMenu->isSelected->command, subList[subEnum].subMenu->isSelected->params);
	    			destroyAllSubMenus();
	    			previousItem = NULL;
					previousCounter2 =0;
    				counter2 = 0;
    				isMainWindowHidden = TRUE;
					popup.isSelected = NULL;
    				ShowWindow(hwnd, SW_HIDE );
	    			break;
				}
			} 
			break;
		}
		break;
	}
    return DefWindowProc(hwnd, message, wParam, lParam);
}

void keyedSubMenu(HWND menu, menuItem *showItem) {
	RECT lpMenu;
	int height;
	menuItem *temper;

	if (showItem->itemLevel ==0)
		temper=popup.root;
	else
		temper=subList[showItem->itemLevel].subMenu->root;
	height=titleHeight;
	while (temper != showItem) {
		height = height + popupSubHeight;
		temper = temper->next;
	}
	GetWindowRect(menu, &lpMenu);
	SetCursorPos(lpMenu.left+2, lpMenu.top+height+2);
}

void GetItemIcon(void *pitem) {
	HICON hIcon;
	char *file;
	char icon[MAX_PATH];
	menuItem *item = (menuItem *) pitem;
	char dir[MAX_PATH];
	UINT dsize = MAX_PATH;

	if (!showPopupIcons)
		_endthread();
    while(item != NULL) {
		strcpy(icon, "");
		if (item->SMenu != NULL) {
			item->hIcon = popupDefaultIcon;
			GetItemIcon(item->SMenu->root);
		} else {
			file = strlwr(strdup(item->command));
			if (strstr(file, "explorer")) {
				file = strdup(item->params);
				if (strstr(file, "{21EC2020-3AEA-1069-A2DD-08002B30309D}")) {
					//Control Panel
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{21EC2020-3AEA-1069-A2DD-08002B30309D}\\DefaultIcon", file);
				} else if (strstr(file, "{208D2C60-3AEA-1069-A2D7-08002B30309D}")) {
					//Network Neigbourhood
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{208D2C60-3AEA-1069-A2D7-08002B30309D}\\DefaultIcon", file);
				} else if (strstr(file, "{992CFFA0-F557-101A-88EC-00DD010CCC48}")) {
					//Dial-up Networking
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{992CFFA0-F557-101A-88EC-00DD010CCC48}\\DefaultIcon", file);
				} else if (strstr(file, "{20D04FE0-3AEA-1069-A2D8-08002B30309D}")) {
					//My computer
					strcpy(file, ""); //Default icon
					RegistryLookup("CLSID\\{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\DefaultIcon", file);
				}
				if (strlen(file) != 0) {
					strcpy(icon, ".extract=");
					if (!strstr(file, "\\")) {
						if (strstr(file, "explorer"))
							GetWindowsDirectory(dir, dsize);
						else
							GetSystemDirectory(dir, dsize);
						strcat(icon, dir);
							strcat(icon, "\\");
					}
					strcat(icon, file);
					hIcon = LoadLSIcon(icon, NULL);
					item->hIcon = hIcon;
				}
			} else {
				SHFILEINFO shf;

				SHGetFileInfo(item->command, NULL, &shf, sizeof(shf), SHGFI_ICON | SHGFI_SMALLICON);
				if (shf.hIcon != NULL)
					item->hIcon = shf.hIcon;
				else {
					_searchenv(item->command, "PATH", dir);
					if (strlen(dir) != 0) {
						SHGetFileInfo(dir, NULL, &shf, sizeof(shf), SHGFI_ICON | SHGFI_SMALLICON);
						item->hIcon = shf.hIcon;
					}
				}
			}
		}
		item = item->next;
    }
}

void RegistryLookup(char* subKey, char *value) {
	char regData[256];
	int regSize = 256;
	LONG res;
	HKEY hOpen;

	RegOpenKeyEx(HKEY_CLASSES_ROOT, subKey, 0, KEY_READ, &hOpen);
	res = RegQueryValueEx(hOpen, value, NULL, NULL, (LPBYTE)regData, (LPDWORD)&regSize);
	if (res == ERROR_SUCCESS)
		strcpy(value, regData);
	else
		strcpy(value, "");
	RegCloseKey(hOpen);
}
/*
	$Log: popup.cpp,v $
	Revision 1.103  1998/11/28 15:07:39  cyberian
	
	Fixed a little transparency bug
	
 */

