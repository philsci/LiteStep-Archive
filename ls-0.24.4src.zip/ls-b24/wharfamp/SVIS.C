/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

 10/20/98 - F. Gastellu
            This file contains the source code for the WharfAmp module

****************************************************************************/

#include <windows.h>
#include <string.h>

#include "math.h"
#include "vis.h"
#include "dibutil.h"
#include "dibapi.h"

char szAppName[] = "WharfAmp"; // Our window class, etc

// configuration declarations
//int config_x=50, config_y=50;	// screen X position and Y position, repsectively
void config_read(struct winampVisModule *this_mod);		// reads the configuration
void config_write(struct winampVisModule *this_mod);	// writes the configuration
void config_getinifn(struct winampVisModule *this_mod, char *ini_file); // makes the .ini file filename
void clearScreen(int fake);
void drawBorder(void);


// returns a winampVisModule when requested. Used in hdr, below
winampVisModule *getModule(int which);

// "member" functions
void config(struct winampVisModule *this_mod); // configuration dialog
int init(struct winampVisModule *this_mod);	   // initialization for module
int render(struct winampVisModule *this_mod);  // rendering for module 2
void quit(struct winampVisModule *this_mod);   // deinitialization for module

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND hMainWnd; // main window handle

// Double buffering data
HDC memDC;		// memory device context
HBITMAP	memBM,  // memory bitmap (for memDC)
		oldBM;  // old bitmap (from memDC)


HWND WharfC, Wharf;
double log2;

// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "WharfAmp v1.0", getModule };

winampVisModule mod =
{
	"WharfAmp Spectrum Analyzer",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	2,		// spectrumNch
	0,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	render, 
	quit
};

// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

char *screen;
RECT rect;
HPALETTE mPal;
HDIB mDib;
HDC hdc;
RGBQUAD *pal;
RGBQUAD p[6] = { {15,7,0,0}, {63,63,0,0}, {255,255,0,0}, {255,255,255,0}, {127,127,127,0}, {255,255,255,0} };

int fallOffDelay=4;
int fallOffSpeed=8;
int fallOffBandSpeed=24;
typedef struct {
	int level;
	int cycle;
	} fallOffType;
fallOffType fallOffTable[2][12];
fallOffType fallOffBand[2][12];
int magnif=2;
int topdif=1;
int topcolor;
int aheight=60;
int shift=0;
int divisor;
int vshift;

HWND winamp_wnd;

// ------------------------------------------------------------------------------------------------
// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.
winampVisModule *getModule(int which)
{
	switch (which)
	{
		case 0: return &mod;
		default:return NULL;
	}
}

// ------------------------------------------------------------------------------------------------
// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampVisModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"WharfAmp - A WinAmp plugin for LiteStep - v1.0\nCopyright(C) 1998, Lone Runner/Aegis", "About",MB_OK);
}

// ------------------------------------------------------------------------------------------------
BOOL CALLBACK EnumChildProc(
	HWND  hwnd,	// handle to child window
    LPARAM  lParam 	// application-defined value
   )
{
	char c[25];

	*c=0;
	GetWindowText(hwnd, c, 24);
	if (!strcmpi(c, "WharfAmp"))
		{
		Wharf = hwnd;
		return FALSE;
		}

return TRUE;
}

// ------------------------------------------------------------------------------------------------
// initialization. Registers our window class, creates our window, etc. Again, this one works for
// both modules, but you could make init1() and init2()...
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod)
{
	int width = 64; 
	int height = 64; 
	float t;

	log2 = log10(2.0);

	rect.top = 0;
	rect.bottom = 64;
	rect.left = 0;
	rect.right = 64;
	shift = ((64-aheight)/4)*2*64;
	t = (float)256 / ((float)aheight / 4);
	if ((int)t != t) t = (int)t + (float)1;
	divisor = (int)t;
	vshift = aheight/4 * 64*2;

	WharfC = FindWindow("TWharfGlobalContainer", NULL);
	EnumChildWindows(WharfC, EnumChildProc, 0);
   
	Wharf = GetWindow(Wharf, GW_CHILD);
	if (!Wharf || !WharfC)
	{
		MessageBox(this_mod->hwndParent,"WharfAmp not found","WharfAmp",MB_OK);
		return 1;
	}

	config_read(this_mod);
	if (topdif) topcolor = 5; else topcolor = 2;

	
	{	// Register our window class
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = this_mod->hDllInstance;	// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(this_mod->hwndParent,"Error registering window class","WharfAmp",MB_OK);
			return 1;
		}
	}


	hMainWnd = CreateWindowEx(
		0/*WS_EX_TOOLWINDOW|WS_EX_APPWINDOW*/,	// these exstyles put a nice small frame, 
											// but also a button in the taskbar
		szAppName,							// our window class name
		""/*this_mod->description*/,				// use description for a window title
		WS_CHILD/*WS_VISIBLE*//*|WS_SYSMENU*/,				// make the window visible with a close button
		0/*config_x*/,0/*config_y*/,					// screen position (read from config)
		width,height,						// width & height of window (need to adjust client area later)
		Wharf,//this_mod->hwndParent,				// parent window (winamp main window)
		NULL,								// no menu
		this_mod->hDllInstance,				// hInstance of DLL
		0); // no window creation data

	if (!hMainWnd) 
	{
		MessageBox(this_mod->hwndParent,"Error creating window","blah",MB_OK);
		return 1;
	}


	{	// adjust size of window to make the client area exactly width x height
		RECT r;
		GetClientRect(hMainWnd,&r);
		SetWindowPos(hMainWnd,0,0,0,width*2-r.right,height*2-r.bottom,/*SWP_NOMOVE|*/SWP_NOZORDER);
	}


	hdc = GetDC(hMainWnd);

	// create our doublebuffer
	memDC = CreateCompatibleDC(NULL);
	memBM = CreateCompatibleBitmap(memDC,width,height);

	//memBM = CreateBitmap(64, 64, 1, 8, NULL);
    
	oldBM = SelectObject(memDC,memBM);

	//mPal = GetStockObject(DEFAULT_PALETTE);
	SelectObject(memDC, GetStockObject(NULL_PEN));
	Rectangle(memDC,0,0,65,65);

		
	mDib = CreateDIB(64, 64, 8);
	screen = FindDIBBits(mDib);
	pal = (RGBQUAD *)FindDIBPal(mDib);
	memcpy(pal, &p, 24);

	//SetDIBColorTable(memDC, 0, 3, &data);
	memset(screen, 0, 4096);
	memset(&fallOffTable, 0, 24*sizeof(fallOffType));
	memset(&fallOffBand, 0, 24*sizeof(fallOffType));
		
	clearScreen(1);
	drawBorder();

	// show the window
	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	ShowWindow(hMainWnd,SW_SHOWNORMAL);
	winamp_wnd = this_mod->hwndParent;

	return 0;
}

// ------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
	ReleaseDC(hMainWnd, hdc);
	config_write(this_mod);		// write configuration
	SelectObject(memDC,oldBM);	// delete our doublebuffer
	DeleteObject(memDC);
	DeleteObject(memBM);	
	DestroyWindow(hMainWnd); // delete our window
	UnregisterClass(szAppName,this_mod->hDllInstance); // unregister window class
}

// ------------------------------------------------------------------------------------------------
// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CREATE:		return 0;
		case WM_ERASEBKGND: return 0;
		case WM_PAINT:
			{ // update from doublebuffer
				PAINTSTRUCT ps;
				RECT r;
				HDC hdc = BeginPaint(hwnd,&ps);
				GetClientRect(hwnd,&r);
				PaintDIB(hdc/*memDC*/, &rect, mDib, &rect);
				//BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);
			}
		return 0;
		case WM_DESTROY: PostQuitMessage(0); return 0;
		case WM_KEYDOWN: // pass keyboard messages to main winamp window (for processing)
		case WM_KEYUP:
			{	// get this_mod from our window's user data
				winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hwnd,GWL_USERDATA);
				PostMessage(this_mod->hwndParent,message,wParam,lParam);
			}
		return 0;
/*		case WM_MOVE:
			{	// get config_x and config_y for configuration
				RECT r;
				GetWindowRect(hMainWnd,&r);
				config_x = r.left;
				config_y = r.top;
			}
		return 0;*/
		case WM_LBUTTONDOWN:
			{
            PostMessage(WharfC, 9183, 0, 0);
			ShowWindow(winamp_wnd,SW_RESTORE);
			SetForegroundWindow(winamp_wnd);
			}
		return 0;
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(WharfC, 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_RBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(WharfC, 9183, 0, 0);
            return 0;

	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// ------------------------------------------------------------------------------------------------
void config_getinifn(struct winampVisModule *this_mod, char *ini_file)
{	// makes a .ini file in the winamp directory named "plugin.ini"
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");
}


// ------------------------------------------------------------------------------------------------
void config_read(struct winampVisModule *this_mod)
{
	char ini_file[MAX_PATH];
	config_getinifn(this_mod,ini_file);

	fallOffDelay=GetPrivateProfileInt(this_mod->description,"TopFallOffDelay",fallOffDelay,ini_file);;
	fallOffSpeed=GetPrivateProfileInt(this_mod->description,"TopFallOffSpeed",fallOffSpeed,ini_file);;;
	fallOffBandSpeed=GetPrivateProfileInt(this_mod->description,"BandFallOffSpeed",fallOffBandSpeed,ini_file);;;
	magnif=GetPrivateProfileInt(this_mod->description,"Magnification",magnif,ini_file);
	topdif=GetPrivateProfileInt(this_mod->description,"TopDifColor",topdif,ini_file);

}

// ------------------------------------------------------------------------------------------------
void config_write(struct winampVisModule *this_mod)
{
	char string[32];
	char ini_file[MAX_PATH];

	config_getinifn(this_mod,ini_file);

	wsprintf(string,"%d",fallOffDelay);
	WritePrivateProfileString(this_mod->description,"TopFallOffDelay",string,ini_file);
	wsprintf(string,"%d",fallOffSpeed);
	WritePrivateProfileString(this_mod->description,"TopFallOffSpeed",string,ini_file);
	wsprintf(string,"%d",fallOffBandSpeed);
	WritePrivateProfileString(this_mod->description,"BandFallOffSpeed",string,ini_file);
	wsprintf(string,"%d",magnif);
	WritePrivateProfileString(this_mod->description,"Magnification",string,ini_file);
	wsprintf(string,"%d",topdif);
	WritePrivateProfileString(this_mod->description,"TopDifColor",string,ini_file);
}

// ------------------------------------------------------------------------------------------------

// render function for analyser. Returns 0 if successful, 1 if visualization should end.
int render(struct winampVisModule *this_mod)
{
int x,y,i,j,f;
double wBand;
int xf,jm;

	// clear background
	clearScreen(0);

	for (y=1;y>=0;y--)
		for (x=3,xf=0,f=0;x<63;x+=5,xf+=20,f++)
			{
			wBand=0;
			for (jm=xf;jm<xf+24;jm++)
				wBand += this_mod->spectrumData[y][jm];
			
			wBand /= (24 / 2);

			if (wBand > 1)
				wBand = (log10(wBand)/log2)*32;
			else
				wBand = 0;
			/*wBand /= (24 / magnif);*/
			if (fallOffBand[y][f].level)
				fallOffBand[y][f].level -= fallOffBandSpeed;
			if (wBand < fallOffBand[y][f].level)
				wBand = fallOffBand[y][f].level;
			else
				fallOffBand[y][f].level = wBand;
			if (wBand > 255)
				wBand = 255;
			if (wBand > fallOffTable[y][f].level)
				{
				fallOffTable[y][f].level = wBand;
				fallOffTable[y][f].cycle = 0;
				}
			for (j=0;j<= (wBand/divisor);j++)
				for (i=0;i<+4;i++)
					screen[shift+x+(j*64*2)+i+y*vshift] = 2;	
			}

	for (y=0;y<2;y++)
		for (f=0;f<12;f++)
			{
			if (fallOffTable[y][f].cycle++ > fallOffDelay && fallOffTable[y][f].level)
				fallOffTable[y][f].level-=fallOffSpeed;
			for (i=0;i<4;i++)
				screen[shift+y*vshift+(fallOffTable[y][f].level/divisor)*64*2+i+3+f*5] = topcolor;
			}

	drawBorder();

	PaintDIB(hdc, &rect, mDib, &rect);

	return 0;
}

// ------------------------------------------------------------------------------------------------
void clearScreen(int fake)
{
int x,y,i,c;

memset(screen, 0, 4096);

for (y=0;y<aheight;y+=2)
	{
	if (fake && (y == 0 || y == 32))
		c = 2;
	else
		c = 1;
	for (x=3;x<63;x+=5)
		for (i=0;i<4;i++)
			screen[shift+y*64+x+i] = c;
	}
}

// ------------------------------------------------------------------------------------------------

void drawBorder(void)
{
int y;

memset(screen, 4, 64);
memset(screen+63*64, 3, 63);
for (y=1;y<64;y++)
	{
	screen[y*64] = 3;
	screen[y*64+63] = 4;
	}
}

