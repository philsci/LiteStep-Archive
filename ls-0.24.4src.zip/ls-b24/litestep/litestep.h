#ifndef __LITESTEP_H
#define __LITESTEP_H

#include "wharfdata.h"

int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
int (FAR *quitWharfModule)(HINSTANCE);
void DoEvents(HWND hwnd, int n);

#define MAXWIN 200

typedef int (*ModuleInitFunc) (HWND, HINSTANCE, wharfDataType*);
typedef int (*NewModuleInitFunc) (HWND, HINSTANCE, LPCSTR);
typedef int (*ModuleQuitFunc) (HINSTANCE);

typedef struct
{
	char				szName[256];
	HINSTANCE			hInstance;

	ModuleInitFunc		pInit;
//	ModuleInitFunc		pWharfInit;
	NewModuleInitFunc	pNewInit;
	ModuleQuitFunc		pQuit;
//	ModuleQuitFunc		pWharfQuit;
} ModuleData;

#define MSGNUM 256
#define HWNDNUM 256

typedef struct
{
	UINT Message;
	HWND hwnd[HWNDNUM];
} msgWinType;

typedef struct {
	HWND trayWnd;
	HWND tooltipWnd;
	HWND hWnd;
	int message;
	UINT uID;
	HICON hIcon;
	char szTip[256];
	int x,y;
	} trayType;

typedef struct dStore {
	WORD ident;
	WORD len;
	void * data;
	struct dStore * next;
} dataStore;

#endif	/* LITESTEP_H */
