#ifndef __HOTKEY2_H
#define __HOTKEY2_H

void drizzt_InitHotKeys ();
void drizzt_FreeHotKeys ();
void drizzt_execute (const char *, const char *, const char *);

#endif