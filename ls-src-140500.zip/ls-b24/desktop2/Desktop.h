/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __DESKTOP_H
#define __DESKTOP_H

#include <windows.h>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"

#define MAX_LINE_LENGTH 4096

class Desktop : public Window
{
private:
  int screenWidth;
  int screenHeight;

  BOOL setDesktopArea;
  int sdaLeft;
  int sdaRight;
  int sdaBottom;
  int sdaTop;

  char bangLeftClick[MAX_LINE_LENGTH];
  char bangRightClick[MAX_LINE_LENGTH];
  char bangMiddleClick[MAX_LINE_LENGTH];

public:
  Desktop(HWND parentWnd, int& code);
  ~Desktop();

  void setLeftClick(LPCSTR args);
  void setRightClick(LPCSTR args);
  void setMiddleClick(LPCSTR args);

private:
  void setMinMax(void);
  void resetMinMax(void);

  virtual void windowProc(Message& message);
  void onActivate(Message& message);
  void onCreate(Message& message);
  void onDestroy(Message& message);
  void onDisplayChange(Message& message);
  void onEndSession(Message& message);
  void onEraseBkgnd(Message& message);
  void onGetRevId(Message& message);
  void onKeyMessage(Message& message);
  void onMouseActivate(Message& message);
  void onMouseButtonDown(Message& message);
  void onMouseButtonUp(Message& message);
  void onNcPaint(Message& message);
  void onPaint(Message& message);
  void onSysCommand(Message& message);
  void onWindowPosChanging(Message& message);
};

void BangSetLeftClick(HWND caller, LPCSTR args);
void BangSetRightClick(HWND caller, LPCSTR args);
void BangSetMiddleClick(HWND caller, LPCSTR args);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
