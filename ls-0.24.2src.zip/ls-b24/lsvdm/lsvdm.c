/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

 Oct. 11, 98 - J. Vaughn
               This file contains the source code for virtual desktop manager
			   module.

****************************************************************************/

#include "lsvdm.h"

HINSTANCE hDll;
void ReadConfig();
BOOL OnThisDesk(HWND hWnd);

FARPROC (__stdcall *SwitchToThisWindow)(HWND, int);

windowType *winList;
int maxWin;
deskT desks[MAX_DESKS];
void FindVisTargets(void);

/* Global variables, etc */

HWND refTopLevel = NULL;
HWND LsVDMWnd = NULL; /* Hidden window to receive messages to for LsVDM */
HWND WharfWnd = NULL; /* Wharf view window handle */
HWND NavWnd = NULL; /* Navigator window handle */

COLORREF borderColor, foreColor, backColor, backSelColor;

char szLitestepPath[256];
char szImagePath[256];
int titleSize = 16;
int DeskInView = 1;
int CurrentDesk = 1; /* indicates the current desk we are on */
int nDesksX = 0; /* indicates the number of desks wide the virtual area is */
int nDesksY = 0; /* indicates the number of desks tall the virtual area is */

HBITMAP titlebarImage = NULL;
HBITMAP navBackpix = NULL;
HBITMAP navImage;
HDC navDC;

char LsVDMClassName[] = "LsVDM Message Window"; /* class name of the msg wnd */
char NavClassName[] = "LsVDM Navigator Window"; /* class name of the nav wnd */
char MiniViewClassName[] = "LsVDM MiniView Window"; /* class name of the wharf wnd */

BOOL navHide = FALSE;
int wndSize; /* size of the wharf mininav */
int ScreenWidth, ScreenHeight;
int vdmBaseX = 0, vdmBaseY = 0;

/* functions */

void ReadConfig()
{
	nDesksX = GetRCInt("VDMDesksX",2);
	nDesksY = GetRCInt("VDMDesksY",2);
	/* if we have too few (1 or less) or too many (more than MAX_DESKS) force to 2x2 */
	if ((nDesksX*nDesksY) <= 1) 
	{
		nDesksX = 2;
		nDesksY = 2;
	}
	if ((nDesksX*nDesksY) > MAX_DESKS) 
	{
		nDesksX = 2;
		nDesksY = 2;
	}
}

/************************************************************************/
/* hides all windows on specified desktop                               */
/************************************************************************/
int HideDesk(int desk)
{
	int x;

	for (x = 0; x < maxWin; x++)
	{
		if (IsWindow(winList[x].Handle))
		{
			/* if window hasn't been assigned a desktop yet see if we can do it here */
			if ((winList[x].Desk == 0) || OnThisDesk(winList[x].Handle)) 
			{
					winList[x].Desk = CurrentDesk;
			}
			if (winList[x].Desk == desk)
			{
				winList[x].Position.left += (ScreenWidth*2);
				SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
			}
		}
	}

	return 0;
}

/************************************************************************/
/* unhides all windows on specified desktop                             */
/************************************************************************/
int UnHideDesk(int desk)
{
	int x;

	for (x = 0; x < maxWin; x++) 
	{
		if (IsWindow(winList[x].Handle))
		{
			/* if window hasn't been assigned a desktop yet see if we can do it here */
			if ((winList[x].Desk == 0) || OnThisDesk(winList[x].Handle))
			{
					winList[x].Desk = CurrentDesk;
			}
			if (winList[x].Desk == desk)
			{
				winList[x].Position.left -= (ScreenWidth*2);
				SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
			}
		}
	}

	return 0;
}

void ShowAll()
{
	int x;

	for (x=0;x< maxWin;x++) 
	{
		if (IsWindow(winList[x].Handle))
		{
			winList[x].Position.left %= ScreenWidth;
			SetWindowPos(winList[x].Handle, 0, winList[x].Position.left, winList[x].Position.top, 0, 0, SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);
		}
	}
}

BOOL OnThisDesk(HWND hWnd)
{
	RECT r;

	GetWindowRect(hWnd, &r);
	if ((r.left < ScreenWidth) && (r.right > 0)) return TRUE;
	return FALSE;
}

/************************************************************************/
/* gathers windows to desktop                                           */
/************************************************************************/
void GatherWindows(void)
{
	ShowAll();
}

/************************************************************************/
/* goes to specified desktop                                            */
/************************************************************************/
int GotoDesk(int desk)
{
	if (desk < 1) {return 1;}
	if (desk > (nDesksX*nDesksY)) {return 1;}

	HideDesk(CurrentDesk);
	UnHideDesk(desk);
	CurrentDesk = desk;

	return 0;
}

/************************************************************************/
/* moves up one desktop                                                 */
/************************************************************************/
int MoveUp()
{
	if (CurrentDesk > nDesksX) {
		GotoDesk(CurrentDesk-nDesksX);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves down one desktop                                               */
/************************************************************************/
int MoveDown()
{
	if (CurrentDesk <= (nDesksX*(nDesksY-1))) {
		GotoDesk(CurrentDesk+nDesksX);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves left one desktop                                               */
/************************************************************************/
int MoveLeft()
{
	if ((CurrentDesk % nDesksX) != 1) {
		GotoDesk(CurrentDesk-1);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* moves right one desktop                                              */
/************************************************************************/
int MoveRight()
{
	if ((CurrentDesk % nDesksX) != 0){
		GotoDesk(CurrentDesk+1);
		return 0;
	}
//	Beep(820,915);
	return 1;
}

/************************************************************************/
/* activates the navigator window                                       */
/************************************************************************/
int ActivateNav()
{
	char tbuf[50];
	itoa(CurrentDesk,(char*)&tbuf,10);
	MessageBox(NULL,(char*)&tbuf,"LsVDM Desk #",MB_OK);

	return 0;
}

/************************************************************************/
/* Window Procedure for the LsVDM message window                        */
/************************************************************************/
LRESULT CALLBACK LsVDMWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case HOTKEY_UP: {MoveUp(); return 0;}
	case HOTKEY_DOWN: {MoveDown(); return 0;}
	case HOTKEY_LEFT: {MoveLeft(); return 0;}
	case HOTKEY_RIGHT: {MoveRight(); return 0;}
	case HOTKEY_NAV: {ActivateNav(); return 0;}
	case HOTKEY_DESK: {GotoDesk(wParam); return 0;}
	case GOTO_HWND:
		{
			if (!wParam)
			{
				int i;

				for (i = 0; i < maxWin; i++)
				{
					if (IsWindow(winList[i].Handle))
					{
						if (winList[i].Handle == (HWND)lParam)
						{
							/* if window hasn't been assigned a desktop yet see if we can do it here */
							if ((winList[i].Desk == 0) || OnThisDesk(winList[i].Handle))
							{
									winList[i].Desk = CurrentDesk;
							}
							if (winList[i].Desk != 0 && winList[i].Desk != CurrentDesk)
								GotoDesk(winList[i].Desk);
						}
					}
				}
				SwitchToThisWindow((HWND)lParam, 1);
			} else {
				GatherWindows();
			}
		}
		return 0;
	}
	return DefWindowProc(hWnd,msg,wParam,lParam);
}

int AttatchVisWindows(void)
{
	int i;
	RECT r;
	char szBuf[256];
	char szBuf2[256];

	for (i=0;i<MAX_DESKS;i++)
	{
		if (desks[i].parent) {
			strcpy((char*)&szBuf,"Desk ");
			strcpy((char*)&szBuf,itoa(i,(char*)&szBuf2,10));
			GetWindowRect(desks[i].parent,&r);
			desks[i].x = r.left;
			desks[i].y = r.top;
			desks[i].w = r.right-r.left;
			desks[i].h = r.bottom-r.top;
			desks[i].backImg = LoadLSImage("C:\\litestep\\images\\sehntile.bmp",NULL);
			desks[i].deskWnd = CreateWindowEx(
				WS_EX_TRANSPARENT,(LPCTSTR)&MiniViewClassName,
				(LPCTSTR)&szBuf,WS_CHILD|WS_CLIPSIBLINGS,
				desks[i].x,desks[i].y,desks[i].w,desks[i].h,
				desks[i].parent,NULL,hDll,NULL);
			if (!desks[i].deskWnd) {
				MessageBox(NULL,"Error attatching miniview","LSVDM Error",MB_OK|MB_ICONERROR);
				return 1;
			}
			SetWindowLong(desks[i].deskWnd,GWL_USERDATA,(long)i);
			{
				HDC hdc; = GetDC(hWnd);
				BitBlt(desks[i].backImg, 0, 0, r.right, r.bottom, hdc, 0, 0, SRCCOPY);
				ReleaseDC(hWnd, hdc);
			}
	}
	return 0;
}

void FindVisTargets(void)
{
	int i;
	char szBuf[256];
	char szBuf2[256];

	for (i=0;i<MAX_DESKS;i++)
	{
		strcpy((char*)&szBuf,"VDM");
		strcpy((char*)&szBuf,itoa(i,(char*)&szBuf2,10));
		desks[i].parent = FindWindow(NULL,(char*)&szBuf);
	}
	return;
}

void RefreshMiniView(int d)
{
	return;
}

/************************************************************************/
/* Window Procedure for the LsVDM message window                        */
/************************************************************************/
LRESULT CALLBACK MiniViewWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC screenDC = BeginPaint(hWnd, &ps);
			RECT r;
			GetClientRect(hWnd, &r);
			i = GetWindowLong(hWnd,GWL_USERDATA)
			RefreshMiniView(i);
			BitBlt(screenDC, 0, 0, r.right, r.bottom, desks[i].dblBuf, 
			0, 0, SRCCOPY);
			EndPaint(hWnd, &ps);
			return 0;
		}
	case WM_TIMER:
		{
			RefreshMiniView(GetWindowLong(hWnd,GWL_USERDATA));
			return 0;
		}
	return DefWindowProc(hWnd,msg,wParam,lParam);
	}
}

/* exported functions */

/************************************************************************/
/* initModuleEx, sets up the VDM message window etc                     */
/************************************************************************/
int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath)
{
	WNDCLASS msgWC;
	WNDCLASS miniWC;
	UINT Msgs[10];
	RECT r;

	hDll = dll;
	strcpy(szLitestepPath, szPath);
	GetClientRect(GetDesktopWindow(), &r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	ReadConfig();

	winList = (windowType *)SendMessage(parent, 9400, 0, 0);
	maxWin = (int) SendMessage(parent, 9400, 1, 0);

	/* Register our message window class */
	memset(&msgWC,0,sizeof(WNDCLASS)); /* clear the strucutre */
	msgWC.hInstance = dll;
	msgWC.lpszClassName = (char *)&LsVDMClassName;
	msgWC.lpfnWndProc = (WNDPROC)&LsVDMWndProc;
	RegisterClass(&msgWC);

	/* Register our miniview window class */
	memset(&miniWC,0,sizeof(WNDCLASS)); /* clear the strucutre */
	miniWC.hInstance = dll;
	miniWC.lpszClassName = (char *)&MiniViewClassName;
	miniWC.lpfnWndProc = (WNDPROC)&MiniViewWndProc;
	RegisterClass(&miniWC);

	/* Create our windows */
	LsVDMWnd = CreateWindowEx(WS_EX_TOOLWINDOW,(LPCTSTR)&LsVDMClassName,
		(LPCTSTR)&LsVDMClassName,WS_BORDER,0,0,0,0,NULL,NULL,dll,NULL);

	if (LsVDMWnd != NULL) {SetWindowLong(LsVDMWnd,GWL_USERDATA,magicDWord);}
		else {MessageBox(NULL,"Error Creating Message Window","LSVDM",MB_OK|MB_ICONERROR);}

	FindVisTargets();
	if (AttatchVisWindows()) {
		MessageBox(parent,"Error creating miniview windows.","LSVDM Error",MB_OK|MB_ICONERROR);
		return 1;
	}
 
	Msgs[0] = 8891;
 	Msgs[1] = HOTKEY_UP;
	Msgs[2] = HOTKEY_DOWN;
	Msgs[3] = HOTKEY_LEFT;
	Msgs[4] = HOTKEY_RIGHT;
	Msgs[5] = HOTKEY_NAV;
	Msgs[6] = HOTKEY_DESK;
	Msgs[7] = 0;
	SendMessage(parent, 9263, (WPARAM)LsVDMWnd, (LPARAM) Msgs);
	
	return 0;
};

/************************************************************************/
/* quitModule, destroys the windows etc                                 */
/************************************************************************/
int quitModule(HINSTANCE dll)
{
	/* destroy the windows */
	if (LsVDMWnd != NULL) {DestroyWindow(LsVDMWnd);} /* kill the msg window */
	/* unregister our classes */
	UnregisterClass((LPCTSTR)&LsVDMClassName,dll);
	return 0;
};
