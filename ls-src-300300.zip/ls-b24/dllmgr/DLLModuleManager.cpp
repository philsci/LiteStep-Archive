// DLLModuleManager.cpp: implementation of the DLLModuleManager class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <comdef.h>
#include "DLLModuleManager.h"
#include "..\lsapi\lsapi.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DLLModuleManager::DLLModuleManager(HWND hwnd, LPCTSTR appPath)
{
	this->appPath = _bstr_t(appPath);
	this->hMainWindow = hwnd;

	refCount = 0;
}

DLLModuleManager::~DLLModuleManager()
{
	QuitModules();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE DLLModuleManager::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IDispatch) {
		*ppv = static_cast<IDispatch*>(this);
	} else if (riid == IID_IModuleManager) {
		*ppv = static_cast<IModuleManager*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE DLLModuleManager::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE DLLModuleManager::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

////////////////////////////////////////////////////////////////////////////
// From IDispatch
HRESULT STDMETHODCALLTYPE DLLModuleManager::GetTypeInfoCount( 
    /* [out] */ UINT __RPC_FAR *pctinfo) {

	return NULL;
}
	
HRESULT STDMETHODCALLTYPE DLLModuleManager::GetTypeInfo( 
	/* [in] */ UINT iTInfo,
	/* [in] */ LCID lcid,
	/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) {

	return NULL;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::GetIDsOfNames( 
	/* [in] */ REFIID riid,
	/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
	/* [in] */ UINT cNames,
	/* [in] */ LCID lcid,
	/* [size_is][out] */ DISPID __RPC_FAR *rgDispId) {

	return NULL;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::Invoke( 
	/* [in] */ DISPID dispIdMember,
	/* [in] */ REFIID riid,
	/* [in] */ LCID lcid,
	/* [in] */ WORD wFlags,
	/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
	/* [out] */ VARIANT __RPC_FAR *pVarResult,
	/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
	/* [out] */ UINT __RPC_FAR *puArgErr) {

	return NULL;
}

#define B24

////////////////////////////////////////////////////////////////////////////
// From IModuleManager
HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModules(int __RPC_FAR *count) {
	int myCount = 0;

#ifdef B24
	char buffer[4096], path[256];
	FILE *f;
	sprintf (path, "%s\\step.rc", (const char*)_bstr_t(appPath.c_str()));
	f = LCOpen (path);
	
	if (f) {
		while (LCReadNextCommand (f, buffer, sizeof (buffer))) {
			char *lpszBuffers[4];
			char token1[4096] = {0};
			char token2[4096] = {0};
			char token3[4096] = {0};
			char token4[4096] = {0};
			
			lpszBuffers[0] = token1;
			lpszBuffers[1] = token2;
			lpszBuffers[2] = token3;
			lpszBuffers[3] = token4;
			
			if (LCTokenize (buffer, lpszBuffers, 4, NULL) >= 2) {
				if (!stricmp (token1, "LoadModule")) {
					BOOL Add = TRUE;
					
					/*if (UnderExplorer) {
						if (match("*desktop*", token2)) Add = FALSE;
					}*/
					
					if (Add) {
						BOOL thread = strcmpi(token3, "threaded") == 0;
						BOOL pump = strcmpi(token4, "pump") == 0;
						_bstr_t mystr(token2);
						LoadModule(mystr, 0);
						myCount++;
						//DoEvents(hMainWindow, 5);
					}
				}
			}
		}
		LCClose (f);
	}

#else // new version using new settings
	for (int i = 0; i < 6; i++) {
		LoadModule(modules[i]);
	}
#endif // B24

	if (count) {
		*count = myCount;
	}

	return S_OK;
}


HRESULT STDMETHODCALLTYPE DLLModuleManager::LoadModule(BSTR location, int flags) {
	DLLModule* dllMod = NULL;
	
	if (dllModuleMap.find(wstring(location)) != dllModuleMap.end()) {
		return E_FAIL; // need message saying already loaded
	}

	try {
		int WARNING; // need to do threading stuff
		dllMod = new DLLModule(location, FALSE, FALSE);
	} catch (int error) {
		switch (error) {
		case BAD_MODULE:
			MessageBox(NULL, "Error: Could not load module.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION);
			break;
		case BAD_INIT:
			MessageBox(NULL, "Error: Could not find initModuleEx().\n\nPlease confirm that the dll is a Litestep module,\nand check with the author for updates.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION);
			break;
		case BAD_QUIT:
			MessageBox(NULL, "Error: Could not find quitModule().\n\nPlease conirm that the dll is a Litestep module.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION);
			break;
		}

		delete dllMod;
		return E_FAIL;
	}

	dllModuleMap[wstring(location)] = dllMod;
	try {
		dllMod->Init(hMainWindow, appPath);
	} catch (...) {
		MessageBox(NULL, "Error: Exception during module initialization.\n\nPlease contact the module writer.", _bstr_t(location), MB_OK | MB_ICONEXCLAMATION);
		dllModuleMap.erase(dllModuleMap.find(wstring(location)));
		return E_FAIL;
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModules(void) {
	wstring2module::iterator iter;

	iter = dllModuleMap.begin();

	while (iter != dllModuleMap.end()) {
		if (iter->second) {
			try {
				iter->second->Quit();
				delete iter->second;
			} catch (...) {
				// quietly swallow exceptions
				// debugging/logging code should go here
			}
		}

		iter++;
	}

	dllModuleMap.clear();

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::QuitModule(BSTR location) {
	DLLModule* dllMod;

	if (location != NULL) {
		wstring newLoc = wstring(location);
		if (dllModuleMap.find(newLoc) != dllModuleMap.end()) {
			dllMod = dllModuleMap[newLoc];

			try {
				dllMod->Quit();
				delete dllMod;
			} catch (...) {
				// Quietly swallow exceptions
				// debugging/logging code should go here
			}

			dllModuleMap.erase(newLoc);
		}
	}

	return S_OK;
}
        
HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleList(SAFEARRAY __RPC_FAR * strlist, int __RPC_FAR *count) {
	long lBound;
	long uBound;
	long size;

	BSTR *outList;

	SafeArrayGetLBound(strlist, 1, &lBound);
	SafeArrayGetUBound(strlist, 1, &uBound);

	size = uBound - lBound + 1;

	SafeArrayAccessData(strlist, (void**)&outList);

	wstring2module::iterator iter = dllModuleMap.begin();
	for (int i = 0; i < size && iter != dllModuleMap.end(); i++, iter++) {
		outList[i] = SysAllocString(iter->first.c_str());
	}

	SafeArrayUnaccessData(strlist);

	*count = i;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE DLLModuleManager::GetModuleCount(int __RPC_FAR *count) {
	*count = dllModuleMap.size();

	return S_OK;
}

//////////////////////////////////////////////////////////
// DLLModule class
DLLModule::DLLModule(BSTR loc, BOOL isThreaded, BOOL isPumped) {
	location = loc;
	hThread = NULL;
	pInitEx = NULL;
	pQuit = NULL;
	threaded = isThreaded;
	pumped = isPumped;

	hInstance = LoadLibrary(_bstr_t(location.c_str()));

	if(hInstance) {
		pInitEx = (ModuleInitExFunc)GetProcAddress(hInstance, TEXT("initModuleEx"));
		pQuit = (ModuleQuitFunc)GetProcAddress(hInstance, TEXT("quitModule"));

		if (!pInitEx) {
			throw BAD_INIT;
		}

		if (!pQuit) {
			throw BAD_INIT;
		}
	} else {
		throw BAD_MODULE;
	}
}

DLLModule::~DLLModule() {
	if (hInstance) {
		FreeLibrary(hInstance);
		hInstance = 0;
	}
}

void DLLModule::Init(HWND hMainWindow, wstring theAppPath) {
	if (hInstance) {
		if (pInitEx) {
			mainWindow = hMainWindow;
			appPath = theAppPath;

			if (threaded) {
				SECURITY_ATTRIBUTES sa;

				sa.nLength = sizeof(SECURITY_ATTRIBUTES);
				sa.lpSecurityDescriptor = NULL;
				sa.bInheritHandle = FALSE;

				CreateThread(&sa, 0, DLLModule::ThreadProc, this, NULL, (ULONG*)&hThread);
			} else {
				CallInit();
			}
		}
	}
}

ULONG DLLModule::CallInit() {
	try {
		pInitEx(mainWindow, hInstance, _bstr_t(appPath.c_str()));
	} catch (...) {
		FreeLibrary(hInstance);
		hInstance = NULL;

		return -1;
	}

	return 0;
}

ULONG __stdcall DLLModule::ThreadProc(void* dllModPtr) {
	DLLModule* dllMod = (DLLModule*)dllModPtr;

	if (dllMod->pumped) {
		dllMod->CallInit();

		MSG msg;

		while (GetMessage(&msg, 0, 0, 0)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		return 0;
	} else {
		return dllMod->CallInit();
	}
}

void DLLModule::Quit() {
	if (hInstance) {
		if (pQuit) {
			try {
				pQuit(hInstance);
			} catch (...) {
				MessageBox(NULL, "Exception while quitting module.", _bstr_t(location.c_str()), MB_OK | MB_ICONEXCLAMATION);
			}

			if (hThread) {
				// wait 1 second for thread to terminate on its own
				WaitForSingleObject(hThread, 1000);
				TerminateThread(hThread, 0);
				hThread = 0;
			}
		}
	}
}

HINSTANCE DLLModule::GetInstance() {
	return hInstance;
}

HANDLE DLLModule::GetThread() {
	return hThread;
}

wstring DLLModule::GetLocation() {
	return location;
}
