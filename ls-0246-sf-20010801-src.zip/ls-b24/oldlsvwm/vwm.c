/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/
/****************************************************************************
 14/06/99 - cael
			Added support for up to 256 desks
 09/06/99 - cael
            	Added ability to switch wallpaper for desks 1 - 4
 15/10/98 - B. Kilian
			Brushing off the Dust for the release. Adding the full hotkey
			Functionality and !Gather.
 07/20/98 - MholmesIV
			Removed the erroneous need for a BgBMP value in modules.ini,
			now using the standard method for getting the background BMP.
 07/18/98 - j_edge
			Moved the Hotkey stuff to after LoadStickySettings() since it
			uses inipath which is initialized in that function.
 07/15/98 - j_edge
			Added the BgBMP entry in MODULES.INI to allow user to specify a 
			different bmp than the default bmp. 
			Added the Hotkey entry in MODULES.INI to allow user to choose
			which key is pressed with arrow keys to switch virtual windows.
 06/17/98 - Sehnsucht
			Cleaned up some of the warnings
			Added window 'class' stickies
 06/16/98 - [Drizzt]
			Added transparency to the default bmp
 06/14/98 - Sehnsucht
			Changed the alt-cursors to mskey-cursors.
			Able to use alt-cursors in programs again (Netscape, IE, etc).
 06/02/98 - F. Gastellu
            This file contains the source code for the virtual window
            manager

****************************************************************************/

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <commctrl.h>

#include "vwm.h"
#include "../lsapi/lsapi.h"

#define VWM_DESKNO 0x11110000;

_TCHAR szAppName[] = _TEXT("lsvwm"); // Our window class, etc
const _TCHAR rcsRevision[] = _TEXT("$Revision: 1.1.1.1 $"); // Our Version 
const _TCHAR rcsId[] = _TEXT("$Id: vwm.c,v 1.1.1.1 2001/05/31 11:57:47 headius Exp $"); // The Full RCS ID.

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void (__stdcall *SwitchToThisWindow)(HWND, int);
BOOL CALLBACK searchLSVWMproc(HWND hWnd, LPARAM lParam );
void BangGather(HWND caller, LPCTSTR args);

void ReadConfig (void);

void MoveCursor(int o, int n);
void prefixWinFix(int s);
void postfixWinFix(int s);
void removeWinFix(HWND hwnd);
void addWinFix(HWND hwnd, int s);
int inFix(HWND hwnd);
void CreateImageMasks(HWND hwnd);
void SetDeskTopImage(void);


HWND hMainWnd=NULL; // _tmain window handle
HWND parent;

// Double buffering data
HDC memDC,		// memory device context
	bgDC;
HBITMAP	memBM,  // memory bitmap (for memDC)
		oldBM,  // old bitmap (from memDC)
		oldBG,	// old Bitmap from background
		bBGBitmap;

//wharfDataType wharfData;

UINT Timer=0;
UINT TimerAct=1;

BOOL backInit=FALSE;

int wndSizeX, wndSizeY;
UINT nOffsetX, nOffsetY;
int currentScreen=0;
int ratioX, ratioY;

int ScreenWidth = 800;//1152;
int ScreenHeight = 600;//864;

HWND refToplevel;

void createView(void);
void createRecordedView(void);
void switchToDesktop(int desk);
void gatherAll(void);
int getDesktop(HWND h);
int outsideAnyScreen(RECT r);
int getDesktopByRect(RECT r);
void DoEvents(int n);
void MakeBuffer(HWND hWnd);
int First = 1;

int ScreensX = 2;
int ScreensY = 2;

int MaxScreens = 4;

RECT *deskRect = NULL;

HIMAGELIST hBGList;

winDataType winRect[500];
winFixType winFix[500];

int nWinRect=0;
int movingWin=-1;

int ticksNewW=0;
HWND newW=(HWND)-1;

HWND lastActive=NULL;
RECT oldWinPos;
POINTS lastPoint;
BOOL taskMgrSwitch=FALSE;
BOOL NoBmps = FALSE;
BOOL NeverSwitch = FALSE;

// Automatically set focus to the application
// in the midle of the sceen after having switched
// desktops.
BOOL FocusCenter = FALSE;

// Shall i test for blocked applications before
// i switch the desktop.
BOOL BlockedTimeout = FALSE;

/* supposedly sets up the array to store the image paths */
_TCHAR deskWallpaper[256][256] = {{"_TEXT("}};

volatile int lock=0;

int inchk=0;
int mpos=0;
UINT mTimer=2;
UINT mcTimer=3;
int mTimeout=50;

int searched=0;
HINSTANCE inst;
HWND photoshop;
HWND eudora;

BOOL autoswitch=TRUE;
int VWMDistance=2;
HWND tapp, desk, winswitch;

BOOL NoAuto = FALSE, NoGather = FALSE;

_TCHAR szLitestepPath [256];
_TCHAR szImagePath [256];
_TCHAR inipath[256];

int backColor;
int foreColor;
int selBackColor;
int borderColor;

int borderSize = 0;

//////////// Sticky Window Config Types etc
typedef struct {
	_TCHAR match[80]; //this is the matching text
	int type; //0 (default) for titlematch, 1 (must be specified) for classmatch
} StickyConfigInfoT;
StickyConfigInfoT StickyConfig[256];
////////////////////////////////
// Loads Sticky Window settings
////////////////////////////////
void LoadStickySettings(void)
{
	_TCHAR tmpbuf[80];
	_TCHAR tmpbuf2[80];
	int x, len;
	_tcscpy((_TCHAR *)&inipath,szLitestepPath);
	len = _tcsclen (inipath);
	if (len && inipath[len-1] != '\\')
	{
		inipath[len-1] = '\\';
	}
	_tcscat(inipath,_TEXT("modules.ini"));
	StickyConfig[0].type = GetPrivateProfileInt(_TEXT("lsvwm"),_TEXT("stickies"),0,inipath);
	for (x=StickyConfig[0].type;x>0;x--)
	{
		itoa(x,(_TCHAR *)&tmpbuf,10);
		_tcscpy((_TCHAR *)&tmpbuf2,_TEXT("sticky"));
		_tcscat((_TCHAR *)&tmpbuf2,(_TCHAR *)&tmpbuf);
		GetPrivateProfileString(_TEXT("lsvwm"),(_TCHAR *)&tmpbuf2,_TEXT(""),(_TCHAR *)&StickyConfig[x].match,79,inipath);
		_tcscpy((_TCHAR *)&tmpbuf2,_TEXT("stype"));
		_tcscat((_TCHAR *)&tmpbuf2,(_TCHAR *)&tmpbuf);
		StickyConfig[x].type = GetPrivateProfileInt(_TEXT("lsvwm"),(_TCHAR *)&tmpbuf2,0,inipath);
	}
}


void BangUp(HWND caller, LPCTSTR args)
{
	RECT r;
	if ((currentScreen > (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen - ScreensX);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDown(HWND caller, LPCTSTR args)
{
	RECT r;
	if ((currentScreen < (MaxScreens - ScreensX)) && !lock)
	{
		switchToDesktop(currentScreen+ ScreensX);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangLeft(HWND caller, LPCTSTR args)
{
	RECT r;
	if (((currentScreen % ScreensX) > 0 ) && !lock)
	{
		switchToDesktop(currentScreen-1);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangRight(HWND caller, LPCTSTR args)
{

	RECT r;

	if (((currentScreen % ScreensX) < (ScreensX - 1)) && !lock)
	{
		switchToDesktop(currentScreen+1);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}

void BangDesk(HWND caller, LPCTSTR args)
{
	RECT r;
	int i = _ttoi(args);

	if ((currentScreen != i) && (i >= 0) && (i < MaxScreens) && !lock)
	{
		switchToDesktop(i);
		GetClientRect(hMainWnd, &r);
		createView();
		InvalidateRect(hMainWnd, &r, FALSE);
	}
}


void RegisterBangCommands(void)
{
	AddBangCommand(_TEXT("!GATHER"), BangGather);
	AddBangCommand(_TEXT("!VWMUP"), BangUp);
	AddBangCommand(_TEXT("!VWMDOWN"), BangDown);
	AddBangCommand(_TEXT("!VWMLEFT"), BangLeft);
	AddBangCommand(_TEXT("!VWMRIGHT"), BangRight);
	AddBangCommand(_TEXT("!VWMDESK"), BangDesk);
}

void UnregisterBangCommands(void)
{
	RemoveBangCommand(_TEXT("!GATHER"));
	RemoveBangCommand(_TEXT("!VWMUP"));
	RemoveBangCommand(_TEXT("!VWMDOWN"));
	RemoveBangCommand(_TEXT("!VWMLEFT"));
	RemoveBangCommand(_TEXT("!VWMRIGHT"));
	RemoveBangCommand(_TEXT("!VWMDESK"));
}


//---------------------------------------------------------
// Startup
//---------------------------------------------------------
int initWharfModuleEx (HWND ParentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
	RECT r;
	HDC pDC;
	UINT Msgs[10];
//	int iHotkey;
	int XPos, YPos;
	int sze;

    memset(winFix, 0, sizeof(winFix));

	GetClientRect(GetDesktopWindow(),&r);
	ScreenWidth = r.right;
	ScreenHeight = r.bottom;

	_tcscpy (szLitestepPath, szPath);

	ReadConfig ();

	MaxScreens = ScreensX * ScreensY;
	deskRect = malloc(MaxScreens * sizeof(RECT));

	for (YPos = 0; YPos < ScreensY; YPos ++)
		for (XPos = 0; XPos < ScreensX; XPos ++)
		{
			int desk = (YPos * ScreensX) + XPos;
			int top = YPos * (ScreenHeight + 10);
			int left = XPos * (ScreenWidth + 10);

			deskRect[desk].top = top;
			deskRect[desk].left = left;
			deskRect[desk].right = left + ScreenWidth;
			deskRect[desk].bottom = top + ScreenHeight;
		}

	parent = ParentWnd;
	wndSizeX = (64 - borderSize*2) / ScreensX;
	wndSizeY = (64 - borderSize*2) / ScreensY;
	nOffsetX = ((wndSizeX*ScreensX) - 64)+borderSize;
	nOffsetY = ((wndSizeY*ScreensY) - 64)+borderSize;
	ratioX = ScreenWidth/wndSizeX;
	ratioY = ScreenHeight/wndSizeY;
    inst = dllInst;

    if (NoAuto) autoswitch = FALSE;

    tapp = GetLitestepWnd();

	sze = sizeof(int) | VWM_DESKNO;

    SendMessage(tapp, LM_RESTOREDATA, (WPARAM) sze, (LPARAM) &currentScreen);

	desk = FindWindow(_TEXT("DesktopBackgroundClass"), NULL);
    winswitch = FindWindow(_TEXT("#32771"), NULL);
    (long)SwitchToThisWindow = (long)GetProcAddress(GetModuleHandle(_TEXT("USER32.DLL")), _TEXT("SwitchToThisWindow"));

	{	// Register our window class
		WNDCLASS wc;

		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = dllInst;					// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
		wc.style = CS_DBLCLKS;
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(parent,_TEXT("Error registering window class"),szAppName,MB_OK);
			return 1;
		}
	}


	hMainWnd = CreateWindowEx(
		WS_EX_TRANSPARENT,										// exstyles 
		szAppName,												// our window class name
		_TEXT("LSVWM"),												// use description for a window title
		WS_CHILD,
		borderSize, borderSize,									// position
		64-borderSize*2,64-borderSize*2,						// width & height of window
		parent,													// parent window
		NULL,													// no menu
		dllInst,												// hInstance of DLL
		0);														// no window creation data

	if (!hMainWnd) 
	{
		MessageBox(parent,_TEXT("Error creating window"),szAppName,MB_OK);
		return 1;
	}

	Msgs[0] = LM_BRINGTOFRONT;
	Msgs[1] = LM_SWITCHTON;
	Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;

	SendMessage(tapp, LM_REGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);

	RegisterBangCommands();

	//load sticky windows settings
	LoadStickySettings();

	// Determine which modifier key is being used for the hotkey & register it

	SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

	// create our doublebuffer

	pDC = GetDC(parent);
	memDC = CreateCompatibleDC(pDC);
	memBM = CreateCompatibleBitmap(pDC, wndSizeX*ScreensX+ScreensX,wndSizeY*ScreensY+ScreensY);
	ReleaseDC(parent, pDC);
	oldBM = SelectObject(memDC,memBM);

	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	SetTimer(hMainWnd, Timer, 500, NULL);
	SetTimer(hMainWnd, TimerAct, 250, NULL);
    SetTimer(hMainWnd, mcTimer, 50, NULL);
	return 0;
}


int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	return initWharfModuleEx(ParentWnd, dllInst, wd->lsPath);
}


//-------------------------------------------------------------------------------------------------
// cleanup
//-------------------------------------------------------------------------------------------------
int quitWharfModule(HINSTANCE dllInst)
{
	int Msgs[10];
	
	//config_write(this_mod);		// write configuration
	gatherAll();
/*	UnregisterHotKey(hMainWnd, 0);
	UnregisterHotKey(hMainWnd, 1);
	UnregisterHotKey(hMainWnd, 2);
	UnregisterHotKey(hMainWnd, 3);
*/
    if (mpos)
        {
        mpos = 0;
        KillTimer(hMainWnd, mTimer);
        }
	
	KillTimer(hMainWnd, mcTimer);
	KillTimer(hMainWnd, Timer);
	KillTimer(hMainWnd, TimerAct);


	SelectObject(memDC,oldBM);	// delete our doublebuffer
	SelectObject(bgDC, oldBG);
	DeleteObject(memDC);
	DeleteObject(bgDC);
	DeleteObject(bBGBitmap); // Delete the background Bitmap.
	DeleteObject(memBM);
	ImageList_Remove(hBGList, -1); // _tremove all our images
	ImageList_Destroy(hBGList); // Free up the memory
	UnregisterBangCommands();
	DestroyWindow(hMainWnd); // delete our window
	Msgs[0] = LM_BRINGTOFRONT;
	Msgs[1] = LM_SWITCHTON;
	Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
	SendMessage(tapp, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	UnregisterClass(szAppName,dllInst/*this_mod->hDllInstance*/); // unregister window class

	free(deskRect);
	deskRect = NULL;
	return 0;
}


////////////////////////////////////////////////////////////////
// Checks to see if given window is supposed to be left alone
////////////////////////////////////////////////////////////////
int StickyCheck1(HWND targetWin, LPTSTR matchval)
{
	_TCHAR tmpbuf[80];
	GetClassName(targetWin, (_TCHAR *)&tmpbuf, 79);
	if (match(matchval,(_TCHAR *)&tmpbuf)) {return 1;}
	return 0;
}

int StickyCheck0(HWND targetWin, LPTSTR matchval)
{
	_TCHAR tmpbuf[80];
	GetWindowText(targetWin, (_TCHAR *)&tmpbuf, 79);
	if (match(matchval,(_TCHAR *)&tmpbuf)) {return 1;}
	return 0;
}

int topWindowAlways(HWND targetWin)
{
	int x;
	int issticky;
	issticky = 0;
	x = StickyConfig[0].type;
	//while we havent finished checking against windows to ignore
	while ((x > 0) && (!issticky)) {
		if (StickyConfig[x].type == 1) {issticky = StickyCheck1(targetWin,StickyConfig[x].match);}
		else {issticky = StickyCheck0(targetWin,StickyConfig[x].match);}
		x--;
	}
	return issticky;
}

//-------------------------------------------------------------------------------------------------
// window procedure for our window
//-------------------------------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
//HDC dp;

	switch (message)
	{
		case LM_GETREVID:
			{
				_TCHAR *buf = (_TCHAR *) lParam;

				if (wParam == 0)
				{
					_tcscpy(buf, _TEXT("vwm.dll: "));
					_tcscat(buf, &rcsRevision[11]);
					buf[_tcsclen(buf)-1] = '\0';
				}
				else if (wParam == 1)
				{
					_tcscpy(buf, &rcsId[1]);
					buf[_tcsclen(buf)-1] = '\0';
				} else
				{
					_tcscpy(buf, _TEXT(""));
				}
				return _tcsclen(buf);

			}
		case WM_CREATE:		
            return 0;
		case WM_ERASEBKGND: return 0;
		case WM_PAINT:
			{ // update from doublebuffer
				PAINTSTRUCT ps;
				RECT r;
				HDC hdc = BeginPaint(hwnd,&ps);

				if (First) 
				{
					MakeBuffer(parent);
					CreateImageMasks(parent);
					First = 0;
				}

				GetClientRect(hwnd,&r);
				if (!backInit)
				{
					createView();
					backInit = TRUE;
				}
				BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);
			}
			return 0;
		case WM_KEYDOWN: 
		case WM_KEYUP:
			PostMessage(parent,message,wParam,lParam);
			return 0;
		case WM_RBUTTONDOWN:
			if (lock) 
			{ // Try later
				PostMessage(hwnd, message, wParam, lParam);
				return 0;
			}
			lock = 1;
			{ // Change desktop
				POINTS pts;
				int deskx;
				int desky;
				int s;

				// This just shouldn't have to be here
				//                        PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);

				pts = MAKEPOINTS(lParam);
				deskx = pts.x / wndSizeX;
				desky = pts.y / wndSizeY;
				s = (desky * ScreensX) + deskx;

				if (s != currentScreen) 
				{
					RECT r;
					switchToDesktop(s);
					GetClientRect(hwnd,&r);
					createView();
					InvalidateRect(hwnd, &r, FALSE);
				}
			}
			lock=0;
			return 0;
		case WM_LBUTTONDOWN:
			{ // Move a window from its miniview
				POINTS pts;
				int i;
				int deskX = currentScreen % ScreensX;
				int deskY = currentScreen / ScreensX;

				// This just shouldn't have to be here
	//            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);

				pts = MAKEPOINTS(lParam);
				for (i=0;winRect[i].valid;i++);
				for (i--; i>=0;i--)
				{
			 		if (pts.x - wndSizeX * deskX >= winRect[i].r.left/ratioX &&
						pts.x - wndSizeX * deskX <= winRect[i].r.right/ratioX && 
						pts.y - wndSizeY * deskY >= winRect[i].r.top/ratioY && 
						pts.y - wndSizeY * deskY <= winRect[i].r.bottom/ratioY)
					{
						GetWindowRect(winRect[i].hwnd, &oldWinPos);
						movingWin = i;
						lastPoint = pts;
						SetCapture(hMainWnd); // Capture mouse
						break;
					}
				}
			}
			return 0;

		case WM_LBUTTONUP:
			{ // End moving
				POINTS pts;
				RECT r;
				int s, deskx, desky;

				// This just shouldn't have to be here
	//            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);

				pts = MAKEPOINTS(lParam);
				deskx = pts.x / wndSizeX;
				desky = pts.y / wndSizeY;
				s = (desky * ScreensX) + deskx;
				ReleaseCapture();
							// If we are outside the virtual space, cancel move
				if (pts.x < 0 || pts.y < 0 || pts.x > 64-borderSize*2 || pts.y > 64-borderSize*2)
					MoveWindow(winRect[movingWin].hwnd, oldWinPos.left, oldWinPos.top, oldWinPos.right-oldWinPos.left, oldWinPos.bottom-oldWinPos.top, TRUE);
				else if (GetWindowLong(winRect[movingWin].hwnd, GWL_STYLE) & WS_MAXIMIZE)
				{ // If window is maximized, make it jump to same coordinates on another desktop
					RECT newRect;
					int oldDesk = getDesktopByRect(oldWinPos);
					int newDesk = s;
					newRect.top = oldWinPos.top + deskRect[newDesk].top - deskRect[oldDesk].top;
					newRect.left = oldWinPos.left + deskRect[newDesk].left - deskRect[oldDesk].left;
					newRect.bottom = oldWinPos.bottom + deskRect[newDesk].top - deskRect[oldDesk].top;
					newRect.right = oldWinPos.right + deskRect[newDesk].left - deskRect[oldDesk].left;
					MoveWindow(winRect[movingWin].hwnd, newRect.left, newRect.top, newRect.right-newRect.left, newRect.bottom-newRect.top, TRUE);
					GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				}
				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
				movingWin=-1;
			}
			return 0;
        case WM_MBUTTONDOWN:
			// This just shouldn't have to be here
//            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
		case WM_MOUSEMOVE:
			{ 
				POINTS pts;
				POINTS thisPt;
				RECT r;

				if (movingWin == -1) return 0;
			// We are moving a window with its miniview
				pts = MAKEPOINTS(lParam);
				thisPt = pts;
				pts.x -= lastPoint.x;
				pts.y -= lastPoint.y;
				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				MoveWindow(winRect[movingWin].hwnd, winRect[movingWin].r.left + pts.x*ratioX, winRect[movingWin].r.top + pts.y * ratioY, winRect[movingWin].r.right + pts.x * ratioX - (winRect[movingWin].r.left + pts.x*ratioX), winRect[movingWin].r.bottom + pts.y * ratioY-(winRect[movingWin].r.top + pts.y*ratioY), TRUE);
				GetWindowRect(winRect[movingWin].hwnd, &winRect[movingWin].r);
				lastPoint = thisPt;

				GetClientRect(hwnd,&r);
				createRecordedView();
				InvalidateRect(hwnd, &r, FALSE);
			}
			return 0;

        case WM_LBUTTONDBLCLK:
            { // toggle autoswitch
				_TCHAR txt[50];
				autoswitch = !autoswitch;
				_stprintf(txt, _TEXT("VWM AutoSwitch is now %s"), autoswitch ? _TEXT("ON") : _TEXT("OFF"));
				MessageBox(parent, txt, _TEXT("LiteStep VWM"), 0);
            }
			break;

		case 9355:
			{
				RECT r;
				int i = wParam;

				if ((currentScreen != i) && !lock)
				{
					switchToDesktop(i);
					GetClientRect(hMainWnd, &r);
					createView();
					InvalidateRect(hMainWnd, &r, FALSE);
//					MessageBox(0, ")Switched Windows"), ")VWM"), MB_OK|MB_TOPMOST);
				}
				return TRUE;
			}

		case 8891: // Change window focus via message (change desktop if needed)
			//taskMgrSwitch = TRUE;
			if (lock)
            { // Try later
				PostMessage(hwnd, message, wParam, lParam);
				return TRUE;
			}
			lock = 1;
			{
				int n = getDesktop((HWND)lParam);
				if (n != currentScreen) switchToDesktop(n);
				//SetForegroundWindow((HWND)lParam);
				SwitchToThisWindow((HWND)lParam, 1);
			}
			lock=0;
			return TRUE;

/*		case WM_DISPLAYCHANGE:
            { // Intercept dynamic resolution changes
            int cxScreen = LOWORD(lParam); 
            int cyScreen = HIWORD(lParam);
            int i,d,s;
            RECT r;
            for (i=0;winRect[i].valid;i++)
	            {
                s = GetWindowLong(winRect[i].hwnd, GWL_STYLE) & WS_MAXIMIZE; 
                d = getDesktop(winRect[i].hwnd);
	            GetWindowRect(winRect[i].hwnd, &r);
                if (d & 1)
                    {
   	                r.left-=(ScreenWidth-cxScreen);
                    r.right-=(ScreenWidth-cxScreen);
                    if (s) 
                        r.right-=(ScreenWidth-cxScreen);
                    }
                if (d & 2)
                    {
                    r.top-=(ScreenHeight-cyScreen);
       	            r.bottom-=(ScreenHeight-cyScreen);
    	            if (s)
   	                    r.bottom-=(ScreenHeight-cyScreen);
                    }
                MoveWindow(winRect[i].hwnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
                ScreenWidth = cxScreen;
                ScreenHeight = cyScreen;
            	deskRect[0].top = 0;
	            deskRect[0].left = 0;
	            deskRect[0].right = ScreenWidth;
	            deskRect[0].bottom = ScreenHeight;
	            deskRect[1].top = 0;
	            deskRect[1].left = ScreenWidth+10;
	            deskRect[1].right = ScreenWidth*2+10;
	            deskRect[1].bottom = ScreenHeight;
	            deskRect[2].top = ScreenHeight+10;
	            deskRect[2].left = 0;
	            deskRect[2].right = ScreenWidth;
	            deskRect[2].bottom = ScreenHeight*2+10;
	            deskRect[3].top = ScreenHeight+10;
	            deskRect[3].left = ScreenWidth+10;
	            deskRect[3].right = ScreenWidth*2+10;
	            deskRect[3].bottom = ScreenHeight*2+10;
                }
            }
        return 0;
*/
	case WM_TIMER:
		{ 
			if (lock) // cancel
				return 0;
            if (wParam == mTimer)
            {
                if (autoswitch)
                { // We need to autoswitch (mouse stayed longer than timeout onb a border of the screen)
                    int nmpos=0;
                    int newScreen = currentScreen;
                    DWORD a = GetMessagePos();
                    POINTS pts;
                    pts = MAKEPOINTS(a);

                    if (pts.x == 0) nmpos |= 1;
                    if (pts.y == 0) nmpos |= 2;
                    if (pts.x == ScreenWidth-1) nmpos |= 4;
                    if (pts.y == ScreenHeight-1) nmpos |= 8;

                    if (nmpos)
                    {
                        if ((nmpos & 1) && ((currentScreen % ScreensX) > 0))
	                            newScreen--;
                        if ((nmpos & 2) && ((currentScreen / ScreensX) > 0))
		                        newScreen -= ScreensX;
                        if ((nmpos & 4) && ((currentScreen % ScreensX) < (ScreensX - 1)))
                                newScreen++;
                        if ((nmpos & 8) && ((currentScreen / ScreensX) < (ScreensY - 1)))
                                newScreen += ScreensX;
                    
                        if (currentScreen != newScreen)
                        {
                            RECT r;
                            MoveCursor(currentScreen, newScreen);
                            switchToDesktop(newScreen);
    
	                        GetClientRect(hMainWnd,&r);
                        	createView();
	                        InvalidateRect(hMainWnd, &r, FALSE);
                            mpos = 0;
                        }
                    }
                }
                KillTimer(hMainWnd, mTimer);
                return 0;
            }
            else
                if (wParam == mcTimer)
                {
                    POINTS pts;
                    DWORD a = GetMessagePos();
                    int nmpos = 0;
                    pts = MAKEPOINTS(a);

                    if (pts.x == 0) nmpos |= 1;
                    if (pts.y == 0) nmpos |= 2;
                    if (pts.x == ScreenWidth-1) nmpos |= 4;
                    if (pts.y == ScreenHeight-1) nmpos |= 8;

                    if (!nmpos)
                    {
                        if (mpos)
                        {
                            KillTimer(hMainWnd, mTimer);
                            mpos = 0;
                        }
                    }
                    else
                    {
                        if (!mpos)
                        {
                            mpos = nmpos;
                            SetTimer(hMainWnd, mTimer, mTimeout, NULL);
                        }
                    }
                    return 0;
                }

           	lock = 1;

            if (!wParam) // _tmain timer, update view, check focus change
            {
    		    RECT r;
			    GetClientRect(hwnd,&r);
			    createView();
			    InvalidateRect(hwnd, &r, FALSE);
			}
            else
   			{
   				int style=0;
    			int a=0;
	    		RECT r;
		    	HWND newFGWin = GetForegroundWindow();

   				if (newFGWin)
    			{
	    			style = GetWindowLong(newFGWin, GWL_STYLE);
		    		a = GetWindowLong(newFGWin, GWL_USERDATA);
			   	}
				
    			if ((newFGWin != lastActive) && !NeverSwitch)
	    		{
// This causes a timeout to be applied against focus change, obsolete?
//		   			if (newFGWin == newW)
//		    			{
//			    		ticksNewW++;
//				    	if (ticksNewW > 0)
//					    	{
							if (newFGWin)
							{
								GetWindowRect(newFGWin, &r);
								if (!outsideAnyScreen(r) && 
									!(a == magicDWord || !newFGWin || (newFGWin && IsIconic(newFGWin)) || 
    								  !(style & WS_VISIBLE) || (style & WS_DISABLED) || 
	    							  (lastActive && IsWindow(lastActive) && IsIconic(lastActive)) ||
									  (lastActive && !IsWindow(lastActive))
		   							  || (!taskMgrSwitch && lastActive && GetWindowLong(lastActive, GWL_USERDATA) == magicDWord))
		    						 )
			   					{
				    				int newScr = getDesktop(newFGWin);
					    			if (newScr != currentScreen)
						    			switchToDesktop(newScr);
									taskMgrSwitch=FALSE;
    							}
							}
	    					lastActive = newFGWin;
// End timeout
//		   					newW = (HWND)-1;
//		    				}
//			    		}
//				    else
//  					{
//	    				newW = newFGWin;
//		   				ticksNewW = 0;
//		    			}
			    	}
                }
			}
			lock = 0;
		return 0;

	}

return DefWindowProc(hwnd,message,wParam,lParam);
}

//----------------------------------------------------------------------------
// Get Background bitmap
//----------------------------------------------------------------------------
void MakeBuffer(HWND hWnd)
{
	RECT r;
	POINT p;
	HDC hdc = GetDC(hWnd);
//	HDC hdc = GetDC(GetDesktopWindow());
//	_TCHAR tmp[1024];

	GetClientRect(hWnd,&r);
	p.x = r.left;
	p.y = r.top;
//	ClientToScreen(hWnd, &p);
//	wsprintf(tmp, ")%d : %d"), p.x, p.y);
//	MessageBox(0, tmp, ")Bleh"), MB_OK|MB_TOPMOST);


	bBGBitmap = CreateCompatibleBitmap(hdc, 64, 64);
	bgDC = CreateCompatibleDC(NULL);
	oldBG = (HBITMAP)SelectObject(bgDC, bBGBitmap);
	if (NoBmps)
	{
		HBRUSH oldBrush, hBlueBrush = CreateSolidBrush(backColor);
		HPEN oldpen, pen = CreatePen(PS_SOLID, 1, borderColor);
		
		// draw _tmain bg
		oldBrush = SelectObject(bgDC, hBlueBrush);
		oldpen = SelectObject(bgDC, pen);
		Rectangle(bgDC, 0, 0, 64, 64);

		SelectObject(bgDC, oldpen);
		SelectObject(bgDC, oldBrush);
		DeleteObject(hBlueBrush);
		DeleteObject(pen);
	}
	else
	{
		BitBlt(bgDC, 0, 0, r.right, r.bottom, hdc, p.x, p.y, SRCCOPY);
	}
	ReleaseDC(hWnd, hdc);
}




//----------------------------------------------------------------------------
// Get shifting value from a desktop to another
//----------------------------------------------------------------------------
void getShifts(int old, int desk, int *addH, int *addV)
{
	int oldDeskX = old % ScreensX;
	int oldDeskY = old / ScreensX;

	int deskX = desk % ScreensX;
	int deskY = desk / ScreensX;

	int shiftX = deskX - oldDeskX;
	int shiftY = deskY - oldDeskY;

	*addH = shiftX * (ScreenWidth + 10);
	*addV = shiftY * (ScreenHeight + 10);
}

//-------------------------------------------------------------------------------------------------
// Callback function. Windows enumeration
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{

	/*if (!refTopmost && (GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
		{
		refTopmost = hwnd;
		return !refToplevel;
		}*/

	if (!refToplevel && !(GetWindowLong(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST))
	{
		refToplevel = hwnd;
		return FALSE;//!refTopmost;
	}

	return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Callback functions, check for eudora
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK EudoraEnumChildProc(HWND hwnd, LPARAM lParam)
{
	HWND owner = GetWindow(hwnd, GW_OWNER);

	if (owner != eudora) return TRUE;
    {
	    int style = GetWindowLong(hwnd, GWL_STYLE);

		if (style & WS_VISIBLE && style & WS_POPUP)
        {
	        _TCHAR txt[25];
		    GetWindowText(hwnd, txt, 23);
			if (!_tcscmp(txt, _TEXT("Progress")) || !_tcscmp(txt, _TEXT("No New Mail")) || !_tcscmp(txt, _TEXT("New Mail!")) || !_tcscmp(txt, _TEXT("Eudora Network Timeout")))
            {
				RECT r;
				RECT r2;
				RECT r3;
				GetWindowRect(eudora, &r);
				GetWindowRect(hwnd, &r2);
				r3.left = ((r.right-r.left-(r2.right-r2.left)) / 2) + r.left;
				r3.top = ((r.bottom-r.top-(r2.bottom-r2.top)) / 2) + r.top;
				r3.right = r3.left + (r2.right-r2.left);
				r3.bottom = r3.top + (r2.bottom-r2.top);
				MoveWindow(hwnd, r3.left, r3.top, r3.right-r3.left, r3.bottom-r3.top, TRUE);
            }
        }
    }

	return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Create the wharf view
//-------------------------------------------------------------------------------------------------
void createView(void)
{
	//int i;
	int xoff, yoff;
	HWND prev;
	RECT r;
	int H=0, V=0;
	static int oldnRects=0;
	int nRects=0;
	HBRUSH hWhiteBrush,
		hGreyBrush,
		hBlueBrush,
		oldBrush;
	HPEN pen,oldpen;
	// If we are moving a window from the miniview, cancel drawing
	if (movingWin > -1) return;
	
	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);

	
	BitBlt(memDC, 0, 0, 64, 64, bgDC, 0, 0, SRCCOPY);

	// draw _tmain bg
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);
//	Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);

	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}

	for (xoff=1; xoff < ScreensX; xoff++)
	{
		MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
		LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
	}
	// draw some other stuff
	for (yoff=1; yoff < ScreensY; yoff++)
	{
		MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
		LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
	}

	// calc and draw selected bg
	r.left = nOffsetX+wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+wndSizeY*(currentScreen / ScreensX);
/*	r.right = r.left+wndSizeX+1;//-(currentScreen % ScreensX);
	r.bottom = r.top+wndSizeY+1;//-(currentScreen / ScreensX);
*/	SelectObject(memDC, hGreyBrush);

//	Rectangle(memDC, r.left, r.top, r.right, r.bottom);
	ImageList_DrawEx(hBGList, currentScreen, memDC, r.left+1, r.top+1, wndSizeX-1, wndSizeY-1, 0, selBackColor, ILD_BLEND50);
	
	SelectObject(memDC, hWhiteBrush);
	
	getShifts(0, currentScreen, &H, &V);
	
	refToplevel = NULL;
	nWinRect=0;
	//refTopmost = NULL;
	// Get a topmost window
	EnumWindows(EnumWindowsProc, 0);
	
	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{ 
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
			if (prev == NULL) break;
		
			//added the part at the end to check if its an always on top window
			if ((!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE)) && (!topWindowAlways(prev)))
				continue;
			if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
				continue;
			GetWindowRect(prev, &winRect[nWinRect].r);
			nRects+=(int)prev;
			Rectangle(memDC, (winRect[nWinRect].r.left + H) / ratioX,
				(winRect[nWinRect].r.top + V) / ratioY,
				(winRect[nWinRect].r.right + H) / ratioX,
				(winRect[nWinRect].r.bottom + V) / ratioY);
			winRect[nWinRect].hwnd=prev;
			winRect[nWinRect++].valid=1;
	}
	
	if (nRects != oldnRects)
    {
		if (! (GetWindowLong(winswitch, GWL_STYLE) & WS_VISIBLE) )
        {
			HWND last = GetWindow(desk, GW_HWNDLAST);
			while (last && last != desk)
			{
				if (GetWindowLong(last, GWL_STYLE) & WS_VISIBLE)
				{
					SetWindowPos(last, GetWindow(desk, GW_HWNDPREV), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
					last = GetWindow(desk, GW_HWNDLAST);
					continue;
				}
				last = GetWindow(last, GW_HWNDPREV);
			}
			
			
        }
		oldnRects = nRects;
		eudora = FindWindow(_TEXT("EudoraMainWindow"), NULL);
		if (eudora)
			EnumWindows(EudoraEnumChildProc, 0);
    }
	
	memset(&winRect[nWinRect], 0, sizeof(winDataType));
	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(pen);
}

//-------------------------------------------------------------------------------------------------
// Callback functions. Enumerates windows to be fixed (hidden when not in active desktop)
//-------------------------------------------------------------------------------------------------
BOOL CALLBACK FixEnumChildProc(HWND hwnd, LPARAM lParam)
{
HWND owner = GetWindow(hwnd, GW_OWNER);

if (owner != photoshop) return TRUE;
    {
    int style = GetWindowLong(hwnd, GWL_STYLE);

    if (style & WS_VISIBLE && style & WS_POPUP)
        if (!inFix(hwnd))
            {
            ShowWindow(hwnd, SW_HIDE);
            addWinFix(hwnd, currentScreen);
            }
    }

return TRUE;
}

//-------------------------------------------------------------------------------------------------
// Does the desktop switching
//-------------------------------------------------------------------------------------------------
void switchToDesktop(int _desk)
{
	RECT r;
	HWND prev;
	HDWP dwp;

	int addH=0, addV=0;

	lock = 1;
	if (movingWin > -1) return;

	getShifts(currentScreen, _desk, &addH, &addV);

	// Fix photoshop
	photoshop = FindWindow(_TEXT("Photoshop"), NULL);
	if (photoshop)
		EnumWindows(FixEnumChildProc, 0);

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);

	DoEvents(2);

	dwp = BeginDeferWindowPos(nWinRect+16);

	goto inside;
	while (1)
	{
		DWORD dwResult;
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord /*|| prev == 0xE44*/)
			continue;
	/*	if (SendMessage(tapp, LM_CHECKFORAPPBAR, 0, (long)prev))
			continue;
	*/
	//inserted code here to check if the window has been set to be ignored
		if (!topWindowAlways(prev)) {
			GetWindowRect(prev, &r);
			r.left-=addH;
			r.right-=addH;
			r.top -=addV;
			r.bottom-=addV;

			//MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
			
			// first 'probe' the window, if it does not anser immediately then do not defere it
			// the reason is that defer will issue a SendMessage that is blocking, and if we do that
			// on a blocked window then entire litestep will be blocked.
			if(!BlockedTimeout)
				dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
			else if(SendMessageTimeout(prev, WM_NULL, 0, 0, SMTO_ABORTIFHUNG, 100, &dwResult) != 0)
				dwp = DeferWindowPos(dwp, prev, NULL, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER | SWP_NOACTIVATE);
			}
		}

	currentScreen = _desk;
	EndDeferWindowPos(dwp);

	postfixWinFix(currentScreen);

	/* code to set the wallpaper for any desk till 256 */
	
	/* make sure the user _wants_ the background changed */
	SetDeskTopImage();
	
	if(FocusCenter)
	{// set focus to the window in the middle of the screen
		POINT p;
		p.x = GetSystemMetrics(SM_CXSCREEN)/2;
		p.y = GetSystemMetrics(SM_CYSCREEN)/2;
		SetForegroundWindow(WindowFromPoint(p));
	}

	lock = 0;
}

//-------------------------------------------------------------------------------------------------
// Gather all windows in one desktop
//-------------------------------------------------------------------------------------------------
void gatherAll(void)
{
	//int i;
	RECT r;
	HWND prev;

	if (NoGather)
    {
		int sze = sizeof(int) | VWM_DESKNO;

		SendMessage(tapp, LM_SAVEDATA, (WPARAM) sze, (LPARAM) &currentScreen);

		return;
    }


	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;
	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);
		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			r.right %= (ScreenWidth+10);
		}
		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			r.bottom %= (ScreenHeight+10);
		}
		if (r.left < -10)
		{
			r.right %= (ScreenWidth+10);
			r.right += ScreenWidth;
			r.left %= (ScreenWidth+10);
			r.left += ScreenWidth;
		}
		if (r.top < -10)
		{
			r.bottom %= (ScreenHeight+10);
			r.bottom += ScreenHeight;
			r.top %= (ScreenHeight+10);
			r.top += ScreenHeight;
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}

	currentScreen = 0;
	SetDeskTopImage();
}

//-------------------------------------------------------------------------------------------------
// Creates the view from known window positions
//-------------------------------------------------------------------------------------------------
void createRecordedView(void)
{
	//int i;
	RECT r;
	int H=0, V=0;
	int i, xoff, yoff;
	HBRUSH hWhiteBrush,
		   hGreyBrush,
		   hBlueBrush,
		   oldBrush;
	HPEN pen,oldpen;
	///HDC tempDC; ///this is unreferrenced???
	///char data[1024]; ///this is unreferenced???

	BitBlt(memDC, 0, 0, 64, 64, bgDC, 0, 0, SRCCOPY);

	hBlueBrush = CreateSolidBrush(backColor);
	hWhiteBrush = CreateSolidBrush(foreColor);
	hGreyBrush = CreateSolidBrush(selBackColor);
	pen = CreatePen(PS_SOLID, 1, borderColor);
	oldBrush = SelectObject(memDC, hBlueBrush);
	oldpen = SelectObject(memDC, pen);

	//Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);
	for (yoff=0; yoff < ScreensY; yoff++)
		for (xoff=0; xoff < ScreensX; xoff++)
		{
			ImageList_Draw(hBGList, (yoff*ScreensX)+xoff, memDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), ILD_NORMAL);
		}
/*
	tempDC = CreateCompatibleDC(NULL);
	SelectObject(tempDC, bBGBitmap);
	if (!BitBlt(memDC, 0, 0, 64, 64, tempDC, 0, 0, SRCCOPY)) {
		Rectangle(memDC, 0, 0, wndSize*2, wndSize*2);
		MessageBox(hMainWnd, ")Failed"), ")Error"), MB_OK);
	}
	DeleteDC(tempDC);
*/

	for (xoff=1; xoff < ScreensX; xoff++)
	{
		MoveToEx(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY, NULL);
		LineTo(memDC, nOffsetX + (xoff * wndSizeX), nOffsetY+(ScreensY*wndSizeY));
	}
	// draw some other stuff
	for (yoff=1; yoff < ScreensY; yoff++)
	{
		MoveToEx(memDC, nOffsetX, nOffsetY + (yoff * wndSizeY), NULL);
		LineTo(memDC, nOffsetX+(ScreensX*wndSizeX), nOffsetY + (yoff * wndSizeY));
	}

	r.left = nOffsetX+ wndSizeX*(currentScreen % ScreensX);
	r.top = nOffsetY+ wndSizeY*(currentScreen / ScreensX);
	r.right = r.left+wndSizeX+1;//-(currentScreen & 1);;
	r.bottom = r.top+wndSizeY+1;//-(currentScreen & 2 ? 1 : 0);;
	SelectObject(memDC, hGreyBrush);

//	Rectangle(memDC, r.left, r.top, r.right, r.bottom);
	ImageList_DrawEx(hBGList, currentScreen, memDC, r.left+1, r.top+1, wndSizeX-1, wndSizeY-1, 0, selBackColor, ILD_BLEND50);

	SelectObject(memDC, hWhiteBrush);

	getShifts(0, currentScreen, &H, &V);

	for (i=0;winRect[i].valid;i++)
	{
		GetWindowRect(winRect[i].hwnd, &winRect[i].r);
		Rectangle(memDC, (winRect[i].r.left + H) / ratioX ,
						 (winRect[i].r.top + V) / ratioY,
						 (winRect[i].r.right + H) / ratioX,
						 (winRect[i].r.bottom + V) / ratioY);
	}

	SelectObject(memDC, oldpen);
	SelectObject(memDC, oldBrush);
	DeleteObject(hWhiteBrush);
	DeleteObject(hGreyBrush);
	DeleteObject(hBlueBrush);
	DeleteObject(pen);
}

//-------------------------------------------------------------------------------------------------
// Returns the desktop associated with a window
//-------------------------------------------------------------------------------------------------
int getDesktop(HWND h)
{
	RECT r;
	GetWindowRect(h, &r);
	return (getDesktopByRect(r));
}

//-------------------------------------------------------------------------------------------------
// Get a desktop associated with a RECT
//-------------------------------------------------------------------------------------------------
int getDesktopByRect(RECT r)
{

	int offsetx = currentScreen % ScreensX;
	int offsety = currentScreen / ScreensX;
	int desk;

	r.left += offsetx * (ScreenWidth + 10);
	r.top += offsety * (ScreenHeight + 10);

	offsetx = ((r.left + 10) / (ScreenWidth + 10));
	offsety = ((r.top + 10) / (ScreenHeight + 10));

	desk = (offsety * ScreensX) + offsetx;

	if (desk < 0 || desk > MaxScreens) desk = 0;
	return desk;
}

//-------------------------------------------------------------------------------------------------
// Check if a RECT is outside of the virtual space
//-------------------------------------------------------------------------------------------------
int outsideAnyScreen(RECT r)
{
return (r.left > ScreensX * (ScreenWidth +10) || r.top > ScreensY*(ScreenHeight +10));
}

//-------------------------------------------------------------------------------------------------
// Changes cursor position 
//-------------------------------------------------------------------------------------------------
void MoveCursor(int o, int n)
{
int h, v;
POINT ps;

getShifts(o, n, &h, &v);

GetCursorPos(&ps);
if (h) h -= (h > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
if (v) v -= (v > 0) ? (10 + VWMDistance) : -(10 + VWMDistance);
ps.x -= h;
ps.y -= v;
SetCursorPos(ps.x, ps.y);
}

//-------------------------------------------------------------------------------------------------
// Add a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void addWinFix(HWND hwnd, int s)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd;i++);

	if (i >= 500) return;
	winFix[i].hwnd = hwnd;
	winFix[i].screen = s;
}

//-------------------------------------------------------------------------------------------------
// Remove a photoshop tool-like window to be fixed
//-------------------------------------------------------------------------------------------------
void removeWinFix(HWND hwnd)
{
	int i;
	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);

	if (i >= 500) return;
	winFix[i].hwnd = NULL;
	winFix[i].screen = 0;
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part2)
//-------------------------------------------------------------------------------------------------
void postfixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s)
        {
			ShowWindow(winFix[i].hwnd, SW_SHOWNA);
			winFix[i].hwnd = NULL;
			winFix[i].screen = 0;
        }
    }
}

//-------------------------------------------------------------------------------------------------
// Fixes the window (part 1)
//-------------------------------------------------------------------------------------------------
void prefixWinFix(int s)
{
	int i;
	for (i=0;i<500;i++)
    {
		if (winFix[i].hwnd && winFix[i].screen == s)
			ShowWindow(winFix[i].hwnd, SW_HIDE);
    }
}

//-------------------------------------------------------------------------------------------------
// Checks if a window is in fixed windows list
//-------------------------------------------------------------------------------------------------
int inFix(HWND hwnd)
{
	int i;

	for (i=0;i<500 && winFix[i].hwnd != hwnd;i++);
		if (i>=500) return 0;
	return 1;    
}
 
//-------------------------------------------------------------------------------------------------
// Non blocking wait
// -------------------------------------------------------------------------------------------------------
void DoEvents(int n)
{
	int i;
	BOOL b=TRUE;
	MSG msg;

	for (i=0;i<n && b;i++)
    {
		b = GetMessage( &msg, NULL, 0, 0 );
		if (b) 
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg ); 
		}
    }
}

/*********************************************************************/
/* Create Masked Images                                               */
/*********************************************************************/
void CreateImageMasks(HWND hwnd)
{
	HBITMAP bPane, bOld;
	HDC	hdc = GetDC(hwnd), TempDC;
	int xoff, yoff;

/*	bgDC = CreateCompatibleDC(hdc);
	SelectObject(bgDC, bBGBitmap);
*/
	hBGList = ImageList_Create(wndSizeX, wndSizeY, ILC_COLOR32, 0, ScreensX);

	TempDC = CreateCompatibleDC(hdc);
	bPane = CreateCompatibleBitmap(hdc, wndSizeX, wndSizeY);

	for (yoff = 0; yoff < ScreensY; yoff++)
		for (xoff = 0; xoff < ScreensX; xoff++)
		{
			bOld = (HBITMAP)SelectObject(TempDC, bPane);
			
			if (!BitBlt(TempDC, 0, 0, wndSizeX, wndSizeX, bgDC, nOffsetX+(xoff*wndSizeX), nOffsetY+(yoff*wndSizeY), SRCCOPY))
				MessageBox(hMainWnd, _TEXT("BitBlt failed"), _TEXT("Error"), MB_OK);
			SelectObject(TempDC, bOld);

			if (ImageList_Add(hBGList, bPane, NULL) == -1)
				MessageBox(hMainWnd, _TEXT("Could not add image..."), _TEXT("Error"), MB_OK);
		}

	ReleaseDC(hwnd, hdc);
	DeleteDC(TempDC);
	DeleteObject(bPane);
	DeleteObject(bOld);
/*	DeleteObject(bgDC);
*/
}

void ReadConfig (void)
{
    int desk_number, i;
	_TCHAR current_line[256];

	NoAuto = GetRCBool(_TEXT("VwmNoAuto"), TRUE);
	NoGather = GetRCBool(_TEXT("VwmNoGathering"), TRUE);
	NoBmps = GetRCBool(_TEXT("VWMNoBackBmp"), TRUE);
	NeverSwitch = GetRCBool(_TEXT("VWMNoSwitchOnFocus"), TRUE);
	
	FocusCenter = GetRCBool(_TEXT("VWMFocusCenter"), TRUE);
	BlockedTimeout = GetRCBool(_TEXT("VWMBlockedTimeout"), TRUE);
		
	backColor = GetRCColor(_TEXT("vwmBackColor"), 0x808080);
	selBackColor = GetRCColor(_TEXT("vwmSelBackColor"), 0x404040);
	foreColor = GetRCColor(_TEXT("VWMForeColor"), 0xFFFFFF);
	borderColor = GetRCColor(_TEXT("VWMBorderColor"), 0x000000);   

	ScreensX = GetRCInt(_TEXT("VWMDesksX"), ScreensX);
	ScreensY = GetRCInt(_TEXT("VWMDesksY"), ScreensY);

	mTimeout = GetRCInt(_TEXT("VWMVelocity"), 300);
	VWMDistance = GetRCInt(_TEXT("VWMSecurityDistance"), 5);
	borderSize = GetRCInt(_TEXT("WharfBevelWidth"), 1);

	// Modified - Maduin, 10-20-1999
	//   Changed to use new API LSGetImagePath rather than
	//   access the step.rc directly.

	LSGetImagePath( szImagePath, 256 );

	/* this code _should_ get the wallpapers for the all desktops*/
	desk_number = (ScreensX * ScreensY);	

	for (i = 0; i < desk_number; ++i)
	{
		/* code to get the wallpaper for desk i */
		_stprintf(current_line, _TEXT("VWMDeskWallpaper%d"), i+1);
    	GetRCString(current_line, deskWallpaper[i], _TEXT(""), MAX_PATH);
    }


}

void SetDeskTopImage(void)
{
	if (deskWallpaper[currentScreen] && (deskWallpaper[currentScreen][0] != '\0' ))
	{
		SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, deskWallpaper[currentScreen], SPIF_UPDATEINIFILE);
	}
}

void BangGather(HWND caller, LPCTSTR args)
{
	RECT r;
	HWND prev;

	refToplevel = NULL;
	EnumWindows(EnumWindowsProc, 0);

	prev = GetWindow(refToplevel, GW_HWNDLAST);
	goto inside;

	while (1)
	{
		prev = GetWindow(prev, GW_HWNDPREV);
		inside:
		if (prev == NULL) break;

		if (!(GetWindowLong(prev, GWL_STYLE) & WS_VISIBLE))
			continue;
		if (GetWindowLong(prev, GWL_USERDATA) == magicDWord)
			continue;
		GetWindowRect(prev, &r);

		if (r.left > ScreenWidth)
		{
			r.left %= (ScreenWidth+10);
			if (r.left > ScreenWidth)
				r.left -= (ScreenWidth + 10);
			r.right %= (ScreenWidth+10);
		}
		else if (r.right < 0)
		{
			r.right %= (ScreenWidth+10);
			if (r.right < 0)
				r.right += (ScreenWidth + 10);
			r.left %= (ScreenWidth+10);
			if (r.left < -10)
				r.left += (ScreenWidth + 10);
		}

		if (r.top > ScreenHeight)
		{
			r.top %= (ScreenHeight+10);
			if (r.top > ScreenHeight)
				r.top -= (ScreenHeight + 10);
			r.bottom %= (ScreenHeight+10);
		}
		else if (r.bottom < 0)
		{
			r.bottom %= (ScreenHeight+10);
			if (r.bottom < 0)
				r.bottom += (ScreenHeight + 10);
			r.top %= (ScreenHeight+10);
			if (r.top < -10)
				r.top += (ScreenHeight + 10);
		}
		MoveWindow(prev, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	}
}

/*
	$Log: vwm.c,v $
	Revision 1.1.1.1  2001/05/31 11:57:47  headius
	importing LiteStep b24 code into cvs
	
	Revision 1.7.2.4  2001/01/21 00:21:24  message
	*** empty log message ***
	
	Revision 1.7.2.3  2001/01/20 03:34:38  message
	*** empty log message ***
	
	Revision 1.7.2.1  2001/01/19 22:17:12  message
	*** empty log message ***
	
	Revision 1.7  2000/05/13 00:30:03  NeXTer
	Update of Shortcuts, and some tweaks in the parsers
	
	Revision 1.19  1999/10/21 03:12:03  maduin
	Readded old RC commands to smooth the transition to new ones
	
	Revision 1.11  1998/11/27 09:00:51  bryan
	Pseudo Transparency for the wharf. eliminates those awful pink module backgrounds
	
	Revision 1.10  1998/11/17 00:36:07  bryan
	Fixed the crash on recycle bug in VWM.dll.
	Also added new abilities LM_SAVEDATA and LM_RESTOREDATA.
	
	Revision 1.9  1998/11/16 06:07:27  bryan
	Some fixes in VWM and a fix for transparency in popups.
	
	Revision 1.8  1998/11/14 00:18:12  bryan
	We finally now have a n*n working VWM. use VWMDesksX and VWMDesksY
	Also fixed a VWM mode with no background BMP. use VWMNoBackBmp
	
	Revision 1.7  1998/11/06 19:11:57  bryan
	Added automatic versioning info. The CVS will take care of the
	versioning numbers.
	Bind !About to a key (and !About Detailed)
	
 */
