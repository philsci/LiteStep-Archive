/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "FolderItem.h"
#include "PopupMenu.h"
#include "TitleItem.h"
#include "Painter.h"
#include "../lsapi/macros.h"
int FolderItem::m_nOverlapX = 5;
int FolderItem::m_nOverlapY = 5;
int FolderItem::m_nDelay = 0;
BOOL FolderItem::m_bDrawArrow = TRUE;

FolderItem::FolderItem(PopupMenu* pSubMenu, _TCHAR* pszTitle) : TitleItem(pszTitle)
{
	m_pSubMenu = pSubMenu;
	m_nTimerId = 0;
	m_nSortPriority = 10;
}

FolderItem::~FolderItem()
{
	if(m_pSubMenu) delete m_pSubMenu;
	m_pSubMenu = NULL;
}

// Paints the folder item, the parent class will paint first
// then will we add the |> icon
void FolderItem::Paint(HDC hDC)
{
	TitleItem::Paint(hDC);

	if(m_bDrawArrow)
		PaintArrow(hDC, m_nTop);
}

void FolderItem::GetTitleRect(RECT* r)
{
	TitleItem::GetTitleRect(r);
	// r->right = r->right - (m_bDrawArrow ? 16 : 0);
}

void FolderItem::PaintArrow(HDC hDC, int nTop)
{
	/* taken from the standard ls popup.cpp, witten by the ls dev team */
	HPEN hOldPen;
	HPEN hPen = CreatePen(PS_SOLID, 1, m_nDarkColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);

	int x = GetWidth() - GetRightIndent();

	// First 2 lines are dark gray
	MoveToEx(hDC, x - 14, nTop + ((GetHeight() - 1) / 2) + 4, NULL);
	LineTo(hDC, x - 14, nTop + ((GetHeight() - 1) / 2) - 4);
	LineTo(hDC, x - 7, nTop + ((GetHeight() - 1) / 2));
	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);

	hPen = CreatePen(PS_SOLID, 1, m_nLightColor);
	hOldPen = (HPEN) SelectObject(hDC, hPen);

	// Finish it off with a white line
	LineTo(hDC, x - 14, nTop + ((GetHeight() - 1) / 2) + 4);

	SelectObject(hDC, hOldPen);
	DeleteObject(hPen);
}

void FolderItem::Attached(PopupMenu* pMenu)
{
	TitleItem::Attached(pMenu);	

	m_pParent->AddChild(m_pSubMenu);
	m_pSubMenu->SetParent(m_pParent);
}


void FolderItem::Invoke()
{
	Active(TRUE);
}

BOOL FolderItem::Active(BOOL bActivate)
{
//	if(IsActive() == bActivate)
//		return bActivate;	

	BOOL result=TitleItem::Active(bActivate);

	if(bActivate)
	{
		if(!IsWindowVisible(m_pSubMenu->GetWindow()) && m_nTimerId == 0)
		{
			m_nTimerId = (UINT)this;
			SetTimer(GetWindow(), m_nTimerId, m_nDelay, NULL);
		}
	}
	else
	{	
		if(m_nTimerId != 0)
			KillTimer(GetWindow(), m_nTimerId);
		m_nTimerId = 0;
		if(m_pSubMenu != NULL)
		{
			if(IsWindowVisible(m_pSubMenu->GetWindow()))
				m_pSubMenu->Hide(HIDE_CHILDREN);
		}
	}

	return result;
}

void FolderItem::Timer(int nTimer)
{
	if((UINT)nTimer == m_nTimerId)
	{
		ShowSubMenu();
		KillTimer(GetWindow(), m_nTimerId);
		m_nTimerId = 0;
	}
}

void FolderItem::ShowSubMenu()
{
	RECT r;
	RECT s;
	RECT rParent;
	PopupMenu* pParent;
	int x,y;

#pragma COMPILE_WARN(NOTE: Might need to make this function for the current monitor only)

	// This window 
	GetWindowRect(GetWindow(), &r);

	// Sub folder window
	GetWindowRect(m_pSubMenu->GetWindow(), &s);

	pParent = m_pParent->GetParent();
	if(pParent)
		GetWindowRect(pParent->GetWindow(), &rParent);

	// Get width of screen
	int screenx = SCREEN_WIDTH;

	// Get height of screen
	int screeny = SCREEN_HEIGHT;

	y = r.top + m_nTop + m_nOverlapY;
	if(y + (s.bottom - s.top) > screeny)
		y = screeny - (s.bottom - s.top);

	if(pParent && (rParent.left > r.left))
		// if my window is to the left of my parent menu
		x = r.left - (s.right - s.left) + m_nOverlapX;
	else
		// else try to go right
		x = r.right - m_nOverlapX;

	// if the new window is too far to the right
	if(x + (s.right - s.left) > screenx)
		x = r.left - (s.right - s.left) + m_nOverlapX;

	// if the new window is too far to the left
	if(x < SCREEN_LEFT)
		x = r.right - m_nOverlapX;

	// keep focus on this folder.. 
	SetForegroundWindow(GetWindow()); 

	m_pSubMenu->Show(x, y);
}

BOOL FolderItem::Key(int nKey)
{
	BOOL bConsumed = FALSE;
	if(IsActive())
	{
		switch(nKey)
		{
		case VK_RIGHT:
			ShowSubMenu();

			// move the focus to the folder 
			SetForegroundWindow(m_pSubMenu->GetWindow());

			// send a vk_down, a hack to make the user not having to press
			// arrow down to ...
			PostMessage(m_pSubMenu->GetWindow(), WM_KEYDOWN, VK_DOWN, 0);
			bConsumed = TRUE;
			break;
		case VK_LEFT:
			if(m_pParent->GetParent() != NULL)
			{
				m_pSubMenu->Hide(HIDE_CHILDREN);
				SetForegroundWindow(GetWindow());
				bConsumed = TRUE;
			}
			break;
		}
	}

	if(m_nShortcut == nKey)
	{
		// HACK to activate this menuitem and disable the
		// other menuitems.
		m_pParent->Mouse(WM_MOUSEMOVE, 0, m_nTop);
		bConsumed=TRUE;
	}
	return bConsumed;
}

