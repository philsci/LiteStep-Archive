/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "systray.h"
#include <commctrl.h>
#include <shellapi.h>
#include <stdio.h>

#include <algorithm>

using namespace std;

// defined directions
#define TD_VERTICAL    0x1
#define TD_TOTOPLEFT   0x2

#define TD_RIGHT       0x0
#define TD_LEFT        (TD_TOTOPLEFT)
#define TD_UP          (TD_TOTOPLEFT|TD_VERTICAL)
#define TD_DOWN        (TD_VERTICAL)

#define REGKEY_SAVEDDATA     TEXT(_TEXT("Software\\LiteStep\\Systray\\SavedData"))

// name of shelldesktop class
#define WC_SHELLDESKTOP    TEXT(_TEXT("DesktopBackgroundClass"))

const _TCHAR szAppName[] = _TEXT("systray"); // Our window class, etc

const _TCHAR rcsRevision[] = _TEXT("$Revision: 1.1.2.16 $"); // Our Version*/
const _TCHAR rcsId[] = _TEXT("$Id: systray.cpp,v 1.1.2.16 2001/02/02 21:55:54 headius Exp $"); // The Full RCS ID.*/

systray *tray; // The module

//=========================================================
// Initialization and cleanup
//=========================================================

int initModuleEx(HWND parentWnd, HINSTANCE dllInst, LPCTSTR szPath)
{
  int code;
  Window::init(dllInst);
  tray = new systray(parentWnd, code);
  return code;
}
int initWharfModule(HWND parentWnd, HINSTANCE dllInst, void *wharfData)
{
  int code;
  Window::init(dllInst);
  tray = new systray(parentWnd, code);
  return code;
}
void quitModule(HINSTANCE dllInst)
{
  delete tray;
}
void quitWharfModule(HINSTANCE dllInst)
{
  delete tray;
}

// BANG COMMAND FUNCTIONS

void bangShow( HWND sender, const _TCHAR *args )
{
	tray->show();
}
void bangHide( HWND sender, const _TCHAR *args )
{
  tray->hide();
}
void bangToggle( HWND sender, const _TCHAR *args )
{
	tray->toggle();
}
void bangOnTop( HWND sender, const _TCHAR *args )
{
	tray->toggleOnTop();
}
void bangMove( HWND sender, const _TCHAR *args )
{
	_TCHAR szX[MAX_LINE_LENGTH], szY[MAX_LINE_LENGTH];
	_TCHAR *tokens[2] = {szX,szY};
	LCTokenize( args, tokens, 2, NULL );
	tray->move(_ttoi(szX),_ttoi(szY));
}
void bangSize( HWND sender, const _TCHAR *args )
{
	_TCHAR szCX[MAX_LINE_LENGTH], szCY[MAX_LINE_LENGTH];
	_TCHAR *tokens[2] = {szCX,szCY};
	LCTokenize( args, tokens, 2, NULL );
	tray->size(_ttoi(szCX),_ttoi(szCY));
}

//=========================================================
// Module code
//=========================================================

//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
systray::systray(HWND parentWnd, int& code):
Window(szAppName)
{
	// reading settings for window creation
  // ======================================

	shelltray = NULL;

  // get ls window handle
  liteStep = GetLitestepWnd();
	desktop = FindWindow(WC_SHELLDESKTOP, NULL);
	if (!desktop)
		desktop = GetDesktopWindow();

  // if the parent window is not litestep, it must be the wharf
  inWharf = (parentWnd!=liteStep);

	// get the position and size of the _tmain window
	// using different method if it's docked in the wharf
  if ( inWharf )
  {
		RECT rc;
	  int  wharfBorder;

	  // get the wharf window size
	  GetClientRect( parentWnd, &rc );
	  wharfBorder = GetRCInt( _TEXT("WharfBevelWidth"), 0 );

	  trayX = wharfBorder;
	  trayY = wharfBorder;
	  trayWidth = rc.right - 2 * wharfBorder;
	  trayHeight = rc.bottom - 2 * wharfBorder;
  }
  else
  {
		trayX = GetRCInt( _TEXT("systrayX"), 0 );
		if ( trayX < 0 )
			trayX += GetSystemMetrics(SM_CXSCREEN);
	  trayY = GetRCInt( _TEXT("systrayY"), 0 );
		if ( trayY < 0 )
			trayY += GetSystemMetrics(SM_CYSCREEN);
	  trayWidth = GetRCInt( _TEXT("systrayWidth"), 64 );
	  trayHeight = GetRCInt( _TEXT("systrayHeight"), 64 );
  }

//  OutputDebugString(_TEXT("just before window creation\n"));

  if (!createWindow(WS_EX_TOOLWINDOW,szAppName,inWharf?WS_CHILD:WS_POPUP,
                    trayX,trayY,trayWidth,trayHeight,(inWharf?parentWnd:desktop)))
  {

	  RESOURCE_MSGBOX(hInstance, IDS_SYSTRAY2_ERROR3,
		  _TEXT("Unable to create window."), szAppName)

    code = 1;
    return;
  }

  code = 0;
}

systray::~systray()
{
  destroyWindow();
}

void systray::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate,            WM_CREATE)
    MESSAGE(onDestroy,           WM_DESTROY)
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onGetRevId,          LM_GETREVID)
		MESSAGE(onRestoreTray,       LM_RESTORESYSTRAY)
		MESSAGE(onSaveTray,          LM_SAVESYSTRAY)
		MESSAGE(onSysTray,           LM_SYSTRAY)
		MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
    MESSAGE(onKeyMessage,        WM_KEYDOWN)
    MESSAGE(onKeyMessage,        WM_KEYUP)
    MESSAGE(onKeyMessage,        WM_HOTKEY)
    MESSAGE(onMouse,             WM_LBUTTONDOWN)
    MESSAGE(onMouse,             WM_MBUTTONDOWN)
    MESSAGE(onMouse,             WM_RBUTTONDOWN)
    MESSAGE(onMouse,             WM_LBUTTONUP)
    MESSAGE(onMouse,             WM_MBUTTONUP)
    MESSAGE(onMouse,             WM_RBUTTONUP)
    MESSAGE(onMouse,             WM_LBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_MBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_RBUTTONDBLCLK)
    MESSAGE(onMouse,             WM_MOUSEMOVE)
    MESSAGE(onPaint,             WM_PAINT)
    MESSAGE(onPaint,             LM_REPAINT)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
  END_MESSAGEPROC
}

void systray::onEndSession(Message& message)
{
  message.lResult = SendMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void systray::onKeyMessage(Message& message)
{
  // Forward these messages
  PostMessage(liteStep, message.uMsg, message.wParam, message.lParam);
}
void systray::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(liteStep, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void systray::onCreate(Message& message)
{
  _TCHAR szTemp[256];
  int tmpInteger = 0;
  int msgs[] = {LM_GETREVID,LM_RESTORESYSTRAY,LM_SAVESYSTRAY,LM_SYSTRAY,0};

	// register messages
  SendMessage(liteStep, LM_REGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	// has to be done
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  // make sure it handle dblclicks... =)
  SetClassLong(hWnd,GCL_STYLE,CS_DBLCLKS|GetClassLong(hWnd,GCL_STYLE));

	// load settings here
	// ===========================================
	visible         = inWharf || GetRCBool(_TEXT("systrayHidden"), FALSE);
	onTop           = !inWharf && GetRCBool(_TEXT("systrayAlwaysOnTop"), TRUE);
	hideIfEmpty     = !inWharf && GetRCBool(_TEXT("systrayHideIfEmpty"), TRUE);
	autoSize        = !inWharf && GetRCBool(_TEXT("systrayAutoSize"), TRUE);
	tmpInteger      = GetRCInt(_TEXT("systrayBorderSize"),0);
	borderTop       = max(GetRCInt(_TEXT("systrayBorderTop"),tmpInteger),0);
	borderLeft      = max(GetRCInt(_TEXT("systrayBorderLeft"),tmpInteger),0);
	borderRight     = max(GetRCInt(_TEXT("systrayBorderRight"),tmpInteger),0);
	borderBottom    = max(GetRCInt(_TEXT("systrayBorderBottom"),tmpInteger),0);
	borderDrag      = !inWharf && GetRCBool(_TEXT("systrayBorderDrag"),TRUE);
	snapDistance    = max(GetRCInt(_TEXT("systraySnapDistance"), (GetRCBool(_TEXT("systraySnap"),TRUE) ? 10 : 0)),0);

	// colors
	clrBack         = GetRCColor(_TEXT("systrayBGColor"),RGB(255,255,255));
	clrBorder       = GetRCColor(_TEXT("systrayBorderColor"),RGB(0,0,0));

	// skinning
  GetRCString(_TEXT("systrayBitmap"),szTemp, "" ,256);

  if ( szTemp[0] == '\0' )
	{
    hbmSkin = NULL;
		transpSkin = (clrBack==RGB(255,0,255));
		if (!transpSkin)
			transpSkin = (borderTop+borderLeft+borderRight+borderBottom>0) && (clrBorder==RGB(255,0,255));
  }
	else
	{
		BITMAP bm;
		HRGN hBitmapRgn, hOpaqueRgn;

    hbmSkin = LoadLSImage(szTemp, NULL);

		// get info from the bitmap
    GetObject( hbmSkin, sizeof(BITMAP), &bm );

		hBitmapRgn = BitmapToRegion( hbmSkin, RGB(255,0,255), 0x101010, 0, 0);
		hOpaqueRgn = CreateRectRgn( 0, 0, bm.bmWidth, bm.bmHeight );

		// to see if any pixels are transparent
		transpSkin = !EqualRgn( hBitmapRgn, hOpaqueRgn );

		DeleteObject( hBitmapRgn );
		DeleteObject( hOpaqueRgn );
	}
  skinTiled = GetRCBool(_TEXT("systrayBitmapTiled"),TRUE);

	// initiate vars for the background creation
	hbmBack     = NULL;
	transpBack = FALSE;

	//tray wrapping
  wrapCount = max(GetRCInt(_TEXT("systrayWrapCount"),0),0);

  // get direction
  GetRCString(_TEXT("systrayDirection"),szTemp,"",256);
  if ( !::strnicmp(szTemp, _TEXT("left"), 5) )
    direction = TD_LEFT;
  else if ( !::strnicmp(szTemp, _TEXT("up"), 3) )
    direction = TD_UP;
  else if ( !::strnicmp(szTemp, _TEXT("down"), 5) )
    direction = TD_DOWN;
	else
		direction = TD_RIGHT;

  // get wrap-direction
  GetRCString(_TEXT("systrayWrapDirection"),szTemp,"",256);
  if (direction & TD_VERTICAL) {
      if ( !::strnicmp( szTemp, _TEXT("left"), 5 ) )
          wrapDirection = TD_LEFT;
      else
          wrapDirection = TD_RIGHT;
  } else {
      if ( !::strnicmp( szTemp, _TEXT("up"), 3) )
          wrapDirection = TD_UP;
      else
          wrapDirection = TD_DOWN;
  }

	// icon
	iconSize     = max(GetRCInt( _TEXT("systrayIconSize"), 16 ),0);
  iconSpacingX = max(GetRCInt( _TEXT("systrayIconSpacingX"), 1 ),0);
	iconSpacingY = max(GetRCInt( _TEXT("systrayIconSpacingY"), 1 ),0);

  // this section evaluates how the placing of new icons should be calculated
  deltaX = ((( direction & TD_VERTICAL ) ? wrapDirection : direction ) == TD_LEFT) ? -1 : 1;
  deltaY = ((( direction & TD_VERTICAL ) ? direction : wrapDirection ) == TD_DOWN) ? 1 : -1;

	deltaX *= iconSize + iconSpacingX;
	deltaY *= iconSize + iconSpacingY;

	setFirstLast();
	createBackground();

  //OutputDebugString(_TEXT("done reading step.rc\n"));

	// NOT FOR WHARF
	if ( !inWharf ) {

		AddBangCommand( _TEXT("!systrayhide"), bangHide );
		AddBangCommand( _TEXT("!systrayshow"), bangShow );
		AddBangCommand( _TEXT("!systraytoggle"), bangToggle );
		AddBangCommand( _TEXT("!systrayontop"), bangOnTop );
		AddBangCommand( _TEXT("!systraymove"), bangMove );
		AddBangCommand( _TEXT("!systraysize"), bangSize );

	}

	// set always on top
	if (onTop)
		SetWindowPos( hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );

	// show window
	ShowWindow( hWnd, (!visible||hideIfEmpty)?SW_HIDE:SW_SHOWNOACTIVATE );
	InvalidateRect( hWnd, NULL, TRUE );

	// create a tooltip window
	tooltip = CreateWindowEx(WS_EX_TOOLWINDOW|WS_EX_TOPMOST,TOOLTIPS_CLASS,NULL,TTS_ALWAYSTIP|WS_POPUP,0,0,0,0,hWnd,NULL,NULL,NULL);

	uLastID = 1;
	pFirst = NULL;
	pLast = NULL;

	// Win98/IE4 stuff
//	PostMessage( HWND_BROADCAST, RegisterWindowMessage(_TEXT("TaskbarCreated")), 0, 0 );

  //OutputDebugString(_TEXT("done initiating, except shellTray\n"));

	if( !FindWindow(WC_SHELLTRAY, NULL) ) {
		shelltray = new shellTray(liteStep, hInstance);
	}

  //OutputDebugString(_TEXT("done initiating\n"));
	// Win98/IE4 stuff
	PostMessage( HWND_BROADCAST, RegisterWindowMessage(_TEXT("TaskbarCreated")), 0, 0 );

}

void systray::onDestroy(Message& message)
{
	int msgs[] = {LM_GETREVID,LM_RESTORESYSTRAY,LM_SAVESYSTRAY,LM_SYSTRAY,0};

	//OutputDebugString(_TEXT("before deleting shelltray\n_TEXT(" );
	if ( shelltray )
		delete shelltray;
	shelltray = NULL;

	//OutputDebugString(_TEXT("after deleting shelltray\n_TEXT(" );
	//OutputDebugString(_TEXT("before removing bang commands\n_TEXT(" );

	// NOT FOR WHARF
	if ( !inWharf )
	{
		RemoveBangCommand(_TEXT("!systrayHide"));
		RemoveBangCommand(_TEXT("!systrayShow"));
		RemoveBangCommand(_TEXT("!systrayToggle"));
		RemoveBangCommand(_TEXT("!systrayOnTop"));
		RemoveBangCommand(_TEXT("!systrayMove"));
		RemoveBangCommand(_TEXT("!systraySize"));
	}

	//OutputDebugString(_TEXT("after removing bang commands\n_TEXT(" );
	//OutputDebugString(_TEXT("before unregistering messages\n_TEXT(" );

	SendMessage(liteStep, LM_UNREGISTERMESSAGE, (WPARAM)hWnd, (LPARAM)msgs);

	//OutputDebugString(_TEXT("after unregistering messages\n_TEXT(" );
	//OutputDebugString(_TEXT("before deletion of icons\n_TEXT(" );

	// destroy the list of icons
	iconListDelAll();

	//OutputDebugString(_TEXT("after deletion of icons\n_TEXT(" );
	//OutputDebugString(_TEXT("before deletion of gdi-objects\n_TEXT(" );

	// destroy the tooltip window
	if (tooltip)
		DestroyWindow( tooltip );
    // delete gdi objects...
	if (hbmSkin)
		DeleteObject( hbmSkin );
	if (hbmBack)
		DeleteObject( hbmBack );
	if (hrgnBack)
		DeleteObject( hrgnBack );

	//OutputDebugString(_TEXT("after deletion of gdi-objects\n_TEXT(" );

}

void systray::onGetRevId(Message& message)
{
  LPTSTR buf = (LPTSTR)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      _stprintf(buf, _TEXT("systray.dll: %s"), &rcsRevision[11]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    case 1:
      _tcscpy(buf, &rcsId[1]);
      buf[_tcsclen(buf) - 1] = '\0';
      break;
    default:
      _tcscpy(buf, _TEXT(""));
  }
  message.lResult = _tcsclen(buf);
}

void systray::onRestoreTray(Message& message)
{
	if ( !iconListLoad( (void *)(message.lParam) ) )
		iconListLoadMaduin();
}

void systray::onSaveTray(Message& message)
{
	iconListSave( (void *)(message.lParam) );
}

void systray::onSysTray(Message& message)
{
	switch( message.wParam )
	{
		case NIM_ADD:
		{
			message.lResult = (BOOL)( iconAdd( (PNOTIFYICONDATA)message.lParam ) != NULL );
			break;
		}
		case NIM_MODIFY:
		{
			message.lResult = (BOOL)( iconMod( (PNOTIFYICONDATA)message.lParam ) != NULL );
			break;
		}
		case NIM_DELETE:
		{
			message.lResult = (BOOL)iconDel( (PNOTIFYICONDATA)message.lParam );
			break;
		}
		default:
		{
			message.lResult = FALSE;
			break;
		}
	}
}

void systray::onMouse(Message& message)
{
  if (!onMouseIcon(message))
	{
		int x = message.lParamLo, y = message.lParamHi;
		if (message.uMsg==WM_LBUTTONDOWN)
		{
			if ( borderDrag && ( (x<=borderLeft) || (x>=trayWidth-borderRight) ||
													 (y<=borderTop) || (y>=trayHeight-borderBottom) ) )
				SendMessage( hWnd, WM_SYSCOMMAND, SC_MOVE|2, message.lParam );
		}
		else if (message.uMsg==WM_RBUTTONUP)
		{
      POINT point = {x, y};

      ClientToScreen(hWnd, &point);
			PostMessage( liteStep, LM_POPUP, 0, MAKELPARAM(point.x, point.y) );
		}
	}
	message.lResult = DefWindowProc(hWnd,message.uMsg,message.wParam,message.lParam);
}

BOOL systray::onMouseIcon(Message& message)
{
	PSYSTRAYICON pSysTrayIcon;
	MSG msg;
  POINT pt;
  pt.x = message.lParamLo;
  pt.y = message.lParamHi;

	// send message to the tooltip
	msg.hwnd = hWnd;
	msg.message = message.uMsg;
	msg.wParam = message.wParam;
	msg.lParam = message.lParam;
	msg.time = GetTickCount();
	msg.pt = pt;
	SendMessage( tooltip, TTM_RELAYEVENT, 0, (LPARAM) &msg );

	// _tremove ")unwanted_TEXT(" icons
	iconListCleanup();

	// get icon at point
  pSysTrayIcon = iconListFindPt(pt);

	// post message to that icon
  if (pSysTrayIcon && pSysTrayIcon->uCallbackMessage)
	{
		SendMessage( pSysTrayIcon->hWnd, pSysTrayIcon->uCallbackMessage, (WPARAM)pSysTrayIcon->uID, (LPARAM)message.uMsg );
		return TRUE;
  }
	return FALSE;
}

void systray::onWindowPosChanging(Message& message)
{
	LPWINDOWPOS lpwp = (LPWINDOWPOS)message.lParam;

	if ( !( lpwp->flags & SWP_NOSIZE ) )
	{
		if ( (trayWidth!=lpwp->cx) || (trayHeight!=lpwp->cy) )
		{
      trayWidth = lpwp->cx;
			trayHeight = lpwp->cy;
		}
	}

	if ( !( lpwp->flags & SWP_NOMOVE ) )
	{
		if (snapDistance)
		{
			if ( abs(lpwp->x) <= snapDistance )
				lpwp->x = 0;
			if ( abs(lpwp->y) <= snapDistance )
				lpwp->y = 0;
			if ( abs(lpwp->x+trayWidth-GetSystemMetrics(SM_CXSCREEN)) <= snapDistance )
				lpwp->x = GetSystemMetrics(SM_CXSCREEN) - trayWidth;
			if ( abs(lpwp->y+trayHeight-GetSystemMetrics(SM_CYSCREEN)) <= snapDistance )
				lpwp->y = GetSystemMetrics(SM_CYSCREEN) - trayHeight;
		}
		trayX = lpwp->x;
		trayY = lpwp->y;
	}

	if ( !( lpwp->flags & SWP_NOSIZE) )
	{
		setFirstLast();
		createBackground();

		InvalidateRect(hWnd,NULL,TRUE);
	}
	message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}

void systray::onPaint (Message& message)
{
	HDC     hdcBuffer;
	HBITMAP hbmBuffer, hbmBufOld;
	HRGN    hrgn = NULL;

	PAINTSTRUCT ps;
	HDC	hdcScreen = BeginPaint(hWnd, &ps);

	hdcBuffer = CreateCompatibleDC(hdcScreen);
	hbmBuffer = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
	hbmBufOld = (HBITMAP)SelectObject(hdcBuffer, hbmBuffer);

	if (transpBack)
		hrgn = CreateRectRgn( 0, 0, 0, 0 );

	// blit the skin
	paintBackground(hdcBuffer, hrgn);

	// blit the icons
	iconListPaint(hdcBuffer, hrgn);

	// set the windowRgn
	if (transpBack)
		SetWindowRgn(hWnd, hrgn, TRUE);

	// when the region is applied you can use a simple SRCCOPY from the buffer
	BitBlt(hdcScreen, 0, 0, trayWidth, trayHeight, hdcBuffer, 0, 0, SRCCOPY);

	// reselect the oldBitmap and kill the new one
	SelectObject(hdcBuffer, hbmBufOld);
	DeleteObject(hbmBuffer);

	// _tremove the memory DC
	DeleteDC(hdcBuffer);

	EndPaint(hWnd, &ps);
}

// bang commands!!
void systray::show(void)
{
	visible = TRUE;
	ShowWindow( hWnd, SW_SHOWNOACTIVATE );
}
void systray::hide(void)
{
	visible = FALSE;
	ShowWindow( hWnd, SW_HIDE );
}
void systray::toggle(void)
{
	visible = !IsWindowVisible( hWnd );
	ShowWindow( hWnd, visible?SW_SHOWNOACTIVATE:SW_HIDE );
}
void systray::toggleOnTop(void)
{
	onTop = !(GetWindowLong(hWnd, GWL_EXSTYLE) & WS_EX_TOPMOST);
	SetWindowPos( hWnd, onTop?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
}
void systray::move(int x, int y)
{
	SetWindowPos( hWnd, NULL, x, y, 0, 0, SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE );
}
void systray::size(int cx, int cy)
{
	SetWindowPos( hWnd, NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE );
}

void systray::setFirstLast()
{
	// the following settings are used with the icon rectangles
	// to ensure they match the desired pattern
	firstX = ( ( direction == TD_LEFT ) || ( wrapDirection == TD_LEFT ) ) ?
				( trayWidth -  borderRight  - iconSpacingX - iconSize ) :
				( borderLeft + iconSpacingX );
	lastX  = firstX + ( wrapCount - 1 ) * deltaX;

	firstY = ( ( direction == TD_DOWN ) || ( wrapDirection == TD_DOWN ) ) ?
				( borderTop + iconSpacingY ) :
				( trayHeight - borderBottom - iconSpacingY - iconSize );

	lastY  = firstY + ( wrapCount - 1 ) * deltaY;
}

void systray::createBackground()
{
  HDC hdcScreen, hdcDst;
  HBITMAP hbmDstOld;

  // delete old objects if necessary...
  if ( hbmBack )
	  DeleteObject( hbmBack );
  hbmBack = NULL;

  if ( hrgnBack )
	  DeleteObject( hrgnBack );
  hrgnBack = NULL;

  // initiate a new destination dc
  hdcScreen = GetDC(hWnd);

  hdcDst    = CreateCompatibleDC(hdcScreen);
  hbmBack   = CreateCompatibleBitmap(hdcScreen, trayWidth, trayHeight);
  hbmDstOld = (HBITMAP)SelectObject(hdcDst, hbmBack);

  ReleaseDC(hWnd, hdcScreen);

  // if the background colors are needed put them on...
  if ((!hbmSkin)||transpSkin)
  {
	  RECT r;
	  HBRUSH brush;

	  // fill the border with the border colors
	  if (borderTop||borderLeft||borderBottom||borderTop)
	  {
		  brush = CreateSolidBrush(clrBorder);

		  if (borderTop)
		  {
			  SetRect(&r, 0, 0, trayWidth, borderTop);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderLeft)
		  {
			  SetRect(&r, 0, borderTop, borderLeft, trayHeight - borderBottom);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderRight)
		  {
			  SetRect(&r, trayWidth - borderRight, borderTop, trayWidth, trayHeight - borderBottom);
			  FillRect(hdcDst, &r, brush);
		  }
		  if (borderBottom)
		  {
			  SetRect(&r, 0, trayHeight - borderBottom, trayWidth, trayHeight);
			  FillRect(hdcDst, &r, brush);
		  }
		  DeleteObject(brush);
	  }

	  // now fill the inner rectangle (excluding the borders) with the background color
	  brush = CreateSolidBrush(clrBack);

	  SetRect(&r, borderLeft, borderTop, trayWidth-borderRight, trayHeight-borderBottom);
	  FillRect(hdcDst, &r, brush);

	  DeleteObject(brush);
  }

  // if a background image is provided, put it on...
  if (hbmSkin)
  {

    HDC     hdcSrc;
    HBITMAP hbmSrcOld;
    BITMAP  bm;
    int innerWidth, innerHeight, bmInnerWidth, bmInnerHeight;

	  // get info from the bitmap
    GetObject(hbmSkin, sizeof(BITMAP), &bm);

    // this is to prevent negative values on the width
    innerWidth  = max(trayWidth -(borderLeft+borderRight), 0);
    innerHeight = max(trayHeight-(borderTop+borderBottom), 0);
    bmInnerWidth  = max(bm.bmWidth -(borderLeft+borderRight), 1);
    bmInnerHeight = max(bm.bmHeight-(borderTop+borderBottom), 1);

    hdcSrc    = CreateCompatibleDC(hdcDst);
    hbmSrcOld = (HBITMAP)SelectObject(hdcSrc, hbmSkin);

	  if (borderTop||borderLeft||borderBottom||borderTop)
	  {

		  // paint the four corners first, and then the borders
		  // topleft, topright, bottomright, bottomleft
		  copyBlt(hdcDst, 0, 0, borderLeft, borderTop, hdcSrc, 0, 0);
		  copyBlt(hdcDst, trayWidth-borderRight, 0, borderRight, borderTop, hdcSrc, bm.bmWidth-borderRight, 0);
		  copyBlt(hdcDst, trayWidth-borderRight, trayHeight-borderBottom, borderRight, borderBottom, hdcSrc, bm.bmWidth-borderRight, bm.bmHeight-borderBottom);
		  copyBlt(hdcDst, 0, trayHeight-borderBottom, borderLeft, borderBottom, hdcSrc, 0, bm.bmHeight-borderBottom);

		  if (borderTop&&innerWidth)
		    sizeBlt(hdcDst, borderLeft, 0, innerWidth, borderTop, hdcSrc, borderLeft, 0, bmInnerWidth, borderTop);
		  if (borderLeft&&innerHeight)
		    sizeBlt(hdcDst, 0, borderTop, borderLeft, innerHeight, hdcSrc, 0, borderTop, borderLeft, bmInnerHeight);
		  if (borderRight&&innerHeight)
		    sizeBlt(hdcDst, trayWidth-borderRight, borderTop, borderRight, innerHeight, hdcSrc, bm.bmWidth-borderRight, borderTop, borderRight, bmInnerHeight);
		  if (borderBottom&&innerWidth)
		    sizeBlt(hdcDst, borderLeft, trayHeight-borderBottom, innerWidth, borderBottom, hdcSrc, borderLeft, bm.bmHeight-borderBottom, bmInnerWidth, borderBottom);
	  }

    // draw area in the middle
    if(innerWidth&&innerHeight)
      sizeBlt(hdcDst, borderLeft, borderTop, innerWidth, innerHeight, hdcSrc, borderLeft, borderTop, bmInnerWidth, bmInnerHeight);

    SelectObject( hdcSrc, hbmSrcOld );
    DeleteDC( hdcSrc );
  }

  SelectObject( hdcDst, hbmDstOld );
  DeleteDC( hdcDst );

  if (!transpSkin)
  {
	  transpBack = FALSE;
  }
  else
  {
	  HRGN hOpaqueRgn = CreateRectRgn(0, 0, trayWidth, trayHeight);
	  hrgnBack        = BitmapToRegion(hbmBack, RGB(255,0,255), 0x101010, 0, 0);

	  // to see if any pixels are transparent
	  transpBack      = !EqualRgn(hrgnBack, hOpaqueRgn);

	  DeleteObject(hOpaqueRgn);

	  if (!transpBack)
	  {
		  DeleteObject(hrgnBack);
		  hrgnBack = NULL;
	  }
  }
}

void systray::paintBackground( HDC hdcDst, HRGN hrgnDst ) {

	HDC hdcSrc;
	HBITMAP hbmOld;

	// if the background isn't there, make one...
	if (!hbmBack)
	{
		createBackground();
  }
  else
  {
    BITMAP bm;
    GetObject(hbmBack,sizeof(BITMAP),&bm);
    if(bm.bmWidth!=trayWidth||bm.bmHeight!=trayHeight)
    {
      createBackground();
    }
  }

	// if there is no background now... do nothing
	if (!hbmBack)
		return;


	hdcSrc = CreateCompatibleDC(hdcDst);
	hbmOld = (HBITMAP)SelectObject(hdcSrc, hbmBack);

	BitBlt(hdcDst, 0, 0, trayWidth, trayHeight, hdcSrc, 0, 0, SRCCOPY);

	SelectObject(hdcSrc, hbmOld);
	DeleteDC(hdcSrc);

	if ( hrgnBack && transpBack )
		CombineRgn(hrgnDst, hrgnBack, NULL, RGN_COPY);

}

// grd Blitting functions...
// to enable transp / not transp painting
// and to enable tile / stretch resizing
int systray::copyBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc)
{
	if (transpSkin)
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, RGB(255,0,255));
	else
		return BitBlt(hdcDst, xDst, yDst, cxDst, cyDst, hdcSrc, xSrc, ySrc, SRCCOPY);

	return 0;
}

int systray::sizeBlt (HDC hdcDst, int xDst, int yDst, int cxDst, int cyDst, HDC hdcSrc, int xSrc, int ySrc, int cxSrc, int cySrc)
{
	HDC		  hdcTmp;
	HBITMAP hbmTmp, hbmOld;
  int     tmpX, tmpY;

	if (transpSkin)
	{
		hdcTmp = CreateCompatibleDC( hdcDst );
		hbmTmp = CreateCompatibleBitmap( hdcDst, cxDst, cyDst );
		hbmOld = (HBITMAP)SelectObject( hdcTmp, hbmTmp );
    tmpX = 0, tmpY = 0;
	}
	else
  {
		hdcTmp = hdcDst;
    tmpX = xDst, tmpY = yDst;
  }

	if (skinTiled)
	{
		int x, y;
		// fill the first row of images
		for (x = 0; x < cxDst; x += cxSrc)
			BitBlt(hdcTmp, tmpX+x, tmpY, min(cxSrc, cxDst-x), min(cySrc,cyDst), hdcSrc, xSrc, ySrc, SRCCOPY);
		// copy this row down the y axis...
		for (y = cySrc; y < cyDst; y += cySrc)
			BitBlt(hdcTmp, tmpX, tmpY+y, cxDst, min(cySrc, cyDst-y), hdcTmp, tmpX, tmpY, SRCCOPY);

	}
	else
  {
	  // stretch it
		StretchBlt(hdcTmp, tmpX, tmpY, cxDst, cyDst, hdcSrc, xSrc, ySrc, cxSrc, cySrc, SRCCOPY);
  }

	// blit the resulting image onto the destination dc
	if (transpSkin)
	{
		TransparentBltLS(hdcDst, xDst, yDst, cxDst, cyDst, hdcTmp, tmpX, tmpY, RGB(255,0,255));

		// cleanup
		SelectObject( hdcTmp, hbmOld );
		DeleteObject( hbmTmp );
		DeleteDC( hdcTmp );
	}
	return 0;
}

PSYSTRAYICON systray::iconListFind(HWND hWnd, UINT uID)
{
	PSYSTRAYICON pSysTrayIcon = pFirst;

	while(pSysTrayIcon)
	{
		if( pSysTrayIcon->hWnd==hWnd && pSysTrayIcon->uID==uID )
			return pSysTrayIcon;
		pSysTrayIcon = pSysTrayIcon->pNext;
	}
  return NULL;
}
PSYSTRAYICON systray::iconListFindPt(POINT pt)
{
	PSYSTRAYICON pSysTrayIcon = pFirst;

	while(pSysTrayIcon)
	{
		if( PtInRect(&pSysTrayIcon->rc,pt) )
		{
			if ( IsWindow(pSysTrayIcon->hWnd) )
			{
				return pSysTrayIcon;
			}
			else
			{
				iconDelGRD(pSysTrayIcon);
				return NULL;
			}
		}
		pSysTrayIcon = pSysTrayIcon->pNext;
	}
  return NULL;
}

int systray::iconListSave(void *dst)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)dst;
	PSYSTRAYICON pSysTrayIcon;
	int i = 0;

	iconListCleanup();
	pSysTrayIcon = pFirst;

	while (pSysTrayIcon)
	{
		// set the saving data based on the list
		trayArray[i].cbSize	= sizeof(NOTIFYICONDATA);
		trayArray[i].hWnd	= pSysTrayIcon->hWnd;
		trayArray[i].uID = pSysTrayIcon->uID;
		trayArray[i].uFlags	= NULL;
		trayArray[i].uCallbackMessage = pSysTrayIcon->uCallbackMessage;
		if (trayArray[i].uCallbackMessage)
			trayArray[i].uFlags |= NIF_MESSAGE;

		if (pSysTrayIcon->hIcon)
		{
			trayArray[i].uFlags |= NIF_ICON;
			trayArray[i].hIcon = CopyIcon(pSysTrayIcon->hIcon);
		}
		else
		{
			trayArray[i].hIcon = NULL;
		}

		if (pSysTrayIcon->szTip)
		{
			trayArray[i].uFlags |= NIF_TIP;
			lstrcpyn(trayArray[i].szTip, pSysTrayIcon->szTip, 64);
		}
		else
		{
			trayArray[i].szTip[0] = '\0';
		}
		i++;

		pSysTrayIcon = pSysTrayIcon->pNext;
	}
	trayArray[i].hWnd = 0;

	return i;
}

int systray::iconListLoad(void *src)
{
	NOTIFYICONDATA *trayArray = (NOTIFYICONDATA*)src;
	int i = 0;

	if (src)
	{
		while (trayArray[i].hWnd)
		{
			// add all icons from the buffer
			SendMessage( liteStep, LM_SYSTRAY, NIM_ADD, (LPARAM)&trayArray[i] );
			DestroyIcon( trayArray[i].hIcon );
			i++;
		}
	}
	return i;
}

int systray::iconListLoadMaduin()
{
	// icon information
	NOTIFYICONDATA *trayArray;
	DWORD dwIconCount = 0;
	unsigned int i = 0;

	// subkey
	HKEY hSubKey = NULL;
	// registry values needed
	DWORD dwDataType;
	DWORD dwDataSize = sizeof(DWORD);

	// open the regestry subkey
	if( RegOpenKeyEx( HKEY_CURRENT_USER, REGKEY_SAVEDDATA, 0, KEY_QUERY_VALUE, &hSubKey ) == ERROR_SUCCESS )
	{
		// get the number of icons
		if( RegQueryValueEx( hSubKey, _TEXT("IconCount"), NULL, &dwDataType, (LPBYTE) &dwIconCount, &dwDataSize ) == ERROR_SUCCESS )
		{
			// if not everything worked perfectly return 0
			if( ( dwDataType == REG_DWORD ) && ( dwDataSize == sizeof(DWORD) ) )
			{
				dwDataSize = dwIconCount * sizeof(NOTIFYICONDATA);
				trayArray = (PNOTIFYICONDATA) new BYTE[ dwDataSize ];

				if(trayArray)
				{
					if( RegQueryValueEx( hSubKey, _TEXT("Icons"), NULL, &dwDataType, (LPBYTE) trayArray, &dwDataSize ) == ERROR_SUCCESS )
					{
						if( dwDataType == REG_BINARY )
						{
							for( i = 0; i < dwIconCount; i++ )
							{
								if( IsWindow( trayArray[i].hWnd ) )
								SendMessage( liteStep, LM_SYSTRAY, NIM_ADD, (LPARAM) &trayArray[i] );
								// as this module does not _tremove the icons array from memory
								// it's not very wise to _tremove the HICONs
							}
						}
					}
					delete[] trayArray;
				}
			}
		}
		// close the registry subkey
		RegCloseKey( hSubKey );
	}
	return (int)(i + 1);
}

void systray::iconListCleanup()
{
	PSYSTRAYICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;

	while(pSysTrayIcon)
	{
		pSysTrayIcon2 = pSysTrayIcon->pNext;
		//char buffer2[MAX_LINE_LENGTH];
		//sprintf(buffer2,")checking window: %d"), (int)pSysTrayIcon->hWnd);
		//OutputDebugString(buffer2);

		if( !IsWindow(pSysTrayIcon->hWnd) )
			iconDelGRD(pSysTrayIcon);

		pSysTrayIcon = pSysTrayIcon2;
	}
}

BOOL systray::iconListDelAll() {

	PSYSTRAYICON pSysTrayIcon = pFirst, pSysTrayIcon2 = NULL;

	while (pSysTrayIcon)
	{
		// save the one to be deleted and move to the next
		pSysTrayIcon2 = pSysTrayIcon->pNext;
		// delete this history item
		iconDelGRD(pSysTrayIcon);
		pSysTrayIcon = pSysTrayIcon2;
	}
	return TRUE;
}

void systray::iconListPaint( HDC hdcDst, HRGN hrgnDst )
{
	PSYSTRAYICON pSysTrayIcon = pFirst;

	while(pSysTrayIcon)
	{
		//char buffer[MAX_LINE_LENGTH];
		//char buffer2[MAX_LINE_LENGTH];
		//GetWindowText(pSysTrayIcon->hWnd,buffer,MAX_LINE_LENGTH-1);
		//sprintf(buffer2, _TEXT("painting icon...\nowner window title=\_TEXT("%s\")"), buffer);
		//OutputDebugString( buffer2 );

		if(pSysTrayIcon->hIcon)
		{
			DrawIconEx(hdcDst, pSysTrayIcon->rc.left, pSysTrayIcon->rc.top, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_NORMAL);

			// combine the region
			if (pSysTrayIcon->hRgn && transpBack)
			{
				OffsetRgn(pSysTrayIcon->hRgn, pSysTrayIcon->rc.left, pSysTrayIcon->rc.top);
				CombineRgn(hrgnDst, hrgnDst, pSysTrayIcon->hRgn, RGN_OR);
				OffsetRgn(pSysTrayIcon->hRgn, -pSysTrayIcon->rc.left, -pSysTrayIcon->rc.top);
			}
		}
		pSysTrayIcon = pSysTrayIcon->pNext;
	}
}

/**** PROPERTY CHANGERS ****/

void systray::setIcon(PSYSTRAYICON pSysTrayIcon, HICON icon)
{
	if (pSysTrayIcon->hRgn)
		DeleteObject(pSysTrayIcon->hRgn);
	pSysTrayIcon->hRgn = NULL;

	if (pSysTrayIcon->hIcon)
		DestroyIcon(pSysTrayIcon->hIcon);
	pSysTrayIcon->hIcon = CopyIcon(icon);

	if (pSysTrayIcon->hIcon && transpBack)
	{
		pSysTrayIcon->hRgn = ::CreateRectRgn(0,0,0,0);

		HDC hdc        = ::CreateCompatibleDC( NULL );
		HBITMAP hbmNew = ::CreateCompatibleBitmap( hdc, iconSize, iconSize );
		HBITMAP hbmOld = (HBITMAP) ::SelectObject( hdc, hbmNew );

		if ( DrawIconEx(hdc, 0, 0, pSysTrayIcon->hIcon, iconSize, iconSize, 0, NULL, DI_MASK) )
		{
			int y = 0;
			while ( y < iconSize )
			{
				int x = 0;
				while ( x < iconSize )
				{
					UINT firstNTX = 0;
					// loop through all transparent pixels...
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( !::GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// set first non transparent pixel
					firstNTX = x;
					// loop through all non transparent pixels
					while ( x < iconSize )
					{
						// if the pixel is white, then break
						if ( GetPixel(hdc, x, y) )
							break;
						x++;
					}
					// if found one or more non-transparent pixels in a row, add them to the rgn...
					if ((x-firstNTX)>0)
					{
						HRGN hTempRgn = CreateRectRgn(firstNTX, y, x, y+1);
						CombineRgn(pSysTrayIcon->hRgn, pSysTrayIcon->hRgn, hTempRgn, RGN_OR);
						DeleteObject(hTempRgn);
					}
					x++;

				}
				y++;

			}

		}
		SelectObject( hdc, hbmOld );
		DeleteObject( hbmNew );
		DeleteDC(hdc);
	}
}

void systray::setToolTip(PSYSTRAYICON pSysTrayIcon, _TCHAR *szNewToolTip)
{
	BOOL     existed = TRUE;
	UINT     uStrLen = 0;
	TOOLINFO ti;

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd	  = hWnd;
	ti.hinst  = NULL;

  //OutputDebugString(_TEXT("1"));

  if (!pSysTrayIcon->szTip)
	{
		existed = FALSE;
		pSysTrayIcon->uToolTip = uLastID++;
	}

	ti.uId = pSysTrayIcon->uToolTip;

  //OutputDebugString(_TEXT("2"));

  // delete old tip
	if (existed)
		delete[] pSysTrayIcon->szTip;

  // set the new tip
	if (szNewToolTip)
	{
		pSysTrayIcon->szTip = new _TCHAR[_tcsclen(szNewToolTip)+1];
		_tcscpy(pSysTrayIcon->szTip,szNewToolTip);
	}
	else
	{
		pSysTrayIcon->szTip = NULL;
	}

	ti.lpszText = pSysTrayIcon->szTip;

  //OutputDebugString(_TEXT("3"));

	if ( existed )
  {
    //OutputDebugString(_TEXT("4a"));
		SendMessage(tooltip, (pSysTrayIcon->szTip)?TTM_UPDATETIPTEXT:TTM_DELTOOL, 0, (LPARAM)&ti);
  }
	else if ( pSysTrayIcon->szTip )
	{
    //OutputDebugString(_TEXT("4b"));
		ti.uFlags = 0;
    ti.rect = pSysTrayIcon->rc;
		SendMessage(tooltip, TTM_ADDTOOL, 0, (LPARAM)&ti);
	}
  //OutputDebugString(_TEXT("5"));
}

void systray::adjustRect(PSYSTRAYICON pSysTrayIcon)
{
	BOOL existed = TRUE;
	PSYSTRAYICON pPrevTrayIcon = pSysTrayIcon->pPrev;

	if (pSysTrayIcon->pPrev)
	{
		if (direction & TD_VERTICAL)
		{
			// if there is room for one more icon
			if (pSysTrayIcon->pPrev->rc.top!=lastY)
			{
				pSysTrayIcon->rc.top  = pSysTrayIcon->pPrev->rc.top  + deltaY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left;
			}
			else
			{
				pSysTrayIcon->rc.top  = firstY;
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + deltaX;
			}
		}
		else
		{
			// if there is room for one more icon
			if (pSysTrayIcon->pPrev->rc.left!=lastX)
			{
				pSysTrayIcon->rc.left = pSysTrayIcon->pPrev->rc.left + deltaX;
				pSysTrayIcon->rc.top  = pSysTrayIcon->pPrev->rc.top;
			}
			else
			{
				pSysTrayIcon->rc.left = firstX;
				pSysTrayIcon->rc.top  = pSysTrayIcon->pPrev->rc.top  + deltaY;
			}
		}
	}
	else
	{
		pSysTrayIcon->rc.left = firstX;
		pSysTrayIcon->rc.top  = firstY;
	}

	pSysTrayIcon->rc.right  = pSysTrayIcon->rc.left + iconSize;
	pSysTrayIcon->rc.bottom = pSysTrayIcon->rc.top  + iconSize;

	if(pSysTrayIcon->szTip)
	{
		TOOLINFO ti;
		ti.hwnd = hWnd;
		ti.uId  = pSysTrayIcon->uToolTip;
		ti.rect = pSysTrayIcon->rc;
		SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
	}
}

void systray::adjustSize()
{
	RECT rcOrg;
	int x,y,cx,cy;

	// this is the new size...
	if (pLast) {

		cx = iconSize+2*iconSpacingX+borderRight+borderLeft;
		cy = iconSize+2*iconSpacingY+borderBottom+borderTop;

		if (direction & TD_VERTICAL)
		{
			if (pLast->rc.left!=firstX)
				cy += (direction==TD_DOWN)?(lastY-firstY):(firstY-lastY);
			else
				cy += (direction==TD_DOWN)?(pLast->rc.top-firstY):(firstY - pLast->rc.top);
			cx += (wrapDirection==TD_RIGHT)?(pLast->rc.left-firstX):(firstX-pLast->rc.left);
		}
		else
		{
			if (pLast->rc.top!=firstY)
				cx += (direction==TD_RIGHT)?(lastX-firstX):(firstX-lastX);
			else
        cx += (direction==TD_RIGHT)?(pLast->rc.left-firstX):(firstX - pLast->rc.left);
			cy += (wrapDirection==TD_DOWN)?(pLast->rc.top-firstY):(firstY - pLast->rc.top);
		}
	}
	else
	{
		cx = borderLeft + borderRight;
		cy = borderTop + borderBottom;
	}

	// position it according to the old position
	GetWindowRect(hWnd, &rcOrg);

	x = ((direction==TD_RIGHT)||(wrapDirection==TD_RIGHT))?rcOrg.left:rcOrg.right-cx;
	y = ((direction==TD_DOWN)||(wrapDirection==TD_DOWN))?rcOrg.top:rcOrg.bottom-cy;

	SetWindowPos(hWnd, NULL, x, y, cx, cy, SWP_NOACTIVATE|SWP_NOZORDER);

  /*trayX = x;
  trayY = y;
  trayWidth = cx;
  trayHeight = cy;

  setFirstLast();
  createBackground();*/

	if (pLast)
	{
		PSYSTRAYICON pSysTrayIcon = pFirst;

		while (pSysTrayIcon)
		{
			adjustRect(pSysTrayIcon);
			pSysTrayIcon = (PSYSTRAYICON)pSysTrayIcon->pNext;
		}
	}
}

PSYSTRAYICON systray::iconAdd(PNOTIFYICONDATA pnid)
{
	PSYSTRAYICON pSysTrayIcon;

	if( !IsWindow(pnid->hWnd) )
		return NULL;

	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if found, modify instead of add
	if ( pSysTrayIcon )
		return iconMod( pnid );

	// if not found (which is the way it should go)
	pSysTrayIcon = new SYSTRAYICON;
	memset(pSysTrayIcon, 0, sizeof(SYSTRAYICON));

	// transfer properties
	pSysTrayIcon->hWnd = pnid->hWnd;
	pSysTrayIcon->uID = pnid->uID;
	pSysTrayIcon->uCallbackMessage = ((pnid->uFlags & NIF_MESSAGE)?pnid->uCallbackMessage:NULL);

	// set icon and region properties
	setIcon( pSysTrayIcon, (pnid->uFlags & NIF_ICON)?pnid->hIcon:NULL );

	// add to last position in the list
	if (!pFirst)
	{
		pFirst = pSysTrayIcon;
		pSysTrayIcon->pPrev = NULL;
	}
	if (pLast)
	{
		pSysTrayIcon->pPrev = pLast;
		pLast->pNext = pSysTrayIcon;
	}
	pLast = pSysTrayIcon;
	pSysTrayIcon->pNext = NULL;

	// adjust the rectangle to the correct position ( uses list position )
	adjustRect(pSysTrayIcon);

	// add tooltip (uses rect)
	setToolTip(pSysTrayIcon, (pnid->uFlags & NIF_TIP)?pnid->szTip:NULL);

	// _tremove ")unwanted_TEXT(" icons
	iconListCleanup();

	if (autoSize)
		adjustSize(); // which will repaint the window
	else
		InvalidateRect(hWnd, &pSysTrayIcon->rc, TRUE);

	// if it's the first icon, send an SHOW message
	if ( (pFirst==pSysTrayIcon) && (hideIfEmpty) )
		ShowWindow(hWnd, SW_SHOWNOACTIVATE);

	// return the newly created icon
	return pSysTrayIcon;
}

PSYSTRAYICON systray::iconMod(PNOTIFYICONDATA pnid)
{
	PSYSTRAYICON pSysTrayIcon;

	// check if the icon already exists
	pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	// if not found, add instead of modify
	if (!pSysTrayIcon)
		return iconAdd(pnid);

	if(pnid->uFlags & NIF_MESSAGE)
		pSysTrayIcon->uCallbackMessage = pnid->uCallbackMessage;

	if(pnid->uFlags & NIF_TIP)
		setToolTip(pSysTrayIcon, pnid->szTip);

	if(pnid->uFlags & NIF_ICON)
		setIcon(pSysTrayIcon, pnid->hIcon);

	// _tremove ")unwanted_TEXT(" icons
	iconListCleanup();

	InvalidateRect(hWnd, NULL, TRUE);

	// return the ")refreshed" icon
	return pSysTrayIcon;
}

BOOL systray::iconDel(PNOTIFYICONDATA pnid)
{
	PSYSTRAYICON pSysTrayIcon = iconListFind(pnid->hWnd, pnid->uID);

	if (pSysTrayIcon)
	{
		return iconDelGRD(pSysTrayIcon);
	}
	return FALSE;
}

BOOL systray::iconDelGRD(PSYSTRAYICON pSysTrayIcon)
{
	PSYSTRAYICON pIteratorSysTrayIcon;
	TOOLINFO ti;

	if( !pSysTrayIcon )
		return FALSE;

	// _tremove the tooltip
	setToolTip(pSysTrayIcon, NULL);

	// _tremove the icon
	setIcon(pSysTrayIcon, NULL);

	// change all the rectangles and update the tooltips
	pIteratorSysTrayIcon = pLast;
	// swap rectangles... this is smooth
	while (pIteratorSysTrayIcon!=pSysTrayIcon)
	{
		if (pIteratorSysTrayIcon&&pIteratorSysTrayIcon->pPrev)
			pIteratorSysTrayIcon->rc = pIteratorSysTrayIcon->pPrev->rc;

		if(pIteratorSysTrayIcon->szTip)
		{
			ti.hwnd = hWnd;
			ti.uId  = pIteratorSysTrayIcon->uToolTip;
			ti.rect = pIteratorSysTrayIcon->rc;
			SendMessage(tooltip, TTM_NEWTOOLRECT, 0, (LPARAM)&ti);
		}
		pIteratorSysTrayIcon = pIteratorSysTrayIcon->pPrev;
	}

	// if it's first or last, move those pointers
	if (pFirst==pSysTrayIcon)
		pFirst = pSysTrayIcon->pNext;
	else
		pSysTrayIcon->pPrev->pNext = pSysTrayIcon->pNext;

	if (pLast==pSysTrayIcon)
		pLast = pSysTrayIcon->pPrev;
	else
		pSysTrayIcon->pNext->pPrev = pSysTrayIcon->pPrev;

	// _tremove the icon class
	delete pSysTrayIcon;

	if (!pFirst&&hideIfEmpty)
	{
		ShowWindow(hWnd, SW_HIDE);
	}
	else
	{
		if (autoSize)
			adjustSize();
		else
			InvalidateRect( hWnd, NULL, TRUE );
	}
	return TRUE;
}
