/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "BmpPainter.h"
#include "MenuItem.h"
#include "../lsapi/lsapi.h"

int BmpPainter::m_nBlt = BMPPAINT_PLAIN;

BmpPainter::BmpPainter(HBITMAP hBmp, BOOL bTansparent)
{
	m_bTransparent = bTansparent;

	GetObject(hBmp, sizeof(m_Bmp), &m_Bmp);

	if(m_bTransparent)
		m_hRegion = BitmapToRegion(hBmp, RGB(255,0,255), 0x10101010, 0, 0);
	else
		m_hRegion = NULL;

	m_hPicture = CreateCompatibleDC(NULL);
	m_hBmpSaved = (HBITMAP) SelectObject(m_hPicture, hBmp);
	m_hBmp = hBmp;
}

BmpPainter::~BmpPainter()
{
	SelectObject(m_hPicture, m_hBmpSaved);

	DeleteDC(m_hPicture);
	DeleteObject(m_hBmp);
}

void BmpPainter::Paint(MenuItem* pMenuItem, HDC hDC)
{
	RECT r;

	Painter::Paint(pMenuItem, hDC);
	pMenuItem->GetItemRect(&r);

	switch(m_nBlt)
	{
	case BMPPAINT_PLAIN:
		BitBlt(hDC, r.left, r.top, r.right - r.left, r.bottom - r.top, m_hPicture, 0, 0, SRCCOPY);
		break;
	case BMPPAINT_STRETCH:
		SetStretchBltMode(hDC, STRETCH_DELETESCANS);
		StretchBlt(hDC, r.left, r.top, r.right - r.left, r.bottom - r.top, 
			       m_hPicture, 0, 0, m_Bmp.bmWidth,m_Bmp.bmHeight,SRCCOPY);
		break;
	case BMPPAINT_TILE:
		for(int x=r.left; x<pMenuItem->GetWidth(); x+=m_Bmp.bmWidth)
			for(int y=r.top; y<(pMenuItem->GetHeight()+r.top); y+=m_Bmp.bmHeight)
				BitBlt(hDC, x, y, r.right - r.left, r.bottom - r.top, m_hPicture, 0, 0, SRCCOPY);
		break;
	}
	
}

void BmpPainter::GetRegion(HRGN hRgn, MenuItem* pItem)
{
	if(m_bTransparent && m_nBlt == BMPPAINT_PLAIN)
	{
		/* if(m_nBlt != BMPPAINT_PLAIN)
		{
			HDC hDC = CreateCompatibleDC(0);
			HBITMAP hBitmap = CreateCompatibleBitmap(hDC, pItem->GetWidth(), pItem->GetHeight());
			hBitmap = (HBITMAP) SelectObject(hDC, hBitmap);

			int nTop = pItem->GetTop();
			pItem->SetPosition(0, 0);
			Paint(pItem, hDC);
			pItem->SetPosition(0, nTop);

			hBitmap = (HBITMAP) SelectObject(hDC, hBitmap);
			DeleteDC(hDC);

			HRGN hRegion = BitmapToRegion(hBitmap, RGB(255, 255, 255), 0x10101010, 0, 0);
			CombineRgn(hRgn, hRegion, 0, RGN_COPY);
			DeleteObject(hRegion);

			DeleteObject(hBitmap);
		}
		else
		{
			CombineRgn(hRgn, m_hRegion, NULL, RGN_COPY);
		} */

		CombineRgn(hRgn, m_hRegion, NULL, RGN_COPY);
	}
	else
	{
		Painter::GetRegion(hRgn, pItem);
	}
}
