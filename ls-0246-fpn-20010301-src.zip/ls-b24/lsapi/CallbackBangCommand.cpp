/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <comdef.h>

#include "CallbackBangCommand.h"

///////// Bang Command ////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CallbackBangCommand::CallbackBangCommand(BANG b) {
	ex = false;
	command = L"";
	bang = b;
	
	refCount = 0;
}

CallbackBangCommand::CallbackBangCommand(BANGEX b, wchar_t *c) {
	ex = true;
	command = c;
	bangex = b;
	
	refCount = 0;
}

CallbackBangCommand::~CallbackBangCommand() {
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE CallbackBangCommand::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IBangCommand) {
		*ppv = static_cast<IBangCommand*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE CallbackBangCommand::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE CallbackBangCommand::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

///////////////////////////////////////////////////////////////////////////
// From IBangCommand
void STDMETHODCALLTYPE CallbackBangCommand::Execute( 
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params) {
	if (ex) {
		bangex((HWND)caller, _bstr_t(command.c_str()), _bstr_t(params, false));
	} else {
		bang((HWND)caller, _bstr_t(params, false));
	}
}
