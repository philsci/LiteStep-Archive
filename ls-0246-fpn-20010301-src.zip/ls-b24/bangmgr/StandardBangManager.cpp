/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
01/20/01 - Bobby G. Vinyard (Message)
  - Bangs weren't being removed from the map, now they are
****************************************************************************/
#include <windows.h>
#include <comdef.h>

#include "StandardBangManager.h"
#include "../lsapi/lsapi.h"
#include "bangmgr.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StandardBangManager::StandardBangManager()
{
	ITypeLib *typelib;

	LoadRegTypeLib(LIBID_LitestepBangManager, 0, 0, 0, &typelib);
	typelib->GetTypeInfoOfGuid(CLSID_StandardBangManager, &typeinfo);

	typelib->Release();

	refCount = 0;
}

StandardBangManager::~StandardBangManager()
{
	typeinfo->Release();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE StandardBangManager::QueryInterface( 
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv) {

	if (riid == IID_IUnknown) {
		*ppv = static_cast<IUnknown*>(this);
	} else if (riid == IID_IBangManager) {
		*ppv = static_cast<IBangManager*>(this);
	} else {
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE StandardBangManager::AddRef( void) {
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE StandardBangManager::Release( void) {
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0) {
		delete this;
	}

	return count;
}

///////////////////////////////////////////////////////////////////////////
// From IDispatch
HRESULT STDMETHODCALLTYPE StandardBangManager::GetTypeInfoCount( 
	/* [out] */ UINT __RPC_FAR *pctinfo) {

	*pctinfo = 1;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardBangManager::GetTypeInfo( 
	/* [in] */ UINT iTInfo,
	/* [in] */ LCID lcid,
	/* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo) {

	if (iTInfo != 0) {
		return DISP_E_BADINDEX;
	}

	typeinfo->AddRef();
	*ppTInfo = typeinfo;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE StandardBangManager::GetIDsOfNames( 
	/* [in] */ REFIID riid,
	/* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
	/* [in] */ UINT cNames,
	/* [in] */ LCID lcid,
	/* [size_is][out] */ DISPID __RPC_FAR *rgDispId) {

	return DispGetIDsOfNames(typeinfo, rgszNames, cNames, rgDispId);
}

HRESULT STDMETHODCALLTYPE StandardBangManager::Invoke( 
	/* [in] */ DISPID dispIdMember,
	/* [in] */ REFIID riid,
	/* [in] */ LCID lcid,
	/* [in] */ WORD wFlags,
	/* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
	/* [out] */ VARIANT __RPC_FAR *pVarResult,
	/* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
	/* [out] */ UINT __RPC_FAR *puArgErr) {

	return DispInvoke(this, typeinfo, dispIdMember, wFlags, pDispParams, pVarResult, pExcepInfo, puArgErr);
}

///////////////////////////////////////////////////////////////////////////
// From IBangManager

// Add a bang command to the manager
BOOL STDMETHODCALLTYPE StandardBangManager::AddBangCommand( 
    /* [in] */ BSTR name,
    /* [in] */ IBangCommand __RPC_FAR *command) {
	
	const wchar_t *name_str = _bstr_t(name, false);

	map<wstring, IBangCommand*>::iterator iter = bang_map.find(name_str);
	
	if (iter != bang_map.end()) {
		return FALSE;
	}

	bang_map[name_str] = command;
	
	return TRUE;
}

// Remove a bang command from the manager
BOOL STDMETHODCALLTYPE StandardBangManager::RemoveBangCommand( 
	/* [in] */ BSTR name) {

	const wchar_t *name_str = _bstr_t(name, false);

	BangMap::iterator iter = bang_map.find(name_str);

	if (iter == bang_map.end()) {
		return FALSE;
	}

	iter->second->Release();
	bang_map.erase(iter);

	return TRUE;
}

// Retrieve a bang command from the manager
IBangCommand *STDMETHODCALLTYPE StandardBangManager::GetBangCommand( 
    /* [in] */ BSTR name) {

	BangMap::iterator iter = bang_map.find(name);

	if (iter == bang_map.end()) {
		return NULL;
	}

	iter->second->AddRef();
	return iter->second;
}

// Execute a bang command with the specified name, passing params, getting result
BOOL STDMETHODCALLTYPE StandardBangManager::ExecuteBangCommand( 
    /* [in] */ BSTR name,
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params) {

	BangMap::iterator iter = bang_map.find(name);

	if (iter == bang_map.end()) {
		return FALSE;
	}

	iter->second->Execute(caller, params);

	return TRUE;
}

// TODO: Execute multiple bang commands with multiple param lists
long STDMETHODCALLTYPE StandardBangManager::ExecuteBangCommands(
    /* [in] */ long count,
	/* [in] */ BSTR __RPC_FAR names[],
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR __RPC_FAR params[]) {

	BangMap::iterator iter;

	long total = 0;

	for (long i = 0; i < count; i++) {
		iter = bang_map.find(names[i]);

		if (iter == bang_map.end()) {
			continue;
		} else {
			total++;
		}

		iter->second->Execute(caller, params[i]);
	}

	return total;
}

void STDMETHODCALLTYPE StandardBangManager::ClearBangCommands( void) {

	BangMap::iterator iter = bang_map.begin();

	while (iter != bang_map.end()) {
		iter->second->Release();
		iter++;
	}

	bang_map.clear();
}

long STDMETHODCALLTYPE StandardBangManager::GetBangCommandNames(
	/* [in] */ long count,
    /* [retval][out] */ BSTR __RPC_FAR names[])
{
	BangMap::iterator iter = bang_map.begin();

	long i = 0;

	while( i < count && iter != bang_map.end() )
	{
		names[i++] = SysAllocString( iter->first.c_str() );
		iter++;
	}

	return i;
}

long STDMETHODCALLTYPE StandardBangManager::GetBangCommandCount(void) {
	return bang_map.size();
}
