/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __HookManager_H
#define __HookManager_H

#define STRICT
#define WIN32_LEAN_AND_MEAN
#ifdef _DEBUG
#define _LSDEBUG
#endif

#pragma	warning(disable: 4786) // STL naming warnings

#include <windows.h>
#include "..\lsapi\lsapi.h"
//#include "..\lsapi\lswinbase.h"
#include "..\hook\hook.h"
#include <map> // STL
#include <set> // STL
#include "..\lsapi\lsdebug.h"

using namespace std;

//typedef set<HWND> sMsgHookList; // Basically a dynamic list of HWNDs for MessageHooks
typedef set<HookCallback*> sMsgHookList;
typedef map<UINT, sMsgHookList*> msg2hwnd; // Maps a message to a list of HWNDs

msg2hwnd m2hmap;
int numMessages;

HHOOK hShellHook;
HHOOK hMsgHook;
//HHOOK hCallWndHook;

HANDLE hHookMgrThread;
HWND hwndHookMgr;
HINSTANCE hInst;
bool processHooks;
HINSTANCE hmodHook;



bool createHookThread();
DWORD HookMgrMain(LPVOID lpv);
bool InstallMsgFilter(bool install);
LRESULT CALLBACK HookMgrWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern "C"
{
  __declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
  __declspec( dllexport ) void quitModule(HINSTANCE dllInst);
}

#endif
