/*
  Copyright (C) 1998-1999 Johan Redestig

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "PopupMaker.h"
#include <winuser.h>
// menu items
#include "MenuItem.h"
#include "FolderItem.h"
#include "PopupMenu.h"
#include "SeparatorItem.h"
#include "CommandItem.h"
#include "TimeItem.h"
#include "RemoteAmpItem.h"
#include "HeaderItem.h"
#include "DirectoryFolder.h"
#include "RunItem.h"
#include "TaskFolder.h"
#include "TaskItem.h"

#include "Re5ources.h"

// Painters
#include "SolidPainter.h"
#include "BmpPainter.h"
#include "GradientPainter.h"

#include "../lsapi/lsapi.h"

#include <io.h>
#include <shlwapi.h>
#include <vector>

extern vector<PopupMenu*> g_PopupMenues;

PopupMaker::PopupMaker()
{
	m_pBottom = NULL;
}

PopupMaker::~PopupMaker()
{
	DeleteObject(m_hDefaultFont);

	if(lstrlen(m_pszEntryFontFace) > 0)
		DeleteObject(m_hEntryFont);

	delete m_pRoot;
	delete m_pTitle;
	delete m_pEntry;
	delete m_pSelEntry;

	if(m_pBottom) delete m_pBottom;

	// delete all PopupMenu object, this is important not just only for
	// not leaking memory but (which is important since one recycles
	// litestep from time to time. litestep will crash upon recycle otherwise
	for(int i0=0; i0<g_PopupMenues.size(); i0++)
		delete g_PopupMenues[i0];


	// delete the painters that we have allocated.
	for(int i=0; i<m_Painters.size(); i++)
		delete m_Painters[i];
}

void PopupMaker::Show()
{
	POINT p;
	GetCursorPos(&p);
	m_pRoot->Show(p.x, p.y);
	SetFocus(m_pRoot->GetWindow());
}

void PopupMaker::Hide()
{
	m_pRoot->Hide(0);
}

void PopupMaker::Initialize(HWND hParentWnd, HINSTANCE dllInst, LPCSTR szPath) 
{
	hInst = dllInst;

	// we are managing the system errors our seleves. this will prevent
	// the system to show a error message box if we would try to l
	UINT nErrorMode = SetErrorMode(1);

	m_pRoot = new PopupMenu(hInst);
    FILE* pStepRC = NULL;
	pStepRC = LCOpen (NULL);
    
	m_bTransparent  = GetRCBool("NoPopupTransparent", FALSE); // draw transparent by default

	m_bHeader = GetRCBool("NoPopupTitles", FALSE);

	// Set the painters ...
    GetRCString("PopupTitlePix", m_pszTitlePix, "", MAX_RC_STRING);
    GetRCString("PopupEntryPix", m_pszEntryPix, "", MAX_RC_STRING);
    GetRCString("PopupSelEntryPix", m_pszSelEntryPix, "", MAX_RC_STRING);
	GetRCString("PopupBottomPix", m_pszBottomPix, "", MAX_RC_STRING);
	m_bGradientTitle = GetRCBool("PopupGradientTitle", TRUE);
	m_nGradientTitle = GetRCColor("PopupGradientTitle", 0x00ff00ff);
	m_bGradientEntry = GetRCBool("PopupGradientEntry", TRUE);
	m_nGradientEntry = GetRCColor("PopupGradientEntry", 0x00ff00ff);
	// Base colors
	m_nTitleColor   = GetRCColor("PopupTitleBgColor", GetSysColor(COLOR_ACTIVECAPTION));
	m_nInActiveTitleColor = GetRCColor("PopupInActiveTitleBgColor", GetSysColor(COLOR_INACTIVECAPTION));
    m_nEntryColor   = GetRCColor("PopupEntryBgColor", GetSysColor(COLOR_BTNFACE));
    m_nSelEntryColor= GetRCColor("PopupSelEntryBgColor", GetSysColor(COLOR_HIGHLIGHT));

	// Text colors
	m_nTitleTextColor   = GetRCColor("PopupTitleColor", GetSysColor(COLOR_WINDOWTEXT));
    m_nEntryTextColor   = GetRCColor("PopupEntryColor", GetSysColor(COLOR_MENUTEXT));
    m_nSelEntryTextColor= GetRCColor("PopupSelEntryColor", GetSysColor(COLOR_HIGHLIGHTTEXT));

	// 3d decoration colors
	m_nBevelLightColor = GetRCColor("PopupBevelLightColor", GetSysColor(COLOR_3DHILIGHT));
	m_nBevelDarkColor = GetRCColor("PopupBevelDarkColor", GetSysColor(COLOR_3DSHADOW)); 

	m_pTitle = MakePainter(m_pszTitlePix, m_nTitleColor, m_nGradientTitle, m_bGradientTitle, FALSE);
	m_pEntry = MakePainter(m_pszEntryPix, m_nEntryColor, m_nGradientEntry, m_bGradientEntry, FALSE);
	m_pSelEntry = MakePainter(m_pszSelEntryPix, m_nSelEntryColor, m_nGradientEntry, m_bGradientEntry, TRUE);
	if(lstrlen(m_pszBottomPix) > 0)
		m_pBottom = new BmpPainter(LoadLSImage(m_pszBottomPix, NULL),m_bTransparent);

	m_bIcons = GetRCBool("PopupIcons", TRUE);

	m_bAutoSeparator = GetRCBool("PopupAutoSeparator", TRUE);
	m_bShowExtension = GetRCBool("PopupShowExtension", TRUE);

	// runitem configuration
	RunItem::SetRememberLast(GetRCBool("PopupRunRememberLast", TRUE));

	// Header item configuration
	HeaderItem::SetDrawCloseButton(GetRCBool("NoPopupCloseButton", FALSE));
	HeaderItem::SetAlwaysOnTop(GetRCBool("PinnedPopupNotOnTop", FALSE));

	// POPUP HEIGHTS
    m_nSubmenuHeight= GetRCInt("PopupSubmenuHeight", 20);
	m_nTitleHeight = GetRCInt("PopupTitleHeight", m_nSubmenuHeight);

	// folder item configuration
	int nOverlapX = GetRCInt("PopupOverlapX", 5);
	int nOverlapY = GetRCInt("PopupOverlapY", -m_nSubmenuHeight);
	FolderItem::SetOverlap(nOverlapX, nOverlapY);
	FolderItem::SetDrawArrow(GetRCBool("NoPopupFolderIcon", FALSE)); 
	FolderItem::SetDelay(GetRCInt("PopupMenuDelay", 100));

	// datetime configuration
	m_nDateTimeAlignment = 	GetRCInt("PopupDateTimeAlign", DT_RIGHT);
    
	// POPUP WIDTHS
    m_nMinWidth = GetRCInt("MinPopupWidth", 100);
	m_pRoot->SetMinWidth(m_nMinWidth);
	if(!GetRCBool("PopupAdaptiveWidth", TRUE))
		PopupMenu::SetMaxWidth(m_nMinWidth);
	else
		PopupMenu::SetMaxWidth(max(m_nMinWidth, GetRCInt("MaxPopupWidth", 500)));

	
	BmpPainter::SetBlt(GetRCInt("PopupBlt", BMPPAINT_PLAIN));
	TaskItem::SetWindowCaption(GetRCBool("PopupTasksWindowCaption", TRUE));

	// Load the default font face
    GetRCString("PopupFontFace",      m_pszFontFace, "", MAX_RC_STRING);
	GetRCString("PopupEntryFontFace", m_pszEntryFontFace, "", MAX_RC_STRING);
	int nFontHeight = GetRCInt("PopupFontHeight", 16);
	if(lstrlen(m_pszFontFace) > 0)
	{
	    m_hDefaultFont = CreateFont(nFontHeight,0,0,0,FW_NORMAL,FALSE,FALSE,
    						FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
    						DEFAULT_QUALITY,DEFAULT_PITCH,m_pszFontFace);
	}
	else
	{
		LOGFONT logFont;
		SystemParametersInfo(SPI_GETICONTITLELOGFONT, 0, &logFont,0);
		m_hDefaultFont = CreateFontIndirect(&logFont);
	}

	if(lstrlen(m_pszEntryFontFace) > 0)
	{
	    m_hEntryFont = CreateFont(nFontHeight,0,0,0,FW_NORMAL,FALSE,FALSE,
    						FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
    						DEFAULT_QUALITY,DEFAULT_PITCH,m_pszEntryFontFace);
	}
	else
	{
		m_hEntryFont = m_hDefaultFont;
	}

	// Set the font
	m_pTitle->SetFont(m_hDefaultFont, m_nTitleTextColor);
	m_pEntry->SetFont(m_hEntryFont, m_nEntryTextColor);
	m_pSelEntry->SetFont(m_hEntryFont, m_nSelEntryTextColor);

	// shall bevels be drawn
	MenuItem::DrawBevel(!GetRCBool("NoPopupBevel", TRUE));
	PopupMenu::DrawBevel(!GetRCBool("NoPopupMenuBevel", TRUE));

	// setup colors to be used for 3d details
	MenuItem::SetLight(m_nBevelLightColor);
	MenuItem::SetDark(m_nBevelDarkColor);

	PopupMenu::SetLight(m_nBevelLightColor);
	PopupMenu::SetDark(m_nBevelDarkColor);

	MenuItem::SetIndent(GetRCInt("PopupTextOffset", 5));

	// The menu title
	char pszHotListName[MAX_RC_STRING];
	GetRCString("HotListName", pszHotListName, "LiteSTEP", MAX_RC_STRING);
	AddHeaderItem(m_pRoot, pszHotListName, TRUE);

	// menu contents
	ParseStepRC(pStepRC, m_pRoot);
    LCClose(pStepRC);

	AddBottomItem(m_pRoot);
	m_pRoot->Validate();

	int Msgs[10];
    Msgs[0] = LM_POPUP;
    Msgs[1] = LM_HIDEPOPUP;
    Msgs[2] = LM_GETREVID;
	Msgs[3] = 0;
    SendMessage (hParentWnd, LM_REGISTERMESSAGE, (WPARAM)m_pRoot->GetWindow(), (LPARAM)Msgs);

	SetErrorMode(nErrorMode);
}

Painter* PopupMaker::MakePainter(char* pszImage, DWORD dwColor, DWORD dwGradColor, BOOL bGrad, BOOL bSwap)
{
	Painter* pNewPainter = NULL;
	DWORD dwLeft = dwColor;
	DWORD dwRight;

	if(lstrlen(pszImage) > 0)
	{
		pNewPainter = new BmpPainter(LoadLSImage(pszImage, NULL), m_bTransparent);
	}
	else if(dwGradColor != 0x00ff00ff)
	{
		dwRight = dwGradColor;
		if(bSwap) swap(dwLeft, dwRight);
		pNewPainter = new GradientPainter(dwLeft, dwRight);
	}
	else if(bGrad)
	{
		dwRight = 0;
		if(bSwap) swap(dwLeft, dwRight);
		pNewPainter = new GradientPainter(dwLeft, dwRight);
	}
	else
	{
		pNewPainter = new SolidPainter(dwColor);
	}

	return pNewPainter;
}

MenuItem* PopupMaker::MakeBangItem(char* pszItem, char* pszTitle)
{
	MenuItem* pMenuItem = NULL;
	if(lstrcmpi(pszItem, "!RemoteAmp") == 0)
		pMenuItem = new RemoteAmpItem();
	else if(lstrcmpi(pszItem, "!DateTime") == 0)
		pMenuItem = new TimeItem(m_nDateTimeAlignment, pszTitle == NULL ? "%c" : pszTitle);
	else if(lstrcmpi(pszItem, "!PopupImage") == 0)
		pMenuItem = new SeparatorItem(FALSE);
	else if(lstrcmpi(pszItem, "!PopupRun") == 0)
		pMenuItem = new RunItem(pszTitle == NULL ? "Run:" : pszTitle);
	else if(lstrcmpi(pszItem, "!PopupTasks") == 0)
		pMenuItem = new TaskFolder(this, pszTitle == NULL ? "Tasks" : pszTitle);
	else if(lstrcmpi(pszItem, "!Separator") == 0)
		pMenuItem = new SeparatorItem();
	return pMenuItem;
}

void PopupMaker::AddHeaderItem(PopupMenu* pMenu, char* pszTitle, BOOL bVeto)
{
	if(m_bHeader || bVeto)
	{
		MenuItem* pHead = new HeaderItem(pszTitle);
		pHead->SetActivePainter(m_pTitle);
		pHead->SetPainter(m_pTitle);
		pHead->SetHeight(m_nTitleHeight);
		pMenu->AddMenuItem(pHead);
	}
}

void PopupMaker::AddBottomItem(PopupMenu* pMenu)
{
	if(m_pBottom)
	{
		MenuItem* pMenuItem = new SeparatorItem(FALSE);
		pMenuItem->SetPainter(m_pBottom);
		pMenuItem->SetHeight(m_nTitleHeight);
		pMenu->AddMenuItem(pMenuItem);
	}
}

void PopupMaker::ParseStepRC(FILE* pStepRC, PopupMenu* pRoot)
{
    char  pszBuffer[4096] = {'\0'};
    char  token1[4096], token2[4096], token3[4096], extra_text[4096];
    char* tokens[3];

    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;

    while (LCReadNextConfig (pStepRC, "*Popup", pszBuffer, sizeof (pszBuffer)))
    {
		HICON hIcon = NULL;		
		Painter* pPainter = m_pEntry;
		MenuItem* pMenuItem = NULL;
		char* pszIcon = NULL;
		int nHeight = m_nTitleHeight;
		int nTokens = 0;
    	token1[0] = token2[0] = token3[0] = extra_text[0] = '\0';

    	nTokens = LCTokenize (pszBuffer, tokens, 3, extra_text);
		if(nTokens == 3)
		{				
			// "*popup "Start Menu" 17 default.bmp "!PopupFolder:C:\WINDOWS\Start Menu""
			if(atoi(token3) > 0)
			{
				char pszBmp[4096] = {'\0'};
				char pszCmd[4096] = {'\0'};
				char* ppszExt[3];
				ppszExt[0] = pszBmp;
				ppszExt[1] = pszCmd;

				nHeight = atoi(token3);

    			LCTokenize(extra_text, ppszExt, 2, token1);
				pPainter = new BmpPainter(LoadLSImage(pszBmp, NULL),m_bTransparent);
				m_Painters.push_back(pPainter);
				lstrcpy(token3, pszCmd);				
			}

   			if (!lstrcmpi(token3, "Folder"))
    		{
				// Folder
				PopupMenu* pSub = new PopupMenu(hInst);
				pSub->SetMinWidth(m_nMinWidth);
				AddHeaderItem(pSub, token2, FALSE);

				// recusively parse the step.rc
				ParseStepRC(pStepRC, pSub);
				pSub->Validate();

				pMenuItem = new FolderItem(pSub, token2);
			}
    		else if(_memicmp(token3, "!PopupFolder:", lstrlen("!PopupFolder:")) == 0)
			{
				// PopupFolder
				char pszFolder[_MAX_PATH];
				char* pszTemp = token3 + lstrlen("!PopupFolder:");
				ExpandEnvironmentStrings(pszTemp, pszFolder, sizeof(pszFolder));

				PopupMenu* pSub = LoadFolder(pszFolder);
				pMenuItem = new FolderItem(pSub, token2);
				pszIcon = "";
			}
			else if(_memicmp(token3, "!DynamicFolder:", lstrlen("!DynamicFolder:")) == 0)
			{
				// PopupFolder
				char pszFolder[_MAX_PATH];
				char* pszTemp = token3 + lstrlen("!DynamicFolder:");
				ExpandEnvironmentStrings(pszTemp, pszFolder, sizeof(pszFolder));

				//PopupMenu* pSub = LoadFolder(pszFolder);
				pMenuItem = new DirectoryFolder(pszFolder, TRUE, this, token2);
				pszIcon = "";
			}
			else if(_memicmp(token3, "!PopupDynamicFolder:", lstrlen("!PopupDynamicFolder:")) == 0)
			{
				// PopupFolder
				char pszFolder[_MAX_PATH];
				char* pszTemp = token3 + lstrlen("!PopupDynamicFolder:");
				ExpandEnvironmentStrings(pszFolder, pszFolder, sizeof(pszFolder));

				//PopupMenu* pSub = LoadFolder(pszFolder);
				pMenuItem = new DirectoryFolder(pszFolder, TRUE, this, token2);
				pszIcon = "";
			}
			// if it is a special menu item that wants a bmp background
			else if(token2[0] == '!')
			{	
				pMenuItem = MakeBangItem(token2, NULL);

				// token2 == token3 then there is the thing with lscp bugs..
				if(pMenuItem != NULL && lstrcmpi(token2, token3) != 0)
				{
					pPainter = new BmpPainter(LoadLSImage(token3, NULL),m_bTransparent);
					m_Painters.push_back(pPainter);
				}
			}
			else
			{
				pMenuItem = MakeBangItem(token3, token2);
				if(pMenuItem == NULL)
				{
					pMenuItem = new CommandItem(token3, extra_text, token2);
					pszIcon = token3[0] == '!' ? NULL : token3;
				}
			}

			if(m_bIcons && pszIcon != NULL)
			{
				HICON hIcon = GetIconFromPath(pszIcon);
				if(hIcon != NULL)
					pMenuItem->SetIcon(hIcon);
			}

			if(pMenuItem != NULL)
			{
				pMenuItem->SetHeight(nHeight);
				pMenuItem->SetPainter(pPainter);
				pMenuItem->SetActivePainter(m_pSelEntry);
				pRoot->AddMenuItem(pMenuItem);
			}
		}
		// "*popup !DateTime"
		else if(nTokens == 2)
		{
			if(lstrcmpi(token2, "~Folder") == 0)
			{
				AddBottomItem(pRoot);
				return;
			}
			else
			{
				pMenuItem = MakeBangItem(token2, NULL);
			}		
				
			if(pMenuItem != NULL)
			{
				// hack to make the separator the separator size
				if(lstrcmpi(token2, "!Separator") == 0)
					pMenuItem->SetHeight(4);
				else
					pMenuItem->SetHeight(m_nSubmenuHeight);

				pMenuItem->SetPainter(m_pEntry);
				pMenuItem->SetActivePainter(m_pSelEntry);
				pRoot->AddMenuItem(pMenuItem);
			}
    	} 			
    }	
}


PopupMenu* PopupMaker::LoadFolder(char* pszFolder)
{
  //For folder merging
  char seps[]   = "|";
  char *token;
  char* tempPath = new char[strlen(pszFolder)+1];
  strcpy(tempPath, pszFolder);
  
  char pszPattern[_MAX_PATH];
  long handle;
  _finddata_t found;
  HICON hIcon = NULL;
  MenuItem* pItem = NULL;
  char* pszIconName=NULL;
  char* pszTemp;
  BOOL bFolders = FALSE;
  BOOL bFiles = FALSE;
  
  // create menu objects 
  PopupMenu* pMenu = new PopupMenu(hInst);
  pMenu->SetMinWidth(m_nMinWidth);
  
  pszTemp = strrchr(pszFolder, '\\');
  if(pszTemp == pszFolder)
    pszTemp = pszFolder;
  else
    pszTemp++;
  AddHeaderItem(pMenu, pszTemp, FALSE);
  
  token = strtok(tempPath, seps );
  while (token != NULL) {
    
    // make file search pattern of foldername 
    //lstrcpy(pszPattern, pszFolder);
    lstrcpy(pszPattern, token);
    if(pszPattern[lstrlen(pszPattern)] != '\\')
      lstrcat(pszPattern, "\\");
    lstrcat(pszPattern, "*");
    
    // for all files in the folder, create a CommandItem
    // and add them to the current popupmenu
    handle = _findfirst(pszPattern, &found);
    
    if(handle != -1) 
    {
      do{
        if(lstrcmp(found.name, ".") ==0 || lstrcmp(found.name, "..") ==0)
          continue;
        if(found.attrib & _A_SUBDIR) 
        {	
          bFolders = TRUE;
          char pszSubFolder[_MAX_PATH];
          lstrcpy(pszSubFolder,token);
          lstrcat(pszSubFolder,"\\");
          lstrcat(pszSubFolder,found.name);
          pItem = new DirectoryFolder(pszSubFolder, FALSE, this, found.name);
          pszIconName = "";
        }
        else
        {
          char pszTitle[_MAX_PATH];
          char pszCmd[_MAX_PATH];
          
          bFiles = TRUE;
          // Assemble command 
          lstrcpy(pszCmd, token);
          lstrcat(pszCmd, "\\");
          lstrcat(pszCmd, found.name);
          
          // Fix title (remove the extension like .lnk)
          lstrcpy(pszTitle, found.name);
          int nStrLen = lstrlen(pszTitle);
          if(nStrLen > 4 && m_bShowExtension)
          {
            // if we are not to show the extention, just remove
            // .lnk or .exe
            char* pszExt = pszTitle + nStrLen - 4;
            if(lstrcmpi(pszExt, ".lnk")==0 || 
              lstrcmpi(pszExt, ".exe")==0 || 
              lstrcmpi(pszExt, ".com")==0)
              pszTitle[nStrLen-4]='\0';
          }
          else
          {
            PathRemoveExtension(pszTitle);
          }
          
          pItem = new CommandItem(pszCmd, NULL,pszTitle);
          pszIconName = pszCmd;
        }
        
        pItem->SetHeight(m_nSubmenuHeight);
        pItem->SetPainter(m_pEntry);
        pItem->SetActivePainter(m_pSelEntry);
        
        if(m_bIcons)
          pItem->SetIcon(GetIconFromPath(pszIconName));
        
        pMenu->AddMenuItem(pItem);
        
      }while(_findnext(handle, &found) == 0);
    }
    _findclose(handle);
    token = strtok( NULL, seps );
  }
  AddBottomItem(pMenu);
  
  if(m_bAutoSeparator && bFolders && bFiles){
    MenuItem* pMenuItem = new SeparatorItem();
    pMenuItem->SetSortPriority(5);
    pMenuItem->SetPainter(m_pEntry);
    pMenuItem->SetActivePainter(m_pSelEntry);
    pMenu->AddMenuItem(pMenuItem);
  }
  
  pMenu->Sort();
  pMenu->Validate();
  
  delete [] tempPath;
  
  return pMenu;
}
