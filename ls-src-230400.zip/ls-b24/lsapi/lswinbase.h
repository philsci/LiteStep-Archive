#ifndef __MODULE_H
#define __MODULE_H

#include <windows.h>

#define BEGIN_MESSAGEPROC switch (message.uMsg) {
#define MESSAGE(handler, msg) case msg: handler(message); break;
#define REJECT_MESSAGE(msg) case msg: break;
#define END_MESSAGEPROC default: message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam); }


extern const HINSTANCE hInstance;


struct Message
{
  UINT uMsg;
  union
  {
    struct
    {
      WPARAM wParam;
      LPARAM lParam;
      LRESULT lResult;
    };
    struct
    {
      WORD wParamLo;
      WORD wParamHi;
      UINT lParamLo;
      UINT lParamHi;
      UINT lResultLo;
      UINT lResultHi;
    };
  };
};


class Window
{
protected:
  static WNDCLASSEX windowClass;
  static LPCSTR className;
  static DWORD instanceCount;
  const volatile HWND hWnd;
  const HWND hParent;

public:
  Window(LPCSTR className);
  virtual ~Window();
  const HWND handle() const;

protected:
  bool createWindow(DWORD dwExStyle, LPCTSTR lpWindowName, DWORD dwStyle,
                    int x, int y, int nWidth, int nHeight, HWND hWndParent);
  bool destroyWindow();

  static LRESULT CALLBACK wndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  virtual void windowProc(Message& message);
};

#endif
