#include "LSBitmap.h"

// ** BitMP Class
LSBitmap::LSBitmap() {
	bitmap = NULL;
	region = NULL;
	name[0] = '\0';
	x = 0;
	y = 0;
	backColor = RGB(255,255,255);
	foreColor = RGB(255,255,255);
}

void LSBitmap::destroy() {
	if (bitmap) {
		DeleteObject(bitmap);
		bitmap = NULL;
	}
/*	if (region) {
		DeleteObject(region);
		region = NULL;
	}*/
	x = 0;
	y = 0;
	name[0] = '\0';
	backColor = RGB(255,255,255);
	foreColor = RGB(255,255,255);
}
