//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by install.rc
//
#define IDB_BKGND                       101
#define IDI_VERSION                     103
#define IDD_ABOUT                       104
#define IDD_BROWSE                      105
#define IDC_ABOUT_EDIT                  1003
#define IDC_BROWSE_DEST                 1004
#define IDC_BROWSE_LIST                 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
