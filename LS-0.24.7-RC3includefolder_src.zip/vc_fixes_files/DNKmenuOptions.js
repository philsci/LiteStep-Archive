//////////
// cjw@dinkumware.com - 12.02
//
//////////

var visableMenu = null;
var menuHead = null;
var menuLinks = null;

var pic = "";
var menuItem = "";
var mbid = 0;
var orderSelectStyle = "COLOR: #ffffcc; background-Color: #993333; cursor: hand;"
var orderDeselectStyle = "COLOR: #ffffcc; background-Color: #993333; cursor: hand;"
var mainSelectStyle = "COLOR: #ffffcc; background-Color: #996600; cursor: hand; BORDER-Right: black 1px solid"
var mainDeselectStyle = "COLOR: #336699; background-Color: #ffffcc; cursor: hand; BORDER-right: black 1px solid"
var mainLinksSelectStyle = "COLOR: #ffffcc; background-Color: #996600; cursor: hand"
var mainLinksDeselectStyle = "COLOR: #336699; background-Color: #ffffcc; cursor: hand"
var orderLinksSelectStyle = "COLOR: #ffffcc; background-Color: #993333; cursor: hand"
var orderLinksDeselectStyle = "COLOR: #ffffcc; background-Color: #993333; cursor: hand"
var selectStyle = "COLOR: #ffffcc; background-Color: #996600; FONT-SIZE: 7pt; cursor: hand; BORDER: black 0px solid";
var deselectStyle = "COLOR: #336699; background-Color: #ffffcc; FONT-FAMILY: Verdana, Tahoma, Microsoft Sans Serif, Arial; FONT-SIZE: 7pt; cursor: hand; BORDER: black 0px solid";
var textStyle = "COLOR: #000000; background-Color: #ffffcc; FONT-FAMILY: Verdana, Tahoma, Microsoft Sans Serif, Arial; FONT-SIZE: 7pt; cursor: default; BORDER: black 0px solid";
var curMenu = 0;    

var detect = navigator.userAgent.toLowerCase();
var OS,browser,total,thestring;
var version = 0;

if (checkIt('konqueror'))
{
	browser = "Konqueror";
	OS = "Linux";
}
else if (checkIt('omniweb')) browser = "OmniWeb"
else if (checkIt('opera')) browser = "Opera"
else if (checkIt('webtv')) browser = "WebTV";
else if (checkIt('icab')) browser = "iCab"
else if (checkIt('msie')) browser = "Internet Explorer"
else if (!checkIt('compatible'))
{
	browser = "Netscape Navigator"
	version = detect.charAt(8);
}
else browser = "An unknown browser";

if (!version) version = detect.charAt(place + thestring.length);

if (!OS)
{
	if (checkIt('linux')) OS = "Linux";
	else if (checkIt('x11')) OS = "Unix";
	else if (checkIt('mac')) OS = "Mac"
	else if (checkIt('win')) OS = "Windows"
	else OS = "an unknown operating system";
}

function checkIt(string)
{
	place = detect.indexOf(string) + 1;
	thestring = string;
	return place;
}

var nscape = (navigator.appName == "Netscape");
var msiev5 = (browser == "Internet Explorer" && version < 6)


//////////
// These are the functions used to build them menus.

function redirect(location)
{ 
  window.location = location
}

function movepic(img_name,img_src) 
{
	document[img_name].src=img_src;
	document[img_name].alt="";
}

function hideAlt() 
{
	document[menuItem].alt="";
}

function showMenu(menuNumber,delay,orderO) 
{
	
	if (delay == "") delay = 0;
	
	visableMenu = eval("document.all.menuBox" + menuNumber);
	menuHead = eval("document.all.menu" + menuNumber);
	menuLinks = eval("document.all.menuLink" + menuNumber);
	
	setTimeout("delayMenuUp(" + orderO + ")",delay);
	//menuUp(orderO)
	curMenu = menuNumber
	pic = "/images/menuItem" + menuNumber + "_on.gif"; 
	menuItem = "menuItem" + menuNumber
	return 0;
}

function hideMenu(menuNumber) 
{
	pic = "/images/menuItem" + menuNumber + ".gif"; 
	menuItem = "menuItem" + menuNumber;
	//////
	//toggleArrow();
	menuDown(menuNumber);
return 0;
	
}
function hideAllMenus() 
{
	//int x = 0;
	//for(x; x < 8; x++) menuDown(x);
	
return 0;
	
}
function toggleArrow() {
if (menuItem != ""  && pic != "") movepic(menuItem,pic);
return 0;
}


function delayMenuUp(orderO)
{
//////
//toggleArrow();
menuUp(orderO);
}

function menuUp(orderO)
{
if (visableMenu != null) 
	{
	visableMenu.style.display = 'block';
	if (orderO == 1)
	{
		 menuHead.style.cssText = orderSelectStyle;
		 menuLinks.style.cssText = orderLinksSelectStyle;
	}
	if (orderO != 1) 
	{
		menuHead.style.cssText = mainSelectStyle;
		menuLinks.style.cssText = mainLinksSelectStyle;
		menuHead.style.display = 'block';
		menuLinks.style.display = 'block';
	}
	
					
	}
return 0;
}

function menuDown(orderO)
{
	if(visableMenu != null) {
				
				if(!visableMenu.contains(event.toElement)) {
					
					visableMenu.style.display = 'none';
					if (orderO == 1)
					{
						menuHead.style.cssText = orderDeselectStyle;
						menuLinks.style.cssText = orderLinksDeselectStyle;
					}
					if (orderO != 1)
					{
						menuHead.style.cssText = mainDeselectStyle;
						menuLinks.style.cssText = mainLinksDeselectStyle;	 
						menuHead.style.display = 'block';				
						menuLinks.style.display = 'block';
					}
					
					
					menuLinks = null;
					visableMenu = null;
					menuHead = null;
					
					window.status='';
	
					

				}
			}
hideAllMenus()
return 0;
}


function menuOption(linkText,linkUrl,orderO)
{
if (linkUrl > "")
	{
	if (linkUrl.search("http:") >= 0)
		{var statusText = linkUrl
		} else
		{var statusText = "http://www.dinkumware.com" + linkUrl}
	if (orderO != 1) document.write ("<tr nowrap><td style=\""+ deselectStyle +"\" onMouseOver=\"this.style.cssText='" + selectStyle + "'; window.status='" + statusText + "'\" onMouseOut=\"this.style.cssText='" + deselectStyle + "'\" onClick=\"window.location = ('" + linkUrl+ "')\">"+ linkText +"</td></tr>");
	if (orderO == 1) document.write ("<tr nowrap><td style=\""+ orderDeselectStyle +"\" onMouseOver=\"this.style.cssText='" + orderSelectStyle + "'; window.status='" + statusText + "'\" onMouseOut=\"this.style.cssText='" + orderDeselectStyle + "'\" onClick=\"window.location = ('" + linkUrl+ "')\">"+ linkText +"</td></tr>");
	} else
	{
	document.write ("<tr nowrap><td style=\""+ textStyle +"\">" + linkText + "<br></td></tr>");
	}
}
function startMenu(menuNumber,orderO)
{
if (orderO != 1) document.write ("<span id=\"menuBox" + menuNumber + "\" onMouseOver=\"showMenu(" + menuNumber + ")\" onMouseOut=\"hideMenu(0)\">");
if (orderO == 1) document.write ("<span id=\"menuBox" + menuNumber + "\" onMouseOver=\"showMenu(" + menuNumber + ",0,1)\" onMouseOut=\"hideMenu(1)\">");
document.write ("<table class=\"menuBox\" width=200>")
return 0;
}
function finishMenu()
{
document.write ("</table></span>");
return 0;
}


//////////
// To add options to the menu just add a line in the space bracketed off by 
// the comment lines using the function provided above.  The linkUrl argument
// is optional.  If left off it will just show the text.
//
//////////

//////////
//block out Netcape -- it causes it to hang for some reason.
if (!nscape && !msiev5)
{
	startMenu(0);
		//////////
		// Dinkumware Home Page
		menuOption("Click to go back to the<BR>Dinkumware, Ltd. home page.");
		//CoreX Library
		//////////
	finishMenu();
	startMenu(1);
		//////////
		// Dinkum Libraries Menu Options
		menuOption("Unabridged Library for VC++","/libdual_vc.html");
		menuOption("Unabridged Library","/libdual.html");
		menuOption("CoreX Library","/libDCorX.html");
		menuOption("Jcore Library","/libjcorev1.html");
		//CoreX Library
		//////////
	finishMenu();
		
	startMenu(2);
		//////////
		// Dinkum Proofers Menu Options
		menuOption("Quick Proofer","/qproofer.html");
		menuOption("C++ Proofer","/cproofer.html");
		menuOption("Jcore Proofer","/jproofer.html");
		//
		//////////
	finishMenu();
	
	startMenu(3);
		//////////
		// Dinkum Library Reference Menu Options
		menuOption("Unabridged Library Reference","/libraries_ref.html");
		menuOption("C++ Library Reference","/refxcpp.html");
		menuOption("C99 Library Reference","/refxc.html");
		menuOption("EC++ Library Reference","/refxdal.html");
		menuOption("CoreX Library Reference","/refxcorex.html");
		menuOption("Jcore Library Reference","/refxjcore.html");
		//
		//////////
	finishMenu();

	
	startMenu(4);
		//////////
		// Dinkum Support Menu Options
		menuOption("Known Bugs","/support.html");
		menuOption("Posix Locales","/liblocales.html");
		menuOption("Bug Report Form","/support/bugReport.aspx");
		menuOption("Website Questions or Comments","/support/websiteComments.aspx");
		menuOption("Search the Dinkumware Website","/search/search.asp");
		menuOption("Login to the Customer Support Pages","/support/login.aspx");
		//
		//////////
	finishMenu();

	startMenu(5);
		//////////
		// Dinkum Exam Menu Options
		menuOption("Click to Exam? our libraries.");
		//
		//////////
	finishMenu();

	startMenu(6);
		//////////
		// Dinkum Talks & Papers Menu Options
		menuOption("Talks:");
		menuOption("Embedded C++","/embed9710.html");
		menuOption("Translating Java to C","/jproject.html");
		menuOption("Papers:");
		menuOption("JFE Embedded Cross Compiler and Dinkum Jcore Library","/javatocv3.html");
		//
		//////////
	finishMenu();

	startMenu(7);
		//////////
		// Dinkum Search Site Menu Options
		menuOption("Search the Dinkumware website or the online reference manuals.");
		//
		//////////
	finishMenu();

	startMenu(8,1);
		//////////
		// Dinkum Order On-Line Menu Options
		menuOption("Click to order Dinkumware products<br>for instant delivery by download<br>from our secure web server.","",1);
		//
		//////////
	finishMenu();
}

