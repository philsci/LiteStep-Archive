#ifndef __POPUP2_H
#define __POPUP2_H

#ifndef STRICT
#define STRICT
#endif

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifdef _UNICODE // yea! we can define unicode to make an NT version
#define _string wstring // and it will be alot quicker, than the default ansi version
#else // running on NT
#define _string string
#endif


#pragma	warning(disable: 4786) // STL naming warnings



#include "../lsapi/lsapi.h"
#include <algorithm>
#include <functional>
#include <vector>
#include <string>

using namespace std;

//const MAX_TEXT = 256;
const MAX_TOKEN = 2048;
const MENU_TIMER = 701;
const SCROLL_TIMER = 702;
const SCROLL_DELAY = 10;

//pre-decl 
class Popup;

static char popupSig[4] = {'P', 'O', 'P', 'S'};
static LPCTSTR szClsId[] = {
	/* control panel */ 
	"{21EC2020-3AEA-1069-A2DD-08002B30309D}",
	/* network neighbourhood */
	"{208D2C60-3AEA-1069-A2D7-08002B30309D}",
	/* dial-up network */
	"{992CFFA0-F557-101A-88EC-00DD010CCC48}",
	/* my computer */
	"{20D04FE0-3AEA-1069-A2D8-08002B30309D}",
	/* last entry */
	NULL};
static LPCTSTR szExtToRemove[] = { ".lnk",
	".exe", ".pif", ".com", ".rnk", ".bat", ".cmd", NULL};


class menuItem {
public:

	menuItem();
	menuItem(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams = NULL, Popup* pop = NULL);
	~menuItem();

//protected:
    
	Popup *owner;
	Popup *sub;
    _string name;
	_string command;
	_string params;
	HICON hIcon;
	enum itemType {mi_basic, mi_folder, mi_static, mi_dynamic, mi_tasks};
	itemType type;
};

typedef vector<menuItem*> itemList;  // Item list

menuItem makemenuItemint(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams = NULL, Popup *lp = NULL);

//simple bitmap class
class BitMP {

public:
	BitMP();
	~BitMP(); //{destroy();}
//protected:
//	void destroy();
	HBITMAP bitmap;
	HRGN region;
	_string name;
	int x;
	int y;
	COLORREF backColor;
	COLORREF foreColor;
};

//the popup list container
class Popup 
{ 
public:
	Popup *parent;
	_string title;

	int numVisible;
	bool onLeft;	// For drawing menus on the left
	bool autoMenu;
	HWND hwnd;
	itemList list;
	static BOOL init;
	HRGN region;
//public:
	Popup(Popup *parent = NULL);
	~Popup();
    friend LRESULT CALLBACK wndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

    menuItem*  safeItem(int indx) const;
    int  firstVisible();
    int  lastVisible();
    void firstVisible(int n);
    void lastVisible(int n);
	void scroll(bool downd);
	bool createWindow();
	void destroyWindow();
	void showWindow(bool show = true);
	void openSubMenu(int num);
	void display(int x, int y);
	void display(POINT pt) {display(pt.x, pt.y);}
	void paint();
	void paintBMP(HDC dest, HDC src, BitMP &bmp, RECT r);
	void paintBMP2(HDC src, BitMP bmp, RECT r);
	void drawItem(const menuItem* mi, HDC hdc, HDC mem, BitMP &bmp, RECT r);
	bool itemRect(int indx, RECT *lpRect) const;
	int calcSize(SIZE& s) const;
	int  itemAt(POINT pt) const;
	bool highlight(int indx, bool snapCursor = false);
	int  hittest(POINT pt, int *pindx = NULL) const; // HTCAPTION/HTCLIENT/HTNOWHERE
	void moveMenu(Popup *p, int indx);
	void closeSubmenus(Popup *p = NULL);
	bool execute(int indx = -1); // -1 means execute 'current'
	bool isPopupWnd(HWND hwnd);
	enum {
		gi_clsid = 0x01,   //lookup among predefined CLSIDs
		gi_shell = 0x02    //ask shell to provide icon info
	};
    void getIcon(menuItem* mi, BYTE flags = gi_clsid|gi_shell);
	void registryLookup(char* subKey, char *value);
	void openDynamic(int indx, bool dynamic = true);
	void showTasks(int indx);
	void loadValues();
	void loadMenus();
	void selectItem(BOOL selected);
	void GetRegion();
	int AlphaNav(char chSearchChar, int nStartPoint);
	int popupMenuDelay() { return _popupMenuDelay; };
	int addToList(LPSTR lpszText, LPSTR lpszCommand, LPSTR lpszParams = NULL, Popup *lp = NULL);


private:

	int current;
	int first;
	int last;

	_string popupFontFace;
	_string popupMenuName;

	int popupSubHeight;// = 20;
	int popupMinWidth;// = 100;
	int popupIconSize;// = 20;
	int titleHeight;// = 20;
	int popupFixedWidth;// = 0;
	int _popupMenuDelay;// = 0;
	int popupFontHeight;
	int popupTextOffset;
	int popupTop;

	HFONT popupFont;
	HICON popupDefaultIcon;
	HICON taskDefaultIcon;
	HICON emptyDefaultIcon;
	BOOL useDesktopIni;

//HWND itemCaller = NULL;
//

	BOOL wentRight[255];
	BOOL noPopupBevel; // = FALSE
	BOOL noBottomBMP; // = FALSE;
	BOOL transBlt; // = TRUE;
	BOOL popupFolderIcon; // = TRUE;
	BOOL showPopupIcons; // = FALSE;
	BOOL isFixedWidth; // = FALSE;
	BOOL shrinkPopupBar; // = FALSE;

	BitMP popBMP;
	BitMP backBMP;
	BitMP titleBMP;
	BitMP selectBMP;
	BitMP bottomBMP;

enum Style {ps_colors, ps_itempic, ps_desktop, ps_fullpic};
Style popStyle;

};

int cxGap = 4;
int cxArrow = 7;
int cyArrow = 7;

HPEN hpenBlack = NULL;
HPEN hpenWhite = NULL;
HPEN hpenGray = NULL;
HBRUSH hbrBlack = NULL;
HBRUSH hbrGray = NULL;

struct timer {
	int id;
	bool timerSet;
	Popup  *tmPop;
	int tmNdx;   // item in this popup

	timer(int i) {id=i, timerSet=false, tmPop=NULL, tmNdx=-1;}
	void setTimer(Popup *p, int indx, int interval = 0);
	void killTimer();
	bool sameItem(Popup *p, int indx) const;
	void resetIndex() {tmNdx = -1;}
};

#ifdef	__cplusplus
extern "C" {
#endif	/* __cplusplus */
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) int quitModule(HINSTANCE dllInst);

#ifdef	__cplusplus
};
#endif	/* __cplusplus */

#endif  /* __POPUP2_H */
