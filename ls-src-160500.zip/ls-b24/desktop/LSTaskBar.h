#pragma warning(disable: 4786)

#ifndef LSTASKBAR
#define LSTASKBAR

#include <map>

using namespace std;

class LSBar;
class LSTaskBar;

class LSTaskButton {
	BOOL btnDrag;
	RECT dragRect;
	BOOL lastStatePushed;
public:
	void Repaint();
	LSTaskButton(HWND wnd, LSTaskBar *owner);
	~LSTaskButton();
	static LRESULT CALLBACK WndProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcAppBtn(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	void drawPushed(HDC hdc, RECT r, HWND hwnd, HWND user);
	void drawPopped(HDC hdc, RECT r, HWND hwnd, HWND user);
	void fillButton(HDC hdc, HWND hwnd, int shift, RECT r, HWND user);
	HICON GetWindowIcon(HWND Hwnd);

	HWND window;
    HWND hWnd;
    HICON icon;
    int txtSum;
	HWND tooltipWnd;
	BOOL needTooltip;
	HWND targetWnd;
	HWND hWndParent;
	LSTaskBar *owner;
	LSSettings *settings;
	BOOL current;
	HDC dragDC;

	BOOL debug;
};

class LSTaskBar {
public:
	LSTaskButton* currentButton;
	LSSettings *settings;

	typedef map<HWND, LSTaskButton*> hwnd2LSTaskButton;
	hwnd2LSTaskButton taskBtn;

	int nWin;

	BOOL btnDrag;
	RECT dragRect;
	BOOL lastStatePushed;
	HDC dragDC;
	HWND dragUser;

	HINSTANCE dll;


	HWND hWndParent;

	HWND currentWindow;
	HWND desktopParent;
	LSBar *owner;
	int ScreenHeight;
	HWND hTasksWnd;

	LSTaskBar(LSBar *theDesktop);
	static LRESULT CALLBACK WndProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT WindowProcTasks(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
	virtual ~LSTaskBar();
	void addWindow(HWND hwnd);
	static BOOL CALLBACK EnumWindowsProc(OLE_HANDLE hwnd, LPARAM lParam);
	void RemoveWindow(HWND);
	int inWinList(HWND hwnd);
	void updateTasksView(int force);
	void destroyAppWnd(HWND);
	int getTxtSum(HWND wnd);
	void getRectangle(LPRECT r);
	void GetWinRect(HWND wnd, RECT *r);
private:
	int ScreenWidth;
};

#endif