#ifndef LSTOOLTIPS
#define LSTOOLTIPS

#include <windows.h>
#include <commctrl.h>
#include <vector>

using namespace std;

class LSToolTips {
	vector<TOOLINFO> tips;
	HWND hToolWnd;

public:
	LSToolTips(HWND);
	void CreateTooltip(HWND hWnd, char *txt, RECT *r);
	void UpdateTooltip(HWND hWnd, char *txt, RECT *r);
	void RemoveTooltip(HWND hWnd);
};

#endif //!defined LSTOOLTIPS