//   _     _ _           _
//  | |   (_) |_ ___ ___| |_ ___ _ __
//  | |   | | __/ _ Y __| __/ _ \ '_ \
//  | |___| | ||  __|__ \ ||  __/ |_) |
//  |_____|_|\__\___|___/\__\___| .__/
//                              |_|
//
//       module | taskbar
//      version | 1.0
//  description | display and manipulate running tasks
//       author | maduin <maduin@dasoft.org>
//      created | 21 feb 2000
//

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <commctrl.h>
#include "../lsapi/lsapi.h"
#include "taskbar.h"

// undocumented SwitchToThisWindow API (maybe this should be in LSAPI?)
void (WINAPI *SwitchToThisWindow)( HWND, int );

Taskbar *taskbar;

int initModuleEx( HWND hParent, HINSTANCE hInstance, LPCTSTR pszPath )
{
	InitCommonControls();

	SwitchToThisWindow = (void (WINAPI *)( HWND, int )) GetProcAddress(
		GetModuleHandle( TEXT("USER32.DLL") ),
		TEXT("SwitchToThisWindow") );

	taskbar = new Taskbar;
	taskbar->OnLoad( hInstance );

	return 0;
}

void quitModule( HINSTANCE hInstance )
{
	taskbar->OnUnload();
	delete taskbar;
}

extern "C" int WINAPI DllMain( HINSTANCE hInstance, DWORD dwReason, LPVOID pvReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )
		DisableThreadLibraryCalls( hInstance );

	return 1;
}

// code from re5ource's popups
BOOL IsAppWindow(HWND hWnd)
{
	BOOL bResult = TRUE;
	LONG nStyle;
	HWND hOwner;
	HWND hParent;

	// if it is a WS_CHILD or not WS_VISIBLE, fail it
	nStyle = GetWindowLong(hWnd, GWL_STYLE);	
	if((nStyle & WS_CHILD) || !(nStyle & WS_VISIBLE))
		bResult = FALSE;

	// if the window is a WS_EX_TOOLWINDOW fail it
	nStyle = GetWindowLong(hWnd, GWL_EXSTYLE);
	if(nStyle & WS_EX_TOOLWINDOW)
		bResult = FALSE;

	// If this has an owner, then only accept this window
	// if the partent is not accepted
	hOwner = GetWindow(hWnd, GW_OWNER);
	if(hOwner && bResult)
		bResult = !IsAppWindow(hOwner);

	// if it has a parent, fail
	hParent = GetParent(hWnd);
	if(hParent)
		bResult = FALSE;

	if(GetWindowLong(hWnd, GWL_USERDATA) == 0x49474541)
		bResult = FALSE;

	return bResult;
}

// also from re5ource's popups
HICON GetIconFromWindow(HWND hWnd, BOOL bBigIcon)
{
   HICON hIcon = NULL;

   int nBigOrSmall = bBigIcon ? ICON_BIG : ICON_SMALL;
   int nBigOrSmall2 = bBigIcon ? GCL_HICON : GCL_HICONSM;

   // try to get the normal icon
   SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 0, 
	   SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);

   // if there is none then try to query the icon
   if(!hIcon) SendMessageTimeout(hWnd, WM_QUERYDRAGICON, 
	   nBigOrSmall, 0, SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);

   // get the class icon
   if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);

   //
   if(!hIcon) SendMessageTimeout(hWnd, WM_GETICON, nBigOrSmall, 
	   1, SMTO_ABORTIFHUNG, 1000, (PULONG)&hIcon);

   if(!hIcon) hIcon = (HICON)GetClassLong(hWnd, nBigOrSmall2);
   
   
   return hIcon;
}
