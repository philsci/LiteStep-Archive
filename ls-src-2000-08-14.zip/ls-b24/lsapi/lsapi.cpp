/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************
08/21/00 - Joachim Calvert (NeXTer)
  - Made !UnloadModule and !ReloadModule able to handle an unlimited number
    of modules. Each module should be enclosed in quotes to follow the
    recommendations for forward compatibility.
07/21/00 - Joachim Calvert (NeXTer)
  - Changed the parsing system to treat token"token" as a single token, to
	  make the use of older themes easier.
06/09/00 - Charles Oliver Nutter (Headius)
  - Added LitestepAPIInit function to initialized lsapi on startup
	- Added support for TransparentBlt to TransparentBltLS to speed up FF00FF-
	  style transparency
05/28/00 - Charles Oliver Nutter (Headius)
  - Added support for arbitrary .rc files to the .rc file caching mechanism
	- Wired the new CacheRCFile function into SetupRC and LCOpen so that files
	  could be loaded and cached in a lazy way - on request
	- Fixed stdcall/cdecl issue on bang commands
05/27/00 - Bobby G Vinyard (Message)
  - Fixed a memory leak in AddVariable, it was returning before deleting 
    lowerName
  - Fixed a memory leak in ParseBangCommand, was not deleting tempCommand if
    (FAILED(hr))
  - Removed all references to BangMap, !About bangs not functioning at this 
    time
05/23/00 - Joachim Calvert (NeXTer)
  - Due to popular demand, yesterdays syntax change is no longer in effect.
    GetRCColor() will assume hex for single values and dec for triplets.
  - However, GetRCInt() does, as of yesterday accept values in either octal,
    decimal or hexadecimal. (Examples: Oct: 0370, Dec: 42, Hex: 0xF0E1D2C3)
  - Fixed the problem with LSGetImagePath() where it wouldn't refresh the
    setting after updating step.rc. (Thanks to Jugg for pointing it out)
05/22/00 - Joachim Calvert (NeXTer)
  - Fixed Headius' use of vectors, since it caused a crash when built under
    BCB. Should also be marginally faster since it now also makes proper
    use of iterators.
  - Also tweaked the GetRCxxx functions a bit. Bools can now be turned off with
    either off, false and no.
  - GetRCColor() now accepts color values as either a single value or a
    triplet in the bases octal, decimal and hexadecimal. All values default to
    decimal, so if you want hex, begin the value with 0x (zero x-ray), or just
    0 (zero) for octal. (Examples: 1241245, 0x00FF8040, 255 0 0, 020 030 040)
05/12/00 - Joachim Calvert (NeXTer)
  - Tweaked the parsers a bit
05/12/00 - Charles Oliver Nutter (Headius)
  - changed RCBuffer, ThemeBuffer, and PicBuffer to use a vector internally
04/26/00 - Joachim Calvert (NeXTer)
  - Now clears all evars on recycle.
04/25/00 - Bret Anderson (MrJukes)
  - Replaced BitmapToRegion() with a streamlined version.
04/23/00 - Joachim Calvert (NeXTer)
  - Various fixes to the parsing system. GetToken() is now exported.
04/22/00 - Joachim Calvert (NeXTer)
  - Swapped the argument names for LoadLSImage() so they represent the correct
    data  
04/21/00 - Joachim Calvert (NeXTer)
  - Fixed UniversalTokenize(): didn't clear the passed strings like it should.
04/19/00 - Joachim Calvert (NeXTer)
  - Merged LCTokenize() and CommandTokenize() into a single function, both
    remain for compatibility reasons.
04/18/00 - Joachim Calvert (NeXTer)
  - Added LS_GWL_CLASSPOINTER to lsapi.h to simplify the creation of classbased
    modules. More along these lines are to be expected in the future.
  - Rewrote CommandParse() from scratch. CommandTokenize() will follow shortly.
04/17/00 - Joachim Calvert (NeXTer)
  Fixed the problem with passing NULL as the argument to ParseBangCommand().
  Also fixed a memory leak in the same function, for good measure.
04/17/00 - Joachim Calvert (NeXTer)
  Merged new code for merging images in LoadLSImage(). Thank's to
  Gustav Munkby (grd) for the new code.
  Removed some old junk.
  Added the struct Message for passing messages from the WndProc to the
  actual message handlers.
04/16/00 - Bobby G. Vinyard (Message)
  Fixed popups displaying in upper left hand corner in certain cases
04/14/00 - Bobby G. Vinyard (Message)
  Fixed a variable redefinition error in GetRCString
  Uncommented _LMBANGCOMMANDA in lsapi.h, this was used in litestep.cpp for
    the prupose of allowing none litestep modules to run litestep bang commands
04/15/00 - Joachim Calvert (NeXTer)
  Reworked the setupVars() function, and added more definitions.
04/14/00 - Joachim Calvert (NeXTer)
  Added StripComment() to make LCReadNextLine() remove comments from the
  lines. This saves some time, and also allows Messy's modification
  work with lines containing comments.
04/14/00 - Bobby G. Vinyard (Message)
  Changed GetRCString() to return the whole line instead of only the first
    token.
04/14/00 - Joachim Calvert (NeXTer)
  Some general cleaning of the code, some redundant code commented out
    until we know everything works without it.
04/14/00 - Bobby G. Vinyard (Message)
  Wasn't allowing modules to redefine bangs (e.g. sysvwm & lsvwm redefined
    !vwmleft..etc)
04/13/00 - Bobby G. Vinyard (Message)
  Bang commands now stored in a stl map structure
  Rewrote AddBangCommand, AddBangCommandEx, ParseBangCommand, RemoveBangCommand
  Change BangAbout to use the new map when displaying bang commands
  Added setupBangs called in litestep startup to register lsapi bangs
  Fixed GetRCString on returning the full line in the step if it was all qouted
    now                   SetDesktopLeftClick !popup x=0 y=0
    will work the same as SetDesktopLeftClick "!popup x=0 y=0"
04/13/00 - Joachim Calvert (NeXTer)
  Rewrote the LCTokenize() function from scratch, it's mow less than half
  the size of the original (I must've missed something important ;) ).
04/11/00 - Joachim Calvert (NeXTer)
  Fixed the LSReadNextConfig() function not recognizing tabs as a valid
  whitespace.
  Fixed a leak in LSExecuteEx().
04/08/00 - Bobby G. Vinyard. (Message)
  Added VarExpansion to ParseBangCommand (now when a third party module, i.e.
    lsxcommand, sends a bang command to be parsed, variables will be expanded.
    e.g. previously you had to do !unloadmodule c:\litestep\modules\systray.dll,
    now you should be able to do !unloadmodule %moduledir%systray.dll, or
    something similiar)
  Reimplemented !about, !about detailed
  Added !about bangs, will display all registered bang commands
  Changed About dialog to use a listbox instead of a textbox (modules will be
    unaffected by this change)
  Changed !popup to take coordinates to display the popup (e.g. !popup x=0 y=0)
03/12/00 - Bobby G. Vinyard. (Message)
  Fixed lsapi crashing with an undeclared variable (envvar was being set to NULL,
    and then was being added to the map)
  Added MessageBox warning if lsapi finds an unitialized variable, will tell the 
    variable, and the line
03/05/00 - Bobby G. Vinyard. (Message)
  Added $litestepdir$ variable
03/04/00 - Joachim Calvert
  Changed Messy's routines to use all lowercase for variable names, to
    avoid conflicting declarations.
03/04/00 - Bobby G. Vinyard. (Message)
  Added variable caching to litestep step.rc variables, and added support
    for predefinedvariables to common window paths.
02/18/00 - Bobby G. Vinyard. (Message)
  Removed the EasterEgg Bang declaration =P
18/01/00 - Joachim Calvert aka NeXTer
  Removed the EasterEgg bang, since it's never done anything but crash LS.
11/04/99 - Adrian Heath
  Added function to remove bang commands to allow unloading of modules
  Also changed the AddBangCommand to cope with reloading a bang command
    for old modules.
  Added two new BangCommands that Load/Unload Modules.  These simply send
    a message to LiteStep.exe giving the module name
12/10/98 - Fahim Farook
  Added code by Thedd to facilitate bitmap merging so that you can
    specify more than one image separated by the "|" symbol
11/11/98 - Fahim Farook
  Added a new function called GetLSBitmapSize to replace the old
  GetBitmapSize in popups as C has a similar function and because
    taskbar skinning added by Thedd uses the same function as well
07/11/98 - Fahim Farook
  Added a dialog box to show version information
31/10/98 - Fahim Farook
  Added a function for loading and/or extracting icon files
15/10/98 - B. Kilian
  Added the pattern matching stuff in.
15/09/98 - J. Vaughn
  Added Bang commands for the VWM, and ability to give params
    to the command.
31/08/98 - D. Hodgkiss
  Added TransparentBltLS command
25/08/98 - D. Hodgkiss
  This file contains the source for general functions
    that can be called by core modules

****************************************************************************/

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings
#include <time.h>
#include <stdio.h>
#include <tchar.h>
#include <crtdbg.h>
#include <windows.h>
#include <shlobj.h>
#include <comutil.h>
#include <vector>
#include <map>
#include <string>
#include "../core/ifcs.h"
#include "CallbackBangCommand.h"
#include "StepSettings.h"

#define LSAPI_INTERNAL
#include "lsapi.h"
#include "safestr.h"

using namespace std;

extern const char rcsRevision[];
const char rcsRevision[] = "$Revision: 1.53.2.20 $"; // Our Version
const char rcsId[] = "$Id: lsapi.cpp,v 1.53.2.20 2000/08/10 12:46:43 NeXTer Exp $"; // The Full RCS ID.

typedef vector<tThemePic*> ThemePicVector;

ThemePicVector PicBuffer;

#define MAX_LINE_LENGTH 4096
#define WHITESPACE " \t\n\r"

StepSettings *g_settings;

//typedef map<string, tBangCommand> BangMap;
//static BangMap bangCommands;

static IBangManager *globalBangManager = NULL;

// TransparentBlt API call for 98 and 2k
typedef WINGDIAPI BOOL  (WINAPI *TRANSPARENTBLT)(HDC,int,int,int,int,HDC,int,int,int,int,UINT);
TRANSPARENTBLT TransBlt = NULL;

int matche_after_star(LPCSTR pattern, LPCSTR text);
int fast_match_after_star(LPCSTR pattern, LPCSTR text);

LRESULT CALLBACK About(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void BangRecycle (HWND caller, LPCSTR args);
void BangRun (HWND caller, LPCSTR args);
void BangShutdown(HWND caller, LPCSTR args);
void BangLogoff(HWND caller, LPCSTR args);
void BangQuit(HWND caller, LPCSTR param);
void BangToggleWharf(HWND caller, LPCSTR args);
void BangGather(HWND caller, LPCSTR args);
void BangPopup(HWND caller, LPCSTR args);
void BangTileWindowsH(HWND caller, LPCSTR args);
void BangTileWindowsV(HWND caller, LPCSTR args);
void BangCascadeWindows(HWND caller, LPCSTR args);
void BangMinimizeWindows(HWND caller, LPCSTR args);
void BangRestoreWindows(HWND caller, LPCSTR args);
void BangAbout(HWND caller, LPCSTR args);
void BangUnloadModule (HWND caller, LPCSTR args);
void BangReloadModule (HWND caller, LPCSTR args);
void BangExecute(HWND caller, LPCSTR args);

static int aboutType = 0;
static HWND lbHwnd = 0;

static TCHAR szFileName[MAX_PATH] = { _T('\0') };

BOOL DLLMain(HINSTANCE hinst, DWORD reason, LPVOID) {
	if (reason == DLL_PROCESS_ATTACH) {
	}

	return TRUE;
}



// A shortcut to speed up debugging
//*
int Pause(LPCSTR msg)
{
  return MessageBox(NULL, msg, "LiteStep", MB_ICONEXCLAMATION | MB_TOPMOST);
}
//*/


void setupBangs()
{
  AddBangCommand("!GATHER", BangGather);
  AddBangCommand("!RECYCLE", BangRecycle);
  AddBangCommand("!RUN", BangRun);
  AddBangCommand("!SHUTDOWN", BangShutdown);
  AddBangCommand("!TOGGLEWHARF", BangToggleWharf);
  AddBangCommand("!LOGOFF", BangLogoff);
  AddBangCommand("!QUIT", BangQuit);
  AddBangCommand("!POPUP", BangPopup);
  AddBangCommand("!TILEWINDOWSH", BangTileWindowsH);
  AddBangCommand("!TILEWINDOWSV", BangTileWindowsV);
  AddBangCommand("!CASCADEWINDOWS", BangCascadeWindows);
  AddBangCommand("!MINIMIZEWINDOWS", BangMinimizeWindows);
  AddBangCommand("!RESTOREWINDOWS", BangRestoreWindows);
  AddBangCommand("!ABOUT",  BangAbout);
  AddBangCommand("!UNLOADMODULE", BangUnloadModule);
  AddBangCommand("!RELOADMODULE", BangReloadModule);
  AddBangCommand("!EXECUTE", BangExecute);
}


BOOL GetShellFolderPath( int nFolder, LPTSTR szPath )
{
  LPITEMIDLIST pidl;
  IMalloc *pMalloc;
  HRESULT hr;
  BOOL fResult = FALSE;

  hr = SHGetSpecialFolderLocation( NULL, nFolder, &pidl );

  if( SUCCEEDED( hr ) )
  {
    fResult = SHGetPathFromIDList( pidl, szPath );

    if( fResult )
      lstrcat( szPath, TEXT("\\") );
  }

  if( SUCCEEDED( SHGetMalloc( &pMalloc ) ) )
  {
    pMalloc->Free( pidl );
    pMalloc->Release();
  }

  return fResult;
}

void setupVars(LPCSTR szLSPath)
{
  char szPath[MAX_PATH];

  StrCopy(szPath, szLSPath);
  strcat(szPath, "\\");
  g_settings->AddVariable("litestepdir", szPath);
  g_settings->AddVariable("bitbucket", "::{645FF040-5081-101B-9F08-00AA002F954E}");
  g_settings->AddVariable("documents", "::{450D8FBA-AD25-11D0-98A8-0800361B1103}");
  g_settings->AddVariable("drives", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}");
  g_settings->AddVariable("network", "::{208D2C60-3AEA-1069-A2D7-08002B30309D}");
  g_settings->AddVariable("controls", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{21EC2020-3AEA-1069-A2DD-08002B30309D}");
  g_settings->AddVariable("dialup", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{992CFFA0-F557-101A-88EC-00DD010CCC48}");
  g_settings->AddVariable("networkanddialup", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{7007ACC7-3202-11D1-AAD2-00805FC1270E}");
  g_settings->AddVariable("printers", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{2227A280-3AEA-1069-A2DE-08002B30309D}");
  g_settings->AddVariable("scheduled", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{D6277990-4C6A-11CF-8D87-00AA0060F5BF}");
  g_settings->AddVariable("admintools", "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}\\::{21EC2020-3AEA-1069-A2DD-08002B30309D}\\::{D20EA4E1-3957-11d2-A40B-0C5020524153}");
  // GetShellFolderPath(CSIDL_BITBUCKET, szPath);
  // AddVariable("bitbucket", szPath);
  GetShellFolderPath(CSIDL_COMMON_DESKTOPDIRECTORY, szPath);
  g_settings->AddVariable("commondesktopdir", szPath);
  // GetShellFolderPath(CSIDL_COMMON_DOCUMENTS, szPath);
  // AddVariable("commondocuments", szPath);
  GetShellFolderPath(CSIDL_COMMON_FAVORITES, szPath);
  g_settings->AddVariable("commonfavorites", szPath);
  GetShellFolderPath(CSIDL_COMMON_PROGRAMS, szPath);
  g_settings->AddVariable("commonprograms", szPath);
  GetShellFolderPath(CSIDL_COMMON_STARTMENU, szPath);
  g_settings->AddVariable("commonstartmenu", szPath);
  GetShellFolderPath(CSIDL_COMMON_STARTUP, szPath);
  g_settings->AddVariable("commonstartup", szPath);
  // GetShellFolderPath(CSIDL_CONTROLS, szPath);
  // AddVariable("controls", szPath);
  GetShellFolderPath(CSIDL_COOKIES, szPath);
  g_settings->AddVariable("cookies", szPath);
  GetShellFolderPath(CSIDL_DESKTOP, szPath);
  g_settings->AddVariable("desktop", szPath);
  GetShellFolderPath(CSIDL_DESKTOPDIRECTORY, szPath);
  g_settings->AddVariable("desktopdir", szPath);
  // GetShellFolderPath(CSIDL_DRIVES, szPath);
  // AddVariable("drives", szPath);
  GetShellFolderPath(CSIDL_FAVORITES, szPath);
  g_settings->AddVariable("favorites", szPath);
  GetShellFolderPath(CSIDL_FONTS, szPath);
  g_settings->AddVariable("fonts", szPath);
  GetShellFolderPath(CSIDL_HISTORY, szPath);
  g_settings->AddVariable("history", szPath);
  GetShellFolderPath(CSIDL_INTERNET, szPath);
  g_settings->AddVariable("internet", szPath);
  GetShellFolderPath(CSIDL_INTERNET_CACHE, szPath);
  g_settings->AddVariable("internetcache", szPath);
  GetShellFolderPath(CSIDL_NETHOOD, szPath);
  g_settings->AddVariable("nethood", szPath);
  // GetShellFolderPath(CSIDL_NETWORK, szPath);
  // AddVariable("network", szPath);
  GetShellFolderPath(CSIDL_PERSONAL, szPath);
  g_settings->AddVariable("documentsdir", szPath);
  // GetShellFolderPath(CSIDL_PRINTERS, szPath);
  // AddVariable("printers", szPath);
  GetShellFolderPath(CSIDL_PRINTHOOD, szPath);
  g_settings->AddVariable("printhood", szPath);
  GetShellFolderPath(CSIDL_PROGRAMS, szPath);
  g_settings->AddVariable("programs", szPath);
  GetShellFolderPath(CSIDL_RECENT, szPath);
  g_settings->AddVariable("recent", szPath);
  GetShellFolderPath(CSIDL_SENDTO, szPath);
  g_settings->AddVariable("sendto", szPath);
  GetShellFolderPath(CSIDL_STARTMENU, szPath);
  g_settings->AddVariable("startmenu", szPath);
  GetShellFolderPath(CSIDL_STARTUP, szPath);
  g_settings->AddVariable("startup", szPath);
  GetShellFolderPath(CSIDL_TEMPLATES, szPath);
  g_settings->AddVariable("templates", szPath);
}

FILE* LCOpen(LPCTSTR szPath)
{
  return g_settings->LCOpen(szPath);
}


BOOL LCClose (FILE *f)
{
  return g_settings->LCClose(f);
}


BOOL LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextCommand(f, szBuffer, dwLength);
}


BOOL LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextConfig(f, szPrefix, szBuffer, dwLength);
}


BOOL LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextLine(f, szBuffer, dwLength);
}


int LCTokenize (LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
  return g_settings->Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters);
}


int GetRCInt(LPCTSTR szKeyName, int nDefault)
{
  return g_settings->GetRCInt(szKeyName, nDefault);
}


BOOL GetRCBool(LPCTSTR szKeyName, BOOL ifFound)
{
  return g_settings->GetRCBool(szKeyName, ifFound);
}


BOOL GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen)
{
  return g_settings->GetRCString(szKeyName, szValue, defStr, maxLen);
}


COLORREF GetRCColor(LPCTSTR szKeyName, COLORREF colDef)
{
  return g_settings->GetRCColor(szKeyName, colDef);
}


BOOL GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault)
{
  return g_settings->GetRCLine(szKeyName, szBuffer, nBufLen, szDefault);
}


void VarExpansion(char *buffer, const char * value)
{
  g_settings->VarExpansion(buffer, value);
}


BOOL SetupRC(LPCTSTR szPath)
{
  FILE* rc;
  FILE* thm;
  char  buffer[MAX_LINE_LENGTH];
  char long_file[MAX_PATH_LENGTH];
  char *char_ptr;

	g_settings->SetStepFile(g_settings->CacheRCFile(szPath));

  // Modified - Maduin, 10-20-1999
  //   Accept both ThemeFile and LSThemeFile to facilitate
  //   greater backwards compatibility.
  GetRCString("LSThemeFile", buffer, "", MAX_LINE_LENGTH);
  if(!buffer[0]) {
    GetRCString( TEXT("ThemeFile"), buffer, TEXT(""), MAX_LINE_LENGTH );
	}

	if (buffer[0]) {
		FILE *f;
		string theme = g_settings->CacheRCFile(buffer);
		if (theme != "") {
			g_settings->SetThemeFile(theme);
		}

		// Get Pics from theme for picbuffer
		f = LCOpen(g_settings->GetThemeFile().c_str());

		while (LCReadNextConfig(f, "*ThemePic", buffer, sizeof(buffer))) {
			char token1[MAX_LINE_LENGTH];
			char token2[MAX_LINE_LENGTH];
			char token3[MAX_LINE_LENGTH];
			char *tokens[3];
			int blah = 0, count;
			
			
			tokens[0] = token1;
			tokens[1] = token2;
			tokens[2] = token3;
			
			token1[0] = token2[0] = token3[0] = '\0';
			count = LCTokenize (buffer, tokens, 3, NULL);
			if (count < 3)
				continue;
			if (is_valid_pattern(token2, &blah))
			{
				tThemePic *pPic = new tThemePic;
				StrLCopy(pPic->program, token2, 255);
				StrLCopy(pPic->bitmap, token3, 255);
				PicBuffer.push_back(pPic);
			}
			else
				continue;
		}

		LCClose(f);
	}

  return TRUE;
}


void CloseRC(void)
{
  g_settings->Clear();

  if (PicBuffer.size())
  {
	  ThemePicVector::iterator iter = PicBuffer.begin();
	  while (iter != PicBuffer.end())
	  {
		  delete *iter;
		  iter++;
	  }
	  PicBuffer.clear();
  }
}


HRGN BitmapToRegion (HBITMAP hBmp, COLORREF cTransparentColor, COLORREF cTolerance, int xoffset, int yoffset)
{
  HRGN hMainRgn = NULL;

  if (hBmp)
  {
    int x;
    int y;
    HDC hdc = CreateCompatibleDC(NULL);
    HRGN hTransRgn = NULL;
    BITMAP bitmap;

    GetObject(hBmp, sizeof(bitmap), &bitmap);
    SelectObject(hdc, hBmp);
    hMainRgn = CreateRectRgn(xoffset, yoffset, xoffset + bitmap.bmWidth, yoffset + bitmap.bmHeight);

    for (y = 0; y < bitmap.bmHeight; y++)
    {
      for (x = 0; x < bitmap.bmWidth; x++)
      {
        COLORREF c = GetPixel(hdc, x, y);
        bool inLimits;

        inLimits = (abs(GetRValue(cTransparentColor) - GetRValue(c)) <= GetRValue(cTolerance));
        inLimits &= (abs(GetGValue(cTransparentColor) - GetGValue(c)) <= GetGValue(cTolerance));
        inLimits &= (abs(GetBValue(cTransparentColor) - GetBValue(c)) <= GetBValue(cTolerance));

        if (inLimits)
        {
          HRGN hTempRgn = CreateRectRgn(x+xoffset, y + yoffset, x + xoffset + 1, y + yoffset + 1);
          if (!hTransRgn) hTransRgn = CreateRectRgn(x + xoffset, y + yoffset, x + xoffset + 1, y + yoffset + 1);
          CombineRgn(hTransRgn, hTransRgn, hTempRgn, RGN_OR);
          DeleteObject(hTempRgn);
        }
      }
    }

    CombineRgn(hMainRgn, hMainRgn, hTransRgn, RGN_DIFF);

    DeleteDC(hdc);
    DeleteObject(hTransRgn);
  }

  return hMainRgn;
}

void SetBangManager(void *bangman) {
	if (globalBangManager == NULL) {
		globalBangManager = (IBangManager*)bangman;
		globalBangManager->AddRef();
	}
}

void ClearBangManager() {
	if (globalBangManager != NULL) {
		globalBangManager->Release();
		globalBangManager = NULL;
	}
}

BOOL AddBangCommand(LPCSTR command, BangCommand f)
{
  IUnknown *unk = new CallbackBangCommand(f);
  IBangCommand *bang;
  unk->QueryInterface(IID_IBangCommand, (void**)&bang);

  char* tempCommand = new char[StrLen(command) + 1];
  CharLower(StrCopy(tempCommand, command));

  globalBangManager->AddBangCommand(_bstr_t(tempCommand), bang);

  delete[] tempCommand;
  return true;
}


BOOL AddBangCommandEx(LPCSTR command, BangCommandEx f) // Killarny
{
  IUnknown *unk = new CallbackBangCommand(f, (wchar_t*)_bstr_t(command));
  IBangCommand *bang;
  unk->QueryInterface(IID_IBangCommand, (void**)&bang);

  char* tempCommand = new char[StrLen(command) + 1];
  CharLower(StrCopy(tempCommand, command));

  globalBangManager->AddBangCommand(_bstr_t(tempCommand), bang);
  
  delete[] tempCommand;
  return true;
}


BOOL RemoveBangCommand(LPCSTR command)
{
  int WARNING; // this function always returns TRUE now
  char* tempCommand = new char[StrLen(command) + 1];
  CharLower(StrCopy(tempCommand, command));

  globalBangManager->RemoveBangCommand(_bstr_t(tempCommand));

  delete[] tempCommand;
  return true;
}


BOOL ParseBangCommand(HWND caller, LPCSTR command, LPCSTR args)
{
  char szTempBuffer[MAX_LINE_LENGTH] = "";
  char* tempCommand;
  BOOL result = false;

  if (!command)
    return result;

  tempCommand = new char[StrLen(command) + 1];
  CharLower(StrCopy(tempCommand, command));

  IBangCommand *bang;
  HRESULT hr = globalBangManager->GetBangCommand(_bstr_t(tempCommand), &bang);

  if (FAILED(hr)) {
    delete[] tempCommand;
	  return false;
  }

  SAFEARRAY *params;
  VARIANT ret_val;
  long indicies[1] = {0};

  params = SafeArrayCreateVector(VT_BSTR, indicies[0], 1);

  if (args) {
	  VarExpansion(szTempBuffer, args);
  }

  SafeArrayPutElement(params, indicies, (void*)(BSTR)_bstr_t(szTempBuffer));

  bang->Execute((OLE_HANDLE)caller, params, &ret_val);

	SafeArrayDestroy(params);

  delete[] tempCommand;
  return result;
}

BOOL GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets) {
  return g_settings->GetToken(szString, szToken, szNextToken, useBrackets);
}

int CommandTokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
  return g_settings->Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, true);
}

void CommandParse(LPCSTR cmd, LPSTR cmdBuf, LPSTR argsBuf, DWORD dwCmdBufSize, DWORD dwArgsBufSize)
{
  char command[MAX_LINE_LENGTH];
  char* tempCommand;
  LPCSTR tempArgs;

  if (cmdBuf)
    cmdBuf[0] = '\0';
  if (argsBuf)
    argsBuf[0] = '\0';
  if (!cmd)
    return;

  VarExpansion(command, cmd);

  tempCommand = new char[MAX_LINE_LENGTH];

  GetToken(command, tempCommand, &tempArgs, true);

  if (cmdBuf)
    StrLCopy(cmdBuf, tempCommand, dwCmdBufSize);
  if (argsBuf)
    StrLCopy(argsBuf, tempArgs, dwArgsBufSize);

  delete[] tempCommand;
}

HINSTANCE LSExecuteEx(HWND Owner, LPCSTR szOperation, LPCSTR szCommand, LPCSTR szArgs, LPCSTR szDirectory, int nShowCmd)
{
  DWORD type;
  SHELLEXECUTEINFO si;
  char *cmd, *args;
  HINSTANCE result;

  if (!StrLen(szCommand))
    return NULL;

  if(*szCommand == '!')
  {
    cmd = new char[StrLen(szCommand) + 1];
    args = new char[StrLen(szArgs) + 1];
    StrCopy(cmd, szCommand);
    StrCopy(args, szArgs);
    result = ParseBangCommand(Owner, cmd, args) ? HINSTANCE(1) : NULL;
    delete[] cmd;
    delete[] args;
    return result;
  }
  else
  {
    type = GetFileAttributes(szCommand);
    if(type & FILE_ATTRIBUTE_DIRECTORY && type != 0xFFFFFFFF)
      return ShellExecute(Owner, szOperation, szCommand, szArgs, NULL, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    else
    {
      memset(&si, 0, sizeof(si));
      si.cbSize = sizeof(SHELLEXECUTEINFO);
      si.hwnd = Owner;
      si.lpVerb = szOperation;
      si.lpFile = szCommand;
      si.lpParameters = szArgs;
      si.lpDirectory = szDirectory;
      si.nShow = nShowCmd;
      si.fMask = SEE_MASK_DOENVSUBST;
      ShellExecuteEx(&si);
      return (HINSTANCE)GetLastError();
    }
  }
}


HINSTANCE LSExecute(HWND Owner, LPCSTR szCommand, int nShowCmd)
{
  char command[MAX_LINE_LENGTH];
  char newCmd[MAX_LINE_LENGTH];
  LPCSTR args;
  char dir[_MAX_DIR];
  char full_directory[_MAX_DIR + _MAX_DRIVE + 1];
  HINSTANCE val = (HINSTANCE)(-1);

  if (!(szCommand && szCommand[0]))
    return 0;

  VarExpansion(command, szCommand);

  if (GetToken(command, newCmd, &args, true))
  {
    if(newCmd[0] == '!')
      val = LSExecuteEx(Owner, NULL, newCmd, args, NULL, 0);
    else
    {
      _splitpath(newCmd, full_directory, dir, NULL, NULL);
      strcat(full_directory, dir);
      val = LSExecuteEx(Owner, "open", newCmd, args, full_directory, nShowCmd ? nShowCmd : SW_SHOWNORMAL);
    }
  }

  return val;
}


void BangExecute(HWND caller, LPCSTR args)
{
  char command[MAX_LINE_LENGTH];
  LPCSTR nextCommand = args;

  if (!StrLen(args))
    return;

  while (GetToken(nextCommand, command, &nextCommand, true))
    LSExecute(caller, command, SW_SHOWDEFAULT);
}


void BangRecycle(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    PostMessage(ls, LM_RECYCLE, 0, 0);
  }
}


void BangUnloadModule(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCSTR nextToken = args;
  char path[MAX_PATH];
  
  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_UNLOADMODULE, (WPARAM)path, 0);
}


void BangReloadModule(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  LPCSTR nextToken = args;
  char path[MAX_PATH];

  if (ls)
    while (GetToken(nextToken, path, &nextToken, false))
      SendMessage(ls, LM_RELOADMODULE, (WPARAM)path, 0);
}


void BangGather(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_BRINGTOFRONT, 1, 0);
}


void BangRun(HWND caller, LPCSTR args)
{
    FARPROC (__stdcall *MSRun)(HWND, int, int, char*, char*, int);

    MSRun = (FARPROC (__stdcall *) (HWND, int, int, char*, char*, int))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3D));
    MSRun(NULL, 0, 0, NULL, NULL, 0);
}


void BangShutdown(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();
    FARPROC (__stdcall *MSWinShutdown)(HWND);

    MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
    MSWinShutdown(ls);
}


void BangLogoff(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 1, 0);
}


void BangQuit(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd ();

  if (ls)
    PostMessage (ls, LM_RECYCLE, 2, 0);
}


void BangToggleWharf(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
    SendMessage(ls, LM_SHADETOGGLE, 0, 0);
}


void BangPopup(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();
  char token0[MAX_LINE_LENGTH], token1[MAX_LINE_LENGTH];
  char* tokens[2];
  POINT p;
  int count = 0;
  tokens[0] = token0;
  tokens[1] = token1;
  token0[0] = token1[0] = '\0';
  if (args)
    count = LCTokenize(args, tokens, 2, NULL);
  if (ls)
  {
    if (GetCursorPos((LPPOINT)&p) == 0)
      p.x = p.y = 0;
    if (count > 1) {
      for (int i = 0; i <= 1; i++)
      {
        if (strnicmp(tokens[i], "X=", 2) == 0)
          p.x = atol(tokens[i] + 2);
        else if (strnicmp(tokens[i], "Y=",2) == 0)
          p.y = atol(tokens[i] + 2);
      }
    }
    SendMessage(ls,LM_HIDEPOPUP,0,0);
    SendMessage(ls,LM_POPUP,p.x,p.y);
  }
}


void BangTileWindowsH(HWND caller, LPCSTR args)
{
  TileWindows(NULL, MDITILE_HORIZONTAL, NULL, 0, NULL);
}


void BangTileWindowsV(HWND caller, LPCSTR args)
{
  TileWindows(NULL, MDITILE_VERTICAL, NULL, 0, NULL);
}


void BangCascadeWindows(HWND caller, LPCSTR args)
{
  CascadeWindows(NULL, MDITILE_SKIPDISABLED, NULL, 0, NULL);
}


void BangMinimizeWindows(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    winList->GetWindowCount(&max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;
      winList->GetWindow(i, (OLE_HANDLE*)&window);
      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsWindowVisible(window))
        continue;
      ShowWindow(window, SW_MINIMIZE);
    }
  }
}


void BangRestoreWindows(HWND caller, LPCSTR args)
{
  HWND ls = GetLitestepWnd();

  if (ls)
  {
    long i, max;
    IWindowList *winList;;

    winList = (IWindowList *)SendMessage(ls, LM_WINDOWLIST, 0, 0);
    winList->GetWindowCount(&max);
    for (i = 0; i < max; i++)
    {
      HWND parent, window;

      winList->GetWindow(i, (OLE_HANDLE*)&window);
      if (GetWindowLong(window, GWL_USERDATA) == magicDWord)
        continue;
      if (GetWindowLong(window, GWL_EXSTYLE) & WS_EX_TOOLWINDOW)
        continue;
      parent = GetParent(window);
      if (GetWindowLong(parent, GWL_USERDATA) == magicDWord)
        continue;
      if (!IsIconic(window))
        continue;
      ShowWindow(window, SW_RESTORE);
    }
  }
}


ULONG WINAPI AboutBoxThread( void * );

void BangAbout( HWND, LPCSTR )
{
	HANDLE threadHandle;
	DWORD threadID;

	threadHandle = CreateThread( NULL,
		0,
		AboutBoxThread,
		NULL,
		0,
		&threadID );

	CloseHandle( threadHandle );
}


void CheckTheme(char *szImage, LPCSTR szFile)
{
  char filename[MAX_PATH];
  ThemePicVector::iterator iter;

  if (PicBuffer.size() && szFile)
  {
    StrCopy(filename, szFile);

    for (iter = PicBuffer.begin(); iter != PicBuffer.end(); iter++)
    {
      if (match((*iter)->program, filename))
      {
        StrCopy(szImage, (*iter)->bitmap);
        return;
      }
    }
  }
}


// Takes strings of the form:
//   File.bmp
//   .extract
//   .extract=file.exe[,3]

HBITMAP LoadLSImage (LPCSTR szImage, LPCSTR szFile) {
  static char szImagesFolder[MAX_PATH] = { '\0' };
  char szImageBuf[MAX_PATH];
  char szImageFinal[MAX_PATH];
  static BOOL bCheckedImagesFolder = FALSE;
  HINSTANCE hInstance;
  HBITMAP   hBitmap;
  HWND    hWnd;

  StrCopy(szImageBuf, szImage);
  if (g_settings->GetThemeFile() != "")
    CheckTheme(szImageBuf, szFile);

  if (!bCheckedImagesFolder)
  {
    // Modified - Maduin, 10-20-1999
    //   Changed to use new API LSGetImagePath rather than
    //   access the step.rc directly.

    LSGetImagePath(szImagesFolder, MAX_PATH);
    bCheckedImagesFolder = TRUE;
  }

  if (!strcmpi(szImageBuf, ".none"))
    return NULL;

  hWnd = GetLitestepWnd();
  if (!hWnd)
    return NULL;

  hInstance = (HINSTANCE) GetWindowLong(hWnd, GWL_HINSTANCE);
  if (!hInstance)
    return NULL;

// Bitmap merging by Thedd
//  Thedd - pic1.bmp|pic2.bmp merges the images. Works recursively,
//  so pic1.bmp|.extract=whatever.dll,3|pic2.bmp also works etc...
// bitmap merging by grd
	if ( strchr (szImageBuf, '|') ) {

		HDC     hdcFirst, hdcSecond, hdcResult;
		HBITMAP hbmFirst, hbmFirstOld;
		HBITMAP hbmSecond, hbmSecondOld;
		HBITMAP	hbmResult, hbmResultOld;
		HBRUSH  hbrTransparent;
		RECT    rc;
		int     wdtFirst, hgtFirst;
		int     wdtSecond, hgtSecond;
		int     wdtResult, hgtResult;
		char    szBuffer1[MAX_PATH+10] = "\0";
		char    szBuffer2[1024] = "\0";
		char   *pipepos;

		// get the position after the [|] character
		pipepos = strchr(szImageBuf, '|');
		pipepos++;

		// copy the text after to szBuffer2
		StrCopy(szBuffer2, pipepos);

		// copy the text before to szBuffer1
		StrLCopy(szBuffer1, szImageBuf, (pipepos - szImageBuf) - 1 ); //StrLen(szImageBuf)-StrLen(szBuffer2)-1);

		// load the two bitmaps
		hbmFirst  = LoadLSImage(szBuffer1, szFile);
		hbmSecond = LoadLSImage(szBuffer2, szFile);

		// if the second one is NULL, then there's no merging to do and
		if (hbmSecond == NULL)
			return hbmFirst;

		// create mem dcs for the bitmaps
		hdcFirst  = CreateCompatibleDC( NULL );
		hdcSecond = CreateCompatibleDC( NULL );

		// select the bitmaps
		hbmFirstOld  = (HBITMAP)SelectObject( hdcFirst,  hbmFirst  );
		hbmSecondOld = (HBITMAP)SelectObject( hdcSecond, hbmSecond );

		// get the bitmap sizes..
		GetLSBitmapSize(hbmFirst, &wdtFirst, &hgtFirst);
		GetLSBitmapSize(hbmSecond, &wdtSecond, &hgtSecond);

		// in earlier version of bitmap merge, those were painted on to each other
		// now let's paint both images to a new one

		// and we support different sized images!! therefore:
		wdtResult = max(wdtFirst,wdtSecond);
		hgtResult = max(hgtFirst,hgtSecond);

		// create another dc, compatible with second dc
		hdcResult = CreateCompatibleDC( hdcSecond );

		// create a new bitmap for the new dc and select it
		hbmResult = CreateCompatibleBitmap( hdcSecond, wdtResult, hgtResult );
		hbmResultOld = (HBITMAP)SelectObject( hdcResult, hbmResult );

		// paint the background in transparent color...
		hbrTransparent = CreateSolidBrush( RGB(255,0,255) );

		rc.top = 0;
		rc.left = 0;
		rc.right = wdtResult;
		rc.bottom = hgtResult;

		FillRect( hdcResult, &rc, hbrTransparent);

		DeleteObject( hbrTransparent );

		// first "standard blit" the second image into the new one:
		BitBlt( hdcResult,(wdtResult-wdtSecond)/2,(hgtResult-hgtSecond)/2,wdtSecond,hgtSecond,hdcSecond,0,0,SRCCOPY );

		// secondly "tranparent blit" the first image over the second one
		TransparentBltLS( hdcResult,(wdtResult-wdtFirst)/2,(hgtResult-hgtFirst)/2,wdtFirst,hgtFirst,hdcFirst,0,0,RGB(255,0,255) );

		// deselect the bitmap from the dc and delete the dc to get the image
		SelectObject(hdcResult, hbmResultOld);
		DeleteDC( hdcResult );

		// delete all used objects
		SelectObject( hdcFirst, hbmFirstOld );
		DeleteObject( hbmFirst );
		DeleteDC( hdcFirst );

		SelectObject( hdcSecond, hbmSecondOld );
		DeleteObject( hbmSecond );
		DeleteDC( hdcSecond );

		return hbmResult;

	}
// end bitmap merging by grd

  if (!strnicmp(szImageBuf, ".extract", StrLen (".extract")))
  {
    char    szBuffer[MAX_PATH+10];  // Leave some overhang for the icon number, if present
    char*   szTemp = NULL;
    int     iIndex = 0;
    HICON   hIcon;

    if (szImageBuf[StrLen(".extract")] == '=')
    {
      StrCopy (szBuffer, szImageBuf + StrLen (".extract="));
      szTemp = strrchr (szBuffer, ',');
    }
    else
    {
      if (!szFile)
        return NULL;

      StrCopy (szBuffer, szFile);
    }

    if (szTemp) // .extract=c:\file.dll,3
    {
      *szTemp = '\0';

      szTemp++;
      iIndex = atoi (szTemp);
    }

    // Now szBuffer is the filename, and iIndex is the index of the icon (zero by default)
    if (iIndex < 0)   // Keep the user from being stupid.
    {
      return NULL;
    }

    if (iIndex > 0)
    {
      int iCount;

      iCount = (int) ExtractIcon (hInstance, szBuffer, 0xffffffff);

      if (iIndex >= iCount) // Is the index out of range?
        return NULL;
    }

    hIcon = ExtractIcon (hInstance, szBuffer, iIndex);

    if (hIcon)
    {
      hBitmap = BitmapFromIcon (hIcon);
      DestroyIcon (hIcon);

      return hBitmap;
    }
  }
  else  // For now, we only support .BMP files
  {
    char szFullPath[MAX_PATH];
    StrCopy (szFullPath, szImagesFolder);

    VarExpansion(szImageFinal, szImageBuf);

    strcat (szFullPath, szImageFinal);

    hBitmap = (HBITMAP) LoadImage
    (
      hInstance,
      szFullPath,
      IMAGE_BITMAP,
      0,
      0,
      LR_DEFAULTCOLOR | LR_LOADFROMFILE
    );

    if (!hBitmap)
    {
      hBitmap = (HBITMAP) LoadImage
      (
        hInstance,
        szImageFinal,
        IMAGE_BITMAP,
        0,
        0,
        LR_DEFAULTCOLOR | LR_LOADFROMFILE
      );
    }
    return hBitmap;
  }

  return NULL;
}


// Creates a 64x64 bitmap of an icon, with pink in the transparent regions.
HBITMAP BitmapFromIcon (HICON hIcon)
{
  ICONINFO info;

  if (GetIconInfo (hIcon, &info))
  {
    HDC   dc;
    HBITMAP hBitmap, oldBMP;
    HBRUSH  hBrush;
    BITMAP  bitmap;

    dc = CreateCompatibleDC (NULL);

    GetObject (info.hbmColor, sizeof (BITMAP), &bitmap);
    hBitmap = CreateBitmapIndirect (&bitmap);
    oldBMP = (HBITMAP)SelectObject(dc, hBitmap);
    hBrush = CreateSolidBrush (RGB (255,0,255));
    DrawIconEx (dc, 0, 0, hIcon, 0, 0, 0, hBrush, DI_NORMAL);
    DeleteObject (hBrush);
    DeleteObject (info.hbmMask);
    DeleteObject (info.hbmColor);
    SelectObject(dc, oldBMP);
    DeleteDC (dc);
    return hBitmap;
  }
  return NULL;
}


// Takes strings of the form:
//   File.ico
//   libary.icl,3 <- libary extraction in imagesfolder
//   c:\path\     <- icon extraction for path out of desktop.ini
//   .extract
//   .extract=file.exe[,3]  ... and returns an icon

HICON LoadLSIcon (LPCSTR szImage, LPCSTR szFile)
{
  static char szImagesFolder[MAX_PATH] = { '\0' };
  char szImageBuf[MAX_PATH];
  char szImageFinal[MAX_PATH];
  char* szTemp;
  int iIndex = 0;

  static BOOL bCheckedImagesFolder = FALSE;
  HINSTANCE hInstance;
  HICON   hIcon;
  HWND    hWnd;

  StrCopy(szImageBuf, szImage);

  if (g_settings->GetThemeFile() != "")
    CheckTheme(szImageBuf, szFile);


  if (!bCheckedImagesFolder)
  {
    // Modified - Maduin, 10-20-1999
    //   Changed to use new API LSGetImagePath rather than
    //   access the step.rc directly.

    LSGetImagePath( szImagesFolder, MAX_PATH );
  }

  if (!strcmpi (szImageBuf, ".none"))
    return NULL;

  hWnd = GetLitestepWnd ();
  if (!hWnd)
    return NULL;

  hInstance = (HINSTANCE) GetWindowLong (hWnd, GWL_HINSTANCE);
  if (!hInstance)
    return NULL;

  szTemp=strrchr(szImageBuf,'\\');
  if ((szTemp)&&(StrLen(szTemp)==1)) // c:\path\ -> desktop.ini
  {
    char szFullPath[MAX_PATH];

    strcat(szImageBuf,"desktop.ini");

    GetPrivateProfileString(".ShellClassInfo","IconIndex","0",szFullPath,MAX_PATH,szImageBuf);
    iIndex=atoi(szFullPath);
    GetPrivateProfileString(".ShellClassInfo","IconFile","",szFullPath,MAX_PATH,szImageBuf);

    hIcon=ExtractIcon (hInstance, szFullPath, iIndex);
    return hIcon;
  }

  if (!strnicmp (szImageBuf, ".extract", StrLen(".extract")))
  {
    char    szBuffer[MAX_PATH+10];  // Leave some overhang for the icon number, if present

    if (szImageBuf[StrLen (".extract")] == '=')
    {
      StrCopy (szBuffer, szImageBuf + StrLen(".extract="));
      szTemp = strrchr (szBuffer, ',');
    }
    else
    {
      if (!szFile)
        return NULL;

      StrCopy (szBuffer, szFile);
    }

    if (szTemp) // .extract=c:\file.dll,3
    {
      *szTemp = '\0';

      szTemp++;
      iIndex = atoi (szTemp);
    }

    // Now szBuffer is the filename, and iIndex is the index of the icon (zero by default)
    if (iIndex < 0)   // Keep the user from being stupid.
      return NULL;

    hIcon = ExtractIcon(hInstance, szBuffer, iIndex);
    if (hIcon)
      return hIcon;
  }
  else
  {
    char szFullPath[MAX_PATH];

    StrCopy(szFullPath, szImagesFolder);
    VarExpansion(szImageFinal, szImageBuf);
    strcat (szFullPath, szImageFinal);

    szTemp = strrchr (szFullPath, ','); // libary.icl,1
    if (szTemp)
    {
      *szTemp = '\0';

      szTemp++;
      iIndex = atoi (szTemp);

      hIcon=ExtractIcon (hInstance, szFullPath, iIndex);
      return hIcon;
    }


    hIcon = (HICON) LoadImage
    (
      hInstance,
      szFullPath,
      IMAGE_ICON,
      0,
      0,
      LR_DEFAULTCOLOR | LR_LOADFROMFILE
    );

    if (!hIcon)
    {
      hIcon = (HICON) LoadImage
      (
        hInstance,
        szImageFinal,
        IMAGE_ICON,
        0,
        0,
        LR_DEFAULTCOLOR | LR_LOADFROMFILE
      );
    }
    return hIcon;
  }

  return NULL;
}


void SetDesktopArea(int left, int top, int right, int bottom) {
  RECT r;

  r.left = left;
  r.top = top;
  r.right = right;
  r.bottom = bottom;
  SystemParametersInfo(SPI_SETWORKAREA, 0, (PVOID)&r, SPIF_SENDCHANGE);
  SystemParametersInfo(SPI_GETWORKAREA, 0, (PVOID)&r, SPIF_SENDCHANGE);
}


void GetLSBitmapSize(HBITMAP hBitmap, int *x, int *y)
{
  BITMAP bm;
  if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
  {
    *x=0;
    *y=0;
  }
  else
  {
    *x = bm.bmWidth;
    *y = bm.bmHeight;
  }
}

void LitestepAPIInit() {
	if (!TransBlt) {
		TransBlt = (TRANSPARENTBLT)GetProcAddress(LoadLibrary("msimg32.dll"), "TransparentBlt");
	}
  
  g_settings = new StepSettings();
}

void TransparentBltLS( HDC dc, int nXDest, int nYDest, int nWidth,
  int nHeight, HDC tempDC, int nXSrc, int nYSrc,
  COLORREF colorTransparent )
{
	if (TransBlt) {
		TransBlt(dc, nXDest, nYDest, nWidth, nHeight, tempDC, nXSrc, nYSrc, nWidth, nHeight, colorTransparent);
	} else {
		HDC locMemDC, maskDC;
		HBITMAP maskBitmap, bmpImage;
		HBITMAP hOldMemBmp, hOldMaskBmp;

		maskDC = CreateCompatibleDC(tempDC);
		locMemDC = CreateCompatibleDC(tempDC);
		bmpImage = CreateCompatibleBitmap(dc, nWidth, nHeight);
		hOldMemBmp = (HBITMAP)SelectObject(locMemDC, bmpImage);
		BitBlt(locMemDC, 0,0,nWidth, nHeight, tempDC, nXSrc, nYSrc, SRCCOPY);
		// Create monochrome bitmap for the mask
		maskBitmap = CreateBitmap(nWidth, nHeight, 1, 1, NULL);
		hOldMaskBmp = (HBITMAP)SelectObject(maskDC, maskBitmap);
		SetBkColor(locMemDC, colorTransparent);
		// Create the mask from the memory DC
		BitBlt(maskDC, 0, 0, nWidth, nHeight, locMemDC, 0, 0, SRCCOPY);
		// Set the background in locMemDC to black. Using SRCPAINT with black
		// and any other color results in the other color, thus making
		// black the transparent color
		SetBkColor(locMemDC, RGB(0,0,0));
		SetTextColor(locMemDC, RGB(255,255,255));
		BitBlt(locMemDC, 0, 0, nWidth, nHeight, maskDC, 0, 0, SRCAND);
		// Set the foreground to black. See comment above.
		SetBkColor(dc, RGB(255,255,255));
		SetTextColor(dc, RGB(0,0,0));
		BitBlt(dc, nXDest, nYDest, nWidth, nHeight, maskDC, 0, 0, SRCAND);
		// Combine the foreground with the background
		BitBlt(dc, nXDest, nYDest, nWidth, nHeight, locMemDC, 0, 0, SRCPAINT);
		SelectObject(maskDC, hOldMaskBmp);
		SelectObject(locMemDC, hOldMemBmp);
		DeleteDC(maskDC);
		DeleteDC(locMemDC);
		DeleteObject(maskBitmap);
		DeleteObject(bmpImage);
		DeleteObject(hOldMemBmp);
		DeleteObject(hOldMaskBmp);
	}
}


HWND GetLitestepWnd()
{
  return FindWindow("TApplication", "LiteStep");
}


void Frame3D(HDC dc, RECT rect, COLORREF TopColor, COLORREF BottomColor, int Width)
{
  HPEN hPen1 = CreatePen(PS_SOLID, 1, TopColor);
  HPEN hPen2 = CreatePen(PS_SOLID, 1, BottomColor);
  HPEN OldPen;
  POINT points[3];

  rect.bottom--;
  rect.right--;

  OldPen = (HPEN)SelectObject(dc, hPen1);

  while (Width > 0)
  {
    POINT p;
    Width--;

    points[0].x = rect.left;
    points[0].y = rect.bottom;
    points[1].x = rect.left;
    points[1].y = rect.top;
    points[2].x = rect.right;
    points[2].y = rect.top;

    Polyline(dc, points, 3);

    SelectObject(dc, hPen2);

    p = points[0];
    points[0] = points[2];
    points[1].x = rect.bottom;
    points[1].y = rect.right;
    points[2] = p;
    points[2].x--;

    Polyline(dc, points, 3);

    SelectObject(dc, hPen1);

    InflateRect(&rect, -1, -1);
  }
  SelectObject(dc, OldPen);
  DeleteObject(hPen1);
  DeleteObject(hPen2);
}


/*----------------------------------------------------------------------------
*
* Return TRUE if PATTERN has is a well formed regular expression according
* to the above syntax
*
* error_type is a return code based on the type of pattern error.  Zero is
* returned in error_type if the pattern is a valid one.  error_type return
* values are as follows:
*
*   PATTERN_VALID - pattern is well formed
*   PATTERN_ESC   - pattern has invalid escape ('\' at end of pattern)
*   PATTERN_RANGE - [..] construct has a no end range in a '-' pair (ie [a-])
*   PATTERN_CLOSE - [..] construct has no end bracket (ie [abc-g )
*   PATTERN_EMPTY - [..] construct is empty (ie [])
*
----------------------------------------------------------------------------*/

BOOL is_valid_pattern (LPCSTR p, LPINT error_type)
{
  /* init error_type */
  *error_type = PATTERN_VALID;

  /* loop through pattern to EOS */
  while (*p)
  {
    /* determine pattern type */
    switch (*p)
    {
      /* check literal escape, it cannot be at end of pattern */
      case '\\':
        if (!*++p)
        {
          *error_type = PATTERN_ESC;
          return FALSE;
        }
        p++;
        break;

      /* the [..] construct must be well formed */
      case '[':
        p++;

        /* if the next character is ']' then bad pattern */
        if (*p == ']')
        {
          *error_type = PATTERN_EMPTY;
           return FALSE;
        }

        /* if end of pattern here then bad pattern */
        if (!*p)
        {
          *error_type = PATTERN_CLOSE;
          return FALSE;
        }

        /* loop to end of [..] construct */
        while (*p != ']')
        {
          /* check for literal escape */
          if (*p == '\\')
          {
            p++;

            /* if end of pattern here then bad pattern */
            if (!*p++)
            {
              *error_type = PATTERN_ESC;
              return FALSE;
            }
          }
          else
            p++;

          /* if end of pattern here then bad pattern */
          if (!*p)
          {
            *error_type = PATTERN_CLOSE;
            return FALSE;
          }

          /* if this a range */
          if (*p == '-')
          {
            /* we must have an end of range */
            if (!*++p || *p == ']')
            {
              *error_type = PATTERN_RANGE;
              return FALSE;
            }
            else
            {
              /* check for literal escape */
              if (*p == '\\')
                    p++;

              /* if end of pattern here
                 then bad pattern           */
              if (!*p++)
              {
                *error_type = PATTERN_ESC;
                return FALSE;
              }
            }
          }
        }
        break;

      /* all other characters are valid pattern elements */
      case '*':
      case '?':
      default:
        p++;                              /* "normal" character */
        break;
    }
  }
  return TRUE;
}


/*----------------------------------------------------------------------------
*
*  Match the pattern PATTERN against the string TEXT;
*
*  returns MATCH_VALID if pattern matches, or an errorcode as follows
*  otherwise:
*
*            MATCH_PATTERN  - bad pattern
*            MATCH_LITERAL  - match failure on literal mismatch
*            MATCH_RANGE    - match failure on [..] construct
*            MATCH_ABORT    - premature end of text string
*            MATCH_END      - premature end of pattern string
*            MATCH_VALID    - valid match
*
*
*  A match means the entire string TEXT is used up in matching.
*
*  In the pattern string:
*       `*' matches any sequence of characters (zero or more)
*       `?' matches any character
*       [SET] matches any character in the specified set,
*       [!SET] or [^SET] matches any character not in the specified set.
*
*  A set is composed of characters or ranges; a range looks like
*  character hyphen character (as in 0-9 or A-Z).  [0-9a-zA-Z_] is the
*  minimal set of characters allowed in the [..] pattern construct.
*  Other characters are allowed (ie. 8 bit characters) if your system
*  will support them.
*
*  To suppress the special syntactic significance of any of `[]*?!^-\',
*  and match the character exactly, precede it with a `\'.
*
----------------------------------------------------------------------------*/

int matche (LPCSTR p, LPCSTR t)
{
  char range_start, range_end;  /* start and end in range */

  BOOL invert;             /* is this [..] or [!..] */
  BOOL member_match;       /* have I matched the [..] construct? */
  BOOL loop;               /* should I terminate? */

  for ( ; *p; p++, t++)
  {
    /* if this is the end of the text
       then this is the end of the match */

    if (!*t)
    {
      return ( *p == '*' && *++p == '\0' ) ?
      MATCH_VALID : MATCH_ABORT;
    }

    /* determine and react to pattern type */

    switch (*p)
    {
      case '?':                     /* single any character match */
        break;

      case '*':                     /* multiple any character match */
        return matche_after_star(p, t);

      /* [..] construct, single member/exclusion character match */
      case '[':
        {
          /* move to beginning of range */
          p++;

          /* check if this is a member match or exclusion match */
          invert = FALSE;
          if (*p == '!' || *p == '^')
          {
            invert = TRUE;
            p++;
          }

          /* if closing bracket here or at range start then we have a
             malformed pattern */
          if (*p == ']')
          {
            return MATCH_PATTERN;
          }

          member_match = FALSE;
          loop = TRUE;

          while (loop)
          {
            /* if end of construct then loop is done */
            if (*p == ']')
            {
              loop = FALSE;
              continue;
            }

            /* matching a '!', '^', '-', '\' or a ']' */
            if (*p == '\\')
              range_start = range_end = *++p;
            else
              range_start = range_end = *p;

            /* if end of pattern then bad pattern (Missing ']') */
            if (!*p)
              return MATCH_PATTERN;

            /* check for range bar */
            if (*++p == '-')
            {
              /* get the range end */
              range_end = *++p;

              /* if end of pattern or construct
                 then bad pattern */
              if (range_end == '\0' || range_end == ']')
                return MATCH_PATTERN;

              /* special character range end */
              if (range_end == '\\')
              {
                range_end = *++p;

                /* if end of text then
                   we have a bad pattern */
                if (!range_end)
                  return MATCH_PATTERN;
              }

              /* move just beyond this range */
              p++;
            }

            /* if the text character is in range then match found.
               make sure the range letters have the proper
               relationship to one another before comparison */

            if (range_start < range_end)
            {
              if (*t >= range_start && *t <= range_end)
              {
                member_match = TRUE;
                loop = FALSE;
              }
            }
            else
            {
              if (*t >= range_end && *t <= range_start)
              {
                member_match = TRUE;
                loop = FALSE;
              }
            }
          }

          /* if there was a match in an exclusion set then no match */
          /* if there was no match in a member set then no match */
          if ((invert && member_match) || !(invert || member_match))
            return MATCH_RANGE;

          /* if this is not an exclusion then skip the rest of
             the [...] construct that already matched. */

          if (member_match)
          {
            while (*p != ']')
            {
              /* bad pattern (Missing ']') */
              if (!*p)
                return MATCH_PATTERN;

              /* skip exact match */
              if (*p == '\\')
              {
                p++;

                /* if end of text then
                   we have a bad pattern */

                if (!*p)
                  return MATCH_PATTERN;
              }

              /* move to next pattern char */

              p++;
            }
          }
          break;
        }
      case '\\':  /* next character is quoted and must match exactly */

        /* move pattern pointer to quoted char and fall through */
        p++;

        /* if end of text then we have a bad pattern */
        if (!*p)
          return MATCH_PATTERN;

        /* must match this character exactly */

      default:
        if (toupper(*p) != toupper(*t))
          return MATCH_LITERAL;
    }
  }

  /* if end of text not reached then the pattern fails */
  if (*t)
    return MATCH_END;
  else
    return MATCH_VALID;
}


/*----------------------------------------------------------------------------
*
* recursively call matche() with final segment of PATTERN and of TEXT.
*
----------------------------------------------------------------------------*/

int matche_after_star (LPCSTR p, LPCSTR t)
{
  int match = 0;
  char nextp;

  /* pass over existing ? and * in pattern */
  while ( *p == '?' || *p == '*' )
  {
    /* take one char for each ? and + */
    if (*p == '?')
    {
      /* if end of text then no match */
      if (!*t++)
        return MATCH_ABORT;
    }

    /* move to next char in pattern */
    p++;
  }

  /* if end of pattern we have matched regardless of text left */

  if (!*p)
    return MATCH_VALID;

  /* get the next character to match which must be a literal or '[' */
  nextp = *p;
  if (nextp == '\\')
  {
    nextp = p[1];

    /* if end of text then we have a bad pattern */
    if (!nextp)
      return MATCH_PATTERN;
  }

  /* Continue until we run out of text or definite result seen */

  do
  {
    /* a precondition for matching is that the next character
       in the pattern match the next character in the text or that
       the next pattern char is the beginning of a range.  Increment
       text pointer as we go here */

    if (tolower(nextp) == tolower(*t) || nextp == '[')
      match = matche(p, t);

    /* if the end of text is reached then no match */
    if (!*t++)
      match = MATCH_ABORT;
  } while ( match != MATCH_VALID &&
    match != MATCH_ABORT &&
    match != MATCH_PATTERN
  );

  /* return result */

  return match;
}


/*----------------------------------------------------------------------------
*
* match() is a shell to matche() to return only BOOL values.
*
----------------------------------------------------------------------------*/

BOOL match(LPCSTR p, LPCSTR t)
{
  int error_type;

  error_type = matche(p,t);
  return (error_type == MATCH_VALID ) ? TRUE : FALSE;
}


// Added - Maduin, 10-20-1999
//   Helper function to retrieve the directory in which
//   LITESTEP.EXE resides.

BOOL WINAPI LSGetLitestepPath( LPTSTR pszPath, UINT nMaxLen )
{
	static TCHAR szPath[MAX_PATH] = "";

	if( !szPath[0] )
	{
		HINSTANCE hInstance;
		int nLen;

		hInstance = (HINSTANCE) GetWindowLong( GetLitestepWnd(), GWL_HINSTANCE );
		GetModuleFileName( hInstance, szPath, MAX_PATH );
		nLen = lstrlen( szPath ) - 1;

		while( nLen > 0 && szPath[nLen] != '\\' )
			nLen--;

		szPath[nLen + 1] = 0;
	}

	lstrcpyn( pszPath, szPath, nMaxLen );
	return TRUE;
}


// Added - Maduin, 10-20-1999
//   Function added to prevent modules from querying
//   for the LSImageFolder (PixmapPath) command using
//   GetRCString directly.

BOOL WINAPI LSGetImagePath( LPTSTR pszPath, UINT nMaxLen )
{
	TCHAR szPath[MAX_PATH] = "";

	if( !GetRCString(TEXT("LSImageFolder"), szPath, TEXT(""), MAX_PATH ) )
	{
		if( !GetRCString( TEXT("PixmapPath"), szPath, TEXT(""), MAX_PATH ) )
		{
			LSGetLitestepPath( szPath, MAX_PATH );

			if( szPath[0] )
				lstrcat( szPath, TEXT("images\\") );
		}
	}

	if( szPath[0] && (szPath[lstrlen( szPath ) - 1] != '\\') )
		lstrcat( szPath, TEXT("\\") );

	lstrcpyn( pszPath, szPath, nMaxLen );
	return szPath[0];
}


/*
  $Log: lsapi.cpp,v $
  Revision 1.53.2.20  2000/08/10 12:46:43  NeXTer
  Improved the unload/reload bangs and added the theme files for lstime2 to
  the release/lstime/ dir

  Revision 1.53.2.19  2000/07/29 04:54:54  headius
  see changes.txt

  Revision 1.53.2.18  2000/07/21 19:11:48  NeXTer
  *** empty log message ***

  Revision 1.53.2.17  2000/06/10 20:09:47  maduin
  Replaced !About

  Revision 1.53.2.16  2000/06/10 19:02:11  headius
  Added TransparentBlt support, LitestepAPIInit function

  Revision 1.53.2.15  2000/06/09 16:04:12  maduin
  *** empty log message ***

  Revision 1.53.2.14  2000/06/09 06:12:51  maduin
  *** empty log message ***

  Revision 1.53.2.13  2000/06/06 20:12:35  maduin
  Fixed bug in LCOpen when szPath was NULL

  Revision 1.53.2.12  2000/06/04 19:53:39  message
  *** empty log message ***

  Revision 1.53.2.11  2000/06/03 23:19:47  headius
  fixing problem with lsopen trying to open "" pass as filename

  Revision 1.53.2.10  2000/05/30 02:02:26  headius
  destroying safearray in parsebangcommand

  Revision 1.53.2.9  2000/05/29 00:56:23  headius
  fixing stdcall/cdecl issues

  Revision 1.53.2.8  2000/05/29 00:00:21  headius
  fixing rc file caching

  Revision 1.53.2.7  2000/05/27 16:52:21  message
  *** empty log message ***

  Revision 1.53.2.6  2000/05/27 00:35:23  headius
  Adding callback bang command definition and wiring bang manger into appropriate functions

  Revision 1.53.2.5  2000/05/25 15:23:43  headius
  see changes.txt

  Revision 1.53.2.3  2000/05/24 16:26:32  headius
  removing neato debug dialogs in lsapi

  Revision 1.53.2.2  2000/05/24 04:24:44  headius
  Added hierarchical caching for rc file config lines

  Revision 1.53.2.1  2000/05/24 03:15:44  headius
  Modified rc file caching to use vector entries in a map, to allow for additional files

  Revision 1.53  2000/05/23 16:10:32  NeXTer
  Misc fixes to LSAPI

  Revision 1.10  2000/03/04 17:09:44  nexter
  *** empty log message ***

  Revision 1.9  2000/03/03 06:16:39  maduin
  *** empty log message ***

  Revision 1.1.1.1  2000/01/28 05:57:37  headius
  Import of Litestep into new cvs

  Revision 1.1  2000/01/21 06:11:45  headius
  C++-ifying lsapi, removal of var-len bangcommand prototype

Revision 1.73  2000/01/18 17:20:23  NeXTer
*** empty log message ***

  Revision 1.43  1999/01/16 02:37:16  bryan
  Variable Expansion extended to the whole of LS.
  
  Revision 1.42  1999/01/08 21:01:17  cyberian
  
  Fixed crash on recycle and loading of startup items
  
  Revision 1.39  1998/11/11 19:55:20  cyberian
  *** empty log message ***
  
 */

