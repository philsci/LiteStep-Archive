/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/****************************************************************************
2000-08-05 / Joachim Calvert (NeXTer)
  - Changed some VC code into more generic API code in the startup code
08/03/00 - Joachim Calvert (NeXTer)
  - Added the ability to pause a recycle by holding the shift key
08/02/00 - Joachim Calvert (NeXTer)
  - Fixed a minor syntax error
  - Added code to prevent the accidental launch of multiple instances
  - Fixed the behavior of the -nostartup switch
  - Implemented support for specifying an arbitrary step.rc on the
    command line (the support was already there, but nonfunctional)
08/01/00 - Charles Oliver Nutter (Headius)
  - Fixed installLitestep bug, backslash between path and Litestep.exe
07/21/00 - Charles Oliver Nutter (Headius)
  - Cleaned up source a bit, removed DoEvents() function
07/21/00 - Joachim Calvert (NeXTer)
  - setupVars() wasn't called soon enough on recycle, so anything that
	  relied on the system variables would cause errors.
06-09-00 - Charles Oliver Nutter (Headius)
  - Added call to LitestepAPIInit, to initialize lsapi.dll
06-03-00 - Bobby G. Vinyard (Message)
  - Removed call causing hookmgr to be unloaded twice
  - Moved code that hides minimized windows  from hook.dll to litestep
05/27/00 - Charles Oliver Nutter (Headius)
  - Reorganized start/stop and reloading of settings to prevent loading them
	  twice initially
05/27/00 - Charles Oliver Nutter (Headius)
  - Added call to clear the bang manager
05/25/00 - Joachim Calvert (NeXTer)
  - Added an ugly clause to enable compilation under BCB.
05/18/00 - Bobby G. Vinyard (Message)
  - Removed litestep call to hookmgr for shell messages
04/13/00 - Bobby G. Vinyard (Message)
  - Added setupBangs() to startup routine
04/08/00 - Bobby G. Vinyard. (Message)
  - Reimplemented !about, !about detailed via void GetRevID();

****************************************************************************/
#pragma warning(disable: 4786)
#include <io.h>
#include <time.h>
#include <tchar.h>
#include <stdio.h>
#include <shlobj.h>
#include <crtdbg.h>
#include <windows.h>
#include <process.h>
#include <winuser.h>

#ifdef __BORLANDC__
  #include <system.hpp>
  #include <wstring.h>
  #define _INC_COMDEF

  #define _bstr_t(pSrc) (BSTR(WideString(pSrc)))
#else
  #include <comdef.h>
#endif


#include <fstream>

#include "litestep.h"
#include "../lsapi/lsapi.h"
#include "wharfdata.h"
#include "StartupRunner.h"
#include "DataStore.h"
#include "LitestepClass.h"
#include "../core/ifcs.h"


// const char rcsRevision[] = "$Revision: 1.22.2.22 $"; // Our Version
const char rcsId[] = "$Id: litestep.cpp,v 1.22.2.22 2000/08/06 01:15:21 NeXTer Exp $"; // The Full RCS ID.
const char LSRev[] = "0.24.5 ";

// Program Options
const LPCTSTR   szMainWindowClass = _T("TApplication");
const LPCTSTR   szMainWindowTitle = _T("LiteStep");

// Paths
CHAR szAppPath[256], szRcPath[256];

// Application instance
HINSTANCE hDLLInstance;

// Run startup items flag
BOOL bRunStartup = TRUE;

// Windows
HWND hMainWindow = NULL;

// Main window procedure
LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

// Show explorer warning? LS is the shell?
BOOL ShowWarning = TRUE, isShell = FALSE;

// Initialize/shutdown manager services
void InitializeManagers();
void ShutdownManagers();

// Read config from step.rc
void ReadConfig (void);

// Parse the command line
void ParseCmdLine(LPSTR lpCmdLine);

// The manager services
DataStore *globalDataStore = NULL;
IMessageManager *globalMsgManager = NULL;
IWindowList *globalWindowList = NULL;
IModuleManager *globalModuleManager = NULL;
IBangManager *globalBangManager = NULL;

ILitestep *globalLitestep = NULL;

// Start up anything that should be started
void start();

// Stop the stuff we started
void stop();

// Shut down litestep
void ShutDown(void);

// We are under explorer? recycling? ending the current session?
BOOL UnderExplorer = FALSE, gRecycle = FALSE, gEndSession = FALSE;

// Skip events (?)
BOOL skipEvents = FALSE;

// Get revision ID's
//HRESULT GetRevId(WPARAM wParam, LPARAM lParam);
void GetRevId(WPARAM wParam, LPARAM lParam);

// Install and Uninstall Routines
void installLitestep(LPCSTR);
void uninstallLitestep();

// Tray data pointer for storage
static trayType *trayData = NULL;

// Undocumented API: Set/Get the shell window, Shutdown windows
FARPROC (__stdcall *SetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *GetShellWindow)(HWND) = NULL;
FARPROC (__stdcall *MSWinShutdown)(HWND) = NULL;

// Some pointers we don't want in the header
int (FAR *initWharfModule)(HWND, HINSTANCE, wharfDataType*);
int (FAR *quitWharfModule)(HINSTANCE);

//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//\//
// Code Starts Here

BOOL FileExists(LPCTSTR szFileName)
{
  HANDLE handle;
  WIN32_FIND_DATA findData;

  handle = FindFirstFile(szFileName, &findData);
  if (handle != INVALID_HANDLE_VALUE)
  {
    FindClose(handle);
    if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
      return TRUE;
  }
  return FALSE;
}

// [Main Litestep Code]
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow) {
	ATOM aClass;
	WNDCLASS wc;
	
	bRunStartup = TRUE;       
	szAppPath[0] = 0;
	hDLLInstance = hInstance;

  // Prevent multiple instances of LiteStep
  CreateMutex(NULL, FALSE, "LiteStep");
  if (GetLastError() == ERROR_ALREADY_EXISTS)
  {
    if (IDNO == MessageBox(
      NULL,
      "A previous instance of LiteStep was detected.\nAre you sure you want to continue?", 
      "LiteStep", 
      MB_TOPMOST | MB_ICONINFORMATION | MB_YESNO | MB_DEFBUTTON2
    ))
      return 0;
  }
	
  // Get undocumented APIs
	SetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "SetShellWindow");
	GetShellWindow = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("USER32.DLL"), "GetShellWindow");
	MSWinShutdown = (FARPROC (__stdcall *)(HWND))GetProcAddress(GetModuleHandle("SHELL32.DLL"), (char*)((long)0x3C));
	
	// Determine our application's path
	if (GetModuleFileName (hDLLInstance, szAppPath, sizeof (szAppPath)) > 0) {
		int len = lstrlen (szAppPath);
		while (len && szAppPath[len-1] != _T('\\')) {
			szAppPath[--len] = _T('\0');
		}
		
		if (len) {
			szAppPath[--len] = _T('\0');
		}
	}
	
	// Parse command line, setting appropriate variables
	ParseCmdLine(lpCmdLine);
  
  // If we can't find "step.rc", there's no point in proceeding
  if (!FileExists(szRcPath))
  {
    char errorMsg[MAX_LINE_LENGTH];

    sprintf(errorMsg, "Unable to find the file \"%s\".\nPlease verify the location of the file, and try again.", szRcPath);
    MessageBox(NULL, errorMsg, "LiteStep", MB_TOPMOST | MB_ICONEXCLAMATION);
    return 0;
  }


	// Initialize OLE/COM
	OleInitialize( NULL );

	// Initalized LitestepAPI
	LitestepAPIInit();
	
	// configure the Win32 window manager to hide windows when they are minimized
	MINIMIZEDMETRICS mm;
	mm.cbSize = sizeof(MINIMIZEDMETRICS);

	SystemParametersInfo( SPI_GETMINIMIZEDMETRICS, mm.cbSize, &mm, 0 );
	
	if( !(mm.iArrange & ARW_HIDE) )
	{
		mm.iArrange |= ARW_HIDE;
		SystemParametersInfo( SPI_SETMINIMIZEDMETRICS, mm.cbSize, &mm, 0 );
	}

	//Setup environment variables
	setupVars(szAppPath);

	// Read config and close the .rc file
	ReadConfig();
	
	// Check for explorer
	if (FindWindow("Shell_TrayWnd", NULL)) { // Running under Exploder
		if (ShowWarning)
			if (MessageBox(0, "You are currently running another shell, while Litestep b24 allows you\012to run under Explorer, we don't advise it for inexperienced users, and we\012will not support it, so do so at your own risk.\012\012If you continue, some of the advanced features of Litestep will be disabled\012such as the desktop. The wharf, hotkeys, and shortcuts will still work.\012\012To get rid of this message next time, put LSNoShellWarning in your step.rc\012\012Continue?", "WARNING", MB_YESNO | MB_ICONEXCLAMATION | MB_TOPMOST) == IDNO)
				exit(0);
			UnderExplorer = TRUE;
	}
	
	// Register Window Class
	memset (&wc, 0, sizeof (wc));
	
	wc.lpfnWndProc = MainWndProc;
	wc.hInstance = hDLLInstance;
	wc.lpszClassName = szMainWindowClass;
	aClass = RegisterClass(&wc);
	if (!aClass) {
		MessageBox(NULL, "Error registering main Litestep window class.", "Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		return 0;
	}

	// Create our main window
	hMainWindow = CreateWindowEx(WS_EX_TOOLWINDOW,
		szMainWindowClass, szMainWindowTitle, 0,
		0, 0, 0, 0, NULL, NULL, hDLLInstance, NULL);
	
	// Start up everything
	if (hMainWindow) {
		MSG message;
		
		// Set magic DWORD to prevent VWM from seeing main window
		SetWindowLong (hMainWindow, GWL_USERDATA, magicDWord);
		
		// Set Shell Window
		if (!UnderExplorer && isShell) SetShellWindow(hMainWindow);

		// init managers
		InitializeManagers();
		
		start();
		
		// Main message pump
		while (GetMessage(&message, 0, 0, 0) > 0) {
			__try {
				TranslateMessage(&message);
				DispatchMessage (&message);
			} __except(1) {
			}
		}
		
		stop();
		
		// Clean up remaining events in message queue
		if (!skipEvents) {
			while (GetMessage (&message, 0, 0, 0) > 0) {
				TranslateMessage(&message);
				DispatchMessage (&message);
			}
		}
		
		// Destroy main window
		DestroyWindow(hMainWindow);
		hMainWindow = NULL;
		
		// Shutdown managers
		ShutdownManagers();
	} else {
		MessageBox(NULL, "Error creating Litestep main application window.", "Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	}
	
	// Unreg class
	UnregisterClass (szMainWindowClass, hDLLInstance);
	
	// Uninitialize OLE/COM
	OleUninitialize();
	
	return 0;
}

void start()
{
	SetBangManager(globalBangManager);

	// Setup bang commands in lsapi
	setupBangs();

	// Load the hook manager
  globalModuleManager->LoadModule(_bstr_t("hookmgr.dll"), 0); // dependency wackiness...we'll put up with it for now.

	// Load modules
	globalModuleManager->LoadModules(NULL);

	// Restore the system tray
	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_RESTORESYSTRAY, &exists);

	if (gRecycle && exists && trayData)
  {
		SendMessage(hMainWindow, LM_RESTORESYSTRAY, 0, (LONG)trayData);
		if (trayData) free(trayData);
	}
	
	// If not recycling, run startup items
	if (!gRecycle)
  {
		// Run startup items if the SHIFT key is not down
		if(!(GetAsyncKeyState(VK_SHIFT) & 0x8000) && bRunStartup)
    {
			_beginthread(StartupRunner::RunStartupStuff, 0, &UnderExplorer);
		}
	}
	gRecycle = FALSE;
	
	SendMessage(GetDesktopWindow(), 0x400, 0, 0); // Undocumented call: Shell Loading Finished
}

void stop() {
	// Save system tray data
	globalModuleManager->QuitModule(_bstr_t("hookmgr.dll")); // dependency wackiness...we'll put up with it for now.

	BOOL exists = FALSE;
	globalMsgManager->HandlerExists(LM_SAVESYSTRAY, &exists);

	if (gRecycle && exists) {
		trayData = (trayType *)calloc(200, sizeof(trayType));
		SendMessage(hMainWindow, LM_SAVESYSTRAY, 0, (LONG)trayData);
	}
	
	// Quit all modules
	globalModuleManager->QuitModules();

	globalBangManager->ClearBangCommands();
	ClearBangManager();
}

void restart() {
	stop();

	CloseRC();

  if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
    MessageBox(NULL, "Recycle has been paused, click OK to continue.", "LiteStep", MB_TOPMOST | MB_ICONINFORMATION);

	setupVars(szAppPath);
	ReadConfig();

	start();
}

LRESULT CALLBACK MainWndProc (HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	switch (uMsg) {
	case WM_KEYDOWN:
		if (wParam == LM_SHUTDOWN) {
			ParseBangCommand(hwnd, "!ShutDown", NULL);
		}
		return 0;
		
	case WM_SYSCOMMAND: 
		switch (wParam) {
		case SC_CLOSE:
			ParseBangCommand(hwnd, "!ShutDown", NULL);
			return 0;
		default:
			return DefWindowProc(hwnd,uMsg,wParam,lParam);
		}
		
	case WM_QUERYENDSESSION:
		return TRUE;
		
	case WM_ENDSESSION:
		gEndSession = TRUE;
		break;
		
	case LM_SAVEDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->StoreData(ident, data, len);
		}
		return 0;
					  }
		
	case LM_RESTOREDATA: {
		WORD ident = HIWORD(wParam);
		WORD len = LOWORD(wParam);
		void * data = (void *) lParam;
		if (globalDataStore) {
			globalDataStore->ReleaseData(ident, data, len);
		}
		return 0;
						 }
		
	case LM_REGISTERMESSAGE: // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->AddMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
		
	case LM_UNREGISTERMESSAGE: // Message Handler Message
		if (globalMsgManager) {
			SAFEARRAY *messages;
			UINT *msgArray = (UINT*)lParam;

			int size = 0;
			for (; msgArray[size] != 0; size++);

			// Create a safe array and populate it
			messages = SafeArrayCreateVector(VT_I4, 0, size);
			SafeArrayAccessData(messages, (void**)&msgArray);
			memcpy(msgArray, (void*)lParam, size * sizeof(UINT));

			globalMsgManager->RemoveMessages((OLE_HANDLE)wParam, messages);

			SafeArrayUnaccessData(messages);
			SafeArrayDestroy(messages);
		}
		break;
		
	case LM_GETLSOBJECT:
		return (LONG) globalLitestep;

	case LM_WINDOWLIST:
		return (LONG)globalWindowList;

	case LM_DATASTORE:
		return (LONG)globalDataStore;
		
	case LM_MESSAGEMANAGER:
		return (LONG) globalMsgManager;

	case LM_RECYCLE:
		if (wParam == 0) {
			gRecycle = TRUE;
			restart();
		} else if (wParam == 1) {
			if (ExitWindowsEx (EWX_LOGOFF, 0)) {
				PostQuitMessage(0);
			}
		} else if (wParam == 2) {
			PostQuitMessage(0);
			skipEvents = TRUE;
		} else {
			ShutDown();
		}
		break;

	case LM_UNLOADMODULE:	{ // Module Handler Message

		LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		break;
	}
		
	case LM_RELOADMODULE:	{ // Module Handler Message
		LPCSTR pszPath = (LPCSTR) wParam;
		WCHAR wszPath[MAX_PATH];

		if( !pszPath || !pszPath[0] )
			break;

		MultiByteToWideChar( CP_ACP,
			MB_PRECOMPOSED,
			pszPath, -1,
			wszPath, MAX_PATH );

		globalModuleManager->QuitModule( wszPath );
		globalModuleManager->LoadModule( wszPath, 0 );
		break;
	}
		
	case LM_BANGCOMMAND: {
		PLMBANGCOMMAND plmbc = (PLMBANGCOMMAND) lParam;

		if( !plmbc )
			return FALSE;
		
		if( plmbc->cbSize != sizeof(LMBANGCOMMAND) )
			return FALSE;
		
		ParseBangCommand( plmbc->hWnd, plmbc->szCommand, plmbc->szArgs );
		return TRUE;
	}
		
	case WM_COPYDATA: {
		PCOPYDATASTRUCT pcds = (PCOPYDATASTRUCT) lParam;
		
		switch( pcds->dwData )
		{
			case LM_BANGCOMMAND:
				
				return SendMessage( hwnd, LM_BANGCOMMAND, 0,
					(LPARAM) pcds->lpData );
		}
		
		return 0;
	}

  case LM_GETREVID: {
    GetRevId(wParam, lParam);
		break;
  }

	default:
		if (globalMsgManager) {
			BOOL exists = FALSE;
			globalMsgManager->HandlerExists(uMsg, &exists);
			
			if (exists) {
				LRESULT lResult;
				globalMsgManager->SendMessage( uMsg, wParam, lParam, &lResult );
				return lResult;
			}
		}
		
		return DefWindowProc (hwnd, uMsg, wParam, lParam);
 }

 return 0;
}


// [Config/Settings Code]
void InitializeManagers(void) {
	globalDataStore = new DataStore();

	HINSTANCE msgMgrLib = ::LoadLibrary("msgmgr.dll");

	if (msgMgrLib == NULL) {
		MessageBox(NULL, "Unable to load msgmgr.dll", "Fatal error", MB_ICONEXCLAMATION | MB_TOPMOST);
		// do something
	}

	IMessageManager *(__stdcall *CreateMessageManager)(void) = (IMessageManager *(__stdcall *)())GetProcAddress(msgMgrLib, "CreateMessageManager");
	globalMsgManager = CreateMessageManager();

	// requires message registration, must come after message manager
	HINSTANCE winListLib = ::LoadLibrary("winlist.dll");

	if (winListLib == NULL) {
		MessageBox(NULL, "Unable to load winlist.dll", "Fatal error", MB_ICONEXCLAMATION | MB_TOPMOST);
		// do something
	}

	IWindowList *(__stdcall *CreateWindowList)(void) = (IWindowList *(__stdcall *)())GetProcAddress(winListLib, "CreateWindowList");
	globalWindowList = CreateWindowList();

	// DLL module manager
	HINSTANCE modManLib = ::LoadLibrary("dllmgr.dll");

	if (modManLib == NULL) {
		MessageBox(NULL, "Unable to load dllmgr.dll", "Fatal error", MB_ICONEXCLAMATION | MB_TOPMOST);
		// do something
	}

	IModuleManager *(__stdcall *CreateModuleManager)(HWND, LPCTSTR) = (IModuleManager *(__stdcall *)(HWND, LPCTSTR))GetProcAddress(modManLib, "CreateModuleManager");
	globalModuleManager = CreateModuleManager(hMainWindow, szAppPath);

	HINSTANCE bangmgr = LoadLibrary("bangmgr.dll");

	if (bangmgr == NULL) {
		MessageBox(NULL, "Unable to load bangmgr.dll", "Fatal error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	} else {
		IBangManager *(__stdcall *CreateBangManager)(void) = (IBangManager *(__stdcall *)())GetProcAddress(bangmgr, "CreateBangManager");
		globalBangManager = CreateBangManager();
	}

	IUnknown *unk = new Litestep();
	unk->QueryInterface(IID_ILitestep, (void**)&globalLitestep);

	globalLitestep->RegisterWindowList(_bstr_t(L"default"), globalWindowList);
	globalLitestep->RegisterMessageManager(_bstr_t(L"default"), globalMsgManager);
	globalLitestep->RegisterModuleManager(_bstr_t(L"default"), globalModuleManager);
	globalLitestep->RegisterBangManager(_bstr_t(L"default"), globalBangManager);
}

void ShutdownManagers() {
	globalLitestep->Release();
	globalLitestep = NULL;

	globalBangManager->Release();
	globalBangManager = NULL;

	globalModuleManager->Release();
	globalModuleManager = NULL;

	globalWindowList->Release();
	globalWindowList = NULL;

	globalMsgManager->Release();
	globalMsgManager = NULL;

	globalDataStore->Clear();
	delete globalDataStore;
	globalDataStore = NULL;
}

void ReadConfig (void) {
	if (SetupRC(szRcPath)) {
		
		// Modified - Maduin, 10-20-1999
		//   Added "ExplorerNoWarn" and "SetAsShell" again to smooth
		//   the transition to the new style. Eventually these should
		//   be removed, but for now backwards compability is a good
		//   thing.
		
		ShowWarning = GetRCBool("LSNoShellWarning", FALSE) && GetRCBool("ExplorerNoWarn", FALSE);
		isShell = GetRCBool("LSSetAsShell", TRUE) || GetRCBool("SetAsShell", TRUE);
	}
}

void ParseCmdLine(LPSTR lpCmdLine)
{
	char token[MAX_PATH];
	LPCTSTR nextToken = lpCmdLine;

  sprintf(szRcPath, "%s\\step.rc", szAppPath);
  while (GetToken(nextToken, token, &nextToken, false))
  {
    if (token[0] == '-')
    {
      if (!stricmp(token, "-nostartup"))
        bRunStartup = FALSE;
      if (!stricmp(token, "-install"))
        installLitestep(szAppPath);
      if (!stricmp(token, "-uninstall"))
        uninstallLitestep();
    }
    else
    {
      if (FileExists(token))
      {
        if (strchr(token, '\\'))
          strcpy(szRcPath, token);
        else
          sprintf(szRcPath, "%s\\%s", szAppPath, token);
      }
    }
  }
}

int ErrorBox( HWND hWnd, LPCTSTR pszText, DWORD dwErrorCode, LPCTSTR pszTitle, UINT nFlags )
{
	TCHAR szMessage[MAX_PATH];
	int nLen;
	
	lstrcpyn(szMessage, pszText, MAX_PATH - 1);
	lstrcat(szMessage, TEXT(" "));
	nLen = lstrlen(szMessage);
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, dwErrorCode,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), szMessage + nLen,
		MAX_PATH - nLen, NULL);
	
	return MessageBox( hWnd, szMessage, pszTitle, nFlags | MB_TOPMOST);
}

void ShutDown(void) {
	
	MSWinShutdown(hMainWindow);
	return;
}

void GetRevId(WPARAM wParam, LPARAM lParam) {
	char buf[256];

	if (wParam == 1) {
    		strcpy(buf, &rcsId[1]);
		buf[strlen(buf)-1] = '\0';
	} else {
		strcpy(buf, "litestep.exe: ");
		strcat(buf, (LPCSTR)&LSRev);
		buf[strlen(buf)-1] = '\0';
	}
  SendMessage((HWND)lParam, LM_GETREVID, 0, (long)buf);
  globalMsgManager->GetRevID(LM_GETREVID, wParam, lParam);
}

void installLitestep(LPCSTR szPath) {
  
  OSVERSIONINFO osInfo;
  // bool setupSucceed; // UNUSED
  
  ZeroMemory(&osInfo, sizeof(osInfo));
  osInfo.dwOSVersionInfoSize = sizeof(osInfo);
  GetVersionEx(&osInfo);
  
  if(MessageBox(NULL, "Do you want to install Litestep as your default shell?", "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES) {
    
    if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) {
      if (MessageBox(NULL, "Would you like to update your Registry with the Shell path?", "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES) {
        char szLs[MAX_PATH], szInf[1024];
        HKEY key;
        DWORD result;

				if (szLs[strlen(szLs) - 1] == '\\') {
					wsprintf(szLs, "%sLitestep.exe\0\0", szPath);
				} else {
					wsprintf(szLs, "%s\\Litestep.exe\0\0", szPath);
				}
        
        wsprintf(szInf, "Install %s for All Users? No will install for Current User (yourself) only", szLs);
        if (MessageBox(NULL, szInf, "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES) {
          // setup reg key for all users
          if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) {
            if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
              MessageBox(NULL, "Installation successful!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
            else
              MessageBox(NULL, "Unable to set registry key!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
            RegCloseKey(key);
          }
          else
            MessageBox(NULL, "Unable to open registry key!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
        } 
        else {
          // setup reg key for current user only
          if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
            NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) {
            if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
              MessageBox(NULL, "Installation successful!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
            else
              MessageBox(NULL, "Unable to set registry key!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
            RegCloseKey(key);
          }
          else
            MessageBox(NULL, "Unable to open registry key!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
        }
      }
    } else	{ // Win9x
      char szWinDir[MAX_PATH], szInf[1024], szLs[MAX_PATH];
      
      GetWindowsDirectory(szWinDir, sizeof(szWinDir));
      strcat(szWinDir, "\\");
      strcat(szWinDir, "SYSTEM.INI");
      wsprintf(szLs, "%sLitestep.exe", szPath);
      
      wsprintf(szInf, "Would you like to update %s with the following\r\n\r\nShell=%s", szWinDir, szLs);
      if (MessageBox(NULL, szInf, "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES) {
        if (WritePrivateProfileString("Boot", "Shell", szLs, szWinDir) != 0)
          MessageBox(NULL, "Installation successful!", "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
        else {
          wsprintf(szInf, "Unable to update %s \n You will need to manually add %s to %s", szWinDir, szLs, szWinDir);
          MessageBox(NULL, szInf, "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
        }
      }
      else {
        wsprintf(szInf, "You will need to manually add %s to %s", szLs, szWinDir);
        MessageBox(NULL, szInf, "LiteStep Installation Complete", MB_OK | MB_TOPMOST);
      }
    }
  }
}

void uninstallLitestep() {

  OSVERSIONINFO osInfo;
  // bool setupSucceed; // UNUSED

  ZeroMemory(&osInfo, sizeof(osInfo));
  osInfo.dwOSVersionInfoSize = sizeof(osInfo);
  GetVersionEx(&osInfo);
  
  if(MessageBox(NULL, "Do you want to uninstall Litestep?", "LiteStep Installation", MB_YESNO | MB_TOPMOST) == IDYES) {
    
    if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) {
      char szLs[MAX_PATH], szInf[1024];
      HKEY key;
      DWORD result;
      
      GetWindowsDirectory(szInf, MAX_PATH);
      
      wsprintf(szLs, "%s\\explorer.exe\0\0", szInf);
      
      wsprintf(szInf, "Install %s for All Users? No will install for Current User (yourself) only", szLs);
      if (MessageBox(NULL, szInf, "LiteStep Uninstallation", MB_YESNO | MB_TOPMOST) == IDYES) {
        // setup reg key for all users
        if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
          NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) {
          if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            MessageBox(NULL, "Uninstallation successful, you may now safely delete the Litestep Directory.", "LiteStep Uninstallation Complete", MB_OK | MB_TOPMOST);
          else
            MessageBox(NULL, "Unable to set registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
          RegCloseKey(key);
        }
        else
          MessageBox(NULL, "Unable to open registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK);
      } 
      else {
        // setup reg key for current user only
        if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\0", 0,
          NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &result) == ERROR_SUCCESS) {
          if (RegSetValueEx(key, "Shell\0", 0, REG_SZ, (const unsigned char*)szLs, lstrlen(szLs)+1) == ERROR_SUCCESS)
            MessageBox(NULL, "Uninstallation successful, ensure no other users are using Litestep before deleting the Litestep directory.", "LiteStep Uinstallation Complete", MB_OK | MB_TOPMOST);
          else
            MessageBox(NULL, "Unable to set registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
          RegCloseKey(key);
        }
        else
          MessageBox(NULL, "Unable to open registry key!", "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
      }
    }
  } else	{ // Win9x
    char szWinDir[MAX_PATH], szInf[1024], szLs[MAX_PATH];
    
    GetWindowsDirectory(szWinDir, sizeof(szWinDir));
    strcat(szWinDir, "\\");
    wsprintf(szLs, "%sexplorer.exe", szWinDir);
    strcat(szWinDir, "SYSTEM.INI");
    
    
    wsprintf(szInf, "Would you like to update %s with the following\r\n\r\nShell=%s", szWinDir, szLs);
    if (MessageBox(NULL, szInf, "LiteStep Uninstallation", MB_YESNO | MB_TOPMOST) == IDYES) {
      if (WritePrivateProfileString("Boot", "Shell", szLs, szWinDir) != 0)
        MessageBox(NULL, "Uninstallation successful, you may now safely delete the Litestep Directory", "LiteStep Uninstallation Complete", MB_OK | MB_TOPMOST);
      else {
        wsprintf(szInf, "Unable to update %s \n You will need to manually add %s to %s", szWinDir, szLs, szWinDir);
        MessageBox(NULL, szInf, "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
      }
    }
    else {
      wsprintf(szInf, "You will need to manually add %s to %s", szLs, szWinDir);
      MessageBox(NULL, szInf, "LiteStep Uninstallation Did Not Complete", MB_OK | MB_TOPMOST);
    }
  } 
}


