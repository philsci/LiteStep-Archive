/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 Francis Gastellu
                    aka Lone Runner/Aegis

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

/****************************************************************************

 06/03/98 - F. Gastellu
            This file contains the source code for the Desktop-ScreenSaver
            module

****************************************************************************/

#include <windows.h>
#include <stdio.h>
#include "baksaver.h"

HWND desktop = NULL;

// -------------------------------------------------------------------------------------------------------
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
char param[261];
desktop = FindWindow("DesktopBackgroundClass", NULL);
if (!desktop)
	{
	MessageBox(ParentWnd, "Could not locate desktop!", "Background ScreenSaver - Error", 0);
	return 1;
	}
if (! *wd->backsaver)
	{
	MessageBox(ParentWnd, "No ScreenSaver specified, use BackScreenSaver in step.rc", "Background ScreenSaver - Error", 0);
	return 1;
	}										   

// Here is the trick: the /P parameter passed to a screensaver make it run
// inside a child window rather than inside the entire desktop window.
// This is used by windows for the preview mode in the control panel.
// So what we just do is pass it the window handle of our desktop with
// the /P parameter, so the screen saver thinks it is running in preview mode.
// Fortunatly in preview mode, mouse moves & keypresses don't stop the process
// Unfortunatly, not all screen savers support prevew mode

sprintf(param, "%s /P %d", wd->backsaver, (int)desktop);
WinExec(param, SW_SHOWNORMAL);

return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quitModule(HINSTANCE dllInst)
{
// WM_DESTROY is automatically sent to desktop's childs upon destoywindow(desktop)
}
