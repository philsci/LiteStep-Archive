/*********************************************************************/
/*                                                                   */
/* LiteSTEP MAIL Checker - By MrJukes & F. Gastellu                  */
/*                                                                   */
/**********************************************************************

 05/05/98 - MrJukes
            First implementation of a mail checker (LsNotify)

 05/20/98 - F. Gastellu
            Rewrite of the original version to allow more options

 06/10/98 - MrJukes
            Added up to 3 pop accounts
			Added popup alert box

 06/10/98 - F. Gastellu
            3 tiny bugfixes

 06/11/98 - Release 3 let out upon the world
		MrJukes
		LSMail Settings Editor included
		Added Reload Settings Popup
		Fixed launch e-mail client to reset animation
		Added Alert Box toggle to pop-up menu
			


****************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <direct.h>
#include <string.h>
#include <time.h>
#include <process.h>
#include "LSMail.h"

#define ANIM_STANDBY			0
#define ANIM_CHECKINPROGRESS	1
#define ANIM_MAILAVAILABLE		2

#define MINUTE 60000

/* ----------------------------------------------------------------- */
char szAppName[] = "LsMail"; // Name of Application, Window class...

typedef struct {
	HDC *DC;
	HBITMAP *BMP, *oldBMP;
	int x,y;
	} ImgListType;

// window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
ImgListType *LoadAnimation(int *nFrames, int *speed, char *IntName, char *BmpName, char *SpeedName);
void GetBitmapSize(HBITMAP hBitmap, int *x, int *y);
void setAnim(int anim, int first);
void LoadSetup(void);
int do_pop(void);
int closeup(int err);

HWND hMainWnd;                    // main window handle
HWND parent;                      // parent window
wharfDataType wharfData;          // Setup data passed to the DLL
int wndSize;                      // Size of the wharf client
HINSTANCE Instance;


ImgListType *MailImgList=NULL;
int nMail;
int MailAnimSpeed;
ImgListType *NoMailImgList=NULL;
int nNoMail;
int NoMailAnimSpeed;

int nSounds;
char **wave;

int alertbox;

ImgListType *curAnim;
int *curNFrames;
int animPtr=0;
BOOL animBlocked=TRUE;
int timeout=1;

int pencolor[3], nX[3], nY[3];

ImgListType NoMail;

int PopPort[3];
char PopServer[3][128]={"","",""};
char PopUser[3][128]={"","",""};
char PopPass[3][128]={"","",""};
char MailClient[256]="";
BOOL soundonnew=TRUE;

int socketinit=0;
int wsainit;
SOCKET mysocket;

int nMessages[3];
int MsgBase[3] = {0,0,0};
int one=1;
HANDLE thread=NULL;

HMENU Popup;

int error=0;
int showerror=1;
int waveCount=0;

int autoflagoff=1;

char ini[_MAX_PATH];
char lsmse[_MAX_PATH];

/*********************************************************************/
/* DLL Entry point                                                   */
/*********************************************************************/
int initWharfModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType *wd)
{
	time_t t;
    parent = ParentWnd; // Save parent window
    // Duplicate wharfData since the one we get will be destroyed
    memcpy(&wharfData, wd, sizeof(wharfDataType));
    wndSize = 64-wharfData.borderSize*2;
	Instance = dllInst;

	MailImgList = LoadAnimation(&nMail, &MailAnimSpeed, "NMailPresent", "MailPresentBase", "MailPresentDelay");
	NoMailImgList = LoadAnimation(&nNoMail, &NoMailAnimSpeed, "NMailChecking", "MailCheckingBase", "MailCheckingDelay");
	LoadSetup();

	curAnim = NoMailImgList;
	curNFrames = &nNoMail;
	animPtr=0;
	animBlocked=TRUE;

	time(&t);
	srand((int)t);

	Popup = CreatePopupMenu();
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 100, "&Check Mail Now");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 101, "&Launch E-Mail Client");
    AppendMenu(Popup, MF_ENABLED | MF_STRING, 102, "&Put Flag Down");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 106, "&Edit Settings");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 107, "&Reload Settings");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 103, "&About LSMail");
	AppendMenu(Popup, MF_SEPARATOR, 104, "");
	AppendMenu(Popup, MF_ENABLED | MF_STRING, 105, "Alert &Box");

	if (alertbox)
	{
		CheckMenuItem(Popup, 105, MF_CHECKED);
	}


    {    // Register the Window class
        WNDCLASS wc;

        memset(&wc,0,sizeof(wc));
        wc.lpfnWndProc = WndProc;       // our window procedure
        wc.hInstance = dllInst;         // hInstance of DLL
        wc.lpszClassName = szAppName;   // our window class name
		wc.style = CS_DBLCLKS;

        if (!RegisterClass(&wc)) 
        {
            MessageBox(parent,"Error registering window class",szAppName, MB_OK);
            return 1;
        }
    }


    hMainWnd = CreateWindowEx(
        WS_EX_TRANSPARENT,                          // exstyles 
        szAppName,                                  // our window class name
        szAppName,                                  // use description for a window title
        WS_CHILD,                                   // window style
        wharfData.borderSize, wharfData.borderSize, // position 
        wndSize,wndSize,                            // width & height of window
        parent,                                     // parent window (litestep wharf window)
        NULL,                                       // no menu
        dllInst,                                    // hInstance of DLL
        0);                                         // no window creation data

    if (!hMainWnd) 
    {						   
        MessageBox(parent,"Error creating window",szAppName,MB_OK);
        return 1;
    }

    // Set normal cursor
    SetCursor(LoadCursor(NULL,MAKEINTRESOURCE(IDC_ARROW)));
	
    // DO NOT REMOVE ! Set magicDWord - required!
    // Used by some modules & litestep internals
    SetWindowLong(hMainWnd,GWL_USERDATA,magicDWord); 

    // show the window
    ShowWindow(hMainWnd,SW_SHOWNORMAL);
	setAnim(ANIM_STANDBY, 1);
	SendMessage(hMainWnd, WM_TIMER, 1, 0);
	SetTimer(hMainWnd, 1, timeout, NULL);

    return 0;
}

/*********************************************************************/
/* Dll closeup request                                               */
/*********************************************************************/
void quitWharfModule(HINSTANCE dllInst)
{
int a;

KillTimer(hMainWnd, 1);
KillTimer(hMainWnd, 0);

if (thread)
	{
	closeup(2);	// Should cause the thread to exit 
	Sleep(1000);
	if (thread)
		{ // if it is still alive, try to kill it
		TerminateThread(thread, 0);
		Sleep(1000);
		}
	}

for (a=0;a<nMail;a++)
	{
	SelectObject(MailImgList[a].DC, MailImgList[a].oldBMP);
	DeleteObject(MailImgList[a].BMP);
	DeleteDC(MailImgList[a].DC);
	} 
for (a=0;a<nNoMail;a++)
	{
	SelectObject(NoMailImgList[a].DC, NoMailImgList[a].oldBMP);
	DeleteObject(NoMailImgList[a].BMP);
	DeleteDC(NoMailImgList[a].DC);
	} 

for (a=0;a<nSounds;a++)
	free(wave[a]);

free(wave);

SelectObject(NoMail.DC, NoMail.oldBMP);
DeleteObject(NoMail.BMP);
DeleteDC(NoMail.DC);

DestroyWindow(hMainWnd);                // delete our window
UnregisterClass(szAppName, dllInst);    // unregister window class
}


/*********************************************************************/
/* Window procedure for our window                                   */
/*********************************************************************/
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int loop=0;
	switch (message)
    {
        case WM_CREATE:		return 0;
        case WM_ERASEBKGND: return 0;
        case WM_PAINT:
			{ 
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd,&ps);

				if (animPtr >= *curNFrames) animPtr = 0;

				if (curAnim)
					{
					BitBlt(hdc, (64-wharfData.borderSize*2-curAnim[animPtr].x)/2,
					      		(64-wharfData.borderSize*2-curAnim[animPtr].y)/2,
								curAnim[animPtr].x, curAnim[animPtr].y,
								curAnim[animPtr].DC,
								0, 0, SRCCOPY);
					}
				for (loop=0;loop<3;loop++)
				{
					// Do we need *nMessages?
				if (nMessages[loop] && curAnim != &NoMail)
					{
					HFONT hf,oldFont;
					char tmp[10];
					
					sprintf(tmp, "%d", nMessages[loop]);

					hf = GetStockObject(ANSI_FIXED_FONT); 
					oldFont = SelectObject(hdc, hf); 
					SetBkMode(hdc, TRANSPARENT);
					SetTextColor(hdc, pencolor[loop]);
					
					TextOut( hdc, nX[loop], nY[loop], tmp, strlen(tmp)); 

					SelectObject(hdc, oldFont);
					}

				if (error && showerror)
					{
					RECT r;
					HPEN oldp, red = CreatePen(PS_SOLID, 1, 0x0000FF);
					
					oldp = SelectObject(hdc, red);

					GetClientRect(hwnd,&r);
					MoveToEx(hdc, 0, 0, NULL);
					LineTo(hdc, wndSize-1, wndSize-1);
					MoveToEx(hdc, 0, wndSize-1, NULL);
					LineTo(hdc, wndSize-1, 0);

					SelectObject(hdc, oldp);
					DeleteObject(red);

					}
                }
                EndPaint(hwnd,&ps);
			}
            return 0;
        case WM_KEYDOWN:    // forward keyboard messages to parent window 
        case WM_KEYUP:
            PostMessage(parent,message,wParam,lParam);
            return 0;
	// Mouse messages are here to ensure we have a good popup menu behaviour. You may insert
        // your own custom actions
        case WM_RBUTTONUP:
                {
                RECT r;
                GetWindowRect(hwnd, &r);
                PostMessage(GetParent(GetParent(parent)), 9182, r.top+(int)HIWORD(lParam), r.left+(int)LOWORD(lParam));
                }
            return 0;
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            PostMessage(GetParent(GetParent(parent)), 9183, 0, 0);
            return 0;
        case WM_RBUTTONDOWN:
			{
			DWORD dw = GetMessagePos();
			TrackPopupMenu(Popup, TPM_RIGHTALIGN | TPM_RIGHTBUTTON, LOWORD(dw), HIWORD(dw), 0, hMainWnd, NULL);
			return 0;
			}
		case WM_TIMER:
			if (wParam)
				{ // Check mail
				if (!thread)
					CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)do_pop, (LPVOID)hwnd, 0, &(int)thread);
				}
			else
				if (!animBlocked)
					{
					RECT r;
					GetClientRect(hMainWnd, &r);
					InvalidateRect(hMainWnd, &r, TRUE);
					animPtr++;
					animPtr %= *curNFrames;
					}
			return 0;
		case WM_LBUTTONDBLCLK:
			if (autoflagoff)
				{
				SendMessage(hMainWnd, WM_COMMAND, 102, 0);
				//MsgBase[0]=MsgBase[1]=MsgBase[2]=0;
				//nMessages[0]=nMessages[1]=nMessages[2]=0;
				}
			WinExec(MailClient, SW_SHOWNORMAL);
			return 0;
		case WM_COMMAND:
			switch(wParam)
				{
				case 100:
					if (!thread)
						CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)do_pop, (LPVOID)hwnd, 0, &(int)thread);
					break;
				case 101:
					if (autoflagoff)
						{
						SendMessage(hMainWnd, WM_COMMAND, 102, 0);
						//MsgBase[0]=MsgBase[1]=MsgBase[2]=0;
						//nMessages[0]=nMessages[1]=nMessages[2]=0;
						}
					WinExec(MailClient, SW_SHOWNORMAL);
					break;
				case 102:
					if (thread)
						{
						TerminateThread(thread, 0);
						closeup(0);
						}
					MsgBase[0] = nMessages[0];
					MsgBase[1] = nMessages[1];
					MsgBase[2] = nMessages[2];
					setAnim(ANIM_STANDBY, 0);
					break;
				case 103:
					MessageBox(0,"LSMail: By LoneRunnr & MrJukes\n-  Thanks to: Nerraw, Floach, MHolmesIV, and all of #Litestep\n-  Email me at: mrjukes@purdue.edu","LSMail Version 1 R3", MB_OK | MB_ICONINFORMATION | MB_SETFOREGROUND );
					break;
				case 105:
					if (alertbox)
					{
						alertbox=0;
						WritePrivateProfileString("LSMail", "AlertBox", "0", ini);
						CheckMenuItem(Popup, 105, MF_UNCHECKED);
					}
					else
					{
						alertbox=1;
						WritePrivateProfileString("LSMail", "AlertBox", "1", ini);
						CheckMenuItem(Popup, 105, MF_CHECKED);
					}
					break;
				case 106:
					WinExec(lsmse, SW_SHOWNORMAL);
					break;
				case 107:
					LoadSetup();
				}
			return 0;
    }
    return DefWindowProc(hwnd,message,wParam,lParam);
}



/*********************************************************************/
/* Load Animation                                                    */
/*********************************************************************/
ImgListType *LoadAnimation(int *nFrames, int *speed, char *IntName, char *BmpName, char *SpeedName)
{
char BaseName[_MAX_PATH+1];
char curName[_MAX_PATH+1];
ImgListType *Ptr;
int a;
int x, y;

char ini[_MAX_PATH];
char drive[_MAX_DRIVE];
char dir[_MAX_DIR];

_splitpath( wharfData.lsPath, drive, dir, NULL, NULL );
_makepath( ini, drive, dir, "MODULES", ".INI" );

*nFrames = GetPrivateProfileInt("LSMail", IntName, 0, ini);
*speed = GetPrivateProfileInt("LSMail", SpeedName, 250, ini);
if (!*speed) *speed=250;
if (!*nFrames) *nFrames = 1;
GetPrivateProfileString("LSMail", BmpName, "", BaseName, _MAX_PATH, ini);

Ptr = (ImgListType *)malloc(sizeof(ImgListType) * *nFrames);

for (a=0;a<*nFrames;a++)
	{
	Ptr[a].DC = CreateCompatibleDC(NULL);
	sprintf(curName, "%s%02d.BMP", BaseName, a+1);
	Ptr[a].BMP = LoadImage(Instance, curName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
	Ptr[a].oldBMP = SelectObject(Ptr[a].DC, Ptr[a].BMP);
	GetBitmapSize(Ptr[a].BMP, &x, &y);
	Ptr[a].x = x;
	Ptr[a].y = y;
	} 

return Ptr;
}

/*********************************************************************/
/* Get Bitmap Size                                                   */
/*********************************************************************/
void GetBitmapSize(HBITMAP hBitmap, int *x, int *y)
{
BITMAP bm;
if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
	{
	*x=0;
	*y=0;
	}
else
	{
	*x = bm.bmWidth;
	*y = bm.bmHeight;
	}
}


/*********************************************************************/
/* Set Animation                                                     */
/*********************************************************************/
void setAnim(int anim, int first)
{
RECT r;

switch (anim)
	{
	case ANIM_STANDBY:
		if (curAnim != &NoMail)
			{
			if (!first)
				KillTimer(hMainWnd, 0);
			curAnim = &NoMail;
			curNFrames = &one;
			animPtr=0;
			animBlocked=TRUE;
			SetTimer(hMainWnd, 0, 1000, NULL);
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			}
		break;
	case ANIM_CHECKINPROGRESS:
		if (curAnim != NoMailImgList)
			{
			if (!first)
				KillTimer(hMainWnd, 0);
			curAnim = NoMailImgList;
			curNFrames = &nNoMail;
			animPtr=0;
			animBlocked=FALSE;
			SetTimer(hMainWnd, 0, NoMailAnimSpeed, NULL);
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			}
		break;
	case ANIM_MAILAVAILABLE:
		if (curAnim != MailImgList)
			{
			if (!first)
				KillTimer(hMainWnd, 0);
			curAnim = MailImgList;
			curNFrames = &nMail;
			animPtr=0;
			animBlocked=FALSE;
			SetTimer(hMainWnd, 0, MailAnimSpeed, NULL);
			GetClientRect(hMainWnd, &r);
			InvalidateRect(hMainWnd, &r, TRUE);
			}
		break;
	}

}


/*********************************************************************/
/* Load Setup                                                        */
/*********************************************************************/
void LoadSetup(void)
{
char drive[_MAX_DRIVE];
char dir[_MAX_DIR];
char BaseName[_MAX_PATH+1];
int a;

_splitpath( wharfData.lsPath, drive, dir, NULL, NULL );
_makepath( ini, drive, dir, "MODULES", ".INI" );
_makepath( lsmse, drive, dir, "lsmse", ".exe" );

// Prepare win.ini for LSMail Settings Editor
WriteProfileSection("LSMail",NULL);
WriteProfileString("LSMail","Location",ini);
// End preparation

timeout = GetPrivateProfileInt("LSMail", "CheckDelay", 10, ini)*MINUTE;
showerror = GetPrivateProfileInt("LSMail", "ShowError", 1, ini);
autoflagoff = GetPrivateProfileInt("LSMail", "AutoFlagOff", 1, ini);
alertbox = GetPrivateProfileInt("LSMail", "AlertBox", 1, ini);

for (a=0;a<3;a++)
{
sprintf(BaseName, "Pop_Port_%d", a+1);
PopPort[a] = GetPrivateProfileInt("LSMail", BaseName, 110, ini);

sprintf(BaseName, "Pop_Server_%d", a+1);
GetPrivateProfileString("LSMail", BaseName, NULL, PopServer[a], 127, ini);

sprintf(BaseName, "Pop_User_%d", a+1);
GetPrivateProfileString("LSMail", BaseName, NULL, PopUser[a], 127, ini);

sprintf(BaseName, "Pop_Password_%d", a+1);
GetPrivateProfileString("LSMail", BaseName, NULL, PopPass[a], 127, ini);

sprintf(BaseName, "PenX_%d", a+1);
nX[a] = GetPrivateProfileInt("LSMail", BaseName, 10, ini);

sprintf(BaseName, "PenY_%d", a+1);
nY[a] = GetPrivateProfileInt("LSMail", BaseName, 50, ini);

sprintf(BaseName, "PenColor_%d", a+1);
pencolor[a] = GetPrivateProfileInt("LSMail", BaseName, 0xFFFFFF, ini);
}

GetPrivateProfileString("LSMail", "MailClient", "eudora.exe", MailClient, 255, ini);
nSounds = GetPrivateProfileInt("LSMail", "nSounds", 50, ini);
wave = (char **)malloc(sizeof(char *) * nSounds);

for (a=0;a<nSounds;a++)
	{
	sprintf(BaseName, "Sound%d", a+1);
	wave[a] = (char *)malloc(_MAX_PATH+1);
	GetPrivateProfileString("LSMail", BaseName, "", wave[a], _MAX_PATH, ini);
	}					   

NoMail.DC = CreateCompatibleDC(NULL);
GetPrivateProfileString("LSMail", "NoMail", "NoMail.BMP", BaseName, _MAX_PATH, ini);
NoMail.BMP = LoadImage(Instance, BaseName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
NoMail.oldBMP = SelectObject(NoMail.DC, NoMail.BMP);
GetBitmapSize(NoMail.BMP, &NoMail.x, &NoMail.y);
}


/*********************************************************************/
/* Check Mail                                                        */
/*********************************************************************/
int do_pop(void)
{
WORD wVersionRequested; 
WSADATA wsaData; 
struct in_addr addr;
struct sockaddr_in myaddr;
int err; 
int on = 1;
int loop = 0, reply = 0;
struct hostent *host;
char data[512];
char temp[256];
int oldnmsg[3]= {nMessages[0],nMessages[1],nMessages[2]};

for (loop=0; loop < 3; loop++)
{
	error=0;

	if (curAnim == &NoMail)
		setAnim(ANIM_CHECKINPROGRESS, 0);
 
	wVersionRequested = MAKEWORD(1, 1); 
	memset(&wsaData, 0, sizeof(wsaData));
	err = WSAStartup(wVersionRequested, &wsaData); 

	if (err != 0) 						 
		return closeup(1);

	wsainit=1;
 
	if ( LOBYTE( wsaData.wVersion ) != 1 || 
		    HIBYTE( wsaData.wVersion ) != 1 ) { 
		return closeup(1);
		}

	// Loop for all accounts

	if (!*PopServer[loop])
	{
		return closeup(0);
	}

	mysocket = socket(PF_INET, SOCK_STREAM, 0);
	memset((void *)&myaddr, 0, sizeof(myaddr));
	myaddr.sin_family = AF_INET;
	myaddr.sin_port = htons((short)PopPort[loop]);

	socketinit=1;
      
	addr.s_addr = inet_addr (PopServer[loop]);
	if (addr.s_addr == INADDR_NONE)
		{
		host = gethostbyname (PopServer[loop]);
		if (host == NULL)
			return closeup(1);
		else
			memcpy((char *) &addr, host->h_addr, host->h_length);
		}
										
	myaddr.sin_addr = addr;

	if (connect(mysocket, (struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR) 
		return closeup(1);

	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR) 
		return closeup(1);

	if (strnicmp(data, "+OK", 3))
		return closeup(1);

	sprintf(data, "USER %s\r\n", PopUser[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR) 
		return closeup(1);

	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR) 
		return closeup(1);

	if (strnicmp(data, "+OK", 3))
		return closeup(1);

	sprintf(data, "PASS %s\r\n", PopPass[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR) 
		return closeup(1);

	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR) 
		return closeup(1);

	if (strnicmp(data, "+OK", 3))
		return closeup(1);

	sprintf(data, "STAT\r\n", PopPass[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR) 
		return closeup(1);

	if (recv(mysocket, data, 512, 0) == SOCKET_ERROR) 
		return closeup(1);

	if (strnicmp(data, "+OK", 3))
		return closeup(1);

	sscanf(data, "+OK %d", &nMessages[loop]);

	sprintf(data, "QUIT\r\n", PopPass[loop]);
	if (send(mysocket, data, strlen(data), 0) == SOCKET_ERROR) 
		return closeup(0);

	if (loop < 2 && *PopServer[loop+1]) // replace 2 by number of alloc'd strings - 1 if you want to use unlimited accounts
		// close the socket since it's re-allocated at next loop
		closesocket(mysocket);

	// Nicer than random (i think ;)
	if (oldnmsg[loop] < nMessages[loop] || (oldnmsg[loop] == nMessages[loop] && !soundonnew))
		if (*wave)
			{
			sndPlaySound(wave[waveCount++], SND_ASYNC|SND_NODEFAULT); 
			waveCount%=nSounds;
			}

	if (oldnmsg[loop] < nMessages[loop] && alertbox)
	{
		sprintf(temp,"You have %d new messages on %s\nWould you like to launch your e-mail client?",nMessages[loop]-oldnmsg[loop],PopServer);
		reply = MessageBox(0,temp,"New Mail Has Arrived", MB_YESNO | MB_DEFBUTTON2 | MB_ICONQUESTION | MB_SETFOREGROUND);
		if ( reply == IDYES ) 
		{
			SendMessage(hMainWnd, WM_COMMAND, 101, 0);
		}
	}
closeup(0);
}
return(0);
}

/*********************************************************************/
/* Close TCP connection                                              */
/*********************************************************************/
int closeup(int err)
{
if (socketinit)
	closesocket(mysocket);

WSACleanup();

if (nMessages[0] > MsgBase[0] || nMessages[1] > MsgBase[1] || nMessages[2] > MsgBase[2])
	setAnim(ANIM_MAILAVAILABLE, 0);
else
	setAnim(ANIM_STANDBY, 0);

error = (err == 1) ? 1 : 0;
if (err != 2) thread=NULL;
return 0;
}
