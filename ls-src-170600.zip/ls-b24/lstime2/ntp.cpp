/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
05-21-00 Bobby G. Vinyard (Message)
  - Setup dialog is now displaying (code in this module could still use some
     cleaning)
05-19-00 Bobby G. Vinyard (Message)
  - First write of the ntpclient class (setup dialog doesnt display, but Ntp
     syncronization works)
****************************************************************************/
#include "resource.h"
#include "ntpfrac.h"
#include "ntp.h"

#include "ntp.h"
const char szAppName[] = "NtpClient"; // Our window class, etc
NtpClient *ntpclient; // The module

INT_PTR CALLBACK DlgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
//---------------------------------------------------------
// Module constructor
//---------------------------------------------------------
NtpClient::NtpClient(HWND parentWnd, int& code):
Window(szAppName)
{
  //NTP Server Information from registry
 	HKEY key;
	unsigned long len = 0;
	unsigned long tp = REG_SZ;

  strcpy(hostname, "18.26.4.105");
	hostport = 123;
	maxderivation = 3600;
	pollfrequency = 0;
	warnonmax=1;
	notifyset=0;
  notifyevents=1;

	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\LiteStep\\Modules\\LSTime\\NTPClient", 0, KEY_READ | KEY_QUERY_VALUE, &key) == ERROR_SUCCESS) {
		len = 255;
		RegQueryValueEx(key, "Server", 0, &tp, (unsigned char *)&hostname[0], &len);
		len = sizeof(DWORD);
		RegQueryValueEx(key, "ServerPort", 0, &tp, (unsigned char *)&hostport, &len);
		RegQueryValueEx(key, "MaxDerivation", 0, &tp, (unsigned char *)&maxderivation, &len);
		RegQueryValueEx(key, "PollFrequency", 0, &tp, (unsigned char *)&pollfrequency, &len);
		RegQueryValueEx(key, "WarnOnAboveDelta", 0, &tp, (unsigned char *)&warnonmax, &len);
		RegQueryValueEx(key, "NotifyOnSetTime", 0, &tp, (unsigned char *)&notifyset, &len);
    RegQueryValueEx(key, "NotifyOnEvents", 0, &tp, (unsigned char *)&notifyevents, &len);
		RegCloseKey(key);
	}


  if (!createWindow(WS_EX_TOOLWINDOW, szAppName, 0,
                    0, 0, 0, 0, parentWnd))
  {
    MessageBox(NULL, "Unable to create window.", szAppName, MB_TOPMOST);
    code = 1;
    return;
  }

  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  wsainit = false;

  if (pollfrequency) SetTimer(hWnd, 1, pollfrequency*MINUTE, NULL);

  code = 0;
}

//---------------------------------------------------------
// Module destructor
//---------------------------------------------------------
NtpClient::~NtpClient()
{
  //Store NTP Server information in the registry
  HKEY key;
  DWORD status;

	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\LiteStep\\Modules\\LSTime\\NTPClient", 0, NULL, REG_OPTION_NON_VOLATILE, KEY_WRITE, NULL, &key, &status) == ERROR_SUCCESS) {
		RegSetValueEx(key, "Server", 0, REG_SZ, (const unsigned char*)&hostname, strlen(hostname));
		RegSetValueEx(key, "ServerPort", 0, REG_DWORD, (const unsigned char*)&hostport, 4);
		RegSetValueEx(key, "MaxDerivation", 0, REG_DWORD, (const unsigned char*)&maxderivation, 4);
		RegSetValueEx(key, "PollFrequency", 0, REG_DWORD, (const unsigned char*)&pollfrequency, 4);
		RegSetValueEx(key, "WarnOnAboveDelta", 0, REG_DWORD, (const unsigned char*)&warnonmax, 4);
		RegSetValueEx(key, "NotifyOnSetTime", 0, REG_DWORD, (const unsigned char*)&notifyset, 4);
    RegSetValueEx(key, "NotifyOnSetTime", 0, REG_DWORD, (const unsigned char*)&notifyevents, 4);
		RegCloseKey(key);
	}

  if (pollfrequency) KillTimer(hWnd, 1);
	KillTimer(hWnd, 0);

  destroyWindow();
}


//=========================================================
// Module code
//=========================================================
void NtpClient::showNTPSetup() 
{
  HWND handle;
  HINSTANCE instance;
  DLGPROC dlgproc;
  handle = hWnd;
  instance = Window::instance();
  dlgproc = (DLGPROC)DlgProc;
  NTPSetup = CreateDialog(instance, MAKEINTRESOURCE(IDD_DIALOG1), handle, dlgproc);
	SetDlgItemText(NTPSetup, IDC_NTPSERVER, hostname);
	SetDlgItemText(NTPSetup, IDC_HINT, "Get a list of servers at: \r\nhttp://www.eecis.udel.edu/~mills/ntp/servers.html\r\nBe sure to read the policy before connecting to a NTP server!");
	SetDlgItemInt(NTPSetup, IDC_NTPPORT, hostport, FALSE);
	SetDlgItemInt(NTPSetup, IDC_NTPMAX, maxderivation, FALSE);
	SetDlgItemInt(NTPSetup, IDC_NTPPOLL, pollfrequency, FALSE);
	CheckDlgButton(NTPSetup, IDC_WARNCHECK, warnonmax);
	CheckDlgButton(NTPSetup, IDC_NOTIFYSET, notifyset);
  CheckDlgButton(NTPSetup, IDC_EVENTNOTIFY, notifyevents);
	ShowWindow(NTPSetup, SW_NORMAL);
  OutputDebugString("showNTPSetup 5");
}


void NtpClient::doNTPSync()
{
	unsigned long thread;
	if (pollfrequency) KillTimer(hWnd, 1);
  CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)doNtpStub, (LPVOID)this, 0, &thread);
}

void NtpClient::translatePacket(SYSTEMTIME received)
{
  SYSTEMTIME now;
  unsigned int originatetimestamp_integer, originatetimestamp_fractional;
  unsigned int receivetimestamp_integer, receivetimestamp_fractional;
  unsigned int transmittimestamp_integer, transmittimestamp_fractional;
  unsigned int received_integer, received_fractional;
  
  unsigned int ti1, tf1, ti2, tf2, ti3, tf3;
  unsigned int d_i, d_f;
  unsigned int t_i, t_f;
  unsigned int i1, f1;
  
  memcpy(xferdata, &databits, sizeof(databits));
  memcpy(&rootdelay, xferdata+4, sizeof(rootdelay));
  memcpy(&rootdispersion, xferdata+8, sizeof(rootdispersion));
  memcpy(&referenceidentifier, xferdata+12, sizeof(referenceidentifier));
  memcpy(&referencetimestamp_hi, xferdata+16, sizeof(referencetimestamp_hi));
  memcpy(&referencetimestamp_lo, xferdata+20, sizeof(referencetimestamp_lo));
  memcpy(&originatetimestamp_hi, xferdata+24, sizeof(originatetimestamp_hi));
  memcpy(&originatetimestamp_lo, xferdata+28, sizeof(originatetimestamp_lo));
  memcpy(&receivetimestamp_hi, xferdata+32, sizeof(receivetimestamp_hi));
  memcpy(&receivetimestamp_lo, xferdata+36, sizeof(receivetimestamp_lo));
  memcpy(&transmittimestamp_hi, xferdata+40, sizeof(transmittimestamp_hi));
  memcpy(&transmittimestamp_lo, xferdata+44, sizeof(transmittimestamp_lo));
  
  originatetimestamp_integer = ntohl(originatetimestamp_hi);
  originatetimestamp_fractional = ntohl(originatetimestamp_lo);
  receivetimestamp_integer = ntohl(receivetimestamp_hi);
  receivetimestamp_fractional = ntohl(receivetimestamp_lo);
  transmittimestamp_integer = ntohl(transmittimestamp_hi);
  transmittimestamp_fractional = ntohl(transmittimestamp_lo);
  
  convertTimeToFixed(received, &received_integer, &received_fractional);
  
  ntp64_moins(received_integer, received_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
  ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, transmittimestamp_integer, transmittimestamp_fractional, &ti2, &tf2);
  
  ntp64_moins(ti1, tf1, ti2, tf2, &d_i, &d_f);
  
  ntp64_moins(receivetimestamp_integer, receivetimestamp_fractional, originatetimestamp_integer, originatetimestamp_fractional, &ti1, &tf1);
  ntp64_moins(transmittimestamp_integer, transmittimestamp_fractional, received_integer, received_fractional, &ti2, &tf2);
  ntp64_plus(ti1, tf1, ti2, tf2, &ti3, &tf3);
  ntp64_sdiv2(ti3, tf3, &t_i, &t_f);
  
  if (maxderivation)
  {
    if (t_i & 0x80000000)
      ntp64_umoins(t_i, t_f, &i1, &f1);
    else
    { i1 = t_i; f1 = t_f; }
    if (i1 > (unsigned)maxderivation && warnonmax)
    {
      char txt[256];
      sprintf(txt, "Server time over maximum derivation (%d seconds). Check your timezone settings.\nClock was not set.", i1);
      MessageBox(NULL, txt, "Warning", MB_ICONWARNING);
      closeup();
      return;
    }
  }
  
  GetSystemTime(&now);
  convertTimeToFixed(now, &ti1, &tf1);
  
  ntp64_plus(ti1, tf1, t_i, t_f, &ti2, &tf2);
  
  convertToSYSTEMTIME(ti2, tf2, &now);
  
  enablePriviledge();
  
  SetSystemTime(&now);
  
  disablePriviledge();
  
  if (notifyset)
    MessageBox(NULL, "Time set!", "NTP Clock Synchronization", MB_ICONINFORMATION);
  
}


void NtpClient::ntp64_plus(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
                unsigned int *resi, unsigned int *resf)
{
  unsigned long lo16 = (frac1 & 0xffff) + (frac2 & 0xffff);
  unsigned long hi16 = (frac1 >> 16) + (frac2 >> 16) + (lo16 >> 16);
  
  *resi = int1 + int2 + (hi16 >> 16);
  *resf = (hi16 << 16) | (lo16 & 0xffff);
}


void NtpClient::ntp64_moins(unsigned int int1, unsigned int frac1, unsigned int int2, unsigned int frac2, 
                 unsigned int *resi, unsigned int *resf)
{
  unsigned int i1, f1;
  ntp64_umoins(int2, frac2, &i1, &f1);
  ntp64_plus(int1, frac1, i1, f1, resi, resf);
}


void NtpClient::ntp64_umoins(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
  ntp64_plus(~int1, ~frac1, 0, 1, resi, resf);
}


void NtpClient::ntp64_sdiv2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
  unsigned int i1, f1, i2, f2;
  
  if (int1 & 0x80000000)
  {
    ntp64_umoins(int1, frac1, &i1, &f1);
    ntp64_div2(i1, f1, &i2, &f2);
    ntp64_umoins(i2, f2, resi, resf);
  }
  else 
    ntp64_div2(int1, frac1, resi, resf);
}


void NtpClient::ntp64_div2(unsigned int int1, unsigned int frac1, unsigned int *resi, unsigned int *resf)
{
  *resf = ((frac1 >> 1) | (int1 << 31));
  *resi = int1 >> 1;
}


int NtpClient::closeup()
{
  if (socketinit)
    closesocket(mysocket);
  
  if (pollfrequency) SetTimer(hWnd, 1, pollfrequency*MINUTE, NULL); 
  lockNTPtimer=0;
  return 0;
}


int NtpClient::socketError(int dontquit)
{
  char *p;
  char txt[256];
  int err = WSAGetLastError();
  switch (err)
  {
  case WSANOTINITIALISED:	
    p = "Sockets not iniatilized";
    break;
  case WSAENETDOWN:
    p = "Network subsystem has failed";
    break;
  case WSAEADDRINUSE:
    p = "Specified address already in use";
    break;
  case WSAEINTR:
    p = "Blocking call was canceled";
    break;
  case WSAEINPROGRESS:
    p = "Blocking call is in progress";
    break;
  case WSAEADDRNOTAVAIL:
    p = "The specified address is not available";
    break;
  case WSAEAFNOSUPPORT:
    p = "Addresses in the specified family cannot be used with this socket";
    break;
  case WSAECONNREFUSED:
    p = "Connection refused";
    break;
  case WSAEINVAL:
    p = "Unbound socket";
    break;
  case WSAEISCONN:
    p = "Socket already connected";
    break;
  case WSAENETUNREACH:
    p = "Network not reachable";
    break;
  case WSAETIMEDOUT:
    p = "Connetion timed out";
    break;
  default: 
    sprintf(txt, "Unknown winsock or internal error (error code = %d)", err);
    p = txt;
    break;
  }
  if (notifyevents)
    MessageBox(NULL, p, "NTP Clock Synchronization", MB_ICONHAND);
  if (!dontquit) closeup();
  return 0;
}


void NtpClient::enablePriviledge()
{
  BOOL opt_ok = OpenProcessToken(GetCurrentProcess(),
    TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
    &tok_handle);
  if (! opt_ok) {
    if (GetLastError() == ERROR_CALL_NOT_IMPLEMENTED) {
      SetLastError(ERROR_SUCCESS);
      priv_modified=0;
      return;
    }
  }
  memset((void *)&tok_priv, 0, sizeof(tok_priv));
  LookupPrivilegeValue(NULL, SE_SYSTEMTIME_NAME,
    &tok_priv.Privileges[0].Luid);
  tok_priv.PrivilegeCount = 1;
  tok_priv.Privileges[0].Attributes |= SE_PRIVILEGE_ENABLED;
  AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
  priv_modified=1;
}


void NtpClient::disablePriviledge()
{
  if (priv_modified)
  {
    tok_priv.Privileges[0].Attributes &= (~ SE_PRIVILEGE_ENABLED);
    AdjustTokenPrivileges(tok_handle, FALSE, &tok_priv, 0, NULL, 0);
  }
}


void NtpClient::convertToSYSTEMTIME(unsigned int int1, unsigned int frac1, SYSTEMTIME *sys_time)
{
   unsigned long ip = int1;
   long int j;

   sys_time->wSecond = (WORD)(ip % 60L);
   ip /= 60L;
   sys_time->wMinute = (WORD)(ip % 60L);
   ip /= 60L;
   sys_time->wHour = (WORD)(ip % 24L);
   ip /= 24L;
   j = ((long int)ip) + JAN_1_1900;

   sys_time->wDayOfWeek = (WORD)((j + 1) % 7L);

   gregorianDate(j, &sys_time->wYear, &sys_time->wMonth, &sys_time->wDay);
   sys_time->wMilliseconds = (WORD)((((double)frac1) * CVT) + 0.5);
}


void NtpClient::convertTimeToFixed(SYSTEMTIME sys_time, unsigned int *integer, unsigned int *fractional)
{
   long int j;

   j = julianDayNumber(sys_time.wYear, sys_time.wMonth, sys_time.wDay);
   j -= JAN_1_1900;
   j = (j * 24L) + (long int)sys_time.wHour;
   j = (j * 60L) + (long int)sys_time.wMinute;
   j = (j * 60L) + (long int)sys_time.wSecond;

   *integer = (unsigned long)j;
   *fractional = ntpfracTable[sys_time.wMilliseconds];
}

int NtpClient::julianDayNumber(WORD wYear, WORD wMonth, WORD wDay)
{
   long int y = (long int)wYear;
   long int d = (long int)wDay;
   long int m = (long int)wMonth;
   long int c;
   long int ya;
   long int j;

   if (m > 2)
      m = m - 3;
   else 
      {
      m = m + 9;
      y = y - 1;
      }
   c = y / 100;
   ya = y - 100 * c;
   j = (146097L * c) / 4 + (1461L * ya) / 4 + (153L * m + 2) / 5 + d + 1721119L;
   return j;
}


void NtpClient::gregorianDate(long julian_time, WORD *wYear, WORD *wMonth, WORD *wDay)
{
   long j = julian_time - 1721119;
   long y = (4 * j - 1) / 146097;
   long d;
   long m;

   j = 4 * j - 1 - 146097 * y;
   d = j / 4;
   j = (4 * d + 3) / 1461;
   d = 4 * d + 3 - 1461 * j;
   d = (d + 4) / 4;
   m = (5 * d - 3) / 153;
   d = 5 * d - 3 - 153 * m;
   d = (d + 5) / 5;
   y = 100 * y + j;
   if (m < 10) {
      m = m + 3;
   } else {
      m = m - 9;
      y = y + 1;
   }
   *wYear = (WORD)y;
   *wMonth = (WORD)m;
   *wDay = (WORD)d;
}


unsigned long NtpClient::doNtpStub(void* obj) 
{
  return ((NtpClient*)obj)->doNtp();
}


unsigned long NtpClient::doNtp()
{
  WORD wVersionRequested; 
  SYSTEMTIME now;
  WSADATA wsaData; 
  struct in_addr addr;
  struct sockaddr_in myaddr;
  struct sockaddr_in _addr;
  int err;
  unsigned int integer, fractional;
  struct hostent *host;
  static int badsocket=0;
  char msgTitle[] = "NTP Clock Synchronization";
  
  lockNTPtimer=1;
  
  if (!wsainit)
  {
    wVersionRequested = MAKEWORD(1, 1); 
    //memset(&wsaData, 0, sizeof(wsaData));
    err = WSAStartup(wVersionRequested, &wsaData); 
  
    if (err != 0) 						 
    {
      MessageBox(NULL, "Enable to start windows sockets", msgTitle, MB_ICONHAND);
      return closeup();
    }
    
    wsainit= true;

    if ( LOBYTE( wsaData.wVersion ) != 1 || 
		    HIBYTE( wsaData.wVersion ) != 1 ) { 
      badsocket= 1;
      MessageBox(NULL, "Incompatible Windows Socket version", msgTitle, MB_ICONHAND);
      return closeup();
    }
  }
  
  if (badsocket) return 0;
  
  mysocket = socket(PF_INET, SOCK_DGRAM, 0);
  memset((void *)&myaddr, 0, sizeof(myaddr));
  myaddr.sin_family = AF_INET;
  myaddr.sin_port = htons((u_short)hostport);
  
  socketinit=1;
  
  host = gethostbyname (hostname);
  if (host == NULL)
  {
    addr.s_addr = inet_addr (hostname);
    if (addr.s_addr == ~0)
    {
      MessageBox(NULL, "Unknown remote host", msgTitle, MB_ICONHAND);
      return closeup();
    }
  }
  else
    memcpy((char *) &addr, host->h_addr, host->h_length);
  
  myaddr.sin_addr = addr;
  
  memset((char *)&_addr, 0, sizeof(_addr));
  _addr.sin_family = AF_INET;
  _addr.sin_port = htons((u_short)hostport);
  _addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if (bind(mysocket, (struct sockaddr *)&_addr, sizeof(_addr)) == SOCKET_ERROR) 
    return socketError(0);
  
  WSAAsyncSelect(mysocket, hWnd, WM_USER+1, FD_READ);
  
  bits.li = 3;
  bits.vn = 2;
  bits.mode = 0;
  bits.stratum = 0;
  bits.poll = 0;
  bits.precision = 0;
  
  memcpy(&databits, &bits, sizeof(databits));
  
  rootdelay = 0;
  rootdispersion = 0;
  referenceidentifier = 0;
  referencetimestamp_hi = 0;
  referencetimestamp_lo = 0;
  originatetimestamp_hi = 0;
  originatetimestamp_lo = 0;
  receivetimestamp_hi = 0;
  receivetimestamp_lo = 0;
  
  GetSystemTime(&now);
  
  convertTimeToFixed(now, &integer, &fractional);
  transmittimestamp_hi = integer;
  transmittimestamp_lo = fractional;
  
  rootdelay = htonl(rootdelay);
  rootdispersion = htonl(rootdispersion);
  referenceidentifier = htonl(referenceidentifier);
  referencetimestamp_hi = htonl(referencetimestamp_hi);
  referencetimestamp_lo = htonl(referencetimestamp_lo);
  originatetimestamp_hi = htonl(originatetimestamp_hi);
  originatetimestamp_lo = htonl(originatetimestamp_lo);
  receivetimestamp_hi = htonl(receivetimestamp_hi);
  receivetimestamp_lo = htonl(receivetimestamp_lo);
  transmittimestamp_hi = htonl(transmittimestamp_hi);
  transmittimestamp_lo = htonl(transmittimestamp_lo);
  
  memcpy(xferdata, &databits, sizeof(databits));
  memcpy(xferdata+4, &rootdelay, sizeof(rootdelay));
  memcpy(xferdata+8, &rootdispersion, sizeof(rootdispersion));
  memcpy(xferdata+12, &referenceidentifier, sizeof(referenceidentifier));
  memcpy(xferdata+16, &referencetimestamp_hi, sizeof(referencetimestamp_hi));
  memcpy(xferdata+20, &referencetimestamp_lo, sizeof(referencetimestamp_lo));
  memcpy(xferdata+24, &originatetimestamp_hi, sizeof(originatetimestamp_hi));
  memcpy(xferdata+28, &originatetimestamp_lo, sizeof(originatetimestamp_lo));
  memcpy(xferdata+32, &receivetimestamp_hi, sizeof(receivetimestamp_hi));
  memcpy(xferdata+36, &receivetimestamp_lo, sizeof(receivetimestamp_lo));
  memcpy(xferdata+40, &transmittimestamp_hi, sizeof(transmittimestamp_hi));
  memcpy(xferdata+44, &transmittimestamp_lo, sizeof(transmittimestamp_lo));
  
  if (sendto(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
    (struct sockaddr *)&myaddr, sizeof(myaddr)) == SOCKET_ERROR) 
    return socketError(0);
  
  SetTimer(hWnd, 0, 20000, NULL);
  ExitThread(0);
  return 0;
}


//=========================================================
// Registered messages
//=========================================================

void NtpClient::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onEndSession,        WM_ENDSESSION)
    MESSAGE(onEndSession,        WM_QUERYENDSESSION)
    MESSAGE(onSysCommand,        WM_SYSCOMMAND)
    MESSAGE(onTimer,             WM_TIMER)
    MESSAGE(onUser,              WM_USER+1)
    MESSAGE(onUser2,             WM_USER+2)
  END_MESSAGEPROC
}


//=========================================================
// Message handlers
//=========================================================
void NtpClient::onEndSession(Message& message)
{
  message.lResult = SendMessage(hParent, message.uMsg, message.wParam, message.lParam);
}



void NtpClient::onSysCommand(Message& message)
{
  if (message.wParam == SC_CLOSE)
    PostMessage(hParent, WM_KEYDOWN, LM_SHUTDOWN, 0);
  else
    message.lResult = DefWindowProc(hWnd, message.uMsg, message.wParam, message.lParam);
}


void NtpClient::onTimer(Message& message)
{
  switch (message.wParam)
  {
  case 0:
	  KillTimer(hWnd, 0);
	  if (notifyevents)
      MessageBox(NULL, "Timeout occured while waiting for NTP reply", "NTP Clock Synchronization", MB_ICONHAND);
	  closeup();
    break;
  case 1:
    doNTPSync();
    break;
  }
}

void NtpClient::onUser(Message& message)
{
  struct sockaddr_in gotfrom;
  SYSTEMTIME now;
  int gotlen = sizeof(gotfrom);
  
  if (recvfrom(mysocket, (char *)&xferdata, sizeof(xferdata), 0,
    (struct sockaddr *)&gotfrom, &gotlen) != SOCKET_ERROR)
  {
    GetSystemTime(&now);
    translatePacket(now);
  }
	else
    socketError(1);
    
  KillTimer(hWnd, 0);
  closeup();
}

void NtpClient::onUser2(Message& message)
{
  BOOL a;
  if (message.wParam == 1) {
    GetDlgItemText(NTPSetup, IDC_NTPSERVER, NtpClient::hostname, 255);
    hostport = GetDlgItemInt(NTPSetup, IDC_NTPPORT, &a, TRUE);
    maxderivation = GetDlgItemInt(NTPSetup, IDC_NTPMAX, &a, TRUE);
    pollfrequency = GetDlgItemInt(NTPSetup, IDC_NTPPOLL, &a, FALSE);
    warnonmax = IsDlgButtonChecked(NTPSetup, IDC_WARNCHECK);
    notifyset = IsDlgButtonChecked(NTPSetup, IDC_NOTIFYSET);
    notifyevents = IsDlgButtonChecked(NTPSetup, IDC_EVENTNOTIFY);
    if (pollfrequency && !lockNTPtimer) SetTimer(hWnd, 1, pollfrequency*MINUTE, NULL);
  }
  DestroyWindow(NTPSetup);
}

INT_PTR CALLBACK DlgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  if (uMsg == WM_COMMAND) {
		if (HIWORD(wParam) == BN_CLICKED)
			{
			switch (LOWORD(wParam))
				{
				case IDOK:
					{
          SendMessage(GetParent(hwndDlg), WM_USER+2, 1, 0);
					break;
					}
				case IDCANCEL:
					SendMessage(GetParent(hwndDlg), WM_USER+2, 0, 0);
					break;
				}
			}
		return TRUE;
	}
  return FALSE; //DefDlgProc(hwndDlg, uMsg, wParam, lParam);
}