/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __LSTIME_H
#define __LSTIME_H

#include <windows.h>
#include "../lsapi/lsapi.h"
#include "../lsapi/lswinbase.h"
#include "../wharf/wharf.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#define MAX_LINE_LENGTH 4096
#define ONE_SEC_IN_MS	1000
#ifndef M_PI
#define M_PI			3.14159265359
#endif
#define LS_GWL_CLASSPOINTER 0

//Typedefs
typedef struct {
	int sX;
	int sY;
	int dX;
	int dY;
	int w;
	int h;
} _6PointPos;
typedef struct {
	int sX;
	int sY;
	int w;
	int h;
} _4PointPos;
typedef struct {
	int dX;
	int dY;
	int w;
	int h;
} _4PointPosA;
typedef struct {
	int dX;
	int dY;
} _2PointPos;
typedef struct {
	HBITMAP usePic;
	HBITMAP oldPic;
	HDC picDC;
} LSTimeImage;

class Lstime
{
private:
  HWND hParent;
  HINSTANCE hInstance;
  HWND hWnd;

  HDC dblBuf;
	HBITMAP dblBufBMP;
  LSTimeImage bkGrnd;
	bool backInit;
	wharfDataType wharfData;
	int wndSize;
  LSTimeImage themePic;
  char ThemePicName[256];
  HBITMAP oldBMP1, oldBMP2, oldBMP3;
  bool globCounter;
  bool firstTime;

  /* This used to be the timeThemeType structure
     and was declared as the curTimeTheme varaible,
     as this was the only placed it was used, just
     gonna make it local private variables
  */
	_4PointPos sDateFontPos;
	_4PointPos sDigiFontPos;
	_4PointPos sAnaDayFontPos;
	_4PointPos sAnaMonthFontPos;
	_2PointPos sDigiClockPos;
	bool bDigiClock;
	_2PointPos sDigiDayPos;
	bool bDigiDay;
	_2PointPos sDigiMonthPos;
	bool bDigiMonth;
	_2PointPos sDigiYearPos;
	bool bDigiYear;
	_2PointPos sDigi2dYearPos;
	bool bDigi2dYear;
	_2PointPos sAnaDayPos;
	bool bAnaDay;
	_2PointPos sAnaMonthPos;
	bool bAnaMonth;
	_4PointPosA sAnaClockPos;
	bool bAnaClock;
	_6PointPos sBackground;
	bool bBackground;
	unsigned long cHourHandColor;
	bool bHourHandColor;
	unsigned long cHourHandShade;
	bool bHourHandShade;
	unsigned long cMinHandColor;
	bool bMinHandColor;
	unsigned long cMinHandShade;
	bool bMinHandShade;
	unsigned long cSecHandColor;
	bool bSecHandColor;
  /* End old timeThemeType structure */

public:
  Lstime(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd, int& code);
  ~Lstime();

private:
  int initModule();
  void quitModule();

  void themeParse(FILE*);
  HRGN getLSRegion(int, int);
  void makeBuffer(HWND);
  void redrawClock();
  void drawAnaClock();

  static LRESULT CALLBACK wndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
  void windowProc(Message& message);
  void onPaint(Message& message);
  void onTimer(Message& message);
  void onRightMouseButton(Message& message);
  void onLeftMouseButtonDblClick(Message& message);
  void onGetRevId(Message& message);
};

extern "C"
{
  __declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
  __declspec( dllexport ) void quitWharfModule(HINSTANCE dll);
}

#endif
