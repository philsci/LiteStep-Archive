

  NT-specific installation:

  - Use regedit.
  - Go to key HKLM\SOFTWARE\Microsoft\Windows NT\Current Version\Winlogon\
  - Change the data string "Shell" (currently to EXPLORER.EXE) to "yourpath\LITESTEP.exe"
  - Go to key HKLM\SOFTWARE\Microsoft\Windows\Current Version\Explorer\
  - (or HKCU\SOFTWARE\Microsoft\Windows\Current Version\Explorer\ for
    user-specific edition)
  - Create a key of type DWORD named DesktopProcess and give it a value of 1
    (this will allow explorer to run more than one instance in spite of the
    fact that it is not the shell)
  - Check step.rc, there are a couple of documented modifications you have to do for WinNT


  Warning:
  --------

  If you use Microsoft IE4, the above modification will not work, you'll need to
  modify the following:

  HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Browse
  NewProcess

   String Value:
	BrowseNewProcess

   Data:
	YES
	NO

  if set to yes, it allows more than one explorer window to be up.

  Replacements for Explorer ?
  ---------------------------

  There are some very good probgrams, check:

    - PowerDesk (better than explorer in my opinion, but shareware)
    - Servant Salamander (verry good and freeware)

  Check my homepage at http://litestep.computerheaven.net for links

 
