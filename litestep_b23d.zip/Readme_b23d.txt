
 This is a VERY small update. It changes only two things:

 - A new functionnality for module developpers. 
 - Desktop is now clickable (it won't refuse focus)


 That's is strictly all that was modified since b23c. Sorry if you were looking
 for more bugfixes, you'll have to wait a bit more.

 I'm currently working to make an exportable source package so we can start
 to work on the GNU GPL'd source package.

 Francis.
