// StartupRunner.h: interface for the StartupRunner class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STARTUPRUNNER_H__61712B29_5D36_4C8C_AA36_B9A03F708E2A__INCLUDED_)
#define AFX_STARTUPRUNNER_H__61712B29_5D36_4C8C_AA36_B9A03F708E2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class StartupRunner  
{
public:
	StartupRunner();
	virtual ~StartupRunner();

// [Startup Handler Code]
	static DWORD WINAPI RunStartupStuff(void* dummy);
	static void RunEntriesIn(HKEY key, LPCTSTR path);
	static void DeleteEntriesIn(HKEY key, LPCTSTR path);
	static void RunStartupMenu(void);
	static void RunFolderContents(LPCSTR szParams);
};

#endif // !defined(AFX_STARTUPRUNNER_H__61712B29_5D36_4C8C_AA36_B9A03F708E2A__INCLUDED_)
