/*

This is a part of the LiteStep Shell Source code.
  
Copyright (C) 1997-98 Francis Gastellu
aka Lone Runner/Aegis
	
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.
	  
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
		
You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
		  
*/

/****************************************************************************
11/16/99 - Headius
Rewrite of LSTaskBar to avoid using the evil winList. LSTaskButton made into
an active class, responsible for drawing itself and activating its
associated window. Tooltips for task buttons have been disabled temporarily.
Internally, taskbar now uses a map rather than a giant array. It is
dependent on the window list only for initial enumeration. Subsequent adds/
removes are done using LM_ADDWINDOW and LM_REMOVEWINDOW. With the rewrite,
desktop no longer maintains the window list.
This is likely the last major rewrite to the taskbar code. Desktop will
be dumped in favor of a new UI module in the next several weeks.
11/15/99 - Headius
Fix for tray icons with no taskbar...icons were not drawing on desktop.
Also fix for desktop window showing in sysvwm.
11/09/99 - Headius
Fix to bugs in taskbar size and painting while in "MSTaskBar" mode
11/04/99 - Headius
Massive rewrite, sofar entire module has been split into 6 classes.
Likely to have two more classes, one for the desktop itself and one for
the bar. How best to split it I'm still working on, but it will be done.
I've been making minor bugfixes along the way, but most of the fixing will
wait until everything is split and working. Then I'll start trying to
encapsulate it better. THEN I'll try to improve it.
10/21/99 - Headius
Rewrote desktop module as a C++ class.
LSBar module implements the LSModule class, which I added to lsapi.
08/09/99 - (e)
Merged context menu drawing code by Ryan Dalzell
01/04/99 - mlin
Re-instated copying HICONS; problems with icons disappearing had
been popping up without this functionality. Oops.
Instead, trayType now maintains both the HICON originally passed
to it and the copy. The original HICON is passed when programs
use LM_SENDSYSTRAY, and the copy everywhere else.
01/02/99 -	mlin
In adding support for TraySaver, the following changes have been
made:
1. Added support for LM_SENDSYSTRAY message that allows other programs
to enumerate the system tray icons.
2. Previously, copies were made of HICONs for tray icons besettings.fore
storing them. This is unecessary, and caused problems with TraySaver,
so I removed it.
3. Fixed problems where a program maintains more than one tray
icon with a modification to removeFromTray
11/14/98 - Thedd (Theodor Nilsson) added by Fahim
Separate skins (with transparency support) for taskbar buttons,
start button, and task tray via TaskButtonSkin, TaskButtonLeft,
TaskButtonRight, TaskButtonSkinActive, TaskButtonLeftActive, 
TaskButtonRightActive, settings.TaskbarNoSkinShift, settings.TaskbarNoTextShift,
TaskTraySkin, TaskTrayLeft, TaskTrayRight, StartButtonSkin, 
StartButtonLeft & StartButtonRight in step.rc
11/13/98 - Fahim
Fixed SystrayOrientation so that the parameters aren't case sensitive
11/11/98 - Thedd (Theodor Nilsson) added by Fahim
Added skin support to taskbar via TaskbarSkin in step.rc
11/11/98 - cael and Fahim
Added support to specify the size of the area to which an application
can maximize via SetDesktopArea and SDALeft, SDARight, SDATop, SDABottom
in step.rc
10/29/98 - Cyberian (Fahim Farook)
Changed SystrayOrientation parameter parsing so that the options 
don't have to be in a specific order and can have any punctuation 
to separate them as long as the string is enclosed in quotes if it
has any whitespaces in it
Added customization options to the taskbar start button via two
step.rc options - StartButtonSize & StartButtonText

  07/18/98 - Azerov
  Removed [Drizzt]'s hotkey patch, as this functionality has been
  added to HotKeys.dll.
  07/16/98 - j_edge
  Added autorun handling for AudioCD's, along with an entry in 
  MODULES.INI to allow user to disable autorun for audio for 
  cases like module cd players which cannot be executed
  07/15/98 - Azerov
  Integrated [Drizzt]'s hotkey patch, which scans the start
  menu and desktop for shortcuts (*.lnk files), and looks to see if
  they have any hotkeys registered. (get properties on a shortcut
  to set the hotkeys).
  07/14/98 - Azerov
  Fixed tooltips for systray/taskbar on NT.
  Fixed some window cleanup errors which only manifested themselves
  as problems on NT. (If settings.appBar was false, window classes were not
  getting unregistered.
  07/14/98 - j_edge
  Added handling code for autorun().
  07/12/98 - Azerov
  Consolidated all the tooltip windows for the app bar and systray into
  one window.
  Cleaned up tooltips alot, and made them save/restore during recycles.
  07/11/98 - Azerov
  Added support for systray configuration through Modules.ini.
  Expanded userAppBar from 16 to 50 items - having more than 16 windows
  open was overwriting memory somewhere. :)
  Got rid of hardcoded values throughout the file which assumed
  that trayWnds[] and userAppBar[] had 50 and 16 members respectively.
  Handle WM_MOUSEACTIVATE message in WndProcIcon, so that clicks and
  doubleclicks are passed to the system tray icons.
  Made window class strings const.
  Commented out the packScreenTray call in the NIM_MODIFY message, as this
  should not be necessary. (The number of systray icons will not change
  during a call to NIM_MODIFY).  packScreenTray was causing the taskbar
  to flicker every time a systray icon changed [eg. dial-up-networking icon].
  Got rid of the remaining flicker problems with the systray and taskbar.
  06/03/98 - F. Gastellu
  This file contains the source code for the desktop system
  module
  
****************************************************************************/
#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <malloc.h>
#include <commctrl.h>
#include <dbt.h>
#include "../core/ifcs.h"
#include "LSBar.h"
#include "../lsapi/lsapi.h"
#include "LSTaskBar.h"

void (__stdcall *SwitchToThisWindow)(HWND, int);

LSBar *myLSBar;

LSBar::LSBar(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
	settings.loadSettings();

	hToolTips = NULL;
	
	backInit=FALSE;
	//settings.trayIconSize=32;
	
	ScreenWidth=1152;
	ScreenHeight=864;
	
	barLeft = 0;
	
	np=0;
	
	barHiden=FALSE;
	hideTimerActive=FALSE;
	
	dontReleaseIcons = FALSE;
	
}

// -------------------------------------------------------------------------------------------------------
// Initialization of the module
// -------------------------------------------------------------------------------------------------------
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath) {
	myLSBar = new LSBar(ParentWnd, dllInst, szPath);

	myLSBar->initModule(ParentWnd, dllInst, szPath);
    
	return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
// -------------------------------------------------------------------------------------------------------
void quitModule(HINSTANCE dllInst) {
	myLSBar->quitModule(dllInst);
	delete myLSBar;
}

// window procedure for our window
LRESULT CALLBACK LSBar::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LSBar *theDesktop = (LSBar*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theDesktop) {
		return theDesktop->WindowProc(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

// -------------------------------------------------------------------------------------------------------
// Manager reset
// -------------------------------------------------------------------------------------------------------
void LSBar::resetManager()
{
	/*int i;
	RECT r;
	for (i=0;i<nWin;i++)
    {
		if (!winList[i].Visible)
		{
			GetWindowRect(winList[i].Handle, &r);
			MoveWindow(winList[i].Handle, r.left-ScreenWidth*3, r.top-ScreenHeight*3, r.right-r.left, r.bottom-r.top, TRUE);
		}
    }
	ArrangeIconicWindows(GetDesktopWindow());*/
	int WARNING;
}

void LSBar::MinMaxWindow(int i) {
	/*RECT r;
	
	if (IsIconic(winList[i].Handle)) {
		if (winList[i].Visible) {
			//ShowWindow(winList[i].Handle, SW_HIDE);
			GetWindowRect(winList[i].Handle, &r);
			MoveWindow(winList[i].Handle, ScreenWidth*3+r.left, ScreenHeight*3+r.top, r.right-r.left, r.bottom-r.top, TRUE);
			winList[i].Visible = FALSE;
		}
	} else {
		if (!winList[i].Visible) {
			winList[i].Visible = TRUE;
		}
   	}*/
	int WARNING;
}

// -------------------------------------------------------------------------------------------------------
// Check a RECT
// -------------------------------------------------------------------------------------------------------
int LSBar::rectOk(HWND hwnd)
{
	RECT r;
	
	GetWindowRect(hwnd, &r);
	return (!(r.bottom == r.top || r.right == r.left));
}

// -------------------------------------------------------------------------------------------------------
// Window procedure for the taskbar
// -------------------------------------------------------------------------------------------------------
LRESULT CALLBACK LSBar::WndProcBar(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LSBar *theDesktop = (LSBar*)::GetWindowLong(hwnd, LS_GWL_CLASSPOINTER);
	
	if (theDesktop) {
		return theDesktop->WindowProcBar(hwnd, message, wParam, lParam);
	} else {
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
}

LRESULT LSBar::WindowProcBar(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int Xpos;
    switch (message) {
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_MOUSEMOVE:
		if (!settings.autoHide) return 0; {
            if (barHiden) {
                myLSBar->ShowBar();
			} else {
                KillTimer(hBarWnd, 1);
				hideTimerActive=FALSE;
			}
		}
		return 0;
	case WM_LBUTTONDOWN:
		{
			// my crude fix for the popups appearing whenever you click
			// on the bottom of the taskbar....
			if (settings.startButton) {
				Xpos = LOWORD(lParam);
				if (Xpos >= 2 && Xpos <= settings.startButtonSize + 14) {
					ParseBangCommand(hwnd, "!popup", NULL);
				}
			}
		}
		break;
	case WM_TIMER:
		{
			if (wParam == 1) {
				if (settings.autoHide) myLSBar->HideBar();
				KillTimer(hBarWnd, 1);
				hideTimerActive=FALSE;
			} else {
				if (settings.autoHide && !barHiden && !hideTimerActive) {
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					GetWindowRect(hBarWnd, &r);
					if (pt.x < r.left || pt.x > r.right || pt.y < r.top || pt.y > r.bottom)
					{
						SetTimer(hBarWnd, 1, settings.autoHideDelay, NULL);
						hideTimerActive=TRUE;
					}
				}
			}
		}
        return 0;
	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
            RECT r;
			int clr1, clr2, clr3;
			HPEN oldPen, pen;
			HBRUSH brush;
			HBITMAP oldBMP;
			
            if (settings.appBar) {
                GetClientRect(hwnd, &r);
				
                if (!settings.newStyle) {
					clr1 = GetSysColor(COLOR_3DHILIGHT);
					clr2 = GetSysColor(COLOR_3DDKSHADOW);
					clr3 = GetSysColor(COLOR_3DFACE);
				} else {
					clr1 = settings.fore;
					clr2 = settings.fore2;
					clr3 = settings.back;
				}
				
				pen = CreatePen(PS_SOLID, 1, clr1);
				oldPen = (HPEN)SelectObject(hdc, pen);
				
				MoveToEx(hdc, 0, 0, NULL);
				LineTo(hdc, r.right, 0);
				SelectObject(hdc, oldPen);
				DeleteObject(pen);
				
				if (settings.stripBar) {
					pen = CreatePen(PS_SOLID, 1, clr2);
					oldPen = (HPEN)SelectObject(hdc, pen);
					
					MoveToEx(hdc, r.right-1, 0, NULL);
					LineTo(hdc, r.right-1, r.bottom-1);
					SelectObject(hdc, oldPen);
					DeleteObject(pen);
				}
				
				r.top++;
				r.right--;
				brush = CreateSolidBrush(clr3);
				
				if (settings.taskBMP.bitmap == NULL) {
					FillRect(hdc, &r, brush);
				} else {
					HDC memDC; // Taskbar skin
					
					memDC = CreateCompatibleDC(hdc);
					oldBMP = (HBITMAP)SelectObject(memDC, settings.taskBMP.bitmap);
					BitBlt(hdc, 0, 0, settings.taskBMP.x, settings.taskBMP.y, memDC, 0, 0,SRCCOPY);
					SelectObject(memDC, oldBMP);
					DeleteDC(memDC);
				}
				
				if (settings.startButton) {
					HPEN old, pen;
					char txt[256];
					HFONT oldFont, hf;
					HICON hIcon1;
					RECT r2;
					
					if (settings.startbuttonskinBMP.bitmap == NULL) {
						pen = CreatePen(PS_SOLID, 1, clr1); // Taskbar skin
						old = (HPEN)SelectObject(hdc, pen);
						
						MoveToEx(hdc, barLeft - 2, 3, NULL);
						LineTo(hdc, 2, 3);
						LineTo(hdc, 2, r.bottom-2);
						SelectObject(hdc, old);
						DeleteObject(pen);
						pen = CreatePen(PS_SOLID, 1, clr2);
						old = (HPEN)SelectObject(hdc, pen);
						LineTo(hdc, barLeft - 2, r.bottom - 2);
						LineTo(hdc, barLeft - 2, 3);
						SelectObject(hdc, old);
						DeleteObject(pen);
					} else {
                        HDC memDC;
                        int xpos = 2+settings.startbuttonleftBMP.x, ypos = 3;
						
                        memDC = CreateCompatibleDC(hdc);
                        oldBMP = (HBITMAP)SelectObject(memDC, settings.startbuttonskinBMP.bitmap);
                        
						while (ypos < r.bottom-2) {
							xpos = 2+settings.startbuttonleftBMP.x;
							
							while (xpos < barLeft-2-settings.startbuttonrightBMP.x) {
								int bmpx = settings.startbuttonskinBMP.x;
								while (xpos+bmpx > barLeft-2-settings.startbuttonrightBMP.x) bmpx--;
								TransparentBltLS(hdc, xpos, ypos, bmpx, settings.startbuttonskinBMP.y, memDC, 0, 0, RGB(255,0,255));
								xpos += settings.startbuttonskinBMP.x;
							}
							
							ypos += settings.startbuttonskinBMP.y;
                        }
						
						SelectObject(memDC, oldBMP);
                        DeleteDC(memDC);
					}
					
					if (settings.startbuttonleftBMP.bitmap != NULL) {
                        HDC memDC;
                        int xpos = 2, ypos = 3;
						
                        memDC = CreateCompatibleDC(hdc);
                        oldBMP = (HBITMAP)SelectObject(memDC, settings.startbuttonleftBMP.bitmap);
                        
						while (ypos < r.bottom-2) {
							TransparentBltLS(hdc, xpos, ypos, settings.startbuttonleftBMP.x, settings.startbuttonleftBMP.y, memDC, 0, 0, RGB(255,0,255));
							ypos += settings.startbuttonleftBMP.y;
                        }
						
						SelectObject(memDC, oldBMP);
                        DeleteDC(memDC);
					} if (settings.startbuttonrightBMP.bitmap != NULL) {
                        HDC memDC;
                        int xpos = barLeft-2-settings.startbuttonrightBMP.x, ypos = 3;
                        
						memDC = CreateCompatibleDC(hdc);
                        oldBMP = (HBITMAP)SelectObject(memDC, settings.startbuttonrightBMP.bitmap);
                        
						while (ypos < r.bottom-2) {
							TransparentBltLS(hdc,
								xpos,
								ypos,
								settings.startbuttonrightBMP.x,
								settings.startbuttonrightBMP.y,
								memDC,
								0,
								0,
								RGB(255,0,255));
							
							ypos += settings.startbuttonrightBMP.y;
                        }
						
						SelectObject(memDC, oldBMP);
                        DeleteDC(memDC);
					}
					
					strcpy(txt, settings.startButtonText);
					
					if (!stricmp(settings.startButtonImage, "default")) {
						hIcon1 = LoadIcon(NULL, IDI_WINLOGO);
					} else {
						hIcon1 = LoadLSIcon(settings.startButtonImage, NULL);
					}
					
					StretchBlt(bufferDC, 0, 0, 32, 32, hdc, 4, 5, settings.trayIconSize, settings.trayIconSize, SRCCOPY);
					DrawIconEx(bufferDC, 0, 0, hIcon1, 0, 0, 0, NULL, DI_DEFAULTSIZE|DI_NORMAL);
					StretchBlt(hdc, 4, 5, settings.trayIconSize, settings.trayIconSize, bufferDC, 0, 0, 32, 32, SRCCOPY);
					
					hf = (HFONT)GetStockObject(ANSI_VAR_FONT); 
					oldFont = (HFONT)SelectObject(hdc, hf); 
					SetBkMode(hdc, TRANSPARENT);
					
					r2.left = 7 + settings.trayIconSize;
					r2.right = barLeft - 4;
					r2.top = 3;
					r2.bottom = r.bottom - 2;
					
					if (settings.newStyle) SetTextColor(hdc, settings.text);
					else SetTextColor(hdc, GetSysColor(COLOR_BTNTEXT));
					
					DrawText(hdc, txt, strlen(txt), &r2, DT_LEFT | DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
					SelectObject(hdc, oldFont);
				}
				DeleteObject(brush);
            }
			EndPaint(hwnd,&ps);
        }
		return 0;
	case WM_KEYDOWN: 
	case WM_KEYUP:
		PostMessage(parent,message,wParam,lParam);
		return 0;
	case WM_SYSCOMMAND:
		switch (wParam) {
		case SC_CLOSE:
			// ???
			PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
			return 0;
		default:
			return DefWindowProc(hwnd,message,wParam,lParam);
		}
    }
	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

// -------------------------------------------------------------------------------------------------------
// Computes window sizes
// -------------------------------------------------------------------------------------------------------
void LSBar::adjustWndSizes(void)
{
	RECT	r,r2;
	int		i = trayWnds->nTrayIcons();
	RECT	trayRect, tasksRect;
	BOOL	need_to_invalidate = FALSE;
	
	// get the current dimensions
	trayWnds->getRectangle(&r);
	taskBar->getRectangle(&r2);
	
	if (!settings.sysTrayRight) {
		//set tray dimensions
		trayRect.left = r.left;
		trayRect.top = r.top;
		trayRect.right = trayRect.left + 6 + (settings.trayIconSize + 2) * i;
		trayRect.bottom = trayRect.top + settings.trayIconSize+6;
		
		if (memcmp(&trayRect, &r, sizeof (trayRect))) {
			need_to_invalidate = TRUE;
			SetWindowPos(trayWnds->hTrayWnd, NULL, 0, 0, trayRect.right - trayRect.left, trayRect.bottom - trayRect.top, SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER);
		}
		
		// set taskbar dimensions
		tasksRect.left = 8 + barLeft + (settings.trayIconSize + 2) * i;
		tasksRect.top = 3;
		tasksRect.right = tasksRect.left + (settings.stripBar ? ScreenWidth - 73 : ScreenWidth - 10 - barLeft) - (settings.trayIconSize + 2) * i;
		tasksRect.bottom = tasksRect.top + settings.trayIconSize + 6;
		
		if (memcmp (&tasksRect, &r2, sizeof (tasksRect))) {
			need_to_invalidate = TRUE;
			SetWindowPos(taskBar->hTasksWnd, NULL, tasksRect.left, tasksRect.top, tasksRect.right - tasksRect.left, tasksRect.bottom - tasksRect.top, SWP_NOOWNERZORDER|SWP_NOZORDER);
		}
	} else {
		// set tray dimensions
		trayRect.left = ScreenWidth - ((6 + (settings.trayIconSize + 2) * i) + (settings.stripBar? 64 : 0));
		trayRect.top = 3;
		trayRect.right = trayRect.left + 6 + (settings.trayIconSize + 2) * i;
		trayRect.bottom = trayRect.top + settings.trayIconSize + 6;
		
		if (memcmp (&trayRect, &r, sizeof (trayRect))) {
			need_to_invalidate = TRUE;
			SetWindowPos (trayWnds->hTrayWnd, NULL, trayRect.left, trayRect.top, trayRect.right - trayRect.left, trayRect.bottom - trayRect.top, SWP_NOOWNERZORDER|SWP_NOZORDER);
		}
		
		// set taskbar dimensions
		tasksRect.left = 6 + barLeft;
		tasksRect.top = 3;
		tasksRect.right = ScreenWidth - ((12 + (settings.trayIconSize + 2) * i) + (settings.stripBar? 64 : 0));
		tasksRect.bottom = tasksRect.top + settings.trayIconSize+6;
		
		if (memcmp (&tasksRect, &r2, sizeof (tasksRect))) {
			need_to_invalidate = TRUE;
			SetWindowPos(taskBar->hTasksWnd, NULL, tasksRect.left, tasksRect.top, tasksRect.right - tasksRect.left, tasksRect.bottom - tasksRect.top, SWP_NOOWNERZORDER|SWP_NOZORDER);
		}
	}
	
	if (need_to_invalidate){
		InvalidateRect(trayWnds->hTrayWnd, &r, TRUE);
    }

	taskBar->updateTasksView(need_to_invalidate? 1 : 0);
}

// -------------------------------------------------------------------------------------------------------
// Sets maximized windows size
// -------------------------------------------------------------------------------------------------------
void LSBar::setMinMax(void) {
	RECT r;
	
	if (!settings.appBar && !settings.setDesktopArea) {
		return;
	}
	SystemParametersInfo(SPI_GETWORKAREA,0,(PVOID)&r,SPIF_SENDCHANGE);
	origWorkArea = r;
	r.bottom = ScreenHeight - ((settings.autoHide) ? 1 : (settings.trayIconSize+10));
	SetDesktopArea(r.left, r.top, r.right, r.bottom);
	
	if (settings.setDesktopArea) {
		r.left = settings.sdaLeft;
		r.top = settings.sdaTop;
		r.right = settings.sdaRight<0 ? ScreenWidth+settings.sdaRight:settings.sdaRight;
		r.bottom = settings.sdaBottom<0 ? ScreenHeight+settings.sdaBottom:settings.sdaBottom;
		SetDesktopArea(r.left, r.top, r.right, r.bottom);
	}
}

// -------------------------------------------------------------------------------------------------------
// Reset to old maximized windows size
// -------------------------------------------------------------------------------------------------------
void LSBar::resetMinMax(void)
{
	RECT r;	
	
	if (!settings.appBar && !settings.setDesktopArea)
		return;
	r.top = 0;
	r.left = 0;
	r.bottom = ScreenHeight;
	r.right = ScreenWidth;
	SetDesktopArea(r.left, r.top, r.right, r.bottom);
}

// -------------------------------------------------------------------------------------------------------
// Non blocking wait
// -------------------------------------------------------------------------------------------------------
void LSBar::DoEvents(int n)
{
	int i;
	BOOL b=TRUE;
	MSG msg;
	
	for (i=0;i<n && b;i++)
    {
		b = GetMessage( &msg, NULL, 0, 0 );
		if (b) 
        {
			TranslateMessage( &msg );
			DispatchMessage( &msg ); 
        }
    }
}

// -------------------------------------------------------------------------------------------------------
// Hide the taskbar
// -------------------------------------------------------------------------------------------------------
void LSBar::HideBar(void)
{
	RECT r;
	int w;
	if (barHiden) return;
	r = taskBarRect;
	w = r.bottom-r.top;
	r.top+= settings.trayIconSize+9;
	r.bottom = r.top + w;
	MoveWindow(hBarWnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	barHiden = TRUE;
}

// -------------------------------------------------------------------------------------------------------
// Show the taskbar
// -------------------------------------------------------------------------------------------------------
void LSBar::ShowBar(void)
{
	RECT r;
	
	if (!barHiden) return;
	r = taskBarRect;
	MoveWindow(hBarWnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
	barHiden = FALSE;
}

// -----------------------------------------------------------------------------------------------
// Reorders windows
// -----------------------------------------------------------------------------------------------
int LSBar::reorderWindows(void) {
	int a=0;
	HWND last = GetWindow(hMainWnd, GW_HWNDLAST);
	while (last && last != hMainWnd) {
		if (GetWindowLong(last, GWL_STYLE) & WS_VISIBLE) {
			a=1;
			SetWindowPos(last, GetWindow(hMainWnd, GW_HWNDPREV), 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
			last = GetWindow(hMainWnd, GW_HWNDLAST);
			continue;
		}

		last = GetWindow(last, GW_HWNDPREV);
    }
	return a;
}

// -----------------------------------------------------------------------------------------------
//  Compares drive type to drives that have autorun enabled set in registry 
//		(using getAutorunDrives()) and if enabled launches open= entry in autorun.inf
// -----------------------------------------------------------------------------------------------
void LSBar::autorun(int drive) {
    unsigned char *pDriveData;
    UINT uDriveType;
    char szDrive[4] = " :\\";
    BOOL floppyNoAutorun = TRUE;
    BOOL fixedNoAutorun = TRUE;
    BOOL netNoAutorun = TRUE;
    BOOL cdNoAutorun = TRUE;
    BOOL ramNoAutorun = TRUE;
    char szInfFilename[15];
    char szOpenEntry[_MAX_PATH];
    char szCommandline[_MAX_PATH];
    STARTUPINFO sInfo;
    PROCESS_INFORMATION pInfo;
    BOOL bResult;
	
    // get info for drive that media has been inserted in
    *szDrive = (char) (drive+(int)'A');
    uDriveType = GetDriveType(szDrive);
	
    // figure out which drives have autorun disabled in registry
    pDriveData = getAutorunDrives();
    floppyNoAutorun = ( 0x04 & *pDriveData );
    fixedNoAutorun = ( 0x08 & *pDriveData );
    netNoAutorun = ( 0x10 & *pDriveData );
    cdNoAutorun = ( 0x20 & *pDriveData );
    ramNoAutorun = ( 0x40 & *pDriveData );
	
    free(pDriveData);
	
    // return if drive has autorun disabled
    switch(uDriveType) {
    case DRIVE_REMOVABLE:
		if( floppyNoAutorun )
			return;
		break;
    case DRIVE_FIXED:
		if( fixedNoAutorun )
			free(pDriveData);
		return;
		break;
    case DRIVE_REMOTE:
		if( netNoAutorun )
			return;
		break;
    case DRIVE_CDROM:
		if( cdNoAutorun )
			return;
		else { 
			// handle AudioCD's here since they should be the only media type
			// this pertains to (can you play an audio cd over a network?)
			char szVolumeName[12];
			DWORD dwVolSerNum;
			DWORD dwMaxCompLength;
			DWORD dwFileSystemFlags;
			char szFileSysName[10];
			HINSTANCE hResult;
			
			GetVolumeInformation( szDrive, szVolumeName, sizeof(szVolumeName), 
				&dwVolSerNum, &dwMaxCompLength, &dwFileSystemFlags, szFileSysName,
				sizeof(szFileSysName) );
			
			// only do this if it's an audio cd & AudioAutoplay is enabled
			if( (strcmp( szVolumeName, "Audio CD" ) == 0) && bAudioAutoplay ) {	
				hResult = ShellExecute(GetDesktopWindow(), "play", "track01.cda", 
					NULL, szDrive, SW_SHOW );
				return;
			} else if( strcmp( szVolumeName, "Audio CD" ) == 0 )
				return;			// AudioAutoplay is disabled in MODULES.INI
		}		
		break;
    case DRIVE_RAMDISK:
		if( ramNoAutorun )
			return;
		break;
    default:
		return;
		break;
    }
    
    // if we've made it this far, it's a data cd so check if there's an autorun.inf
    // and if so get the "open" entry from it & execute it
    _makepath( szInfFilename, szDrive, NULL, "Autorun", ".inf" );
	
    GetPrivateProfileString( "autorun", "open", "", szOpenEntry, 
		sizeof(szOpenEntry), szInfFilename );
	
    if( !*szOpenEntry )
		return;
	
    strcpy( szCommandline, szDrive );
    strcat( szCommandline, szOpenEntry );
	
    memset( &sInfo, 0, sizeof(sInfo) );
    sInfo.cb=sizeof(sInfo);
    sInfo.wShowWindow=SW_SHOWNORMAL;
	
	
    bResult = CreateProcess( NULL, szCommandline, NULL, NULL, FALSE,
		CREATE_NEW_PROCESS_GROUP, NULL, szDrive, &sInfo, &pInfo );
    
    if(!bResult)
    {
		char lpMsgBuf[256];
		
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
			NULL, GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf, 0, NULL );
		
		MessageBox(NULL, lpMsgBuf, "ERROR:CreateProcess() failed", 
			MB_OK|MB_ICONINFORMATION );
		
		LocalFree( lpMsgBuf );
		return;
    }
	
    if(pInfo.hProcess)
		CloseHandle( pInfo.hProcess );
    if(pInfo.hThread)
		CloseHandle( pInfo.hThread );
}

// -----------------------------------------------------------------------------------------------
// used by autorun()
// -----------------------------------------------------------------------------------------------
unsigned char *LSBar::getAutorunDrives( void ) 
{
    HKEY hKey = NULL;
    DWORD dwType, dwSize = 0;
    unsigned char *pDriveData = NULL;
    char *lpzRegistryString =
		"Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer";
    LONG result;
	
    result = RegOpenKeyEx( HKEY_CURRENT_USER, lpzRegistryString, 
		(unsigned long)NULL, KEY_READ, &hKey );
	
    if (result == ERROR_SUCCESS)
    {
		result = RegQueryValueEx( hKey, "NoDriveTypeAutorun", NULL, &dwType, NULL, &dwSize );
		
		if (result == ERROR_SUCCESS)
		{
			pDriveData = (unsigned char *)malloc(dwSize);
			RegQueryValueEx( hKey, "NoDriveTypeAutorun", NULL, &dwType, pDriveData, &dwSize );
		}
		RegCloseKey( hKey );
    }
	
    if (!pDriveData)
    {
		pDriveData = (unsigned char *) malloc (1);
		
		*pDriveData = '\0';
    }
    return pDriveData;
}


BOOL CALLBACK LSBar::EnumChildWindowsProc(HWND hwnd, LPARAM lParam)
{
	char szBuffer[256];
	
	GetClassName(hwnd, szBuffer, sizeof(szBuffer));
	if (stricmp(szBuffer, "TWharfGlobalContainer"))
		return TRUE;
	
	GetWindowText(hwnd, szBuffer, sizeof(szBuffer));
	if (!stricmp(szBuffer, "LSSystray"))
	{
		*(HWND*)(lParam)=hwnd;
		return FALSE;
	}
	return TRUE;
}

int LSBar::initModule(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
	/////////////////////////////////////////////////////////////////////////////////////////////

   	WNDCLASSEX wc;
    UINT Msgs[6];
	int xwidth;
	
    dll = dllInst;
    parent = ParentWnd;
    strcpy(lsPath, szPath);
	
	// get windows version info
    memset (&os_info, 0, sizeof (os_info));
    os_info.dwOSVersionInfoSize = sizeof (os_info);
    GetVersionEx (&os_info);
    
    desktopWnd = GetDesktopWindow();

	// setup taskbar position
	if (settings.startButton) 
		barLeft = settings.startButtonSize + settings.trayIconSize;
	
	// set up screen sizes
    ScreenWidth = GetSystemMetrics(SM_CXSCREEN);
    ScreenHeight = GetSystemMetrics(SM_CYSCREEN);
	
    TRISIZE = settings.trayIconSize/2;
	
    // To do: check if this is a Dec Alpha processor. Under NT Alpha, the
    //        SwitchToThisWindow function does not exists
    SwitchToThisWindow = (void (__stdcall *)(HWND, int))GetProcAddress(GetModuleHandle("USER32.DLL"), "SwitchToThisWindow");

    // Register Desktop window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   	wc.lpfnWndProc = LSBar::WndProc;				// our window procedure
   	wc.hInstance = dllInst;					// hInstance of DLL
   	wc.lpszClassName = szAppName;			// our window class name
   	wc.style = 0;

   	if (!RegisterClassEx(&wc)) {
		MessageBox(parent,"Error registering window class","LSBar",MB_OK);
		return 1;
   	}

    // Register bar window class
   	memset(&wc,0,sizeof(wc));
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.cbWndExtra = 4;
   	wc.lpfnWndProc = LSBar::WndProcBar;			// our window procedure
   	wc.hInstance = dllInst;					// hInstance of DLL
   	wc.lpszClassName = szBar;			// our window class name
   	wc.style = CS_DBLCLKS;
   	
	if (!RegisterClassEx(&wc)) {
		MessageBox(parent,"Error registering window class, must be already registered",szBar,MB_OK);
		return 1;
   	}
	
	// Find the litestep main window
    hContWnd = GetLitestepWnd();
    
    // Set the maximized size for applications
    myLSBar->setMinMax();
	
	// Desktop Window (main window)
   	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,							// exstyles 
		szAppName,									// our window class name
		"LSDesktop",								// use description for a window title
        WS_POPUP|WS_CLIPSIBLINGS|WS_CLIPCHILDREN,	// styles
		0, 0,										// position 
		ScreenWidth,ScreenHeight,					// width & height of window
		hContWnd,									// parent window 
		NULL,										// no menu
		dllInst,									// hInstance of DLL
		NULL);										// no window creation data
	if (!hMainWnd) {						   
		MessageBox(parent,"Error creating window","LSBar",MB_OK);
		return 1;
    }

	// Set class pointer into window for access later
	SetWindowLong(hMainWnd, LS_GWL_CLASSPOINTER, (LONG)this);
	SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);
	
	// create the tooltip window
    hToolTips = CreateWindow(
		TOOLTIPS_CLASS,
		"LSDeskToolTip",
		TTS_ALWAYSTIP,
        CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		(HMENU) NULL,
		dll,
		NULL);
    if (!hToolTips) {
		MessageBox(parent, "Error creating tooltip window", "Desktop ToolTips Error", MB_OK);
		return 1;
    }
	
    SetWindowPos(hToolTips, HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);
	
	/// Create windows

	// list of tool tips
	toolTips = new LSToolTips(hBarWnd);

	// Bar Window
	if (settings.appBar) {
		if (settings.appBar && settings.stripBar) {
			xwidth = ScreenWidth - 64;
		} else {
			xwidth = ScreenWidth;
		}

   		hBarWnd = CreateWindowEx(
			WS_EX_TOPMOST | WS_EX_TOOLWINDOW,				// exstyles 
			szBar,											// our window class name
			"LSMSSysTray",									// use description for a window title
			WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN,	// styles
			0, ScreenHeight-settings.trayIconSize-10,		// position 
			xwidth, settings.trayIconSize+10,				// width & height of window
			hMainWnd,										// parent window 
			NULL,											// no menu
			dllInst,										// hInstance of DLL
			NULL);											// no window creation data
   		if (!hBarWnd) {						   
       		MessageBox(parent,"Error creating window",szBar,MB_OK);
			return 1;
		}

		// Set class pointer into window for access later
		SetWindowLong(hBarWnd, LS_GWL_CLASSPOINTER, (LONG)this);
		SetWindowLong(hBarWnd, GWL_USERDATA, magicDWord);

		// task bar
		taskBar = new LSTaskBar(this);

		// Register desktop-specific LS messages
		Msgs[0] = LM_GETREVID;
		Msgs[1] = LM_CHECKFORAPPBAR;
		Msgs[2] = LM_REPAINT;
		Msgs[3] = 0;
		SendMessage(parent, LM_REGISTERMESSAGE, (WPARAM)hMainWnd, (LPARAM)Msgs);
	}

	// tray window manager
	trayWnds = new LSTrayWindowManager(this);

	// Task Bar setup
	if (settings.appBar) {
		
		// Create our double buffer for icons drawing
		HDC dc = GetDC(parent);
		bufferDC = CreateCompatibleDC(dc);
		bufferBmp = CreateCompatibleBitmap(dc, 32, 32);
		oldbBmp = (HBITMAP)SelectObject(bufferDC, bufferBmp);
		ReleaseDC(parent, dc);

		SetWindowPos(hBarWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
		ShowWindow(hBarWnd,SW_SHOWNORMAL);
		GetWindowRect(hBarWnd, &taskBarRect);
		if (settings.autoHide) 
			myLSBar->HideBar();

		ShowWindow(trayWnds->hTrayWnd,SW_SHOWNORMAL);

		SetActiveWindow(hMainWnd);
		// This function is quick. a 50ms timer is not a problem 
		if (settings.autoHide) 
			SetTimer( hBarWnd, 0, 50, NULL);
	}

	// show the main window
	SetCursor(LoadCursor(NULL,IDC_ARROW));
	SetWindowPos(hMainWnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	return 0;
}

// -------------------------------------------------------------------------------------------------------
// cleanup (opposite of init()). Destroys the window, unregisters the window class
void LSBar::quitModule(HINSTANCE dllInst) { 
    int Msgs[6];
    
    KillTimer(hMainWnd, htimer);
    if (settings.autoHide) 
		KillTimer(hBarWnd, 0);
    if (hideTimerActive) {
		KillTimer(hBarWnd, 1); 
		hideTimerActive=FALSE;
    }
    resetManager();

	delete trayWnds;

	if (settings.appBar) {
		delete taskBar;
	}

	DestroyWindow(hBarWnd); // delete our window
	UnregisterClass(szBar,dllInst); // unregister window class
	
    resetMinMax();
	
    SelectObject(bufferDC, oldbBmp);
    DeleteObject(bufferBmp);
	//Taskbar skin
	if (settings.appBar) {
		DeleteObject(settings.taskBMP.bitmap);
		DeleteObject(settings.taskbtnskinBMP[0].bitmap);
		DeleteObject(settings.taskbtnleftBMP[0].bitmap);
		DeleteObject(settings.taskbtnrightBMP[0].bitmap);
		DeleteObject(settings.taskbtnskinBMP[1].bitmap);
		DeleteObject(settings.taskbtnleftBMP[1].bitmap);
		DeleteObject(settings.taskbtnrightBMP[1].bitmap);
		DeleteObject(settings.tasktrayskinBMP.bitmap);
		DeleteObject(settings.tasktrayleftBMP.bitmap);
		DeleteObject(settings.tasktrayrightBMP.bitmap);
		DeleteObject(settings.startbuttonskinBMP.bitmap);
		DeleteObject(settings.startbuttonleftBMP.bitmap);
		DeleteObject(settings.startbuttonrightBMP.bitmap);
	}
	//Taskbar skin
    DeleteDC(bufferDC);
	
    DestroyWindow(hMainWnd); // delete our window
    if (hToolTips)
    {
		DestroyWindow (hToolTips);
		hToolTips = NULL;
    }
	
	Msgs[0] = LM_GETREVID;
	Msgs[1] = LM_CHECKFORAPPBAR;
	Msgs[2] = LM_REPAINT;
	Msgs[3] = LM_ADDWINDOW;
	Msgs[4] = LM_REMOVEWINDOW;
	Msgs[5] = 0;
	SendMessage(parent, LM_UNREGISTERMESSAGE, (WPARAM) hMainWnd, (LPARAM) Msgs);
	
    UnregisterClass(szAppName,dllInst); // unregister window class
}

LRESULT LSBar::WindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
	case LM_GETREVID:
		{
			char *buf = (char *) lParam;
			
			if (wParam == 0) {
				strcpy(buf, "desktop.dll: ");
				strcat(buf, &rcsRevision[11]);
				buf[strlen(buf)-1] = '\0';
			} else if (wParam == 1) {
				strcpy(buf, &rcsId[1]);
				buf[strlen(buf)-1] = '\0';
			} else {
				strcpy(buf, "");
			}
			return strlen(buf);
		}
		
	case WM_DISPLAYCHANGE:
		{	
            // Screen resolution has changed. Change things accordingly
			
            int cxScreen = LOWORD(lParam); 
            int cyScreen = HIWORD(lParam);
            if (settings.appBar) {
                RECT r;
				if (barHiden) ShowBar();
                r = taskBarRect;
                r.right -= (ScreenWidth - cxScreen);
                r.top -= (ScreenHeight - cyScreen);
                r.bottom -= (ScreenHeight - cyScreen);
				SetWindowPos(hBarWnd, 0, r.left, r.top, r.right-r.left, r.bottom-r.top, SWP_NOZORDER);
				GetWindowRect(hBarWnd, &taskBarRect);
                r.left = 6+barLeft;
                r.top = 3;
                r.right = cxScreen - 6 - barLeft;
                r.bottom = settings.trayIconSize+8;
                MoveWindow(taskBar->hTasksWnd, r.left, r.top, r.right-r.left, r.bottom-r.top, TRUE);
			}

            ScreenWidth = cxScreen;
            ScreenHeight = cyScreen;

			int i;
            trayWnds->packScreenTray();
            for (i=0;i<sizeof(trayWnds)/sizeof(trayType);i++) {
                if ((*trayWnds)[i].trayWnd) {
                    SetWindowPos((*trayWnds)[i].trayWnd, 0, (*trayWnds)[i].x, (*trayWnds)[i].y, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
				}
			}
		}
        return 0;
		
	case WM_DEVICECHANGE:
		{
			// A device has changed in the system
			PDEV_BROADCAST_HDR pdbch;
			PDEV_BROADCAST_VOLUME pdbcv;
			if (wParam != DBT_DEVICEARRIVAL) return TRUE;
			pdbch = (PDEV_BROADCAST_HDR) lParam;
			switch (pdbch->dbch_devicetype) {
			case DBT_DEVTYP_VOLUME:
				pdbcv = (PDEV_BROADCAST_VOLUME) pdbch;
				if (pdbcv->dbcv_flags == DBTF_MEDIA)  {
					int i;
					for (i =0; i< 26;i++) {
						if (pdbcv->dbcv_unitmask & (1 << i)) {
							if( !(GetAsyncKeyState( VK_SHIFT ) & 0x8000) )
								autorun(i); // Call autorun on a specific drive
						}
					}
				}
				return TRUE;
			default:
				return TRUE;
			}
		}
	case WM_MOUSEACTIVATE:
		PostMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam)); // Close any popup open
		return MA_ACTIVATE;
	case WM_ACTIVATE:
		SendMessage(parent, LM_LSSELECT, 0, 0); // Tells litestep it has been selected
		if (LOWORD(wParam)) SetActiveWindow(parent);
		return 0;
	case WM_ENDSESSION:
	case WM_QUERYENDSESSION:
		return SendMessage(parent,message,wParam,lParam);
	case WM_CREATE:
		return 0;
	case WM_ERASEBKGND:
		{
			PaintDesktop( (HDC) wParam );
			return TRUE;
		}
	case LM_REPAINT: // Manually ask for a paint (stupid)
	case WM_PAINT:
		{ // update from doublebuffer
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd,&ps);
			
			PaintDesktop(hdc);
			if (!settings.appBar && np++ == 0) // If this is the first time we paint, tell it to litestep
				PostMessage(parent, LM_FIRSTDESKTOPPAINT, 0, 0);
			EndPaint(hwnd,&ps);
		}
		return 0;
	case WM_SYSCOMMAND:
		{
			switch (wParam) {
			case SC_CLOSE: // stupid but works
				PostMessage(parent,WM_KEYDOWN,LM_SHUTDOWN,0);
				return 0;
			default:
				break;
			}
			
			break;
		}
	case WM_KEYDOWN:
		{
			int i=0;
			i++;
		}
	case WM_KEYUP:
		{ // forward
			PostMessage(parent,message,wParam,lParam);
		}
		return 0;
	case WM_HOTKEY:
		{
			int i=0;
			i++;
		}
	case WM_WINDOWPOSCHANGING:
		{
			// Trap windowposchanging messages
			WINDOWPOS *c = (WINDOWPOS*)lParam;
			c->hwndInsertAfter = HWND_BOTTOM;
			c->flags |= SWP_NOMOVE | SWP_NOSIZE;
		}
		return 0;
	case WM_NCPAINT: // one more security
		if (!wParam)
			SetWindowPos(hwnd, HWND_BOTTOM, 0, 0, 0, 0, SWP_NOSIZE|SWP_NOMOVE);
		return 0;
	case WM_RBUTTONUP: // Open popup menu
		SendMessage(parent, LM_POPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_LBUTTONUP:
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case WM_RBUTTONDOWN: // Close popup menu
	case WM_LBUTTONDOWN:
	case WM_MBUTTONDOWN:
		SendMessage(parent, LM_HIDEPOPUP, (int)HIWORD(lParam), (int)LOWORD(lParam));
		return 0;
	case LM_MINMAXWIN:
		{
			int i;
			i = taskBar->inWinList((HWND)wParam);
			if (i != -1)
				MinMaxWindow(i);
		}
		break;
    }
	return DefWindowProc(hwnd,message,wParam,lParam);
}

/*
$Log: LSBar.cpp,v $
Revision 1.5  2000/04/23 16:53:16  nexter
Converted more bang commads to use LPCSTR

Revision 1.1.1.1  2000/01/28 05:57:35  headius
Import of Litestep into new cvs

Revision 1.7  2000/01/21 05:58:11  headius
Multiple fixes for AppBtnClass bug, removed all hook code

Revision 1.6  2000/01/19 06:54:51  headius
Updates to fix problems with windows not unregistering, and a few memory leaks.

Revision 1.5  2000/01/17 04:29:11  headius
Rewrite to remove window list logic, not use global winList array, better memory management, speed enhancements.
Tooltips on task buttons will not work for now.

Revision 1.4  2000/01/16 08:59:58  headius
Fixes for systray icons without taskbar bug and desktop window showing in sysvwm bug.

Revision 1.3  2000/01/09 23:35:57  headius
Modifications to fix size and painting

Revision 1.2  1999/11/11 04:30:48  headius
Added fix for desktop and child windows not being set visible

Revision 1.94  1999/10/19 00:15:19  jugg
*** empty log message ***

  Revision 1.64  1998/11/17 19:25:49  cyberian
  *** empty log message ***
  
	Revision 1.53  1998/11/07 00:58:46  bryan
	finally fixed the problems. I hate it when someone changes the size of
	something and then doesn't make sure it's been carried through the the rest
	of the source. The message passing stuff now works.
	
	  Revision 1.52  1998/11/06 19:11:52  bryan
	  Added automatic versioning info. The CVS will take care of the
	  versioning numbers.
	  Bind !About to a key (and !About Detailed)
	  
		*/
