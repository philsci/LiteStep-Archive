/*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
04/25/00 - Joachim Calvert (NeXTer)
  - Complete rewrite from scratch, 2nd edition. The first edition
    accidentally got overwritten when I had finished it...
****************************************************************************/

#include <stdio>
#include <windows>
#include <commctrl>

#include "shortcut.h"
#include "../lsapi/lsapi.h"
#include "../lsapi/safestr.h"

using namespace std;

//****************************************************************************
// Application Constants
const char szAppName[] = "ShortcutClass"; // Our window class, etc
const char dllName[] = "shortcut.dll";   // Our DLL name
const char rcsRevision[] = "$Revision: 1.1 $"; // Our Version
const char rcsId[] = "$Id: shortcut.cpp,v 1.1 2000/04/25 00:31:32 nexter Exp $"; // The Full RCS ID.


ShortcutFactory* shortcutFactory;
HWND desktopWnd;


int initModuleEx(HWND parentWnd, HINSTANCE, LPCSTR)
{
  int code;

  desktopWnd = FindWindow("DesktopBackgroundClass", NULL);
  if (!desktopWnd)
    desktopWnd = GetDesktopWindow();

  new ShortcutFactory(shortcutFactory, parentWnd, code);

  return code;
}


void quitModule(HINSTANCE)
{
  delete shortcutFactory;
}

//=========================================================
// ShortcutFactory ////////////////////////////////////////
//=========================================================

ShortcutFactory::ShortcutFactory(ShortcutFactory*& self, HWND parentWnd, int& code):
Window(szAppName)
{
  self = this;
  shortcutHints = CreateWindow
  (
    TOOLTIPS_CLASS, NULL, TTS_ALWAYSTIP,
    CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
    NULL, NULL, hInstance, NULL
  );
  if (shortcutHints)
    SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);

  createWindow(WS_EX_TOOLWINDOW, "ShortcutFactory", WS_POPUP,
               0, 0, 0, 0, parentWnd);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  createShortcuts();
}


ShortcutFactory::~ShortcutFactory()
{
  destroyWindow();
}


void ShortcutFactory::relayHintMessage(HWND hWnd, Message& message)
{
  MSG hintMessage = {hWnd, message.uMsg, message.wParam, message.lParam};

  if (!shortcutHints)
    return;
  SendMessage(shortcutHints, TTM_RELAYEVENT, 0, LPARAM(&hintMessage));
  SetWindowPos(shortcutHints, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}


void ShortcutFactory::addHint(HWND hWnd, LPSTR caption)
{
  TOOLINFO ti;
  RECT clientRect;

  if (!shortcutHints)
    return;
  GetClientRect(hWnd, &clientRect);
  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = TTF_SUBCLASS;
  ti.hwnd = hWnd;
  ti.uId = 0;
  ti.rect = clientRect;
  ti.hinst = hInstance;
  ti.lpszText = caption;
  ti.lParam = 0;
  SendMessage(shortcutHints, TTM_ADDTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::removeHint(HWND hWnd)
{
  TOOLINFO ti;
  RECT emptyRect = {0, 0, 0, 0};

  if (!shortcutHints)
    return;
  ti.cbSize = sizeof(TOOLINFO);
  ti.uFlags = 0;
  ti.hwnd = hWnd;
  ti.uId = 0;
  ti.rect = emptyRect;
  ti.hinst = hInstance;
  ti.lpszText = NULL;
  ti.lParam = 0;
  SendMessage(shortcutHints, TTM_DELTOOL, 0, LPARAM(&ti));
}


void ShortcutFactory::createShortcuts()
{
  char configLine[MAX_LINE_LENGTH];
  FILE* step = LCOpen(NULL);
  DWORD groupNumber;
  ShortcutMap::iterator smIter;
  Shortcut* newShortcut;

  if (step)
  {
    while (LCReadNextConfig(step, "*shortcut", configLine, MAX_LINE_LENGTH))
    {
      newShortcut = new Shortcut(configLine, groupNumber);
      smIter = shortcutGroups.find(groupNumber);
      if (smIter == shortcutGroups.end())
        shortcutGroups.insert(ShortcutMap::value_type(groupNumber, newShortcut));
      else
      {
        newShortcut->append(smIter->second);
        smIter->second = newShortcut;
      }
    }
    LCClose(step);
  }
}


void ShortcutFactory::bangToggleGroup(HWND sender, LPCSTR args)
{
  char group[MAX_LINE_LENGTH];
  LPCSTR nextGroup = args;
  ShortcutMap::iterator smIter;

  while (GetToken(nextGroup, group, &nextGroup, false))
  {
    smIter = shortcutFactory->shortcutGroups.find(atoi(group));
    if (smIter != shortcutFactory->shortcutGroups.end())
      if (smIter->second)
        smIter->second->setVisible();
  }
}


void ShortcutFactory::bangShowGroup(HWND sender, LPCSTR args)
{
  char group[MAX_LINE_LENGTH];
  LPCSTR nextGroup = args;
  ShortcutMap::iterator smIter;

  while (GetToken(nextGroup, group, &nextGroup, false))
  {
    smIter = shortcutFactory->shortcutGroups.find(atoi(group));
    if (smIter != shortcutFactory->shortcutGroups.end())
      if (smIter->second)
        smIter->second->setVisible(1);
  }
}


void ShortcutFactory::bangHideGroup(HWND sender, LPCSTR args)
{
  char group[MAX_LINE_LENGTH];
  LPCSTR nextGroup = args;
  ShortcutMap::iterator smIter;

  while (GetToken(nextGroup, group, &nextGroup, false))
  {
    smIter = shortcutFactory->shortcutGroups.find(atoi(group));
    if (smIter != shortcutFactory->shortcutGroups.end())
      if (smIter->second)
        smIter->second->setVisible(-1);
  }
}


void ShortcutFactory::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onGetRevId, LM_GETREVID)
  END_MESSAGEPROC
}


void ShortcutFactory::onCreate(Message& message)
{
  int lsMessages[] = {LM_GETREVID, 0};

  SendMessage(hParent, LM_REGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

  AddBangCommand("!shortcuttogglegroup", bangToggleGroup);
  AddBangCommand("!shortcutshowgroup", bangShowGroup);
  AddBangCommand("!shortcuthidegroup", bangHideGroup);
}


void ShortcutFactory::onDestroy(Message& message)
{
  ShortcutMap::iterator smIter;
  int lsMessages[] = {LM_GETREVID, 0};

  for (smIter = shortcutGroups.begin(); smIter != shortcutGroups.end(); smIter++)
    if (smIter->second)
      delete smIter->second;

  if (shortcutHints)
    DestroyWindow(shortcutHints);

  SendMessage(hParent, LM_UNREGISTERMESSAGE, WPARAM(hWnd), LPARAM(lsMessages));

  RemoveBangCommand("!shortcuttogglegroup");
  RemoveBangCommand("!shortcutshowgroup");
  RemoveBangCommand("!shortcuthidegroup");
}


void ShortcutFactory::onGetRevId(Message& message)
{
  char* buf = (char*)(message.lParam);

  switch (message.wParam)
  {
    case 0:
      sprintf(buf, "shortcut.dll: %s", &rcsRevision[11]);
      buf[strlen(buf) - 1] = '\0';
      break;
    case 1:
      strcpy(buf, &rcsId[1]);
      buf[strlen(buf) - 1] = '\0';
      break;
    default:
      strcpy(buf, "");
  }
  message.lResult = strlen(buf);
}


//=========================================================
// Shortcut ///////////////////////////////////////////////
//=========================================================

Shortcut::Shortcut(LPCSTR szLine, DWORD& group):
Window(szAppName),
next(NULL),
riCurrent(NULL),
caption(NULL),
command(NULL),
commandArgs(NULL),
state(ssNormal),
startTopMost(false),
startHidden(false),
left(0),
top(0),
width(32),
height(32)
{
  int relLeft;
  int relTop;

  memset(&riNormal, 0, sizeof(RegionImage));
  memset(&riHover, 0, sizeof(RegionImage));
  memset(&riClick, 0, sizeof(RegionImage));

  group = parseConfig(szLine);

  relLeft = (left < 0 ? GetSystemMetrics(SM_CXSCREEN) + left : left);
  relTop = (top < 0 ? GetSystemMetrics(SM_CYSCREEN) + top : top);

  createWindow((startTopMost ? WS_EX_TOPMOST | WS_EX_TOOLWINDOW : WS_EX_TOOLWINDOW),
               "Shortcut", (startTopMost ? WS_POPUP : WS_CHILD),
               relLeft, relTop, width, height, desktopWnd);
  SetWindowLong(hWnd, GWL_USERDATA, magicDWord);

  setImage(riNormal);
  if (!startHidden)
    ShowWindow(hWnd, SW_SHOW);

  if (caption)
    shortcutFactory->addHint(hWnd, caption);
}


Shortcut::~Shortcut()
{
  if (next)
    delete next;
  clear();
  shortcutFactory->removeHint(hWnd);
  destroyWindow();
}


DWORD Shortcut::parseConfig(LPCSTR szConfigLine)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR nextToken = szConfigLine;
  DWORD result;

  clear();

  GetToken(nextToken, NULL, &nextToken, false);
  if (GetToken(nextToken, token, &nextToken, false))
  {
    caption = new char[StrLen(token) + 1];
    StrCopy(caption, token);
  }

  if (GetToken(nextToken, token, &nextToken, false))
    left = atoi(token);
  if (GetToken(nextToken, token, &nextToken, false))
    top = atoi(token);

  if (GetToken(nextToken, token, &nextToken, false))
    riNormal.image = LoadLSImage(token, NULL);
  if (GetToken(nextToken, token, &nextToken, false))
    riHover.image = LoadLSImage(token, NULL);
  if (GetToken(nextToken, token, &nextToken, false))
    riClick.image = LoadLSImage(token, NULL);

  if (GetToken(nextToken, token, &nextToken, false))
  {
    if (token[0] == '#')
      result = atoi(&token[1]);
    startHidden = strchr(token, 'h');
    startTopMost = strchr(token, 't');
  }

  if (GetToken(nextToken, token, &nextToken, false))
  {
    command = new char[StrLen(token) + 1];
    StrCopy(command, token);
  }
  if (nextToken)
  {
    commandArgs = new char[StrLen(nextToken) + 1];
    StrCopy(commandArgs, nextToken);
  }

  if (riNormal.image)
    riNormal.region = BitmapToRegion(riNormal.image, RGB(255, 0, 255), 0x101010, 0, 0);
  if (riHover.image)
    riHover.region = BitmapToRegion(riHover.image, RGB(255, 0, 255), 0x101010, 0, 0);
  if (riNormal.image)
    riClick.region = BitmapToRegion(riClick.image, RGB(255, 0, 255), 0x101010, 0, 0);

  return result;
}


void Shortcut::setVisible(int visible)
{
  if (!visible)
    ShowWindow(hWnd, (IsWindowVisible(hWnd) ? SW_HIDE : SW_SHOW));
  else
    ShowWindow(hWnd, (visible > 0 ? SW_SHOW : SW_HIDE));
  if (next)
    next->setVisible(visible);
}


void Shortcut::setImage(RegionImage& regionImage)
{
  if (!regionImage.image || (&regionImage == riCurrent))
    return;

  HRGN windowRgn = CreateRectRgn(0, 0, 0, 0);
  RECT clientRect;

  riCurrent = &regionImage;
  GetLSBitmapSize(riCurrent->image, &width, &height);
  SetWindowPos(hWnd, HWND_TOP, 0, 0, width, height, SWP_NOZORDER | SWP_NOMOVE | SWP_NOACTIVATE);
  CombineRgn(windowRgn, riCurrent->region, NULL, RGN_COPY);
  SetWindowRgn(hWnd, windowRgn, true);
  GetClientRect(hWnd, &clientRect);
  InvalidateRect(hWnd, &clientRect, true);
}


void Shortcut::append(Shortcut* shortcut)
{
  next = shortcut;
}


void Shortcut::clear()
{
  if (caption)
    delete[] caption;
  if (command)
    delete[] command;
  if (commandArgs)
    delete[] commandArgs;
  if (riNormal.image)
    DeleteObject(riNormal.image);
  if (riNormal.region)
    DeleteObject(riNormal.region);
  if (riHover.image)
    DeleteObject(riHover.image);
  if (riHover.region)
    DeleteObject(riHover.region);
  if (riClick.image)
    DeleteObject(riClick.image);
  if (riClick.region)
    DeleteObject(riClick.region);
  caption = NULL;
  command = NULL;
  commandArgs = NULL;
  memset(&riNormal, 0, sizeof(RegionImage));
  memset(&riHover, 0, sizeof(RegionImage));
  memset(&riClick, 0, sizeof(RegionImage));
}


void Shortcut::windowProc(Message& message)
{
  BEGIN_MESSAGEPROC
    MESSAGE(onCreate, WM_CREATE)
    MESSAGE(onDestroy, WM_DESTROY)
    MESSAGE(onMouseMove, WM_MOUSEMOVE)
    MESSAGE(onMouseLeave, WM_MOUSELEAVE)
    MESSAGE(onLButtonDown, WM_LBUTTONDOWN)
    MESSAGE(onLButtonUp, WM_LBUTTONUP)
    MESSAGE(onPaint, WM_PAINT)
    MESSAGE(onDisplayChange, WM_DISPLAYCHANGE)
    MESSAGE(onWindowPosChanging, WM_WINDOWPOSCHANGING)
    REJECT_MESSAGE(WM_ERASEBKGND)
  END_MESSAGEPROC
}


void Shortcut::onCreate(Message& message)
{
}


void Shortcut::onDestroy(Message& message)
{
}


void Shortcut::onMouseMove(Message& message)
{
  TRACKMOUSEEVENT trackMouseEvent;
  {
    TRACKMOUSEEVENT& tme = trackMouseEvent;

    tme.cbSize = sizeof(TRACKMOUSEEVENT);
    tme.dwFlags = TME_LEAVE;
    tme.hwndTrack = hWnd;
    tme.dwHoverTime = HOVER_DEFAULT;
  }
  TrackMouseEvent(&trackMouseEvent);

  if (state != ssNormal)
    return;

  state = ssHover;
  setImage(riHover);

  shortcutFactory->relayHintMessage(hWnd, message);
}


void Shortcut::onMouseLeave(Message& message)
{
  if (state == ssNormal)
    return;

  state = ssNormal;
  setImage(riNormal);
}


void Shortcut::onLButtonDown(Message& message)
{
  if (state == ssClick)
    return;

  state = ssClick;
  setImage(riClick);
}


void Shortcut::onLButtonUp(Message& message)
{
  char buffer[MAX_LINE_LENGTH];

  if (state != ssClick)
    return;

  state = ssNormal;
  setImage(riNormal);

  if (command)
  {
    if (commandArgs)
      sprintf(buffer, "\"%s\" %s", command, commandArgs);
    else
      sprintf(buffer, "\"%s\"", command);
    LSExecute(hWnd, buffer, SW_SHOWDEFAULT);
  }
}


void Shortcut::onPaint(Message& message)
{
  HDC hDC;
  HDC sourceDC;
  PAINTSTRUCT paintStruct;
  HBITMAP oldImage;

  if (!riCurrent)
    return;
  hDC = BeginPaint(hWnd, &paintStruct);
  sourceDC = CreateCompatibleDC(hDC);
  oldImage = HBITMAP(SelectObject(sourceDC, riCurrent->image));
  BitBlt(hDC, 0, 0, width, height, sourceDC, 0, 0, SRCCOPY);
  SelectObject(sourceDC, oldImage);
  DeleteDC(sourceDC);
  EndPaint(hWnd, &paintStruct);
}


void Shortcut::onDisplayChange(Message& message)
{
  int newLeft;
  int newTop;

  newLeft = (left < 0 ? message.lParamLo + left : left);
  newTop = (top < 0 ? message.lParamHi + top : top);
  SetWindowPos(hWnd, HWND_TOP, newLeft, newTop, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}


void Shortcut::onWindowPosChanging(Message& message)
{
  WINDOWPOS& windowPos = *(WINDOWPOS*)(message.lParam);

  if (!changeZOrder)
    windowPos.flags |= SWP_NOZORDER;
  changeZOrder = false;
}

