

  It came to my knowledge that installing LiteSTEP under NT is not very difficult :

  - Use regedit.
  - Go to key HKLM\SOFTWARE\Microsoft\Windows NT\Current Version\Winlogon\
  - Change the data string "Shell" (currently to EXPLORER.EXE) to "yourpath\LITESTEP.exe"

  HOWEVER...
  ----------

  Yes... however... i've been told it prevents Explorer from opening more than 1 window at a time.

  I have NO IDEA why it does so... I'll work into this problem as soon as i have some better
  tracing tools for NT, but for now i cannot do anything.

  Just wait for an update... sorry for this problem.


  Also, please, don't try to use the LM78 module under NT, it will fail with a priviliedged
  instruction error message. That's normal, NT forbids any direct access to IO ports.


 