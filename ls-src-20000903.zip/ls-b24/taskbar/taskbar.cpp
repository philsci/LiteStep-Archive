/*   _     _ _           _
//  | |   (_) |_ ___ ___| |_ ___ _ __
//  | |   | | __/ _ Y __| __/ _ \ '_ \
//  | |___| | ||  __|__ \ ||  __/ |_) |
//  |_____|_|\__\___|___/\__\___| .__/
//                              |_|
//
//       module | taskbar
//      version | 1.0
//  description | display and manipulate running tasks
//       author | maduin <maduin@dasoft.org>
//      created | 21 feb 2000
*/

#define WIN32_LEAN_AND_MEAN
#define STRICT

#define WC_TASKBAR		TEXT("TaskbarLS")

#define EDGE_BOTTOM		0
#define EDGE_TOP		1

#define TIMER_AUTOHIDE	1
#define TIMER_UPDATE    2

// taskbar/tray control messages
#define TM_DOCK			(WM_USER + 0x100)
#define TM_APPLYSKIN	(WM_USER + 0x101)
#define TM_LAYOUT		(WM_USER + 0x102)
#define TM_GETWIDTH		(WM_USER + 0x200)

#include <windows.h>
#include <commctrl.h>
#include "../lsapi/lsapi.h"
#include "taskbar.h"
//#include "StartButtonSkin.h"

const int borderLeft = 4;
const int borderTop = 4;
const int borderRight = 4;
const int borderBottom = 4;

const int buttonBorderLeft = 4;
const int buttonBorderTop = 4;
const int buttonBorderRight = 4;
const int buttonBorderBottom = 4;

const int iconSize = 16;
const int iconSpacing = 3;
const int spacing = 3;

//
// Taskbar
//

Taskbar::Taskbar()
{
	hWnd = NULL;
	hInstance = NULL;
	hToolTips = NULL;

	edge = EDGE_BOTTOM;
	height = 0;
	width = 0;

	neededHeight = 0;

	screenHeight = 0;
	screenWidth = 0;

	active = FALSE;
	autoHidden = FALSE;
	mouseOver = FALSE;
	capture = NULL;

	startButton = FALSE;
	startMousePressed = FALSE;
	startMouseOver = FALSE;

	hTray = NULL;
	trayWidth = -1;

	skin = NULL;
	buttonSkin = NULL;
	activeButtonSkin = NULL;
	startButtonSkin = NULL;
	traySkin = NULL;

	font = NULL;
}

Taskbar::~Taskbar()
{
	// ...
}

UINT messages[] = {
	LM_LSSELECT,
	LM_GETMINRECT,
	LM_REDRAW,
	LM_WINDOWACTIVATED,
	LM_WINDOWCREATED,
	LM_WINDOWDESTROYED,
	0
};

void Taskbar::OnLoad( HINSTANCE hInstanceP )
{
	hInstance = hInstanceP;

	// get config variables from step.rc
	ReadConfig();

	// register taskbar window class
	WNDCLASSEX wc;
	memset( &wc, 0, sizeof(WNDCLASSEX) );

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_GLOBALCLASS;
	wc.lpfnWndProc = Taskbar::WndProc;
	wc.cbWndExtra = sizeof(Taskbar *);
	wc.hInstance = hInstance;
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.lpszClassName = WC_TASKBAR;

	if( !RegisterClassEx( &wc ) )
	{
		MessageBox( NULL, TEXT("Could not register taskbar window class."),
			TEXT("Taskbar"), MB_ICONERROR | MB_TOPMOST);

		return;
	}

	// create the taskbar window
	hWnd = CreateWindowEx( WS_EX_TOOLWINDOW,
		WC_TASKBAR,
		NULL,
		WS_POPUP,
		0, 0, 0, 0,
		GetLitestepWnd(),
		NULL,
		hInstance,
		(LPVOID) this );

	if( !hWnd )
	{
		MessageBox( NULL, TEXT("Could not create taskbar window."),
			TEXT("Taskbar"), MB_ICONERROR | MB_TOPMOST);

		return;
	}

	// create tooltips control
	hToolTips = CreateWindowEx( WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
		TOOLTIPS_CLASS,
		NULL,
		TTS_ALWAYSTIP | WS_POPUP,
		0, 0, 0, 0,
		hWnd,
		NULL,
		hInstance,
		NULL );

	// adjust the Z-order, size, position
	SetWindowPos( hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );

	// hide us from the VWM
	SetWindowLong( hWnd, GWL_USERDATA, magicDWord );

	// create font and compute needed height
	if( autoHide )
		autoHidden = TRUE;

	OnSettingChange();

	// show the window
	ShowWindow( hWnd, SW_SHOWNOACTIVATE );

	// adjust desktop area
	if( !autoHide )
	{
		RECT r;

		SystemParametersInfo( SPI_GETWORKAREA, 0, (LPVOID) &r, 0 );
		prevDeskArea = r;

		if( edge == EDGE_TOP )
			r.top = r.top + neededHeight - 2;
		else
			r.bottom = r.bottom - neededHeight - 2;

		SystemParametersInfo( SPI_SETWORKAREA, 0, (LPVOID) &r, SPIF_SENDCHANGE );
	}

	// create start menu button
	if (startButton) {
		pStartButton = new TaskbarButton(*this, NULL);
		pStartButton->SetSkin(startButtonSkin);
		pStartButton->SetCaption(startButtonText);
	}

	// enumerate current tasks, setup buttons and start update timer
	EnumWindows( Taskbar::EnumWindowsProc, (LPARAM) this );
	Layout();
	//SetTimer( hWnd, TIMER_UPDATE, 1000, NULL );

	// register for LS messages
	SendMessage( GetLitestepWnd(), LM_REGISTERMESSAGE,
		(WPARAM) hWnd, (LPARAM) ::messages );
}

void Taskbar::OnUnload()
{
	// shutdown timer
	KillTimer(hWnd, TIMER_UPDATE);

	// unregister messages
	SendMessage( GetLitestepWnd(), LM_UNREGISTERMESSAGE,
		(WPARAM) hWnd, (LPARAM) ::messages );

	// reset desktop area
	if( !autoHide )
		SystemParametersInfo( SPI_SETWORKAREA, 0, (LPVOID) &prevDeskArea, SPIF_SENDCHANGE );

	// destroy tooltips control
	if( hToolTips )
		DestroyWindow( hToolTips );

	// destroy window and unregister class
	if( hWnd )
		DestroyWindow( hWnd );

	UnregisterClass( WC_TASKBAR, hInstance );

	// release skins
	delete skin;
	delete buttonSkin;
	delete activeButtonSkin;
	delete traySkin;

	// release font
	DeleteObject( font );

	// release buttons
	for( size_t i = 0; i < buttons.size(); i++ )
	{
		delete buttons[i];
		buttons[i] = NULL;
	}

	buttons.clear();
}

void Taskbar::Invalidate( int x, int y, int cx, int cy )
{
	RECT r;

	r.left = x;
	r.top = y;
	r.right = x + cx;
	r.bottom = y + cy;

	InvalidateRect( hWnd, &r, FALSE );
}

TaskbarButton *Taskbar::GetCapture()
{
	return capture;
}

void Taskbar::SetCapture( TaskbarButton *button )
{
	::SetCapture( hWnd );
	capture = button;
}

void Taskbar::ReleaseCapture()
{
	::ReleaseCapture();
	capture = NULL;
}

TaskbarButton *Taskbar::ButtonAtPoint( int x, int y )
{
	if (pStartButton->HasPoint(x, y)) {
		return pStartButton;
	}

	for( size_t i = 0; i < buttons.size(); i++ )
	{
		if( buttons[i]->HasPoint( x, y ) )
			return buttons[i];
	}

	return NULL;
}

void Taskbar::ReadConfig()
{
	TCHAR buffer[MAX_PATH];
	TCHAR bufferLeft[MAX_PATH];
	TCHAR bufferRight[MAX_PATH];

	// autohide settings
	autoHide = GetRCBool( TEXT("AutoHideTaskbar"), TRUE );
	autoHideDelay = GetRCInt( TEXT("AutoHideDelay"), 500 );

	// edge
	if( GetRCString( TEXT("TaskbarEdge"), buffer, TEXT(""), 16 ) )
	{
		if( !stricmp( buffer, TEXT("TOP") ) )
			edge = EDGE_TOP;
	}

	// appearance
	msTaskbar = GetRCBool( TEXT("MSTaskbar"), TRUE );
	foreColor1 = GetRCColor( TEXT("LSTaskbarFore"), RGB( 192, 192, 192 ) );
	foreColor2 = GetRCColor( TEXT("LSTaskbarFore2"), RGB( 64, 64, 64 ) );
	backColor = GetRCColor( TEXT("LSTaskbarBack"), RGB( 128, 128, 128 ) );
	textColor = GetRCColor( TEXT("LSTaskbarText"), msTaskbar ? GetSysColor( COLOR_BTNTEXT ) : RGB( 255, 255, 255 ) );

	// start button
	startButton = GetRCBool( TEXT("TaskbarStartButton"), TRUE);
	startButtonSize = GetRCInt( TEXT("StartButtonSize"), 50);
	GetRCString(TEXT("StartButtonText"), startButtonText, "LiteStep", 255);
	if (GetRCString(TEXT("StartButtonSkin"), buffer, "", MAX_PATH)) {
		GetRCString(TEXT("StartButtonLeft"), bufferLeft, "", MAX_PATH);
		GetRCString(TEXT("StartButtonRight"), bufferRight, "", MAX_PATH);

		startButtonSkin = new TaskbarSkin(bufferLeft, buffer, bufferRight);
		//startButtonSkin->SetStretch(FALSE);
		startButtonSkin->SetBackColor(backColor);
	}

	// misc
	stripTaskbar = GetRCBool( TEXT("StripTaskbar"), TRUE );

	// skin settings
	noSkinShift = GetRCBool( TEXT("TaskbarNoSkinShift"), TRUE );
	noTextShift = GetRCBool( TEXT("TaskbarNoTextShift"), TRUE );

	// taskbar skin
	if( GetRCString( TEXT("TaskbarSkin"), buffer, TEXT(""), MAX_PATH ) )
	{
		GetRCString( TEXT("TaskbarLeft"), bufferLeft, TEXT(""), MAX_PATH );
		GetRCString( TEXT("TaskbarRight"), bufferRight, TEXT(""), MAX_PATH );

		skin = new TaskbarSkin( bufferLeft, buffer, bufferRight );
	}

	// taskbar button skin
	if( GetRCString( TEXT("TaskButtonSkin"), buffer, TEXT(""), MAX_PATH ) )
	{
		GetRCString( TEXT("TaskButtonLeft"), bufferLeft, TEXT(""), MAX_PATH );
		GetRCString( TEXT("TaskButtonRight"), bufferRight, TEXT(""), MAX_PATH );

		buttonSkin = new TaskbarSkin( bufferLeft, buffer, bufferRight );
	}

	// active taskbar button skin
	if( GetRCString( TEXT("TaskButtonSkinActive"), buffer, TEXT(""), MAX_PATH ) )
	{
		GetRCString( TEXT("TaskButtonLeftActive"), bufferLeft, TEXT(""), MAX_PATH );
		GetRCString( TEXT("TaskButtonRightActive"), bufferRight, TEXT(""), MAX_PATH );

		activeButtonSkin = new TaskbarSkin( bufferLeft, buffer, bufferRight );
	}

	// tray skin
	if( GetRCString( TEXT("TaskTraySkin"), buffer, TEXT(""), MAX_PATH ) )
	{
		GetRCString( TEXT("TaskTrayLeft"), bufferLeft, TEXT(""), MAX_PATH );
		GetRCString( TEXT("TaskTrayRight"), bufferRight, TEXT(""), MAX_PATH );

		traySkin = new TaskbarSkin( bufferLeft, buffer, bufferRight );
	}


}

void Taskbar::Layout()
{
	int buttonCount = buttons.size();

	if( buttonCount <= 0 )
	{
		// if no buttons, just repaint
		if( !autoHidden )
			InvalidateRect( hWnd, NULL, FALSE );

		return;
	}

	int availableWidth = width - borderLeft - borderRight;
	availableWidth = max( availableWidth, 0 );  // cannot be less than zero

	if( startButton )
	{
		availableWidth = availableWidth - startButtonSize - 4;
		availableWidth = max( availableWidth, 0 );
	}

	if( hTray )
	{
		if( trayWidth < 0 )
			trayWidth = (int) SendMessage( hTray, TM_GETWIDTH, 0, 0 );

		availableWidth = availableWidth - trayWidth - 4;
		availableWidth = max( availableWidth, 0 );
	}

	if( buttonCount > 1 )
	{
		availableWidth = availableWidth - (buttonCount - 1) * spacing;
		availableWidth = max( availableWidth, 0 );
	}

	int widthPerButton = availableWidth / buttonCount;
	int error = availableWidth % buttonCount;

	int x = borderLeft;
	int buttonHeight = height - borderTop - borderBottom;

	// put the start button in its place
	if (startButton) {
		pStartButton->Move(x, borderTop, startButtonSize, buttonHeight);
		x = x + startButtonSize + 4;
	}

	// set placement for each button
	for( size_t i = 0; i < buttons.size(); i++ )
	{
		TaskbarButton *button = buttons[i];

		if( error > 0 )
		{
			button->Move( x, borderTop, widthPerButton + 1, buttonHeight );
			x = x + widthPerButton + spacing + 1;

			error--;
		}
		else
		{
			button->Move( x, borderTop, widthPerButton, buttonHeight );
			x = x + widthPerButton + spacing;
		}
	}

	if( hTray )
		MoveWindow( hTray, x + spacing, borderTop, trayWidth, buttonHeight, FALSE );

	if( !autoHidden )
		InvalidateRect( hWnd, NULL, FALSE );
}

void Taskbar::SetWindowPosition()
{
	int realHeight;

	if( autoHidden )
		realHeight = 2;
	else
		realHeight = neededHeight - 2;

	if( edge == EDGE_TOP )
	{
		SetWindowPos( hWnd, NULL, -2, realHeight - neededHeight,
			(stripTaskbar ? screenWidth - 64 : screenWidth + 4),
			neededHeight, SWP_NOACTIVATE | SWP_NOZORDER );
	}
	else
	{
		SetWindowPos( hWnd, NULL, -2, screenHeight - realHeight,
			(stripTaskbar ? screenWidth - 64 : screenWidth + 4),
			neededHeight, SWP_NOACTIVATE | SWP_NOZORDER );
	}
}

void Taskbar::Dock( HWND hTrayP )
{
	if( hTray )
		SetParent( hTray, NULL );

	hTray = hTrayP;
	trayWidth = -1;

	ShowWindow( hTray, SW_HIDE );
	SetParent( hTray, hWnd );

	Layout();
	ShowWindow( hTray, SW_SHOWNOACTIVATE );
}

void Taskbar::ApplyTraySkin( HDC hDC, RECT &r )
{
	if( !traySkin )
	{
		if( !msTaskbar )
		{
			// simple 3D frame
			HBRUSH hbrBack;
			HPEN hpnFore;
			HPEN hpnTemp;

			hbrBack = CreateSolidBrush( backColor );
			FillRect( hDC, &r, hbrBack );
			DeleteObject( hbrBack );

			hpnFore = CreatePen( PS_SOLID, 1, foreColor1 );
			hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

			MoveToEx( hDC, r.left , r.bottom - 1, NULL );
			LineTo( hDC, r.right - 1, r.bottom - 1 );
			LineTo( hDC, r.right - 1, r.top );

			SelectObject( hDC, hpnTemp );
			DeleteObject( hpnFore );

			hpnFore = CreatePen( PS_SOLID, 1, foreColor2 );
			hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

			LineTo( hDC, r.left, r.top );
			LineTo( hDC, r.left, r.bottom - 1 );

			SelectObject( hDC, hpnTemp );
			DeleteObject( hpnFore );
		}
		else
		{
			// MS taskbar style
			DrawEdge( hDC, &r, BDR_SUNKENOUTER, BF_RECT | BF_MIDDLE );
		}
	}
	else
	{
		// skin
		traySkin->Apply( hDC, r.left, r.top, r.right - r.left, r.bottom - r.top );
	}
}

TaskbarButton *Taskbar::SearchForButtonByHandle( HWND hWnd )
{
	for( size_t i = 0; i < buttons.size(); i++ )
	{
		if( hWnd == buttons[i]->GetTask() )
			return buttons[i];
	}

	return NULL;
}

void Taskbar::OnActivate( BOOL becomingActive )
{
	active = becomingActive;

	if( becomingActive && autoHidden )
	{
		autoHidden = FALSE;
		SetWindowPosition();
	}
	else if( !becomingActive && autoHide )
	{
		// only hide if mouse is also not over taskbar
		if( !mouseOver )
		{
			autoHidden = TRUE;
			SetWindowPosition();
		}
	}
}

void Taskbar::OnDisplayChange()
{
	screenHeight = GetSystemMetrics( SM_CYSCREEN );
	screenWidth = GetSystemMetrics( SM_CXSCREEN );

	SetWindowPosition();
}

void Taskbar::OnGetMinRect( HWND hWnd, RECT *rectangle )
{
/*	TCHAR className[64];
	GetClassName( hWnd, className, 64 );

	TCHAR title[256];
	GetWindowText( hWnd, title, 256 );

	PrintLog( "GetMinRect - hWnd: %08X; className: %s; title: %s",
		hWnd, className, title ); */
}

void Taskbar::OnLButtonDown( int x, int y )
{
	TaskbarButton *button;

	if( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if( button ) {
		if (button == pStartButton) {
			if (edge == EDGE_TOP) {
				SendMessage(GetLitestepWnd(), LM_POPUP, 0, MAKELPARAM(0, height));
			} else {
				SendMessage(GetLitestepWnd(), LM_POPUP, 0, MAKELPARAM(0, screenHeight - height));
			}
		} else {
			button->OnLButtonDown( x, y );
		}
	}
}

void Taskbar::OnLButtonUp( int x, int y )
{
	TaskbarButton *button;

	if( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if( button )
		button->OnLButtonUp( x, y );
}

void Taskbar::OnMouseMove( int x, int y )
{
	mouseOver = TRUE;

	// is autohide enabled?
	if( autoHide )
	{
		// are we hidden?
		if( autoHidden )
		{
			// if hidden, unhide
			autoHidden = FALSE;
			SetWindowPosition();

			// timer to keep us visible
			SetTimer( hWnd, TIMER_AUTOHIDE, autoHideDelay, NULL );

			return;
		}

		// timer to keep us visible
		SetTimer( hWnd, TIMER_AUTOHIDE, autoHideDelay, NULL );
	}

	TaskbarButton *button;

	if( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if( button )
	{
		button->OnMouseMove( x, y );
		return;
	}

	POINT pt;
	RECT r;

	pt.x = x;
	pt.y = y;

	r.left = 2;
	r.top = 4;
	r.right = r.left + 64;
	r.bottom = height - 4;

	if( PtInRect( &r, pt ) )
		startMouseOver = TRUE;
}

void Taskbar::OnPaint( HDC hDC )
{
	HDC hdcScreen;
	HDC hdcBuffer;
	HBITMAP hbmBuffer;
	HBITMAP hbmTemp;

	hdcScreen = GetDC( NULL );
	hdcBuffer = CreateCompatibleDC( hdcScreen );
	hbmBuffer = CreateCompatibleBitmap( hdcScreen, width, height );
	hbmTemp = (HBITMAP) SelectObject( hdcBuffer, hbmBuffer );
	ReleaseDC( NULL, hdcScreen );

	if( !skin )
	{
		RECT r;
		GetClientRect( hWnd, &r );

		if( !msTaskbar )
		{
			// simple 3D frame
			HBRUSH hbrBack;
			HPEN hpnFore;
			HPEN hpnTemp;

			hbrBack = CreateSolidBrush( backColor );
			FillRect( hdcBuffer, &r, hbrBack );
			DeleteObject( hbrBack );

			hpnFore = CreatePen( PS_SOLID, 1, foreColor2 );
			hpnTemp = (HPEN) SelectObject( hdcBuffer, hpnFore );

			MoveToEx( hdcBuffer, r.left, r.bottom - 1, NULL );
			LineTo( hdcBuffer, r.right - 1, r.bottom - 1 );
			LineTo( hdcBuffer, r.right - 1, r.top );

			SelectObject( hdcBuffer, hpnTemp );
			DeleteObject( hpnFore );

			hpnFore = CreatePen( PS_SOLID, 1, foreColor1 );
			hpnTemp = (HPEN) SelectObject( hdcBuffer, hpnFore );

			LineTo( hdcBuffer, r.left, r.top );
			LineTo( hdcBuffer, r.left, r.bottom - 1 );

			SelectObject( hdcBuffer, hpnTemp );
			DeleteObject( hpnFore );
		}
		else
		{
			// MS taskbar style
			DrawEdge( hdcBuffer, &r, EDGE_RAISED, BF_RECT | BF_MIDDLE );
		}
	}
	else
	{
		// skin
		skin->Apply( hdcBuffer, 0, 0, width, height );
	}

	if (startButton) {
		pStartButton->OnPaint(hdcBuffer);
	}

	for( size_t i = 0; i < buttons.size(); i++ )
		buttons[i]->OnPaint( hdcBuffer );

	BitBlt( hDC, 0, 0, width, height, hdcBuffer, 0, 0, SRCCOPY );

	SelectObject( hdcBuffer, hbmTemp );
	DeleteObject( hbmBuffer );
	DeleteDC( hdcBuffer );
}

// OnRedraw
//

void Taskbar::OnRedraw( HWND hWnd, BOOL fFlash )
{
	/* TCHAR className[64];
	GetClassName( hWnd, className, 64 );

	TCHAR title[256];
	GetWindowText( hWnd, title, 256 );

	PrintLog( "Redraw - hWnd: %08X; className: %s; title: %s; fFlash: %d",
		hWnd, className, title, fFlash ); */

	TaskbarButton *button = SearchForButtonByHandle( hWnd );

	if( button )
		button->OnUpdate();
}

void Taskbar::OnRButtonDown( int x, int y )
{
	TaskbarButton *button;

	if( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if( button )
		button->OnRButtonDown( x, y );
}

void Taskbar::OnRButtonUp( int x, int y )
{
	TaskbarButton *button;

	if( capture )
		button = capture;
	else
		button = ButtonAtPoint( x, y );

	if( button )
		button->OnRButtonUp( x, y );
}

void Taskbar::OnSettingChange()
{
	if( font )
		DeleteObject( font );

	// create font
	NONCLIENTMETRICS ncm;
	ncm.cbSize = sizeof(NONCLIENTMETRICS);

	SystemParametersInfo( SPI_GETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS),
		&ncm, 0 );

	font = CreateFontIndirect( &ncm.lfCaptionFont );

	// compute needed height and set initial position
	TEXTMETRIC tm;
	HDC hDC;
	HFONT hfnTemp;

	hDC = GetDC( NULL );
	hfnTemp = (HFONT) SelectObject( hDC, font );

	GetTextMetrics( hDC, &tm );

	SelectObject( hDC, hfnTemp );
	ReleaseDC( NULL, hDC );

	neededHeight = max( (const int)(tm.tmHeight + tm.tmExternalLeading), iconSize );
	neededHeight = neededHeight + buttonBorderTop + buttonBorderBottom;
	neededHeight = neededHeight + borderTop + borderBottom;

	screenHeight = GetSystemMetrics( SM_CYSCREEN );
	screenWidth = GetSystemMetrics( SM_CXSCREEN );

	SetWindowPosition();
}

void Taskbar::OnSize( int widthP, int heightP )
{
	height = heightP;
	width = widthP;

	Layout();
}

void Taskbar::OnTimerAutoHide()
{
	POINT pt;
	RECT r;

	GetCursorPos( &pt );
	GetWindowRect( hWnd, &r );

	if( !PtInRect( &r, pt ) )
	{
		// if mouse moved off window, autohide
		KillTimer( hWnd, TIMER_AUTOHIDE );
		mouseOver = FALSE;

		if( !active )
		{
			// only hide if we're also not active
			autoHidden = TRUE;
			SetWindowPosition();
		}
	}
}

void Taskbar::OnTimerUpdate()
{
	for( size_t i = 0; i < buttons.size(); i++ )
	{
		if( GetForegroundWindow() == buttons[i]->GetTask() && !buttons[i]->IsActive() )
			buttons[i]->OnUpdate();
		else if( buttons[i]->IsActive() )
			buttons[i]->OnUpdate();
	}
}

void Taskbar::OnWindowActivated( HWND hApplication, BOOL fFullScreen )
{
	if( fFullScreen )
	{
		// window is going fullscreen, un-'always on top' ourself
		if( GetWindowLong( hWnd, GWL_EXSTYLE ) & WS_EX_TOPMOST )
		{
			SetWindowPos( hWnd, HWND_NOTOPMOST, 0, 0, 0, 0,
				SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );
		}
	}
	else
	{
		// make sure we're always on top
		if( !(GetWindowLong( hWnd, GWL_EXSTYLE ) & WS_EX_TOPMOST) )
		{
			SetWindowPos( hWnd, HWND_TOPMOST, 0, 0, 0, 0,
				SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE );
		}
	}

	// update buttons
	for( size_t i = 0; i < buttons.size(); i++ )
		buttons[i]->OnUpdate();
}

void Taskbar::OnWindowCreated( HWND hTask )
{
	TaskbarButton *button = new TaskbarButton( *this, hTask );
	buttons.push_back( button );

	Layout();
}

void Taskbar::OnWindowDestroyed( HWND hTask )
{
	vector<TaskbarButton *>::iterator i;

	for( i = buttons.begin(); i != buttons.end(); i++ )
	{
		TaskbarButton *button = *i;

		if( button->GetTask() == hTask )
		{
			delete button;
			buttons.erase( i );

			Layout();
			return;
		}
	}
}

BOOL Taskbar::OnWindowMessage( UINT nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult )
{
	lResult = 0;

	// relay mouse messages to tooltips control
	if( nMessage >= WM_MOUSEFIRST && nMessage <= WM_MOUSELAST )
	{
		MSG msg;

		msg.hwnd = hWnd;
		msg.message = nMessage;
		msg.wParam = wParam;
		msg.lParam = lParam;

		SendMessage( hToolTips, TTM_RELAYEVENT, 0, (LPARAM) &msg );
	}

	switch( nMessage )
	{
		case LM_LSSELECT:
		{
			OnWindowActivated( NULL, FALSE );
			return TRUE;
		}

		case LM_GETMINRECT:
		{
			OnGetMinRect( (HWND) wParam, (RECT *) lParam );
			return TRUE;
		}

		case LM_REDRAW:
		{
			OnRedraw( (HWND) wParam, (BOOL) lParam );
			return TRUE;
		}

		case LM_WINDOWACTIVATED:
		{
			OnWindowActivated( (HWND) wParam, (BOOL) lParam );
			return TRUE;
		}

		case LM_WINDOWCREATED:
		{
			OnWindowCreated( (HWND) wParam );
			return TRUE;
		}

		case LM_WINDOWDESTROYED:
		{
			OnWindowDestroyed( (HWND) wParam );
			return TRUE;
		}

		case WM_ACTIVATE:
		{
			OnActivate( (LOWORD(wParam) == WA_INACTIVE) ? FALSE : TRUE );
			return TRUE;
		}

		case WM_DISPLAYCHANGE:
		{
			OnDisplayChange();
			return TRUE;
		}

		case WM_LBUTTONDOWN:
		{
			OnLButtonDown( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_LBUTTONUP:
		{
			OnLButtonUp( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_MOUSEMOVE:
		{
			OnMouseMove( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hDC;

			if( !wParam )
				hDC = BeginPaint( hWnd, &ps );
			else
				hDC = (HDC) wParam;

			OnPaint( hDC );

			if( !wParam )
				EndPaint( hWnd, &ps );

			return TRUE;
		}

		case WM_RBUTTONDOWN:
		{
			OnRButtonDown( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_RBUTTONUP:
		{
			OnRButtonUp( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_SETTINGCHANGE:
		{
			OnSettingChange();
			return TRUE;
		}

		case WM_SIZE:
		{
			OnSize( (int) (short) LOWORD( lParam ), (int) (short) HIWORD( lParam ) );
			return TRUE;
		}

		case WM_TIMER:
		{
			switch( wParam )
			{
				case TIMER_AUTOHIDE:
				{
					OnTimerAutoHide();
					return TRUE;
				}

				case TIMER_UPDATE:
				{
					OnTimerUpdate();
					return TRUE;
				}
			}

			return FALSE;
		}

		case TM_DOCK:
		{
			Dock( (HWND) wParam );
			return TRUE;
		}

		case TM_APPLYSKIN:
		{
			RECT *r = (RECT *) lParam;
			ApplyTraySkin( (HDC) wParam, *r );

			return TRUE;
		}

		case TM_LAYOUT:
		{
			trayWidth = -1;
			Layout();

			return TRUE;
		}
	}

	return FALSE;
}

BOOL WINAPI Taskbar::EnumWindowsProc( HWND hWnd, LPARAM lParam )
{
	Taskbar *taskbar = (Taskbar *) lParam;

	if( taskbar && IsAppWindow( hWnd ) )
	{
		TaskbarButton *button = new TaskbarButton( *taskbar, hWnd );
		button->SetSkin(taskbar->buttonSkin);
		taskbar->buttons.push_back( button );
	}

	return TRUE;
}

LRESULT WINAPI Taskbar::WndProc( HWND hWnd, UINT nMessage, WPARAM wParam, LPARAM lParam )
{
	Taskbar *taskbar = (Taskbar *) GetWindowLong( hWnd, 0 );

	if( nMessage == WM_NCCREATE )
	{
		LPCREATESTRUCT pcs = (LPCREATESTRUCT) lParam;
		taskbar = (Taskbar *) pcs->lpCreateParams;

		taskbar->hWnd = hWnd;
		SetWindowLong( hWnd, 0, (LONG) taskbar );
	}

	if( taskbar )
	{
		LRESULT lResult;

		if( taskbar->OnWindowMessage( nMessage, wParam, lParam, lResult ) )
			return lResult;
	}

	return DefWindowProc( hWnd, nMessage, wParam, lParam );
}

//
// TaskbarButton
//

TaskbarButton::TaskbarButton( Taskbar &tb, HWND hWnd ) : container( tb )
{
	hTask = hWnd;
	skin = NULL;

	active = (GetForegroundWindow() == hTask);
	if (hTask) {
		caption = GetWindowCaption();
		// add tooltip
		TOOLINFO ti;
		memset( &ti, 0, sizeof(TOOLINFO) );

		ti.cbSize = sizeof(TOOLINFO);
		ti.hwnd = container.hWnd;
		ti.uId = (UINT) this;
		ti.lpszText = caption;

		SendMessage( container.hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti );
	}
	otherCaption = NULL;
	icon = GetIcon();

	mousePressed = FALSE;
	mouseOver = FALSE;

	x = 0;
	y = 0;
	height = 0;
	width = 0;

}

TaskbarButton::~TaskbarButton()
{
	delete caption;

	// delete tooltip
	TOOLINFO ti;
	memset( &ti, 0, sizeof(TOOLINFO) );

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = container.hWnd;
	ti.uId = (UINT) this;

	SendMessage( container.hToolTips, TTM_DELTOOL, 0, (LPARAM) &ti );
}

BOOL TaskbarButton::HasPoint( int xP, int yP )
{
	if( xP < (x + width) && xP >= x )
	{
		if( yP < (y + height) && yP >= y )
			return TRUE;
	}

	return FALSE;
}

void TaskbarButton::Move( int xP, int yP, int widthP, int heightP )
{
	x = xP;
	y = yP;
	height = heightP;
	width = widthP;

	// update tooltip
	TOOLINFO ti;
	memset( &ti, 0, sizeof(TOOLINFO) );

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = container.hWnd;
	ti.uId = (UINT) this;
	ti.rect.left = x;
	ti.rect.top = y;
	ti.rect.right = x + width;
	ti.rect.bottom = y + height;

	SendMessage( container.hToolTips, TTM_NEWTOOLRECT, 0, (LPARAM) &ti );
}

void TaskbarButton::OnLButtonDown( int, int )
{
	container.SetCapture( this );

	mousePressed = TRUE;
	container.Invalidate( x, y, width + 1, height + 1 );
}

void TaskbarButton::OnLButtonUp( int, int )
{
	mousePressed = FALSE;

	if( container.GetCapture() != this )
		return;

	container.ReleaseCapture();

	if( !mouseOver )
	{
		container.Invalidate( x, y, width + 1, height + 1 );
		return;
	}

	if( active )
	{
		// already active, minimize it
		ShowWindowAsync( hTask, SW_MINIMIZE );
	}
	else
	{
		if( !IsIconic( hTask ) )
		{
			// if not minimized, move to application's current desktop
			SendMessage( GetLitestepWnd(), LM_BRINGTOFRONT, 0, (LPARAM) hTask );
		}

		// undocumented call to switch window activation
		SwitchToThisWindow( hTask, 1 );
	}
}

void TaskbarButton::OnMouseMove( int mX, int mY )
{
	if( mouseOver != HasPoint( mX, mY ) )
	{
		mouseOver = !mouseOver;
		container.Invalidate( x, y, width + 1, height + 1 );
	}
}

void TaskbarButton::OnPaint( HDC hDC )
{
	RECT r;

	r.left = x;
	r.top = y;
	r.right = x + width;
	r.bottom = y + height;

	//TaskbarSkin *skin = container.buttonSkin;

	int skinShift = 0;
	int textShift = 0;

	BOOL drawPressed = active || (mouseOver && mousePressed);

	if( drawPressed )
	{
		if( container.activeButtonSkin )
			skin = container.activeButtonSkin;

		skinShift = container.noSkinShift ? 0 : 1;
		textShift = container.noTextShift ? 0 : 1;
	}

	if( !skin )
	{
		if( !container.msTaskbar )
		{
			// simple 3D frame
			HBRUSH hbrBack;
			HPEN hpnFore;
			HPEN hpnTemp;

			hbrBack = CreateSolidBrush( container.backColor );
			FillRect( hDC, &r, hbrBack );
			DeleteObject( hbrBack );

			hpnFore = CreatePen( PS_SOLID, 1, drawPressed ? container.foreColor1 : container.foreColor2 );
			hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

			MoveToEx( hDC, r.left, r.bottom - 1, NULL );
			LineTo( hDC, r.right - 1, r.bottom - 1 );
			LineTo( hDC, r.right - 1, r.top );

			SelectObject( hDC, hpnTemp );
			DeleteObject( hpnFore );

			hpnFore = CreatePen( PS_SOLID, 1, drawPressed ? container.foreColor2 : container.foreColor1 );
			hpnTemp = (HPEN) SelectObject( hDC, hpnFore );

			LineTo( hDC, r.left, r.top );
			LineTo( hDC, r.left, r.bottom - 1 );

			SelectObject( hDC, hpnTemp );
			DeleteObject( hpnFore );
		}
		else
		{
			// MS taskbar style
			DrawEdge( hDC, &r, drawPressed ? EDGE_SUNKEN : EDGE_RAISED, BF_RECT | BF_MIDDLE | BF_SOFT );
		}
	}
	else
	{
		// simple 3D frame
		HBRUSH hbrBack;

		hbrBack = CreateSolidBrush( container.backColor );
		FillRect( hDC, &r, hbrBack );
		DeleteObject( hbrBack );

		// skin
		skin->Apply( hDC, x + skinShift, y + skinShift, width, height );
	}

	r.left = r.left + buttonBorderLeft;
	r.top = r.top + buttonBorderTop;
	r.right = r.right - buttonBorderRight;
	r.bottom = r.bottom - buttonBorderBottom;

	OffsetRect( &r, textShift, textShift );

	if( icon && (r.right - r.left) >= iconSize )
	{
		int iconY = r.top + ((r.bottom - r.top) - iconSize + 1) / 2;

		DrawIconEx( hDC, r.left, iconY, icon, iconSize,
			iconSize, 0, NULL, DI_NORMAL );

		r.left = r.left + iconSize + iconSpacing;
	}

	COLORREF tempColor;
	HFONT tempFont;

	tempColor = SetTextColor( hDC, container.textColor );
	tempFont = (HFONT) SelectObject( hDC, container.font );
	SetBkMode( hDC, TRANSPARENT );

	if (hTask) {
		if (caption) {
			DrawText( hDC, caption, strlen( caption ), &r,
				DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS );
		}
	} else {
		if (otherCaption) {
			DrawText( hDC, otherCaption, strlen( otherCaption ), &r,
				DT_SINGLELINE | DT_VCENTER | DT_END_ELLIPSIS );
		}
	}


	SetTextColor( hDC, tempColor );
	SelectObject( hDC, tempFont );
}

void TaskbarButton::OnRButtonDown( int, int )
{
	container.SetCapture( this );

	mousePressed = TRUE;
	container.Invalidate( x, y, width + 1, height + 1 );
}

void TaskbarButton::OnRButtonUp( int, int )
{
	mousePressed = FALSE;

	if( container.GetCapture() != this )
		return;

	container.ReleaseCapture();

	if( !mouseOver )
	{
		container.Invalidate( x, y, width + 1, height + 1 );
		return;
	}

	HMENU systemMenu;
	systemMenu = GetSystemMenu( hTask, FALSE );

	WINDOWPLACEMENT wp;
	wp.length = sizeof(WINDOWPLACEMENT);
	GetWindowPlacement( hTask, &wp );

	// restore is enabled only if minimized or maximized (not normal)
	EnableMenuItem( systemMenu, SC_RESTORE, MF_BYCOMMAND |
		(wp.showCmd != SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// move is enabled only if normal
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
		(wp.showCmd == SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// size is enabled only if normal
	EnableMenuItem( systemMenu, SC_SIZE, MF_BYCOMMAND |
		(wp.showCmd == SW_SHOWNORMAL ? MF_ENABLED : MF_GRAYED) );

	// minimize is enabled only if not minimized
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
		(wp.showCmd != SW_SHOWMINIMIZED ? MF_ENABLED : MF_GRAYED) );

	// maximize is enabled only if not maximized
	EnableMenuItem( systemMenu, SC_MOVE, MF_BYCOMMAND |
		(wp.showCmd != SW_SHOWMAXIMIZED ? MF_ENABLED : MF_GRAYED) );

	// let application modify menu
	SendMessage( hTask, WM_INITMENUPOPUP, (WPARAM) systemMenu, MAKELPARAM( 0, TRUE ) );
	SendMessage( hTask, WM_INITMENU, (WPARAM) systemMenu, 0 );

	// display the menu
	POINT pt;
	GetCursorPos( &pt );

	int command = TrackPopupMenu( systemMenu,
		TPM_RETURNCMD | TPM_RIGHTBUTTON,
		pt.x, pt.y, 0,
		container.hWnd,
		NULL );

	if( command )
	{
		if( command != SC_MINIMIZE && command != SC_CLOSE )
			SetForegroundWindow( hTask );

		PostMessage( hTask, WM_SYSCOMMAND, (WPARAM) command, MAKELPARAM( pt.x, pt.y ) );
	}
	else
	{
		container.Invalidate( x, y, width + 1, height + 1 );
	}
}

void TaskbarButton::OnUpdate()
{
	bool needRedraw = false;

	// has activiation state changed?
	bool tempActive = (GetForegroundWindow() == hTask);

	if( tempActive != active )
	{
		active = tempActive;
		needRedraw = true;
	}

	// has caption changed?
	LPTSTR temp1, temp2;

	if (hTask) {
		temp1 = caption;
		temp2 = GetWindowCaption();
	} else {
		temp1 = otherCaption;
		temp2 = NULL;
	}

	if( temp2 == NULL || strcmp( temp1, temp2 ) != 0 )
	{
		if (temp2) {
			delete [] caption;
			caption = temp2;
			needRedraw = true;
			temp1 = caption;
		}

		// update tooltip
		TOOLINFO ti;
		memset( &ti, 0, sizeof(TOOLINFO) );

		ti.cbSize = sizeof(TOOLINFO);
		ti.hwnd = container.hWnd;
		ti.uId = (UINT) this;
		ti.lpszText = temp1;

		SendMessage( container.hToolTips, TTM_UPDATETIPTEXT, 0, (LPARAM) &ti );
	} else {
		if (temp2) { 
			delete [] temp2;
		}
	}


	// has icon changed?
	HICON tempIcon = GetIcon();

	if( icon != tempIcon )
	{
		icon = tempIcon;
		needRedraw = true;
	}

	if( needRedraw )
		container.Invalidate( x, y, width + 1, height + 1 );
}

LPTSTR TaskbarButton::GetWindowCaption()
{
	LPTSTR windowCaption;
	int length;

	if (hTask) {
		length = GetWindowTextLength( hTask );

		windowCaption = new TCHAR[length + 1];
		GetWindowText( hTask, windowCaption, length + 1 );
	}

	return windowCaption;
}

HICON TaskbarButton::GetIcon()
{
	return GetIconFromWindow( hTask, FALSE );
}

//
// TaskbarSkin
//

TaskbarSkin::TaskbarSkin() {
	TaskbarSkin(NULL, NULL, NULL);
}

TaskbarSkin::TaskbarSkin( LPCTSTR pszLeft, LPCTSTR pszMiddle, LPCTSTR pszRight )
{
	stretch = TRUE;
	backColor = 0;
	hbmLeft = NULL;
	hbmMiddle = NULL;
	hbmRight = NULL;

	if( pszLeft && pszLeft[0] )
	{
		hbmLeft = LoadLSImage( pszLeft, NULL );
		GetLSBitmapSize( hbmLeft, &leftW, &leftH );
	}

	if( pszMiddle && pszMiddle[0] )
	{
		hbmMiddle = LoadLSImage( pszMiddle, NULL );
		GetLSBitmapSize( hbmMiddle, &middleW, &middleH );
	}

	if( pszRight && pszRight[0] )
	{
		hbmRight = LoadLSImage( pszRight, NULL );
		GetLSBitmapSize( hbmRight, &rightW, &rightH );
	}
}

TaskbarSkin::~TaskbarSkin()
{
	if( hbmLeft )
		DeleteObject( hbmLeft );

	if( hbmMiddle )
		DeleteObject( hbmMiddle );

	if( hbmRight )
		DeleteObject( hbmRight );
}

void TaskbarSkin::Apply( HDC hDC, int x, int y, int width, int height )
{
	HDC hdcBuffer;
	HDC hdcMem;
	HBITMAP hbmBuffer;
	HGDIOBJ hgoBuffer;
	HGDIOBJ hgoMem;
	int widthLeft = width;

	hdcBuffer = CreateCompatibleDC( hDC );
	hbmBuffer = CreateCompatibleBitmap( hDC, width, height );
	hgoBuffer = SelectObject( hdcBuffer, hbmBuffer );

	hdcMem = CreateCompatibleDC( hDC );
	hgoMem;

	SetStretchBltMode( hdcBuffer, STRETCH_DELETESCANS );

	if (backColor) {
		// simple 3D frame
		RECT r;
		HBRUSH hbrBack;

		r.top = 0;
		r.left = 0;
		r.bottom = height;
		r.right = width;

		hbrBack = CreateSolidBrush( backColor );
		FillRect( hdcMem, &r, hbrBack );
		FillRect( hdcBuffer, &r, hbrBack );
		DeleteObject( hbrBack );
	}

	if( hbmLeft && width > 0 )
	{
		hgoMem = SelectObject( hdcMem, hbmLeft );

		if (stretch) {
			StretchBlt( hdcBuffer, 0, 0, min( widthLeft, leftW ), height,
				hdcMem, 0, 0, leftW, leftH, SRCCOPY );
		} else {
			BitBlt(hdcBuffer, 0, 0, min(widthLeft, leftW), height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
		widthLeft = widthLeft - leftW;
	}

	if( hbmRight && width > 0 )
	{
		hgoMem = SelectObject( hdcMem, hbmRight );

		if (stretch) {
			StretchBlt( hdcBuffer, width - rightW, 0, min( widthLeft, rightW ),
				height, hdcMem, 0, 0, rightW, rightH, SRCCOPY );
		} else {
			BitBlt(hdcBuffer, width - rightW, 0, min(widthLeft, rightW), height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
		widthLeft = widthLeft - rightW;
	}

	if( hbmMiddle && width > 0 )
	{
		hgoMem = SelectObject( hdcMem, hbmMiddle );

		if (stretch) {
			StretchBlt( hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height,
				hdcMem, 0, 0, middleW, middleH, SRCCOPY );
		} else {
			BitBlt(hdcBuffer, hbmLeft ? leftW : 0, 0, widthLeft, height, hdcMem, 0, 0, SRCCOPY);
		}

		SelectObject( hdcMem, hgoMem );
	}

	TransparentBltLS( hDC, x, y, width, height, hdcBuffer, 0, 0,
		RGB( 255, 0, 255 ) );

	SelectObject( hdcBuffer, hgoBuffer );
	DeleteObject( hbmBuffer );
	DeleteDC( hdcBuffer );

	DeleteDC( hdcMem );
}

void TaskbarButton::SetSkin(TaskbarSkin *s)
{
	skin = s;
}

TaskbarSkin* TaskbarButton::GetSkin()
{
	return skin;
}

void TaskbarSkin::SetStretch(BOOL s)
{
	stretch = s;
}

BOOL TaskbarSkin::GetStretch()
{
	return stretch;
}

void TaskbarSkin::SetBackColor(COLORREF color)
{
	backColor = color;
}

COLORREF TaskbarSkin::GetBackColor()
{
	return backColor;
}

void TaskbarButton::SetCaption(LPCTSTR cap)
{
	if (!cap) {
		return;
	}

	if (otherCaption) {
		delete [] otherCaption;
	} else {
		otherCaption = new char[strlen(cap) + 1];
	}

	strcpy(otherCaption, cap);

	// add tooltip
	TOOLINFO ti;
	memset( &ti, 0, sizeof(TOOLINFO) );

	ti.cbSize = sizeof(TOOLINFO);
	ti.hwnd = container.hWnd;
	ti.uId = (UINT) this;
	ti.lpszText = otherCaption;

	SendMessage( container.hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti );
}
