/*
  Copyright (C) 1998-1999 Johan Redestig
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#if !defined(AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_)
#define AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_RC_STRING 256

#include <vector>

using namespace std;

class PopupMenu;
class Painter;
class MenuItem;

class PopupMaker
{
public:
	PopupMaker();
	~PopupMaker();

	void Show();
	void Hide();

	void Initialize(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);

	void ParseStepRC(FILE* pStepRC, PopupMenu* pRoot);

	PopupMenu* LoadFolder(LPTSTR pszTitle, char* pszFolder);

	Painter* MakePainter(char* pszImage, DWORD dwColor, DWORD dwGradColor, BOOL bGrad, BOOL bSwap);

	/**
	Returns a new MenuItem according to pszItem with the pszTitle

	@param pszItem name of the menu item to create
	@param pszTitle the title of the menu item
	@return a new menu item, or NULL if none suitable was found
	*/
	MenuItem* MakeBangItem(char* pszItem, char* pszTitle);

	/**
	adds the bottom image to the menu item. if m_pBottom is not pointing at NULL
	then nothing happens

	@param pMenu pointer to the menu that shall receive a bottom image
	*/
	void AddBottomItem(PopupMenu* pMenu);

	void AddHeaderItem(PopupMenu* pMenu, char* pszTitle, BOOL bVeto);

//private:

	vector<Painter*> m_Painters;

	HINSTANCE hInst;
	char m_pszTitlePix[MAX_RC_STRING];
	char m_pszEntryPix[MAX_RC_STRING];
	char m_pszSelEntryPix[MAX_RC_STRING];
	char m_pszBottomPix[MAX_RC_STRING];
	char m_pszFontFace[MAX_RC_STRING];
	char m_pszEntryFontFace[MAX_RC_STRING];


	BOOL m_bHeader;
	BOOL m_bTransparent;

	BOOL m_bShowExtension;

	BOOL m_bAutoSeparator;

	BOOL m_bGradientTitle;
	DWORD m_nGradientTitle;
	BOOL m_bGradientEntry;
	DWORD m_nGradientEntry;

	BOOL m_bIcons;

	int m_nTitleHeight;

	DWORD m_nTitleColor;
	DWORD m_nInActiveTitleColor;
	DWORD m_nEntryColor;
	DWORD m_nSelEntryColor;


	DWORD m_nTitleTextColor;
	DWORD m_nEntryTextColor;
	DWORD m_nSelEntryTextColor;

	DWORD m_nBevelLightColor;
	DWORD m_nBevelDarkColor;
	
	/// minimum acceptable width of a menu
	int  m_nMinWidth;

	/// 
	int  m_nSubmenuHeight;

	int m_nDateTimeAlignment;

	PopupMenu* m_pRoot;

	HFONT m_hDefaultFont;
	HFONT m_hEntryFont;

	Painter* m_pTitle;
	Painter* m_pInactiveTitle;
	Painter* m_pEntry;
	Painter* m_pSelEntry;
	Painter* m_pBottom;
};

#endif // !defined(AFX_POPUPMAKER_H__7375AD76_787E_11D2_B6A7_00C0DF466974__INCLUDED_)
