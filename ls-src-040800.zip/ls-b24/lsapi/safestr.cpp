#include "safestr.h"


bool CharInStr(const char chr, const char* szString)
{
  if (!(chr && szString))
    return false;

  return strchr(szString, chr) != NULL;
}

char* StrLCopy(char* szDest, const char* szSource, size_t dwMaxLen)
{
  size_t maxLen;

  if (!(szDest && szSource))
    return NULL;

  maxLen = StrLen(szSource) < dwMaxLen ? StrLen(szSource) : dwMaxLen;

  strncpy(szDest, szSource, maxLen);
  szDest[maxLen] = '\0';

  return szDest;
}

