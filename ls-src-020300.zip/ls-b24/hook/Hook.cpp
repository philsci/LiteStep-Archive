#define STRICT
#include <time.h>
#include <windows.h>

#define HOOK_DLL
#include "hook.h"

// Used to WM_COPYDATA to pass messages
HOOKMSGDATA ghmd;
COPYDATASTRUCT gcds = { 0, sizeof(HOOKMSGDATA), &ghmd };

#pragma data_seg("SHAREDATA")
static HHOOK g_hHookShell=0;    // Hook for WH_SHELL
static HHOOK g_hHookMessage =0; // Hook for WH_GETMESSAGE
static HWND parent=NULL;        // HWND of process loading hook.dll
#pragma data_seg()
HINSTANCE hInst;

void AttachHookDll(HWND hwndParent) {
    MINIMIZEDMETRICS mm;

	if (hwndParent) {
        // Store hwnd of Parent, this will be used later to send captured messages
		parent = hwndParent;
        // Prevent windows from being shown when minimized
		memset(&mm, 0, sizeof(MINIMIZEDMETRICS));
		mm.cbSize = sizeof(MINIMIZEDMETRICS);
		SystemParametersInfo(SPI_GETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);
		mm.iArrange |= ARW_HIDE; // ARW_HIDE == 8
		SystemParametersInfo(SPI_SETMINIMIZEDMETRICS, sizeof(MINIMIZEDMETRICS), &mm, FALSE);
	} else {
	    // Unload shell filter
	    InstallShellFilter(false);
        // Unload msg filter
        InstallMsgFilter(false);
	}
}

/*
Installs and uninstall the shell filter
*/
bool InstallShellFilter(bool install) {
    if ((install) && !(g_hHookShell)) {
        // Create shell hook
		g_hHookShell = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellProc, hInst, 0);
		if (!g_hHookShell)
			MessageBox(parent, "Error creating shell Hook!", "Hook", MB_OK);
    }
    else if (!(install) && (g_hHookShell)) {
		UnhookWindowsHookEx(g_hHookShell);
		g_hHookShell = 0;
    }
    if (g_hHookShell == NULL) return false;
    return true;
}

/*
Installs and uninstall the message filter
*/
bool InstallMsgFilter(bool install) {
    if ((install) && !(g_hHookMessage)) {
        // Create message hook
		g_hHookMessage = SetWindowsHookEx(WH_GETMESSAGE, (HOOKPROC)GetMsgProc, hInst, 0);
		if (!g_hHookMessage)
			MessageBox(parent, "Error creating message Hook!", "Hook", MB_OK);
    }
    else if (!(install) && (g_hHookMessage)) {
		UnhookWindowsHookEx(g_hHookMessage);
		g_hHookMessage = 0;
    }
    if (g_hHookMessage == NULL) return false;
    return true;
}

/*
Call back for WH_SHELL
*/
LRESULT CALLBACK ShellProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	HWND hwnd = (HWND)wParam;

	if (0 > nCode)
		return (CallNextHookEx(g_hHookShell, nCode, wParam, lParam));
    SendMessage(parent, LM_SHELLMESSAGE, (WPARAM)hwnd, (LPARAM)nCode);
	//switch (nCode) {
	//case HSHELL_ACTIVATESHELLWINDOW:
	//	break;
	//case HSHELL_GETMINRECT:
	//	PostMessage(parent, LM_MINMAXWIN, (WPARAM)hwnd, 0);
	//	break;
	//case HSHELL_LANGUAGE:
	//	break;
	//case HSHELL_REDRAW:
	//	break;
	//case HSHELL_TASKMAN:
	//	break;
	//case HSHELL_WINDOWACTIVATED:
	//	PostMessage(parent, LM_ACTIVEWIN, (WPARAM)hwnd, 0);
	//	break;
	//case HSHELL_WINDOWCREATED:
	//	PostMessage(parent, LM_ADDWINDOW, (WPARAM)hwnd, 0);
	//	break;
	//case HSHELL_WINDOWDESTROYED:
	//	PostMessage(parent, LM_REMOVEWINDOW, (WPARAM)hwnd, 0);
	//	break;
    //default:
    //    break;
	//}
	return 0;
}

/*
Call back for WH_GETMESSAGE
*/
LRESULT CALLBACK GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam )
{
    PCWPSTRUCT pcwps;
    pcwps = (PCWPSTRUCT)lParam;

   if ( nCode >= 0 ) {
       if (pcwps->message != WM_TIMER) {
            ghmd.wParam = pcwps->wParam;
            ghmd.lParam = pcwps->lParam;
            gcds.dwData = pcwps->message;
            SendMessage(parent, WM_COPYDATA, (WPARAM)pcwps->hwnd, (LPARAM)&gcds);
       }
   }
   return (CallNextHookEx(g_hHookMessage, nCode, wParam, lParam));
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	if (fdwReason == DLL_PROCESS_ATTACH) {
		// We don't need thread notifications for what we're doing.  Thus, get
		// rid of them, thereby eliminating some of the overhead of this DLL,
		// which will end up in nearly every GUI process anyhow.
		DisableThreadLibraryCalls(hinstDLL);
		hInst = hinstDLL;
	}
	return TRUE;
}
