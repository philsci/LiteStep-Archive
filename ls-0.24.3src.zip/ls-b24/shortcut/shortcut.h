#ifndef __ACTIVESHORTCUTS_H_
#define __ACTIVESHORTCUTS_H_

#include "../litestep/wharfdata.h"

typedef struct {
    char szCommand[256];
	char szParameters[256];
    char szName[256];
    int x, y, state;
    HBITMAP bmpOff, bmpOn, bmpClick;
	HRGN transOnRgn, transOffRgn, transClickRgn;
    SIZE onSize, offSize, clickSize;
    HWND hwnd;
	UINT uTimer;
    } shortcutType;

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initModule(HWND parent, HINSTANCE dll, wharfDataType* wd);
__declspec( dllexport ) int initModuleEx(HWND parent, HINSTANCE dll, LPCSTR szPath);
__declspec( dllexport ) void quitModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif


#endif

