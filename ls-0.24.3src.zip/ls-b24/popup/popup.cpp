 /*

  This is a part of the LiteStep Shell Source code.

  Copyright (C) 1997-98 The LiteStep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/


/****************************************************************************
 31/10/98 - Fahim Farook
			Added support for popup menu navigation via keyboard
 29/10/98 - Cyberian (Fahim Farook)
			Added support for popupmenu height customization. The title bar
			wouldn't change sizes earlier - now takes its value from PopupSubMenuHeight
			in step.rc
 9/11/98 - M. West
    		New popups created, limited functionality, will parse in a simple
    		1 layer popup menu, and run programs from it,
 30/10/98 - B. Kilian
			Fixed Fixed the popups repainting problem, and the setWindowPos 
			in the paint.
 30/10/98 - J Redestig
			Setforegroundwindow, so the popups get focus correctly, and <ESC> exits popups.
 30/10/98 - T Engel
			Environment substitution for !PopupFolders

****************************************************************************/



#include <windows.h>
#include <stdio.h>

#include "..\lsapi\lsapi.h"
#include "popup.h"

#define WM_SELECTED 9667
#define WM_NOTSELECTED 9666
//BOOL selected[255];

BOOL isMainWindowHidden = TRUE;

int previousCounter2 = 0;
int counter2 = 0;
int popupSubHeight = 20;
int titleHeight = 20;

HWND itemCaller = NULL;
menuItem *previousItem = NULL;	

BOOL noPopupBevel;
int popupLevel = 0;
HFONT popupFont;
int popupFontHeight;
char popupFontFace[256];
int popupTextOffset;
COLORREF titleColor, selColor, normColor;
BOOL transBlt, popupFolderIcon=TRUE;
WNDCLASS wc;
const char szAppName[] = "PopupMenu"; // Our window class, etc

WNDCLASS subM;
const char popupSubName[] = "subPopupMenu"; // Our window class, etc

popupMenu popup; //popup class struct
fileItem *popupFile;  //rc file info holder
subMenuHWND subList[255]; //popup submenu pointer struct

int subEnum = 0; //submenu counter

HINSTANCE appInstance;
int yy;
HWND parent;
HWND hMainWnd = NULL;

BOOL timerIdent = FALSE;
BOOL wentRight[255];

menuItem *timerPointer = NULL;
int timerHeight = 0;


BOOL goingToSubMenu = FALSE;
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath);
int fillDirectory(char *dirName, menuItem *target);
void displaySubMenu(HWND calledFrom, menuItem *item, int height);
LRESULT CALLBACK PopupWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void displaySingleMenuItem(HWND hwnd, menuItem *item, int totalHeight, BOOL selected);
void closePopupSubMenu(HWND subMenu);
void initializePopupMenu();
void displayPopup(HWND hwnd, int x, int y);
void PaintSubMenu(int i);
void PaintPopup(HWND hwnd);
void keyedSubMenu(HWND Menu, menuItem *showItem);

POINT pt; 
POINT currentRootLocation;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//BEGIN CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

menuItem::~menuItem()
    {
    	if(next != NULL)
    		delete next;
    	if(SMenu != NULL)
    		delete SMenu;
    }

BOOL popupMenu::newMenuItem()
{
    menuItem *temp = root;
    
    while(1) //finds the last node in the list
    {
    	if(temp == NULL)
    		break;
    	else if(temp->next == NULL)
    		break;
    	else temp = temp->next;
    }
    
    if(temp == NULL)
    {
    	root = new menuItem;
    	root->next = NULL;
    	current = root;
    }
    
    else 
    {
    	temp->next = new menuItem;
    	current = temp->next;
    }
    
    return(TRUE);
}


int popupMenu::returnMenuWidth()
{
    return(menuWidth);
}


fileItem::fileItem()
{
    strcpy(itemName, "\0");
    strcpy(bmpName, " ");
    strcpy(popupCommand, " ");
    next = NULL;
    itemHeight = popupSubHeight;
}

fileItem::~fileItem()
{
    delete next;
}


BOOL subMenu::newMenuItem()
{
    menuItem *temp = root;
    
    while(1) //finds the last node in the list
    {
    	if(temp == NULL)
    		break;
    	else if(temp->next == NULL)
    		break;
    	else temp = temp->next;
    }
    
    if(temp == NULL)
    {
    	root = new menuItem;
    	current = root;
    }
    
    else 
    {
    	temp->next = new menuItem;
    	current = temp->next;
    }
    
    return(TRUE);
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//END CLASS DEFINITION 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void destroyCurrentSubMenu()
{
    DestroyWindow((HWND)subList[subEnum].subMenuHwnd);
//	subList[subEnum].subMenu->isSubOpen = FALSE;
    subList[subEnum].subMenuHwnd = NULL;
    subList[subEnum].subMenu = NULL;
    subEnum--;
}

void destroyAllSubMenus()
{
    for(int i = 0;i < 255; i++)
    {
    	if(subList[i].subMenuHwnd != NULL)
    	{
    		DestroyWindow((HWND)subList[i].subMenuHwnd);
//			subList[i].subMenu->isSubOpen = FALSE;
    		subList[i].subMenuHwnd = NULL;
    		subList[i].subMenu = NULL;
			wentRight[i] = FALSE;
    	}
    	subEnum = 0;
    }
}

//get bitmaps size func stolen from 23e
void GetBitmapSize(HBITMAP hBitmap, int *x, int *y)
{
BITMAP bm;
if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
    {
    *x=0;
    *y=0;
    }
else
    {
    *x = bm.bmWidth;
    *y = bm.bmHeight;
    }
}

//cleanup, not much to do
int quitModule(HINSTANCE dllInst)
{
    destroyAllSubMenus();
    DestroyWindow(hMainWnd);
    DeleteObject(popupFont);
	if (popup.titleBMP.bitmap)
		DeleteObject(popup.titleBMP.bitmap);
	if (popup.backBMP.bitmap)
		DeleteObject(popup.backBMP.bitmap);
	if (popup.selectBMP.bitmap)
		DeleteObject(popup.selectBMP.bitmap);
	if (popup.bottomBMP.bitmap)
		DeleteObject(popup.bottomBMP.bitmap);
    UnregisterClass(szAppName,dllInst); // unregister window class
    UnregisterClass(popupSubName,dllInst); // unregister window class
    return 1;
}

//now defunct entry point, will take it out if somone complains
int initModule(HWND ParentWnd, HINSTANCE dllInst, wharfDataType* wd)
{
    return initModuleEx (ParentWnd, dllInst, wd->lsPath);
}

//DLL entry point
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
    appInstance = dllInst;
    parent = ParentWnd;

    //set all menus to NON-selected mode
    //for(int SE = 0; SE < 255; selected[SE] = FALSE, SE++);
    //parse file and fill popup class structure
    initializePopupMenu();
    
    memset(&wc,0,sizeof(wc));
    wc.lpfnWndProc = (WNDPROC)&WndProc;// our window procedure
    //wc.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    wc.hInstance = appInstance;			
    wc.lpszClassName = szAppName;// our window class name
    wc.style = 0;

    memset(&subM,0,sizeof(subM));
    subM.lpfnWndProc = (WNDPROC)&PopupWndProc;// our window procedure
    //subM.hbrBackground = (HBRUSH) GetStockObject(LTGRAY_BRUSH);
    subM.hInstance = appInstance;			
    subM.lpszClassName = popupSubName;// our window class name
    subM.style = 0;

    if (!RegisterClass(&wc)) 
    {
    	MessageBox(NULL,"Error registering window class",szAppName,MB_OK);
    	return 1;
    }

    if (!RegisterClass(&subM)) 
    {
    	MessageBox(NULL,"Error registering window class",szAppName,MB_OK);
    	return 1;
    }

    hMainWnd = CreateWindowEx(
        	WS_EX_TOPMOST|WS_EX_TOOLWINDOW,//WS_EX_TRANSPARENT,									// exstyles 
    		szAppName,								// our window class name
    		"",											// use description for a window title
    		WS_POPUP,				
    		0, 0,									// position 
    		popup.menuWidth,(popup.totalHeight + titleHeight + popup.bottomBMP.y),				// width & height of window
    		ParentWnd,								// parent window 
    		NULL,									// no menu
    		appInstance,								// hInstance of DLL
    		NULL);									// no window creation data

    SetWindowLong(hMainWnd, GWL_USERDATA, magicDWord);

    //create the message id's that popup.dll will use
    int Msgs[10];
    Msgs[0] = 9182;
    Msgs[1] = 9183;
    Msgs[2] = 0;
    SendMessage (ParentWnd, 9263, (WPARAM)hMainWnd, (LPARAM)Msgs);
	
	for (int i=0; i<256; i++)
		wentRight[i] = FALSE;
    return 0;
}

// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int counter = titleHeight;
    POINT pt; RECT r;
	int previousCounter = titleHeight;
    //yy = HIWORD(lParam); 
    int y = HIWORD(lParam); 
    WORD fActive;
    HWND hwndGetFocus;
    int p;
    
    menuItem *temp3 = NULL;
    int counter3 = 40;
	int previousCounter3 = titleHeight;
    //makes a temp pointer to the root of our popup tree, 
    menuItem *item = popup.root;

    switch (message) {
    case LM_POPUP:
 		GetCursorPos(&pt);
		displayPopup(hwnd, pt.x, pt.y);
		SetForegroundWindow(hwnd);
		return 0;

    case WM_PAINT:
        PaintPopup(hwnd);
//		displayPopup(hwnd, currentRootLocation.x, currentRootLocation.y);
    	return 0;

	case WM_ERASEBKGND:
		return 0;

    case WM_LBUTTONDOWN:
//    	GetCursorPos(&pt);
    	GetCursorPos(&pt);
    	GetWindowRect(hwnd, &r);
    	pt.x -= r.left;
    	pt.y -= r.top;
    	
    	while(item != NULL)
    	{
    		counter = counter + item->height;
    		
			if(pt.y > titleHeight && pt.y < counter)
    		{
    			char temp[256];
    			if(item->SMenu == NULL)
    			{
    				strcpy(temp, item->command);
    				destroyAllSubMenus();
    				if(item->command[0] != '!')
    				{
    					SHELLEXECUTEINFO si;
    					memset(&si, 0, sizeof(si));
    					si.cbSize = sizeof(SHELLEXECUTEINFO);
    					si.lpDirectory = NULL;
    					si.lpVerb = NULL;
    					si.nShow = 1;
    					si.fMask = SEE_MASK_DOENVSUBST;
    					si.lpFile = item->command;
    					si.lpParameters = item->params;
    					ShellExecuteEx(&si);

    				}
    				else
    					ParseBangCommand (hwnd, item->command, item->params);
    				
    				previousItem = NULL;
    				previousCounter2 = 0;
    				counter2 = 0;
    				isMainWindowHidden = TRUE;
					popup.isSelected = NULL;
    				ShowWindow(hwnd, SW_HIDE );

    				break;
    			}
    				
    			else if(item->SMenu != subList[subEnum].subMenu)
    			{
    				if(subEnum > 0)
    					destroyAllSubMenus();
    				
    				else
    				{
    					goingToSubMenu = TRUE;
    					displaySubMenu(hwnd,item, counter);
    				}
    				
    				break;
    			}
    			break;
    		}
    		item = item->next;
    	}
    	break;		

    case WM_TIMER:
    	
    	if(timerPointer == NULL)
    		break;
    	if(timerPointer->SMenu->root->itemLevel == 1 && 
    		timerPointer->SMenu != subList[subEnum].subMenu)
    	{
    		destroyAllSubMenus();
    		displaySubMenu(hwnd, timerPointer, timerHeight);
    		timerPointer = NULL;
    		KillTimer(hwnd, 0);
    	}

    	break;
    case WM_MOUSEMOVE:

		if(y < titleHeight || previousItem == NULL);
    		
    		else if(y < previousCounter2 || y > counter2 || previousItem->itemLevel > 0)
    		{
    			if(previousItem != popup.isSelected && previousItem->itemLevel > 0)
    			{
    				temp3 = popup.root;
    				while(temp3 != popup.isSelected)
    				{
    					counter3 = counter3 + temp3->height;
    					previousCounter3 = previousCounter3 + temp3->height;
    					temp3 = temp3->next;
    				}
    			
    			}
    			
    			else
    			{
    				temp3 = previousItem;
    				previousCounter3 = previousCounter2;
    			}


    			displaySingleMenuItem(hwnd, temp3, previousCounter3, FALSE);			


    			timerPointer = NULL;
    		}
    	
    	while(item != NULL)
    	{
    		counter = counter + item->height;

			if(y < titleHeight);
    		else if(y > previousCounter && y < counter)
    		{

    			if(previousItem == NULL);
				else if(subEnum != 0 && previousItem->SMenu != subList[subEnum].subMenu) {
    				destroyAllSubMenus();
				}

    			displaySingleMenuItem(hwnd, item, previousCounter, TRUE);			
    			previousCounter2 = previousCounter;
    			popup.isSelected = item;
    			counter2 = counter;
    			previousItem = item;

    		}

    		if(y > previousCounter && y < counter && item->SMenu != NULL && subList[subEnum].subMenu != item->SMenu)
    		{
    			if(timerPointer != item)
    			{
    				SetTimer(hwnd, 0, popup.subMenuDelay, NULL);
    				timerPointer = item;
    				timerHeight = counter;
    				break;
    			}
    		}

    		previousCounter = previousCounter + item->height;
    		item = item->next;
    	}
    	break;
    
    //so you can move the window around, will implement more here later
    case WM_NCHITTEST:
    	GetCursorPos(&pt);
    	GetWindowRect(hwnd, &r);
    	//pt.x -= r.left;
    	pt.y -= r.top;
    	
    	if(pt.y < titleHeight)
    	{
    		if(previousItem == NULL);
    		else if(previousItem->itemLevel == 0)
    		{
    			displaySingleMenuItem(hwnd, previousItem, previousCounter2, FALSE);			
    			previousItem = NULL;
    			timerPointer = NULL;
    		}
    		else
    		{
    				temp3 = popup.root;
    				while(temp3 != popup.isSelected)
    				{
    					counter3 = counter3 + temp3->height;
    					previousCounter3 = previousCounter3 + temp3->height;
    					temp3 = temp3->next;
    				}

    			displaySingleMenuItem(hwnd, temp3, previousCounter3, FALSE);			
    			previousItem = NULL;
    			timerPointer = NULL;
    	
    			}
    			
    			destroyAllSubMenus();
    			return (HTCAPTION);
    	}
    	else break;
    
    case WM_ACTIVATE:
    	fActive = LOWORD(wParam);
    	if(fActive == WA_INACTIVE)
    	{
    		hwndGetFocus = (HWND)lParam; // handle of window receiving focus 
    		
    		if(goingToSubMenu == TRUE)
    			break;
    		p = 1;
    		do
    		{
    			if(subList[p].subMenuHwnd == hwndGetFocus && subList[p].subMenuHwnd !=NULL)
    				return 0;
    			p++;
    		}while(p < (subEnum +1));
    		previousItem = NULL;
    		previousCounter2 =0;
    		counter2 = 0;
    		isMainWindowHidden = TRUE;
    		timerPointer = NULL;
			popup.isSelected = NULL;
    		ShowWindow(hwnd, SW_HIDE );
    		destroyAllSubMenus();
    		return 0;
    	}
    	break;	

    case WM_SYSCOMMAND:
    	{
    	switch (wParam)
    		{
    		case SC_CLOSE:
    			PostMessage(parent,WM_KEYDOWN,8889,0);
    			return 0;
    		default:
    			return DefWindowProc(hwnd,message,wParam,lParam);
    		}
    	}

    case WM_NCDESTROY:
    case WM_CLOSE:
    case WM_DESTROY:
    case WM_QUIT:
    case WM_ENDSESSION:
    case WM_QUERYENDSESSION:
    	break;
    	//		return SendMessage(parent,message,wParam,lParam);

	case WM_KEYDOWN:          
		switch (wParam) {
		case VK_ESCAPE: // Main popup
			// Destroy the popup menu if the user hits ESCAPE
			destroyAllSubMenus();
			isMainWindowHidden = TRUE;
			popup.isSelected = NULL;
			ShowWindow(hwnd, SW_HIDE);
			break;

		case VK_DOWN: // Main popup
			if (subEnum > 0) {
				if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->next);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
				} else {
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->root);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
				}
			} else {
				if (popup.isSelected !=NULL && popup.isSelected->next != NULL)
					keyedSubMenu(hwnd, popup.isSelected->next);
				else
					keyedSubMenu(hwnd, popup.root);
			}
			break;
		case VK_UP: // Main popup
			if (subEnum > 0) 
			{
				if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) 
				{
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->current);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
				} else 
				{
					menuItem *temper = subList[subEnum].subMenu->root;
					while (subList[subEnum].subMenu->isSelected != temper->next) 
					{
						temper = temper->next;
					}
					keyedSubMenu(subList[subEnum].subMenuHwnd, temper);
					subList[subEnum].subMenu->isSelected = temper;
				}

			} else 
			{
				if (popup.isSelected == NULL)
				{
					keyedSubMenu(hwnd, popup.current);
				}
				else
				{
					if (popup.isSelected != popup.root) 
					{
						menuItem *temper = popup.root;
						while (popup.isSelected != temper->next) 
						{
							temper = temper->next;
						}
						keyedSubMenu(hwnd, temper);
					} else 
					{
						keyedSubMenu(hwnd, popup.current);
					}
				}
			}
			break;
		case VK_RIGHT: // Main popup
/*			if (popup.isSelected != NULL) {
				if (popup.isSelected->SMenu != NULL) 
					keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
			} */
    		break;
		case VK_LEFT: // Main popup
			if (subEnum > 0) {
				wentRight[subEnum] = FALSE;
				subList[subEnum].subMenu->isSelected = NULL;
				if (subList[subEnum].subMenu->root->itemLevel == 1) {
					destroyCurrentSubMenu();
					keyedSubMenu(hMainWnd, popup.isSelected);
				} else { 
					destroyCurrentSubMenu();
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
				}
			}
    		break;
		case VK_RETURN: // Main popup
			if (previousItem != NULL && previousItem->itemLevel == 0) {
	    		if(previousItem->SMenu == NULL) {
	    			char temp[256];
					strcpy(temp, previousItem->command);
	    			destroyAllSubMenus();
	    			if(previousItem->command[0] != '!') {
	    				SHELLEXECUTEINFO si;
						memset(&si, 0, sizeof(si));
    					si.cbSize = sizeof(SHELLEXECUTEINFO);
	    				si.lpDirectory = NULL;
						si.lpVerb = NULL;
    					si.nShow = 1;
    					si.fMask = SEE_MASK_DOENVSUBST;
    					si.lpFile = previousItem->command;
    					si.lpParameters = previousItem->params;
	    				ShellExecuteEx(&si);
					} else
	    				ParseBangCommand (hwnd, previousItem->command, previousItem->params);
	    			previousItem = NULL;
					previousCounter2 =0;
    				counter2 = 0;
    				isMainWindowHidden = TRUE;
					popup.isSelected = NULL;
    				ShowWindow(hwnd, SW_HIDE );
	    			break;
				}
			}
			break;
		}
		break;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}


void displaySingleMenuItem(HWND hwnd, menuItem *item, int totalHeight, BOOL selected)
{
    HDC DC, memDC;
    PAINTSTRUCT ps;
    HFONT oldFont;
    HPEN hPen, oldPen;
    RECT r;

    if(selected)
    {
    	DC = BeginPaint(hwnd,&ps);
    	memDC = CreateCompatibleDC(DC);

    	DC = GetDC(hwnd);
    	oldFont = (HFONT) SelectObject(DC, popupFont);
    	SelectObject(memDC, popup.selectBMP.bitmap);

		if (transBlt)
    		TransparentBltLS(DC,0,totalHeight, popup.selectBMP.x, popupSubHeight, memDC, 0, 0,RGB(255,0,255));
		else
    		BitBlt(DC,0,totalHeight, popup.selectBMP.x, popupSubHeight, memDC, 0, 0,SRCCOPY);

    	SetTextColor(DC,  selColor);
    	SetBkMode(DC, TRANSPARENT);

    	r.left = popupTextOffset;
    	r.right = popup.selectBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + popupSubHeight;
    	DrawText(DC, item->name, lstrlen(item->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
//		TextOut(DC, 0,totalHeight,  item->name, strlen(item->name));

    	if (!noPopupBevel)
    	{
    		// First we draw the white frame on the left/top
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth, totalHeight);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, 0, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Now the black frame on the bottom/right
    		hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-1, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		MoveToEx(DC, 0, totalHeight+item->height-1, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	// Paint little folder arrow thingy
    	if (item->SMenu != NULL && popupFolderIcon)
    	{
    		// First 2 lines are dark gray
    		hPen = CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-12, totalHeight+item->height-5, NULL);
    		LineTo(DC, popup.menuWidth-12, totalHeight+4);
    		LineTo(DC, popup.menuWidth-5, totalHeight+(item->height/2));
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Finish it off with a white line
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		LineTo(DC, popup.menuWidth-12, totalHeight+item->height-5);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	SelectObject(DC, oldFont);
    	ReleaseDC(hwnd, DC);
    	EndPaint(hwnd,&ps);	
    	DeleteDC(memDC);
    }

    else
    {
    	DC = BeginPaint(hwnd,&ps);
    	memDC = CreateCompatibleDC(DC);

    	DC = GetDC(hwnd);
    	oldFont = (HFONT) SelectObject(DC, popupFont);
    	SelectObject(memDC, popup.backBMP.bitmap);
    	
		if (transBlt)
    		TransparentBltLS(DC,0,totalHeight, popup.backBMP.x, popupSubHeight, memDC, 0, 0,RGB(255,0,255));
		else
    		BitBlt(DC,0,totalHeight, popup.backBMP.x, popupSubHeight, memDC, 0, 0,SRCCOPY);

    	SetTextColor(DC,  normColor);
    	SetBkMode(DC, TRANSPARENT);

    	r.left = popupTextOffset;
    	r.right = popup.backBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + popupSubHeight;
    	DrawText(DC, item->name, lstrlen(item->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
//		TextOut(DC, 0,totalHeight,  item->name, strlen(item->name));
    	
    	if (!noPopupBevel)
    	{
    		// First we draw the white frame on the left/top
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth, totalHeight);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, 0, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Now the black frame on the bottom/right
    		hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-1, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		MoveToEx(DC, 0, totalHeight+item->height-1, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	// Paint little folder arrow thingy
    	if (item->SMenu != NULL && popupFolderIcon)
    	{
    		// First 2 lines are dark gray
    		hPen = CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-12, totalHeight+item->height-5, NULL);
    		LineTo(DC, popup.menuWidth-12, totalHeight+4);
    		LineTo(DC, popup.menuWidth-5, totalHeight+(item->height/2));
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Finish it off with a white line
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		LineTo(DC, popup.menuWidth-12, totalHeight+item->height-5);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	SelectObject(DC, oldFont);
    	ReleaseDC(hwnd, DC);
    	EndPaint(hwnd,&ps);	
    	DeleteDC(memDC);

    }

}


void subFolderInit(menuItem *target, fileItem *item)
{
    subMenu *subMenuItem;
    target->SMenu = new subMenu;
    subMenuItem = target->SMenu;
    popupLevel++;

    item = item->next;
    while(item != NULL)
    {
    	if(!stricmp(item->popupCommand, "~folder"))
    		break;
    	
    	subMenuItem->newMenuItem();
    	strcpy(subMenuItem->current->name, item->itemName);
    	strcpy(subMenuItem->current->command, item->popupCommand);
    	strcpy(subMenuItem->current->bmp, item->bmpName);
    	strcpy(subMenuItem->current->params, item->commandParam);
    	subMenuItem->current->height = item->itemHeight;
    	subMenuItem->current->itemLevel = popupLevel;	

    	item = item->next;

    }
    popupLevel--;

    menuItem *temper = subMenuItem->root;
    int totalHeight = 0;
    while(temper != NULL)
    {
    	totalHeight = totalHeight + temper->height;
    	temper = temper->next;
    }

    subMenuItem->totalHeight = totalHeight;

}


void initializePopupMenu() 
{
    FILE *f = NULL;
    char	buffer[4096];
    char	token1[4096], token2[4096], token3[4096], token4[4096], token5[4096], extra_text[4096];
    char*	tokens[5];
    fileItem * item = popupFile;
    
    GetRCString("HotListName", popup.menuName, "", 256);
    GetRCString("PopupTitlePix", popup.titleBarBMP	, "", 256);
    GetRCString("PopupEntryPix", popup.backgroundBMP	, "", 256);
    GetRCString("PopupSelEntryPix", popup.selectedBMP	, "", 256);
	GetRCString("PopupBottomPix", popup.bottomBarBMP, "", 256);
    GetRCString("PopupFontFace", popupFontFace, "Arial", 256);

	popupFolderIcon = GetRCBool("NoPopupFolderIcon", FALSE);
	transBlt = GetRCBool("PopupTransparent", TRUE);
    noPopupBevel = GetRCBool("NoPopupBevel", TRUE);
    popupFontHeight = GetRCInt("PopupFontHeight", 16);
    titleColor = GetRCColor("PopupTitleColor", 0xffffff);
    normColor = GetRCColor("PopupEntryColor", 0xffffff);
    selColor = GetRCColor("PopupSelEntryColor", 0x000000);
    popup.subMenuDelay = GetRCInt("PopupMenuDelay",0);
    popup.menuWidth = GetRCInt("minpopupwidth", 100);
    popupSubHeight = GetRCInt("PopupSubmenuHeight", 20);
	titleHeight = GetRCInt("PopupSubmenuHeight", 20);
	popupTextOffset = GetRCInt("PopupTextOffset", 5);

    
    popupFile = new fileItem;
    item = popupFile;

    
    tokens[0] = token1;
    tokens[1] = token2;
    tokens[2] = token3;
    tokens[3] = token4;
    tokens[4] = token5;

    buffer[0] = 0;
    f = LCOpen (NULL);
    int keeper = 0;
    
    while (LCReadNextConfig (f, "*popup", buffer, sizeof (buffer)))
    {
     	int count = 0, count2 = 0;
    	char truly_extra_text[4096];
    	if(keeper == 0)
    		keeper = 1;
    	else
    	{
    		item->next = new fileItem;
    		item = item->next;
    	}

    	token1[0] = token2[0] = token3[0] = token4[0] = token5[0] = extra_text[0] = truly_extra_text[0] = '\0';

    	count = LCTokenize (buffer, tokens, 3, extra_text);
    	
    	switch (count)
    	{
    	case 3:											// *Popup
    		strcpy(item->itemName, token2);				// "Name"
    		if (atoi(token3))
    		{
    			item->itemHeight = atoi(token3);			// Height
    			count2 = LCTokenize(extra_text, tokens, 2, truly_extra_text);
    			strcpy(item->bmpName, token1);				// Bitmap.bmp
    			strcpy(item->popupCommand, token2);			// Command.exe
    			strcpy(item->commandParam, truly_extra_text);		// -command_params
    		}
    		else
    		{
    			item->itemHeight = popupSubHeight;
    			strcpy(item->bmpName, popup.backgroundBMP);
    			if (!stricmp(token3, "Folder"))
    			{
    				strcpy(item->popupCommand, "!Folder");
    			}
    			else
    			{
    				strcpy(item->popupCommand, token3);
    			}
    			strcpy(item->commandParam, extra_text);
    		}
    		break;

    	case 2:
    		strcpy(item->popupCommand, token2);
    	}
    			
    }		

    
    //copys the popupFile structure into our popup strucure
    //in later revisions error checking will go here
    
    LCClose(f);


    item = popupFile;
    while(item != NULL)
    {
    	if(!stricmp(item->popupCommand, "~folder"))
    		item = item->next;
    	if(item == NULL)
    		break;
    	
    	popup.newMenuItem();
    	strcpy(popup.current->name, item->itemName);
    	strcpy(popup.current->command, item->popupCommand);
    	strcpy(popup.current->bmp, item->bmpName);
    	strcpy(popup.current->params, item->commandParam);
    	popup.current->height = item->itemHeight;
    	popup.current->itemLevel = popupLevel;	
    	
    	if(!strncmp(popup.current->command, "!PopupFolder", 12))
    	{
			// te 10/28/98, expand %UserProfile%, %Home%, etc
			char temp[MAX_PATH], real[MAX_PATH];
			strcpy(temp, popup.current->command+13);
			popupLevel++;
			ExpandEnvironmentStrings(temp, real, sizeof(real));
			fillDirectory(real, popup.current);
			popupLevel--;
    	}
    	
    	else if(!stricmp(popup.current->command, "!Folder"))
    	{
    		subFolderInit(popup.current, item);
    		while(stricmp(item->next->popupCommand, "~folder") && item != NULL)
    			item = item->next;
    		if(item == NULL)
    			break;
    	}

    	
    	item = item->next;
    }
    	
    	

    
    menuItem *temper = popup.root;
    int totalHeight = 0;
    while(temper != NULL)
    {
    	totalHeight = totalHeight + temper->height;
    	temper = temper->next;
    }

    popup.totalHeight = totalHeight;

    //loads up images i will eventualy seperate this into its own function
    popup.backBMP.bitmap = LoadLSImage(popup.backgroundBMP, NULL);
    popup.titleBMP.bitmap = LoadLSImage(popup.titleBarBMP, NULL);
    popup.selectBMP.bitmap = LoadLSImage(popup.selectedBMP, NULL);
	popup.bottomBMP.bitmap = LoadLSImage(popup.bottomBarBMP, NULL);
    
    GetBitmapSize(popup.selectBMP.bitmap, &popup.selectBMP.x, &popup.selectBMP.y);
    GetBitmapSize(popup.backBMP.bitmap, &popup.backBMP.x, &popup.backBMP.y);
    GetBitmapSize(popup.titleBMP.bitmap, &popup.titleBMP.x, &popup.titleBMP.y);
	GetBitmapSize(popup.bottomBMP.bitmap, &popup.bottomBMP.x, &popup.bottomBMP.y);

    popupFont = CreateFont(
    		popupFontHeight,
    		0,
    		0,
    		0,
    		FW_NORMAL,
    		FALSE,
    		FALSE,
    		FALSE,
    		DEFAULT_CHARSET,
    		OUT_DEFAULT_PRECIS,
    		CLIP_DEFAULT_PRECIS,
    		DEFAULT_QUALITY,
    		DEFAULT_PITCH,
    		popupFontFace);
}



void displayPopup(HWND hwnd, int x, int y)
{
	currentRootLocation.x = x;
	currentRootLocation.y = y;
    
    GetCursorPos(&pt);

	PaintPopup(hwnd);
    //displays the window
	if (x + popup.menuWidth > GetSystemMetrics(SM_CXSCREEN))
		x -= popup.menuWidth;

	if ((y + popup.totalHeight + titleHeight) > GetSystemMetrics(SM_CYSCREEN))
		y = GetSystemMetrics(SM_CYSCREEN) - (popup.totalHeight + titleHeight);

	SetWindowPos(hwnd, HWND_TOP, x, y, popup.menuWidth,(popup.totalHeight + titleHeight + popup.bottomBMP.y), 
    	SWP_SHOWWINDOW);
    
    int sdaf =123;
}

void PaintPopup(HWND hwnd)
{
    HDC DC, memDC;
    PAINTSTRUCT ps;
    HFONT oldFont;
    RECT r;

    DC = BeginPaint(hwnd,&ps);
    memDC = CreateCompatibleDC(DC);
    isMainWindowHidden = FALSE;
    
    oldFont = (HFONT) SelectObject(DC, popupFont);
    //blits out title info
    SelectObject(memDC, popup.titleBMP.bitmap);
	if (transBlt)
		TransparentBltLS(DC,0,0, popup.titleBMP.x, popup.titleBMP.y, memDC, 0, 0,RGB(255,0,255));
	else
		BitBlt(DC,0,0, popup.titleBMP.x, popup.titleBMP.y, memDC, 0, 0,SRCCOPY);

    SetBkMode(DC, TRANSPARENT);

    r.left = popupTextOffset;
    r.right = popup.titleBMP.x-popupTextOffset;
    r.top= 0;
    r.bottom = popup.titleBMP.y;
    SetTextColor(DC,  titleColor);
    DrawText(DC, popup.menuName, lstrlen(popup.menuName), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
//	TextOut(DC, 0,0,  popup.menuName, strlen(popup.menuName));
    SelectObject(DC, oldFont);
    ReleaseDC(hwnd, DC);
    
    
    
    //creates a list hopper to retrive popup info
    menuItem *item = popup.root;
    
    int totalHeight = titleHeight;
    
    //blits out each menu item, in order that they where entered into the RC
    while(item != NULL)
    {
    	HPEN hPen, oldPen;

    	DC = GetDC(hwnd);
    	oldFont = (HFONT) SelectObject(DC, popupFont);
    	SelectObject(memDC, popup.backBMP.bitmap);
    
    	//not implemented yet
    	//TransparentBltLS( DC, 0,totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0,RGB(255,0,255));
    
    	if (transBlt)
	    	TransparentBltLS(DC,0,totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0,RGB(255,0,255));
		else
    		BitBlt(DC,0,totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0,SRCCOPY);

		SetTextColor(DC,  normColor);
    	SetBkMode(DC, TRANSPARENT);

    	r.left = popupTextOffset;
    	r.right = popup.backBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + popup.backBMP.y;
    	DrawText(DC, item->name, lstrlen(item->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
//		TextOut(DC, 0,totalHeight,  item->name, strlen(item->name));

    	if (!noPopupBevel)
    	{
    		// First we draw the white frame on the left/top
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth, totalHeight);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, 0, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Now the black frame on the bottom/right
    		hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-1, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		MoveToEx(DC, 0, totalHeight+item->height-1, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	// Paint little folder arrow thingy
    	if (item->SMenu != NULL && popupFolderIcon)
    	{
    		// First 2 lines are dark gray
    		hPen = CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-12, totalHeight+item->height-5, NULL);
    		LineTo(DC, popup.menuWidth-12, totalHeight+4);
    		LineTo(DC, popup.menuWidth-5, totalHeight+(item->height/2));
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Finish it off with a white line
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		LineTo(DC, popup.menuWidth-12, totalHeight+item->height-5);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	ReleaseDC(hwnd, DC);
    	totalHeight = totalHeight + item->height;
    	item = item->next;
    }

	if (popup.bottomBMP.bitmap)
	{
		SelectObject(memDC, popup.bottomBMP.bitmap);
		if (transBlt)
			TransparentBltLS(DC,0,totalHeight, popup.bottomBMP.x, popup.bottomBMP.y, memDC, 0, 0,RGB(255,0,255));
		else
			BitBlt(DC,0,totalHeight, popup.bottomBMP.x, popup.bottomBMP.y, memDC, 0, 0,SRCCOPY);
	}

    SelectObject(DC, oldFont);
    EndPaint(hwnd,&ps);	
    DeleteDC(memDC);

}


int fillDirectorySortFunc(const void *a, const void *b)
{
    WIN32_FIND_DATA *f1 = (WIN32_FIND_DATA *)a;
    WIN32_FIND_DATA *f2 = (WIN32_FIND_DATA *)b;

    if (f1->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    {
    	if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    		return stricmp(f1->cFileName, f2->cFileName);
    	else
    		return -1;
    }
    if (f2->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    	return 1;

    return stricmp(f1->cFileName, f2->cFileName);
}

//parses a directory and fills the popup data structure with the results
int fillDirectory(char *dirName, menuItem *target)
{
    int l=0;	
    int j, k, still=1;

    WIN32_FIND_DATA fd;
    HANDLE h;
    char temp2[MAX_PATH];
    strcpy(temp2, dirName);
    strcat(temp2, "\\*");
    h = FindFirstFile(temp2, &fd);
    if (h == INVALID_HANDLE_VALUE)
    	return 1;
    
    target->SMenu = new subMenu;
    
    
    
    menuItem *walker = target;
    WIN32_FIND_DATA fileTable[255];
    
    for (j=0;j<255 && still;j++)
    {
    	fileTable[j] = fd;
    	still = FindNextFile(h, &fd);
    }

    qsort((void *)fileTable, j, sizeof(WIN32_FIND_DATA), fillDirectorySortFunc);

    for (k=j,j=0;l<255 && j<k;l++,j++)
    {
    	if (fileTable[j].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        {
    		if (!strcmp(fileTable[j].cFileName, ".") || !strcmp(fileTable[j].cFileName, ".."))
           	{
            	l--;
    		}
    		else
    		{
    			char t[MAX_PATH];
    			walker->SMenu->newMenuItem();// = new menuItem;
    			strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
    			strcpy(t, dirName);
    			strcat(t, "\\");
    			strcat(t, fileTable[j].cFileName);
    			walker->SMenu->current->height = popupSubHeight;
    			walker->SMenu->current->itemLevel = popupLevel;
    			popupLevel++;
    			int temp2 = fillDirectory(t, walker->SMenu->current);
    			if(temp2)
    			{
    				delete walker->SMenu->current->SMenu;
    				walker->SMenu->current->SMenu = NULL;
    				strcpy(walker->SMenu->current->command, t);
    			}

    			popupLevel--;
    		}
    	}
    	else
    	{
    		char temp[5];
    		
    		//strcpy(temp2, "\"");
    		strcpy(temp2, "");
    	 	strcat(temp2, dirName);
    		strcat(temp2, "\\");
    		strcat(temp2, fileTable[j].cFileName);
    		//strcat(temp2, "\"");
       		
    		walker->SMenu->newMenuItem();			
    		strcpy(walker->SMenu->current->command,temp2);
    		
    		strcpy(temp, fileTable[j].cFileName +(strlen(fileTable[j].cFileName) -4));
    		

    		//stripping unwanted extentions from the name
			if(!stricmp(temp, ".lnk") || !stricmp(temp, ".exe") || !stricmp(temp, ".pif") || !stricmp(temp, ".com") || !stricmp(temp, ".rnk") || !stricmp(temp, ".bat")) 
    		{
    			strncpy(walker->SMenu->current->name, fileTable[j].cFileName, 
    				strlen(fileTable[j].cFileName) -4);
    			walker->SMenu->current->name[strlen(fileTable[j].cFileName) -4] = '\0';
    		}
    		
    		else strcpy(walker->SMenu->current->name, fileTable[j].cFileName);
    		
    		
    		walker->SMenu->current->height = popupSubHeight;
    		walker->SMenu->current->itemLevel = popupLevel;
    	}

    }
    FindClose(h);
    menuItem *counter = target->SMenu->root;
    target->SMenu->totalHeight = 0;
    while(counter != NULL)
    {
    	target->SMenu->totalHeight = counter->height + target->SMenu->totalHeight;
    	counter = counter->next;
    }
    
    if(target->SMenu->root == NULL)
    	return 1;
    return 0;


}
    
void displaySubMenu(HWND calledFrom, menuItem *firstItem, int height)
{
    RECT lpRect;

    if(isMainWindowHidden == TRUE)
    	return;
    GetWindowRect(calledFrom, &lpRect);
    subEnum++;

    if (lpRect.right + popup.menuWidth > GetSystemMetrics(SM_CXSCREEN)) //||
    	//lpRect.right + popup.menuWidth * subEnum > GetSystemMetrics(SM_CXSCREEN))
    	lpRect.right -= popup.menuWidth * 2;

	if (firstItem->SMenu->totalHeight+(lpRect.top+(height-titleHeight)) > GetSystemMetrics(SM_CYSCREEN))
		lpRect.top = GetSystemMetrics(SM_CYSCREEN) - (firstItem->SMenu->totalHeight +(height- titleHeight));

    subList[subEnum].subMenuHwnd = CreateWindowEx(
        	WS_EX_TOPMOST|WS_EX_TOOLWINDOW,//WS_EX_TRANSPARENT,										// exstyles 
    		popupSubName,								// our window class name
    		"",											// use description for a window title
    		WS_POPUP,				
			lpRect.right, (lpRect.top+(height-titleHeight)), 							// position 
    		popup.menuWidth,(firstItem->SMenu->totalHeight)+titleHeight + popup.bottomBMP.y,	// width & height of window
    		hMainWnd,								// parent window 
    		NULL,									// no menu
    		appInstance,								// hInstance of DLL
    		NULL);									// no window creation data
    
    SetWindowLong(subList[subEnum].subMenuHwnd, GWL_USERDATA, magicDWord);

    subList[subEnum].subMenu = firstItem->SMenu;
    subList[subEnum].subMenu->isSubOpen = TRUE;
	BOOL temp2 = SetWindowPos(subList[subEnum].subMenuHwnd, HWND_TOP, lpRect.right, (lpRect.top+(height-(titleHeight*2))), 
    popup.menuWidth,(firstItem->SMenu->totalHeight)+titleHeight+popup.bottomBMP.y,
    SWP_SHOWWINDOW);
    
	PaintSubMenu(subEnum);

    goingToSubMenu = FALSE;
}


void PaintSubMenu(int i)
{
    HFONT oldFont;
    RECT r;
    HDC DC, memDC;
    PAINTSTRUCT ps;
    
	if (i >  subEnum) return;

	//creates a list hopper to retrive popup info
    menuItem *item = subList[i].subMenu->root;

    DC = BeginPaint(subList[i].subMenuHwnd,&ps);
    memDC = CreateCompatibleDC(DC);
    
    oldFont = (HFONT) SelectObject(DC, popupFont);
    //blits out title info
    SelectObject(memDC, popup.titleBMP.bitmap);
	if (transBlt)
		TransparentBltLS(DC,0,0, popup.titleBMP.x, popup.titleBMP.y, memDC, 0, 0,RGB(255,0,255));
	else
		BitBlt(DC,0,0, popup.titleBMP.x, popup.titleBMP.y, memDC, 0, 0,SRCCOPY);

    SetBkMode(DC, TRANSPARENT);

    r.left = popupTextOffset;
    r.right = popup.titleBMP.x-popupTextOffset;
    r.top= 0;
    r.bottom = popup.titleBMP.y;
    SetTextColor(DC,  titleColor);
	if (i <= 1)
	{
		DrawText(DC, popup.isSelected->name, lstrlen(popup.isSelected->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
	}
	else
	{
		DrawText(DC, subList[i-1].subMenu->isSelected->name, lstrlen(subList[i-1].subMenu->isSelected->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
	}
//	TextOut(DC, 0,0,  popup.menuName, strlen(popup.menuName));
    SelectObject(DC, oldFont);
    ReleaseDC(subList[i].subMenuHwnd, DC);

    int totalHeight = titleHeight;
    
    //blits out each menu item, in order that they where entered into the RC
    while(item != NULL)
    {
    	HPEN hPen, oldPen;

    	DC = GetDC(subList[i].subMenuHwnd);
    	oldFont = (HFONT) SelectObject(DC, popupFont);
    	SelectObject(memDC, popup.backBMP.bitmap);
    	
    	//not implemented yet
    	//TransparentBltLS( DC, 0, totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0, 
    //	RGB(255,0,255)) ;
    
		if (transBlt)
    		TransparentBltLS(DC,0,totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0,RGB(255,0,255));
		else
    		BitBlt(DC,0,totalHeight, popup.backBMP.x, popup.backBMP.y, memDC, 0, 0,SRCCOPY);

    	SetTextColor(DC,  normColor);
    	SetBkMode(DC, TRANSPARENT);

    	r.left = popupTextOffset;
    	r.right = popup.backBMP.x-popupTextOffset;
    	r.top= totalHeight;
    	r.bottom = totalHeight + popup.backBMP.y;
    	DrawText(DC, item->name, lstrlen(item->name), &r, DT_END_ELLIPSIS | DT_VCENTER | DT_SINGLELINE);
//		TextOut(DC, 0,totalHeight,  item->name, strlen(item->name));

    	if (!noPopupBevel)
    	{
    		// First we draw the white frame on the left/top
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth, totalHeight);
    		MoveToEx(DC, 0, totalHeight, NULL);
    		LineTo(DC, 0, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Now the black frame on the bottom/right
    		hPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-1, totalHeight, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		MoveToEx(DC, 0, totalHeight+item->height-1, NULL);
    		LineTo(DC, popup.menuWidth-1, totalHeight+item->height-1);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	// Paint little folder arrow thingy
    	if (item->SMenu != NULL && popupFolderIcon)
    	{
    		// First 2 lines are dark gray
    		hPen = CreatePen(PS_SOLID, 1, RGB(0x40,0x40,0x40));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		MoveToEx(DC, popup.menuWidth-12, totalHeight+item->height-5, NULL);
    		LineTo(DC, popup.menuWidth-12, totalHeight+4);
    		LineTo(DC, popup.menuWidth-5, totalHeight+(item->height/2));
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);

    		// Finish it off with a white line
    		hPen = CreatePen(PS_SOLID, 1, RGB(255,255,255));
    		oldPen = (HPEN) SelectObject(DC, hPen);
    		LineTo(DC, popup.menuWidth-12, totalHeight+item->height-5);
    		SelectObject(DC, oldPen);
    		DeleteObject(hPen);
    	}

    	ReleaseDC(subList[subEnum].subMenuHwnd, DC);
    	totalHeight = totalHeight + item->height;
    	item = item->next;
    }

 	if (popup.bottomBMP.bitmap)
	{
		SelectObject(memDC, popup.bottomBMP.bitmap);
		if (transBlt)
			TransparentBltLS(DC,0,totalHeight, popup.bottomBMP.x, popup.bottomBMP.y, memDC, 0, 0,RGB(255,0,255));
		else
			BitBlt(DC,0,totalHeight, popup.bottomBMP.x, popup.bottomBMP.y, memDC, 0, 0,SRCCOPY);
	}
	
	SelectObject(DC, oldFont);
    EndPaint(subList[subEnum].subMenuHwnd,&ps);	

    //displays the window
    DeleteDC(memDC);

}




void closePopupSubMenu(HWND subMenu)
{
    DestroyWindow(subMenu);
}	

// window procedure for our window
LRESULT CALLBACK PopupWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    int counter = titleHeight;
    int counter22 = popupSubHeight + titleHeight;
    int previousCounter = titleHeight;
    BOOL setFlag = FALSE;
    RECT r;
    HWND hwndGetFocus;
    int p;
    int tempEnum = 1;
    int tempEnum2 = 0;
    menuItem *item;
    menuItem *temp3;
    int goingTo = 1;
    //subMenu *goingTo = NULL;
    int y = HIWORD(lParam); 
    int x = LOWORD(lParam); 
    WORD fActive;
    int counter3 = popupSubHeight + titleHeight;
    int previousCounter3 = titleHeight;

    while(hwnd != subList[tempEnum].subMenuHwnd)
    {
    	tempEnum++;
    	if(tempEnum > subEnum)
    		break;
    }
    
    switch (message)
    {
	case WM_PAINT:
		PaintSubMenu(tempEnum);
		break;

	case WM_ERASEBKGND:
		return 0;

    case WM_TIMER:
    	KillTimer(hwnd, 1);
    	if(timerPointer == NULL)
    		break;

    	if(timerPointer->SMenu != subList[subEnum].subMenu && timerPointer != NULL && hwnd == itemCaller)
    	{
    		static int tempertemper = 0;
    		tempertemper++;
    		if(tempertemper > 1)
    			tempertemper = 0;
    		while(timerPointer->itemLevel < subList[subEnum].subMenu->root->itemLevel)
    			destroyCurrentSubMenu();
    		goingToSubMenu = TRUE;
    		displaySubMenu(hwnd, timerPointer, timerHeight);
    		timerPointer = NULL;			
    	}

    	break;

    case WM_MOUSEMOVE:

    	item = subList[subEnum].subMenu->root;
    	if(tempEnum < subEnum)
    		item = subList[tempEnum].subMenu->root;
    	while(item != NULL)
    	{
    		GetCursorPos(&pt);
    		GetWindowRect(hwnd, &r);
    		pt.x -= r.left;

    		if(subList[tempEnum].subMenu->root->itemLevel > previousItem->itemLevel && setFlag == FALSE)
    		{
    			timerPointer = NULL;	
    			setFlag = TRUE;
    			KillTimer(hwnd, 1);
    		}

    		if(subList[tempEnum].subMenu->root->itemLevel < previousItem->itemLevel 
    			&& 
    			previousItem->itemLevel > 0 && setFlag == FALSE)
    		{
    			//while(subList[subEnum].subMenu->root->itemLevel != subList[tempEnum].subMenu->isSelected->itemLevel)
    			//	destroyCurrentSubMenu();
    			KillTimer(hwnd, 1);

    			while(subList[subEnum].subMenu->root->itemLevel != subList[tempEnum].subMenu->root->itemLevel)
    				destroyCurrentSubMenu();
    			
    			temp3 =	subList[tempEnum].subMenu->isSelected;
    			menuItem *tempPointer = subList[tempEnum].subMenu->root;
    			while(tempPointer != temp3)
    			{
    				previousCounter3 = previousCounter3 + tempPointer->height;
    				tempPointer = tempPointer->next;
    			}
    							
    			displaySingleMenuItem(hwnd, temp3, previousCounter3, FALSE);
    			setFlag = TRUE;
    			timerPointer = NULL;
    		}
    		
    		else if(y < previousCounter2 || y > counter2 || pt.x < 0 || pt.x > popup.menuWidth)
    		{
    			KillTimer(hwnd, 1);
    			if(previousItem->itemLevel != 0 && setFlag == FALSE)
    			{
    				while(subList[subEnum].subMenu->root->itemLevel != subList[tempEnum].subMenu->root->itemLevel)
    					destroyCurrentSubMenu();

    				temp3 = previousItem;
    				previousCounter3 = previousCounter2;
    			
    				displaySingleMenuItem(hwnd, temp3, previousCounter3, FALSE);
    				setFlag = TRUE;
    				timerPointer = NULL;
    			}
    		}
    		
    		if(y > previousCounter && y < counter22)
    		{
    			
    			displaySingleMenuItem(hwnd, item, previousCounter, TRUE);
    			previousCounter2 = previousCounter;
    			counter2 = counter22;
    			previousItem = item;
    		
    		}
    		
    		if(y > previousCounter && y < counter22 && item->SMenu != NULL && item != timerPointer 
    			&& item->SMenu != subList[subEnum].subMenu && subList[tempEnum+1].subMenu != item->SMenu)
    		{
    			if(timerPointer != item)
    			{
    				subList[tempEnum].subMenu->isSelected = item;
    				SetTimer(hwnd, 1, popup.subMenuDelay, NULL);
    				timerPointer = item;
    				itemCaller = hwnd;
    				timerHeight = counter22;
    				previousCounter2 = previousCounter;

    				counter2 = counter22;
    				break;
    				}
    		}
    		counter22 = counter22 + item->height;
    		previousCounter = previousCounter + item->height;
    		item = item->next;
    	}
    	break;

    case WM_ACTIVATE:
    	
    	fActive = LOWORD(wParam);

    	if(fActive == WA_INACTIVE)
    	{
    		hwndGetFocus = (HWND)lParam; // handle of window receiving focus 
    		
    		if(goingToSubMenu == TRUE || hwndGetFocus == hMainWnd)
    			break;
    		p = 1;
    		do
    		{
    			if(subList[p].subMenuHwnd == hwndGetFocus)
    				return 0;
    			p++;
    		}while(p < (subEnum +1));
    		previousItem = NULL;
    		previousCounter2 =0;
    		counter2 = 0;
    		isMainWindowHidden = TRUE;
			popup.isSelected = NULL;
    		ShowWindow(hMainWnd, SW_HIDE );
    		destroyAllSubMenus();
    		return 0;
    	}
    	break;	
    
    case WM_LBUTTONDOWN:
    	GetCursorPos(&pt);
    	GetWindowRect(hwnd, &r);
    	pt.x -= r.left;
    	pt.y -= r.top;
    	
    	item = subList[subEnum].subMenu->root;

    	tempEnum2 = 0;
    	if(tempEnum < subEnum)
    	{
    		tempEnum2 = subEnum;
    		item = subList[tempEnum].subMenu->root;
    		while(tempEnum2 > tempEnum)
    		{
    			destroyCurrentSubMenu();
    			tempEnum2--;
    		}
    	}

    	while(item != NULL)
    	{
    		counter = counter + item->height;
    		
    		if(pt.y > 0 && pt.y < counter && pt.x > 0 && pt.x < r.right&& hwnd == subList[subEnum].subMenuHwnd)
    		{
//				char temp[256];
    
    			if(item->SMenu == NULL )
    			{
    				if(item->command[0] != '!')
    				{
    					SHELLEXECUTEINFO si;
    					memset(&si, 0, sizeof(si));
    					si.cbSize = sizeof(SHELLEXECUTEINFO);
    					si.lpDirectory = NULL;
    					si.lpVerb = NULL;
    					si.nShow = 1;
    					si.fMask = SEE_MASK_DOENVSUBST;
    					si.lpFile = item->command;
    					si.lpParameters = item->params;
    					ShellExecuteEx(&si);
    				}
    				
    				else
    					ParseBangCommand (hwnd, item->command, item->params);

    				destroyAllSubMenus();
    				isMainWindowHidden = TRUE;
    				previousItem = NULL;
    				previousCounter2 =0;
    				counter2 = 0;
					popup.isSelected = NULL;
    				ShowWindow(hMainWnd, SW_HIDE );

    				break;
    			}
    			else
    			{
    				displaySubMenu(hwnd, item, counter);
    				break;
    			}
    				
    		}
    		else if(tempEnum < subEnum)
    		{
//				char temp[256];
    
    			if(item->SMenu == NULL )
    			{

//					strcpy(temp, item->command);

    				if(item->command[0] != '!')
    				{
    					SHELLEXECUTEINFO si;
    					memset(&si, 0, sizeof(si));
    					si.cbSize = sizeof(SHELLEXECUTEINFO);
    					si.lpDirectory = NULL;
    					si.lpVerb = NULL;
    					si.nShow = 1;
    					si.fMask = SEE_MASK_DOENVSUBST;
    					si.lpFile = item->command;
    					si.lpParameters = item->params;
    					ShellExecuteEx(&si);
    				}
    				else
    					ParseBangCommand (hwnd, item->command, item->params);

    				destroyAllSubMenus();
    				isMainWindowHidden = TRUE;
    				previousItem = NULL;
    				previousCounter2 =0;
    				counter2 = 0;
					popup.isSelected = NULL;
    				ShowWindow(hMainWnd, SW_HIDE );

    				break;
    			}
    			else
    			{
    				goingToSubMenu = TRUE;
    				displaySubMenu(hwnd, item, counter);
    				break;
    			}

    		}
    		item = item->next;
    	}
    	break;		
	case WM_KEYDOWN: //Subfolder key navigation
		switch (wParam) {
		case VK_ESCAPE:
			// Destroy the popup menu if the user hits ESCAPE
			destroyAllSubMenus();
			isMainWindowHidden = TRUE;
			popup.isSelected = NULL;
			ShowWindow(hMainWnd, SW_HIDE);
			break;
		case VK_DOWN: //Sub folder
			if (wentRight[subEnum]) {
				if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->isSelected->next);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
				} else {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
				}

			} else {
				if (subEnum == 1) {
					destroyCurrentSubMenu();
				    WndProc(hMainWnd, message, wParam, lParam);
				} else {
					destroyCurrentSubMenu();
					if (subList[subEnum].subMenu->isSelected != subList[subEnum].subMenu->current) {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected->next);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->isSelected->next;
					} else {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->root);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
					}
				}
			} 
			break;
		case VK_UP: //Sub folder
			if (wentRight[subEnum]) {
				if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) {
					keyedSubMenu(hwnd, subList[subEnum].subMenu->current);
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
				} else {
					menuItem *temper = subList[subEnum].subMenu->root;
					while (subList[subEnum].subMenu->isSelected != temper->next) {
						temper = temper->next;
					}
					keyedSubMenu(hwnd, temper);
					subList[subEnum].subMenu->isSelected = temper;
				}
			} else {
				if (subEnum == 1) {
					destroyCurrentSubMenu();
				    WndProc(hMainWnd, message, wParam, lParam);
				} else {
					destroyCurrentSubMenu();
					if (subList[subEnum].subMenu->isSelected == subList[subEnum].subMenu->root) {
						keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->current);
						subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->current;
					} else {
						menuItem *temper = subList[subEnum].subMenu->root;
						while (subList[subEnum].subMenu->isSelected != temper->next) {
							temper = temper->next;
						}
						keyedSubMenu(subList[subEnum].subMenuHwnd, temper);
					}

				}
			}
			break;
		case VK_RIGHT: //Sub folder
			if (wentRight[subEnum]) {
				if (subList[subEnum].subMenu->isSelected->SMenu != NULL && subList[subEnum].subMenu->isSelected != NULL) { 
					int totalHeight = titleHeight+subList[subEnum].subMenu->root->height;
					menuItem *temper = subList[subEnum].subMenu->root;
					while (temper != subList[subEnum].subMenu->isSelected) {
						totalHeight = totalHeight + temper->height;
						temper = temper->next;
					}
					displaySubMenu(hwnd, subList[subEnum].subMenu->isSelected, totalHeight);
					keyedSubMenu(subList[subEnum+1].subMenuHwnd, subList[subEnum].subMenu->isSelected->SMenu->root);
				}

			} else {
					subList[subEnum].subMenu->isSelected = subList[subEnum].subMenu->root;
					keyedSubMenu(hwnd, subList[subEnum].subMenu->root);
					wentRight[subEnum] = TRUE;
			}
			break;
		case VK_LEFT: //Sub folder
			if (wentRight[subEnum]) {
				wentRight[subEnum] = FALSE;
				subList[subEnum].subMenu->isSelected = NULL;
				if (subList[subEnum].subMenu->root->itemLevel == 1) {
					destroyCurrentSubMenu();
					keyedSubMenu(hMainWnd, popup.isSelected);
				} else { 
					destroyCurrentSubMenu();
					keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
				}
			} else {
				if (subEnum>1) {
					if (subList[subEnum-1].subMenu->isSelected != NULL) {
						if (subList[subEnum-1].subMenu->isSelected->SMenu != NULL) {
							destroyCurrentSubMenu();
							wentRight[subEnum] = FALSE;
							subList[subEnum].subMenu->isSelected = NULL;
							destroyCurrentSubMenu();
							if (subEnum > 0) {
								keyedSubMenu(subList[subEnum].subMenuHwnd, subList[subEnum].subMenu->isSelected);
							} else {
								keyedSubMenu(hMainWnd, popup.isSelected);
							}
						}
					}
				}
			}
			break;
		case VK_RETURN: //Sub folder
			if (previousItem != NULL && previousItem->itemLevel == 0) {
	    		if(previousItem->SMenu == NULL) {
	    			char temp[256];
					strcpy(temp, previousItem->command);
	    			destroyAllSubMenus();
	    			if(previousItem->command[0] != '!') {
	    				SHELLEXECUTEINFO si;
						memset(&si, 0, sizeof(si));
    					si.cbSize = sizeof(SHELLEXECUTEINFO);
	    				si.lpDirectory = NULL;
						si.lpVerb = NULL;
    					si.nShow = 1;
    					si.fMask = SEE_MASK_DOENVSUBST;
    					si.lpFile = previousItem->command;
    					si.lpParameters = previousItem->params;
	    				ShellExecuteEx(&si);
					} else
	    				ParseBangCommand (hwnd, previousItem->command, previousItem->params);
	    			previousItem = NULL;
					previousCounter2 =0;
    				counter2 = 0;
    				isMainWindowHidden = TRUE;
					popup.isSelected = NULL;
    				ShowWindow(hwnd, SW_HIDE );
	    			break;
				}
			} 
			break;
		}
		break;
	}
    return DefWindowProc(hwnd, message, wParam, lParam);
}

void keyedSubMenu(HWND menu, menuItem *showItem) {
	RECT lpMenu;
	int height;
	menuItem *temper;

	if (showItem->itemLevel ==0)
		temper=popup.root;
	else
		temper=subList[showItem->itemLevel].subMenu->root;
	height=titleHeight;
	while (temper != showItem) {
		height = height + temper->height;
		temper = temper->next;
	}
	GetWindowRect(menu, &lpMenu);
	SetCursorPos(lpMenu.left+2, lpMenu.top+height+2);
//	SetForegroundWindow(menu);
//	SetFocus(menu);
}
