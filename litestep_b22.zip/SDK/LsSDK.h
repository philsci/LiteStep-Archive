/*********************************************************************/
/*                                                                   */
/* LiteSTEP Wharf Module SDK 1.2                                     */
/*                                                                   */
/* Copyright (c)1998 Francis Gastellu aka Lone Runner/Aegis          */
/*                                                                   */
/*********************************************************************/
/*                                                                   */
/* Header file                                                       */
/*                                                                   */
/* ----------------------------------------------------------------- */

#ifndef __LSSDK_H
#define __LSSDK_H

/* ----------------------------------------------------------------- */

#include <windows.h>

/* ----------------------------------------------------------------- */

typedef struct {
    HWND Handle;
    BOOL Visible;
    RECT Position;
    } windowType;

typedef struct {
	int borderSize;
	int pos;
	int winListSize;
	windowType *winList;
	int trayIconSize;
    int lm78Unit;
    int lm78MaxCpu;
    int lm78MaxMb;
    int lm78Cpu;
    int taskBar;
    int msTaskBar;
    int taskBarFore;
    int taskBarBack;
    int taskBarText;
    int vwmVelocity;
    int autoHideWharf;
    int autoHideTaskbar;
    int VWMDistance;
    int autoHideDelay;
    int showBeta;
    int usClock;
	int VWMNoGathering;
	int VWMNoAuto;
    } wharfDataType;

/* ----------------------------------------------------------------- */

long magicDWord = 0x49474541;

/* ----------------------------------------------------------------- */

#ifdef __cplusplus
extern "C" {
#endif

__declspec( dllexport ) int initWharfModule(HWND parent, HINSTANCE dll, wharfDataType *wd);
__declspec( dllexport ) void quitWharfModule(HINSTANCE dllInst);

#ifdef __cplusplus
}
#endif

#endif
