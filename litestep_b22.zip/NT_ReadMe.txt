

  It came to my knowledge that installing LiteSTEP under NT is not very difficult :

  - Use regedit.
  - Go to key HKLM\SOFTWARE\Microsoft\Windows NT\Current Version\Winlogon\
  - Change the data string "Shell" (currently to EXPLORER.EXE) to "yourpath\LITESTEP.exe"

  HOWEVER...
  ----------

  Yes... however... i've been told it prevents Explorer from opening more than 1 window at a time.

  I've traced explorer to know why it does so, and ended up with the conclusion that microsoft,
  beside some function in the api made to simplify shell development, did not intended anyone
  to make a new shell. In fact explorer relies on the explorer-shell to enable multiple instances
  (that is, it tries to communicate with the main explorer to tell 'open a new window'). Only
  a patch will make explorer behave correctly with litestep. I'm looking in this direction.

  Wait for an update... sorry for this problem.


  Also, please, don't try to use the LM78 module under NT, it will fail with a priviliedged
  instruction error message. That's normal, NT forbids any direct access to IO ports.


  Note: Beside these problems, Litestep is still usable under NT (and many people use it), so if
        you can't manage to make it work, please think twice before putting the fault on litestep,
        thanks ;)
