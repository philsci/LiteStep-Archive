
  For contact, see at the end of this document.

  =============================================================================
  => LITESTEP 1.0 �22
  =============================================================================

  Quickly what's new ?

     1.0 �22- 04/13/98
            - Added tooltips on taskbar app buttons (when title stripped) & system tray
            - Fixed windows on taskbar that shouldn't have been on taskbar
            - Fixed Winamp minimize to tray only
            - Updated SDK to reflect news
            - Programs are now run from their paths instead of c:\
            - Modified popup menu case sensitive sort to case insensitive
            - Added HotListName function to modify name of the root popup menu
            - Added option to disable window gathering to physical desktop upon recycling
            - Added option todisable vwm autoswitch
            - Added Right-click on LARGE popup menus to double working area
            - Modified default step.rc to fix control panel loading
            - Added popup menu actions: !PopupPrograms !PopupRecentDocs, !PopupPersonal,
              !PopupDesktop, !PopupFolder:..., and !PopupRun
            - Added Wharf action: !WharfRun
            - System tray does not loose icons upon recycling anymore
            - Lowered memory/resource consumption
            - Fixed dynamic resolution changes
            - Added autohide features for Wharf & Taskbar ("AutoHideWharf", "AutoHideTaskbar",
              "AutoHideDelay n")
            - Added option to remove the Beta version on the desktop ("NoShowBeta")
            - Added auto-detection when a window title changes. Taskbar is now updated in real
              time.
            - Fixed NoTaskbar setting that made startup programs not loading
            - Cleanup on taskbar code (no more flashs)
            - Fixed a little bug on the system tray that made some icons disapear
            - Fixed applications launching 'behind' litestep
            - Added option to specify the security mouse distance with lsvwm autoswitch
              ("VWMSecurityDistance n").
            - Added double-click on lsvwm to toggle autoswitch
            - Added European/Us lsclock mode option ("UsClock")
            - Fixed year 2000 problem for lsclock
            - Added more fixes for eudora
            - Fixed popup aligment proplems
            - Fixed popup Access violation problems
            - More ? Yes definitly... can't remember :)


   What is LiteSTEP ?
   ------------------


     LiteSTEP is a shell replacement for Windows95 (NT not fully supported) that will give
     your Windows the AfterSTEP look&feel.


     It consists in a Wharf toolbar, a popup menu and some modules.

     The Wharf toolbar is used to organize your applications & modules.

     The Popup menu will automatically gives you access to installed applications via its
     start menu.

     The Modules are used to their particular function: Clock, Temperature monitor,
     WinAMP plugin, Virtual Window Manager...


   Your reasons for using LiteSTEP :
   ---------------------------------

     - If you come from the LINUX world and are used to AFTERSTEP.

     - If having multiple desktops would make your work easier.

     - If you dislike Microsoft's Shell or find it eats too much memory, CPU and that it is
       not always stable.

     - If the aspect of your desktop is important to you.

     - If you like to have something different from your friends.

     Or simply to try a cool & stable alternative to Microsoft's Shell.


  =============================================================================
  => INSTALLATION PROCEDURE
  =============================================================================


 - Extract files in C:\LITESTEP (or you're gonna edit your step.rc)
 - Either Edit system.ini or use ShellSw to replace your shell

    - method 1: edit system.ini:

         [boot]
         shell=explorer.exe

         replace by :

         [boot]
         shell=c:\litestep\litestep.exe

    - method 2: use shellsw:

         install shellsw as indicated in its doc

 - Edit step.rc to match your configuration


  =============================================================================
  => UPGRADING FROM PREVIOUS VERSION
  =============================================================================

    1.0 �11 -> 1.0 �12+ : Remove section [WharfAmp Spectrum Analyzer] in
                          plugin.ini, in Winamp's directory!
                          (parameters behaviour is REALLY different, so
                          removing this will ensure you have some correct
                          setup that you can then customize again)
    1.0 �10 -> 1.0 �11+ : Move STEP.RC to LiteStep's directory!
                          Remove any !WharfLogoff, !WharfDos & !WharfRestart
                          command from step.rc 
    1.0 �3 -> 1.0 �4+   : Remove lstep.dll
    1.0 �1 -> 1.0 �2+   : Name chage (Simplestep -> LiteStep)
                          Pay attention to directory name!


  =============================================================================
  => USAGE
  =============================================================================

  Usage is quiet easy, there are therefore some tricks that you should know :


    The lsvwm virtual window manager:


        - Left Click & drag   = drag windows between desktops
        - Right click         = select desktop
        - ALT-UP, ALT-DOWN, 
          ALT-LEFT, ALT-RIGHT = Moves between desktops

        + Holding the mouse at the screen border will autoswitch desktop (configure
          resistance to fit your needs)


     The task manager:

        - Left click          = Switch to task
        - Right click         = open system menu
        - Shift-Right Click   = Sets tip to Window class (usefull to set a 64x64
                                icon)

     The WharfAmp:

        - Left-Click          = Switchs to WinAmp


     The lsclock:

        - Left-DblClick       = Opens time & date properties


     Overall:

        - Alt-TAB             = Switch tasks


     Popup Menu

        - Right-Click         = Scroll down BIG popup menus (larger than the screen)



  =============================================================================
  => STEP.RC STRUCTURE
  =============================================================================


  Notes:

    => Thoses specifications are about to change without notice
    => Step.RC is a straight text file, where lines are delimited with carriage returns
    => Any string may be enclosed by quotes ("). This may be usefull for long names paths
       and filenames, font names & Wharf tiles that can, this way, include SPACES.


  Commands
  --------

  - PixmapPath path

    Sets the directory where to look for images

    > path = directory where to look at

  - DefaultBackPix bitmap

    > bitmap = bitmap you want to use as background when you use the ".extract" function to
      automatically assing an icon.

  - WharfTitleFontSize n

    Sets the font size of the wharf titles (usually only used by the task manager unless
    a WharfAllTitles command has been issued)

    > n = size of font in points


  - WharfTitleFont fontname

    Sets the font used for the wharf titles (usually only used by the task manager unless
    a WharfAllTitles command has been issued)

    > fontname = name of font


  - WharfTitleFore color

    Sets the Wharf titles foreground color

    > color = RGB components of color to be used (ie: FFFFFF = white, 000000 = black,
      808080 = grey)


  - WharfTitleBack color

    Sets the Wharf titles background color

    > color = RGB components of color to be used (ie: FFFFFF = white, 000000 = black,
      808080 = grey)


  - WharfAllTitles

    Tells LiteStep to put titles on all Wharfs, even normal & folder ones.


  - LoadModule modulename

    Loads a DLL global module

    > modulename = path & name of the DLL module file to load


  - NTStyleTaskMgr

    Tells Task Manager to behave like NT explorer shell, that is: when a window is the
    selected window, a click on its icon will minimize it.

    Without this command, the task manager will just switch back to the selected window
    upon clicking on its icon.

    This is not a recommended setting since it is quiet confusing (at the beginning at least)


  - WharfBevelWidth n

    Width of the wharf bevel (thickness of buttons)

    > n = width in pixel


  - WharfPressOffset n

    Offset to shift image for button press effect (usually set to same value as WharfBevelWidth)

    > n = shift in pixel


  - WharfNoHints

    Tells LiteStep not to show hints with Wharf names when the mouse stops on a Wharf


  - WharfNoAnim

    Tells LiteStep not to animate appearance of menus

  - Icon iconname [.] regexp

    sets the task manager icon for the specified window.

    > iconname = icon to use for the Wharf image
    > . = sets class name regexp instead of window name regexp
    > regexp = regular expression to apply against window name or class name (ie: *Netscape will
      match any window name ending with the word 'Netscape')


  - NoShowBeta

    Removes the Beta symbol at the topleft screen corner.


  - AutoHideWharf

    Sets the wharf bar to autohide when not selected


  - AutoHideTaskbar

    Sets the taskbar to autohide when not selected.


  - AutoHideDelay

    Sets the delay between deselection and auto-hiding of wharf & taskbar   


  - *Wharf 

       The *Wharf command may be used in 3 ways:


           - *Wharf wharfname iconname [%systemname] action [parameters]

              Sets a new visible Wharf, launching a command

              > wharfname = name to appear in Hints
              > iconname = icon to use as the Wharf image (or ".extract" to extract from an exe file)
              > %systemname = (optional) tells the Wharf systemname (used by the WharfAmp plugin
                for example)
              > action = any action to perform
              > parameters = any parameter to pass to the action

           - *Wharf wharfname iconname Folder

              Sets a new visible Wharf, opening a Wharf folder

              > wharfname = name to appear in Hints
              > iconname = icon to use as the Wharf image
              > Folder = Word "Folder"

           - *Wharf ~Folder

              Closes Wharf folder definition

              > ~Folder = Word "~Folder"

  - *Popup 

     The Popup command is used in 3 ways:

           - *Popup Entryname action [parameters]

             Sets a new entry with its title and action
             (See bellow for special actions)

           - *Popup Entryname Folder

             Sets up a new folder

           - *Popup ~Folder

             Closes previous folder

  - PopupTitlePix bitmap

    Sets texture of title entries in popup menu. Bitmap should be aprox. 17x400


  - PopupEntryPix bitmap

    Sets texture of normal unselected entries in popup menu. Bitmap should be aprox. 17x400

  - PopupSelEntryPix bitmap

    Sets texture of selected entries in popup menu. Bitmap should be aprox. 17x400

  - PopupTitleColor rgbvalue

    Sets font color for popup title entry. ie: FFFFFF

  - PopupEntryColor rgbvalue

    Sets font color for popup unselected entry. ie: 000000

  - PopupSelEntryColor rgbvalue

    Sets font color for popup selected entry. ie: 000000

  - HotListName name

    Sets name of the root popup menu. ie: HotListName Popup Menu


------------------------------------------------------------------------------
  ------ Everything bellow this line is dedicated to external modules -----

  Desktop:

  - SysTrayIconSize n

    Specifies size of system tray icons.

    > n = size in pixel

  - NoTaskBar

    Tells desktop module not to create a taskbar

  - MsTaskBar

    Tells desktop module to create a microsoft-like taskbar instead of litestep's own one.

  - LSTaskBarFore color
  - LSTaskBarBack color
  - LSTaskBarText color

    > color = rvd hexadecimal value of colors for taskbar foreground, background & text

  LM78

  - lm78Cpu cputype

    Specifies your CPU type for the lm78 monitor

    > cputype = "amd", "cyrix", or "intel"

  - lm78Unit unit

    Specifies Temperature units

    > unit = "C" or "F"

  - lm78MaxCpu n

    Specifies cpu temperature above witch the warning led flashes

    > n = temperature limit

  - lm78MaxMb n

    Specifies mother board temperature above witch the warning led flashes

    > n = temperature limit

  Virtual Window Manager

  - VWMVelocity n

    Sets the apparent resistance of screen border

    > n = milliseconds to hold the mouse at the border before switching


  - VWMNoAuto

    Disable vwm autoswitch


  - VWMNoGathering

    Disable gathering of windows upon recycling


  LSCLOCK

  - UsClock

    Sets clock to 12h format instead of 24h format

------------------------------------------------------------------------------

  Actions for Wharf
  -----------------


    !WharfRecycle

       Reload LiteStep configuration & Wharfs

    !WharfShutdown

       Opens Shutdown/Restart/MsDos/Logoff Menu

    !WharfLogoff

       Close all programs and Logoff.

    !WharfTasks

       Opens task manager

    d:\path\filename.exe [params]

       Runs the specified filename

    @c:\path\module.dll

       Loads the specified Wharf module
       NOTE: This commands takes effect DURING THE STEP.RC LOADING, not when you click on
       the wharf!

    !WharfRun

       Pops up the Run box.

  Actions for Popup
  -----------------

    !PopupStartMenu

       Automatically insterts the Start menu folder contents in the popup's tree hierarchy

    !PopuShutdown

       Opens Shutdown/Restart/MsDos/Logoff Menu

    !PopupLogoff

       Close all programs and Logoff.

    !PopupPrograms 

       Fills following tree with contents of the programs system folder

    !PopupRecentDocs

       Fills following tree with contents of the Recently open documents system folder

    !PopupPersonal

       Fills following tree with contents of the Personal documents system folder

    !PopupDesktop

       Fills following tree with itms from explorer's Desktop (except system items such as
       network neighborood, my computer, trashcan... )

    !PopupFolder:...

       Fills following tree with contents of the specified folder. ie: !PopupFolder:C:\Temp
       (Warning: putting big trees like root folders will make the popup menu loading very long)

    !PopupRun

       Pops up the Run box.


  =============================================================================
  => TIPS
  =============================================================================

     Here are some tips you could use to customize your STEP.RC:

      - "explorer /e" will open explorer in the Desktop section.
      - "explorer /s" will open an explorer cabinet file
      - The file "Exit To Dos.PIF" in your windows directory will shutdown
        windows and exit to DOS
      - "control filename.cpl" will open the specific control pannel application
        (ie: "control timedate.cpl" will open time & date properties)
      - You can make .LNKs files and launch them (usefull for network neighborhood for ex)
      - You can also launch any document, just puts its name (ie: mytext.doc)

     For more advanced users:

     When you know the CLSID of an explorer namespace, you can use it this way:

     (extract from MS Sdk Help)

         - If the junction point is an item under the desktop:

           explorer.exe /e,/root,::{CLSID of item}


         - If the junction point is an item under My Computer:

           explorer.exe /e,/root,,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}
           \::{CLSID of item}
   

         - If the junction point is a file system folder:

           explorer.exe /e,/root, [path to a junction point]


      For an example, look at the default step.rc. The control panel is run using this method.


  =============================================================================
  => KNOWN BUGS
  =============================================================================

    * I personnaly run LiteSTEP since its beginning in developpement, and had NO problem.
    * I also know of tenth of people using it always or sometimes and not reporting any major
      problem.
      
       However, here is a list of the known small bugs:


     - The lsvwm (Virtual Window Manager) is still not perfect in its behaviour.
       When you have only one app open in a desktop and you close/minimize it,
       it should not switch desktop. Sometimes it does.
     
     - Sometimes (very rarely), lsvwm's border is white... Never saw it, but i had such
       reports (in fact, one ;)

     - (very) Buggy windows installations may not be able to boot back or load Explorer. 
       *I've seen this only ONCE* and on a VERY BUGGY WINDOWS installation <=
       Since there is STRICTLY NO CODE in litestep TO WRITE ANYTHING ANYWHERE (this was one of
       the main directions of my software, so you have total control over it), blame microsoft.


  =============================================================================
  => WHAT'S NEW ?
  =============================================================================


     LiteStep WHATSNEW


     1.0 �22- 04/09/98
            - Added tooltips on taskbar app buttons (when title stripped) & system tray
            - Fixed windows on taskbar that shouldn't have been on taskbar
            - Fixed Winamp minimize to tray only
            - Programs are now run from their paths instead of c:\
            - Updated SDK to reflect news
            - Modified popup menu case sensitive sort to case insensitive
            - Added HotListName function to modify name of the root popup menu
            - Added option to disable window gathering to physical desktop upon recycling
            - Added option todisable vwm autoswitch
            - Added Right-click on LARGE popup menus to double working area
            - Modified default step.rc to fix control panel loading
            - Added popup menu actions: !PopupPrograms !PopupRecentDocs, !PopupPersonal,
              !PopupDesktop, !PopupFolder:..., and !PopupRun
            - Added Wharf action: !WharfRun
            - System tray does not loose icons upon recycling anymore
            - Lowered memory/resource consumption
            - Fixed dynamic resolution changes
            - Added autohide features for Wharf & Taskbar ("AutoHideWharf", "AutoHideTaskbar",
              "AutoHideDelay n")
            - Added option to remove the Beta version on the desktop ("NoShowBeta")
            - Added auto-detection when a window title changes. Taskbar is now updated in real
              time.
            - Fixed NoTaskbar setting that made startup programs not loading
            - Cleanup on taskbar code (no more flashs)
            - Fixed a little bug on the system tray that made some icons disapear
            - Fixed applications launching 'behind' litestep
            - Added option to specify the security mouse distance with lsvwm autoswitch
              ("VWMSecurityDistance n").
            - Added double-click on lsvwm to toggle autoswitch
            - Added European/Us lsclock mode option ("UsClock")
            - Fixed year 2000 problem for lsclock
            - Added more fixes for eudora
            - Fixed popup aligment proplems
            - Fixed popup Access violation problems
            - More ? Can't remember :)

     1.0 �21- 03/25/98
            - Modified LSVWM so it is now aware of Photoshop & Eudora. Photoshop's tool
              windows will not be screwed up anymore upon switching virtual screen. Eudora's
              progress bar will be automatically recentered when it appears.
              These are specific fixes because eudora and photoshop handle windows a way that
              is not compatible with virtual desktop tools. Now it will work with LiteStep, enjoy!
            - Added background texture for selected entry in the popup menu. Removed background
              color, thus, PopupBarColor entry in step.rc is no more relevant. Use
              PopupSelEntryPix instead.
            - Added PopupSelEntryColor in step.rc
            - Fixed problem with b20 that made the Wharf sometime disapear
            - Fixed the b20a bug. Wharf menu did not close upon deactivation
            - Documented new step.rc settings
            - Fixed ALT-F4 on taskbar

     1.0 �20- 03/25/98
            - Added the loooong awaited Popup menu! Right click on desktop, see new step.rc
            - Various small memory leak bug fixed

     1.0 �19- 03/18/98
            - Switching to fullscreen DOS boxes now works
            - Made litestep-style taskbar customizable in colors
            - Added automatic virtual window switching when mouse is hold by the side
              of the screen. (apparent resistance of the screen border is customizable
              in the step.rc)
            - System tray now antialias its icons
            - Taskbar now takes small icon in priority, then antialias the big icon if
              necessary.

     1.0 �18- 03/17/98
            - Added new taskbar look (use "MsTaskBar" to use normal look)
            - Fixed small problems appeared with the taskbar

     1.0 �17- 03/15/98
            - Special .LNK files (dialup, network, recycle bin...) are now run.
            - Environement variables are now resolved in paths
            - Added taskbar part of the desktop module. To disable it, put "NoTaskBar" in your
              step.rc

     1.0 �16- 03/08/98
            - First Public Beta
            - Now runs also User specific Run & RunOnce registry keys
            - Fixed ShellSw bug: SystemIni line was ignored, C:\WINDOWS\SYSTEM.INI
              was assumed.

     1.0 �15- 02/20/98
            - lsvwm now allows moving maximized windows
            - small lsvwm bugfixes + speedup
            - Removed unnecessary windows from task manager

     1.0 �14- 02/05/98
            - Added the LM78 plugin (Check that if you have a TX motherboard!,
              WARNING: That works ONLY with TX boards! Currently it has been
              tested on a TX-98E/AMDK6 and works, but i don't know for other
              configs, give me some feedback!)
              => look the spep.rc to configure le lm78 module!

     1.0 �13- 02/03/98
            - Re-enabled !WharfLogoff command due to the fact that 
              IE4 removes this option from the shutdown menu (thanx ms)
            - Fixed previous !WharfLogoff command. Now works fully with
              any MSDOS box in the logoff way.
            - Fixed a little bug in lsvwm (appeared with "out of any desktop"
              windows taking focus)
            - Disabled child windows appearing in Task Manager

      1.0 �12- 01/31/98 - Read UPGRADE.TXT!
            - Removed a load of ridiculously small and harmless bugs :)
            - Modified WharfAmp so it has a logarithmic scale, please
              REMOVE the [WharfAmp Spectrum Analyzer] section in winamp's
              plugin.ini !!! (read UPGRADE.TXT)

     1.0 �11- 01/30/98
            - Modified !WharfShutdown to open windows shutdown box
            - Removed old !WharfShutdown, !WharfLogoff & !WharfDos
              (they were quiet buggy, and are no more needed due to the
              new !WharfShutdown and ALT-F4)
            - Fixed some minor lsvwm bugs (now seems to be quiet bug-free!!)
            - Added Hotkeys ALT-Arrows to switch desktop
            - Added auto-iconed task manager when not configured
            - Speeded-up the close menu function
            - Now starts & remove whatever is in the RunOnce registry key
            - Added RightClick on task manager icons to open System Menu
              for the application
            - Added Shift-RightClick on task manager icons to set tip to
              the window class name (usefull to configure 64x64 icons in
              the step.rc)
            - the STEP.RC configuration file is now searched in the
              executable's directory, be carefull!

     1.0 �10- 01/24/98
            - Fixed System tray (undocumented features sux)
            - Fixed (again) some lsvwm bugs
            - Removed desktop icon from ALT-TAB
            - Fixed WM_QUERYENDSESSION response (will now work with programs that makes
              windows restart)
            - Now starts whatever is in the Run registry key (so now fully compatible with
              Seagate Direct Tape Access & other softwares that run init in the registry
              instead of start menu)
            - Now starts any program in the start menu

     1.0 �9 - 01/18/98
            - Added System Tray
            - Fixed numerous lsvwm bugs
            - Added Double-Click on lsclock opens Date&Time properties

     1.0 �8 - 01/11/98
            - Added lsvwm (Virtual Window Manager)
            - Added desktop module (faster & more accurate task manager, and will include
              soon a system tray)
            - Added Win95 Key to open TaskMgr
            - Added ESC to close a menu
            - Various fixup
            - Recompiled WharfAmp & lsclock without debug code (woops ;))

     1.0 �7 - 01/05/98
            - Added parsing of '"' in step.rc (names/commandlines/bitmaps...)

     1.0 �6 - 01/04/98
            - Completed module handling (added internal modules)
              => use @module.dll to use
            - Added lsclock module (similar to asclock)

     1.0 �5 - 01/03/98
            - Added first part of Module handling (externaly
              driven modules only for now)
              => use %WinName tag to use
            - Added WharfAmp module (WinAmp spectrum analyzer
              in a wharf)

     1.0 �4 - 01/01/98
            - Fixed problems with DirectX games
            - Removed DLL usage
            - Code speedup
            - Added ALT-F4 menu
            - Fixed close query

     1.0 �3 - 12/20/97
            - Added TaskManager bar
            - Fixed small issues
            - Removed fake desktop component to reduce cpu usage
              (now using only one (the real) desktop)
            - Really usable
            - Known bug
                 - Does not provide auto-insert notifications, thus,
                   does not work with Adaptec Direct-CD, Seagate Direct
                   Tape Access, and such proggies.

     1.0 �2 - 12/18/97
            - Changed name (previously SimpleStep)
            - Fixed:
                 - ALT-F4 closed wharf & desktop
                 - Wharf bar was not always on top
                 - Wharf menu was not closed upon activation of an app
                 - Maximize event was not handled
            - Still needs a taskmanager
            - Quiet usable
            - Added Wharf menu animations
            - Added Icons loading in memory for faster access

     1.0 �1 - 12/14/97
            - First beta out (private)
            - Lot of bugs
            - Not fully usable

  =============================================================================
  => FUTUR ENHENCEMENTS
  =============================================================================

      Some enhencements are planned:

       - A Control Panel

           => This will make configuration much more easy

       - A DDE Server

           => This will make LiteSTEP compliant with old installation softwares that
              want to create icons in Program Manager (today installations don't use
              this method anymore)

       - ... Any idea ?


      NOTE: In the directory SDK you can find the Software Developement Kit to build
            Wharf Modules. Be creative !

  =============================================================================
  => LICENSE / DISCLAIMER / CONTACT
  =============================================================================


      LiteSTEP is still in beta stage.

      LiteSTEP is freeware. Use it at your own risks! I cannot be held responsible for
      any damage (software or hardware) happened while using LiteSTEP.

      LiteSTEP has been tested by many people, many people use it on a daily basis, and
      no incident happened. Thus i really deny responsability on any problem you could have.

      LiteSTEP is free to use & give to your friends, i don't ask for any money, nor i offer any
      official technical support. However, if you have some questions, i may be reached at the
      following addresses. (I cannot garantee that i will answer every mail since i'm REALLY
      busy all the time).


      email:

         note: before email me, please check web page for known bugs.

         gastellu@club-internet.fr
         francis@ace.epita.fr


      web page:

         http://www.anandtech.com/litestep


  =============================================================================
  => EOR (End Of Reame)
  =============================================================================
