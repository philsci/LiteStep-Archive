#pragma warning(disable: 4786)

#include "../core/ifcs.h"
#include <string>

using namespace std;

typedef void (*BANG)(HWND sender, LPCSTR args);
typedef void (*BANGEX)(HWND sender, LPCSTR args, LPCSTR command);

class CallbackBangCommand : public IBangCommand  
{

public:
	CallbackBangCommand(BANG b);
	CallbackBangCommand(BANGEX b, wstring command);
	virtual ~CallbackBangCommand();

	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
  ULONG STDMETHODCALLTYPE Release( void);
	
	///////////////////////////////////////////////////////////////////////////
	// From IBangCommand
    HRESULT STDMETHODCALLTYPE Execute( 
        /* [in] */ OLE_HANDLE caller,
        /* [in] */ SAFEARRAY __RPC_FAR * params,
        /* [retval][out] */ VARIANT __RPC_FAR *result);
private:
	bool ex;
	BANG bang;
	BANGEX bangex;
	wstring command;

	long refCount;
};
