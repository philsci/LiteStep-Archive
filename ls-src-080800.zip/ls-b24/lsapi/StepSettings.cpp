// StepSettings.cpp: implementation of the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#include <windows.h>
#include "StepSettings.h"
#include "safestr.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StepSettings::StepSettings()
{
	ThemeInUse = FALSE;
	ThemeFile = "";
	StepFile = "";
}

StepSettings::~StepSettings()
{

}

FILE* StepSettings::Open(LPCTSTR szPath)
{
  FILE *f;

  f = fopen (szPath, "r");

  if (f)
  {
    fseek (f, 0, SEEK_SET);
  }

  return f;
}


BOOL StepSettings::Close (FILE *f)
{
  if (f)
  {
    fclose (f);
  }

  return TRUE;
}


BOOL StepSettings::ReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  char szTempBuffer[MAX_LINE_LENGTH];

  if (!f)
  {
    return FALSE;
  }

  while (ReadNextLine (f, szTempBuffer, sizeof (szTempBuffer)))
  {
    if (!ispunct (szTempBuffer[0]))
    {
      StrLCopy (szBuffer, szTempBuffer, dwLength);

      return TRUE;
    }
  }

  return FALSE;
}


BOOL StepSettings::ReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
  char szTempPrefix[MAX_LINE_LENGTH], szTempBuffer[MAX_LINE_LENGTH];
  int prefix_length;

  if (!f)
  {
    return FALSE;
  }

  szTempPrefix[0] = 0;

  if (szPrefix[0] != '*')
  {
    StrCopy (szTempPrefix, "*");
  }

  strcat (szTempPrefix, szPrefix);

  prefix_length = StrLen (szTempPrefix);

  while (ReadNextLine (f, szTempBuffer, sizeof (szTempBuffer)))
  {
    if (!strnicmp(szTempBuffer, szTempPrefix, prefix_length) && isspace(szTempBuffer[prefix_length]))
    {
      StrLCopy (szBuffer, szTempBuffer, dwLength);

      return TRUE;
    }
  }

  return FALSE;
}


BOOL StepSettings::ReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  char szTempBuffer[MAX_LINE_LENGTH];

  while (f && !feof (f))
  {
    StrCopy(szBuffer, "");

    if (!fgets (szTempBuffer, dwLength, f))
      break;

    StripComment(szTempBuffer);
    CleanString(szTempBuffer);

    if (szTempBuffer[0] && szTempBuffer[0] != ';')
    {
      // Because of caching, we can't do var expansion at this point
      //VarExpansion(szBuffer, szTempBuffer);
      StrCopy(szBuffer, szTempBuffer);
      return TRUE;
    }
  }

  return FALSE;
}

//---------------------------------------------------------
// Cleans leading & trailing blanks from the passed string
//---------------------------------------------------------
char* StepSettings::CleanString(char* szString)
{
  if (!szString)
    return NULL;

  char* temp = new char[StrLen(szString) + 1];
  char* current = szString;

  current += strspn(current, WHITESPACE);

  StrCopy(temp, current);

  current = &temp[StrLen(temp) - 1];

  while (isspace(*current))
    current--;

  current[1] = 0;
  StrCopy(szString, temp);

  delete[] temp;
  return szString;
}


//---------------------------------------------------------
// Strips any comments from the string
//---------------------------------------------------------
char* StepSettings::StripComment(char* szString)
{
  if (!szString)
    return NULL;

  int quoteLevel = 0;
  char lastQuote = 0;
  char* current = szString;

  for (; *current; current++)
  {
    switch (*current)
    {
      case '[':
        quoteLevel++;
        break;

      case ']':
        quoteLevel--;
        break;

      case '"':
      case '\'':
        if (lastQuote == *current)
        {
          quoteLevel--;
          lastQuote = 0;
        }
        else if (!lastQuote)
        {
          quoteLevel++;
          lastQuote = *current;
        }
        break;

      case ';':
        if (!quoteLevel)
        {
          *current = 0;
          return szString;
        }
    }
  }
  return szString;
}

void StepSettings::VarExpansion(char *buffer, const char * value)
{
  int i, j;
  char * startDollar, * endDollar;
  char * string1;
  char buf[MAX_LINE_LENGTH];
  char buf2[MAX_LINE_LENGTH];
  char bvalue[MAX_LINE_LENGTH];
  int StillVars = 1;
  char *envvar;
  VarMap::iterator it;
  char warning[MAX_LINE_LENGTH];

  if (buffer && value)
  {
    StrCopy(bvalue, value);
    CleanString(bvalue);
    StrCopy(buffer, bvalue);
  }
  else
  {
    if (buffer && !value)
      buffer[0] = '\0';
    return;
  }

  while (StillVars)
  {
    startDollar = strchr(bvalue, '$');
    if (startDollar)
    {
      endDollar = strchr(&startDollar[1], '$');
      if (endDollar)
      {
        i = StrLen(startDollar) - StrLen(endDollar) - 1;
        j = StrLen(bvalue) - StrLen(startDollar);
        string1 = startDollar;
        string1++;
        StrLCopy(buf, CharLower(string1), i);
        buf[i]='\0';

        envvar=NULL;

        string var_value;

        if (!GetVariable(buf, var_value)) {
          if (!GetRCString(buf, buf2, buf, 255)) {
            envvar = getenv(buf);
            if (envvar != NULL) {
              // caching environment variables
              AddVariable(buf, envvar);
            }
            else {
              // caching blank, prevent future lookups, errors
              AddVariable(buf, buf2);
              StrCopy(warning, "Uninitialized variable: ");
              strcat(warning, buf);
              strcat(warning, "\n\0");
              strcat(warning, "at line: ");
              strcat(warning, value);
              MessageBox(NULL, warning, "Uninitialized Variable", MB_OK | MB_ICONWARNING | MB_TOPMOST);
            }
          }
        }
        else {
          StrCopy(buf2,var_value.c_str());
        }
        if (bvalue != startDollar)
        {
          StrLCopy(buffer, bvalue, j);
          buffer[j] = '\0';
        }
        else
        {
          StrCopy(buffer, "");
        }

        if (envvar) {
          strcat(buffer,envvar);
        } else {
          strcat(buffer, buf2);
        }
        strcat(buffer, ++endDollar);
        StrCopy(bvalue, buffer);
      }
      else
      {
        StillVars = 0;
      }
    }
    else
    {
      StillVars = 0;
    }
  }
}

// reads, parses, and caches the file specified, returns as 'string' the path the file's cache was stored under
string StepSettings::CacheRCFile(LPCTSTR szPath) {
  char  buffer[MAX_LINE_LENGTH];
  char long_file[MAX_PATH_LENGTH];
  char *char_ptr;
  string rcFile;
	FILE *rc;
	
  GetFullPathName(szPath, MAX_PATH_LENGTH, long_file, &char_ptr);
  strlwr(long_file);
  rcFile = long_file;
	
	rc = Open(rcFile.c_str());

	if (!rc) {
		// could not open file, return blank file path
		return "";
	}
	
	if (CommandBuffers.find(rcFile) != CommandBuffers.end()) {
		// Re-parse, re-cache the file
		CommandBuffers.erase(rcFile);
		ConfigBuffers.erase(rcFile);
	}

	// put a vector in the map for main rc file
  CommandBuffers[rcFile] = StringVector();
  ConfigBuffers[rcFile] = CacheMap();
	
  while (ReadNextLine(rc, buffer, sizeof (buffer)))
  {
		// Currently destroys buffer, needs to be fixed
		if (buffer[0] == '*') {
			int endConfig = strcspn(buffer, WHITESPACE);
			buffer[endConfig] = '\0';
			
			string config = strlwr(buffer);
			
			CacheMap::iterator iter = ConfigBuffers[rcFile].find(config);
			if (iter == ConfigBuffers[rcFile].end()) {
				ConfigBuffers[rcFile][config] = StringVector();
			}
			
			char *begin = buffer + endConfig + 1;
			
			CleanString(begin);
			
			ConfigBuffers[rcFile][config].push_back(begin);
			continue;
		}
		
 	  CommandBuffers[rcFile].push_back(buffer);
	}

	Close(rc);

	return rcFile;
}

LPCTSTR StepSettings::FindLine(LPCTSTR szKeyName)
{
  TCHAR szCommand[64];
  LPTSTR pszCommand;
  LPCTSTR pszBuffer;
  int nLen;
  StringVector::iterator iter;

  if (ThemeInUse)
  {
	  for (iter = CommandBuffers[ThemeFile].begin(); iter != CommandBuffers[ThemeFile].end(); iter++)
    {
      pszBuffer = iter->c_str();
      pszCommand = szCommand;
      nLen = 63;

      while(*pszBuffer && !isspace(*pszBuffer))
      {
        if(nLen)
        {
          *pszCommand++ = *pszBuffer;
          nLen--;
        }

        pszBuffer++;
      }

      *pszCommand = 0;

      if(!stricmp(szCommand, szKeyName))
        return iter->c_str();
    }
  }

  for (iter = CommandBuffers[StepFile].begin(); iter != CommandBuffers[StepFile].end(); iter++)
  {
    pszBuffer = iter->c_str();
    pszCommand = szCommand;
    nLen = 63;

    while(*pszBuffer && !isspace(*pszBuffer))
    {
      if(nLen)
      {
        *pszCommand++ = *pszBuffer;
        nLen--;
      }

      pszBuffer++;
    }

    *pszCommand = 0;

    if( !stricmp( szCommand, szKeyName ) )
      return iter->c_str();
  }

  return NULL;
}


int StepSettings::GetRCInt(LPCTSTR szKeyName, int nDefault)
{
  int val = nDefault;
  LPCSTR line;
  char token[MAX_LINE_LENGTH];

  // Try to find the variable in the map
  {
    string value;

    if (GetVariable(szKeyName, value))
      return strtol(value.c_str(), NULL, 0);
  }

  // Couldn't find it, look in theme.rc/step.rc
  line = FindLine(szKeyName);
  if (line)
  {
    GetToken(line, NULL, &line, false);
    if (GetToken(line, token, NULL, false))
      val = strtol(token, NULL, 0);
  }

  // Store the value for future lookups
  char number[33];
  ltoa(val, number, 10);
  AddVariable(szKeyName, number);

  return val;
}


BOOL StepSettings::GetRCBool(LPCTSTR szKeyName, BOOL ifFound)
{
  //bool val = !ifFound; // <-- changed because of warning, not sure
  BOOL val = !ifFound;
  char token[MAX_LINE_LENGTH];
  LPCSTR line;

  {
    string value;

    if (GetVariable(szKeyName, value))
      return stricmp(value.c_str(), "true");
  }

  line = FindLine(szKeyName);
  if (line)
  {
    GetToken(line, NULL, &line, false);
    if (GetToken(line, token, NULL, false))
    {
      if (stricmp(token, "off") && stricmp(token, "false") && stricmp(token, "no"))
        val = ifFound;
    }
    else
      val = ifFound;
  }

  // Add variable to cache
  AddVariable(szKeyName, (val ? "true" : "false"));

  return (val);
}


BOOL StepSettings::GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR line;
  BOOL result = FALSE;

  // look in the variable map
  {
    string value;

    if (GetVariable(szKeyName, value))
    {
      StrLCopy(szValue, value.c_str(), maxLen);
      return TRUE;
    }
  }

  // couldn't find it, check theme/step vectors
  line = FindLine(szKeyName);
  if (line)
  {
    GetToken(line, NULL, &line, false);
    GetToken(line, token, NULL, false);
    VarExpansion(token, token);
    StrLCopy(szValue, token, maxLen);
    result = TRUE;
  }
  else
    StrLCopy (szValue, defStr, maxLen);

  // cache variable to map for future use
  AddVariable(szKeyName, szValue);

  return result;
}


COLORREF StepSettings::GetRCColor(LPCTSTR szKeyName, COLORREF colDef)
{
  COLORREF val = colDef;
  char token[MAX_LINE_LENGTH];
  LPCSTR line;

  // Try to find it in the var map
  {
    string value;

    if (GetVariable(szKeyName, value))
      return strtol(value.c_str(), NULL, 0);
  }

  // not found, look in the theme/step vectors
  line = FindLine(szKeyName);
  if (line)
  {
    int count;
    count = Tokenize(line, NULL, 0, NULL);
    GetToken(line, NULL, &line, false);

    if(count == 4)
    {
      int r, g, b;

      GetToken(line, token, &line, false);
      r = strtol(token, NULL, 10);
      GetToken(line, token, &line, false);
      g = strtol(token, NULL, 10);
      GetToken(line, token, NULL, false);
      b = strtol(token, NULL, 10);


      val = RGB(r, g, b);
    }
    else if(count >= 2)
    {
      GetToken(line, token, NULL, false);
      val = strtol(token, NULL, 16);

      if( !GetRCBool("LSColorBGR", TRUE) )
        val = RGB(GetBValue(val), GetGValue(val), GetRValue(val));
    }
  }

  // cache formatted color string to map for future use
  char store_value[33];
  ltoa(val, store_value, 10);
  AddVariable(szKeyName, store_value);

  return val;
}


BOOL StepSettings::GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault)
{
  LPCTSTR line = NULL;

  // verify parameters
  if(!szBuffer || !nBufLen)
    return FALSE;

  if (!szKeyName)
  	return FALSE;

  // find it
  {
    string value;

    if (GetVariable(szKeyName, value))
    {
      StrLCopy(szBuffer, value.c_str(), nBufLen);
      return TRUE;
    }
  }

  line = FindLine(szKeyName);

  if (!line)
  {
    if (szDefault)
      StrLCopy(szBuffer, szDefault, nBufLen);
    else
      *szBuffer = '\0';
  }
  else
  {
    char token[MAX_LINE_LENGTH];

    GetToken(line, token, &line, false);
    StrLCopy(szBuffer, line, nBufLen);
  }

  AddVariable(szKeyName, szBuffer);

  return TRUE;
}

bool StepSettings::AddVariable(LPCSTR name, LPCSTR value)
{
  LPSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  VarMap::iterator it = stepVariables.find(lowerName);
  if (it == stepVariables.end())
  {
    stepVariables.insert(VarMap::value_type(name, value));
    result = true;
  }
  delete[] lowerName;
  return result;
}


bool StepSettings::GetVariable(LPCSTR name, string& value)
{
  LPSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  iter = stepVariables.find(lowerName);
  if (iter != stepVariables.end())
  {
    value = iter->second;
    result = true;
  }
  delete[] lowerName;
  return result;
}

//---------------------------------------------------------
// Extracts the first token and returns a pointer to the
// next. Doesn't care about string lengths
//---------------------------------------------------------
BOOL StepSettings::GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets)
{
  LPCSTR current = szString;
  LPCSTR startMarker = NULL;
  LPCSTR endMarker = NULL;
  int bracketLevel = 0;
  char quoteChar = '\0';
  bool isToken = false;
	bool appendNextToken = false;

  if (szToken)
    szToken[0] = '\0';
  if (szNextToken)
    *szNextToken = NULL;

  if (!(szString && szString[0]))
    return FALSE;

  current += strspn(current, WHITESPACE);

  for (; *current; current++)
  {
    if (isspace(*current) && !quoteChar)
    {
      endMarker = current;
      break;
    }

    if (useBrackets && CharInStr(*current, "[]") && !CharInStr(quoteChar, "\'\""))
    {
      if (*current == '[')
      {
        if (isToken && !quoteChar)
        {
          endMarker = current;
          break;
        }
        bracketLevel++;
        quoteChar = '[';
        continue;
      }
      else
      {
        bracketLevel--;
        if (bracketLevel <= 0)
        {
          endMarker = current;
          break;
        }
      }
    }

    if (CharInStr(*current, "\'\"") && (quoteChar != '['))
    {
      if (!quoteChar)
      {
        if (isToken)
        {
					appendNextToken = true;
          endMarker = current;
          break;
        }
        quoteChar = *current;
        continue;
      }
      else if (*current == quoteChar)
      {
        endMarker = current;
        break;
      }
    }

    if (!isToken)
    {
      isToken = true;
      startMarker = current;
    }
  }

  if (startMarker && szToken)
    StrLCopy(szToken, startMarker, endMarker - startMarker);

  if (!appendNextToken && *current)
    current++;

  current += strspn(current, WHITESPACE);

  if (*current && szNextToken)
    *szNextToken = current;

	if (appendNextToken && *current)
    GetToken(current, szToken + strlen(szToken), szNextToken, useBrackets);

  return startMarker != NULL;
}

int StepSettings::Tokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters, bool useBrackets)
{
  DWORD i;
  char buffer[MAX_LINE_LENGTH];
  LPCSTR nextToken = buffer;
  DWORD tokens = 0;

  VarExpansion(buffer, szString);

  for (i = 0; i < dwNumBuffers; i++)
    if (lpszBuffers[i])
      lpszBuffers[i][0] = '\0';
  if (szExtraParameters)
    szExtraParameters[0] = '\0';

  if (lpszBuffers || szExtraParameters)
  {
    for (tokens = 0; nextToken && (tokens < dwNumBuffers); tokens++)
    {
      GetToken(nextToken, lpszBuffers[tokens], &nextToken, useBrackets);
    }

    if (szExtraParameters  && nextToken)
      StrCopy(szExtraParameters, nextToken);
  }
  else
    while (GetToken(nextToken, NULL, &nextToken, useBrackets))
      tokens++;

  return tokens;
}

FILE* StepSettings::LCOpen(LPCTSTR szPath)
{
	char full_path[MAX_PATH_LENGTH];
	char *char_ptr;

	if (szPath && strlen(szPath) > 0) {
		GetFullPathName(szPath, MAX_PATH_LENGTH, full_path, &char_ptr);
		strlwr(full_path);
	} else {
		strcpy(full_path, StepFile.c_str());
	}

	if (ConfigBuffers.find(full_path) == ConfigBuffers.end()) {
		// Have not read the file yet...read and cache
		if (CacheRCFile(full_path) == "") {
			MessageBox(NULL, "File not found", full_path, MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			return NULL;
		}
	}

	CacheState *state = new CacheState;

	state->filename = full_path;
	state->command_iter_valid = false;
	state->config_iter_valid = false;
	state->line_iter_valid = false;

	return (FILE*)state;
}


BOOL StepSettings::LCClose (FILE *f)
{
	if (f) {
		CacheState *state = (CacheState*)f;

		delete state;
	}

	return TRUE;
}


BOOL StepSettings::LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	return LCReadNextLine(f, szBuffer, dwLength);
}


BOOL StepSettings::LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
	if (!f) {
		return FALSE;
	}

	CacheState *state = (CacheState*)f;

	if (state->line_iter_valid) {
		// !!! We should not have line iter populated, error out !!!
		return FALSE;
	}

	// lowcasify
	char low_prefix[MAX_LINE_LENGTH];
	strcpy(low_prefix, szPrefix);
	strlwr(low_prefix);

	// first time through, get command iter
	if (!state->command_iter_valid) {
		state->command_iter = ConfigBuffers[state->filename].find(low_prefix);

		if (state->command_iter == ConfigBuffers[state->filename].end()) {
			// Command not found, clear and return
			state->command_iter_valid = false;
			state->config_iter_valid = false;

			return FALSE;
		}

		// command found, get config iter
		state->config_iter = state->command_iter->second.begin();
		state->command_iter_valid = true;
		state->config_iter_valid = true;
	}

	if (state->config_iter == state->command_iter->second.end()) {
		// end of this command, clear and return
		state->command_iter_valid = false;
		state->config_iter_valid = false;

		return FALSE;
	}

	// At this point we should have an acceptable config line, build and return it
	char buffer[MAX_LINE_LENGTH];

	buffer[0] = 0; // blank
	strcat(buffer, state->command_iter->first.c_str()); // command name
	strcat(buffer, " "); // space
	strcat(buffer, state->config_iter->c_str()); // configuration line

  VarExpansion(szBuffer, buffer);
	//StrLCopy(szBuffer, buffer, dwLength); // copied

	// just increment the config iter, leave it to the next loop to determine if it's valid
	state->config_iter++;

	return TRUE;
}


BOOL StepSettings::LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	if (!f) {
		return FALSE;
	}

	CacheState *state = (CacheState*)f;

	if (state->config_iter_valid || state->command_iter_valid) {
		// !!! We should not have config or command iter populated, error out !!!
		return FALSE;
	}

	if (!state->line_iter_valid) {
		// first time through, get first line of rc
		state->line_iter = CommandBuffers[state->filename].begin();
	} 

	if (state->line_iter == CommandBuffers[state->filename].end()) {
		// end of rc file, clear and return
		state->line_iter_valid = false;

		return FALSE;
	}

	state->line_iter_valid = true;

	// At this point, we should have a usable line, send it out!
  VarExpansion(szBuffer, state->line_iter->c_str());
	//StrLCopy(szBuffer, state->line_iter->c_str(), dwLength);

	// Increment the iter, leave validation for next loop
	state->line_iter++;

	return TRUE;
}

void StepSettings::SetStepFile(string step_file)
{
  StepFile = step_file;
}

void StepSettings::SetThemeFile(string theme_file)
{
  ThemeFile = theme_file;
  ThemeInUse = TRUE;
}

string StepSettings::GetStepFile()
{
  return StepFile;
}

string StepSettings::GetThemeFile()
{
  return ThemeFile;
}

void StepSettings::Clear()
{
  if (stepVariables.size()) {
	  stepVariables.clear();
  }

	// Clear the caches
  if (CommandBuffers.size())
  {
	  CommandBuffers.clear();
  }

  if (ConfigBuffers.size()) {
	  ConfigBuffers.clear();
  }
}

CacheMap &StepSettings::GetCommandBuffers() {
  return CommandBuffers;
}

CacheMapMap &StepSettings::GetConfigBuffers() {
  return ConfigBuffers;
}
