#include "safestr.h"


bool CharInStr(const char chr, const char* szString)
{
  if (!(chr && szString))
    return false;

  return strchr(szString, chr) != NULL;
}


const char* StrIPos(const char* s1, const char* s2)
{
  if (!(StrLen(s1) && StrLen(s2)))
    return NULL;
  
  const char* result;
  char* t1 = new char[StrLen(s1) + 1];
  char* t2 = new char[StrLen(s2) + 1];

  strlwr(StrCopy(t1, s1));
  strlwr(StrCopy(t2, s2));
  result = strstr(t1, t2);
  
  delete[] t1;
  delete[] t2;
  return result;
}


char* StrLCopy(char* szDest, const char* szSource, size_t dwMaxLen)
{
  size_t maxLen;

  if (!(szDest && szSource))
    return NULL;

  maxLen = StrLen(szSource) < dwMaxLen ? StrLen(szSource) : dwMaxLen;

  strncpy(szDest, szSource, maxLen);
  szDest[maxLen] = '\0';

  return szDest;
}

