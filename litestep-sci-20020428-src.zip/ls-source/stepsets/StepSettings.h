/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
// StepSettings.h: interface for the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#if !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
#define AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <string>
#include <map>
#include "../core/ifcs.h"
#include "stepsets.h"

using namespace std;

class Parser;

// DO NOT CHANGE THESE!
#define MAX_BANGCOMMAND            64
#define MAX_BANGARGS               256
#define MAX_RCCOMMAND              64
#define MAX_LINE_LENGTH            4096
#define MAX_PATH_LENGTH		   1024
#define MAX_LINE_LENGTH 4096
#define WHITESPACE L" \t\n\r"

typedef vector<wstring> StringVector;

typedef map< wstring, StringVector > CacheMap;
typedef map< wstring, CacheMap > CacheMapMap;

typedef pair< wstring, StringVector > StringAndStringVector;
typedef map< wstring, StringAndStringVector > StringAndStringVectorMap;

// forward declare
class StepSettings;

class StepIterator: public IStepIterator
{
	// filename we are using, for command iteration
	wstring filename;

	// whether we have a valid line iterator
	bool line_iter_valid;

	// whether we have valid command and line iters
	bool command_iter_valid;

	StringAndStringVectorMap::iterator line_map_iter;
	StringVector::iterator line_iter;
	CacheMap::iterator command_iter;

	StepSettings *ss;
	long refCount;

public:
	StepIterator(BSTR szPath, StepSettings *stepsets);

	~StepIterator();

	///////////////////////////////////////////////////////////////////////
	// From IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(
	    /* [in] */ REFIID riid,
	    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);

	virtual ULONG STDMETHODCALLTYPE AddRef( void);

	virtual ULONG STDMETHODCALLTYPE Release( void);

	//////////////////////
	// From IStepIterator
	virtual BSTR STDMETHODCALLTYPE NextConfig(
	    /* [in] */ const BSTR szPrefix);

	virtual BSTR STDMETHODCALLTYPE NextLine( void);
};

class StepSettings: public IStepSettings
{
	friend class StepIterator;

	BOOL ThemeInUse;
	//string ThemeFile;
	//string StepFile;

	// One file/line-list combo per name.
	// Meant for settings that are overridden by ones loaded later.
	StringAndStringVectorMap NameToFileAndLines;
	// One name2line per file. One list of lines per name.
	// Meant for settings that are loaded on a per-file basis.
	CacheMapMap FileToNameToLines;

	typedef map<wstring, wstring> VarMap;

	// pre-defined variables provided by litestep
	VarMap stepVariables;

	// default file for LCOpen, set to the first file cached
	wstring defaultFile;

protected:
	FILE* Open(LPCWSTR szPath);
	BOOL Close (FILE *f);
	BOOL ReadNextLine (FILE *f, LPWSTR szBuffer, DWORD dwLength);
	LPWSTR CleanString(LPWSTR szString);
	LPWSTR StripComment(LPWSTR szString);
	BSTR FindLine(LPCWSTR szKeyName);
	void AddFileLine(LPCWSTR filename, LPCWSTR name, LPCWSTR value);
	bool AddLine(LPCWSTR filename, LPCWSTR name, LPCWSTR value);
	//bool GetLine(LPCWSTR name, wstring& value);

	bool ReadLine(FILE *, LPWSTR, LPWSTR);
	bool ProcessLine(FILE *, LPCWSTR, LPCWSTR, LPCWSTR);
	bool ProcessIf(FILE *, LPCWSTR, LPCWSTR);
	bool SkipIf(FILE *);

	wstring ProcessInclude(LPCWSTR szPath, LPCWSTR szRCPath);

	bool AddVariable(LPCWSTR name, LPCWSTR value);
	void RemoveVariable(LPCWSTR name);
	bool GetVariable(LPCWSTR name, wstring& value);
	bool VariableExists(LPCWSTR name);
	BOOL GetToken(LPCWSTR szString, LPWSTR szToken, LPCWSTR* szNextToken, BOOL useBrackets);

	double Eval(const BSTR sInput);
	double MathEvaluate(const BSTR sInput);

	CacheMapMap &GetFileToNameToLines();
	StringAndStringVectorMap &GetNameToFileAndLines();
	wstring CacheRCFile(LPCWSTR szPath);
public:

	BOOL RCLineExists(LPCWSTR szKeyName);
	void ClearAll();
	//string GetThemeFile();
	//string GetStepFile();
	//void SetThemeFile(string theme_file);
	//void SetStepFile(string step_file);
	StepSettings();
	virtual ~StepSettings();

	///////////////////////////////////////////////////////////////////////
	// From IUnknown
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(
	    /* [in] */ REFIID riid,
	    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);

	virtual ULONG STDMETHODCALLTYPE AddRef( void);

	virtual ULONG STDMETHODCALLTYPE Release( void);

	//////////////////////////////////////////////////////////////////////////
	// From IStepSettings
	virtual BSTR STDMETHODCALLTYPE VarExpansion(
	    /* [in] */ const BSTR value);

	virtual void STDMETHODCALLTYPE Clear( void);

	virtual void STDMETHODCALLTYPE SetVariable(
	    /* [in] */ const BSTR name,
	    /* [in] */ const BSTR value);

	virtual void STDMETHODCALLTYPE ClearVariable(
	    /* [in] */ const BSTR name);

	virtual BSTR STDMETHODCALLTYPE ParseFile(
	    /* [in] */ const BSTR stepfile);

	virtual int STDMETHODCALLTYPE GetInt(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ int nDefault);

	virtual BOOL STDMETHODCALLTYPE GetBool(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ BOOL ifFound);

	virtual BOOL STDMETHODCALLTYPE GetBoolDef(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ BOOL bDefault);

	virtual BSTR STDMETHODCALLTYPE GetString(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ const BSTR defStr);

	virtual COLORREF STDMETHODCALLTYPE GetColor(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ COLORREF colDef);

	virtual BSTR STDMETHODCALLTYPE GetLine(
	    /* [in] */ const BSTR szKeyName,
	    /* [in] */ const BSTR szDefault);

	virtual BOOL STDMETHODCALLTYPE Token(
	    /* [in] */ const BSTR szString,
	    /* [out] */ BSTR __RPC_FAR *szToken,
	    /* [out] */ int __RPC_FAR *iNextToken,
	    /* [in] */ BOOL useBrackets);

	virtual int STDMETHODCALLTYPE Tokenize(
	    /* [in] */ const BSTR szString,
	    /* [in] */ int count,
	    /* [size_is][out] */ BSTR __RPC_FAR tokens[  ],
	    /* [out] */ BSTR __RPC_FAR *remainder,
	    /* [in] */ BOOL useBrackets);

	virtual IStepIterator __RPC_FAR *STDMETHODCALLTYPE GetIterator(
	    /* [in] */ const BSTR szPath);

private:
	Parser* parser;
	long refCount;
};

#endif // !defined(AFX_STEPSETTINGS_H__4DAA8A20_64B4_11D4_AF40_0050DABB661D__INCLUDED_)
