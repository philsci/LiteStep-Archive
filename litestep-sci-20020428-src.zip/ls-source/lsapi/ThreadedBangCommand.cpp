/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include <windows.h>
#include <comdef.h>

#include "lsapi.h"

#include "ThreadedBangCommand.h"

///////// Bang Command ////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ThreadedBangCommand::ThreadedBangCommand(DWORD thread, BANG b)
{
	callback_bang = new CallbackBangCommand(b);
	callback_bang->AddRef();
	thread_id = thread;

	refCount = 0;
}

ThreadedBangCommand::ThreadedBangCommand(DWORD thread, BANGEX b, wchar_t *c)
{
	callback_bang = new CallbackBangCommand(b, c);
	callback_bang->AddRef();
	thread_id = thread;

	refCount = 0;
}

ThreadedBangCommand::~ThreadedBangCommand()
{
	callback_bang->Release();
}

////////////////////////////////////////////////////////////////////////////
// From IUnknown
HRESULT STDMETHODCALLTYPE ThreadedBangCommand::QueryInterface(
    /* [in] */ REFIID riid,
    /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppv)
{

	if (riid == IID_IUnknown)
	{
		*ppv = static_cast<IUnknown*>(this);
	}
	else if (riid == IID_IBangCommand)
	{
		*ppv = static_cast<IBangCommand*>(this);
	}
	else
	{
		*ppv = 0;
		return E_NOINTERFACE;
	}

	reinterpret_cast<IUnknown*>(*ppv)->AddRef();
	return S_OK;
}

ULONG STDMETHODCALLTYPE ThreadedBangCommand::AddRef( void)
{
	return InterlockedIncrement(&refCount);
}

ULONG STDMETHODCALLTYPE ThreadedBangCommand::Release( void)
{
	LONG count = InterlockedDecrement(&refCount);

	if (count == 0)
	{
		delete this;
	}

	return count;
}

///////////////////////////////////////////////////////////////////////////
// From IBangCommand
void STDMETHODCALLTYPE ThreadedBangCommand::Execute(
    /* [in] */ OLE_HANDLE caller,
    /* [in] */ BSTR params)
{

	DWORD current_id = GetCurrentThreadId();

	if (current_id != this->thread_id)
	{
		BangCommandInfo *info = new BangCommandInfo;

		info->bang = callback_bang;
		info->bang->AddRef();
		info->caller = caller;

		info->params = SysAllocString(params);

		// target thread deletes array and info
		PostThreadMessage(this->thread_id, LM_THREAD_BANGCOMMAND, (WPARAM)info, NULL);
	}
	else
	{
		callback_bang->Execute(caller, params);
	}
}
