/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/ 
/*
  Copyright (C) 1998-1999 Johan Redestig
 
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
 
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
 
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
****************************************************************************/
#include "stdafx.h"
#include "re5ources.h"
#include "ShellFolder.h"
#include "Painter.h"

#define SFM_ASYNC_START (WM_USER + 56)
#define SFM_ASYNC_END (WM_USER + 57)
#define SFM_ASYNC_ADD (WM_USER + 58)

ShellFolder::ShellFolder(PopupMaker *pPopupMaker, IShellFolder *pshf, LPITEMIDLIST pidlFull, LPITEMIDLIST pidl, LPSTR pszTitle, int iIcon, HIMAGELIST hImageList) :
		FolderItem(NULL, pszTitle)
{
	m_pPopupMaker = pPopupMaker;
	m_pshf = pshf;
	m_pidlFull = pidlFull;
	m_pidl = pidl;
	m_hThread = INVALID_HANDLE_VALUE;
	m_pLoadingFolder = NULL;
	m_bFolderLoaded = FALSE;

	if (m_pshf)
		m_pshf->AddRef();

	SetIcon(hImageList, iIcon);
}

ShellFolder::ShellFolder(PopupMaker *pPopupMaker, LPSTR pszTitle, int csidl)
		: FolderItem( NULL, NULL )
{
	m_pPopupMaker = pPopupMaker;
	m_pshf = NULL;
	m_pidlFull = NULL;
	m_pidl = NULL;
	m_hThread = INVALID_HANDLE_VALUE;
	m_pLoadingFolder = NULL;
	m_bFolderLoaded = FALSE;

	SHGetSpecialFolderLocation(NULL, csidl, &m_pidlFull);

	if (m_pidlFull)
	{
		SHFILEINFO shfi;
		HIMAGELIST hImageList;

		hImageList = (HIMAGELIST) SHGetFileInfo((LPSTR) m_pidlFull, 0,
		                                        &shfi, sizeof(SHFILEINFO), SHGFI_ATTRIBUTES | SHGFI_DISPLAYNAME |
		                                        SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SMALLICON);

		SetIcon(hImageList, shfi.iIcon);

		TrimLeft(shfi.szDisplayName);
		m_pszTitle = strdup(pszTitle ? pszTitle : shfi.szDisplayName);

		if (shfi.dwAttributes & SFGAO_FOLDER && !(shfi.dwAttributes & SFGAO_REMOVABLE))
		{
			IShellFolder *pshfDesktop;
			SHGetDesktopFolder(&pshfDesktop);

			pshfDesktop->BindToObject(m_pidlFull, NULL, IID_IShellFolder,
			                          (void **) &m_pshf);

			pshfDesktop->Release();
		}
	}

}

ShellFolder::~ShellFolder()
{
	if (m_pshf)
	{
		m_pshf->Release();
		m_pshf = NULL;
	}

	if (m_pidlFull)
	{
		FreeIDList(m_pidlFull);
		m_pidlFull = NULL;
	}

	if (m_pidl)
	{
		FreeIDList(m_pidl);
		m_pidl = NULL;
	}

	if (m_hThread != INVALID_HANDLE_VALUE)
	{
		TerminateThread(m_hThread, 0);
		CloseHandle(m_hThread);
		m_hThread = INVALID_HANDLE_VALUE;
	}

	if (m_pLoadingFolder)
	{
		delete m_pLoadingFolder;
		m_pLoadingFolder = NULL;
	}
}

void ShellFolder::SetSubMenu(PopupMenu *pSubMenu)
{
	BOOL bSubMenuVisible = FALSE;

	if (m_pSubMenu)
	{
		bSubMenuVisible = IsWindowVisible(m_pSubMenu->GetWindow());
		m_pSubMenu->Hide(HIDE_CHILDREN);

		m_pParent->RemoveChild(m_pSubMenu);

		delete m_pSubMenu;
		m_pSubMenu = NULL;
	}

	m_pSubMenu = pSubMenu;
	m_pParent->AddChild(m_pSubMenu);
	m_pSubMenu->SetParent(m_pParent);

	if (bSubMenuVisible)
		ShowSubMenu();
}

BOOL ShellFolder::Active(BOOL bActivate)
{
	if (IsLeaf())
	{
		return TitleItem::Active(bActivate);
	}
	else
	{
		BOOL bRet = FolderItem::Active(bActivate);

		if (bActivate && !m_bFolderLoaded && m_hThread == INVALID_HANDLE_VALUE)
		{
			DWORD dwThreadID;

			m_hThread = CreateThread(NULL, 0, ThreadProc,
			                         (void *) this, 0, &dwThreadID);
		}

		return bRet;
	}
}

void ShellFolder::Attached(PopupMenu *pParent)
{
	m_pParent = pParent;

	if (!IsLeaf())
	{
		PopupMenu *ppm = new PopupMenu(m_pPopupMaker->hInst);
		m_pPopupMaker->AddHeaderItem(ppm, GetTitle(), FALSE);

		MenuItem *pmi = new TitleItem(RESSTR(IDS_POPUP_LOADING));
		pmi->SetActivePainter(NULL);
		pmi->SetPainter(m_pPopupMaker->m_pEntry);
		pmi->SetHeight(m_pPopupMaker->m_nSubmenuHeight);
		ppm->AddMenuItem(pmi);

		m_pPopupMaker->AddBottomItem(ppm);
		ppm->Validate();

		SetSubMenu(ppm);
	}
}

void ShellFolder::GetTitleRect(RECT *prc)
{
	if (IsLeaf())
		TitleItem::GetTitleRect(prc);
	else
		FolderItem::GetTitleRect(prc);
}

void ShellFolder::Invoke()
{
	if (IsLeaf())
	{
		SHELLEXECUTEINFO sei;

		m_pParent->Hide(HIDE_PARENTS);

		sei.cbSize = sizeof(SHELLEXECUTEINFO);
		sei.fMask = SEE_MASK_INVOKEIDLIST | SEE_MASK_IDLIST | SEE_MASK_FLAG_NO_UI;
		sei.hwnd = NULL;
		sei.lpVerb = NULL;
		sei.lpFile = NULL;
		sei.lpParameters = NULL;
		sei.lpDirectory = NULL;
		sei.nShow = SW_SHOW;
		sei.lpIDList = m_pidlFull;

		ShellExecuteEx(&sei);
	}
	else
	{
		FolderItem::Invoke();
	}
}

void ShellFolder::RInvoke()
{
	LPMALLOC pMalloc;
	LPSHELLFOLDER psfFolder, psfNextFolder;
	LPITEMIDLIST pidlItem, pidlNextItem, *ppidl;
	LPCONTEXTMENU pContextMenu;
	CMINVOKECOMMANDINFO ici;
	UINT nCount, nCmd;
	HMENU hMenu;

	// Get current cursor position & window
	POINT point;
	HWND hwnd;

	GetCursorPos(&point);
	hwnd = WindowFromPoint(point);

	//
	// Get pointers to the shell's IMalloc interface and the desktop's
	// IShellFolder interface.
	//

	if (SUCCEEDED (SHGetMalloc (&pMalloc)))
	{

		if (!SUCCEEDED (SHGetDesktopFolder (&psfFolder)))
		{
			pMalloc->Release();
		}
		else
		{
			//
			// Convert the path name into a pointer to an item ID list (pidl).
			//
			if (m_pidlFull != NULL)
			{

				if (nCount = GetItemCount (m_pidlFull))
				{ // nCount must be > 0
					//
					// Initialize psfFolder with a pointer to the IShellFolder
					// interface of the folder that contains the item whose context
					// menu we're after, and initialize pidlItem with a pointer to
					// the item's item ID. If nCount > 1, this requires us to walk
					// the list of item IDs stored in m_pidlFull and bind to each
					// subfolder referenced in the list.
					//
					pidlItem = m_pidlFull;

					while (--nCount)
					{
						//
						// Create a 1-item item ID list for the next item in m_pidlFull.
						//

						pidlNextItem = DuplicateItem (pMalloc, pidlItem);

						if (pidlNextItem == NULL)
						{
							//pMalloc->Free (m_pidlFull);
							psfFolder->Release();
							pMalloc->Release();
							return ;
						}

						//
						// Bind to the folder specified in the new item ID list.
						//
						if (!SUCCEEDED (psfFolder->BindToObject (pidlNextItem, NULL, IID_IShellFolder, (void**)&psfNextFolder)))
						{
							pMalloc->Free(pidlNextItem);
							//pMalloc->Free (m_pidlFull);
							psfFolder->Release();
							pMalloc->Release();
							return ;
						}

						//
						// Release the IShellFolder pointer to the parent folder
						// and set psfFolder equal to the IShellFolder pointer for
						// the current folder.
						//
						psfFolder->Release();
						psfFolder = psfNextFolder;

						//
						// Release the storage for the 1-item item ID list we created
						// just a moment ago and initialize pidlItem so that it points
						// to the next item in m_pidlFull.
						//
						pMalloc->Free(pidlNextItem);
						pidlItem = GetNextItem (pidlItem);
					}

					//
					// Get a pointer to the item's IContextMenu interface and call
					// IContextMenu::QueryContextMenu to initialize a context menu.
					//
					ppidl = &pidlItem;
					if (SUCCEEDED (psfFolder->GetUIObjectOf (hwnd, 1, (const ITEMIDLIST**)ppidl, (const GUID)IID_IContextMenu, NULL, (void**)&pContextMenu)))
					{

						hMenu = CreatePopupMenu ();
						if (SUCCEEDED (pContextMenu->QueryContextMenu (
						                   hMenu, 0, 1, 0x7FFF, CMF_NORMAL)))
						{

							//
							// Display the context menu.
							//
							nCmd = TrackPopupMenu (hMenu, TPM_LEFTALIGN |
							                       TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_RETURNCMD,
							                       point.x, point.y, 0, hwnd, NULL);

							//
							// If a command was selected from the menu, execute it.
							//
							if (nCmd)
							{
								ici.cbSize = sizeof (CMINVOKECOMMANDINFO);
								ici.fMask = SEE_MASK_FLAG_NO_UI;
								ici.hwnd = hwnd;
								ici.lpVerb = MAKEINTRESOURCE (nCmd - 1);
								ici.lpParameters = NULL;
								ici.lpDirectory = NULL;
								ici.nShow = SW_SHOWNORMAL;
								ici.dwHotKey = 0;
								ici.hIcon = NULL;

								pContextMenu->InvokeCommand(&ici);


							}
							DestroyMenu (hMenu);
							pContextMenu->Release();
						}
					}
					//pMalloc->Free (m_pidlFull);
				}
			}
			//
			// Clean up and return.
			//

			psfFolder->Release();
			pMalloc->Release();
		}
	}

}

BOOL ShellFolder::IsLeaf()
{
	return m_pshf ? FALSE : TRUE;
}

void ShellFolder::Paint(HDC hDC)
{
	FolderItem::Paint(hDC);

	/*
	MenuItem::Paint(hDC);

	RECT r;
	GetTitleRect(&r);

	// DrawText(hDC, GetTitle(), lstrlen( GetTitle() ), &r,
	//	GetDrawTextFormat());

	Painter *pPainter = m_pBackground;

	if(m_bActive && m_pActiveBackground)
		pPainter = m_pActiveBackground;

	if(pPainter)
		pPainter->PaintText(hDC, r, GetTitle(), GetDrawTextFormat());

	if(m_bDrawArrow && !IsLeaf())
		PaintArrow(hDC, m_nTop);

	if(m_bDrawBevel)
		PaintBevel(hDC, m_nTop);
	*/
}

BOOL ShellFolder::OnUser(int nMessage, WPARAM wParam, LPARAM lParam, LRESULT &lResult)
{
	if (nMessage >= SFM_ASYNC_START && nMessage <= SFM_ASYNC_ADD && wParam == (WPARAM) this)
	{
		switch (nMessage)
		{
			case SFM_ASYNC_START:
			{
				m_pLoadingFolder = new PopupMenu(m_pPopupMaker->hInst);
				m_pPopupMaker->AddHeaderItem(m_pLoadingFolder, GetTitle(), FALSE);
				return TRUE;
			}

			case SFM_ASYNC_END:
			{
				m_pPopupMaker->AddBottomItem(m_pLoadingFolder);
				m_pLoadingFolder->Invalidate();
				m_pLoadingFolder->Validate();

				SetSubMenu(m_pLoadingFolder);
				m_pLoadingFolder = NULL;
				return TRUE;
			}

			case SFM_ASYNC_ADD:
			{
				m_pLoadingFolder->AddMenuItem((MenuItem *) lParam, SortFunction, m_pshf);
				return TRUE;
			}
		}
	}

	return FolderItem::OnUser(nMessage, wParam, lParam, lResult);
}

void ShellFolder::UpdateFolder()
{
	IEnumIDList *peidl;
	HRESULT hr;
	BOOL bEmpty = TRUE;

	hr = m_pshf->EnumObjects(NULL, SHCONTF_FOLDERS |
	                         SHCONTF_NONFOLDERS, &peidl);

	PostMessage(GetWindow(), SFM_ASYNC_START, (WPARAM) this, 0);

	if (SUCCEEDED(hr))
	{
		LPITEMIDLIST pidl;

		while (peidl->Next(1, &pidl, NULL) == S_OK)
		{
			LPITEMIDLIST pidlFull = JoinIDLists(m_pidlFull, pidl);
			SHFILEINFO shfi;

			SHGetFileInfo((LPCSTR) pidlFull, 0, &shfi, sizeof(SHFILEINFO),
			              SHGFI_ATTRIBUTES | SHGFI_DISPLAYNAME | SHGFI_SMALLICON |
			              SHGFI_PIDL | SHGFI_SYSICONINDEX);

			TrimLeft(shfi.szDisplayName);

			MenuItem *pmi = NULL;

			if (shfi.dwAttributes & SFGAO_FOLDER)
			{
				IShellFolder *pshfFolder = NULL;

				if (!(shfi.dwAttributes & SFGAO_REMOVABLE))
				{
					m_pshf->BindToObject(pidl, NULL, IID_IShellFolder,
					                     (void **) &pshfFolder);
				}

				pmi = new ShellFolder(m_pPopupMaker,
				                      pshfFolder,
				                      pidlFull,
				                      pidl,
				                      shfi.szDisplayName,
				                      shfi.iIcon,
				                      m_hImageList);

				if (pshfFolder)
					pshfFolder->Release();
			}
			else
			{
				pmi = new ShellFolder(m_pPopupMaker,
				                      NULL,
				                      pidlFull,
				                      pidl,
				                      shfi.szDisplayName,
				                      shfi.iIcon,
				                      m_hImageList);
			}

			if (pmi != NULL)
			{
				pmi->SetActivePainter(pmi->IsLeaf() ? m_pPopupMaker->m_pSelEntry : m_pPopupMaker->m_pSelFolder);
				pmi->SetPainter(pmi->IsLeaf() ? m_pPopupMaker->m_pEntry : m_pPopupMaker->m_pFolder);
				pmi->SetHeight(m_pPopupMaker->m_nSubmenuHeight);

				PostMessage(GetWindow(), SFM_ASYNC_ADD, (WPARAM) this, (LPARAM) pmi);
				bEmpty = FALSE;
			}
		}

		peidl->Release();
	}

	if (bEmpty)
	{
		MenuItem *pmi = new TitleItem(RESSTR(IDS_POPUP_EMPTY));

		pmi->SetActivePainter(NULL);
		pmi->SetPainter(m_pPopupMaker->m_pEntry);
		pmi->SetHeight(m_pPopupMaker->m_nSubmenuHeight);

		PostMessage(GetWindow(), SFM_ASYNC_ADD, (WPARAM) this, (LPARAM) pmi);
	}

	PostMessage(GetWindow(), SFM_ASYNC_END, (WPARAM) this, 0);
}

// returns true if m1 < m2
bool ShellFolder::SortFunction(void *pvSortParam, MenuItem *m1, MenuItem *m2)
{
	if (m1->GetSortPriority() < m2->GetSortPriority())
		return true;
	else if (m1->GetSortPriority() > m2->GetSortPriority())
		return false;

	IShellFolder *pshf = (IShellFolder *) pvSortParam;

	ShellFolder *sf1 = (ShellFolder *) m1;
	ShellFolder *sf2 = (ShellFolder *) m2;

	return (short) HRESULT_CODE(pshf->CompareIDs(0, sf1->m_pidl, sf2->m_pidl)) > 0;
}

DWORD WINAPI ShellFolder::ThreadProc( void *pvParameter )
{
	ShellFolder *pThis = (ShellFolder *) pvParameter;

	Sleep(100);

	if (pThis)
	{
		pThis->UpdateFolder();
		pThis->m_bFolderLoaded = TRUE;

		CloseHandle(pThis->m_hThread);
		pThis->m_hThread = INVALID_HANDLE_VALUE;
	}

	return 0;
}

LPITEMIDLIST CreateIDList(int cb)
{
	IMalloc *pMalloc;
	LPITEMIDLIST pidl = NULL;

	if (cb <= 0)
		return NULL;

	if (SUCCEEDED(SHGetMalloc(&pMalloc)))
	{
		pidl = (LPITEMIDLIST) pMalloc->Alloc(cb);
		pMalloc->Release();
	}

	if (pidl)
		memset(pidl, 0, cb);

	return pidl;
}

LPITEMIDLIST DuplicateIDList(LPCITEMIDLIST pidl)
{
	LPITEMIDLIST pidlNew;
	int cb = GetIDListSize(pidl);

	if (!pidl)
		return NULL;

	pidlNew = CreateIDList(cb);

	if (pidlNew)
		memcpy(pidlNew, pidl, cb);

	return pidlNew;
}

/* LPITEMIDLIST DuplicateLastID(LPCITEMIDLIST pidl)
{
	LPCITEMIDLIST pidlPrevious;
 
	if(!pidl || !pidl->mkid.cb)
		return NULL;
 
	do
	{
		pidlPrevious = pidl;
		pidl = NextID(pidl);
	}
	while(pidl->mkid.cb);
 
	return DuplicateIDList(pidlPrevious);
} */

LPITEMIDLIST JoinIDLists(LPCITEMIDLIST pidlA, LPCITEMIDLIST pidlB)
{
	LPITEMIDLIST pidl;
	int cbA, cbB;

	cbA = pidlA ? GetIDListSize(pidlA) - sizeof(pidlA->mkid.cb) : 0;
	cbB = GetIDListSize(pidlB);

	pidl = CreateIDList(cbA + cbB);

	if (pidl)
	{
		if (pidlA)
			memcpy(pidl, pidlA, cbA);

		memcpy((LPBYTE) pidl + cbA, pidlB, cbB);
	}

	return pidl;
}

int GetIDListSize(LPCITEMIDLIST pidl)
{
	if (!pidl)
		return 0;

	int cb = sizeof(pidl->mkid.cb);

	while (pidl->mkid.cb)
	{
		cb = cb + pidl->mkid.cb;
		pidl = NextID(pidl);
	}

	return cb;
}

LPCITEMIDLIST NextID(LPCITEMIDLIST pidl)
{
	return (LPCITEMIDLIST) ((CONST BYTE *) pidl + pidl->mkid.cb);
}

void FreeIDList(LPITEMIDLIST pidl)
{
	IMalloc *pMalloc;

	if (SUCCEEDED(SHGetMalloc(&pMalloc)))
	{
		pMalloc->Free(pidl);
		pMalloc->Release();
	}
}

HANDLE SHChangeNotifyRegister(HWND hWnd, DWORD dwFlags, DWORD dwEventMask, UINT nMessage, UINT cItems, NOTIFYREGISTER *pItems)
{
	HANDLE (WINAPI *pfnSHChangeNotifyRegister)(HWND, DWORD, DWORD, UINT, UINT, NOTIFYREGISTER *) = (HANDLE (WINAPI *)(HWND, DWORD, DWORD, UINT, UINT, NOTIFYREGISTER *)) GetProcAddress(
	            GetModuleHandle("SHELL32.DLL"), (LPCSTR) 2);

	return pfnSHChangeNotifyRegister(hWnd, dwFlags, dwEventMask, nMessage, cItems, pItems);
}

BOOL SHChangeNotifyDeregister(HANDLE hNotify)
{
	BOOL (WINAPI *pfnSHChangeNotifyDeregister)(HANDLE) = (BOOL (WINAPI *)(HANDLE)) GetProcAddress(
	            GetModuleHandle("SHELL32.DLL"), (LPCSTR) 4);

	return pfnSHChangeNotifyDeregister(hNotify);
}
