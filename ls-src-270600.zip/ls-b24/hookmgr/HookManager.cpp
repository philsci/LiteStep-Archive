/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2000 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/****************************************************************************
06/03/00 - Bobby G. Vinyard (Message)
  - Swapped lParam and wParam for LM_REGISTERMESSAGE and LM_UNREGISTERMESSAGE
06/03/00 - Bobby G. Vinyard (Message)
  - Yet another rewrite
    - No longer uses lswinbase
    - HookMgr uses a sepereate thread now
    - Added HookCallback for modules to use when using HookMgr
    - Probably should be using WM_CALLWNDPROC or WM_CALLWNDPROCRET but these
     lock my system up everytime i try set one... =\ ( so the implementation
     is commented out for now)
05/18/00 - Bobby G. Vinyard (Message)
  - Rewrote hookmgr to handle only WM messages and to d2 format 
****************************************************************************/
#include "HookManager.h"

//=========================================================
// Initialization and cleanup
//=========================================================
int initModuleEx(HWND ParentWnd, HINSTANCE dllInst, LPCSTR szPath)
{
  hInst = dllInst;
  hShellHook = NULL;
  hMsgHook = NULL;
  hHookMgrThread = NULL;
  hwndHookMgr = NULL;
  hmodHook = LoadLibrary("hook");
  if (hmodHook) {
    processHooks = true;
    if(!createHookThread()) {
      MessageBox(NULL, "Could not create Hook Manager Thread", HOOKMGRWINDOWNAME, MB_OK);
      processHooks = false;
    }
  }
  else {
    MessageBox(NULL, "Could not load hook.dll", HOOKMGRWINDOWNAME, MB_OK);
    processHooks = false;
  }
  return 0;
}


void quitModule(HINSTANCE dllInst)
{
  SendMessage(hwndHookMgr, WM_CLOSE, 0, 0);
  WaitForSingleObject(hHookMgrThread, INFINITE);
  processHooks = false;
  UnregisterClass(HOOKMGRWINDOWCLASS, dllInst);
  FreeLibrary(hmodHook);
}


bool createHookThread() {
  WNDCLASS wc;
  DWORD Id;
  
  //
  // Register a class for the hook stuff to forward its messages to.
  //
  wc.hCursor        = NULL;    // this window never shown, so no
  wc.hIcon          = NULL;    // cursor or icon are necessary
  wc.lpszMenuName   = NULL;
  wc.lpszClassName  = HOOKMGRWINDOWCLASS;
  wc.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
  wc.hInstance      = hInst;
  wc.style          = 0;
  wc.lpfnWndProc    = HookMgrWndProc;
  wc.cbWndExtra     = sizeof(HWND) + sizeof(HWND);
  wc.cbClsExtra     = 0;
  
  if (!RegisterClass(&wc)) {
    return FALSE;
  }
  //
  // Now create another thread to handle the new queue
  //
  if (!(hHookMgrThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)HookMgrMain,
    0L, STANDARD_RIGHTS_REQUIRED, &Id))) {
    return FALSE;
  }
  return TRUE;
  
}


DWORD HookMgrMain(LPVOID lpv) {
  MSG msg;
  
  hwndHookMgr = CreateWindow(HOOKMGRWINDOWCLASS, HOOKMGRWINDOWNAME,
    WS_OVERLAPPEDWINDOW,
    0, 0, 0, 0,
    NULL, NULL,
    hInst, NULL);
  
  if (!hwndHookMgr) {
    MessageBox(NULL, "Unable to create window.", HOOKMGRWINDOWNAME, MB_TOPMOST);
    ExitThread(0);
  }
  
  while (IsWindow(hwndHookMgr) && GetMessage(&msg, hwndHookMgr, 0, 0)) {
    if (processHooks) {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }
  
  hwndHookMgr = NULL;

  return 0;
  
}


bool InstallMsgFilter(bool install) {
/*
  if (install && !hMsgHook && !hCallWndHook) {

    setCallWndHook(SetWindowsHookEx(WH_CALLWNDPROC,
      (HOOKPROC)GetProcAddress(hmodHook, "LSCallWndProc"), hmodHook, 0));
    hCallWndHook = getCallWndHook();

    setMsgHook(SetWindowsHookEx(WH_GETMESSAGE,
      (HOOKPROC)GetProcAddress(hmodHook, "GetMsgProc"), hmodHook, 0));
    hMsgHook = getMsgHook();

    if (hMsgHook && hCallWndHook) {
      return true;
    }
  }
  else if (!install && hMsgHook && hCallWndHook) {
    setMsgHook(NULL);
    UnhookWindowsHookEx(hMsgHook);
    hMsgHook = NULL;

    setCallWndHook(NULL);
    UnhookWindowsHookEx(hCallWndHook);
    hCallWndHook = NULL;
  }
*/
  if (install && !hMsgHook) {
    setMsgHook(SetWindowsHookEx(WH_GETMESSAGE,
      (HOOKPROC)GetProcAddress(hmodHook, "GetMsgProc"), hmodHook, 0));
    hMsgHook = getMsgHook();

    if (hMsgHook) {
      return true;
    }
  }
  else if (!install && hMsgHook) {
    setMsgHook(NULL);
    UnhookWindowsHookEx(hMsgHook);
    hMsgHook = NULL;
  }
  return false;
}

LRESULT CALLBACK HookMgrWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
  sMsgHookList *psHwnds;
  sMsgHookList::reverse_iterator lrit;
  msg2hwnd::iterator m2hit;
  switch (msg) {
  case WM_COPYDATA:
    {
      if (numMessages == 0) break;
      if (((PCOPYDATASTRUCT)lParam)->cbData != sizeof(MSG)) break;
      msgd.message = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->message;
      msgd.hwnd = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->hwnd;
      msgd.wParam = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->wParam;
      msgd.lParam = ((PMSG)((PCOPYDATASTRUCT)lParam)->lpData)->lParam;
      m2hit = m2hmap.find(msgd.message);
      if (m2hit != m2hmap.end()) {
        _LSDEBUG2("WM_COPYDATA message found", (int)msgd.message)
        psHwnds = (*m2hit).second;
        for(lrit=psHwnds->rbegin(); lrit != psHwnds->rend(); lrit++) {
          (*lrit)(msgd.hwnd, msgd.message, msgd.wParam, msgd.lParam);
        }
      }
    }
    return TRUE;
    
  case LM_REGISTERMESSAGE:
    {
      if (numMessages == 0) { 
        if (InstallMsgFilter(true)) {
          psHwnds = new sMsgHookList;
          psHwnds->insert((HookCallback*)lParam);
          m2hmap.insert(msg2hwnd::value_type((UINT)wParam,psHwnds));
          numMessages++;
        }
      }
      else {
        m2hit = m2hmap.find((UINT)wParam);
        if (m2hit == m2hmap.end()) {
          psHwnds = new sMsgHookList;
          psHwnds->insert((HookCallback*)lParam);
          m2hmap.insert(msg2hwnd::value_type((UINT)wParam,psHwnds));
        }
        else {
          psHwnds = (*m2hit).second;
          psHwnds->insert((HookCallback*)lParam);
        }
        numMessages++;
      }
    }
    return TRUE;
    
  case LM_UNREGISTERMESSAGE:
    {
      if (numMessages) {
        m2hit = m2hmap.find((UINT)wParam);
        if (m2hit != m2hmap.end()) {
          sMsgHookList::iterator lit;
          psHwnds = (*m2hit).second;
          lit = psHwnds->find((HookCallback*)lParam);
          if (lit != psHwnds->end()) {
            psHwnds->erase(lit);
            if (psHwnds->empty()) {
              delete (*m2hit).second;
              m2hmap.erase(m2hit);
            }
            numMessages--;
            if (!numMessages) {
              InstallMsgFilter(false);
            }
          }   
        }
      }
    }
    return TRUE;;
  case WM_CREATE:
    {
      setShellHook(SetWindowsHookEx(WH_SHELL, 
        (HOOKPROC)GetProcAddress(hmodHook, "ShellProc"), hmodHook, 0));
      hShellHook = getShellHook();
    }
    break;
    
  case WM_DESTROY:
    {
      if (hShellHook) {
        setShellHook(NULL);
        UnhookWindowsHookEx(hShellHook);
        hShellHook = NULL;
      }
      InstallMsgFilter(false);
      PostQuitMessage(0);
    }
    return 0;
      
  case WM_NCDESTROY:
    {
      processHooks = FALSE;
    }
    break;
  }
  return DefWindowProc(hwnd, msg, wParam, lParam);
}