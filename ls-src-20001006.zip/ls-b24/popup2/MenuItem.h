/*
  Copyright (C) 1998-1999 Johan Redestig
  
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#if !defined(AFX_MENUITEM_H__D5612514_732D_11D2_B69F_00C0DF466974__INCLUDED_)
#define AFX_MENUITEM_H__D5612514_732D_11D2_B69F_00C0DF466974__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define HICON_BLANK ((HICON) 1)

class PopupMenu;
class Painter;

/**
This is an 'abstract' base class of menu items
*/
class MenuItem
{
public:
	/**
	constructs a menu item object
	*/
	MenuItem();

	/**
	destroys the menu otem object
	*/
	virtual ~MenuItem();

	/**
	Paint the menu item att the dc.

	@param hDC handle to the dc to be painted
	*/
	virtual void Paint(HDC hDC);

	/**
	Execute the command that is associated with the menu item
	*/
	virtual void Invoke();

	/**
	handler of key press messages

	@param nKey the key that was pressed
	*/
	virtual BOOL Key(int nKey);

	/**
	Informs the menuitem that a mouse message have been sent

	@param nMsg the mouse message type WM_MOUSEMOVE, WM_LBUTTON, etc.
	@param x location of the mouse message
	@param y location of the mouse message
	*/
	virtual void Mouse(int nMsg, int x, int y);

	/**
	Timer callback, used by menuitems that implement anumation or
	various waiting. examples are the TimeItem, FolderItem

	@param nTimer the identity of the timer that caused the callback
	*/
	virtual void Timer(int nTimer);

  /**
  Returns whether the item is a leaf or a node
  */
  virtual inline BOOL IsLeaf(){return TRUE;};
  
  /**
	Returns the height of the menu item

	@return the height of the menu item
	*/
	virtual inline int GetHeight(){return m_nHeight;};

	/**
	Sets the (desired) height of the menu item

	@param nHeight the (desired) height of the menu item
	*/
	virtual inline void SetHeight(int nHeight){m_nHeight=nHeight;};

	/**
	Returns the width of the menu item

	@return the width of the menu item
	*/
	virtual inline int GetWidth(){return m_nWidth;};

	/**
	Sets the (desired) width of the menu item

	@param nWidth the (desired) width of the menu item
	*/
	virtual inline void SetWidth(int nWidth){m_nWidth = nWidth;};

	/**
	The menu asks the menu item if it is ok to hide the menu, default 
	implementatin returns TRUE

	@return if this menu item accepts to be hidden
	*/
	virtual BOOL Hide(){return TRUE;};

	/**
	Set the key that is the shortcut use macros like VK_ESCAPE, VK_K, ...

	@param nKey the keycode for the shortcut key
	*/
	virtual void SetShortcut(int nKey) {m_nShortcut = nKey;};

	/**
	This item has been connected to a popup menu this happens _once_ during 
	the lifetime of the object

	@param pMenu pointer to the popupmenu object that this menuitem is
	             connected to
	*/
	virtual void Attached(PopupMenu* pMenu);

	/**
	Sent to the menuitems when the mouse is moving. The menuitem may reply
	to this message to inofrm windows that it is CLIENT area or NONCLIENT

	@param x the location of the message
	@param y the location of the message
	@return the type of area that this menu item covers
	*/
	virtual LRESULT NcHitTest(int x, int y){return 0;};

	/**
	handled the WM_COMMAND messages

	@param wParam the wParam that was sent with the WM_COMMAND
	@param lParam the lParam that was sent with the WM_COMMAND
	*/
	virtual LRESULT Command(WPARAM wParam, LPARAM lParam);

	virtual void AsyncStart( LPARAM lParam ) { }
	virtual void AsyncEnd( LPARAM lParam ) { }
	virtual void AsyncAdd( LPARAM lParam ) { }

	/**
	Gets the bounding box of this item in popupmenu space.

	@param pRect pointer to a RECT that will receive the information
	*/
	virtual void GetItemRect(LPRECT pRect);

	/**
	Paints a bevel around this menu item

	@param hDC handle to the devicecontect to be painted
	@parma nTop the y location of the bevel
	*/
	virtual void PaintBevel(HDC hDC, int nTop);

	/**
	Sets the activation state of this menu item. The resulting activation 
	state is returned. If this method returns false then it is impossible
	to actuvate the meni item (TimeItem, Separatir, header,..)

	@param bActive the new activation state
	@return the resulting activation state, may be different than bActive
	*/
	virtual BOOL Active(BOOL bActive);

	/**
	Sets the painter object to be used to paint the background of this menuitem

	@param pBackground the new background painter object
	*/
	virtual void SetPainter(Painter* pBackground);

	/**
	Returns the painterobject that is currently used to paint the background

	@return the current paitner object
	*/
	virtual Painter* GetPainter(){return m_pBackground;};
		
	/**
	Sets the painter object to be used to paint the active background of this menuitem

	@param pBackground the new active background painter object
	*/
	virtual void SetActivePainter(Painter* pBackground);

	/**
	Notifies the menuitem that the menu is moving
	*/
	virtual void Moving(){;};

	/**
	returns the current activation state of this menu itme

	@return if this menu item is active or not
	*/
	virtual BOOL IsActive(){return m_bActive;};

	/**
	Sets the icon to be used to paint this menu item

	@param hIcon handle to the icon to be used, if hIcon is NULL then no icon
	             is painted
	*/
	virtual void SetIcon(HICON hIcon){m_hIcon = hIcon;};

	/**
	returns the y location of the menu item

	@reutn the y location of the menu item
	*/
	virtual int GetTop(){return m_nTop;};
	
	/**
	Returns handle to the window that is associated with this menu item.
	NULL if there is no such window

	@return the window handle to htis menuitme
	*/
	virtual HWND GetWindow();

	/**
	Initializes hRgn with the region that thie menu item plans to cover when
	it is painted on a window

	@param hRgn handle to the region to be initalized
	*/
	virtual void GetRegion(HRGN hRgn);

	/**
	this happes from time to time. it tells the object where it is located in 
	client coordinates.
	*/
	virtual void SetPosition(int nLeft, int nTop){m_nLeft=nLeft;m_nTop=nTop;};

	/**
	Sets the priority this menu item has when it is compared with other menuitems

	@param nSortPriority the sort priority
	*/
	virtual void SetSortPriority(int nSortPriority){m_nSortPriority = nSortPriority;};

	/**
	Returns the priority this menu item has when it is compared with other menuitems

	@return the sort priority
	*/
	virtual int  GetSortPriority(){return m_nSortPriority;};

	/**
	Returns the string that is used to compare this menu item with others. this string
	is typically the title text

	@return the sort string
	*/
	virtual char* GetSortString(){return NULL;};

	/**
	Sets the number of pixels to indent the contents of the menu item
	when it is painted

	@param nIndent the number of pixels to indent
	*/
	static void SetIndent(int nIndent) {m_nIndent = nIndent;};

	/**
	returns the number of pixels that menuitems will use to indexnt the contents
	of the menu item while it is painted

	@return the number of pixles to indent
	*/
	static int GetIndent(){return m_nIndent;};

	/**
	Sets the number of pixels to indent the menu item's contents from
	the right side.

	@param nRightIndent number of pixels to indent
	*/
	static void SetRightIndent( int nRightIndent ) { m_nRightIndent = nRightIndent; }

	/**
	Returns the number of pixels that the menu item's contents will be
	indented from the right side.

	@return number of pixels to indent
	*/
	static int GetRightIndent() { return m_nRightIndent; }

	// Horizontal text alignment
	static void SetAlignment( int nAlignment ) { m_nAlignment = nAlignment; }
	static int GetAlignment() { return m_nAlignment; }

	// Horizontal text alignment for titles
	static void SetTitleAlignment( UINT nTitleAlignment ) { m_nTitleAlignment = nTitleAlignment; }
	static int GetTitleAlignment() { return m_nTitleAlignment; }

	// Compares pM1 with pM2 and returns 'true' if pM1 is 'larger' than pM2
	// it returns 'false' otherwise
	static bool Compare(MenuItem* pM1,MenuItem* pM2);

	/**
	Sets if the bevels should be painted or not

	@param bDrawBevel should bevels be painted on menuitems?
	*/
	static void DrawBevel(BOOL bDrawBevel) {m_bDrawBevel = bDrawBevel;};

	/**
	Sets the color that shall be used to paint the dark areas of 3d effects.

	@param nColor the dark color
	*/
	static void SetDark(DWORD nColor) {m_nDarkColor = nColor;};

	/**
	Sets the color that shall be used to paint the bright areas of 3d effects.

	@param nColor the bright color
	*/
	static void SetLight(DWORD nColor) {m_nLightColor = nColor;};

protected:
	/// constat used when determinig the menuitem location compared to other menuitems
	int m_nSortPriority;

	/// number of pixels to indent when painting the foreground on the popup
	static int m_nIndent;

	/// number of pixels to indent from the right side
	static int m_nRightIndent;

	/// Horizontal text alignment (DT_*)
	static int m_nAlignment;
	static int m_nTitleAlignment;

	/// handle to icon to be painted on the menuitem
	HICON m_hIcon;

	/// should bevels be painted on the menu item
	static BOOL m_bDrawBevel;

	/// the 'dark' color to use when painting 3d effects
	static DWORD m_nDarkColor;

	/// the 'light' color to use when painting 3d effects
	static DWORD m_nLightColor;

	/**
	Tests if the pont x,y is on the menu item
	
	@param x the location
	@param y the location
	@return the point is over then returns 0
	*/
	BOOL IsOver(int x, int y);

	/// The popup menu that this item resides on
	PopupMenu* m_pParent;

	/// The key shortcut to this item
	int m_nShortcut;

	/// y location of the menuitem
	int m_nTop;

	/// x location of the menuitem
	int m_nLeft;

	/// the width of the menuitem
	int m_nWidth;

	/// the height of the menuitem
	int m_nHeight;

	/// the current active status of the menuitem
	BOOL m_bActive;

	/// pointer to the painter object that paints the default foreground
	Painter* m_pForeground;

	/// pointer to the painter object that paints the default background
	Painter* m_pBackground;

	/// pointer to the painter object that paints the active foreground
	Painter* m_pActiveForeground;

	/// pointer to the painter object that paints the active background
	Painter* m_pActiveBackground;
};

#endif // !defined(AFX_MENUITEM_H__D5612514_732D_11D2_B69F_00C0DF466974__INCLUDED_)
