/*
  Copyright (C) 2000, The Litestep Development Team

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "stdafx.h"
#include "re5ources.h"
#include "ShellFolder.h"

ShellFolder::ShellFolder( PopupMaker *pPopupMaker, IShellFolder *pshf, LPITEMIDLIST pidlFull, LPITEMIDLIST pidl, LPTSTR pszTitle, int iIcon, HIMAGELIST hImageList ) :
	FolderItem( NULL, pszTitle )
{
	m_pPopupMaker = pPopupMaker;
	m_pshf = pshf;
	m_pidlFull = pidlFull;
	m_pidl = pidl;
	m_iIcon = iIcon;
	m_hImageList = hImageList;
	m_hThread = INVALID_HANDLE_VALUE;
	m_pLoadingFolder = NULL;
	m_bFolderLoaded = FALSE;

	if( m_pshf )
		m_pshf->AddRef();
}

ShellFolder::ShellFolder( PopupMaker *pPopupMaker, LPTSTR pszTitle, int csidl )
	: FolderItem( NULL, NULL )
{
	m_pPopupMaker = pPopupMaker;
	m_pshf = NULL;
	m_pidlFull = NULL;
	m_pidl = NULL;
	m_iIcon = -1;
	m_hImageList = NULL;
	m_hThread = INVALID_HANDLE_VALUE;
	m_pLoadingFolder = NULL;
	m_bFolderLoaded = FALSE;

	SHGetSpecialFolderLocation( NULL, csidl, &m_pidlFull );

	if( m_pidlFull )
	{
		SHFILEINFO shfi;

		m_hImageList = (HIMAGELIST) SHGetFileInfo( (LPTSTR) m_pidlFull, 0,
			&shfi, sizeof(SHFILEINFO), SHGFI_ATTRIBUTES | SHGFI_DISPLAYNAME |
			SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SMALLICON );

		TrimLeft( shfi.szDisplayName );

		m_pszTitle = strdup( pszTitle ? pszTitle : shfi.szDisplayName );
		m_iIcon = m_pPopupMaker->m_bIcons ? shfi.iIcon : -1;

		if( shfi.dwAttributes & SFGAO_FOLDER && !(shfi.dwAttributes & SFGAO_REMOVABLE) )
		{
			IShellFolder *pshfDesktop;
			SHGetDesktopFolder( &pshfDesktop );

			pshfDesktop->BindToObject( m_pidlFull, NULL, IID_IShellFolder,
				(void **) &m_pshf );

			pshfDesktop->Release();
		}
	}
}

ShellFolder::~ShellFolder()
{
	if( m_pshf )
	{
		m_pshf->Release();
		m_pshf = NULL;
	}

	if( m_pidlFull )
	{
		FreeIDList( m_pidlFull );
		m_pidlFull = NULL;
	}

	if( m_pidl )
	{
		FreeIDList( m_pidl );
		m_pidl = NULL;
	}

	if( m_hThread != INVALID_HANDLE_VALUE )
	{
		TerminateThread( m_hThread, 0 );
		CloseHandle( m_hThread );
		m_hThread = INVALID_HANDLE_VALUE;
	}

	if( m_pLoadingFolder )
	{
		delete m_pLoadingFolder;
		m_pLoadingFolder = NULL;
	}
}

void ShellFolder::SetSubMenu( PopupMenu *pSubMenu )
{
	BOOL bSubMenuVisible = FALSE;

	if( m_pSubMenu )
	{
		bSubMenuVisible = IsWindowVisible( m_pSubMenu->GetWindow() );
		m_pSubMenu->Hide( HIDE_CHILDREN );

		m_pParent->RemoveChild( m_pSubMenu );

		delete m_pSubMenu;
		m_pSubMenu = NULL;
	}

	m_pSubMenu = pSubMenu;
	m_pParent->AddChild( m_pSubMenu );
	m_pSubMenu->SetParent( m_pParent );

	if( bSubMenuVisible )
		ShowSubMenu();
}

BOOL ShellFolder::Active( BOOL bActivate )
{
	if( IsLeaf() )
	{
		return TitleItem::Active( bActivate );
	}
	else
	{
		BOOL bRet = FolderItem::Active( bActivate );

		if( bActivate && !m_bFolderLoaded && m_hThread == INVALID_HANDLE_VALUE )
		{
			DWORD dwThreadID;

			m_hThread = CreateThread( NULL, 0, ThreadProc,
				(void *) this, 0, &dwThreadID );
		}

		return bRet;
	}
}

void ShellFolder::Attached( PopupMenu *pParent )
{
	m_pParent = pParent;

	if( !IsLeaf() )
	{
		PopupMenu *ppm = new PopupMenu( m_pPopupMaker->hInst );
		m_pPopupMaker->AddHeaderItem( ppm, GetTitle(), FALSE );

		MenuItem *pmi = new TitleItem( RESSTR(IDS_POPUP_LOADING) );
		pmi->SetActivePainter( NULL );
		pmi->SetPainter( m_pPopupMaker->m_pEntry );
		pmi->SetHeight( m_pPopupMaker->m_nSubmenuHeight );
		ppm->AddMenuItem( pmi );

		m_pPopupMaker->AddBottomItem( ppm );
		ppm->Validate();

		SetSubMenu( ppm );
	}
}

void ShellFolder::GetTitleRect( RECT *prc )
{
	if( IsLeaf() )
		TitleItem::GetTitleRect( prc );
	else
		FolderItem::GetTitleRect( prc );

	if( !m_hIcon && m_iIcon != -1 )
		prc->left = prc->left + GetHeight();
}

void ShellFolder::Invoke()
{
	if( IsLeaf() )
	{
		SHELLEXECUTEINFO sei;

		m_pParent->Hide( HIDE_PARENTS );

		sei.cbSize = sizeof(SHELLEXECUTEINFO);
		sei.fMask = SEE_MASK_INVOKEIDLIST | SEE_MASK_IDLIST;
		sei.hwnd = NULL;
		sei.lpVerb = NULL;
		sei.lpFile = NULL;
		sei.lpParameters = NULL;
		sei.lpDirectory = NULL;
		sei.nShow = SW_SHOW;
		sei.lpIDList = m_pidlFull;

		ShellExecuteEx( &sei );
	}
	else
	{
		FolderItem::Invoke();
	}
}

BOOL ShellFolder::IsLeaf()
{
	return m_pshf ? FALSE : TRUE;
}

void ShellFolder::Paint( HDC hDC )
{
	MenuItem::Paint( hDC );

	if( !m_hIcon && m_iIcon != -1 )
	{
		ImageList_Draw( m_hImageList, m_iIcon, hDC, 3 + GetIndent(),
			m_nTop + (GetHeight() - 16) / 2, ILD_TRANSPARENT );
	}

	RECT r;
	GetTitleRect( &r );

	DrawText( hDC, GetTitle(), lstrlen( GetTitle() ), &r,
		GetDrawTextFormat() );

	if( m_bDrawArrow && !IsLeaf() )
		PaintArrow( hDC, m_nTop );

	if( m_bDrawBevel )
		PaintBevel( hDC, m_nTop );
}

void ShellFolder::AsyncStart( LPARAM lParam )
{
	m_pLoadingFolder = new PopupMenu( m_pPopupMaker->hInst );
	m_pPopupMaker->AddHeaderItem( m_pLoadingFolder, GetTitle(), FALSE );
}

void ShellFolder::AsyncEnd( LPARAM lParam )
{
	m_pPopupMaker->AddBottomItem( m_pLoadingFolder );
	m_pLoadingFolder->Invalidate();
	m_pLoadingFolder->Validate();

	SetSubMenu( m_pLoadingFolder );
	m_pLoadingFolder = NULL;
}

void ShellFolder::AsyncAdd( LPARAM lParam )
{
	m_pLoadingFolder->AddMenuItem( (MenuItem *) lParam, SortFunction, m_pshf );
}

void ShellFolder::UpdateFolder()
{
	IEnumIDList *peidl;
	HRESULT hr;
	BOOL bEmpty = TRUE;

	hr = m_pshf->EnumObjects( NULL, SHCONTF_FOLDERS |
		SHCONTF_NONFOLDERS, &peidl );

	PostMessage( GetWindow(), PPM_ASYNC_START, (WPARAM) this, 0 );

	if( SUCCEEDED( hr ) )
	{
		LPITEMIDLIST pidl;

		while( peidl->Next( 1, &pidl, NULL ) == S_OK )
		{
			LPITEMIDLIST pidlFull = JoinIDLists( m_pidlFull, pidl );
			SHFILEINFO shfi;
				
			SHGetFileInfo( (LPCTSTR) pidlFull, 0, &shfi, sizeof(SHFILEINFO),
				SHGFI_ATTRIBUTES | SHGFI_DISPLAYNAME | SHGFI_SMALLICON |
				SHGFI_PIDL | SHGFI_SYSICONINDEX );

			TrimLeft( shfi.szDisplayName );

			MenuItem *pmi = NULL;

			if( shfi.dwAttributes & SFGAO_FOLDER )
			{
				IShellFolder *pshfFolder = NULL;

				if( !(shfi.dwAttributes & SFGAO_REMOVABLE) )
				{
					m_pshf->BindToObject( pidl, NULL, IID_IShellFolder,
						(void **) &pshfFolder );
				}

				pmi = new ShellFolder( m_pPopupMaker,
					pshfFolder,
					pidlFull,
					pidl,
					shfi.szDisplayName,
					m_pPopupMaker->m_bIcons ? shfi.iIcon : -1,
					m_hImageList );

				if( pshfFolder )
					pshfFolder->Release();
			}
			else
			{
				pmi = new ShellFolder( m_pPopupMaker,
					NULL,
					pidlFull,
					pidl,
					shfi.szDisplayName,
					m_pPopupMaker->m_bIcons ? shfi.iIcon : -1,
					m_hImageList );
			}

			if( pmi != NULL )
			{
				pmi->SetActivePainter( m_pPopupMaker->m_pSelEntry );
				pmi->SetPainter( m_pPopupMaker->m_pEntry );
				pmi->SetHeight( m_pPopupMaker->m_nSubmenuHeight );

				PostMessage( GetWindow(), PPM_ASYNC_ADD, (WPARAM) this, (LPARAM) pmi );
				bEmpty = FALSE;
			}
		}

		peidl->Release();
	}

	if( bEmpty )
	{
		MenuItem *pmi = new TitleItem( RESSTR(IDS_POPUP_EMPTY) );

		pmi->SetActivePainter( NULL );
		pmi->SetPainter( m_pPopupMaker->m_pEntry );
		pmi->SetHeight( m_pPopupMaker->m_nSubmenuHeight );

		PostMessage( GetWindow(), PPM_ASYNC_ADD, (WPARAM) this, (LPARAM) pmi );
	}

	PostMessage( GetWindow(), PPM_ASYNC_END, (WPARAM) this, 0 );
}

// returns true if m1 < m2
bool ShellFolder::SortFunction( void *pvSortParam, MenuItem *m1, MenuItem *m2 )
{
	if( m1->GetSortPriority() < m2->GetSortPriority() )
		return true;
	else if( m1->GetSortPriority() > m2->GetSortPriority() )
		return false;

	IShellFolder *pshf = (IShellFolder *) pvSortParam;

	ShellFolder *sf1 = (ShellFolder *) m1;
	ShellFolder *sf2 = (ShellFolder *) m2;

	return (short) HRESULT_CODE( pshf->CompareIDs( 0, sf1->m_pidl, sf2->m_pidl ) ) > 0;
}

DWORD WINAPI ShellFolder::ThreadProc( void *pvParameter )
{
	ShellFolder *pThis = (ShellFolder *) pvParameter;

	Sleep( 100 );

	if( pThis )
	{
		pThis->UpdateFolder();
		pThis->m_bFolderLoaded = TRUE;

		CloseHandle( pThis->m_hThread );
		pThis->m_hThread = INVALID_HANDLE_VALUE;
	}

	return 0;
}

LPITEMIDLIST CreateIDList( int cb )
{
	IMalloc *pMalloc;
	LPITEMIDLIST pidl = NULL;

	if( cb <= 0 )
		return NULL;

	if( SUCCEEDED( SHGetMalloc( &pMalloc ) ) )
	{
		pidl = (LPITEMIDLIST) pMalloc->Alloc( cb );
		pMalloc->Release();
	}

	if( pidl )
		memset( pidl, 0, cb );

	return pidl;
}

LPITEMIDLIST DuplicateIDList( LPCITEMIDLIST pidl )
{
	LPITEMIDLIST pidlNew;
	int cb = GetIDListSize( pidl );

	if( !pidl )
		return NULL;

	pidlNew = CreateIDList( cb );
	
	if( pidlNew )
		memcpy( pidlNew, pidl, cb );

	return pidlNew;
}

/* LPITEMIDLIST DuplicateLastID( LPCITEMIDLIST pidl )
{
	LPCITEMIDLIST pidlPrevious;

	if( !pidl || !pidl->mkid.cb )
		return NULL;

	do
	{
		pidlPrevious = pidl;
		pidl = NextID( pidl );
	}
	while( pidl->mkid.cb );

	return DuplicateIDList( pidlPrevious );
} */

LPITEMIDLIST JoinIDLists( LPCITEMIDLIST pidlA, LPCITEMIDLIST pidlB )
{
	LPITEMIDLIST pidl;
	int cbA, cbB;

	cbA = pidlA ? GetIDListSize( pidlA ) - sizeof( pidlA->mkid.cb ) : 0;
	cbB = GetIDListSize( pidlB );

	pidl = CreateIDList( cbA + cbB );

	if( pidl )
	{
		if( pidlA )
			memcpy( pidl, pidlA, cbA );

		memcpy( (LPBYTE) pidl + cbA, pidlB, cbB );
	}

	return pidl;
}

int GetIDListSize( LPCITEMIDLIST pidl )
{
	if( !pidl )
		return 0;

	int cb = sizeof( pidl->mkid.cb );

	while( pidl->mkid.cb )
	{
		cb = cb + pidl->mkid.cb;
		pidl = NextID( pidl );
	}

	return cb;
}

LPCITEMIDLIST NextID( LPCITEMIDLIST pidl )
{
	return (LPCITEMIDLIST) ((CONST BYTE *) pidl + pidl->mkid.cb);
}

void FreeIDList( LPITEMIDLIST pidl )
{
	IMalloc *pMalloc;

	if( SUCCEEDED( SHGetMalloc( &pMalloc ) ) )
	{
		pMalloc->Free( pidl );
		pMalloc->Release();
	}
}
