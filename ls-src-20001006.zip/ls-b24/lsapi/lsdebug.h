#pragma once

#ifndef __LSDEBUG_H
#define __LSDEBUG_H

#include <windows.h>
#include <stdio.h>

#ifdef _LSDEBUG
#ifndef _LSDEBUGBUFFER
static char debugBuffer[4096];
#define _LSDEBUGBUFFER
#endif

// _LSDEBUG0
static void lssprintf(char* buffer, const char* file, int line) {
  sprintf(buffer, "%s:%i", file, line);
}

// _LSDEBUG1
static void lssprintf(char* buffer, const char* file, int line, int msg) {
  sprintf(buffer, "%s:%i %i", file, line, msg);
}

static void lssprintf(char* buffer, const char* file, int line, const char* msg) {
  sprintf(buffer, "%s:%i %s", file, line, msg);
}

static void lssprintf(char* buffer, const char* file, int line, long msg) {
  sprintf(buffer, "%s:%i %li", file, line, msg);
}

// _LSDEBUG2
static void lssprintf(char* buffer, const char* file, int line, const char* text, int msg) {
  sprintf(buffer, "%s:%i %s = %i", file, line, text, msg);
}

static void lssprintf(char* buffer, const char* file, int line, const char* text, const char* msg) {
  sprintf(buffer, "%s:%i %s = %s", file, line, text, msg);
}

static void lssprintf(char* buffer, const char* file, int line, const char* text, long msg) {
  sprintf(buffer, "%s:%i %s = %li", file, line, text, msg);
}

#define _LSDEBUG0 lssprintf(debugBuffer, __FILE__, __LINE__); \
  OutputDebugString(debugBuffer);

#define _LSDEBUG1(msg) lssprintf(debugBuffer, __FILE__, __LINE__, msg); \
  OutputDebugString(debugBuffer);

#define _LSDEBUG2(text, msg) lssprintf(debugBuffer, __FILE__, __LINE__, text, msg); \
  OutputDebugString(debugBuffer);

// LiteStep Debug Function Start
#define _LSDEBUGFUNS(msg) _LSDEBUG2("Entering", msg) //OutputDebugString("Entering "#msg);
// LiteStep Debug Function End
#define _LSDEBUGFUNE(msg) _LSDEBUG2("Exiting", msg)

#define _LSDEBUGLASTERR _LSDEBUG2("Last Error", (int)GetLastError())

#else // !_LSDEBBUG

#define _LSDEBUG0
#define _LSDEBUG1(msg)
#define _LSDEBUG2(text, msg)

#define _LSDEBUGFUNS(msg)
#define _LSDEBUGFUNE(msg)

#define _LSDEBUGLASTERR
#endif

#endif