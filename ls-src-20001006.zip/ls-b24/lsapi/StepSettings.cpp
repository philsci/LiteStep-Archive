// StepSettings.cpp: implementation of the StepSettings class.
//
//////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786) // STL naming warnings
#pragma warning(disable: 4503) // STL naming warnings

#include <windows.h>
#include "StepSettings.h"
#include "lsapi.h"
#include "safestr.h"
#include <time.h>

#define VALUE_NOT_FOUND_STRING "\0x01"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
extern StepSettings *g_settings; // declared and handled in lsapi.cpp

StepSettings::StepSettings()
{
	ThemeInUse = FALSE;
	ThemeFile = "";
	StepFile = "";
}

StepSettings::~StepSettings()
{

}

FILE* StepSettings::Open(LPCTSTR szPath)
{
  FILE *f;

  f = fopen (szPath, "r");

  if (f)
  {
    fseek (f, 0, SEEK_SET);
  }

  return f;
}


BOOL StepSettings::Close (FILE *f)
{
  if (f)
  {
    fclose (f);
  }

  return TRUE;
}


BOOL StepSettings::ReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  char szTempBuffer[MAX_LINE_LENGTH];

  if (!f)
  {
    return FALSE;
  }

  while (ReadNextLine (f, szTempBuffer, sizeof (szTempBuffer)))
  {
    if (!ispunct (szTempBuffer[0]))
    {
      StrLCopy (szBuffer, szTempBuffer, dwLength);

      return TRUE;
    }
  }

  return FALSE;
}


BOOL StepSettings::ReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
  char szTempPrefix[MAX_LINE_LENGTH], szTempBuffer[MAX_LINE_LENGTH];
  int prefix_length;

  if (!f)
  {
    return FALSE;
  }

  szTempPrefix[0] = 0;

  if (szPrefix[0] != '*')
  {
    StrCopy (szTempPrefix, "*");
  }

  strcat (szTempPrefix, szPrefix);

  prefix_length = StrLen (szTempPrefix);

  while (ReadNextLine (f, szTempBuffer, sizeof (szTempBuffer)))
  {
    if (!strnicmp(szTempBuffer, szTempPrefix, prefix_length) && isspace(szTempBuffer[prefix_length]))
    {
      StrLCopy (szBuffer, szTempBuffer, dwLength);

      return TRUE;
    }
  }

  return FALSE;
}


BOOL StepSettings::ReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  char szTempBuffer[MAX_LINE_LENGTH];

  while (f && !feof (f))
  {
    StrCopy(szBuffer, "");

    if (!fgets (szTempBuffer, dwLength, f))
      break;

    StripComment(szTempBuffer);
    CleanString(szTempBuffer);

    if (szTempBuffer[0] && szTempBuffer[0] != ';')
    {
      // Because of caching, we can't do var expansion at this point
      //VarExpansion(szBuffer, szTempBuffer);
      StrCopy(szBuffer, szTempBuffer);
      return TRUE;
    }
  }

  return FALSE;
}

//---------------------------------------------------------
// Cleans leading & trailing blanks from the passed string
//---------------------------------------------------------
char* StepSettings::CleanString(char* szString)
{
  if (!szString)
    return NULL;

  char* temp = new char[StrLen(szString) + 1];
  char* current = szString;

  current += strspn(current, WHITESPACE);

  StrCopy(temp, current);

  current = &temp[StrLen(temp) - 1];

  while (isspace(*current))
    current--;

  current[1] = 0;
  StrCopy(szString, temp);

  delete[] temp;
  return szString;
}


//---------------------------------------------------------
// Strips any comments from the string
//---------------------------------------------------------
char* StepSettings::StripComment(char* szString)
{
  if (!szString)
    return NULL;

  int quoteLevel = 0;
  char lastQuote = 0;
  char* current = szString;

  for (; *current; current++)
  {
    switch (*current)
    {
      case '[':
        quoteLevel++;
        break;

      case ']':
        quoteLevel--;
        break;

      case '"':
      case '\'':
        if (lastQuote == *current)
        {
          quoteLevel--;
          lastQuote = 0;
        }
        else if (!lastQuote)
        {
          quoteLevel++;
          lastQuote = *current;
        }
        break;

      case ';':
        if (!quoteLevel)
        {
          *current = 0;
          return szString;
        }
    }
  }
  return szString;
}

void StepSettings::VarExpansion(char *buffer, const char * value)
{
  int i, j;
  char * startDollar, * endDollar;
  char * string1;
  char buf[MAX_LINE_LENGTH];
  char buf2[MAX_LINE_LENGTH];
  char bvalue[MAX_LINE_LENGTH];
  int StillVars = 1;
  char *envvar;
  VarMap::iterator it;
  char warning[MAX_LINE_LENGTH];

  if (buffer && value)
  {
    StrCopy(bvalue, value);
    CleanString(bvalue);
    StrCopy(buffer, bvalue);
  }
  else
  {
    if (buffer && !value)
      buffer[0] = '\0';
    return;
  }

  while (StillVars)
  {
    startDollar = strchr(bvalue, '$');
    if (startDollar)
    {
      endDollar = strchr(&startDollar[1], '$');
      if (endDollar)
      {
        i = StrLen(startDollar) - StrLen(endDollar) - 1;
        j = StrLen(bvalue) - StrLen(startDollar);
        string1 = startDollar;
        string1++;
        StrLCopy(buf, CharLower(string1), i);
        buf[i]='\0';

        envvar=NULL;

        string var_value;

        if (!GetVariable(buf, var_value)) {
          if (!GetRCString(buf, buf2, buf, 255)) {
            envvar = getenv(buf);
            if (envvar != NULL) {
              // caching environment variables
              AddVariable(buf, envvar);
            }
            else {
              // caching blank, prevent future lookups, errors
              AddVariable(buf, buf2);
              StrCopy(warning, "Uninitialized variable: ");
              strcat(warning, buf);
              strcat(warning, "\n\0");
              strcat(warning, "at line: ");
              strcat(warning, value);
              MessageBox(NULL, warning, "Uninitialized Variable", MB_OK | MB_ICONWARNING | MB_TOPMOST);
            }
          }
        }
        else {
          StrCopy(buf2,var_value.c_str());
        }
        if (bvalue != startDollar)
        {
          StrLCopy(buffer, bvalue, j);
          buffer[j] = '\0';
        }
        else
        {
          StrCopy(buffer, "");
        }

        if (envvar) {
          strcat(buffer,envvar);
        } else {
          strcat(buffer, buf2);
        }
        strcat(buffer, ++endDollar);
        StrCopy(bvalue, buffer);
      }
      else
      {
        StillVars = 0;
      }
    }
    else
    {
      StillVars = 0;
    }
  }
}

// reads, parses, and caches the file specified, returns as 'string' the path the file's cache was stored under
string StepSettings::CacheRCFile(LPCTSTR szPath) {
  char  buffer[MAX_LINE_LENGTH];
  char long_file[MAX_PATH_LENGTH];
  char *char_ptr;
  string rcFile;
	FILE *rc;
	
  GetFullPathName(szPath, MAX_PATH_LENGTH, long_file, &char_ptr);
  strlwr(long_file);
  rcFile = long_file;
	
	rc = Open(rcFile.c_str());

	if (!rc) {
		// could not open file, return blank file path
		return "";
	}
	
	if (FileToNameToLines.find(rcFile) != FileToNameToLines.end()) {
		// Re-parse, re-cache the file
		FileToNameToLines.erase(rcFile);
	}

	// put a vector in the map for main rc file
  FileToNameToLines[rcFile] = CacheMap();
	
  while (ReadNextLine(rc, buffer, sizeof (buffer)))
  {
		char buffer2[MAX_LINE_LENGTH];
		int endConfig = strcspn(buffer, WHITESPACE);
		strncpy(buffer2, buffer, endConfig);
		buffer2[endConfig] = '\0';

		strlwr(buffer2);

		char *begin;

		if (endConfig < strlen(buffer)) {
			begin = buffer + endConfig + 1;
		} else {
			begin = buffer + endConfig;
		}
			
		CleanString(begin);
		
		AddFileLine(rcFile.c_str(), buffer2, begin);

		// Add line from this file to cache of lines, overriding previous files
		AddLine(rcFile.c_str(), buffer2, begin);
	}

	Close(rc);

	return rcFile;
}

// Returns the first instance of a line in the cache
LPCTSTR StepSettings::FindLine(LPCTSTR szKeyName)
{
  TCHAR szCommand[256];
  StringAndStringVectorMap::iterator iter;

	strncpy(szCommand, szKeyName, 255);
	strlwr(szCommand);
	iter = NameToFileAndLines.find(szCommand);
	if (iter != NameToFileAndLines.end()) {
		// line exists in the line cache, so it must have an entry
		// only one file per name, so just get the first string in it
		return iter->second.second.begin()->c_str();
	}

  return NULL;
}


int StepSettings::GetRCInt(LPCTSTR szKeyName, int nDefault)
{
  int val = nDefault;
  LPCSTR line;
  char token[MAX_LINE_LENGTH];

  // Couldn't find it, look in theme.rc/step.rc
  line = FindLine(szKeyName);
  if (line)
  {
		// use first token now...FindLine returns remainder of line now
    if (GetToken(line, token, NULL, false))
      val = strtol(token, NULL, 0);

		/*// Store the value for future lookups
		char number[33];
		ltoa(val, number, 10);
		AddVariable(szKeyName, number);*/

		return val;
  } else {
		// Try to find the variable in the pre-defined set
    string value;

    if (GetVariable(szKeyName, value)) {
      return strtol(value.c_str(), NULL, 0);
		}
  }

	// nothing found, return default
	return nDefault;
}


BOOL StepSettings::GetRCBool(LPCTSTR szKeyName, BOOL ifFound)
{
  //bool val = !ifFound; // <-- changed because of warning, not sure
  BOOL val = !ifFound;
	BOOL cache_val = FALSE;
  char token[MAX_LINE_LENGTH];
  LPCSTR line;

  

  line = FindLine(szKeyName);
  if (line)
  {
		// use first token now...FindLine returns remainder of line now
    if (GetToken(line, token, NULL, false))
    {
      if (stricmp(token, "off") && stricmp(token, "false") && stricmp(token, "no"))
      {
				cache_val = TRUE;
        val = ifFound;
      }
    }
    else
    {
			cache_val = TRUE;
      val = ifFound;
    }
		if (cache_val)
			val = ifFound;
		else
			val = !ifFound;

		// Add variable to cache
		//AddVariable(szKeyName, (cache_val ? "true" : "false"));

		return val;
  }

	// nothing found, return !ifFound
	return !ifFound;
}


// AKA GetRCBoolTheWayGodIntendedIt()
BOOL StepSettings::GetRCBoolDef(LPCTSTR szKeyName, BOOL bDefault)
{
  BOOL result = bDefault;
  char token[MAX_LINE_LENGTH];
  LPCSTR line;
  string value;

  line = FindLine(szKeyName);
  if (line)
  {
    result = TRUE;
    if (GetToken(line, token, &line, false))
    {
      if (!(stricmp(token, "off") && stricmp(token, "false") && stricmp(token, "no")))
				result = FALSE;
    }
  } else {
		if (GetVariable(szKeyName, value))
		{
			return !stricmp(value.c_str(), "true");
		}
	}

	return result;
}


BOOL StepSettings::GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR line;
  BOOL result = FALSE;

  // couldn't find it, check theme/step vectors
  line = FindLine(szKeyName);
  if (line)
  {
		// use first token now...FindLine returns remainder of line now
    GetToken(line, token, NULL, false);
    VarExpansion(token, token);
    StrLCopy(szValue, token, maxLen);
		// cache variable to map for future use
		//AddVariable(szKeyName, szValue);

		return TRUE;
  } else {
		// check for predefined value
    string value;

    if (GetVariable(szKeyName, value))
    {
      StrLCopy(szValue, value.c_str(), maxLen);
	    return TRUE;
    }
  }

  StrLCopy (szValue, defStr, maxLen);
	return FALSE;
}


COLORREF StepSettings::GetRCColor(LPCTSTR szKeyName, COLORREF colDef)
{
  char token[MAX_LINE_LENGTH];
  LPCSTR line;

  line = FindLine(szKeyName);
  if (line)
  {
    int count = Tokenize(line, NULL, 0, NULL);

    if(count >= 3)
    {
      int r, g, b;

      GetToken(line, token, &line, false);
      r = strtol(token, NULL, 10);
      GetToken(line, token, &line, false);
      g = strtol(token, NULL, 10);
      GetToken(line, token, NULL, false);
      b = strtol(token, NULL, 10);

      return RGB(r, g, b);
    }
    else if(count >= 1)
    {
      GetToken(line, token, NULL, false);
      COLORREF val = strtol(token, NULL, 16);

      if(!GetRCBool("LSColorBGR", TRUE))
        val = RGB(GetBValue(val), GetGValue(val), GetRValue(val));
      return val;
    }
  }
	return colDef;
}


BOOL StepSettings::GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault)
{
  LPCTSTR line = NULL;

  // verify parameters
  if(!szBuffer || !nBufLen)
    return FALSE;

  if (!szKeyName)
  	return FALSE;

  // find it
 

  line = FindLine(szKeyName);

  if (line)
  {
		// copy complete line as is
    StrLCopy(szBuffer, line, nBufLen);

		return TRUE;
  }
  else {
		// check for predefined value
    string value;

    if (GetVariable(szKeyName, value))
    {
	    StrLCopy(szBuffer, value.c_str(), nBufLen);
		  return TRUE;
    }
  }

  if (szDefault) 
    StrLCopy(szBuffer, szDefault, nBufLen);
  else
    *szBuffer = '\0';

	return FALSE;
}

bool StepSettings::AddVariable(LPCSTR name, LPCSTR value)
{
  LPSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  VarMap::iterator it = stepVariables.find(lowerName);
  if (it == stepVariables.end())
  {
    stepVariables[lowerName] = value;
    result = true;
  }
  delete[] lowerName;
  return result;
}


bool StepSettings::GetVariable(LPCSTR name, string& value)
{
  LPSTR lowerName;
  bool result = false;
  VarMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  iter = stepVariables.find(lowerName);
  if (iter != stepVariables.end())
  {
    value = iter->second;
    result = true;
  }
  delete[] lowerName;
  return result;
}

// Add a line with the specified name and value to the cache
bool StepSettings::AddLine(LPCSTR filename, LPCSTR name, LPCSTR value)
{
  LPSTR lowerName;
  bool result = false;
  StringAndStringVectorMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  StringAndStringVectorMap::iterator it = NameToFileAndLines.find(lowerName);
  if (it == NameToFileAndLines.end() || NameToFileAndLines[lowerName].first != filename)
  {
		// nothing in cache yet, or a new file is overwriting previous settings,
		// create a StringAndStringVector to hold lines from this file
    NameToFileAndLines[lowerName] = StringAndStringVector(filename, StringVector());
	}

	// push the line into the cache
	NameToFileAndLines[lowerName].second.push_back(value);
  result = true;

  delete[] lowerName;
  return result;
}

// Get the top line with the specified value in the cache
bool StepSettings::GetLine(LPCSTR name, string& value)
{
  LPSTR lowerName;
  bool result = false;
  StringAndStringVectorMap::iterator iter;

  if (!StrLen(name))
    return false;

  lowerName = new char[StrLen(name) + 1];
  CharLower(StrCopy(lowerName, name));

  iter = NameToFileAndLines.find(lowerName);
  if (iter != NameToFileAndLines.end())
  {
		// return first line in the list
    value = iter->second.second.begin()->c_str();
    result = true;
  }
  delete[] lowerName;
  return result;
}

//---------------------------------------------------------
// Extracts the first token and returns a pointer to the
// next. Doesn't care about string lengths
//---------------------------------------------------------
BOOL StepSettings::GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets)
{
  LPCSTR current = szString;
  LPCSTR startMarker = NULL;
  LPCSTR endMarker = NULL;
  int bracketLevel = 0;
  char quoteChar = '\0';
  bool isToken = false;
	bool appendNextToken = false;

  if (szToken)
    szToken[0] = '\0';
  if (szNextToken)
    *szNextToken = NULL;

  if (!(szString && szString[0]))
    return FALSE;

  current += strspn(current, WHITESPACE);

  for (; *current; current++)
  {
    if (isspace(*current) && !quoteChar)
    {
      endMarker = current;
      break;
    }

    if (useBrackets && CharInStr(*current, "[]") && !CharInStr(quoteChar, "\'\""))
    {
      if (*current == '[')
      {
        if (isToken && !quoteChar)
        {
          endMarker = current;
          break;
        }
        bracketLevel++;
        quoteChar = '[';
        continue;
      }
      else
      {
        bracketLevel--;
        if (bracketLevel <= 0)
        {
          endMarker = current;
          break;
        }
      }
    }

    if (CharInStr(*current, "\'\"") && (quoteChar != '['))
    {
      if (!quoteChar)
      {
        if (isToken)
        {
					appendNextToken = true;
          endMarker = current;
          break;
        }
        quoteChar = *current;
        continue;
      }
      else if (*current == quoteChar)
      {
        endMarker = current;
        break;
      }
    }

    if (!isToken)
    {
      isToken = true;
      startMarker = current;
    }
  }

  if (startMarker && szToken)
    StrLCopy(szToken, startMarker, endMarker - startMarker);

  if (!appendNextToken && *current)
    current++;

  current += strspn(current, WHITESPACE);

  if (*current && szNextToken)
    *szNextToken = current;

	if (appendNextToken && *current)
    GetToken(current, szToken + strlen(szToken), szNextToken, useBrackets);

  return startMarker != NULL;
}

int StepSettings::Tokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters, bool useBrackets)
{
  DWORD i;
  char buffer[MAX_LINE_LENGTH];
  LPCSTR nextToken = buffer;
  DWORD tokens = 0;

  VarExpansion(buffer, szString);

  for (i = 0; i < dwNumBuffers; i++)
    if (lpszBuffers[i])
      lpszBuffers[i][0] = '\0';
  if (szExtraParameters)
    szExtraParameters[0] = '\0';

  if (lpszBuffers || szExtraParameters)
  {
    for (tokens = 0; nextToken && (tokens < dwNumBuffers); tokens++)
    {
      GetToken(nextToken, lpszBuffers[tokens], &nextToken, useBrackets);
    }

    if (szExtraParameters  && nextToken)
      StrCopy(szExtraParameters, nextToken);
  }
  else
    while (GetToken(nextToken, NULL, &nextToken, useBrackets))
      tokens++;

  return tokens;
}

FILE* StepSettings::LCOpen(LPCTSTR szPath)
{
	char full_path[MAX_PATH_LENGTH];
	char *char_ptr;

	if (szPath && strlen(szPath) > 0) {
		GetFullPathName(szPath, MAX_PATH_LENGTH, full_path, &char_ptr);
		strlwr(full_path);
	} else {
		strcpy(full_path, StepFile.c_str());
	}

	if (FileToNameToLines.find(full_path) == FileToNameToLines.end()) {
		// Have not read the file yet...read and cache
		if (CacheRCFile(full_path) == "") {
			MessageBox(NULL, "File not found", full_path, MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			return NULL;
		}
	}

	CacheState *state = new CacheState;

	state->filename = full_path;
	state->command_iter_valid = false;
	state->line_iter_valid = false;

	return (FILE*)state;
}


BOOL StepSettings::LCClose (FILE *f)
{
	if (f) {
		CacheState *state = (CacheState*)f;

		delete state;
	}

	return TRUE;
}


BOOL StepSettings::LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	return LCReadNextLine(f, szBuffer, dwLength);
}

BOOL StepSettings::LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
	if (!f) {
		return FALSE;
	}

	CacheState *state = (CacheState*)f;

	if (state->line_iter_valid) {
		// !!! We should not have line iter valid, error out !!!
		return FALSE;
	}

	// lowcasify
	char low_prefix[MAX_LINE_LENGTH];
	strcpy(low_prefix, szPrefix);
	strlwr(low_prefix);

	// first time through, get command iter
	if (!state->command_iter_valid) {
		state->command_iter = FileToNameToLines[state->filename].find(low_prefix);

		if (state->command_iter == FileToNameToLines[state->filename].end()) {
			// Command not found, clear and return
			state->command_iter_valid = false;

			return FALSE;
		}

		// command found, get line iter
		state->line_iter = state->command_iter->second.begin();
		state->command_iter_valid = true;
	}

	if (state->line_iter == state->command_iter->second.end()) {
		// end of this command, clear and return
		state->command_iter_valid = false;

		return FALSE;
	}

	// At this point we should have an acceptable config line, build and return it
	char buffer[MAX_LINE_LENGTH];

	buffer[0] = 0; // blank
	strcat(buffer, state->command_iter->first.c_str()); // command name
	strcat(buffer, " "); // space
	strcat(buffer, state->line_iter->c_str()); // configuration line

  VarExpansion(szBuffer, buffer);

	// just increment the config iter, leave it to the next loop to determine if it's valid
	state->line_iter++;

	return TRUE;
}


BOOL StepSettings::LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
	if (!f) {
		return FALSE;
	}

	CacheState *state = (CacheState*)f;

	if (state->command_iter_valid) {
		// !!! We should not have line iter valid, error out !!!
		return FALSE;
	}

	// first time through, get command iter
	if (!state->line_iter_valid) {
		state->line_map_iter = NameToFileAndLines.begin();

		if (state->line_map_iter == NameToFileAndLines.end()) {
			// Command not found, clear and return
			state->command_iter_valid = false;

			return FALSE;
		}

		// command found, get line iter
		state->line_iter = state->line_map_iter->second.second.begin();
		state->line_iter_valid = true;
	}

	if (state->line_iter == state->line_map_iter->second.second.end()) {
		// end of lines for this prefix, move to next
		state->line_map_iter++;

		if (state->line_map_iter == NameToFileAndLines.end()) {
			// end of lines, clear and return
			state->line_iter_valid = false;

			return FALSE;
		}

		state->line_iter = state->line_map_iter->second.second.begin();
	}

	// At this point we should have an acceptable config line, build and return it
	char buffer[MAX_LINE_LENGTH];

	buffer[0] = 0; // blank
	strcat(buffer, state->line_map_iter->first.c_str()); // command name
	strcat(buffer, " "); // space
	strcat(buffer, state->line_iter->c_str()); // configuration line

  VarExpansion(szBuffer, buffer);

	// just increment the config iter, leave it to the next loop to determine if it's valid
	state->line_iter++;

	return TRUE;
}

void StepSettings::SetStepFile(string step_file)
{
  StepFile = step_file;
}

void StepSettings::SetThemeFile(string theme_file)
{
  ThemeFile = theme_file;
  ThemeInUse = TRUE;
}

string StepSettings::GetStepFile()
{
  return StepFile;
}

string StepSettings::GetThemeFile()
{
  return ThemeFile;
}

void StepSettings::Clear()
{
  if (stepVariables.size()) {
	  stepVariables.clear();
  }
	
	if (NameToFileAndLines.size()) {
		NameToFileAndLines.clear();
	}

	// Clear the caches
  if (FileToNameToLines.size())
  {
	  FileToNameToLines.clear();
  }
}

CacheMapMap &StepSettings::GetFileToNameToLines() {
  return FileToNameToLines;
}

StringAndStringVectorMap &StepSettings::GetNameToFileAndLines() {
  return NameToFileAndLines;
}

void StepSettings::AddFileLine(LPCTSTR filename, LPCTSTR name, LPCTSTR value)
{
	// Add string vector if one doesn't exist
	CacheMap::iterator iter = FileToNameToLines[filename].find(name);
	if (iter == FileToNameToLines[filename].end()) {
		FileToNameToLines[filename][name] = StringVector();
	}
		
	// Add to list of lines for a given name in this file
	FileToNameToLines[filename][name].push_back(value);
}

// dll exports
FILE* LCOpen(LPCTSTR szPath)
{
  return g_settings->LCOpen(szPath);
}


BOOL LCClose (FILE *f)
{
  return g_settings->LCClose(f);
}


BOOL LCReadNextCommand (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextCommand(f, szBuffer, dwLength);
}


BOOL LCReadNextConfig (FILE *f, LPCSTR szPrefix, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextConfig(f, szPrefix, szBuffer, dwLength);
}


BOOL LCReadNextLine (FILE *f, LPSTR szBuffer, DWORD dwLength)
{
  return g_settings->LCReadNextLine(f, szBuffer, dwLength);
}


int LCTokenize (LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
  return g_settings->Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters);
}

BOOL GetToken(LPCSTR szString, LPSTR szToken, LPCSTR* szNextToken, BOOL useBrackets) {
  return g_settings->GetToken(szString, szToken, szNextToken, useBrackets);
}

int CommandTokenize(LPCSTR szString, LPSTR *lpszBuffers, DWORD dwNumBuffers, LPSTR szExtraParameters)
{
  return g_settings->Tokenize(szString, lpszBuffers, dwNumBuffers, szExtraParameters, true);
}


int GetRCInt(LPCTSTR szKeyName, int nDefault)
{
  return g_settings->GetRCInt(szKeyName, nDefault);
}


BOOL GetRCBool(LPCTSTR szKeyName, BOOL ifFound)
{
  return g_settings->GetRCBool(szKeyName, ifFound);
}


BOOL GetRCBoolDef(LPCTSTR szKeyName, BOOL bDefault)
{
  return g_settings->GetRCBoolDef(szKeyName, bDefault);
}


BOOL GetRCString(LPCTSTR szKeyName, LPSTR szValue, LPCTSTR defStr, int maxLen)
{
  return g_settings->GetRCString(szKeyName, szValue, defStr, maxLen);
}


COLORREF GetRCColor(LPCTSTR szKeyName, COLORREF colDef)
{
  return g_settings->GetRCColor(szKeyName, colDef);
}


BOOL GetRCLine(LPCTSTR szKeyName, LPTSTR szBuffer, UINT nBufLen, LPCTSTR szDefault)
{
  return g_settings->GetRCLine(szKeyName, szBuffer, nBufLen, szDefault);
}


void VarExpansion(char *buffer, const char * value)
{
  g_settings->VarExpansion(buffer, value);
}

