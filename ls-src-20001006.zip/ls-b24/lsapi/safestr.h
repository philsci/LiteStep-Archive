#ifndef __SAFESTR_H
#define __SAFESTR_H

#include <string>

using namespace std;


// Safe version of strlen()
inline size_t StrLen(const char* szString)
{
  return (szString ? strlen(szString) : 0);
}


// Safe version of strcpy()
inline char* StrCopy(char* szDest, const char* szSource)
{
  return (szDest && szSource ? strcpy(szDest, szSource) : NULL);
}


// Checks if chr exists in szString
bool CharInStr(const char chr, const char* szString);

// Returns the first occurrence of s2 in s1, ignoring case
const char* StrIPos(const char* s1, const char* s2);

// Copies at most dwMaxLen chars from the source
char* StrLCopy(char* szDest, const char* szSource, size_t dwMaxLen);


#endif
 