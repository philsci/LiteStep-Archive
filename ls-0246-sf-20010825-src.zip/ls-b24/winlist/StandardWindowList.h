/*
This is a part of the LiteStep Shell Source code.

Copyright (C) 1997-2001 The LiteStep Development Team

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

// StandardWindowList.h: interface for the StandardWindowList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_)
#define AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <vector>
#include "../core/ifcs.h"

#define WINDOWLIST_CLASS "WindowListClass"
#define WINDOWLIST_TITLE "Window List Manager"

using namespace std;

class StandardWindowList: public IWindowList
{
public:
	StandardWindowList();
	virtual ~StandardWindowList();
	
	////////////////////////////////////////////////////////////////////////////
	// From IUnknown
    HRESULT STDMETHODCALLTYPE QueryInterface( 
        /* [in] */ REFIID riid,
        /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
		
	ULONG STDMETHODCALLTYPE AddRef( void);
    
    ULONG STDMETHODCALLTYPE Release( void);
	
	/////////////////////////////////////////////////////////////////////////////
	// From IWindowList
	virtual HWND STDMETHODCALLTYPE GetWindow( 
        /* [in] */ long index);
        
    virtual long STDMETHODCALLTYPE FindWindow( 
        /* [in] */ HWND hwnd);
    
    virtual long STDMETHODCALLTYPE GetWindowList( 
        /* [out] */ HWND __RPC_FAR *wlist,
        /* [in] */ long cNumSlots);
    
    virtual long STDMETHODCALLTYPE GetWindowCount( void);
    
    virtual long STDMETHODCALLTYPE EnumerateWindows( 
        /* [in] */ WINDOWLISTENUMPROC enumProc,
        /* [in] */ LPARAM lParam);

	/////////////////////////////////////////////////////////////////////////////
	// Internal methods
	LRESULT WindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);
	static LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam);
	static int CALLBACK EnumProc(HWND hwnd, LPARAM lParam);

private:
	typedef vector<HWND> hwndVect;

	long refCount;
	hwndVect windowList;
	//HWND winList[200];
	//int nWin;
	BOOL InWinList(HWND hwnd);
	HINSTANCE hInstance;
	void AddWindow(HWND hwnd);
	void RemoveWindow(HWND hwnd);
	HWND hWnd;
	HWND hWndParent;

};

#endif // !defined(AFX_STANDARDWINDOWLIST_H__062597E6_70B9_4F8C_9AFF_4F3734B08452__INCLUDED_)
